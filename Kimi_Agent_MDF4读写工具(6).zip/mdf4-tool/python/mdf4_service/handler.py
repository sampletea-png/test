"""
Command Handler

Handles MDF4 file operations based on received commands.
Uses strongly typed request/response instead of Map.
"""

import logging
import base64
import io
import numpy as np
import threading
from asammdf import MDF, Signal


class CommandHandler:
    """Command handler for MDF4 operations"""

    def __init__(self):
        self.open_files = {}  # file_id -> {'mdf': MDF, 'mode': 'r'|'w', 'path': str}
        self.file_counter = 0
        self.logger = logging.getLogger(__name__)
        self.lock = threading.Lock()

    def handle(self, command):
        """Handle command
        
        Args:
            command: dict with 'type' and other fields
            
        Returns:
            Response dict with 'status' and other fields
        """
        cmd_type = command.get('type')

        self.logger.debug(f"Handling command: {cmd_type}")

        handlers = {
            'OPEN_READ': self._handle_open_read,
            'OPEN_WRITE': self._handle_open_write,
            'GET_SIGNALS': self._handle_get_signals,
            'GET_SIGNAL_INFO': self._handle_get_signal_info,
            'READ_SIGNAL': self._handle_read_signal,
            'READ_SIGNALS_BATCH': self._handle_read_signals_batch,
            'READ_SIGNAL_CHUNK': self._handle_read_signal_chunk,
            'APPEND_SIGNAL_CHUNK': self._handle_append_signal_chunk,
            'SET_COMPRESSION': self._handle_set_compression,
            'SAVE': self._handle_save,
            'CLOSE': self._handle_close,
            'GET_INFO': self._handle_get_info,
            'PING': self._handle_ping,
        }

        handler = handlers.get(cmd_type)
        if handler:
            try:
                return handler(command)
            except Exception as e:
                self.logger.error(f"Error handling {cmd_type}: {e}")
                return {'status': 'ERROR', 'message': str(e)}
        else:
            return {'status': 'ERROR', 'message': f'Unknown command: {cmd_type}'}

    def _handle_open_read(self, command):
        """Open file for reading"""
        file_path = command['filePath']
        mdf = MDF(file_path)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'r',
                'path': file_path
            }

        self.logger.info(f"Opened file for reading: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'fileId': file_id,
            'version': mdf.version
        }

    def _handle_open_write(self, command):
        """Open file for writing"""
        import os
        file_path = command['filePath']
        version = command.get('version', '4.10')

        # Ensure directory exists
        dir_path = os.path.dirname(file_path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
            self.logger.info(f"Created directory: {dir_path}")

        # Create new MDF file
        mdf = MDF(version=version)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'w',
                'path': file_path,
                'signals': {}  # Store signal data for batch append
            }

        self.logger.info(f"Created file for writing: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'fileId': file_id,
            'version': version
        }

    def _handle_get_signals(self, command):
        """Get all signal names"""
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal_names = []

        for group in mdf.groups:
            for channel in group.channels:
                signal_names.append(channel.name)

        return {
            'status': 'OK',
            'signalNames': signal_names
        }

    def _handle_get_signal_info(self, command):
        """Get signal information"""
        file_id = command['fileId']
        signal_name = command['signalName']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        return {
            'status': 'OK',
            'sampleCount': len(signal.samples) if signal.samples is not None else 0,
            'unit': signal.unit,
            'comment': signal.comment
        }

    def _handle_read_signal(self, command):
        """Read signal data"""
        file_id = command['fileId']
        signal_name = command['signalName']
        start_time = command.get('startTime')
        end_time = command.get('endTime')

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        # Time range filtering
        timestamps = signal.timestamps
        samples = signal.samples

        if start_time is not None or end_time is not None:
            mask = np.ones(len(timestamps), dtype=bool)
            if start_time is not None:
                mask &= timestamps >= start_time
            if end_time is not None:
                mask &= timestamps <= end_time
            timestamps = timestamps[mask]
            samples = samples[mask]

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'dataType': str(samples.dtype) if samples is not None else 'unknown',
            'timestampsBase64': self._encode_array(timestamps),
            'samplesBase64': self._encode_array(samples)
        }

    def _handle_read_signals_batch(self, command):
        """Read multiple signals (batch)"""
        file_id = command['fileId']
        signal_names = command['signalNames']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signals_data = {}

        for signal_name in signal_names:
            signal = mdf.get(signal_name)
            signals_data[signal_name] = {
                'name': signal.name,
                'unit': signal.unit,
                'description': signal.comment,
                'dataType': str(signal.samples.dtype) if signal.samples is not None else 'unknown',
                'timestampsBase64': self._encode_array(signal.timestamps),
                'samplesBase64': self._encode_array(signal.samples)
            }

        return {
            'status': 'OK',
            'signals': signals_data
        }

    def _handle_read_signal_chunk(self, command):
        """Read signal data in chunks"""
        file_id = command['fileId']
        signal_name = command['signalName']
        offset = command.get('offset', 0)
        limit = command.get('limit', 10000)

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        timestamps = signal.timestamps
        samples = signal.samples

        # Apply chunk range
        start = int(offset)
        end = min(start + int(limit), len(timestamps))

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'dataType': str(samples.dtype) if samples is not None else 'unknown',
            'timestampsBase64': self._encode_array(timestamps[start:end]),
            'samplesBase64': self._encode_array(samples[start:end]),
            'offset': offset,
            'count': end - start
        }

    def _handle_append_signal_chunk(self, command):
        """Append signal data chunk"""
        file_id = command['fileId']
        name = command['name']
        timestamps_b64 = command['timestampsBase64']
        samples_b64 = command['samplesBase64']
        config = command.get('config', {})
        is_last = command.get('last', False)

        self.logger.debug(f"Append signal chunk: file_id={file_id}, name={name}, is_last={is_last}")

        file_info = self.open_files.get(file_id)
        if not file_info:
            self.logger.error(f"File not open: {file_id}")
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Decode arrays
        timestamps = self._decode_array(timestamps_b64)
        samples = self._decode_array(samples_b64)

        self.logger.debug(f"Decoded arrays: timestamps={len(timestamps)}, samples={len(samples)}")

        # Store signal data in file_info for accumulation
        if name not in file_info['signals']:
            file_info['signals'][name] = {
                'timestamps': [],
                'samples': [],
                'config': config
            }
        
        file_info['signals'][name]['timestamps'].append(timestamps)
        file_info['signals'][name]['samples'].append(samples)

        # If this is the last chunk, append the complete signal to MDF
        if is_last:
            signal_data = file_info['signals'][name]
            all_timestamps = np.concatenate(signal_data['timestamps'])
            all_samples = np.concatenate(signal_data['samples'])
            
            self.logger.info(f"Creating signal '{name}' with {len(all_samples)} samples")
            
            try:
                # Ensure arrays are numpy arrays with correct dtype
                all_timestamps = np.asarray(all_timestamps, dtype=np.float64)
                all_samples = np.asarray(all_samples, dtype=np.float64)
                
                self.logger.debug(f"Timestamps dtype: {all_timestamps.dtype}, shape: {all_timestamps.shape}")
                self.logger.debug(f"Samples dtype: {all_samples.dtype}, shape: {all_samples.shape}")
                
                # Create Signal object and append to MDF
                signal = Signal(
                    samples=all_samples,
                    timestamps=all_timestamps,
                    name=name,
                    unit=config.get('unit', ''),
                    comment=config.get('description', '')
                )
                mdf.append(signal)
                
                self.logger.info(f"Successfully appended signal '{name}' to file {file_id}")
            except Exception as e:
                self.logger.error(f"Failed to append signal: {e}")
                import traceback
                self.logger.error(traceback.format_exc())
                return {'status': 'ERROR', 'message': f'Failed to append signal: {str(e)}'}

        return {
            'status': 'OK',
            'appended': len(samples)
        }

    def _handle_set_compression(self, command):
        """Set compression level"""
        file_id = command['fileId']
        level = command['level']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        # Set compression (implementation depends on asammdf version)
        # mdf = file_info['mdf']
        # mdf.configure(compression=level)

        self.logger.info(f"Set compression level {level} for file: {file_info['path']}")

        return {'status': 'OK'}

    def _handle_save(self, command):
        """Save file"""
        import os
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            self.logger.error(f"File not open for save: {file_id}")
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        file_path = file_info['path']

        self.logger.info(f"Saving file: {file_path}")

        # Ensure directory exists before saving
        dir_path = os.path.dirname(file_path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
            self.logger.info(f"Created directory: {dir_path}")

        try:
            mdf.save(file_path, overwrite=True)
            self.logger.info(f"Successfully saved file: {file_path}")
            return {'status': 'OK'}
        except Exception as e:
            self.logger.error(f"Failed to save file: {e}")
            return {'status': 'ERROR', 'message': f'Failed to save file: {str(e)}'}

    def _handle_close(self, command):
        """Close file"""
        file_id = command['fileId']
        file_info = self.open_files.pop(file_id, None)

        if file_info:
            mdf = file_info['mdf']
            mdf.close()
            self.logger.info(f"Closed file: {file_info['path']}")

        return {'status': 'OK'}

    def _handle_get_info(self, command):
        """Get file information"""
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Calculate total channels
        channel_count = sum(len(group.channels) for group in mdf.groups)

        return {
            'status': 'OK',
            'version': mdf.version,
            'channelGroupCount': len(mdf.groups),
            'channelCount': channel_count,
            'recordCount': 0,  # Placeholder
            'startTime': str(mdf.header.start_time) if mdf.header.start_time else None,
            'duration': mdf.header.duration if hasattr(mdf.header, 'duration') else 0.0
        }

    def _handle_ping(self, command):
        """Ping handler"""
        return {'status': 'OK', 'message': 'pong'}

    def _encode_array(self, arr):
        """Encode numpy array to base64 string
        
        Encode as raw bytes (8 bytes per double) for compatibility with Java ByteBuffer.
        """
        if arr is None or len(arr) == 0:
            return ''

        # Convert to float64 if not already
        arr = np.asarray(arr, dtype=np.float64)
        # Convert to raw bytes (8 bytes per double)
        raw_bytes = arr.tobytes()
        return base64.b64encode(raw_bytes).decode('utf-8')

    def _decode_array(self, b64_str):
        """Decode base64 string to numpy array
        
        The Java side encodes double arrays as raw bytes (8 bytes per double),
        not as numpy .npy format. So we need to decode it accordingly.
        """
        if not b64_str:
            return np.array([])

        try:
            # Try numpy .npy format first (for backward compatibility)
            buffer = io.BytesIO(base64.b64decode(b64_str))
            return np.load(buffer, allow_pickle=False)
        except Exception:
            # Fall back to raw bytes decoding (Java ByteBuffer format)
            raw_bytes = base64.b64decode(b64_str)
            # Each double is 8 bytes
            num_doubles = len(raw_bytes) // 8
            # Use numpy's frombuffer to decode raw bytes as doubles
            return np.frombuffer(raw_bytes, dtype=np.float64, count=num_doubles)
