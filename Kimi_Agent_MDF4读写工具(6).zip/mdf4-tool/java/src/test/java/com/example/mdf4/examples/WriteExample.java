package com.example.mdf4.examples;

import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.MDF4Writer;
import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.pool.PoolConfig;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * MDF4写入示例
 * <p>
 * 演示如何创建MDF4文件并写入信号数据。
 * </p>
 */
public class WriteExample {

    public static void main(String[] args) {
        MDF4ServiceManager manager = null;

        try {
            // 初始化服务
            PoolConfig config = new PoolConfig();
            config.setMaxConnections(2);

            manager = MDF4ServiceManager.getInstance();
            manager.initialize(config);

            // 创建输出目录
            Path outputDir = Paths.get("target/test-output");
            Files.createDirectories(outputDir);
            String outputFile = outputDir.resolve("new_file.mf4").toAbsolutePath().toString();

            System.out.println("Output file: " + outputFile);

            try (MDF4Writer writer = manager.createWriter()) {
                // 创建新文件
                String fileId = writer.create(outputFile, "4.10");

                // 准备时间戳和数据
                int sampleCount = 1000;
                double[] timestamps = new double[sampleCount];
                double[] samples = new double[sampleCount];

                for (int i = 0; i < sampleCount; i++) {
                    timestamps[i] = i * 0.01;  // 10ms间隔
                    samples[i] = Math.sin(i * 0.1);
                }

                // 配置信号
                SignalConfig voltageConfig = SignalConfig.builder()
                        .unit("V")
                        .description("Voltage signal")
                        .dataType("FLOAT64")
                        .build();

                // 追加信号
                writer.appendSignal(fileId, "Voltage", timestamps, samples, voltageConfig);

                // 添加另一个信号
                SignalConfig currentConfig = SignalConfig.builder()
                        .unit("A")
                        .description("Current signal")
                        .dataType("FLOAT64")
                        .build();

                double[] currentSamples = new double[sampleCount];
                for (int i = 0; i < sampleCount; i++) {
                    currentSamples[i] = Math.cos(i * 0.1) * 0.5;
                }

                writer.appendSignal(fileId, "Current", timestamps, currentSamples, currentConfig);

                // 设置压缩
                writer.setCompression(fileId, 6);

                // 保存文件
                writer.save(fileId);

                // 关闭文件
                writer.close(fileId);

                System.out.println("File created successfully!");
            }

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);  // 异常退出
        } finally {
            // 确保服务被关闭
            if (manager != null) {
                System.out.println("Shutting down MDF4 service...");
                manager.shutdown();
            }
        }
    }
}
