package com.example.mdf4.pool;

import com.example.mdf4.exception.MDF4Exception;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * MDF4连接池 - 自定义实现（不依赖Apache Commons Pool2）
 * <p>
 * 特性：
 * - 支持最大/最小连接数限制
 * - 连接空闲超时自动回收
 * - 连接有效性检测
 * - 线程安全的连接借用/归还
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4ConnectionPool {
    private static final Logger logger = LoggerFactory.getLogger(MDF4ConnectionPool.class);

    private final PoolConfig config;
    private final MDF4ConnectionFactory factory;

    // 空闲连接队列
    private final BlockingQueue<MDF4Connection> idleConnections;

    // 活跃连接集合
    private final ConcurrentHashMap<String, MDF4Connection> activeConnections;

    // 连接计数器
    private final AtomicInteger connectionCounter;

    // 总连接数（包括活跃和空闲）
    private final AtomicInteger totalConnections;

    // 锁，用于创建新连接
    private final ReentrantLock createLock;

    // 连接池关闭标志
    private volatile boolean closed;

    // 连接回收调度器
    private final ScheduledExecutorService evictionScheduler;

    public MDF4ConnectionPool(MDF4ConnectionFactory factory, PoolConfig config) {
        this.factory = factory;
        this.config = config;
        this.idleConnections = new LinkedBlockingQueue<>();
        this.activeConnections = new ConcurrentHashMap<>();
        this.connectionCounter = new AtomicInteger(0);
        this.totalConnections = new AtomicInteger(0);
        this.createLock = new ReentrantLock();
        this.closed = false;

        // 启动空闲连接回收调度器
        this.evictionScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "MDF4-Pool-Evictor");
            t.setDaemon(true);
            return t;
        });
        this.evictionScheduler.scheduleWithFixedDelay(
                this::evictIdleConnections,
                config.getEvictionIntervalMillis(),
                config.getEvictionIntervalMillis(),
                TimeUnit.MILLISECONDS
        );

        // 初始化最小连接数
        initializeMinConnections();

        logger.info("MDF4ConnectionPool created with config: {}", config);
    }

    /**
     * 初始化最小连接数
     */
    private void initializeMinConnections() {
        int minIdle = config.getMinIdle();
        for (int i = 0; i < minIdle; i++) {
            try {
                MDF4Connection conn = createConnection();
                if (conn != null) {
                    idleConnections.offer(conn);
                }
            } catch (Exception e) {
                logger.warn("Failed to create initial connection: {}", e.getMessage());
            }
        }
    }

    /**
     * 借用连接
     *
     * @return MDF4连接
     * @throws MDF4Exception 如果获取失败
     */
    public MDF4Connection borrowConnection() throws MDF4Exception {
        return borrowConnection(config.getMaxWaitMillis(), TimeUnit.MILLISECONDS);
    }

    /**
     * 借用连接（带超时）
     *
     * @param timeout 超时时间
     * @param unit    时间单位
     * @return MDF4连接
     * @throws MDF4Exception 如果获取失败或超时
     */
    public MDF4Connection borrowConnection(long timeout, TimeUnit unit) throws MDF4Exception {
        if (closed) {
            throw new MDF4Exception("Connection pool is closed");
        }

        long deadline = System.currentTimeMillis() + unit.toMillis(timeout);

        while (System.currentTimeMillis() < deadline) {
            // 1. 尝试从空闲队列获取
            MDF4Connection conn = idleConnections.poll();
            if (conn != null) {
                if (validateConnection(conn)) {
                    conn.setBorrowTime(System.currentTimeMillis());
                    activeConnections.put(conn.getConnectionId(), conn);
                    logger.debug("Connection borrowed from idle pool: {}", conn.getConnectionId());
                    return conn;
                } else {
                    // 连接无效，关闭并继续
                    closeConnection(conn);
                }
            }

            // 2. 尝试创建新连接
            if (totalConnections.get() < config.getMaxConnections()) {
                MDF4Connection newConn = createConnection();
                if (newConn != null) {
                    newConn.setBorrowTime(System.currentTimeMillis());
                    activeConnections.put(newConn.getConnectionId(), newConn);
                    logger.debug("New connection created and borrowed: {}", newConn.getConnectionId());
                    return newConn;
                }
            }

            // 3. 等待一段时间后重试
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new MDF4Exception("Interrupted while waiting for connection", e);
            }
        }

        throw new MDF4Exception("Timeout waiting for connection");
    }

    /**
     * 归还连接
     *
     * @param connection 连接对象
     */
    public void returnConnection(MDF4Connection connection) {
        if (connection == null) {
            return;
        }

        // 从活跃连接中移除
        activeConnections.remove(connection.getConnectionId());

        if (closed) {
            closeConnection(connection);
            return;
        }

        // 验证连接是否有效
        if (!validateConnection(connection)) {
            closeConnection(connection);
            return;
        }

        // 重置连接状态
        connection.setBorrowTime(0);
        connection.setLastReturnTime(System.currentTimeMillis());

        // 归还到空闲队列
        if (!idleConnections.offer(connection)) {
            // 队列已满，关闭连接
            closeConnection(connection);
        } else {
            logger.debug("Connection returned to idle pool: {}", connection.getConnectionId());
        }
    }

    /**
     * 创建新连接
     *
     * @return 新连接，如果创建失败返回null
     */
    private MDF4Connection createConnection() {
        createLock.lock();
        try {
            // 双重检查
            if (totalConnections.get() >= config.getMaxConnections()) {
                return null;
            }

            String connId = "conn-" + connectionCounter.incrementAndGet();
            MDF4Connection conn = factory.createConnection(connId);

            if (conn != null) {
                totalConnections.incrementAndGet();
                logger.debug("Connection created: {}", connId);
            }

            return conn;
        } catch (Exception e) {
            logger.error("Failed to create connection", e);
            return null;
        } finally {
            createLock.unlock();
        }
    }

    /**
     * 验证连接是否有效
     *
     * @param connection 连接
     * @return 是否有效
     */
    private boolean validateConnection(MDF4Connection connection) {
        if (connection == null) {
            return false;
        }

        // 检查连接是否已关闭
        if (!connection.isValid()) {
            return false;
        }

        // 检查连接是否超过最大生命周期
        long lifetime = System.currentTimeMillis() - connection.getCreateTime();
        if (lifetime > config.getMaxLifetimeMillis()) {
            return false;
        }

        return true;
    }

    /**
     * 关闭连接
     *
     * @param connection 连接
     */
    private void closeConnection(MDF4Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                totalConnections.decrementAndGet();
                logger.debug("Connection closed: {}", connection.getConnectionId());
            } catch (Exception e) {
                logger.warn("Error closing connection: {}", e.getMessage());
            }
        }
    }

    /**
     * 回收空闲连接
     */
    private void evictIdleConnections() {
        if (closed) {
            return;
        }

        List<MDF4Connection> toEvict = new ArrayList<>();

        // 遍历空闲连接，找出需要回收的
        for (MDF4Connection conn : idleConnections) {
            long idleTime = System.currentTimeMillis() - conn.getLastReturnTime();

            // 超过空闲超时时间，或者超过最大连接数
            if (idleTime > config.getIdleTimeoutMillis() ||
                    idleConnections.size() > config.getMaxIdle()) {
                if (idleConnections.remove(conn)) {
                    toEvict.add(conn);
                }
            }
        }

        // 关闭需要回收的连接
        for (MDF4Connection conn : toEvict) {
            closeConnection(conn);
        }

        // 确保最小连接数
        while (idleConnections.size() < config.getMinIdle() &&
                totalConnections.get() < config.getMaxConnections()) {
            MDF4Connection conn = createConnection();
            if (conn != null) {
                if (!idleConnections.offer(conn)) {
                    closeConnection(conn);
                    break;
                }
            } else {
                break;
            }
        }
    }

    /**
     * 关闭连接池
     */
    public void shutdown() {
        if (closed) {
            return;
        }

        closed = true;
        logger.info("Shutting down MDF4ConnectionPool...");

        // 停止调度器
        evictionScheduler.shutdown();

        // 关闭所有活跃连接
        for (MDF4Connection conn : activeConnections.values()) {
            closeConnection(conn);
        }
        activeConnections.clear();

        // 关闭所有空闲连接
        MDF4Connection conn;
        while ((conn = idleConnections.poll()) != null) {
            closeConnection(conn);
        }

        // 终止所有Python进程
        factory.destroyAllProcesses();

        logger.info("MDF4ConnectionPool shut down");
    }

    // Getters for monitoring

    public int getActiveCount() {
        return activeConnections.size();
    }

    public int getIdleCount() {
        return idleConnections.size();
    }

    public int getTotalCount() {
        return totalConnections.get();
    }

    public boolean isClosed() {
        return closed;
    }
}
