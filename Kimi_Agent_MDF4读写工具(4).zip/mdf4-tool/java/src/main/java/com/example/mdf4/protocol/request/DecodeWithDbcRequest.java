package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * DBC解码请求
 */
public class DecodeWithDbcRequest {
    private final RequestType type = RequestType.DECODE_WITH_DBC;
    private String mdfPath;
    private String dbcPath;
    private String outputPath;

    public DecodeWithDbcRequest() {
    }

    public DecodeWithDbcRequest(String mdfPath, String dbcPath, String outputPath) {
        this.mdfPath = mdfPath;
        this.dbcPath = dbcPath;
        this.outputPath = outputPath;
    }

    public RequestType getType() {
        return type;
    }

    public String getMdfPath() {
        return mdfPath;
    }

    public void setMdfPath(String mdfPath) {
        this.mdfPath = mdfPath;
    }

    public String getDbcPath() {
        return dbcPath;
    }

    public void setDbcPath(String dbcPath) {
        this.dbcPath = dbcPath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }
}
