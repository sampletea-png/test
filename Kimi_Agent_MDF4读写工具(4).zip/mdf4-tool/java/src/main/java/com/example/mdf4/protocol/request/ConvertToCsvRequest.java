package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * MDF4转CSV请求
 */
public class ConvertToCsvRequest {
    private final RequestType type = RequestType.CONVERT_TO_CSV;
    private String mdfPath;
    private String csvPath;
    private String delimiter;
    private boolean includeTime;
    private String timeFormat;

    public ConvertToCsvRequest() {
    }

    public ConvertToCsvRequest(String mdfPath, String csvPath, String delimiter, boolean includeTime, String timeFormat) {
        this.mdfPath = mdfPath;
        this.csvPath = csvPath;
        this.delimiter = delimiter;
        this.includeTime = includeTime;
        this.timeFormat = timeFormat;
    }

    public RequestType getType() {
        return type;
    }

    public String getMdfPath() {
        return mdfPath;
    }

    public void setMdfPath(String mdfPath) {
        this.mdfPath = mdfPath;
    }

    public String getCsvPath() {
        return csvPath;
    }

    public void setCsvPath(String csvPath) {
        this.csvPath = csvPath;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    public boolean isIncludeTime() {
        return includeTime;
    }

    public void setIncludeTime(boolean includeTime) {
        this.includeTime = includeTime;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }
}
