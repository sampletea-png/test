package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

import java.util.List;

/**
 * 合并文件请求
 */
public class ConcatenateRequest {
    private final RequestType type = RequestType.CONCATENATE;
    private List<String> mdfPaths;
    private String outputPath;

    public ConcatenateRequest() {
    }

    public ConcatenateRequest(List<String> mdfPaths, String outputPath) {
        this.mdfPaths = mdfPaths;
        this.outputPath = outputPath;
    }

    public RequestType getType() {
        return type;
    }

    public List<String> getMdfPaths() {
        return mdfPaths;
    }

    public void setMdfPaths(List<String> mdfPaths) {
        this.mdfPaths = mdfPaths;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }
}
