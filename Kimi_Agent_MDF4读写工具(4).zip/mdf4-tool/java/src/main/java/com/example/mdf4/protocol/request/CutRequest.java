package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 裁剪文件请求
 */
public class CutRequest {
    private final RequestType type = RequestType.CUT;
    private String inputPath;
    private String outputPath;
    private Double startTime;
    private Double endTime;

    public CutRequest() {
    }

    public CutRequest(String inputPath, String outputPath, Double startTime, Double endTime) {
        this.inputPath = inputPath;
        this.outputPath = outputPath;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public RequestType getType() {
        return type;
    }

    public String getInputPath() {
        return inputPath;
    }

    public void setInputPath(String inputPath) {
        this.inputPath = inputPath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    public Double getStartTime() {
        return startTime;
    }

    public void setStartTime(Double startTime) {
        this.startTime = startTime;
    }

    public Double getEndTime() {
        return endTime;
    }

    public void setEndTime(Double endTime) {
        this.endTime = endTime;
    }
}
