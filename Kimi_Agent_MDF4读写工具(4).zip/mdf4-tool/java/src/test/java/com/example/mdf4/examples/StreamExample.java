package com.example.mdf4.examples;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.MDF4Writer;
import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

/**
 * 流式读取示例
 * <p>
 * 本示例演示如何分块读取大数据量信号，避免内存溢出。
 * </p>
 */
public class StreamExample {

    public static void main(String[] args) throws Exception {
        // 初始化服务
        PoolConfig config = new PoolConfig();
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        // 创建测试文件路径
        Path outputDir = Paths.get("target/test-output");
        Files.createDirectories(outputDir);
        String filePath = outputDir.resolve("test_stream.mf4").toAbsolutePath().toString();

        List<String> signals = Arrays.asList("LargeSignal1", "LargeSignal2");

        // 步骤1: 创建大测试文件（100万个样本）
        System.out.println("=== Creating large test file ===");
        createLargeTestFile(manager, filePath, signals);
        System.out.println("Large test file created: " + filePath);

        // 步骤2: 流式读取
        System.out.println("\n=== Stream reading ===");
        try (MDF4Reader reader = manager.createReader()) {
            String fileId = reader.open(filePath);

            for (String signalName : signals) {
                System.out.println("\nStreaming read for: " + signalName);

                final int[] totalRead = {0};
                final long startTime = System.currentTimeMillis();

                reader.readSignalStream(fileId, signalName, (chunk, offset, total) -> {
                    totalRead[0] += chunk.getSampleCount();
                    System.out.printf("  Chunk: offset=%d, count=%d, total=%d%n",
                            offset, chunk.getSampleCount(), total);

                    // 处理数据块...
                    // 这里可以进行实时分析，例如计算统计值
                    double[] samples = chunk.getSamples();
                    if (samples.length > 0) {
                        double sum = 0;
                        double min = samples[0];
                        double max = samples[0];
                        for (double sample : samples) {
                            sum += sample;
                            if (sample < min) min = sample;
                            if (sample > max) max = sample;
                        }
                        double avg = sum / samples.length;
                        System.out.printf("    Stats: min=%.2f, max=%.2f, avg=%.2f%n", min, max, avg);
                    }

                    return true; // 继续读取
                });

                long duration = System.currentTimeMillis() - startTime;
                System.out.printf("Total read: %d samples in %d ms%n", totalRead[0], duration);
            }

            reader.close(fileId);
        }

        manager.shutdown();
    }

    /**
     * 创建大测试文件
     */
    private static void createLargeTestFile(MDF4ServiceManager manager, String filePath, List<String> signalNames) throws Exception {
        try (MDF4Writer writer = manager.createWriter()) {
            String fileId = writer.create(filePath, "4.10");

            int sampleCount = 1000000;  // 100万个样本
            double[] timestamps = new double[sampleCount];

            for (int i = 0; i < sampleCount; i++) {
                timestamps[i] = i * 0.001;  // 1ms间隔
            }

            // 为每个信号生成数据
            for (String signalName : signalNames) {
                double[] samples = new double[sampleCount];
                double phase = Math.random() * Math.PI * 2;

                for (int i = 0; i < sampleCount; i++) {
                    samples[i] = 1000 * Math.sin(i * 0.001 + phase) + Math.random() * 100;
                }

                writer.appendSignal(fileId, signalName, timestamps, samples,
                        SignalConfig.builder()
                                .unit("unit")
                                .description(signalName)
                                .build());
            }

            writer.save(fileId);
            writer.close(fileId);
        }
    }
}
