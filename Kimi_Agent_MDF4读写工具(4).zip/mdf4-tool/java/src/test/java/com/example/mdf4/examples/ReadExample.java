package com.example.mdf4.examples;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.MDF4Writer;
import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * MDF4读取示例
 * <p>
 * 本示例会先创建一个测试文件，然后读取它。
 * 在实际使用中，请替换为实际的MDF4文件路径。
 * </p>
 */
public class ReadExample {

    public static void main(String[] args) throws Exception {
        // 配置连接池
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(5);

        // 初始化服务
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        // 创建测试文件路径
        Path outputDir = Paths.get("target/test-output");
        Files.createDirectories(outputDir);
        String testFile = outputDir.resolve("test_read.mf4").toAbsolutePath().toString();

        System.out.println("Test file: " + testFile);

        try {
            // 步骤1: 创建一个测试文件（实际使用时可以跳过）
            System.out.println("\n=== Step 1: Create test file ===");
            createTestFile(manager, testFile);

            // 步骤2: 读取文件
            System.out.println("\n=== Step 2: Read file ===");
            try (MDF4Reader reader = manager.createReader()) {
                String fileId = reader.open(testFile);

                // 获取所有信号名称
                List<String> signals = reader.getSignalNames(fileId);
                System.out.println("Signals: " + signals);

                // 读取单个信号
                SignalData engineSpeed = reader.readSignal(fileId, "EngineSpeed");
                System.out.println("Engine Speed: " + engineSpeed);
                System.out.println("Sample count: " + engineSpeed.getSampleCount());

                // 按时间范围读取
                SignalData torque = reader.readSignal(fileId, "EngineTorque", 0.0, 60.0);
                System.out.println("Torque (0-60s): " + torque.getSampleCount() + " samples");

                // 批量读取多个信号
                List<String> batchSignals = Arrays.asList("EngineSpeed", "EngineTorque", "ThrottlePosition");
                Map<String, SignalData> batchData = reader.readSignals(fileId, batchSignals);
                for (Map.Entry<String, SignalData> entry : batchData.entrySet()) {
                    System.out.println(entry.getKey() + ": " + entry.getValue().getSampleCount() + " samples");
                }

                // 获取文件信息
                System.out.println("\nFile Info:");
                System.out.println(reader.getInfo(fileId));

                // 关闭文件
                reader.close(fileId);
            }

            // 步骤3: 流式读取（大数据量）
            System.out.println("\n=== Step 3: Stream read ===");
            try (MDF4Reader reader = manager.createReader()) {
                String fileId = reader.open(testFile);

                System.out.println("Streaming read:");
                reader.readSignalStream(fileId, "EngineSpeed", (chunk, offset, total) -> {
                    System.out.printf("Chunk: offset=%d, count=%d, total=%d%n",
                            offset, chunk.getSampleCount(), total);
                    // 处理数据块...
                    return true; // 继续读取
                });

                reader.close(fileId);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭服务
            manager.shutdown();
        }
    }

    /**
     * 创建测试文件
     */
    private static void createTestFile(MDF4ServiceManager manager, String filePath) throws Exception {
        try (MDF4Writer writer = manager.createWriter()) {
            String fileId = writer.create(filePath, "4.10");

            int sampleCount = 10000;
            double[] timestamps = new double[sampleCount];
            double[] engineSpeed = new double[sampleCount];
            double[] engineTorque = new double[sampleCount];
            double[] throttlePosition = new double[sampleCount];

            for (int i = 0; i < sampleCount; i++) {
                timestamps[i] = i * 0.01;  // 10ms间隔
                engineSpeed[i] = 1000 + 500 * Math.sin(i * 0.01);
                engineTorque[i] = 200 + 100 * Math.cos(i * 0.02);
                throttlePosition[i] = 50 + 30 * Math.sin(i * 0.005);
            }

            // 添加信号
            writer.appendSignal(fileId, "EngineSpeed", timestamps, engineSpeed,
                    SignalConfig.builder().unit("rpm").description("Engine Speed").build());
            writer.appendSignal(fileId, "EngineTorque", timestamps, engineTorque,
                    SignalConfig.builder().unit("Nm").description("Engine Torque").build());
            writer.appendSignal(fileId, "ThrottlePosition", timestamps, throttlePosition,
                    SignalConfig.builder().unit("%").description("Throttle Position").build());

            writer.save(fileId);
            writer.close(fileId);

            System.out.println("Test file created successfully!");
        }
    }
}
