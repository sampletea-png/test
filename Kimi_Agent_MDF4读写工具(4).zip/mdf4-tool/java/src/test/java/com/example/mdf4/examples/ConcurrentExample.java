package com.example.mdf4.examples;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.MDF4Writer;
import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

/**
 * 多线程并发读取示例
 * <p>
 * 本示例会先创建一个测试文件，然后使用多个线程并发读取不同信号。
 * </p>
 */
public class ConcurrentExample {

    public static void main(String[] args) throws Exception {
        // 配置连接池（根据并发需求调整）
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(10);
        config.setMaxWaitMillis(60000);

        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        // 创建测试文件路径
        Path outputDir = Paths.get("target/test-output");
        Files.createDirectories(outputDir);
        String filePath = outputDir.resolve("test_concurrent.mf4").toAbsolutePath().toString();

        List<String> signals = Arrays.asList(
                "EngineSpeed", "EngineTorque", "ThrottlePosition",
                "VehicleSpeed", "CoolantTemp", "OilPressure",
                "BatteryVoltage", "IntakeAirTemp"
        );

        // 步骤1: 创建测试文件
        System.out.println("=== Creating test file ===");
        createTestFile(manager, filePath, signals);
        System.out.println("Test file created: " + filePath);

        // 步骤2: 并发读取
        System.out.println("\n=== Concurrent reading ===");

        // 创建线程池
        ExecutorService executor = Executors.newFixedThreadPool(signals.size());
        List<Future<SignalData>> futures = new ArrayList<>();

        long startTime = System.currentTimeMillis();

        // 每个信号一个线程读取
        for (String signalName : signals) {
            Future<SignalData> future = executor.submit(() -> {
                try (MDF4Reader reader = manager.createReader()) {
                    String fileId = reader.open(filePath);
                    SignalData data = reader.readSignal(fileId, signalName);
                    reader.close(fileId);
                    return data;
                }
            });
            futures.add(future);
        }

        // 收集结果
        for (int i = 0; i < futures.size(); i++) {
            try {
                SignalData data = futures.get(i).get(30, TimeUnit.SECONDS);
                System.out.printf("Signal: %s, Samples: %d%n",
                        signals.get(i), data.getSampleCount());
            } catch (Exception e) {
                System.err.println("Error reading signal: " + signals.get(i));
                e.printStackTrace();
            }
        }

        long duration = System.currentTimeMillis() - startTime;
        System.out.println("\nTotal time: " + duration + " ms");

        executor.shutdown();
        manager.shutdown();
    }

    /**
     * 创建测试文件
     */
    private static void createTestFile(MDF4ServiceManager manager, String filePath, List<String> signalNames) throws Exception {
        try (MDF4Writer writer = manager.createWriter()) {
            String fileId = writer.create(filePath, "4.10");

            int sampleCount = 50000;  // 50000 samples
            double[] timestamps = new double[sampleCount];

            for (int i = 0; i < sampleCount; i++) {
                timestamps[i] = i * 0.001;  // 1ms间隔
            }

            // 为每个信号生成数据
            for (String signalName : signalNames) {
                double[] samples = new double[sampleCount];
                double phase = Math.random() * Math.PI * 2;
                double amplitude = 100 + Math.random() * 900;
                double offset = Math.random() * 100;

                for (int i = 0; i < sampleCount; i++) {
                    samples[i] = offset + amplitude * Math.sin(i * 0.01 + phase);
                }

                writer.appendSignal(fileId, signalName, timestamps, samples,
                        SignalConfig.builder()
                                .unit("unit")
                                .description(signalName)
                                .build());
            }

            writer.save(fileId);
            writer.close(fileId);
        }
    }
}
