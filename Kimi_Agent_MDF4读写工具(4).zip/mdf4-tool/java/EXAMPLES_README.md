# MDF4工具示例运行指南

## 示例位置

示例代码位于 `src/test/java/com/example/mdf4/examples/` 目录下：

- `ReadExample.java` - 基本读取示例
- `WriteExample.java` - 写入示例
- `ConcurrentExample.java` - 多线程并发示例
- `StreamExample.java` - 流式读取示例

## 运行前准备

### 1. 安装Python依赖

```bash
cd ../python
pip install -r requirements.txt
pip install -e .
```

### 2. 编译Java项目

```bash
cd java
mvn clean compile test-compile
```

## 运行示例

### 方式1：使用Maven Exec插件（推荐）

```bash
# 运行读取示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ReadExample" -Dexec.classpathScope=test

# 运行写入示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.WriteExample" -Dexec.classpathScope=test

# 运行并发示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ConcurrentExample" -Dexec.classpathScope=test

# 运行流式示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.StreamExample" -Dexec.classpathScope=test
```

### 方式2：使用Maven Profile

```bash
# 运行读取示例
mvn exec:java -Pread-example

# 运行写入示例
mvn exec:java -Pwrite-example

# 运行并发示例
mvn exec:java -Pconcurrent-example

# 运行流式示例
mvn exec:java -Pstream-example
```

### 方式3：打包后运行

```bash
# 打包
mvn clean package

# 运行（需要指定测试类路径）
java -cp "target/mdf4-tool-1.0.0.jar:target/test-classes" com.example.mdf4.examples.ReadExample
```

## 示例说明

### ReadExample
- 创建一个测试MDF4文件
- 读取所有信号名称
- 读取单个信号数据
- 按时间范围读取
- 批量读取多个信号
- 流式分块读取

### WriteExample
- 创建新MDF4文件
- 追加多个信号数据
- 设置压缩级别
- 保存文件

### ConcurrentExample
- 创建测试文件
- 使用多个线程并发读取不同信号
- 展示连接池的并发能力

### StreamExample
- 创建大测试文件（100万个样本）
- 流式分块读取，避免内存溢出
- 实时处理每个数据块

## 输出文件

示例运行后会生成测试文件到 `target/test-output/` 目录：
- `test_read.mf4` - ReadExample生成的文件
- `new_file.mf4` - WriteExample生成的文件
- `test_concurrent.mf4` - ConcurrentExample生成的文件
- `test_stream.mf4` - StreamExample生成的文件

## 常见问题

### 问题1：找不到mdf4_service

**原因**：Python模块未安装

**解决**：
```bash
cd ../python
pip install -e .
```

### 问题2：找不到主类

**原因**：测试类未编译

**解决**：
```bash
mvn test-compile
```

### 问题3：ClassNotFoundException

**原因**：依赖未正确加载

**解决**：使用 `-Dexec.classpathScope=test` 参数

### 问题4：文件写入失败

**原因**：输出目录不存在

**解决**：示例代码会自动创建输出目录，无需手动创建
