# DataObserver - 仿Simulink数据观察器

一个高性能的Java数据收集和存储系统，仿照Simulink Data Inspector设计，支持运行时动态添加/取消数据源，并发读写，以及多种存储格式（包括使用Python第三方库的MDF4支持）。

## 特性

- **动态数据源管理**: 运行时添加或移除观察的数据源
- **并发读写**: 基于无锁环形缓冲区的高性能数据收集
- **多种存储格式**: 
  - MDF4（原生Java实现）
  - MDF4（Python asammdf库）
  - CSV（纯Java实现）
  - 可扩展其他格式
- **大文件支持**: 支持GB级数据量
- **可扩展存储**: 支持多种存储格式扩展

## 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                      DataObserver                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ DataSource  │  │ DataSource  │  │     DataSource      │  │
│  │   (源1)     │  │   (源2)     │  │       (源N)         │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         └────────────────┴────────────────────┘             │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │    RingBuffer          │                     │
│              │  (无锁环形缓冲区)        │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │   Writer Thread        │                     │
│              │   (批量写入)            │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │    DataStorage         │                     │
│              │  (多种格式支持)          │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
└──────────────────────────┼──────────────────────────────────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
    ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
    │  MDF4       │ │  MDF4       │ │    CSV      │
    │ (Native)    │ │ (Python)    │ │  (Native)   │
    │             │ │ (asammdf)   │ │             │
    └─────────────┘ └─────────────┘ └─────────────┘
```

## 快速开始

### 1. 环境准备

**Java环境**:
```bash
# 需要 Java 11+
java -version
```

**Python环境** (如果使用Python MDF4存储):
```bash
# 安装Python 3.8+
python3 --version

# 安装依赖
pip3 install asammdf numpy
# 或者
pip3 install -r python/requirements.txt
```

### 2. 添加依赖

```xml
<dependency>
    <groupId>com.dataobserver</groupId>
    <artifactId>data-observer</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 3. 基本使用

```java
import com.dataobserver.core.*;
import com.dataobserver.storage.*;
import java.nio.file.Paths;

public class Example {
    public static void main(String[] args) throws Exception {
        // 1. 创建观察器
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        // 2. 选择存储方式
        
        // 方式1: 原生Java MDF4 (不依赖Python)
        DataStorage storage = new MDF4Storage();
        storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);
        
        // 方式2: Python asammdf MDF4 (功能更完善)
        // DataStorage storage = new PythonMDF4Storage();
        // storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);
        
        // 方式3: CSV格式
        // DataStorage storage = new CsvStorage();
        // storage.open(Paths.get("data.csv"), DataStorage.OpenMode.CREATE);
        
        // 3. 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource(
            "source1", "Test Source", 100.0
        );
        source.addSineWaveChannel("sine", 10.0, 1.0, 0.0);
        source.addNoiseChannel("noise", 2.0, 0.0);
        
        // 4. 添加数据源
        observer.addDataSource(source);
        
        // 5. 开始记录
        observer.startRecording();
        
        // 6. 记录一段时间
        Thread.sleep(5000);
        
        // 7. 停止并关闭
        observer.stopRecording();
        storage.close();
        observer.close();
    }
}
```

## 存储格式对比

| 格式 | 实现方式 | 优点 | 缺点 |
|------|----------|------|------|
| MDF4 (Native) | 纯Java | 无外部依赖，轻量级 | 功能相对简单 |
| MDF4 (Python) | asammdf库 | 功能完整，兼容性好 | 需要Python环境 |
| CSV | 纯Java | 通用格式，易查看 | 文件大，性能低 |

## 核心组件

### DataObserver

主类，负责管理数据源、缓冲区和存储引擎。

```java
// 配置参数
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(100000)      // 环形缓冲区大小
    .setBatchSize(100)          // 批量写入大小
    .setWorkerThreads(2)        // 工作线程数
    .setDebugMode(true);        // 调试模式

DataObserver observer = new DataObserver(config);
```

### 存储引擎

#### 1. 原生Java MDF4

```java
MDF4Storage storage = new MDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);
```

#### 2. Python asammdf MDF4

```java
PythonMDF4Storage storage = new PythonMDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);

// 获取文件信息
System.out.println(storage.getFileInfo());
```

#### 3. CSV

```java
CsvStorage storage = new CsvStorage();
storage.setDelimiter(',');           // 设置分隔符
storage.setIncludeTimestamp(true);   // 包含时间戳
storage.open(Paths.get("data.csv"), DataStorage.OpenMode.CREATE);
```

### 数据源

```java
// 创建模拟数据源
SimulatedDataSource source = new SimulatedDataSource(
    "sensor", "Temperature Sensor", 100.0  // ID, 名称, 采样率(Hz)
);

// 添加通道
source.addSineWaveChannel("sine", 10.0, 1.0, 0.0);  // 正弦波
source.addNoiseChannel("noise", 2.0, 0.0);          // 噪声
source.addRampChannel("ramp", 5.0, 0.0);            // 斜坡
source.addStepChannel("step", 0.0, 100.0, 2.0);     // 阶跃

// 添加数据源
observer.addDataSource(source);
```

### 动态数据源管理

```java
// 运行时添加数据源
SimulatedDataSource newSource = new SimulatedDataSource("new", "New Source", 50.0);
newSource.addRampChannel("value", 10.0, 0.0);
observer.addDataSource(newSource);

// 运行时移除数据源
observer.removeDataSource("source1");
```

## 性能优化

### 1. 缓冲区调优

```java
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(1000000)    // 大缓冲区减少阻塞
    .setBatchSize(1000)        // 大批量提高吞吐量
    .setWorkerThreads(4);      // 多线程处理
```

### 2. 采样率控制

```java
// 限制数据源采样率
observer.setSampleRate("source1", 50.0);  // 50Hz
```

### 3. 批量写入

```java
// 批量写入多条记录
List<DataRecord> records = new ArrayList<>();
for (int i = 0; i < 1000; i++) {
    DataRecord record = new DataRecord(System.nanoTime());
    record.addValue("value", i, DataType.INT32);
    records.add(record);
}
storage.writeRecords(records);  // 批量写入
```

## Python asammdf 详细使用

### 环境检查

```java
// 检查Python环境
boolean hasPython = PythonProcessManager.checkPythonEnvironment();

// 检查asammdf
boolean hasAsammdf = PythonProcessManager.checkAsammdf();
```

### 文件信息

```java
PythonMDF4Storage storage = new PythonMDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.READ_ONLY);

// 获取文件信息
JsonNode info = storage.getFileInfo();
System.out.println("Version: " + info.get("version").asText());
System.out.println("Channels: " + info.get("channels").asInt());
System.out.println("Groups: " + info.get("groups").asInt());
```

## 扩展存储格式

实现自定义存储格式：

```java
public class ParquetStorage implements DataStorage {
    @Override
    public void open(Path path, OpenMode mode) { ... }
    
    @Override
    public void writeRecord(DataRecord record) { ... }
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.PARQUET;
    }
    // ...
}

// 注册到工厂
StorageFactory.registerProvider(
    StorageFormat.PARQUET, 
    ParquetStorage::new
);
```

## 测试

```bash
# 编译
mvn compile

# 运行测试
mvn test

# 打包
mvn package

# 运行示例
java -jar target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar

# 运行Python存储示例
java -cp target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar \
     com.dataobserver.example.PythonStorageExample
```

## 项目结构

```
data-observer/
├── pom.xml                          # Maven配置
├── python/
│   ├── requirements.txt             # Python依赖
│   └── mdf4_storage.py              # Python MDF4服务
├── src/
│   ├── main/java/com/dataobserver/
│   │   ├── core/                    # 核心接口
│   │   ├── storage/                 # 存储接口和实现
│   │   │   ├── DataStorage.java     # 存储接口
│   │   │   ├── MDF4Storage.java     # 原生MDF4
│   │   │   ├── PythonMDF4Storage.java   # Python MDF4
│   │   │   └── CsvStorage.java      # CSV存储
│   │   ├── mdf4/                    # MDF4原生实现
│   │   ├── python/                  # Python通信
│   │   │   └── PythonProcessManager.java
│   │   ├── buffer/                  # 环形缓冲区
│   │   └── example/                 # 示例代码
│   └── test/                        # 测试代码
├── README.md                        # 本文件
├── QUICKSTART.md                    # 快速开始
└── ARCHITECTURE.md                  # 架构设计
```

## 系统要求

- Java 11+
- Maven 3.6+ (可选)
- Python 3.8+ (使用Python存储时需要)
- asammdf 7.3+ (使用Python MDF4时需要)

## 许可证

MIT License

## 参考

- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/)
- [asammdf Documentation](https://asammdf.readthedocs.io/)
- [Simulink Data Inspector](https://www.mathworks.com/help/simulink/ug/sdi.html)
