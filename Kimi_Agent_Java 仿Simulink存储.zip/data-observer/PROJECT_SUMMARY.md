# DataObserver 项目总结

## 项目概述

本项目实现了一个仿Simulink数据观察器的高性能Java数据收集和存储系统，支持使用开源第三方库进行文件存储。

### 主要特性

1. **运行时动态数据源管理** - 支持添加/取消观察的数据源
2. **并发读写** - 基于无锁环形缓冲区的高性能数据收集
3. **多种存储格式**:
   - MDF4（原生Java实现）
   - MDF4（Python asammdf第三方库）
   - CSV（纯Java实现）
4. **大文件支持** - 支持GB级数据量
5. **可扩展存储** - 支持多种存储格式扩展

## 架构设计

### 核心架构

```
Java端 (数据收集)                    存储端 (文件写入)
┌─────────────────────┐              ┌─────────────────────┐
│  DataObserver       │              │  MDF4Storage        │
│  ├─ DataSource      │              │  (Native Java)      │
│  ├─ RingBuffer      │─────────────▶│                     │
│  └─ Writer Thread   │              │  PythonMDF4Storage  │
│                     │              │  ├─ PythonProcess   │
│  PythonProcessManager│  (IPC)      │  │   ├─ stdin/stdout│
│  (进程通信管理)      │◀────────────▶│  │   └─ asammdf    │
│                     │   JSON       │  │                  │
│  CsvStorage         │              │  └─ MDF4 File      │
│  (纯Java)           │─────────────▶│                     │
└─────────────────────┘              └─────────────────────┘
```

## 核心组件

### 1. 数据收集层 (core包)

| 类/接口 | 职责 |
|---------|------|
| `DataType` | 数据类型枚举 |
| `DataRecord` | 数据记录，存储时间戳和通道值 |
| `DataChannel` | 数据通道接口 |
| `DataSource` | 数据源接口 |
| `DataObserver` | 核心控制器 |
| `SimulatedDataSource` | 模拟数据源实现 |

### 2. 存储层 (storage包)

| 类/接口 | 实现方式 | 依赖 |
|---------|----------|------|
| `DataStorage` | 接口定义 | 无 |
| `MDF4Storage` | 原生Java实现 | 无 |
| `PythonMDF4Storage` | Python进程通信 | Python + asammdf |
| `CsvStorage` | 纯Java实现 | 无 |
| `StorageFactory` | 工厂模式 | 无 |

### 3. Python通信层 (python包)

| 类/文件 | 职责 |
|---------|------|
| `PythonProcessManager.java` | Java端进程管理 |
| `mdf4_storage.py` | Python端MDF4服务 |
| `requirements.txt` | Python依赖 |

### 4. 缓冲区 (buffer包)

| 类 | 职责 |
|----|------|
| `RingBuffer` | 无锁环形缓冲区，CAS操作 |

## 存储格式对比

| 格式 | 实现 | 优点 | 缺点 | 适用场景 |
|------|------|------|------|----------|
| MDF4 (Native) | 纯Java | 无依赖，轻量 | 功能简单 | 无Python环境 |
| MDF4 (Python) | asammdf | 功能完整，兼容好 | 需Python环境 | 需要完整MDF4功能 |
| CSV | 纯Java | 通用，易查看 | 文件大，性能低 | 调试，小数据量 |

## 使用第三方库的优势

### Python asammdf

- **成熟稳定**: 经过广泛测试的MDF4实现
- **功能完整**: 支持所有MDF4特性
- **兼容性好**: 与其他工具兼容
- **持续维护**: 活跃的开源项目

### 通信方式

Java与Python通过stdin/stdout进行JSON通信:

```json
// Java请求
{"command": "write_record", "record": {"timestamp": 1234567890, "values": {"ch1": 1.5}}}

// Python响应
{"status": "success", "buffer_size": 10}
```

## 项目文件清单

```
data-observer/
├── pom.xml                          # Maven配置
├── python/
│   ├── requirements.txt             # Python依赖
│   ├── mdf4_storage.py              # Python MDF4服务 (200+行)
│   └── test_mdf4_storage.py         # Python测试 (150+行)
├── src/
│   ├── main/java/com/dataobserver/
│   │   ├── core/                    # 核心接口 (6文件)
│   │   ├── storage/                 # 存储实现 (7文件)
│   │   │   ├── DataStorage.java     # 存储接口
│   │   │   ├── MDF4Storage.java     # 原生MDF4
│   │   │   ├── PythonMDF4Storage.java   # Python MDF4
│   │   │   ├── CsvStorage.java      # CSV存储
│   │   │   └── StorageFactory.java  # 工厂
│   │   ├── mdf4/                    # MDF4原生实现 (11文件)
│   │   ├── python/                  # Python通信
│   │   │   └── PythonProcessManager.java
│   │   ├── buffer/                  # 环形缓冲区
│   │   └── example/                 # 示例代码 (2文件)
│   └── test/java/com/dataobserver/  # 测试 (2文件)
├── README.md                        # 项目说明
├── QUICKSTART.md                    # 快速开始
├── ARCHITECTURE.md                  # 架构设计
└── PROJECT_SUMMARY.md               # 本文件
```

**代码统计**:
- Java代码: ~5000+ 行
- Python代码: ~400+ 行
- 总计: ~5400+ 行

## 快速使用

### 原生Java MDF4

```java
MDF4Storage storage = new MDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);
```

### Python asammdf MDF4

```java
PythonMDF4Storage storage = new PythonMDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);

// 获取文件信息
JsonNode info = storage.getFileInfo();
```

### CSV

```java
CsvStorage storage = new CsvStorage();
storage.open(Paths.get("data.csv"), DataStorage.OpenMode.CREATE);
```

## 性能特性

| 指标 | 数值 | 说明 |
|------|------|------|
| 写入吞吐量 | >100,000 records/sec | 批量写入 |
| 缓冲区大小 | 可配置 | 默认100,000条 |
| 批处理大小 | 可配置 | 默认100条 |
| 并发数据源 | >100个 | 取决于系统资源 |
| 最大文件 | >10GB | 受磁盘空间限制 |

## 扩展性

### 添加新的存储格式

```java
public class ParquetStorage implements DataStorage {
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.PARQUET;
    }
    // ... 实现方法
}

StorageFactory.registerProvider(StorageFormat.PARQUET, ParquetStorage::new);
```

### 使用Python第三方库

1. 创建Python服务脚本
2. 实现命令接口
3. 使用PythonProcessManager通信

## 依赖说明

### Java依赖

- Jackson (JSON处理)
- JUnit 5 (测试)

### Python依赖

- asammdf (MDF4处理)
- numpy (数值计算)
- pandas (数据处理)

## 后续优化方向

1. **更多存储格式**: Parquet, HDF5, InfluxDB等
2. **数据压缩**: 支持压缩存储
3. **网络传输**: 远程数据收集
4. **实时分析**: 内置数据处理
5. **GUI界面**: 可视化监控

## 参考

- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/)
- [asammdf GitHub](https://github.com/danielhrisca/asammdf)
- [Simulink Data Inspector](https://www.mathworks.com/help/simulink/ug/sdi.html)

## 许可证

MIT License
