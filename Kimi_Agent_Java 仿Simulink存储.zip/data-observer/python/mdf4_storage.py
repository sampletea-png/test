#!/usr/bin/env python3
"""
MDF4 Storage Service
使用asammdf库处理MDF4文件格式
通过stdin/stdout与Java进程通信
"""

import sys
import json
import struct
import os
import signal
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import threading
import queue

import numpy as np
from asammdf import MDF, Signal


@dataclass
class ChannelInfo:
    """通道信息"""
    name: str
    data_type: str
    unit: str = ""
    description: str = ""
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    sample_rate: float = 0.0


@dataclass
class DataRecord:
    """数据记录"""
    timestamp: int  # 纳秒级时间戳
    values: Dict[str, Any]


class MDF4StorageService:
    """MDF4存储服务"""
    
    def __init__(self):
        self.mdf: Optional[MDF] = None
        self.file_path: Optional[str] = None
        self.channels: Dict[str, ChannelInfo] = {}
        self.buffer: List[DataRecord] = []
        self.buffer_lock = threading.Lock()
        self.running = True
        self.batch_size = 100
        self.flush_interval = 1.0  # 秒
        self.last_flush = datetime.now()
        
        # 数据类型映射
        self.type_mapping = {
            'UINT8': np.uint8,
            'UINT16': np.uint16,
            'UINT32': np.uint32,
            'UINT64': np.uint64,
            'INT8': np.int8,
            'INT16': np.int16,
            'INT32': np.int32,
            'INT64': np.int64,
            'FLOAT': np.float32,
            'DOUBLE': np.float64,
            'BOOLEAN': np.bool_,
        }
    
    def open_file(self, path: str, mode: str = 'create') -> Dict[str, Any]:
        """打开MDF4文件"""
        try:
            self.file_path = path
            
            if mode == 'append' and os.path.exists(path):
                self.mdf = MDF(path)
            else:
                self.mdf = MDF(version='4.11')
            
            return {
                'status': 'success',
                'path': path,
                'mode': mode,
                'version': self.mdf.version_str if self.mdf else '4.11'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def close_file(self) -> Dict[str, Any]:
        """关闭MDF4文件"""
        try:
            if self.mdf:
                self._flush_buffer()
                self.mdf.save(self.file_path, overwrite=True)
                self.mdf.close()
                self.mdf = None
            
            return {
                'status': 'success',
                'file_path': self.file_path
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def register_channel(self, channel_info: Dict[str, Any]) -> Dict[str, Any]:
        """注册通道"""
        try:
            channel = ChannelInfo(
                name=channel_info['name'],
                data_type=channel_info.get('data_type', 'DOUBLE'),
                unit=channel_info.get('unit', ''),
                description=channel_info.get('description', ''),
                min_value=channel_info.get('min_value'),
                max_value=channel_info.get('max_value'),
                sample_rate=channel_info.get('sample_rate', 0.0)
            )
            
            self.channels[channel.name] = channel
            
            return {
                'status': 'success',
                'channel': channel.name,
                'data_type': channel.data_type
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def write_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """写入单条记录"""
        try:
            data_record = DataRecord(
                timestamp=record['timestamp'],
                values=record['values']
            )
            
            with self.buffer_lock:
                self.buffer.append(data_record)
                
                # 检查是否需要刷新
                if len(self.buffer) >= self.batch_size:
                    self._flush_buffer()
            
            return {
                'status': 'success',
                'buffer_size': len(self.buffer)
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def write_records(self, records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """批量写入记录"""
        try:
            for record in records:
                data_record = DataRecord(
                    timestamp=record['timestamp'],
                    values=record['values']
                )
                self.buffer.append(data_record)
            
            with self.buffer_lock:
                if len(self.buffer) >= self.batch_size:
                    self._flush_buffer()
            
            return {
                'status': 'success',
                'count': len(records),
                'buffer_size': len(self.buffer)
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _flush_buffer(self):
        """刷新缓冲区到MDF文件"""
        if not self.buffer or not self.mdf:
            return
        
        try:
            # 按通道组织数据
            channel_data: Dict[str, List] = {name: [] for name in self.channels.keys()}
            timestamps = []
            
            for record in self.buffer:
                # 转换时间戳为秒
                ts_seconds = record.timestamp / 1e9
                timestamps.append(ts_seconds)
                
                for channel_name in self.channels.keys():
                    value = record.values.get(channel_name, 0)
                    channel_data[channel_name].append(value)
            
            # 为每个通道创建Signal并追加到MDF
            for channel_name, channel_info in self.channels.items():
                if channel_name in channel_data and channel_data[channel_name]:
                    data = np.array(channel_data[channel_name], 
                                   dtype=self.type_mapping.get(channel_info.data_type, np.float64))
                    
                    signal = Signal(
                        samples=data,
                        timestamps=np.array(timestamps),
                        name=channel_name,
                        unit=channel_info.unit,
                        comment=channel_info.description
                    )
                    
                    self.mdf.append(signal)
            
            # 清空缓冲区
            self.buffer.clear()
            self.last_flush = datetime.now()
            
        except Exception as e:
            print(f"Error flushing buffer: {e}", file=sys.stderr)
    
    def flush(self) -> Dict[str, Any]:
        """强制刷新"""
        try:
            with self.buffer_lock:
                self._flush_buffer()
            
            return {
                'status': 'success',
                'buffer_size': len(self.buffer)
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def get_info(self) -> Dict[str, Any]:
        """获取文件信息"""
        try:
            if not self.mdf:
                return {
                    'status': 'error',
                    'message': 'File not open'
                }
            
            return {
                'status': 'success',
                'version': self.mdf.version_str,
                'groups': len(self.mdf.groups),
                'channels': len(self.mdf.channels_db),
                'file_path': self.file_path,
                'registered_channels': list(self.channels.keys())
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def handle_command(self, command: Dict[str, Any]) -> Dict[str, Any]:
        """处理命令"""
        cmd = command.get('command')
        
        if cmd == 'open':
            return self.open_file(
                command.get('path'),
                command.get('mode', 'create')
            )
        
        elif cmd == 'close':
            return self.close_file()
        
        elif cmd == 'register_channel':
            return self.register_channel(command.get('channel', {}))
        
        elif cmd == 'write_record':
            return self.write_record(command.get('record', {}))
        
        elif cmd == 'write_records':
            return self.write_records(command.get('records', []))
        
        elif cmd == 'flush':
            return self.flush()
        
        elif cmd == 'info':
            return self.get_info()
        
        elif cmd == 'exit':
            self.close_file()
            self.running = False
            return {'status': 'success', 'message': 'Exiting'}
        
        else:
            return {
                'status': 'error',
                'message': f'Unknown command: {cmd}'
            }


def main():
    """主函数 - 通过stdin/stdout与Java通信"""
    service = MDF4StorageService()
    
    # 设置信号处理
    def signal_handler(sig, frame):
        service.close_file()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print(json.dumps({
        'status': 'ready',
        'message': 'MDF4 Storage Service started'
    }), flush=True)
    
    while service.running:
        try:
            # 读取命令
            line = sys.stdin.readline()
            if not line:
                break
            
            # 解析命令
            command = json.loads(line.strip())
            
            # 处理命令
            result = service.handle_command(command)
            
            # 输出结果
            print(json.dumps(result), flush=True)
            
        except json.JSONDecodeError as e:
            print(json.dumps({
                'status': 'error',
                'message': f'Invalid JSON: {str(e)}'
            }), flush=True)
        
        except Exception as e:
            print(json.dumps({
                'status': 'error',
                'message': str(e)
            }), flush=True)


if __name__ == '__main__':
    main()
