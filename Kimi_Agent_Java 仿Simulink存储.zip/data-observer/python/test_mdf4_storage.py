#!/usr/bin/env python3
"""
MDF4存储服务测试
"""

import json
import sys
import tempfile
import os

from mdf4_storage import MDF4StorageService


def test_basic_operations():
    """测试基本操作"""
    print("Testing basic operations...")
    
    service = MDF4StorageService()
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        # 测试打开文件
        result = service.open_file(temp_path, 'create')
        assert result['status'] == 'success', f"Open failed: {result}"
        print(f"  ✓ Open file: {result['version']}")
        
        # 测试注册通道
        channel = {
            'name': 'test_channel',
            'data_type': 'DOUBLE',
            'unit': 'V',
            'description': 'Test channel',
            'sample_rate': 100.0
        }
        result = service.register_channel(channel)
        assert result['status'] == 'success', f"Register channel failed: {result}"
        print(f"  ✓ Register channel: {result['channel']}")
        
        # 测试写入记录
        for i in range(10):
            record = {
                'timestamp': i * 1000000000,  # 纳秒
                'values': {'test_channel': i * 1.5}
            }
            result = service.write_record(record)
            assert result['status'] == 'success', f"Write record failed: {result}"
        
        print(f"  ✓ Write 10 records")
        
        # 测试刷新
        result = service.flush()
        assert result['status'] == 'success', f"Flush failed: {result}"
        print(f"  ✓ Flush buffer")
        
        # 测试获取信息
        result = service.get_info()
        assert result['status'] == 'success', f"Get info failed: {result}"
        print(f"  ✓ File info: {result}")
        
        # 测试关闭
        result = service.close_file()
        assert result['status'] == 'success', f"Close failed: {result}"
        print(f"  ✓ Close file")
        
        # 验证文件存在
        assert os.path.exists(temp_path), "File not created"
        file_size = os.path.getsize(temp_path)
        assert file_size > 0, "File is empty"
        print(f"  ✓ File size: {file_size} bytes")
        
    finally:
        # 清理
        if os.path.exists(temp_path):
            os.remove(temp_path)
    
    print("Basic operations test passed!\n")


def test_batch_write():
    """测试批量写入"""
    print("Testing batch write...")
    
    service = MDF4StorageService()
    
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        service.open_file(temp_path, 'create')
        
        # 注册通道
        service.register_channel({
            'name': 'ch1',
            'data_type': 'DOUBLE',
            'unit': 'V'
        })
        service.register_channel({
            'name': 'ch2',
            'data_type': 'INT32',
            'unit': 'count'
        })
        
        # 批量写入
        records = []
        for i in range(100):
            records.append({
                'timestamp': i * 100000000,
                'values': {'ch1': i * 0.1, 'ch2': i}
            })
        
        result = service.write_records(records)
        assert result['status'] == 'success'
        assert result['count'] == 100
        print(f"  ✓ Batch write 100 records")
        
        service.close_file()
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
    
    print("Batch write test passed!\n")


def test_multiple_channels():
    """测试多通道"""
    print("Testing multiple channels...")
    
    service = MDF4StorageService()
    
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        service.open_file(temp_path, 'create')
        
        # 注册多个通道
        channels = [
            {'name': 'sine', 'data_type': 'DOUBLE', 'unit': 'V'},
            {'name': 'cosine', 'data_type': 'DOUBLE', 'unit': 'V'},
            {'name': 'counter', 'data_type': 'INT32', 'unit': 'count'},
            {'name': 'flag', 'data_type': 'BOOLEAN', 'unit': ''}
        ]
        
        for ch in channels:
            service.register_channel(ch)
        
        print(f"  ✓ Registered {len(channels)} channels")
        
        # 写入数据
        import math
        for i in range(50):
            record = {
                'timestamp': i * 100000000,
                'values': {
                    'sine': math.sin(i * 0.1),
                    'cosine': math.cos(i * 0.1),
                    'counter': i,
                    'flag': i % 2 == 0
                }
            }
            service.write_record(record)
        
        print(f"  ✓ Write 50 records with 4 channels")
        
        service.flush()
        service.close_file()
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
    
    print("Multiple channels test passed!\n")


def test_command_interface():
    """测试命令接口"""
    print("Testing command interface...")
    
    service = MDF4StorageService()
    
    # 测试未知命令
    result = service.handle_command({'command': 'unknown'})
    assert result['status'] == 'error'
    print(f"  ✓ Unknown command handled")
    
    # 测试exit命令
    result = service.handle_command({'command': 'exit'})
    assert result['status'] == 'success'
    assert not service.running
    print(f"  ✓ Exit command handled")
    
    print("Command interface test passed!\n")


def main():
    """运行所有测试"""
    print("=" * 50)
    print("MDF4 Storage Service Tests")
    print("=" * 50 + "\n")
    
    try:
        test_basic_operations()
        test_batch_write()
        test_multiple_channels()
        test_command_interface()
        
        print("=" * 50)
        print("All tests passed!")
        print("=" * 50)
        
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
