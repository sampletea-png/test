# DataObserver 快速开始指南

## 环境准备

### Java环境

```bash
# 检查Java版本 (需要11+)
java -version
```

### Python环境 (可选，用于Python MDF4存储)

```bash
# 检查Python版本 (需要3.8+)
python3 --version

# 安装Python依赖
pip3 install asammdf numpy

# 或者使用requirements.txt
pip3 install -r python/requirements.txt
```

## 快速开始

### 1. 基本数据收集 (原生Java MDF4)

```java
import com.dataobserver.core.*;
import com.dataobserver.storage.*;
import java.nio.file.Paths;

public class QuickStart {
    public static void main(String[] args) throws Exception {
        // 创建观察器
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        // 创建原生Java MDF4存储
        DataStorage storage = new MDF4Storage();
        storage.open(Paths.get("output.mf4"), DataStorage.OpenMode.CREATE);
        
        // 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource(
            "sensor", "Temperature Sensor", 100.0
        );
        source.addSineWaveChannel("temperature", 50.0, 1.0, 25.0);
        
        // 添加数据源
        observer.addDataSource(source);
        
        // 开始记录
        observer.startRecording();
        Thread.sleep(5000);
        observer.stopRecording();
        
        storage.close();
        observer.close();
        
        System.out.println("Data saved to output.mf4");
    }
}
```

### 2. 使用Python asammdf存储

```java
import com.dataobserver.core.*;
import com.dataobserver.storage.*;
import java.nio.file.Paths;

public class PythonExample {
    public static void main(String[] args) throws Exception {
        // 检查Python环境
        if (!PythonProcessManager.checkPythonEnvironment()) {
            System.err.println("Python not found!");
            return;
        }
        
        // 创建Python MDF4存储
        PythonMDF4Storage storage = new PythonMDF4Storage();
        storage.open(Paths.get("python_output.mf4"), DataStorage.OpenMode.CREATE);
        
        // 注册通道
        storage.registerChannel(new TestChannel("sine", DataType.DOUBLE, "V"));
        storage.registerChannel(new TestChannel("cosine", DataType.DOUBLE, "V"));
        
        // 写入数据
        for (int i = 0; i < 1000; i++) {
            DataRecord record = new DataRecord(System.nanoTime());
            record.addValue("sine", Math.sin(i * 0.01), DataType.DOUBLE);
            record.addValue("cosine", Math.cos(i * 0.01), DataType.DOUBLE);
            storage.writeRecord(record);
        }
        
        // 获取文件信息
        System.out.println(storage.getFileInfo());
        
        storage.close();
    }
}
```

### 3. CSV存储

```java
CsvStorage storage = new CsvStorage();
storage.setDelimiter(',');
storage.setIncludeTimestamp(true);
storage.open(Paths.get("data.csv"), DataStorage.OpenMode.CREATE);

// 注册通道
storage.registerChannel(channel);

// 写入数据
for (int i = 0; i < 100; i++) {
    DataRecord record = new DataRecord(System.nanoTime());
    record.addValue("value", i, DataType.INT32);
    storage.writeRecord(record);
}

storage.flush();
storage.close();
```

## 动态数据源管理

```java
// 运行时添加数据源
SimulatedDataSource newSource = new SimulatedDataSource("new", "New Source", 50.0);
newSource.addRampChannel("value", 10.0, 0.0);
observer.addDataSource(newSource);

// 运行时移除数据源
observer.removeDataSource("sensor");
```

## 配置参数

```java
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(100000)      // 环形缓冲区大小
    .setBatchSize(100)          // 批量写入大小
    .setWorkerThreads(2)        // 工作线程数
    .setProject("MyProject")    // 项目名称
    .setSubject("Test")         // 测试主题
    .setDebugMode(true);        // 调试模式

DataObserver observer = new DataObserver(config);
```

## 监控统计

```java
// 获取统计信息
DataObserver.Statistics stats = observer.getStatistics();
System.out.println("Records: " + stats.getTotalRecords());
System.out.println("Buffer: " + stats.getBufferSize() + "/" + stats.getBufferCapacity());
System.out.println("File size: " + stats.getFileSize() + " bytes");
```

## 性能调优

### 1. 缓冲区大小

```java
// 大数据量场景，增大缓冲区
config.setBufferSize(1000000);  // 100万条
config.setBatchSize(1000);       // 每批1000条
```

### 2. 采样率控制

```java
// 限制数据源采样率，降低负载
observer.setSampleRate("source1", 50.0);  // 50Hz
```

### 3. 批量写入

```java
// 批量写入比单条写入效率更高
List<DataRecord> batch = new ArrayList<>();
for (int i = 0; i < 1000; i++) {
    batch.add(createRecord(i));
}
storage.writeRecords(batch);
```

## 存储格式选择

| 场景 | 推荐格式 | 说明 |
|------|----------|------|
| 无Python环境 | MDF4 (Native) | 纯Java实现，无依赖 |
| 需要完整MDF4功能 | MDF4 (Python) | asammdf库，兼容性好 |
| 需要查看原始数据 | CSV | 文本格式，易读 |
| 大数据量 | MDF4 | 二进制格式，空间效率高 |

## 调试技巧

```java
// 启用调试模式
config.setDebugMode(true);

// 添加监听器
observer.addListener(new DataObserver.ObserverListener() {
    @Override
    public void onDataDropped(DataSource source, DataRecord record) {
        System.err.println("Data dropped from: " + source.getName());
    }
    
    @Override
    public void onError(String message, Throwable error) {
        System.err.println("Error: " + message);
        error.printStackTrace();
    }
});
```

## 常见问题

### Q: Python MDF4存储无法启动？

A: 检查以下几点：
1. Python 3.8+ 是否安装: `python3 --version`
2. asammdf是否安装: `pip3 list | grep asammdf`
3. 安装依赖: `pip3 install asammdf numpy`

### Q: 如何选择存储格式？

A: 
- 如果没有Python环境，使用 `MDF4Storage` (原生Java)
- 如果需要完整的MDF4功能，使用 `PythonMDF4Storage`
- 如果需要查看原始数据，使用 `CsvStorage`

### Q: 支持多大的数据量？

A: 理论上只受磁盘空间限制。对于GB级数据，建议使用MDF4格式并启用批量写入。

### Q: 如何保证数据不丢失？

A: 
1. 使用足够大的缓冲区
2. 定期调用 `flush()`
3. 启用批量写入
4. 监控缓冲区使用率

## Python服务测试

```bash
# 测试Python MDF4服务
cd python
python3 test_mdf4_storage.py
```

## 构建运行

```bash
# 编译
cd data-observer
mvn compile

# 运行测试
mvn test

# 打包
mvn package

# 运行示例
java -jar target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar
```

## 参考文档

- [README.md](README.md) - 项目说明
- [ARCHITECTURE.md](ARCHITECTURE.md) - 架构设计
- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/) - MDF标准
- [asammdf Documentation](https://asammdf.readthedocs.io/) - Python库文档
