# DataObserver 架构设计文档

## 1. 系统概述

DataObserver是一个仿照Simulink Data Inspector设计的高性能数据收集和存储系统，主要特点：

- **运行时动态管理**: 支持运行时添加/移除数据源
- **并发高性能**: 无锁环形缓冲区 + 批量写入
- **大文件支持**: 内存映射 + 分块处理，支持GB级数据
- **标准格式**: 原生支持ASAM MDF4格式
- **可扩展**: 插件化存储格式支持

## 2. 核心架构

### 2.1 整体架构图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           Application Layer                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │
│  │   Console    │  │     GUI      │  │    API       │  │   Script    │ │
│  │    Client    │  │    Client    │  │   Client     │  │   Client    │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬──────┘ │
└─────────┼─────────────────┼─────────────────┼─────────────────┼────────┘
          │                 │                 │                 │
          └─────────────────┴────────┬────────┴─────────────────┘
                                     │
┌────────────────────────────────────┼────────────────────────────────────┐
│                         DataObserver Core                               │
│  ┌─────────────────────────────────┼─────────────────────────────────┐  │
│  │                         Data Source Manager                        │  │
│  │  ┌─────────┐ ┌─────────┐ ┌─────┴─────┐ ┌─────────┐ ┌─────────┐   │  │
│  │  │ Source  │ │ Source  │ │  Source   │ │ Source  │ │ Source  │   │  │
│  │  │   #1    │ │   #2    │ │    #3     │ │   #4    │ │   #N    │   │  │
│  │  └───┬─────┘ └────┬────┘ └─────┬─────┘ └────┬────┘ └────┬────┘   │  │
│  └──────┼────────────┼────────────┼────────────┼───────────┼────────┘  │
│         │            │            │            │           │            │
│         └────────────┴────────────┼────────────┴───────────┘            │
│                                   │                                     │
│  ┌────────────────────────────────┼─────────────────────────────────┐  │
│  │                    Ring Buffer (Lock-free)                         │  │
│  │                    ┌─────────────┴─────────────┐                   │  │
│  │                    │     Capacity: 100000+     │                   │  │
│  │                    │     Batch Size: 100+      │                   │  │
│  │                    └─────────────┬─────────────┘                   │  │
│  └──────────────────────────────────┼─────────────────────────────────┘  │
│                                     │                                     │
│  ┌──────────────────────────────────┼─────────────────────────────────┐  │
│  │                      Writer Thread Pool                            │  │
│  │                      ┌─────────────┴─────────────┐                   │  │
│  │                      │   Concurrent Write Queue   │                   │  │
│  │                      └─────────────┬─────────────┘                   │  │
│  └────────────────────────────────────┼─────────────────────────────────┘  │
└───────────────────────────────────────┼───────────────────────────────────┘
                                        │
┌───────────────────────────────────────┼───────────────────────────────────┐
│                         Storage Layer                                  │
│  ┌────────────────────────────────────┼───────────────────────────────┐ │
│  │                         Storage Interface                          │ │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌───────────┐ │ │
│  │  │   MDF4      │  │    CSV      │  │    HDF5     │  │  Custom   │ │ │
│  │  │  (Native)   │  │  (Optional) │  │  (Optional) │  │ (Extensible│ │ │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └───────────┘ │ │
│  └────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 数据流图

```
Data Source
     │
     │ generate DataRecord
     ▼
┌─────────────┐
│  Callback   │
└──────┬──────┘
       │
       │ offer to
       ▼
┌─────────────┐     ┌─────────────┐
│ RingBuffer  │────▶│  Consumer   │ (poll batch)
│ (Lock-free) │     │   Thread    │
└─────────────┘     └──────┬──────┘
                           │
                           │ write batch
                           ▼
                    ┌─────────────┐
                    │   Storage   │
                    │   Engine    │
                    └──────┬──────┘
                           │
                           │ persist
                           ▼
                    ┌─────────────┐
                    │  MDF4 File  │
                    └─────────────┘
```

## 3. 核心组件详解

### 3.1 DataObserver (核心控制器)

**职责**:
- 生命周期管理（初始化、启动、停止、关闭）
- 数据源管理（添加、移除、查询）
- 存储引擎管理
- 工作线程调度

**关键设计**:
```java
public class DataObserver {
    // 并发控制
    private final ReentrantReadWriteLock sourcesLock;
    
    // 无锁缓冲区
    private RingBuffer<DataRecord> ringBuffer;
    
    // 工作线程池
    private ExecutorService executorService;
    
    // 数据源集合
    private final Map<String, DataSource> dataSources;
}
```

### 3.2 RingBuffer (无锁环形缓冲区)

**设计原理**: 基于Disruptor的环形缓冲区设计

**特点**:
- 无锁CAS操作，避免线程阻塞
- 批量读写，提高吞吐量
- 多种等待策略（自旋、让步、暂停）

**实现**:
```java
public class RingBuffer<T> {
    private final Object[] buffer;
    private final AtomicLong writeSequence = new AtomicLong(-1);
    private final AtomicLong readSequence = new AtomicLong(-1);
    
    public boolean offer(T element) {
        // CAS操作，无锁写入
        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + 1;
        
        if (writeSequence.compareAndSet(currentWrite, nextWrite)) {
            buffer[(int)(nextWrite & mask)] = element;
            return true;
        }
        return false;
    }
}
```

**性能指标**:
- 容量: 可配置（默认100,000条记录）
- 批处理: 可配置（默认100条/批）
- 吞吐量: >100万条/秒（单线程）

### 3.3 DataStorage (存储接口)

**设计模式**: 策略模式 + 工厂模式

**核心接口**:
```java
public interface DataStorage {
    void open(Path path, OpenMode mode);
    void writeRecord(DataRecord record);
    void writeRecords(List<DataRecord> records);  // 批量写入
    void registerChannel(DataChannel channel);
    void flush();
    void close();
    
    // 特性检测
    boolean supportsConcurrentWrite();
    boolean supportsReadWhileWriting();
}
```

### 3.4 MDF4Storage (MDF4存储实现)

**文件格式** (ASAM MDF 4.1.1标准):

```
MDF4 File Structure:
┌─────────────────────────────────────────────────────────────┐
│ ID Block (64 bytes)                                          │
│ - File ID: "MDF "                                            │
│ - Version: "4.11"                                            │
│ - Program: "DataObserver"                                    │
├─────────────────────────────────────────────────────────────┤
│ Header Block (HD)                                            │
│ - Start Time (nanoseconds)                                   │
│ - Author, Project, Subject                                   │
│ - Links to Data Groups                                       │
├─────────────────────────────────────────────────────────────┤
│ File History Block (FH) [Optional]                           │
│ - Creation/Modification history                              │
├─────────────────────────────────────────────────────────────┤
│ Data Group Block (DG)                                        │
│ - Record ID size                                             │
│ - Links to Channel Groups                                    │
│ - Links to Data Blocks                                       │
├─────────────────────────────────────────────────────────────┤
│ Channel Group Block (CG)                                     │
│ - Record ID                                                  │
│ - Cycle Count (record count)                                 │
│ - Data Bytes (record size)                                   │
│ - Links to Channel Blocks                                    │
├─────────────────────────────────────────────────────────────┤
│ Channel Blocks (CN)                                          │
│ - Channel Type (data/master)                                 │
│ - Data Type (uint8, int32, float, double, etc.)              │
│ - Byte Offset                                                │
│ - Bit Count                                                  │
│ - Links to Name/Unit/Comment blocks                          │
├─────────────────────────────────────────────────────────────┤
│ Data Block (DT)                                              │
│ - Raw binary data records                                    │
│ - Fixed record size (sorted)                                 │
└─────────────────────────────────────────────────────────────┘
```

**块链接结构**:
```
HD ──▶ DG ──▶ CG ──▶ CN1 ──▶ CN2 ──▶ CN3 ──▶ ...
       │      │       │       │       │
       │      │       ▼       ▼       ▼
       │      │     TX(name) TX(name) TX(name)
       │      │     TX(unit) TX(unit) TX(unit)
       │      │
       │      ▼
       │     DT (Data Block)
       │
       ▼
      DG (next data group, optional)
```

**大文件处理策略**:
1. **内存映射**: 使用`MappedByteBuffer`处理大文件
2. **分块映射**: 每次映射固定大小（默认64MB）
3. **动态扩展**: 文件大小动态增长
4. **批量刷新**: 定期强制写入磁盘

## 4. 并发设计

### 4.1 读写分离

```
┌─────────────────────────────────────────────────────────┐
│                      Write Path                          │
│  DataSource ──▶ RingBuffer ──▶ WriterThread ──▶ Storage │
│     (多线程)      (无锁)         (单线程)        (IO)    │
└─────────────────────────────────────────────────────────┘
                           │
                           │ Read-Write Lock
                           │ (Storage level)
                           ▼
┌─────────────────────────────────────────────────────────┐
│                      Read Path                           │
│  Reader ──▶ Storage (concurrent read supported)         │
│  (支持读写同时进行)                                       │
└─────────────────────────────────────────────────────────┘
```

### 4.2 锁策略

| 组件 | 锁类型 | 说明 |
|------|--------|------|
| RingBuffer | 无锁(CAS) | 高性能，无阻塞 |
| DataSource管理 | 读写锁 | 读多写少场景 |
| Storage写入 | 内部同步 | 保证数据一致性 |
| 文件IO | NIO Channel | 支持并发读写 |

### 4.3 线程模型

```
Main Thread:
  - DataObserver管理
  - 数据源生命周期控制

Worker Threads (N个):
  - 数据写入处理
  - 批量写入优化

Scheduler Thread:
  - 缓冲区监控
  - 统计信息更新

DataSource Threads (每个Source一个):
  - 数据生成/采集
  - 独立采样率控制
```

## 5. 性能优化

### 5.1 写入优化

| 优化策略 | 实现方式 | 效果 |
|----------|----------|------|
| 批量写入 | 积累N条记录后一次性写入 | 减少IO次数 |
| 缓冲区 | RingBuffer解耦生产消费 | 提高吞吐量 |
| 内存映射 | MappedByteBuffer | 减少数据拷贝 |
| 压缩 | 支持DZBlock压缩 | 减少存储空间 |

### 5.2 内存优化

| 策略 | 说明 |
|------|------|
| 对象池 | 复用DataRecord对象 |
| 直接缓冲区 | ByteBuffer.allocateDirect |
| 分块映射 | 避免一次性映射大文件 |
| 及时清理 | 释放不再使用的缓冲区 |

### 5.3 性能指标

| 指标 | 目标值 | 测试环境 |
|------|--------|----------|
| 写入吞吐量 | >100,000 records/sec | 单通道，SSD |
| 延迟 | <10ms (p99) | 批量大小100 |
| 并发数据源 | >100个 | 8GB内存 |
| 最大文件大小 | >10GB | 64位系统 |
| 缓冲区内存 | <500MB | 默认配置 |

## 6. 扩展性设计

### 6.1 存储格式扩展

```java
// 1. 实现DataStorage接口
public class ParquetStorage implements DataStorage {
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.PARQUET;
    }
    // ... 实现其他方法
}

// 2. 注册到工厂
StorageFactory.registerProvider(
    StorageFormat.PARQUET, 
    ParquetStorage::new
);

// 3. 使用
observer.createStorage(path, StorageFormat.PARQUET);
```

### 6.2 数据源扩展

```java
// 实现DataSource接口
public class CanBusDataSource implements DataSource {
    @Override
    public void start() {
        // 初始化CAN接口
    }
    
    @Override
    public void setDataCallback(DataCallback callback) {
        // 设置数据回调
        this.callback = callback;
    }
    // ...
}
```

## 7. 错误处理

### 7.1 异常分类

| 级别 | 类型 | 处理方式 |
|------|------|----------|
| 致命 | 存储引擎初始化失败 | 抛出异常，终止启动 |
| 严重 | 写入失败 | 通知监听器，尝试恢复 |
| 警告 | 缓冲区满 | 丢弃数据，记录日志 |
| 信息 | 采样率不匹配 | 自动调整，记录日志 |

### 7.2 恢复机制

```java
// 写入失败重试
int retryCount = 0;
while (retryCount < MAX_RETRIES) {
    try {
        storage.writeRecords(batch);
        break;
    } catch (IOException e) {
        retryCount++;
        if (retryCount >= MAX_RETRIES) {
            notifyError("Write failed after retries", e);
        }
        Thread.sleep(RETRY_DELAY_MS);
    }
}
```

## 8. 监控与诊断

### 8.1 统计信息

```java
public class Statistics {
    long totalRecords;        // 总记录数
    long storageRecordCount;  // 已持久化记录数
    int bufferSize;           // 当前缓冲区大小
    int bufferCapacity;       // 缓冲区容量
    int activeSources;        // 活跃数据源数
    boolean isRecording;      // 是否正在记录
    long fileSize;            // 文件大小
}
```

### 8.2 监控指标

- 缓冲区使用率
- 写入吞吐量
- 数据源采样率
- 文件增长速度
- 错误发生率

## 9. 部署建议

### 9.1 JVM配置

```bash
java -Xms2g -Xmx4g \
     -XX:+UseG1GC \
     -XX:MaxGCPauseMillis=200 \
     -XX:+UseLargePages \
     -jar data-observer.jar
```

### 9.2 系统配置

- 文件描述符限制: >65535
- 虚拟内存: 充足（用于内存映射）
- 磁盘IO: SSD推荐
- CPU: 多核（用于并发处理）

## 10. 未来扩展

1. **网络传输**: 支持远程数据收集
2. **实时分析**: 内置数据处理和告警
3. **云存储**: 支持S3等对象存储
4. **数据压缩**: 更高效的压缩算法
5. **分布式**: 支持多节点数据收集
