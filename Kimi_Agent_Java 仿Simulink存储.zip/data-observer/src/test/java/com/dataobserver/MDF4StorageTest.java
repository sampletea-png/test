package com.dataobserver;

import com.dataobserver.core.*;
import com.dataobserver.mdf4.MDF4Storage;
import com.dataobserver.storage.DataStorage;
import com.dataobserver.storage.StorageFormat;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MDF4存储测试类
 */
public class MDF4StorageTest {
    
    private static final String TEST_FILE = "test.mf4";
    private MDF4Storage storage;
    
    @BeforeEach
    public void setUp() {
        storage = new MDF4Storage();
    }
    
    @AfterEach
    public void tearDown() throws IOException {
        if (storage != null) {
            storage.close();
        }
        // 清理测试文件
        File file = new File(TEST_FILE);
        if (file.exists()) {
            file.delete();
        }
    }
    
    @Test
    public void testCreateAndClose() throws IOException {
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        assertTrue(storage.supportsConcurrentWrite());
        assertTrue(storage.supportsReadWhileWriting());
        assertEquals(StorageFormat.MDF4, storage.getFormat());
        
        storage.close();
        
        assertTrue(file.exists());
        assertTrue(file.length() > 0);
    }
    
    @Test
    public void testRegisterChannel() throws IOException {
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        // 创建测试通道
        TestDataChannel channel = new TestDataChannel(
            "test_channel", 
            DataType.DOUBLE, 
            "V",
            -10.0,
            10.0
        );
        
        storage.registerChannel(channel);
        
        assertEquals(1, storage.getRegisteredChannels().size());
        assertEquals(channel.getName(), storage.getRegisteredChannels().get(0).getName());
        
        storage.close();
    }
    
    @Test
    public void testWriteAndReadRecords() throws IOException {
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        // 注册通道
        TestDataChannel channel1 = new TestDataChannel("channel1", DataType.DOUBLE, "V", null, null);
        TestDataChannel channel2 = new TestDataChannel("channel2", DataType.INT32, "count", null, null);
        
        storage.registerChannel(channel1);
        storage.registerChannel(channel2);
        
        // 写入记录
        long timestamp = System.nanoTime();
        DataRecord record = new DataRecord(timestamp);
        record.addValue("channel1", 3.14, DataType.DOUBLE);
        record.addValue("channel2", 42, DataType.INT32);
        
        storage.writeRecord(record);
        
        assertEquals(1, storage.getRecordCount());
        
        // 刷新到磁盘
        storage.flush();
        
        assertTrue(storage.getFileSize() > 0);
        
        storage.close();
    }
    
    @Test
    public void testMultipleRecords() throws IOException {
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        // 注册通道
        TestDataChannel channel = new TestDataChannel("value", DataType.DOUBLE, "V", null, null);
        storage.registerChannel(channel);
        
        // 写入多条记录
        int recordCount = 1000;
        for (int i = 0; i < recordCount; i++) {
            DataRecord record = new DataRecord(System.nanoTime());
            record.addValue("value", (double) i, DataType.DOUBLE);
            storage.writeRecord(record);
        }
        
        assertEquals(recordCount, storage.getRecordCount());
        
        storage.close();
        
        // 验证文件大小
        File file = new File(TEST_FILE);
        assertTrue(file.length() > recordCount * 8);  // 至少每条记录8字节
    }
    
    @Test
    public void testAppendMode() throws IOException {
        // 先创建文件
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        TestDataChannel channel = new TestDataChannel("value", DataType.INT32, "count", null, null);
        storage.registerChannel(channel);
        
        DataRecord record1 = new DataRecord(System.nanoTime());
        record1.addValue("value", 100, DataType.INT32);
        storage.writeRecord(record1);
        
        storage.close();
        
        long fileSize1 = new File(TEST_FILE).length();
        
        // 以追加模式打开
        storage = new MDF4Storage();
        storage.open(path, DataStorage.OpenMode.APPEND);
        
        DataRecord record2 = new DataRecord(System.nanoTime());
        record2.addValue("value", 200, DataType.INT32);
        storage.writeRecord(record2);
        
        storage.close();
        
        long fileSize2 = new File(TEST_FILE).length();
        
        assertTrue(fileSize2 > fileSize1);
    }
    
    @Test
    public void testLargeFile() throws IOException {
        Path path = Paths.get(TEST_FILE);
        storage.open(path, DataStorage.OpenMode.CREATE);
        
        // 注册多个通道
        storage.registerChannel(new TestDataChannel("ch1", DataType.DOUBLE, "V", null, null));
        storage.registerChannel(new TestDataChannel("ch2", DataType.DOUBLE, "A", null, null));
        storage.registerChannel(new TestDataChannel("ch3", DataType.INT32, "count", null, null));
        
        // 写入大量记录（模拟GB级数据）
        int recordCount = 100000;  // 实际测试时可增加
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < recordCount; i++) {
            DataRecord record = new DataRecord(System.nanoTime());
            record.addValue("ch1", Math.sin(i * 0.01), DataType.DOUBLE);
            record.addValue("ch2", Math.cos(i * 0.01), DataType.DOUBLE);
            record.addValue("ch3", i, DataType.INT32);
            storage.writeRecord(record);
            
            // 每10000条刷新一次
            if (i % 10000 == 0) {
                storage.flush();
            }
        }
        
        long duration = System.currentTimeMillis() - startTime;
        double throughput = (double) recordCount / duration * 1000;
        
        System.out.println("Wrote " + recordCount + " records in " + duration + " ms");
        System.out.println("Throughput: " + String.format("%.2f", throughput) + " records/sec");
        
        storage.close();
        
        File file = new File(TEST_FILE);
        System.out.println("File size: " + (file.length() / 1024 / 1024) + " MB");
        
        assertTrue(file.length() > 0);
    }
    
    /**
     * 测试数据通道实现
     */
    private static class TestDataChannel implements DataChannel {
        private final String name;
        private final DataType dataType;
        private final String unit;
        private final Double minValue;
        private final Double maxValue;
        
        TestDataChannel(String name, DataType dataType, String unit, 
                       Double minValue, Double maxValue) {
            this.name = name;
            this.dataType = dataType;
            this.unit = unit;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }
        
        @Override
        public String getId() {
            return "test." + name;
        }
        
        @Override
        public String getName() {
            return name;
        }
        
        @Override
        public String getDescription() {
            return "Test channel: " + name;
        }
        
        @Override
        public DataType getDataType() {
            return dataType;
        }
        
        @Override
        public String getUnit() {
            return unit;
        }
        
        @Override
        public Double getMinValue() {
            return minValue;
        }
        
        @Override
        public Double getMaxValue() {
            return maxValue;
        }
        
        @Override
        public String getConversionFormula() {
            return "linear(1,0)";
        }
        
        @Override
        public boolean isMasterChannel() {
            return false;
        }
        
        @Override
        public DataSource getSource() {
            return null;
        }
        
        @Override
        public double getSampleRate() {
            return 100.0;
        }
        
        @Override
        public java.util.Map<String, String> getMetadata() {
            return new java.util.HashMap<>();
        }
    }
}
