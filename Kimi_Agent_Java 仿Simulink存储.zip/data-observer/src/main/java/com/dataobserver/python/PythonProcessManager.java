package com.dataobserver.python;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataRecord;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.*;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Python进程管理器
 * 管理Python子进程，通过stdin/stdout进行通信
 */
public class PythonProcessManager implements AutoCloseable {
    
    private static final Logger LOGGER = Logger.getLogger(PythonProcessManager.class.getName());
    
    private Process pythonProcess;
    private BufferedReader reader;
    private BufferedWriter writer;
    private final ObjectMapper objectMapper;
    
    // 响应队列
    private final BlockingQueue<JsonNode> responseQueue;
    private final ExecutorService responseHandler;
    
    // 状态
    private final AtomicBoolean isRunning;
    private final AtomicInteger commandId;
    
    // Python脚本路径
    private final String pythonScriptPath;
    private final String pythonExecutable;
    
    public PythonProcessManager() {
        this("python3", findPythonScript());
    }
    
    public PythonProcessManager(String pythonExecutable, String pythonScriptPath) {
        this.pythonExecutable = pythonExecutable;
        this.pythonScriptPath = pythonScriptPath;
        this.objectMapper = new ObjectMapper();
        this.responseQueue = new LinkedBlockingQueue<>();
        this.responseHandler = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "Python-Response-Handler");
            t.setDaemon(true);
            return t;
        });
        this.isRunning = new AtomicBoolean(false);
        this.commandId = new AtomicInteger(0);
    }
    
    /**
     * 查找Python脚本路径
     */
    private static String findPythonScript() {
        // 尝试多个可能的位置
        String[] possiblePaths = {
            "python/mdf4_storage.py",
            "../python/mdf4_storage.py",
            "src/main/python/mdf4_storage.py",
            "mdf4_storage.py"
        };
        
        for (String path : possiblePaths) {
            File file = new File(path);
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        
        // 默认返回相对路径
        return "python/mdf4_storage.py";
    }
    
    /**
     * 启动Python进程
     */
    public synchronized void start() throws IOException {
        if (isRunning.get()) {
            return;
        }
        
        LOGGER.info("Starting Python process: " + pythonExecutable + " " + pythonScriptPath);
        
        ProcessBuilder pb = new ProcessBuilder(
            pythonExecutable,
            pythonScriptPath
        );
        
        // 设置工作目录
        pb.directory(new File("."));
        
        // 启动进程
        pythonProcess = pb.start();
        
        // 初始化IO
        reader = new BufferedReader(new InputStreamReader(pythonProcess.getInputStream()));
        writer = new BufferedWriter(new OutputStreamWriter(pythonProcess.getOutputStream()));
        
        // 启动响应处理线程
        isRunning.set(true);
        responseHandler.submit(this::handleResponses);
        
        // 等待就绪信号
        waitForReady();
        
        LOGGER.info("Python process started successfully");
    }
    
    /**
     * 等待Python进程就绪
     */
    private void waitForReady() throws IOException {
        try {
            String line = reader.readLine();
            if (line != null) {
                JsonNode response = objectMapper.readTree(line);
                if ("ready".equals(response.get("status").asText())) {
                    LOGGER.info("Python service ready: " + response.get("message").asText());
                }
            }
        } catch (Exception e) {
            throw new IOException("Failed to initialize Python process", e);
        }
    }
    
    /**
     * 处理响应
     */
    private void handleResponses() {
        while (isRunning.get()) {
            try {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                
                JsonNode response = objectMapper.readTree(line);
                responseQueue.offer(response);
                
            } catch (IOException e) {
                if (isRunning.get()) {
                    LOGGER.log(Level.WARNING, "Error reading from Python process", e);
                }
            }
        }
    }
    
    /**
     * 发送命令并等待响应
     */
    public JsonNode sendCommand(String command, Map<String, Object> params) throws IOException {
        ensureRunning();
        
        ObjectNode request = objectMapper.createObjectNode();
        request.put("command", command);
        request.put("id", commandId.incrementAndGet());
        
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                request.set(entry.getKey(), objectMapper.valueToTree(entry.getValue()));
            }
        }
        
        // 清空响应队列（避免读取旧响应）
        responseQueue.clear();
        
        // 发送命令
        String json = request.toString();
        LOGGER.fine("Sending command: " + json);
        
        synchronized (writer) {
            writer.write(json);
            writer.newLine();
            writer.flush();
        }
        
        // 等待响应
        try {
            JsonNode response = responseQueue.poll(30, TimeUnit.SECONDS);
            if (response == null) {
                throw new IOException("Timeout waiting for Python response");
            }
            return response;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while waiting for response", e);
        }
    }
    
    /**
     * 打开文件
     */
    public JsonNode openFile(String path, String mode) throws IOException {
        return sendCommand("open", Map.of(
            "path", path,
            "mode", mode
        ));
    }
    
    /**
     * 关闭文件
     */
    public JsonNode closeFile() throws IOException {
        return sendCommand("close", null);
    }
    
    /**
     * 注册通道
     */
    public JsonNode registerChannel(DataChannel channel) throws IOException {
        Map<String, Object> channelInfo = Map.of(
            "name", channel.getName(),
            "data_type", channel.getDataType().name(),
            "unit", channel.getUnit() != null ? channel.getUnit() : "",
            "description", channel.getDescription() != null ? channel.getDescription() : "",
            "min_value", channel.getMinValue(),
            "max_value", channel.getMaxValue(),
            "sample_rate", channel.getSampleRate()
        );
        
        return sendCommand("register_channel", Map.of("channel", channelInfo));
    }
    
    /**
     * 写入单条记录
     */
    public JsonNode writeRecord(DataRecord record) throws IOException {
        Map<String, Object> recordMap = Map.of(
            "timestamp", record.getTimestamp(),
            "values", record.getAllValues()
        );
        
        return sendCommand("write_record", Map.of("record", recordMap));
    }
    
    /**
     * 批量写入记录
     */
    public JsonNode writeRecords(List<DataRecord> records) throws IOException {
        List<Map<String, Object>> recordList = records.stream()
            .map(r -> Map.of(
                "timestamp", r.getTimestamp(),
                "values", (Object) r.getAllValues()
            ))
            .toList();
        
        return sendCommand("write_records", Map.of("records", recordList));
    }
    
    /**
     * 刷新缓冲区
     */
    public JsonNode flush() throws IOException {
        return sendCommand("flush", null);
    }
    
    /**
     * 获取文件信息
     */
    public JsonNode getInfo() throws IOException {
        return sendCommand("info", null);
    }
    
    /**
     * 确保进程正在运行
     */
    private void ensureRunning() throws IOException {
        if (!isRunning.get() || pythonProcess == null || !pythonProcess.isAlive()) {
            throw new IOException("Python process is not running");
        }
    }
    
    @Override
    public synchronized void close() throws Exception {
        if (!isRunning.get()) {
            return;
        }
        
        LOGGER.info("Closing Python process manager");
        
        isRunning.set(false);
        
        // 发送退出命令
        try {
            sendCommand("exit", null);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error sending exit command", e);
        }
        
        // 关闭IO
        if (writer != null) {
            writer.close();
        }
        if (reader != null) {
            reader.close();
        }
        
        // 等待进程结束
        if (pythonProcess != null) {
            boolean terminated = pythonProcess.waitFor(5, TimeUnit.SECONDS);
            if (!terminated) {
                LOGGER.warning("Python process did not terminate, forcing...");
                pythonProcess.destroyForcibly();
            }
        }
        
        // 关闭线程池
        responseHandler.shutdown();
        responseHandler.awaitTermination(5, TimeUnit.SECONDS);
        
        LOGGER.info("Python process manager closed");
    }
    
    /**
     * 检查Python环境
     */
    public static boolean checkPythonEnvironment() {
        try {
            ProcessBuilder pb = new ProcessBuilder("python3", "--version");
            Process process = pb.start();
            boolean success = process.waitFor(5, TimeUnit.SECONDS);
            return success && process.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 检查asammdf是否安装
     */
    public static boolean checkAsammdf() {
        try {
            ProcessBuilder pb = new ProcessBuilder("python3", "-c", "import asammdf");
            Process process = pb.start();
            return process.waitFor(5, TimeUnit.SECONDS) && process.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
