package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * MDF4数据块（Data Block - DT）
 * 存储实际的数据记录
 */
public class MDF4DataBlock extends MDF4Block {
    
    // 数据内容
    private byte[] data;
    
    // 内存映射相关
    private long dataStartPosition;
    private boolean useMemoryMapping;
    private FileChannel fileChannel;
    
    public MDF4DataBlock() {
        super(MDF4BlockType.DT);
        this.data = new byte[0];
        this.useMemoryMapping = false;
    }
    
    public MDF4DataBlock(byte[] data) {
        super(MDF4BlockType.DT);
        this.data = data != null ? data : new byte[0];
        this.useMemoryMapping = false;
    }
    
    /**
     * 创建用于内存映射的数据块
     */
    public static MDF4DataBlock createForMemoryMapping(long initialSize) {
        MDF4DataBlock block = new MDF4DataBlock();
        block.useMemoryMapping = true;
        block.data = new byte[(int) Math.min(initialSize, Integer.MAX_VALUE)];
        return block;
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 无链接 + 数据
        return 24 + (data != null ? data.length : 0);
    }
    
    @Override
    protected int calculateLinkCount() {
        return 0;  // 数据块没有链接
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        // 无链接
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        if (data != null && data.length > 0) {
            file.write(data);
        }
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        // 无链接
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        long dataSize = blockSize - 24;  // 减去头部大小
        if (dataSize > 0) {
            if (dataSize > Integer.MAX_VALUE) {
                throw new IOException("Data block too large: " + dataSize);
            }
            data = new byte[(int) dataSize];
            file.readFully(data);
        }
    }
    
    /**
     * 追加数据到块
     */
    public void appendData(byte[] newData) {
        if (newData == null || newData.length == 0) {
            return;
        }
        
        byte[] combined = new byte[data.length + newData.length];
        System.arraycopy(data, 0, combined, 0, data.length);
        System.arraycopy(newData, 0, combined, data.length, newData.length);
        this.data = combined;
    }
    
    /**
     * 使用内存映射追加数据
     */
    public long appendDataMapped(RandomAccessFile file, byte[] newData) throws IOException {
        if (!useMemoryMapping) {
            throw new IllegalStateException("Memory mapping not enabled");
        }
        
        long currentPos = file.getFilePointer();
        
        // 写入数据
        file.write(newData);
        
        return newData.length;
    }
    
    /**
     * 获取数据开始位置（用于内存映射读取）
     */
    public long getDataStartPosition() {
        return dataStartPosition;
    }
    
    public void setDataStartPosition(long position) {
        this.dataStartPosition = position;
    }
    
    public void setData(byte[] data) {
        this.data = data != null ? data : new byte[0];
    }
    
    public byte[] getData() {
        return data;
    }
    
    public int getDataLength() {
        return data != null ? data.length : 0;
    }
    
    public boolean isUseMemoryMapping() {
        return useMemoryMapping;
    }
    
    public void setUseMemoryMapping(boolean useMemoryMapping) {
        this.useMemoryMapping = useMemoryMapping;
    }
}
