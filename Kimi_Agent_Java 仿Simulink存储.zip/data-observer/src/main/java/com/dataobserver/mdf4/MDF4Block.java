package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * MDF4块基类
 * 所有MDF4块的抽象基类
 */
public abstract class MDF4Block {
    
    protected static final ByteOrder BYTE_ORDER = ByteOrder.LITTLE_ENDIAN;
    protected static final String CHARSET = "UTF-8";
    
    // 块头大小（字节）
    protected static final int BLOCK_HEADER_SIZE = 24;
    
    // 块类型（4字节）
    protected final MDF4BlockType blockType;
    
    // 块在文件中的位置
    protected long filePosition = -1;
    
    // 块大小（包括头部和数据）
    protected long blockSize;
    
    // 链接块数量
    protected int linkCount;
    
    protected MDF4Block(MDF4BlockType blockType) {
        this.blockType = blockType;
    }
    
    /**
     * 获取块类型
     */
    public MDF4BlockType getBlockType() {
        return blockType;
    }
    
    /**
     * 获取块在文件中的位置
     */
    public long getFilePosition() {
        return filePosition;
    }
    
    /**
     * 获取块大小
     */
    public long getBlockSize() {
        return blockSize;
    }
    
    /**
     * 计算块大小
     */
    protected abstract long calculateBlockSize();
    
    /**
     * 获取链接数量
     */
    protected abstract int calculateLinkCount();
    
    /**
     * 写入块到文件
     */
    public long write(RandomAccessFile file) throws IOException {
        this.filePosition = file.getFilePointer();
        this.blockSize = calculateBlockSize();
        this.linkCount = calculateLinkCount();
        
        // 写入块头
        writeBlockHeader(file);
        
        // 写入链接
        writeLinks(file);
        
        // 写入数据
        writeData(file);
        
        return filePosition;
    }
    
    /**
     * 写入块头
     */
    protected void writeBlockHeader(RandomAccessFile file) throws IOException {
        // 块类型ID（4字节）
        byte[] typeBytes = blockType.getBlockId().getBytes(StandardCharsets.US_ASCII);
        file.write(typeBytes);
        if (typeBytes.length < 4) {
            file.write(new byte[4 - typeBytes.length]);
        }
        
        // 保留字段（4字节）
        file.writeInt(0);
        
        // 块大小（8字节）
        file.writeLong(blockSize);
        
        // 链接数量（8字节）
        file.writeLong(linkCount);
    }
    
    /**
     * 写入链接
     */
    protected abstract void writeLinks(RandomAccessFile file) throws IOException;
    
    /**
     * 写入数据
     */
    protected abstract void writeData(RandomAccessFile file) throws IOException;
    
    /**
     * 从文件读取块
     */
    public void read(RandomAccessFile file, long position) throws IOException {
        this.filePosition = position;
        file.seek(position);
        
        // 读取块头
        readBlockHeader(file);
        
        // 读取链接
        readLinks(file);
        
        // 读取数据
        readData(file);
    }
    
    /**
     * 读取块头
     */
    protected void readBlockHeader(RandomAccessFile file) throws IOException {
        // 块类型ID（4字节）
        byte[] typeBytes = new byte[4];
        file.readFully(typeBytes);
        String typeId = new String(typeBytes, StandardCharsets.US_ASCII).trim();
        
        if (!typeId.equals(blockType.getBlockId().trim())) {
            throw new IOException("Invalid block type. Expected: " + blockType.getBlockId() + ", Found: " + typeId);
        }
        
        // 保留字段（4字节）
        file.skipBytes(4);
        
        // 块大小（8字节）
        this.blockSize = file.readLong();
        
        // 链接数量（8字节）
        this.linkCount = (int) file.readLong();
    }
    
    /**
     * 读取链接
     */
    protected abstract void readLinks(RandomAccessFile file) throws IOException;
    
    /**
     * 读取数据
     */
    protected abstract void readData(RandomAccessFile file) throws IOException;
    
    /**
     * 更新链接
     */
    public void updateLink(RandomAccessFile file, int linkIndex, long targetPosition) throws IOException {
        long linkOffset = filePosition + 24 + linkIndex * 8;  // 24是头部大小
        file.seek(linkOffset);
        file.writeLong(targetPosition);
    }
    
    /**
     * 辅助方法：写入字符串到ByteBuffer
     */
    protected void putString(ByteBuffer buffer, String str, int maxLength) {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        int len = Math.min(bytes.length, maxLength);
        buffer.put(bytes, 0, len);
        // 填充剩余空间
        for (int i = len; i < maxLength; i++) {
            buffer.put((byte) 0);
        }
    }
    
    /**
     * 辅助方法：从文件读取字符串
     */
    protected String readString(RandomAccessFile file, int length) throws IOException {
        byte[] bytes = new byte[length];
        file.readFully(bytes);
        // 找到null终止符
        int actualLen = 0;
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] == 0) {
                actualLen = i;
                break;
            }
        }
        if (actualLen == 0) actualLen = bytes.length;
        return new String(bytes, 0, actualLen, StandardCharsets.UTF_8);
    }
}
