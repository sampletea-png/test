package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * MDF4标识块（ID Block）
 * 文件的第一个块，固定64字节
 */
public class MDF4IDBlock extends MDF4Block {
    
    // 固定参数
    private static final String FILE_ID = "MDF ";
    private static final String FORMAT_ID = "4.11";
    private static final String PROGRAM_ID = "DataObserver";
    private static final byte BYTE_ORDER_CODE = 0;  // 0 = Little Endian
    
    // 浮点格式（8字节）
    private static final byte[] FLOAT_FORMAT = {0, 0, 0, 0, 0, 0, 0, 0};
    
    // 版本号
    private final int version;
    private final int minorVersion;
    
    public MDF4IDBlock() {
        super(MDF4BlockType.ID);
        this.version = 4;
        this.minorVersion = 11;
    }
    
    public MDF4IDBlock(int version, int minorVersion) {
        super(MDF4BlockType.ID);
        this.version = version;
        this.minorVersion = minorVersion;
    }
    
    @Override
    protected long calculateBlockSize() {
        return 64;  // ID块固定64字节
    }
    
    @Override
    protected int calculateLinkCount() {
        return 0;  // ID块没有链接
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        // ID块没有链接
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 文件标识符（8字节）
        byte[] fileIdBytes = FILE_ID.getBytes(StandardCharsets.US_ASCII);
        file.write(fileIdBytes);
        file.write(new byte[8 - fileIdBytes.length]);
        
        // 格式标识符（8字节）
        byte[] formatIdBytes = FORMAT_ID.getBytes(StandardCharsets.US_ASCII);
        file.write(formatIdBytes);
        file.write(new byte[8 - formatIdBytes.length]);
        
        // 程序标识符（8字节）
        byte[] programIdBytes = PROGRAM_ID.getBytes(StandardCharsets.US_ASCII);
        file.write(programIdBytes);
        file.write(new byte[8 - programIdBytes.length]);
        
        // 字节序（2字节）
        file.writeShort(BYTE_ORDER_CODE);
        
        // 浮点格式（2字节）
        file.write(FLOAT_FORMAT, 0, 2);
        
        // 版本号（2字节）
        file.writeShort(version * 100 + minorVersion);
        
        // 保留字段（2字节）
        file.writeShort(0);
        
        // 标准版本（1字节）
        file.writeByte(4);
        
        // 保留字段（1字节）
        file.writeByte(0);
        
        // 扩展块偏移（8字节）
        file.writeLong(0);  // 无扩展块
        
        // 填充到64字节
        long currentPos = file.getFilePointer();
        long padding = 64 - currentPos;
        if (padding > 0) {
            file.write(new byte[(int) padding]);
        }
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        // ID块没有链接
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        // 读取文件标识符
        byte[] fileIdBytes = new byte[8];
        file.readFully(fileIdBytes);
        
        // 读取格式标识符
        byte[] formatIdBytes = new byte[8];
        file.readFully(formatIdBytes);
        
        // 读取程序标识符
        byte[] programIdBytes = new byte[8];
        file.readFully(programIdBytes);
        
        // 跳过剩余字段
        file.skipBytes(64 - 24 - 8);  // 64字节总数减去已读取的
    }
    
    public String getVersionString() {
        return version + "." + minorVersion;
    }
    
    public int getVersion() {
        return version;
    }
    
    public int getMinorVersion() {
        return minorVersion;
    }
}
