package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * MDF4通道组块（Channel Group Block - CG）
 * 包含一组相关的通道
 */
public class MDF4ChannelGroupBlock extends MDF4Block {
    
    // 链接
    private long nextCgPosition = 0;       // 下一个通道组块位置
    private long cnFirstPosition = 0;      // 第一个通道块位置
    private long txAcqNamePosition = 0;    // 采集名称文本块位置
    private long siAcqSourcePosition = 0;  // 采集源信息块位置
    private long srFirstPosition = 0;      // 第一个采样缩减块位置（可选）
    private long mdCommentPosition = 0;    // 注释块位置（可选）
    
    // 数据字段
    private long recordId;                 // 记录ID
    private long cycleCount;               // 循环计数（记录数）
    private short flags;                   // 标志
    private byte pathSeparator;            // 路径分隔符
    private int reserved;                  // 保留字段
    private long dataBytes;                // 每个记录的数据字节数
    private long invalBytes;               // 无效字节数
    
    // 运行时数据
    private String name;
    private String comment;
    private int recordSize;                // 记录大小（计算得出）
    
    public MDF4ChannelGroupBlock() {
        super(MDF4BlockType.CG);
        this.recordId = 1;
        this.cycleCount = 0;
        this.flags = 0;
        this.pathSeparator = (byte) '\\';
        this.reserved = 0;
        this.dataBytes = 0;
        this.invalBytes = 0;
        this.recordSize = 0;
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 链接6*8=48字节 + 数据字段
        return 24 + 48 + 8 + 8 + 2 + 1 + 1 + 4 + 8 + 8;
    }
    
    @Override
    protected int calculateLinkCount() {
        return 6;
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        file.writeLong(nextCgPosition);
        file.writeLong(cnFirstPosition);
        file.writeLong(txAcqNamePosition);
        file.writeLong(siAcqSourcePosition);
        file.writeLong(srFirstPosition);
        file.writeLong(mdCommentPosition);
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        file.writeLong(recordId);
        file.writeLong(cycleCount);
        file.writeShort(flags);
        file.writeByte(pathSeparator);
        file.writeByte(0);  // 保留
        file.writeInt(reserved);
        file.writeLong(dataBytes);
        file.writeLong(invalBytes);
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        nextCgPosition = file.readLong();
        cnFirstPosition = file.readLong();
        txAcqNamePosition = file.readLong();
        siAcqSourcePosition = file.readLong();
        srFirstPosition = file.readLong();
        mdCommentPosition = file.readLong();
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        recordId = file.readLong();
        cycleCount = file.readLong();
        flags = file.readShort();
        pathSeparator = file.readByte();
        file.readByte();  // 保留
        reserved = file.readInt();
        dataBytes = file.readLong();
        invalBytes = file.readLong();
    }
    
    // Getters and Setters
    
    public void setNextCgPosition(long position) {
        this.nextCgPosition = position;
    }
    
    public long getNextCgPosition() {
        return nextCgPosition;
    }
    
    public void setCnFirstPosition(long position) {
        this.cnFirstPosition = position;
    }
    
    public long getCnFirstPosition() {
        return cnFirstPosition;
    }
    
    public void setTxAcqNamePosition(long position) {
        this.txAcqNamePosition = position;
    }
    
    public long getTxAcqNamePosition() {
        return txAcqNamePosition;
    }
    
    public void setMdCommentPosition(long position) {
        this.mdCommentPosition = position;
    }
    
    public long getMdCommentPosition() {
        return mdCommentPosition;
    }
    
    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }
    
    public long getRecordId() {
        return recordId;
    }
    
    public void setCycleCount(long cycleCount) {
        this.cycleCount = cycleCount;
    }
    
    public long getCycleCount() {
        return cycleCount;
    }
    
    public void incrementCycleCount() {
        this.cycleCount++;
    }
    
    public void setDataBytes(long dataBytes) {
        this.dataBytes = dataBytes;
        this.recordSize = (int) dataBytes;
    }
    
    public long getDataBytes() {
        return dataBytes;
    }
    
    public void setInvalBytes(long invalBytes) {
        this.invalBytes = invalBytes;
    }
    
    public long getInvalBytes() {
        return invalBytes;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public int getRecordSize() {
        return recordSize;
    }
    
    public void setRecordSize(int recordSize) {
        this.recordSize = recordSize;
        this.dataBytes = recordSize;
    }
}
