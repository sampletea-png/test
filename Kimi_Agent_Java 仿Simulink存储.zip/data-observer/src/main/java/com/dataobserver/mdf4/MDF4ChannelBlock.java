package com.dataobserver.mdf4;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataType;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * MDF4通道块（Channel Block - CN）
 * 描述一个数据通道的属性
 */
public class MDF4ChannelBlock extends MDF4Block {
    
    // 链接
    private long nextCnPosition = 0;       // 下一个通道块位置
    private long ccPosition = 0;           // 转换块位置
    private long cePosition = 0;           // 通道扩展块位置（可选）
    private long cdPosition = 0;           // 通道依赖块位置（可选）
    private long namePosition = 0;         // 通道名称文本块位置
    private long sourcePosition = 0;       // 源信息块位置
    private long unitPosition = 0;         // 单位文本块位置
    private long commentPosition = 0;      // 注释文本块位置
    
    // 数据字段
    private byte channelType;              // 通道类型（0=数据，1=时间）
    private byte syncType;                 // 同步类型
    private byte dataType;                 // 数据类型
    private byte bitOffset;                // 位偏移
    private int byteOffset;                // 字节偏移
    private int bitCount;                  // 位数
    private long flags;                    // 标志
    private long posInvalBit;              // 无效位位置
    private long precision;                // 精度
    private long valRangeMin;              // 最小值
    private long valRangeMax;              // 最大值
    private long limitMin;                 // 下限
    private long limitMax;                 // 上限
    private long limitExtMin;              // 扩展下限
    private long limitExtMax;              // 扩展上限
    
    // 运行时数据
    private String name;
    private String unit;
    private String comment;
    private DataType dataTypeEnum;
    
    public MDF4ChannelBlock() {
        super(MDF4BlockType.CN);
        this.channelType = 0;
        this.syncType = 0;
        this.dataType = 0;
        this.bitOffset = 0;
        this.byteOffset = 0;
        this.bitCount = 32;
        this.flags = 0;
        this.posInvalBit = 0;
        this.precision = 0;
        this.valRangeMin = 0;
        this.valRangeMax = 0;
        this.limitMin = 0;
        this.limitMax = 0;
        this.limitExtMin = 0;
        this.limitExtMax = 0;
    }
    
    /**
     * 从DataChannel创建CN块
     */
    public static MDF4ChannelBlock fromDataChannel(DataChannel channel, int byteOffset, int recordSize) {
        MDF4ChannelBlock cn = new MDF4ChannelBlock();
        cn.name = channel.getName();
        cn.unit = channel.getUnit();
        cn.comment = channel.getDescription();
        cn.dataTypeEnum = channel.getDataType();
        cn.dataType = mapDataType(channel.getDataType());
        cn.bitCount = channel.getDataType().getSizeBytes() * 8;
        cn.byteOffset = byteOffset;
        cn.channelType = channel.isMasterChannel() ? (byte) 1 : (byte) 0;
        
        // 设置范围
        if (channel.getMinValue() != null) {
            cn.valRangeMin = Double.doubleToRawLongBits(channel.getMinValue());
        }
        if (channel.getMaxValue() != null) {
            cn.valRangeMax = Double.doubleToRawLongBits(channel.getMaxValue());
        }
        
        return cn;
    }
    
    /**
     * 映射DataType到MDF4数据类型代码
     */
    private static byte mapDataType(DataType type) {
        switch (type) {
            case UINT8: return 0;
            case UINT16: return 2;
            case UINT32: return 4;
            case UINT64: return 6;
            case INT8: return 1;
            case INT16: return 3;
            case INT32: return 5;
            case INT64: return 7;
            case FLOAT: return 8;
            case DOUBLE: return 9;
            case BOOLEAN: return 1;  // 作为INT8处理
            case STRING: return 10;  // String UTF-8
            case BYTE_ARRAY: return 10;  // Byte array
            default: return 5;  // 默认INT32
        }
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 链接8*8=64字节 + 数据字段
        return 24 + 64 + 1 + 1 + 1 + 1 + 4 + 4 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 8;
    }
    
    @Override
    protected int calculateLinkCount() {
        return 8;
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        file.writeLong(nextCnPosition);
        file.writeLong(ccPosition);
        file.writeLong(cePosition);
        file.writeLong(cdPosition);
        file.writeLong(namePosition);
        file.writeLong(sourcePosition);
        file.writeLong(unitPosition);
        file.writeLong(commentPosition);
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        file.writeByte(channelType);
        file.writeByte(syncType);
        file.writeByte(dataType);
        file.writeByte(bitOffset);
        file.writeInt(byteOffset);
        file.writeInt(bitCount);
        file.writeLong(flags);
        file.writeLong(posInvalBit);
        file.writeLong(precision);
        file.writeLong(valRangeMin);
        file.writeLong(valRangeMax);
        file.writeLong(limitMin);
        file.writeLong(limitMax);
        file.writeLong(limitExtMin);
        file.writeLong(limitExtMax);
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        nextCnPosition = file.readLong();
        ccPosition = file.readLong();
        cePosition = file.readLong();
        cdPosition = file.readLong();
        namePosition = file.readLong();
        sourcePosition = file.readLong();
        unitPosition = file.readLong();
        commentPosition = file.readLong();
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        channelType = file.readByte();
        syncType = file.readByte();
        dataType = file.readByte();
        bitOffset = file.readByte();
        byteOffset = file.readInt();
        bitCount = file.readInt();
        flags = file.readLong();
        posInvalBit = file.readLong();
        precision = file.readLong();
        valRangeMin = file.readLong();
        valRangeMax = file.readLong();
        limitMin = file.readLong();
        limitMax = file.readLong();
        limitExtMin = file.readLong();
        limitExtMax = file.readLong();
    }
    
    // Getters and Setters
    
    public void setNextCnPosition(long position) {
        this.nextCnPosition = position;
    }
    
    public long getNextCnPosition() {
        return nextCnPosition;
    }
    
    public void setCcPosition(long position) {
        this.ccPosition = position;
    }
    
    public long getCcPosition() {
        return ccPosition;
    }
    
    public void setNamePosition(long position) {
        this.namePosition = position;
    }
    
    public long getNamePosition() {
        return namePosition;
    }
    
    public void setSourcePosition(long position) {
        this.sourcePosition = position;
    }
    
    public long getSourcePosition() {
        return sourcePosition;
    }
    
    public void setUnitPosition(long position) {
        this.unitPosition = position;
    }
    
    public long getUnitPosition() {
        return unitPosition;
    }
    
    public void setCommentPosition(long position) {
        this.commentPosition = position;
    }
    
    public long getCommentPosition() {
        return commentPosition;
    }
    
    public void setChannelType(byte channelType) {
        this.channelType = channelType;
    }
    
    public byte getChannelType() {
        return channelType;
    }
    
    public void setByteOffset(int byteOffset) {
        this.byteOffset = byteOffset;
    }
    
    public int getByteOffset() {
        return byteOffset;
    }
    
    public void setBitCount(int bitCount) {
        this.bitCount = bitCount;
    }
    
    public int getBitCount() {
        return bitCount;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public DataType getDataTypeEnum() {
        return dataTypeEnum;
    }
    
    public void setDataTypeEnum(DataType dataTypeEnum) {
        this.dataTypeEnum = dataTypeEnum;
    }
}
