package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * MDF4数据组块（Data Group Block - DG）
 * 包含一个或多个通道组的数据
 */
public class MDF4DataGroupBlock extends MDF4Block {
    
    // 链接
    private long nextDgPosition = 0;       // 下一个数据组块位置
    private long cgFirstPosition = 0;      // 第一个通道组块位置
    private long dataPosition = 0;         // 数据块位置
    private long mdCommentPosition = 0;    // 注释块位置（可选）
    
    // 数据字段
    private byte recIdSize;                // 记录ID大小
    private byte reserved1;
    private byte reserved2;
    private byte reserved3;
    
    public MDF4DataGroupBlock() {
        super(MDF4BlockType.DG);
        this.recIdSize = 0;  // 0表示不使用记录ID
        this.reserved1 = 0;
        this.reserved2 = 0;
        this.reserved3 = 0;
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 链接4*8=32字节 + 数据字段4字节
        return 24 + 32 + 4;
    }
    
    @Override
    protected int calculateLinkCount() {
        return 4;
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        file.writeLong(nextDgPosition);
        file.writeLong(cgFirstPosition);
        file.writeLong(dataPosition);
        file.writeLong(mdCommentPosition);
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        file.writeByte(recIdSize);
        file.writeByte(reserved1);
        file.writeByte(reserved2);
        file.writeByte(reserved3);
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        nextDgPosition = file.readLong();
        cgFirstPosition = file.readLong();
        dataPosition = file.readLong();
        mdCommentPosition = file.readLong();
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        recIdSize = file.readByte();
        reserved1 = file.readByte();
        reserved2 = file.readByte();
        reserved3 = file.readByte();
    }
    
    // Getters and Setters
    
    public void setNextDgPosition(long position) {
        this.nextDgPosition = position;
    }
    
    public long getNextDgPosition() {
        return nextDgPosition;
    }
    
    public void setCgFirstPosition(long position) {
        this.cgFirstPosition = position;
    }
    
    public long getCgFirstPosition() {
        return cgFirstPosition;
    }
    
    public void setDataPosition(long position) {
        this.dataPosition = position;
    }
    
    public long getDataPosition() {
        return dataPosition;
    }
    
    public void setMdCommentPosition(long position) {
        this.mdCommentPosition = position;
    }
    
    public long getMdCommentPosition() {
        return mdCommentPosition;
    }
    
    public void setRecIdSize(byte recIdSize) {
        this.recIdSize = recIdSize;
    }
    
    public byte getRecIdSize() {
        return recIdSize;
    }
}
