package com.dataobserver.storage;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataRecord;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * 数据存储接口
 * 定义数据存储的基本操作，支持多种格式
 */
public interface DataStorage {
    
    /**
     * 打开存储（创建或追加）
     * @param path 文件路径
     * @param mode 打开模式
     */
    void open(Path path, OpenMode mode) throws IOException;
    
    /**
     * 关闭存储
     */
    void close() throws IOException;
    
    /**
     * 写入数据记录
     * @param record 数据记录
     */
    void writeRecord(DataRecord record) throws IOException;
    
    /**
     * 批量写入数据记录
     * @param records 数据记录列表
     */
    void writeRecords(List<DataRecord> records) throws IOException;
    
    /**
     * 注册通道
     * @param channel 数据通道
     */
    void registerChannel(DataChannel channel) throws IOException;
    
    /**
     * 批量注册通道
     * @param channels 数据通道列表
     */
    void registerChannels(List<DataChannel> channels) throws IOException;
    
    /**
     * 获取已注册的所有通道
     */
    List<DataChannel> getRegisteredChannels();
    
    /**
     * 获取存储格式
     */
    StorageFormat getFormat();
    
    /**
     * 获取当前文件大小（字节）
     */
    long getFileSize() throws IOException;
    
    /**
     * 获取已写入的记录数
     */
    long getRecordCount();
    
    /**
     * 刷新缓冲区到磁盘
     */
    void flush() throws IOException;
    
    /**
     * 是否支持并发写入
     */
    boolean supportsConcurrentWrite();
    
    /**
     * 是否支持读取时写入
     */
    boolean supportsReadWhileWriting();
    
    /**
     * 获取存储元数据
     */
    StorageMetadata getMetadata();
    
    /**
     * 设置存储属性
     */
    void setProperty(String key, String value);
    
    /**
     * 获取存储属性
     */
    String getProperty(String key);
    
    /**
     * 打开模式枚举
     */
    enum OpenMode {
        CREATE,      // 创建新文件，如果存在则覆盖
        APPEND,      // 追加到现有文件
        READ_ONLY    // 只读模式
    }
}
