package com.dataobserver.storage;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataRecord;
import com.dataobserver.core.DataType;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * CSV格式存储实现
 * 使用纯Java实现，无需外部依赖
 */
public class CsvStorage implements DataStorage {
    
    private BufferedWriter writer;
    private Path filePath;
    private OpenMode openMode;
    
    // 通道管理
    private final Map<String, DataChannel> registeredChannels;
    private final List<String> channelOrder;
    private final ReentrantReadWriteLock lock;
    
    // 统计
    private final AtomicLong recordCount;
    private final AtomicBoolean isOpen;
    private boolean headerWritten;
    
    // 元数据
    private StorageMetadata metadata;
    private final Map<String, String> properties;
    
    // 配置
    private char delimiter = ',';
    private boolean includeTimestamp = true;
    private String timestampFormat = "nanoseconds";
    
    public CsvStorage() {
        this.registeredChannels = new ConcurrentHashMap<>();
        this.channelOrder = new ArrayList<>();
        this.lock = new ReentrantReadWriteLock();
        this.recordCount = new AtomicLong(0);
        this.isOpen = new AtomicBoolean(false);
        this.properties = new ConcurrentHashMap<>();
        this.metadata = new StorageMetadata();
        this.headerWritten = false;
    }
    
    @Override
    public void open(Path path, OpenMode mode) throws IOException {
        lock.writeLock().lock();
        try {
            if (isOpen.get()) {
                throw new IllegalStateException("Storage is already open");
            }
            
            this.filePath = path;
            this.openMode = mode;
            
            boolean append = mode == OpenMode.APPEND;
            
            // 检查文件是否存在
            File file = path.toFile();
            headerWritten = append && file.exists() && file.length() > 0;
            
            // 打开文件
            writer = new BufferedWriter(new FileWriter(file, append));
            
            isOpen.set(true);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void close() throws IOException {
        lock.writeLock().lock();
        try {
            if (!isOpen.get()) {
                return;
            }
            
            if (writer != null) {
                writer.flush();
                writer.close();
                writer = null;
            }
            
            isOpen.set(false);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void writeRecord(DataRecord record) throws IOException {
        ensureOpen();
        
        lock.readLock().lock();
        try {
            writeHeaderIfNeeded();
            
            StringBuilder line = new StringBuilder();
            
            // 时间戳
            if (includeTimestamp) {
                line.append(record.getTimestamp());
            }
            
            // 通道值
            for (String channelName : channelOrder) {
                if (line.length() > 0) {
                    line.append(delimiter);
                }
                
                Object value = record.getValue(channelName);
                if (value != null) {
                    line.append(formatValue(value, record.getType(channelName)));
                }
            }
            
            writer.write(line.toString());
            writer.newLine();
            
            recordCount.incrementAndGet();
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void writeRecords(List<DataRecord> records) throws IOException {
        ensureOpen();
        
        lock.readLock().lock();
        try {
            writeHeaderIfNeeded();
            
            for (DataRecord record : records) {
                StringBuilder line = new StringBuilder();
                
                // 时间戳
                if (includeTimestamp) {
                    line.append(record.getTimestamp());
                }
                
                // 通道值
                for (String channelName : channelOrder) {
                    if (line.length() > 0) {
                        line.append(delimiter);
                    }
                    
                    Object value = record.getValue(channelName);
                    if (value != null) {
                        line.append(formatValue(value, record.getType(channelName)));
                    }
                }
                
                writer.write(line.toString());
                writer.newLine();
            }
            
            recordCount.addAndGet(records.size());
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 格式化值
     */
    private String formatValue(Object value, DataType type) {
        if (value == null) {
            return "";
        }
        
        switch (type) {
            case FLOAT:
                return String.format("%.6f", ((Number) value).floatValue());
            case DOUBLE:
                return String.format("%.9f", ((Number) value).doubleValue());
            case STRING:
                String str = (String) value;
                // 如果包含分隔符或引号，需要转义
                if (str.contains(String.valueOf(delimiter)) || str.contains("\"")) {
                    str = str.replace("\"", "\"\"");
                    return "\"" + str + "\"";
                }
                return str;
            default:
                return value.toString();
        }
    }
    
    /**
     * 写入CSV头部
     */
    private void writeHeaderIfNeeded() throws IOException {
        if (headerWritten) {
            return;
        }
        
        StringBuilder header = new StringBuilder();
        
        if (includeTimestamp) {
            header.append("timestamp");
        }
        
        for (String channelName : channelOrder) {
            if (header.length() > 0) {
                header.append(delimiter);
            }
            header.append(escapeHeader(channelName));
        }
        
        writer.write(header.toString());
        writer.newLine();
        headerWritten = true;
    }
    
    /**
     * 转义头部字段
     */
    private String escapeHeader(String header) {
        if (header.contains(String.valueOf(delimiter)) || header.contains("\"")) {
            header = header.replace("\"", "\"\"");
            return "\"" + header + "\"";
        }
        return header;
    }
    
    @Override
    public void registerChannel(DataChannel channel) throws IOException {
        ensureOpen();
        
        lock.writeLock().lock();
        try {
            if (registeredChannels.containsKey(channel.getName())) {
                return;
            }
            
            registeredChannels.put(channel.getName(), channel);
            channelOrder.add(channel.getName());
            
            // 如果头部已写入，需要重新写入（CSV格式限制）
            if (headerWritten) {
                // CSV不支持动态添加列，这里我们只是记录警告
                System.err.println("Warning: Adding channel after header written: " + channel.getName());
            }
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void registerChannels(List<DataChannel> channels) throws IOException {
        for (DataChannel channel : channels) {
            registerChannel(channel);
        }
    }
    
    @Override
    public List<DataChannel> getRegisteredChannels() {
        lock.readLock().lock();
        try {
            return List.copyOf(registeredChannels.values());
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void flush() throws IOException {
        ensureOpen();
        
        lock.readLock().lock();
        try {
            if (writer != null) {
                writer.flush();
            }
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.CSV;
    }
    
    @Override
    public long getFileSize() throws IOException {
        if (filePath == null) {
            return 0;
        }
        return java.nio.file.Files.size(filePath);
    }
    
    @Override
    public long getRecordCount() {
        return recordCount.get();
    }
    
    @Override
    public boolean supportsConcurrentWrite() {
        return false;  // CSV不支持并发写入
    }
    
    @Override
    public boolean supportsReadWhileWriting() {
        return true;
    }
    
    @Override
    public StorageMetadata getMetadata() {
        return metadata;
    }
    
    @Override
    public void setProperty(String key, String value) {
        properties.put(key, value);
    }
    
    @Override
    public String getProperty(String key) {
        return properties.get(key);
    }
    
    // 配置方法
    
    public void setDelimiter(char delimiter) {
        this.delimiter = delimiter;
    }
    
    public void setIncludeTimestamp(boolean includeTimestamp) {
        this.includeTimestamp = includeTimestamp;
    }
    
    private void ensureOpen() throws IOException {
        if (!isOpen.get()) {
            throw new IOException("Storage is not open");
        }
    }
}
