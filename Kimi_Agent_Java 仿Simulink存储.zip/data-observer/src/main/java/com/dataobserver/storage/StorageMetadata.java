package com.dataobserver.storage;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * 存储元数据
 */
public class StorageMetadata {
    private String version;
    private String creator;
    private String description;
    private Instant creationTime;
    private Instant modificationTime;
    private String project;
    private String subject;
    private final Map<String, String> customProperties;
    
    public StorageMetadata() {
        this.customProperties = new HashMap<>();
        this.creationTime = Instant.now();
        this.modificationTime = Instant.now();
    }
    
    public String getVersion() {
        return version;
    }
    
    public void setVersion(String version) {
        this.version = version;
    }
    
    public String getCreator() {
        return creator;
    }
    
    public void setCreator(String creator) {
        this.creator = creator;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Instant getCreationTime() {
        return creationTime;
    }
    
    public void setCreationTime(Instant creationTime) {
        this.creationTime = creationTime;
    }
    
    public Instant getModificationTime() {
        return modificationTime;
    }
    
    public void setModificationTime(Instant modificationTime) {
        this.modificationTime = modificationTime;
    }
    
    public String getProject() {
        return project;
    }
    
    public void setProject(String project) {
        this.project = project;
    }
    
    public String getSubject() {
        return subject;
    }
    
    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    public void setCustomProperty(String key, String value) {
        customProperties.put(key, value);
    }
    
    public String getCustomProperty(String key) {
        return customProperties.get(key);
    }
    
    public Map<String, String> getCustomProperties() {
        return new HashMap<>(customProperties);
    }
}
