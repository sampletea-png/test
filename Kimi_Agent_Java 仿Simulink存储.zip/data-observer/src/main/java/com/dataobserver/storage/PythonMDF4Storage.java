package com.dataobserver.storage;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataRecord;
import com.dataobserver.python.PythonProcessManager;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 基于Python asammdf库的MDF4存储实现
 * 通过进程间通信调用Python进行实际的文件操作
 */
public class PythonMDF4Storage implements DataStorage {
    
    private static final Logger LOGGER = Logger.getLogger(PythonMDF4Storage.class.getName());
    
    private PythonProcessManager pythonManager;
    private Path filePath;
    private OpenMode openMode;
    
    // 通道管理
    private final Map<String, DataChannel> registeredChannels;
    private final ReentrantReadWriteLock lock;
    
    // 统计
    private final AtomicLong recordCount;
    private final AtomicBoolean isOpen;
    
    // 元数据
    private StorageMetadata metadata;
    private final Map<String, String> properties;
    
    public PythonMDF4Storage() {
        this.registeredChannels = new ConcurrentHashMap<>();
        this.lock = new ReentrantReadWriteLock();
        this.recordCount = new AtomicLong(0);
        this.isOpen = new AtomicBoolean(false);
        this.properties = new ConcurrentHashMap<>();
        this.metadata = new StorageMetadata();
    }
    
    @Override
    public void open(Path path, OpenMode mode) throws IOException {
        lock.writeLock().lock();
        try {
            if (isOpen.get()) {
                throw new IllegalStateException("Storage is already open");
            }
            
            this.filePath = path;
            this.openMode = mode;
            
            // 检查Python环境
            if (!PythonProcessManager.checkPythonEnvironment()) {
                throw new IOException("Python environment not found. Please install Python 3.");
            }
            
            if (!PythonProcessManager.checkAsammdf()) {
                LOGGER.warning("asammdf not installed. Installing...");
                installAsammdf();
            }
            
            // 启动Python进程
            pythonManager = new PythonProcessManager();
            pythonManager.start();
            
            // 打开文件
            String modeStr = mode == OpenMode.APPEND ? "append" : "create";
            JsonNode response = pythonManager.openFile(path.toString(), modeStr);
            
            if (!"success".equals(response.get("status").asText())) {
                throw new IOException("Failed to open file: " + 
                    response.get("message").asText());
            }
            
            LOGGER.info("Opened MDF4 file: " + path + " (version: " + 
                response.get("version").asText() + ")");
            
            isOpen.set(true);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 安装asammdf
     */
    private void installAsammdf() throws IOException {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                "pip3", "install", "asammdf", "numpy"
            );
            Process process = pb.inheritIO().start();
            boolean success = process.waitFor(60, java.util.concurrent.TimeUnit.SECONDS);
            if (!success || process.exitValue() != 0) {
                throw new IOException("Failed to install asammdf");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while installing asammdf", e);
        }
    }
    
    @Override
    public void close() throws IOException {
        lock.writeLock().lock();
        try {
            if (!isOpen.get()) {
                return;
            }
            
            if (pythonManager != null) {
                try {
                    JsonNode response = pythonManager.closeFile();
                    if (!"success".equals(response.get("status").asText())) {
                        LOGGER.warning("Error closing file: " + response.get("message").asText());
                    }
                } catch (Exception e) {
                    LOGGER.log(Level.WARNING, "Error during close", e);
                } finally {
                    try {
                        pythonManager.close();
                    } catch (Exception e) {
                        LOGGER.log(Level.WARNING, "Error closing Python manager", e);
                    }
                }
            }
            
            isOpen.set(false);
            LOGGER.info("Storage closed");
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void writeRecord(DataRecord record) throws IOException {
        ensureOpen();
        
        lock.readLock().lock();
        try {
            JsonNode response = pythonManager.writeRecord(record);
            
            if (!"success".equals(response.get("status").asText())) {
                throw new IOException("Write failed: " + response.get("message").asText());
            }
            
            recordCount.incrementAndGet();
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void writeRecords(List<DataRecord> records) throws IOException {
        ensureOpen();
        
        if (records.isEmpty()) {
            return;
        }
        
        lock.readLock().lock();
        try {
            JsonNode response = pythonManager.writeRecords(records);
            
            if (!"success".equals(response.get("status").asText())) {
                throw new IOException("Batch write failed: " + response.get("message").asText());
            }
            
            recordCount.addAndGet(records.size());
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void registerChannel(DataChannel channel) throws IOException {
        ensureOpen();
        
        lock.writeLock().lock();
        try {
            if (registeredChannels.containsKey(channel.getName())) {
                return;
            }
            
            JsonNode response = pythonManager.registerChannel(channel);
            
            if (!"success".equals(response.get("status").asText())) {
                throw new IOException("Failed to register channel: " + 
                    response.get("message").asText());
            }
            
            registeredChannels.put(channel.getName(), channel);
            LOGGER.fine("Registered channel: " + channel.getName());
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void registerChannels(List<DataChannel> channels) throws IOException {
        for (DataChannel channel : channels) {
            registerChannel(channel);
        }
    }
    
    @Override
    public List<DataChannel> getRegisteredChannels() {
        lock.readLock().lock();
        try {
            return List.copyOf(registeredChannels.values());
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void flush() throws IOException {
        ensureOpen();
        
        lock.readLock().lock();
        try {
            JsonNode response = pythonManager.flush();
            
            if (!"success".equals(response.get("status").asText())) {
                throw new IOException("Flush failed: " + response.get("message").asText());
            }
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.MDF4;
    }
    
    @Override
    public long getFileSize() throws IOException {
        if (filePath == null) {
            return 0;
        }
        return java.nio.file.Files.size(filePath);
    }
    
    @Override
    public long getRecordCount() {
        return recordCount.get();
    }
    
    @Override
    public boolean supportsConcurrentWrite() {
        return true;
    }
    
    @Override
    public boolean supportsReadWhileWriting() {
        return true;
    }
    
    @Override
    public StorageMetadata getMetadata() {
        return metadata;
    }
    
    @Override
    public void setProperty(String key, String value) {
        properties.put(key, value);
    }
    
    @Override
    public String getProperty(String key) {
        return properties.get(key);
    }
    
    /**
     * 获取文件信息
     */
    public JsonNode getFileInfo() throws IOException {
        ensureOpen();
        return pythonManager.getInfo();
    }
    
    private void ensureOpen() throws IOException {
        if (!isOpen.get()) {
            throw new IOException("Storage is not open");
        }
    }
}
