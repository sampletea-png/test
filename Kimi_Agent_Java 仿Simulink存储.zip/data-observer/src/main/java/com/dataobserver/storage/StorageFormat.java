package com.dataobserver.storage;

/**
 * 存储格式枚举
 */
public enum StorageFormat {
    MDF4("mf4", "ASAM MDF4 Format"),
    CSV("csv", "Comma Separated Values"),
    HDF5("h5", "Hierarchical Data Format 5"),
    PARQUET("parquet", "Apache Parquet"),
    CUSTOM("custom", "Custom Format");
    
    private final String extension;
    private final String description;
    
    StorageFormat(String extension, String description) {
        this.extension = extension;
        this.description = description;
    }
    
    public String getExtension() {
        return extension;
    }
    
    public String getDescription() {
        return description;
    }
    
    public static StorageFormat fromExtension(String ext) {
        for (StorageFormat format : values()) {
            if (format.extension.equalsIgnoreCase(ext)) {
                return format;
            }
        }
        return CUSTOM;
    }
}
