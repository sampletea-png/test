package com.dataobserver.storage;

import com.dataobserver.mdf4.MDF4Storage;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 存储工厂类
 * 用于创建和管理不同格式的存储引擎
 */
public class StorageFactory {
    
    private static final Map<StorageFormat, StorageProvider> providers = new ConcurrentHashMap<>();
    
    static {
        // 注册原生Java MDF4存储（不依赖Python）
        registerProvider(StorageFormat.MDF4, MDF4Storage::new);
        
        // 注册基于Python asammdf的MDF4存储
        registerProvider(StorageFormat.MDF4, "python", PythonMDF4Storage::new);
        
        // 注册CSV存储
        registerProvider(StorageFormat.CSV, CsvStorage::new);
    }
    
    /**
     * 带名称的存储提供者注册
     */
    public static void registerProvider(StorageFormat format, String name, StorageProvider provider) {
        providers.put(format, provider);
    }
    
    /**
     * 注册存储提供者
     */
    public static void registerProvider(StorageFormat format, StorageProvider provider) {
        providers.put(format, provider);
    }
    
    /**
     * 创建存储实例
     */
    public static DataStorage createStorage(StorageFormat format) {
        StorageProvider provider = providers.get(format);
        if (provider == null) {
            throw new IllegalArgumentException("No provider registered for format: " + format);
        }
        return provider.create();
    }
    
    /**
     * 检查是否支持指定格式
     */
    public static boolean isSupported(StorageFormat format) {
        return providers.containsKey(format);
    }
    
    /**
     * 获取所有支持的格式
     */
    public static StorageFormat[] getSupportedFormats() {
        return providers.keySet().toArray(new StorageFormat[0]);
    }
    
    /**
     * 存储提供者接口
     */
    @FunctionalInterface
    public interface StorageProvider {
        DataStorage create();
    }
}
