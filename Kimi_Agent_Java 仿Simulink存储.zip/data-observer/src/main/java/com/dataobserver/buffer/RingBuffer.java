package com.dataobserver.buffer;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;

/**
 * 无锁环形缓冲区实现
 * 基于Disruptor的设计思想，支持高并发读写
 * @param <T> 元素类型
 */
public class RingBuffer<T> {
    
    private final Object[] buffer;
    private final int capacity;
    private final int mask;
    
    // 序列号，使用原子long保证可见性
    private final AtomicLong writeSequence = new AtomicLong(-1);
    private final AtomicLong readSequence = new AtomicLong(-1);
    
    // 批处理大小
    private final int batchSize;
    
    // 等待策略
    private final WaitStrategy waitStrategy;
    
    public RingBuffer(int capacity) {
        this(capacity, 64, WaitStrategy.YIELDING);
    }
    
    public RingBuffer(int capacity, int batchSize, WaitStrategy waitStrategy) {
        // 容量必须是2的幂次方，以便使用位运算优化
        this.capacity = nextPowerOfTwo(capacity);
        this.mask = this.capacity - 1;
        this.buffer = new Object[this.capacity];
        this.batchSize = batchSize;
        this.waitStrategy = waitStrategy;
    }
    
    /**
     * 获取下一个2的幂次方
     */
    private static int nextPowerOfTwo(int value) {
        return 1 << (32 - Integer.numberOfLeadingZeros(value - 1));
    }
    
    /**
     * 写入单个元素
     */
    public boolean offer(T element) {
        if (element == null) {
            throw new NullPointerException("Element cannot be null");
        }
        
        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + 1;
        
        // 检查是否有空间
        long wrapPoint = nextWrite - capacity;
        long cachedRead = readSequence.get();
        
        if (wrapPoint > cachedRead) {
            // 可能需要等待，重新检查
            if (wrapPoint > readSequence.get()) {
                return false;  // 缓冲区满
            }
        }
        
        // 尝试CAS操作
        if (!writeSequence.compareAndSet(currentWrite, nextWrite)) {
            return false;  // CAS失败
        }
        
        // 写入数据
        buffer[(int) (nextWrite & mask)] = element;
        return true;
    }
    
    /**
     * 阻塞式写入
     */
    public void put(T element) throws InterruptedException {
        while (!offer(element)) {
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            waitStrategy.waitForWrite(this);
        }
    }
    
    /**
     * 批量写入
     */
    @SafeVarargs
    public final int offerBatch(T... elements) {
        if (elements == null || elements.length == 0) {
            return 0;
        }
        
        int count = Math.min(elements.length, batchSize);
        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + count;
        
        // 检查空间
        long wrapPoint = nextWrite - capacity;
        if (wrapPoint > readSequence.get()) {
            return 0;  // 空间不足
        }
        
        // CAS操作
        if (!writeSequence.compareAndSet(currentWrite, nextWrite)) {
            return 0;
        }
        
        // 批量写入
        for (int i = 0; i < count; i++) {
            buffer[(int) ((currentWrite + 1 + i) & mask)] = elements[i];
        }
        
        return count;
    }
    
    /**
     * 读取单个元素
     */
    @SuppressWarnings("unchecked")
    public T poll() {
        long currentRead = readSequence.get();
        long nextRead = currentRead + 1;
        
        // 检查是否有数据可读
        if (nextRead > writeSequence.get()) {
            return null;  // 缓冲区空
        }
        
        // 尝试CAS操作
        if (!readSequence.compareAndSet(currentRead, nextRead)) {
            return null;  // CAS失败
        }
        
        // 读取数据
        int index = (int) (nextRead & mask);
        T element = (T) buffer[index];
        buffer[index] = null;  // 帮助GC
        return element;
    }
    
    /**
     * 批量读取
     */
    @SuppressWarnings("unchecked")
    public int pollBatch(T[] container) {
        long currentRead = readSequence.get();
        long available = writeSequence.get() - currentRead;
        
        if (available <= 0) {
            return 0;
        }
        
        int count = (int) Math.min(available, Math.min(container.length, batchSize));
        long nextRead = currentRead + count;
        
        // CAS操作
        if (!readSequence.compareAndSet(currentRead, nextRead)) {
            return 0;
        }
        
        // 批量读取
        for (int i = 0; i < count; i++) {
            int index = (int) ((currentRead + 1 + i) & mask);
            container[i] = (T) buffer[index];
            buffer[index] = null;
        }
        
        return count;
    }
    
    /**
     * 阻塞式读取
     */
    public T take() throws InterruptedException {
        T element;
        while ((element = poll()) == null) {
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            waitStrategy.waitForRead(this);
        }
        return element;
    }
    
    /**
     * 获取当前大小
     */
    public int size() {
        return (int) (writeSequence.get() - readSequence.get());
    }
    
    /**
     * 检查是否为空
     */
    public boolean isEmpty() {
        return writeSequence.get() <= readSequence.get();
    }
    
    /**
     * 检查是否已满
     */
    public boolean isFull() {
        return size() >= capacity;
    }
    
    /**
     * 获取容量
     */
    public int getCapacity() {
        return capacity;
    }
    
    /**
     * 获取剩余空间
     */
    public int remainingCapacity() {
        return capacity - size();
    }
    
    /**
     * 清空缓冲区
     */
    public void clear() {
        long currentRead = readSequence.get();
        long currentWrite = writeSequence.get();
        
        // 清空所有数据
        for (long i = currentRead + 1; i <= currentWrite; i++) {
            buffer[(int) (i & mask)] = null;
        }
        
        readSequence.set(currentWrite);
    }
    
    /**
     * 等待策略枚举
     */
    public enum WaitStrategy {
        SPIN {
            @Override
            void waitForWrite(RingBuffer<?> buffer) {
                // 自旋等待
            }
            @Override
            void waitForRead(RingBuffer<?> buffer) {
                // 自旋等待
            }
        },
        YIELDING {
            @Override
            void waitForWrite(RingBuffer<?> buffer) {
                Thread.yield();
            }
            @Override
            void waitForRead(RingBuffer<?> buffer) {
                Thread.yield();
            }
        },
        PARKING {
            @Override
            void waitForWrite(RingBuffer<?> buffer) {
                LockSupport.parkNanos(1000);
            }
            @Override
            void waitForRead(RingBuffer<?> buffer) {
                LockSupport.parkNanos(1000);
            }
        };
        
        abstract void waitForWrite(RingBuffer<?> buffer);
        abstract void waitForRead(RingBuffer<?> buffer);
    }
}
