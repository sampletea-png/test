package com.dataobserver.example;

import com.dataobserver.core.*;
import com.dataobserver.storage.*;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 使用Python第三方库的存储示例
 */
public class PythonStorageExample {
    
    public static void main(String[] args) throws Exception {
        System.out.println("=== Python Storage Example ===\n");
        
        // 示例1: 使用Python asammdf存储MDF4
        pythonMdf4Example();
        
        // 示例2: 使用CSV存储
        // csvExample();
    }
    
    /**
     * 使用Python asammdf库存储MDF4
     */
    public static void pythonMdf4Example() throws Exception {
        System.out.println("--- Python asammdf MDF4 Example ---");
        System.out.println("This example uses Python's asammdf library for MDF4 storage.");
        System.out.println();
        
        // 检查Python环境
        if (!PythonProcessManager.checkPythonEnvironment()) {
            System.err.println("Python 3 not found! Please install Python 3.");
            System.err.println("On Ubuntu/Debian: sudo apt-get install python3 python3-pip");
            System.err.println("Then install asammdf: pip3 install asammdf numpy");
            return;
        }
        
        System.out.println("Python environment found.");
        
        if (!PythonProcessManager.checkAsammdf()) {
            System.out.println("asammdf not found. Please install it:");
            System.out.println("  pip3 install asammdf numpy");
            return;
        }
        
        System.out.println("asammdf found.");
        System.out.println();
        
        // 创建观察器
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        // 使用Python MDF4存储
        PythonMDF4Storage storage = new PythonMDF4Storage();
        storage.setProperty("project", "PythonTest");
        storage.setProperty("subject", "asammdf");
        
        Path storagePath = Paths.get("python_data.mf4");
        storage.open(storagePath, DataStorage.OpenMode.CREATE);
        
        System.out.println("Created storage: " + storagePath.toAbsolutePath());
        
        // 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource("source1", "Test Source", 100.0);
        source.addSineWaveChannel("sine_wave", 10.0, 1.0, 0.0);
        source.addNoiseChannel("noise", 2.0, 0.0);
        
        // 手动注册通道到存储
        for (DataChannel channel : source.getChannels()) {
            storage.registerChannel(channel);
        }
        
        // 添加数据源（不自动注册通道，因为我们已经手动注册了）
        observer.addDataSource(source);
        
        System.out.println("Starting recording...");
        
        // 记录一段时间
        long startTime = System.currentTimeMillis();
        int recordCount = 0;
        
        while (System.currentTimeMillis() - startTime < 3000) {
            // 获取统计信息
            DataObserver.Statistics stats = observer.getStatistics();
            System.out.println("  " + stats);
            
            Thread.sleep(1000);
            recordCount = (int) stats.getTotalRecords();
        }
        
        // 停止
        observer.stopRecording();
        
        // 刷新存储
        storage.flush();
        
        // 获取文件信息
        System.out.println("\nFile info:");
        System.out.println("  " + storage.getFileInfo());
        
        // 关闭
        storage.close();
        observer.close();
        
        System.out.println("\nData saved to: " + storagePath.toAbsolutePath());
        System.out.println("File size: " + storagePath.toFile().length() + " bytes\n");
    }
    
    /**
     * CSV存储示例
     */
    public static void csvExample() throws Exception {
        System.out.println("--- CSV Storage Example ---");
        
        // 创建CSV存储
        CsvStorage storage = new CsvStorage();
        
        Path storagePath = Paths.get("data.csv");
        storage.open(storagePath, DataStorage.OpenMode.CREATE);
        
        System.out.println("Created CSV storage: " + storagePath.toAbsolutePath());
        
        // 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource("source1", "Test Source", 10.0);
        source.addSineWaveChannel("sine", 10.0, 1.0, 0.0);
        source.addRampChannel("ramp", 5.0, 0.0);
        
        // 注册通道
        for (DataChannel channel : source.getChannels()) {
            storage.registerChannel(channel);
        }
        
        // 创建观察器并设置存储
        DataObserver observer = new DataObserver();
        observer.initialize();
        observer.addDataSource(source);
        
        // 手动写入一些记录（CSV不支持通过DataObserver自动写入）
        System.out.println("Writing records...");
        
        for (int i = 0; i < 100; i++) {
            DataRecord record = new DataRecord(System.nanoTime());
            record.addValue("sine", Math.sin(i * 0.1), DataType.DOUBLE);
            record.addValue("ramp", i * 0.5, DataType.DOUBLE);
            storage.writeRecord(record);
        }
        
        storage.flush();
        storage.close();
        
        System.out.println("Wrote 100 records");
        System.out.println("Data saved to: " + storagePath.toAbsolutePath());
        System.out.println("File size: " + storagePath.toFile().length() + " bytes\n");
        
        observer.close();
    }
}
