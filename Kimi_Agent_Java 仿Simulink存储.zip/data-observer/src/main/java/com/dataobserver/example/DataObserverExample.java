package com.dataobserver.example;

import com.dataobserver.core.*;
import com.dataobserver.storage.StorageFormat;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

/**
 * DataObserver使用示例
 */
public class DataObserverExample {
    
    public static void main(String[] args) throws Exception {
        System.out.println("=== DataObserver Example ===\n");
        
        // 示例1: 基本使用
        basicUsage();
        
        // 示例2: 多数据源
        // multipleDataSources();
        
        // 示例3: 动态添加/移除数据源
        // dynamicSources();
    }
    
    /**
     * 基本使用示例
     */
    public static void basicUsage() throws Exception {
        System.out.println("--- Basic Usage Example ---");
        
        // 1. 创建配置
        DataObserver.Config config = new DataObserver.Config()
            .setBufferSize(10000)
            .setBatchSize(50)
            .setWorkerThreads(2)
            .setProject("TestProject")
            .setSubject("DataCollection")
            .setDebugMode(true);
        
        // 2. 创建观察器
        DataObserver observer = new DataObserver(config);
        
        // 3. 添加监听器
        observer.addListener(new DataObserver.ObserverListener() {
            @Override
            public void onInitialized() {
                System.out.println("[Listener] Observer initialized");
            }
            
            @Override
            public void onStorageCreated(java.nio.file.Path path, StorageFormat format) {
                System.out.println("[Listener] Storage created: " + path + " (" + format + ")");
            }
            
            @Override
            public void onSourceAdded(DataSource source) {
                System.out.println("[Listener] Source added: " + source.getName());
            }
            
            @Override
            public void onRecordingStarted() {
                System.out.println("[Listener] Recording started");
            }
            
            @Override
            public void onRecordingStopped() {
                System.out.println("[Listener] Recording stopped");
            }
            
            @Override
            public void onClosed() {
                System.out.println("[Listener] Observer closed");
            }
        });
        
        // 4. 初始化
        observer.initialize();
        
        // 5. 创建存储
        Path storagePath = Paths.get("test_data.mf4");
        observer.createStorage(storagePath, StorageFormat.MDF4);
        
        // 6. 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource("source1", "Test Source", 100.0);
        
        // 添加通道
        source.addSineWaveChannel("sine_wave", 10.0, 1.0, 0.0);  // 幅值10, 频率1Hz
        source.addNoiseChannel("noise", 2.0, 0.0);  // 噪声幅值2
        source.addRampChannel("ramp", 5.0, 0.0);  // 斜率5
        
        // 7. 添加数据源
        observer.addDataSource(source);
        
        // 8. 开始记录
        observer.startRecording();
        
        // 9. 记录一段时间
        System.out.println("Recording for 5 seconds...");
        for (int i = 0; i < 5; i++) {
            Thread.sleep(1000);
            DataObserver.Statistics stats = observer.getStatistics();
            System.out.println("  " + stats);
        }
        
        // 10. 停止记录
        observer.stopRecording();
        
        // 11. 关闭
        observer.close();
        
        System.out.println("\nData saved to: " + storagePath.toAbsolutePath());
        System.out.println("File size: " + storagePath.toFile().length() + " bytes\n");
    }
    
    /**
     * 多数据源示例
     */
    public static void multipleDataSources() throws Exception {
        System.out.println("--- Multiple Data Sources Example ---");
        
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        Path storagePath = Paths.get("multi_source_data.mf4");
        observer.createStorage(storagePath, StorageFormat.MDF4);
        
        // 创建多个数据源
        SimulatedDataSource source1 = new SimulatedDataSource("sensor1", "Temperature Sensor", 10.0);
        source1.addSineWaveChannel("temperature", 50.0, 0.1, 25.0);  // 25±50°C
        source1.addNoiseChannel("temp_noise", 2.0, 0.0);
        
        SimulatedDataSource source2 = new SimulatedDataSource("sensor2", "Pressure Sensor", 50.0);
        source2.addRampChannel("pressure", 100.0, 0);  // 压力递增
        
        SimulatedDataSource source3 = new SimulatedDataSource("controller", "PID Controller", 100.0);
        source3.addStepChannel("setpoint", 0.0, 100.0, 2.0);  // 2秒后阶跃
        source3.addSineWaveChannel("output", 50.0, 0.5, 50.0);
        
        // 添加所有数据源
        observer.addDataSource(source1);
        observer.addDataSource(source2);
        observer.addDataSource(source3);
        
        // 开始记录
        observer.startRecording();
        
        System.out.println("Recording from 3 sources for 5 seconds...");
        Thread.sleep(5000);
        
        observer.stopRecording();
        observer.close();
        
        System.out.println("Data saved to: " + storagePath.toAbsolutePath() + "\n");
    }
    
    /**
     * 动态添加/移除数据源示例
     */
    public static void dynamicSources() throws Exception {
        System.out.println("--- Dynamic Sources Example ---");
        
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        Path storagePath = Paths.get("dynamic_data.mf4");
        observer.createStorage(storagePath, StorageFormat.MDF4);
        
        // 添加初始数据源
        SimulatedDataSource source1 = new SimulatedDataSource("source1", "Initial Source", 50.0);
        source1.addSineWaveChannel("signal1", 10.0, 1.0, 0.0);
        observer.addDataSource(source1);
        
        observer.startRecording();
        
        System.out.println("Recording with 1 source...");
        Thread.sleep(2000);
        
        // 动态添加数据源
        System.out.println("Adding second source...");
        SimulatedDataSource source2 = new SimulatedDataSource("source2", "Dynamic Source", 30.0);
        source2.addSineWaveChannel("signal2", 5.0, 2.0, 0.0);
        source2.addNoiseChannel("noise", 1.0, 0.0);
        observer.addDataSource(source2);
        
        Thread.sleep(2000);
        
        // 移除第一个数据源
        System.out.println("Removing first source...");
        observer.removeDataSource("source1");
        
        Thread.sleep(2000);
        
        // 再添加一个新数据源
        System.out.println("Adding third source...");
        SimulatedDataSource source3 = new SimulatedDataSource("source3", "Final Source", 20.0);
        source3.addRampChannel("ramp", 10.0, 0.0);
        observer.addDataSource(source3);
        
        Thread.sleep(2000);
        
        observer.stopRecording();
        
        DataObserver.Statistics stats = observer.getStatistics();
        System.out.println("Final statistics: " + stats);
        
        observer.close();
        
        System.out.println("Data saved to: " + storagePath.toAbsolutePath() + "\n");
    }
}
