package com.dataobserver.core;

import com.dataobserver.buffer.RingBuffer;
import com.dataobserver.mdf4.MDF4Storage;
import com.dataobserver.storage.DataStorage;
import com.dataobserver.storage.StorageFormat;
import com.dataobserver.storage.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 数据观察器主类
 * 仿照Simulink Data Inspector实现
 * 支持动态添加/取消观察的数据源，并发读写，大文件存储
 */
public class DataObserver implements AutoCloseable {
    
    // 配置参数
    private final Config config;
    
    // 存储引擎
    private DataStorage storage;
    
    // 数据源管理
    private final Map<String, DataSource> dataSources;
    private final Map<String, DataSourceInfo> sourceInfoMap;
    private final ReentrantReadWriteLock sourcesLock;
    
    // 数据缓冲区
    private RingBuffer<DataRecord> ringBuffer;
    
    // 工作线程
    private ExecutorService executorService;
    private ScheduledExecutorService scheduledExecutor;
    
    // 状态控制
    private final AtomicBoolean isRunning;
    private final AtomicBoolean isRecording;
    private final AtomicLong recordCounter;
    
    // 数据写入任务
    private Future<?> writerTask;
    
    // 监听器
    private final Set<ObserverListener> listeners;
    
    // 采样控制
    private final Map<String, SampleRateController> sampleRateControllers;
    
    public DataObserver() {
        this(new Config());
    }
    
    public DataObserver(Config config) {
        this.config = config;
        this.dataSources = new ConcurrentHashMap<>();
        this.sourceInfoMap = new ConcurrentHashMap<>();
        this.sourcesLock = new ReentrantReadWriteLock();
        this.isRunning = new AtomicBoolean(false);
        this.isRecording = new AtomicBoolean(false);
        this.recordCounter = new AtomicLong(0);
        this.listeners = ConcurrentHashMap.newKeySet();
        this.sampleRateControllers = new ConcurrentHashMap<>();
    }
    
    /**
     * 初始化观察器
     */
    public void initialize() {
        // 创建环形缓冲区
        this.ringBuffer = new RingBuffer<>(config.getBufferSize(), 
                                           config.getBatchSize(), 
                                           RingBuffer.WaitStrategy.YIELDING);
        
        // 创建线程池
        this.executorService = Executors.newFixedThreadPool(
            config.getWorkerThreads(),
            new ThreadFactory() {
                private int counter = 0;
                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "DataObserver-Worker-" + (++counter));
                    t.setDaemon(true);
                    return t;
                }
            }
        );
        
        this.scheduledExecutor = Executors.newScheduledThreadPool(2, r -> {
            Thread t = new Thread(r, "DataObserver-Scheduler");
            t.setDaemon(true);
            return t;
        });
        
        isRunning.set(true);
        
        // 启动数据写入线程
        startWriterTask();
        
        // 启动缓冲区监控
        startBufferMonitor();
        
        notifyInitialized();
    }
    
    /**
     * 创建存储
     */
    public void createStorage(Path path, StorageFormat format) throws IOException {
        createStorage(path, format, DataStorage.OpenMode.CREATE);
    }
    
    /**
     * 创建存储（指定打开模式）
     */
    public void createStorage(Path path, StorageFormat format, DataStorage.OpenMode mode) throws IOException {
        // 根据格式创建存储引擎
        switch (format) {
            case MDF4:
                storage = new MDF4Storage();
                break;
            default:
                throw new UnsupportedOperationException("Storage format not supported: " + format);
        }
        
        // 设置元数据
        StorageMetadata metadata = new StorageMetadata();
        metadata.setCreator(config.getCreator());
        metadata.setProject(config.getProject());
        metadata.setSubject(config.getSubject());
        metadata.setDescription(config.getDescription());
        
        // 打开存储
        storage.open(path, mode);
        
        notifyStorageCreated(path, format);
    }
    
    /**
     * 添加数据源（开始观察）
     */
    public void addDataSource(DataSource source) {
        sourcesLock.writeLock().lock();
        try {
            if (dataSources.containsKey(source.getId())) {
                throw new IllegalArgumentException("DataSource already exists: " + source.getId());
            }
            
            // 创建数据源信息
            DataSourceInfo info = new DataSourceInfo(source);
            sourceInfoMap.put(source.getId(), info);
            dataSources.put(source.getId(), source);
            
            // 注册通道到存储
            if (storage != null && isRecording.get()) {
                try {
                    for (DataChannel channel : source.getChannels()) {
                        storage.registerChannel(channel);
                    }
                } catch (IOException e) {
                    notifyError("Failed to register channels for source: " + source.getId(), e);
                }
            }
            
            // 设置数据回调
            source.setDataCallback(record -> {
                if (isRecording.get()) {
                    onDataReceived(source, record);
                }
            });
            
            // 启动数据源
            if (isRunning.get()) {
                source.start();
            }
            
            notifySourceAdded(source);
            
        } finally {
            sourcesLock.writeLock().unlock();
        }
    }
    
    /**
     * 移除数据源（取消观察）
     */
    public void removeDataSource(String sourceId) {
        sourcesLock.writeLock().lock();
        try {
            DataSource source = dataSources.remove(sourceId);
            if (source != null) {
                // 停止数据源
                source.stop();
                
                // 移除回调
                source.removeDataCallback();
                
                // 清理信息
                sourceInfoMap.remove(sourceId);
                sampleRateControllers.remove(sourceId);
                
                notifySourceRemoved(source);
            }
        } finally {
            sourcesLock.writeLock().unlock();
        }
    }
    
    /**
     * 获取数据源
     */
    public DataSource getDataSource(String sourceId) {
        sourcesLock.readLock().lock();
        try {
            return dataSources.get(sourceId);
        } finally {
            sourcesLock.readLock().unlock();
        }
    }
    
    /**
     * 获取所有数据源
     */
    public List<DataSource> getAllDataSources() {
        sourcesLock.readLock().lock();
        try {
            return new ArrayList<>(dataSources.values());
        } finally {
            sourcesLock.readLock().unlock();
        }
    }
    
    /**
     * 开始记录
     */
    public void startRecording() {
        if (storage == null) {
            throw new IllegalStateException("Storage not created. Call createStorage() first.");
        }
        
        isRecording.set(true);
        
        // 注册所有通道
        sourcesLock.readLock().lock();
        try {
            for (DataSource source : dataSources.values()) {
                try {
                    for (DataChannel channel : source.getChannels()) {
                        storage.registerChannel(channel);
                    }
                } catch (IOException e) {
                    notifyError("Failed to register channels", e);
                }
            }
        } finally {
            sourcesLock.readLock().unlock();
        }
        
        notifyRecordingStarted();
    }
    
    /**
     * 停止记录
     */
    public void stopRecording() {
        isRecording.set(false);
        
        // 刷新缓冲区
        if (storage != null) {
            try {
                storage.flush();
            } catch (IOException e) {
                notifyError("Failed to flush storage", e);
            }
        }
        
        notifyRecordingStopped();
    }
    
    /**
     * 数据接收回调
     */
    private void onDataReceived(DataSource source, DataRecord record) {
        // 采样率控制
        SampleRateController controller = sampleRateControllers.get(source.getId());
        if (controller != null && !controller.shouldSample()) {
            return;
        }
        
        // 添加到缓冲区
        boolean offered = ringBuffer.offer(record);
        if (!offered) {
            // 缓冲区满，通知丢弃
            notifyDataDropped(source, record);
        }
    }
    
    /**
     * 启动数据写入任务
     */
    private void startWriterTask() {
        writerTask = executorService.submit(() -> {
            DataRecord[] batch = new DataRecord[config.getBatchSize()];
            
            while (isRunning.get() || !ringBuffer.isEmpty()) {
                try {
                    // 批量读取
                    int count = ringBuffer.pollBatch(batch);
                    
                    if (count > 0 && storage != null && isRecording.get()) {
                        List<DataRecord> records = Arrays.asList(batch).subList(0, count);
                        storage.writeRecords(records);
                        recordCounter.addAndGet(count);
                    }
                    
                    // 如果数据量少，短暂等待
                    if (count == 0) {
                        Thread.sleep(1);
                    }
                    
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (IOException e) {
                    notifyError("Failed to write records", e);
                }
            }
        });
    }
    
    /**
     * 启动缓冲区监控
     */
    private void startBufferMonitor() {
        scheduledExecutor.scheduleAtFixedRate(() -> {
            if (config.isDebugMode()) {
                int size = ringBuffer.size();
                int capacity = ringBuffer.getCapacity();
                double usage = (double) size / capacity * 100;
                System.out.printf("[DataObserver] Buffer usage: %.1f%% (%d/%d)%n", 
                    usage, size, capacity);
            }
        }, 5, 5, TimeUnit.SECONDS);
    }
    
    /**
     * 设置数据源采样率
     */
    public void setSampleRate(String sourceId, double targetRateHz) {
        sampleRateControllers.put(sourceId, new SampleRateController(targetRateHz));
    }
    
    /**
     * 获取统计信息
     */
    public Statistics getStatistics() {
        Statistics stats = new Statistics();
        stats.setTotalRecords(recordCounter.get());
        stats.setBufferSize(ringBuffer.size());
        stats.setBufferCapacity(ringBuffer.getCapacity());
        stats.setActiveSources(dataSources.size());
        stats.setIsRecording(isRecording.get());
        
        if (storage != null) {
            try {
                stats.setFileSize(storage.getFileSize());
                stats.setStorageRecordCount(storage.getRecordCount());
            } catch (IOException e) {
                // 忽略
            }
        }
        
        return stats;
    }
    
    @Override
    public void close() throws Exception {
        isRunning.set(false);
        isRecording.set(false);
        
        // 停止所有数据源
        sourcesLock.readLock().lock();
        try {
            for (DataSource source : dataSources.values()) {
                source.stop();
            }
        } finally {
            sourcesLock.readLock().unlock();
        }
        
        // 等待写入任务完成
        if (writerTask != null) {
            try {
                writerTask.get(5, TimeUnit.SECONDS);
            } catch (Exception e) {
                // 忽略
            }
        }
        
        // 关闭线程池
        if (executorService != null) {
            executorService.shutdown();
            executorService.awaitTermination(5, TimeUnit.SECONDS);
        }
        
        if (scheduledExecutor != null) {
            scheduledExecutor.shutdown();
            scheduledExecutor.awaitTermination(5, TimeUnit.SECONDS);
        }
        
        // 关闭存储
        if (storage != null) {
            storage.close();
        }
        
        notifyClosed();
    }
    
    // 监听器管理
    
    public void addListener(ObserverListener listener) {
        listeners.add(listener);
    }
    
    public void removeListener(ObserverListener listener) {
        listeners.remove(listener);
    }
    
    // 通知方法
    
    private void notifyInitialized() {
        for (ObserverListener listener : listeners) {
            listener.onInitialized();
        }
    }
    
    private void notifyStorageCreated(Path path, StorageFormat format) {
        for (ObserverListener listener : listeners) {
            listener.onStorageCreated(path, format);
        }
    }
    
    private void notifySourceAdded(DataSource source) {
        for (ObserverListener listener : listeners) {
            listener.onSourceAdded(source);
        }
    }
    
    private void notifySourceRemoved(DataSource source) {
        for (ObserverListener listener : listeners) {
            listener.onSourceRemoved(source);
        }
    }
    
    private void notifyRecordingStarted() {
        for (ObserverListener listener : listeners) {
            listener.onRecordingStarted();
        }
    }
    
    private void notifyRecordingStopped() {
        for (ObserverListener listener : listeners) {
            listener.onRecordingStopped();
        }
    }
    
    private void notifyDataDropped(DataSource source, DataRecord record) {
        for (ObserverListener listener : listeners) {
            listener.onDataDropped(source, record);
        }
    }
    
    private void notifyError(String message, Throwable error) {
        for (ObserverListener listener : listeners) {
            listener.onError(message, error);
        }
    }
    
    private void notifyClosed() {
        for (ObserverListener listener : listeners) {
            listener.onClosed();
        }
    }
    
    // 内部类
    
    /**
     * 配置类
     */
    public static class Config {
        private int bufferSize = 100000;
        private int batchSize = 100;
        private int workerThreads = 2;
        private String creator = "DataObserver";
        private String project = "";
        private String subject = "";
        private String description = "";
        private boolean debugMode = false;
        
        public int getBufferSize() { return bufferSize; }
        public Config setBufferSize(int size) { this.bufferSize = size; return this; }
        
        public int getBatchSize() { return batchSize; }
        public Config setBatchSize(int size) { this.batchSize = size; return this; }
        
        public int getWorkerThreads() { return workerThreads; }
        public Config setWorkerThreads(int threads) { this.workerThreads = threads; return this; }
        
        public String getCreator() { return creator; }
        public Config setCreator(String creator) { this.creator = creator; return this; }
        
        public String getProject() { return project; }
        public Config setProject(String project) { this.project = project; return this; }
        
        public String getSubject() { return subject; }
        public Config setSubject(String subject) { this.subject = subject; return this; }
        
        public String getDescription() { return description; }
        public Config setDescription(String desc) { this.description = desc; return this; }
        
        public boolean isDebugMode() { return debugMode; }
        public Config setDebugMode(boolean debug) { this.debugMode = debug; return this; }
    }
    
    /**
     * 数据源信息
     */
    private static class DataSourceInfo {
        private final DataSource source;
        private long recordsReceived;
        private long recordsDropped;
        private long startTime;
        
        DataSourceInfo(DataSource source) {
            this.source = source;
            this.startTime = System.currentTimeMillis();
        }
    }
    
    /**
     * 采样率控制器
     */
    private static class SampleRateController {
        private final double targetIntervalNs;
        private long lastSampleTime;
        
        SampleRateController(double targetRateHz) {
            this.targetIntervalNs = targetRateHz > 0 ? 1_000_000_000.0 / targetRateHz : 0;
            this.lastSampleTime = 0;
        }
        
        synchronized boolean shouldSample() {
            if (targetIntervalNs <= 0) {
                return true;
            }
            
            long now = System.nanoTime();
            if (lastSampleTime == 0 || (now - lastSampleTime) >= targetIntervalNs) {
                lastSampleTime = now;
                return true;
            }
            return false;
        }
    }
    
    /**
     * 统计信息
     */
    public static class Statistics {
        private long totalRecords;
        private long storageRecordCount;
        private int bufferSize;
        private int bufferCapacity;
        private int activeSources;
        private boolean isRecording;
        private long fileSize;
        
        public long getTotalRecords() { return totalRecords; }
        public void setTotalRecords(long count) { this.totalRecords = count; }
        
        public long getStorageRecordCount() { return storageRecordCount; }
        public void setStorageRecordCount(long count) { this.storageRecordCount = count; }
        
        public int getBufferSize() { return bufferSize; }
        public void setBufferSize(int size) { this.bufferSize = size; }
        
        public int getBufferCapacity() { return bufferCapacity; }
        public void setBufferCapacity(int capacity) { this.bufferCapacity = capacity; }
        
        public int getActiveSources() { return activeSources; }
        public void setActiveSources(int count) { this.activeSources = count; }
        
        public boolean isRecording() { return isRecording; }
        public void setIsRecording(boolean recording) { this.isRecording = recording; }
        
        public long getFileSize() { return fileSize; }
        public void setFileSize(long size) { this.fileSize = size; }
        
        @Override
        public String toString() {
            return String.format(
                "Statistics{records=%d, buffer=%d/%d, sources=%d, recording=%s, fileSize=%.2f MB}",
                totalRecords, bufferSize, bufferCapacity, activeSources, 
                isRecording, fileSize / (1024.0 * 1024.0)
            );
        }
    }
    
    /**
     * 观察器监听器接口
     */
    public interface ObserverListener {
        default void onInitialized() {}
        default void onStorageCreated(Path path, StorageFormat format) {}
        default void onSourceAdded(DataSource source) {}
        default void onSourceRemoved(DataSource source) {}
        default void onRecordingStarted() {}
        default void onRecordingStopped() {}
        default void onDataDropped(DataSource source, DataRecord record) {}
        default void onError(String message, Throwable error) {}
        default void onClosed() {}
    }
}
