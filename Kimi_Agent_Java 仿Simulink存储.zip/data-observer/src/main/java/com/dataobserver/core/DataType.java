package com.dataobserver.core;

/**
 * 支持的数据类型枚举
 * 对应MDF4规范中的数据类型
 */
public enum DataType {
    // 无符号整数
    UINT8(0, 1, false),
    UINT16(1, 2, false),
    UINT32(2, 4, false),
    UINT64(3, 8, false),
    
    // 有符号整数
    INT8(4, 1, true),
    INT16(5, 2, true),
    INT32(6, 4, true),
    INT64(7, 8, true),
    
    // 浮点数
    FLOAT(8, 4, true),
    DOUBLE(9, 8, true),
    
    // 特殊类型
    BOOLEAN(10, 1, false),
    STRING(11, -1, false),  // 变长
    BYTE_ARRAY(12, -1, false);  // 变长
    
    private final int typeCode;
    private final int sizeBytes;
    private final boolean signed;
    
    DataType(int typeCode, int sizeBytes, boolean signed) {
        this.typeCode = typeCode;
        this.sizeBytes = sizeBytes;
        this.signed = signed;
    }
    
    public int getTypeCode() {
        return typeCode;
    }
    
    public int getSizeBytes() {
        return sizeBytes;
    }
    
    public boolean isSigned() {
        return signed;
    }
    
    public boolean isVariableLength() {
        return sizeBytes == -1;
    }
    
    public static DataType fromTypeCode(int code) {
        for (DataType type : values()) {
            if (type.typeCode == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown type code: " + code);
    }
}
