package com.mf4.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 请求类 - 用于Java与Python之间的通信
 */
public class Request {
    
    /**
     * 请求类型枚举
     */
    public enum RequestType {
        OPEN_FILE("open_file"),
        CREATE_FILE("create_file"),
        CLOSE_FILE("close_file"),
        READ_DATA("read_data"),
        READ_NEXT_CHUNK("read_next_chunk"),
        CLOSE_ITERATOR("close_iterator"),
        READ_BATCH("read_batch"),
        WRITE_DATA("write_data"),
        GET_INFO("get_info"),
        GET_CHANNELS("get_channels"),
        GET_CHANNEL_INFO("get_channel_info"),
        FIND_CHANNEL("find_channel"),
        SAVE_FILE("save_file"),
        GET_MEMORY_STATS("get_memory_stats"),
        PING("ping"),
        SHUTDOWN("shutdown");
        
        private final String value;
        
        RequestType(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    /**
     * 写入模式枚举
     */
    public enum WriteMode {
        APPEND("append"),
        OVERWRITE("overwrite"),
        CREATE_NEW("create_new");
        
        private final String value;
        
        WriteMode(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    private String requestType;
    private String requestId;
    private String fileId;
    private Map<String, Object> data;
    
    public Request() {
        this.requestId = UUID.randomUUID().toString();
        this.data = new HashMap<>();
    }
    
    public Request(RequestType requestType) {
        this();
        this.requestType = requestType.getValue();
    }
    
    public Request(RequestType requestType, String fileId) {
        this(requestType);
        this.fileId = fileId;
    }
    
    public String getRequestType() {
        return requestType;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getFileId() {
        return fileId;
    }
    
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    
    public Map<String, Object> getData() {
        return data;
    }
    
    public void setData(Map<String, Object> data) {
        this.data = data;
    }
    
    public void addData(String key, Object value) {
        if (this.data == null) {
            this.data = new HashMap<>();
        }
        this.data.put(key, value);
    }
    
    // ============ 静态工厂方法 ============
    
    public static Request openFile(String filePath, boolean createIfNotExists) {
        Request request = new Request(RequestType.OPEN_FILE);
        request.addData("filePath", filePath);
        request.addData("createIfNotExists", createIfNotExists);
        return request;
    }
    
    public static Request createFile(String filePath, boolean overwrite) {
        Request request = new Request(RequestType.CREATE_FILE);
        request.addData("filePath", filePath);
        request.addData("overwrite", overwrite);
        return request;
    }
    
    public static Request closeFile(String fileId) {
        return new Request(RequestType.CLOSE_FILE, fileId);
    }
    
    public static Request readData(String fileId, int groupIndex, Integer channelIndex,
                                   Double start, Double end, Integer samples, boolean useIterator) {
        Request request = new Request(RequestType.READ_DATA, fileId);
        request.addData("groupIndex", groupIndex);
        if (channelIndex != null) {
            request.addData("channelIndex", channelIndex);
        }
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        if (samples != null) {
            request.addData("samples", samples);
        }
        request.addData("useIterator", useIterator);
        return request;
    }
    
    public static Request readNextChunk(String iteratorId) {
        Request request = new Request(RequestType.READ_NEXT_CHUNK);
        request.addData("iteratorId", iteratorId);
        return request;
    }
    
    public static Request closeIterator(String iteratorId) {
        Request request = new Request(RequestType.CLOSE_ITERATOR);
        request.addData("iteratorId", iteratorId);
        return request;
    }
    
    public static Request readBatch(String fileId, int groupIndex, int[] channelIndices,
                                    Double start, Double end, Integer maxSamples) {
        Request request = new Request(RequestType.READ_BATCH, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelIndices", channelIndices);
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        if (maxSamples != null) {
            request.addData("maxSamples", maxSamples);
        }
        return request;
    }
    
    public static Request writeData(String fileId, int groupIndex, List<Map<String, Object>> channelData,
                                    int batchSize, WriteMode writeMode) {
        Request request = new Request(RequestType.WRITE_DATA, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelData", channelData);
        request.addData("batchSize", batchSize);
        request.addData("writeMode", writeMode.getValue());
        return request;
    }
    
    public static Request getInfo(String fileId) {
        return new Request(RequestType.GET_INFO, fileId);
    }
    
    public static Request getChannels(String fileId, Integer groupIndex) {
        Request request = new Request(RequestType.GET_CHANNELS, fileId);
        if (groupIndex != null) {
            request.addData("groupIndex", groupIndex);
        }
        return request;
    }
    
    public static Request getChannelInfo(String fileId, int groupIndex, int channelIndex) {
        Request request = new Request(RequestType.GET_CHANNEL_INFO, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelIndex", channelIndex);
        return request;
    }
    
    public static Request findChannel(String fileId, String channelName) {
        Request request = new Request(RequestType.FIND_CHANNEL, fileId);
        request.addData("channelName", channelName);
        return request;
    }
    
    public static Request saveFile(String fileId, String filePath, boolean overwrite) {
        Request request = new Request(RequestType.SAVE_FILE, fileId);
        if (filePath != null) {
            request.addData("filePath", filePath);
        }
        request.addData("overwrite", overwrite);
        return request;
    }
    
    public static Request getMemoryStats() {
        return new Request(RequestType.GET_MEMORY_STATS);
    }
    
    public static Request ping() {
        return new Request(RequestType.PING);
    }
    
    public static Request shutdown() {
        return new Request(RequestType.SHUTDOWN);
    }
}
