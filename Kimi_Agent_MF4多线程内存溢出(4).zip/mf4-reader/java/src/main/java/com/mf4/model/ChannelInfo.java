package com.mf4.model;

/**
 * 通道基本信息
 */
public class ChannelInfo {
    
    private String name;
    private int groupIndex;
    private int channelIndex;
    private String unit;
    private String comment;
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getGroupIndex() {
        return groupIndex;
    }
    
    public void setGroupIndex(int groupIndex) {
        this.groupIndex = groupIndex;
    }
    
    public int getChannelIndex() {
        return channelIndex;
    }
    
    public void setChannelIndex(int channelIndex) {
        this.channelIndex = channelIndex;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    @Override
    public String toString() {
        return "ChannelInfo{" +
                "name='" + name + '\'' +
                ", groupIndex=" + groupIndex +
                ", channelIndex=" + channelIndex +
                ", unit='" + unit + '\'' +
                '}';
    }
}
