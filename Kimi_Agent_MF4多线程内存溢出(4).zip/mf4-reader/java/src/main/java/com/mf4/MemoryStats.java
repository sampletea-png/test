package com.mf4;

/**
 * Python服务端内存统计信息
 */
public class MemoryStats {
    
    private long rss;
    private double rssMB;
    private long vms;
    private double vmsMB;
    private int openFiles;
    private int activeIterators;
    private String error;
    
    public long getRss() {
        return rss;
    }
    
    public void setRss(long rss) {
        this.rss = rss;
    }
    
    public double getRssMB() {
        return rssMB;
    }
    
    public void setRssMB(double rssMB) {
        this.rssMB = rssMB;
    }
    
    public long getVms() {
        return vms;
    }
    
    public void setVms(long vms) {
        this.vms = vms;
    }
    
    public double getVmsMB() {
        return vmsMB;
    }
    
    public void setVmsMB(double vmsMB) {
        this.vmsMB = vmsMB;
    }
    
    public int getOpenFiles() {
        return openFiles;
    }
    
    public void setOpenFiles(int openFiles) {
        this.openFiles = openFiles;
    }
    
    public int getActiveIterators() {
        return activeIterators;
    }
    
    public void setActiveIterators(int activeIterators) {
        this.activeIterators = activeIterators;
    }
    
    public String getError() {
        return error;
    }
    
    public void setError(String error) {
        this.error = error;
    }
    
    public boolean isAvailable() {
        return error == null || error.isEmpty();
    }
    
    @Override
    public String toString() {
        if (!isAvailable()) {
            return "MemoryStats{error='" + error + "'}";
        }
        return "MemoryStats{" +
                "rssMB=" + String.format("%.2f", rssMB) +
                ", vmsMB=" + String.format("%.2f", vmsMB) +
                ", openFiles=" + openFiles +
                ", activeIterators=" + activeIterators +
                '}';
    }
}
