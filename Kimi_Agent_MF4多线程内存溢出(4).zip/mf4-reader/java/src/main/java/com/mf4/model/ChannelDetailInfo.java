package com.mf4.model;

/**
 * 通道详细信息
 */
public class ChannelDetailInfo {
    
    private String name;
    private int groupIndex;
    private int channelIndex;
    private String unit;
    private String comment;
    private String dataType;
    private Integer sampleCount;
    private Double startTime;
    private Double endTime;
    private String conversion;
    private String source;
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getGroupIndex() {
        return groupIndex;
    }
    
    public void setGroupIndex(int groupIndex) {
        this.groupIndex = groupIndex;
    }
    
    public int getChannelIndex() {
        return channelIndex;
    }
    
    public void setChannelIndex(int channelIndex) {
        this.channelIndex = channelIndex;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public String getDataType() {
        return dataType;
    }
    
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    public Integer getSampleCount() {
        return sampleCount;
    }
    
    public void setSampleCount(Integer sampleCount) {
        this.sampleCount = sampleCount;
    }
    
    public Double getStartTime() {
        return startTime;
    }
    
    public void setStartTime(Double startTime) {
        this.startTime = startTime;
    }
    
    public Double getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Double endTime) {
        this.endTime = endTime;
    }
    
    public String getConversion() {
        return conversion;
    }
    
    public void setConversion(String conversion) {
        this.conversion = conversion;
    }
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
    @Override
    public String toString() {
        return "ChannelDetailInfo{" +
                "name='" + name + '\'' +
                ", groupIndex=" + groupIndex +
                ", channelIndex=" + channelIndex +
                ", unit='" + unit + '\'' +
                ", comment='" + comment + '\'' +
                ", sampleCount=" + sampleCount +
                '}';
    }
}
