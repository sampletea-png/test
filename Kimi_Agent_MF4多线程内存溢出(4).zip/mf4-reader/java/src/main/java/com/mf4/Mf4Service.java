package com.mf4;

import com.mf4.exception.Mf4Exception;

import java.io.Closeable;

/**
 * MF4服务接口 - 管理Python进程和文件操作
 */
public interface Mf4Service extends Closeable {
    
    void start() throws Mf4Exception;
    
    boolean isRunning();
    
    Mf4File openFile(String filePath) throws Mf4Exception;
    
    Mf4File openFile(String filePath, boolean createIfNotExists) throws Mf4Exception;
    
    Mf4File createFile(String filePath) throws Mf4Exception;
    
    Mf4File createFile(String filePath, boolean overwrite) throws Mf4Exception;
    
    MemoryStats getMemoryStats() throws Mf4Exception;
    
    @Override
    void close();
}
