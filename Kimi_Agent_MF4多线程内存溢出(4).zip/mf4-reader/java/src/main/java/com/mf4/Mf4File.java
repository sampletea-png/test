package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.ChannelData;
import com.mf4.model.ChannelDetailInfo;
import com.mf4.model.ChannelInfo;
import com.mf4.model.FileInfo;

import java.io.Closeable;
import java.util.List;

/**
 * MF4文件操作接口
 */
public interface Mf4File extends Closeable {
    
    String getFileId();
    
    String getFilePath();
    
    FileInfo getInfo() throws Mf4Exception;
    
    List<ChannelInfo> getChannels() throws Mf4Exception;
    
    List<ChannelInfo> getChannels(int groupIndex) throws Mf4Exception;
    
    ChannelDetailInfo getChannelInfo(int groupIndex, int channelIndex) throws Mf4Exception;
    
    List<ChannelInfo> findChannel(String channelName) throws Mf4Exception;
    
    ChannelData readChannel(int groupIndex, int channelIndex) throws Mf4Exception;
    
    ChannelData readChannel(int groupIndex, int channelIndex, double startTime, double endTime) throws Mf4Exception;
    
    ChannelData readChannel(int groupIndex, int channelIndex, int maxSamples) throws Mf4Exception;
    
    ChannelDataIterator readChannelStream(int groupIndex, int channelIndex) throws Mf4Exception;
    
    ChannelDataIterator readChannelStream(int groupIndex, int channelIndex, 
                                          double startTime, double endTime) throws Mf4Exception;
    
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices) throws Mf4Exception;
    
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                   double startTime, double endTime) throws Mf4Exception;
    
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                   double startTime, double endTime, int maxSamples) throws Mf4Exception;
    
    List<ChannelData> readGroup(int groupIndex) throws Mf4Exception;
    
    List<ChannelData> readGroup(int groupIndex, int maxChannels) throws Mf4Exception;
    
    void writeChannel(int groupIndex, ChannelData data) throws Mf4Exception;
    
    void writeChannel(int groupIndex, ChannelData data, WriteMode writeMode) throws Mf4Exception;
    
    void writeChannels(int groupIndex, List<ChannelData> dataList) throws Mf4Exception;
    
    void writeChannels(int groupIndex, List<ChannelData> dataList, WriteMode writeMode) throws Mf4Exception;
    
    void writeChannels(int groupIndex, List<ChannelData> dataList, int batchSize, WriteMode writeMode) throws Mf4Exception;
    
    void save() throws Mf4Exception;
    
    void save(String filePath, boolean overwrite) throws Mf4Exception;
    
    @Override
    void close();
    
    boolean isClosed();
    
    enum WriteMode {
        APPEND,
        OVERWRITE,
        CREATE_NEW
    }
}
