package com.mf4;

import com.mf4.model.ChannelData;
import com.mf4.model.ChannelDetailInfo;
import com.mf4.model.FileInfo;

import java.util.List;
import java.util.logging.Logger;

/**
 * 主入口类
 */
public class Main {
    
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    
    public static void main(String[] args) {
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4ServiceImpl service = new Mf4ServiceImpl(pythonScriptPath)) {
            service.start();
            LOGGER.info("Service started on port: " + service.getPort());
            
            // 获取内存统计
            MemoryStats stats = service.getMemoryStats();
            LOGGER.info("Memory stats: " + stats);
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
