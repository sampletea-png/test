package com.mf4;

import com.google.gson.Gson;
import com.mf4.model.Request;
import com.mf4.model.Response;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Socket客户端 - 负责与Python服务器的通信
 */
public class SocketClient {
    
    private static final byte[] MAGIC_NUMBER = new byte[]{'M', 'F', '4', 'P'};
    private static final int VERSION = 1;
    private static final int HEADER_SIZE = 12;
    private static final int BUFFER_SIZE = 8192;
    private static final int DEFAULT_TIMEOUT = 300000;
    
    private final String host;
    private final int port;
    private final Gson gson;
    private final ReentrantLock lock;
    private final AtomicBoolean connected;
    
    private Socket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.gson = new Gson();
        this.lock = new ReentrantLock();
        this.connected = new AtomicBoolean(false);
    }
    
    public void connect() throws IOException {
        lock.lock();
        try {
            if (connected.get()) {
                return;
            }
            
            socket = new Socket(host, port);
            socket.setSoTimeout(DEFAULT_TIMEOUT);
            socket.setKeepAlive(true);
            socket.setTcpNoDelay(true);
            
            outputStream = new BufferedOutputStream(socket.getOutputStream());
            inputStream = new BufferedInputStream(socket.getInputStream());
            
            connected.set(true);
        } finally {
            lock.unlock();
        }
    }
    
    public void disconnect() {
        lock.lock();
        try {
            connected.set(false);
            
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    // ignore
                }
                outputStream = null;
            }
            
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    // ignore
                }
                inputStream = null;
            }
            
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // ignore
                }
                socket = null;
            }
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isConnected() {
        return connected.get() && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    public Response sendRequest(Request request) throws IOException {
        lock.lock();
        try {
            if (!isConnected()) {
                throw new IOException("Not connected to server");
            }
            
            String jsonRequest = gson.toJson(request);
            byte[] requestData = jsonRequest.getBytes(StandardCharsets.UTF_8);
            
            ByteBuffer header = ByteBuffer.allocate(HEADER_SIZE);
            header.put(MAGIC_NUMBER);
            header.put((byte) VERSION);
            header.put(new byte[3]);
            header.putInt(requestData.length);
            
            outputStream.write(header.array());
            outputStream.write(requestData);
            outputStream.flush();
            
            String jsonResponse = receiveMessage();
            
            return gson.fromJson(jsonResponse, Response.class);
            
        } finally {
            lock.unlock();
        }
    }
    
    private String receiveMessage() throws IOException {
        byte[] header = new byte[HEADER_SIZE];
        int headerRead = 0;
        
        while (headerRead < HEADER_SIZE) {
            int read = inputStream.read(header, headerRead, HEADER_SIZE - headerRead);
            if (read == -1) {
                throw new IOException("Connection closed while reading header");
            }
            headerRead += read;
        }
        
        for (int i = 0; i < 4; i++) {
            if (header[i] != MAGIC_NUMBER[i]) {
                throw new IOException("Invalid magic number in response");
            }
        }
        
        int dataLength = ByteBuffer.wrap(header, 8, 4).getInt();
        
        if (dataLength < 0 || dataLength > 100 * 1024 * 1024) {
            throw new IOException("Invalid data length: " + dataLength);
        }
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream(dataLength);
        byte[] buffer = new byte[Math.min(BUFFER_SIZE, dataLength)];
        int totalRead = 0;
        
        while (totalRead < dataLength) {
            int toRead = Math.min(buffer.length, dataLength - totalRead);
            int read = inputStream.read(buffer, 0, toRead);
            if (read == -1) {
                throw new IOException("Connection closed while reading body");
            }
            baos.write(buffer, 0, read);
            totalRead += read;
        }
        
        return baos.toString(StandardCharsets.UTF_8.name());
    }
    
    public boolean ping() {
        try {
            Response response = sendRequest(Request.ping());
            return response.isSuccess();
        } catch (Exception e) {
            return false;
        }
    }
    
    public void shutdownServer() {
        try {
            sendRequest(Request.shutdown());
        } catch (Exception e) {
            // ignore
        } finally {
            disconnect();
        }
    }
}
