package com.mf4.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 响应类 - 用于Java与Python之间的通信
 */
public class Response {
    
    /**
     * 响应状态枚举
     */
    public enum Status {
        SUCCESS("success"),
        ERROR("error"),
        PARTIAL("partial");
        
        private final String value;
        
        Status(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
        
        public static Status fromValue(String value) {
            for (Status status : values()) {
                if (status.value.equals(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown status: " + value);
        }
    }
    
    private String requestId;
    private String status;
    private String message;
    private Map<String, Object> data;
    private boolean hasMore;
    private int chunkIndex;
    
    public Response() {
        this.data = new HashMap<>();
        this.hasMore = false;
        this.chunkIndex = 0;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public Map<String, Object> getData() {
        return data;
    }
    
    public void setData(Map<String, Object> data) {
        this.data = data;
    }
    
    public boolean isHasMore() {
        return hasMore;
    }
    
    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
    
    public int getChunkIndex() {
        return chunkIndex;
    }
    
    public void setChunkIndex(int chunkIndex) {
        this.chunkIndex = chunkIndex;
    }
    
    public boolean isSuccess() {
        return Status.SUCCESS.getValue().equals(status);
    }
    
    public String getErrorMessage() {
        if (Status.ERROR.getValue().equals(status)) {
            return message;
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    public String getString(String key) {
        if (data == null) {
            return null;
        }
        Object value = data.get(key);
        return value != null ? value.toString() : null;
    }
    
    @SuppressWarnings("unchecked")
    public Integer getInt(String key) {
        if (data == null) {
            return null;
        }
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    public Boolean getBoolean(String key) {
        if (data == null) {
            return null;
        }
        Object value = data.get(key);
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    public <T> List<T> getList(String key) {
        if (data == null) {
            return null;
        }
        Object value = data.get(key);
        if (value instanceof List) {
            return (List<T>) value;
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    public Map<String, Object> getMap(String key) {
        if (data == null) {
            return null;
        }
        Object value = data.get(key);
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        return null;
    }
    
    @Override
    public String toString() {
        return "Response{" +
                "requestId='" + requestId + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", hasMore=" + hasMore +
                ", chunkIndex=" + chunkIndex +
                '}';
    }
}
