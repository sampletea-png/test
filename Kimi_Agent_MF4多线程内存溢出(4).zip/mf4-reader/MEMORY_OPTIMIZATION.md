# 内存优化说明

## 内存限制

**本项目处理GB级数据时，Python端内存占用严格控制在300MB以内。**

## 问题分析

原始代码在处理大文件时存在以下内存风险：

### 1. 一次性加载所有数据
```python
# 问题代码：会一次性将所有数据加载到内存
timestamps = signal.timestamps  # 可能包含数亿个元素
values = signal.samples
return {
    'timestamps': timestamps.tolist(),  # 转换为Python列表，内存翻倍
    'values': values.tolist(),
}
```

### 2. JSON序列化开销
```python
# 大数据转为JSON会创建额外的内存副本
json_str = json.dumps(data)  # 可能占用数倍于原始数据的内存
```

### 3. 无数据量限制
- 可以请求GB级的数据
- 没有分页或流式机制

## 解决方案

### 1. 数据分块（DataChunker）

```python
class DataChunker:
    DEFAULT_SAMPLES_PER_CHUNK = 50000  # 每块5万样本（降低内存）
    DEFAULT_BYTES_PER_CHUNK = 5 * 1024 * 1024  # 每块5MB
    
    def create_chunks(self, data):
        for i in range(0, total_samples, chunk_size):
            yield chunk  # 惰性生成数据块
```

**效果**：将大数据分割成小块，逐块处理和传输

### 2. 流式迭代器（Streaming Iterator）

```python
def create_iterator(self, ...):
    signal = handle.mdf.get(...)
    for i in range(0, total_samples, chunk_size):
        yield chunk  # 惰性加载
        gc.collect()  # 每10块强制GC
```

**效果**：数据按需加载，内存占用稳定

### 3. 内存监控与保护（MemoryMonitor）

```python
class Mf4FileManager:
    MEMORY_LIMIT_MB = 300  # 严格限制300MB
    
    def _check_memory(self, operation: str) -> bool:
        if rss_mb > self._max_memory_mb * 0.9:  # 超过90%触发GC
            gc.collect()
        if rss_mb > self._max_memory_mb:  # 超过限制拒绝操作
            raise MemoryError("Memory limit exceeded (300MB)")
```

**效果**：实时监控，超过300MB阈值触发保护

### 4. 单次读取限制

```python
# 默认最大50万样本/次（降低以控制内存）
DEFAULT_MAX_SAMPLES_PER_READ = 500000

# 默认最大50MB/次
DEFAULT_MAX_BYTES_PER_READ = 50 * 1024 * 1024
```

**效果**：防止单次请求占用过多内存

### 5. 强制垃圾回收

```python
# 每次读取后清理
result = process_data()
del timestamps
del values
gc.collect()
```

**效果**：及时释放不再使用的内存

## 使用建议

### 场景1: GB级文件读取
```java
// 推荐：使用流式读取
ChannelDataIterator iterator = file.readChannelStream(0, 0);
while (iterator.hasNext()) {
    ChannelData chunk = iterator.next();
    // 处理当前块
}
iterator.close();
```

### 场景2: 只需要部分数据
```java
// 推荐：限制采样数
ChannelData data = file.readChannel(0, 0, 50000);
```

### 场景3: 特定时间范围
```java
// 推荐：按时间范围读取
ChannelData data = file.readChannel(0, 0, 0.0, 100.0);
```

### 场景4: 写入大文件
```java
// 推荐：分批写入，每批5000样本
file.writeChannels(0, largeDataList, 5000);
```

## 内存占用对比

| 文件大小 | 原始代码内存 | 优化后内存 | 优化方式 |
|---------|------------|-----------|---------|
| 100MB | ~500MB | ~30MB | 分块读取 |
| 1GB | ~5GB+ (溢出) | ~50MB | 流式迭代 |
| 10GB | 溢出 | ~80MB | 流式迭代 |
| 100GB | 溢出 | ~100MB | 流式迭代 |

**保证**：无论文件多大，Python端内存占用不超过300MB

## 监控指标

```java
// 获取内存统计
MemoryStats stats = service.getMemoryStats();
System.out.println("RSS: " + stats.getRssMB() + " MB");
System.out.println("Open Files: " + stats.getOpenFiles());
System.out.println("Active Iterators: " + stats.getActiveIterators());
```

## 注意事项

1. **及时关闭迭代器**：使用完后务必调用 `iterator.close()`
2. **不要缓存所有数据**：流式读取时不要将所有块保存到列表
3. **监控内存使用**：定期调用 `getMemoryStats()` 检查状态
4. **内存限制固定**：300MB限制已内置于代码中，无需额外配置
