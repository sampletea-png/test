"""
MF4服务器主模块 - 提供Socket服务处理Java端的请求
"""
import socket
import threading
import signal
import sys
import os
import argparse
from typing import Optional

from protocol import Request, Response, RequestType, ProtocolHelper
from mf4_handler import Mf4FileManager
from logger_config import setup_logger

import logging

logger = logging.getLogger('mf4_server')


class Mf4Server:
    """MF4文件服务器"""
    
    def __init__(self, host: str = '127.0.0.1', port: int = 0, 
                 log_dir: str = None, parent_pid: int = None,
                 max_memory_mb: int = 300):
        self.host = host
        self.port = port
        self.parent_pid = parent_pid
        self.log_dir = log_dir
        
        self.server_socket: Optional[socket.socket] = None
        self.file_manager = Mf4FileManager(max_memory_mb=max_memory_mb)
        self.running = False
        self._lock = threading.RLock()
        self._client_threads: set = set()
        
        setup_logger(log_dir)
        
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
        
        logger.info(f"MF4 Server initialized. Host: {host}, Port: {port}, MaxMemory: {max_memory_mb}MB")
    
    def _signal_handler(self, signum, frame):
        """信号处理函数"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.shutdown()
        sys.exit(0)
    
    def start(self) -> int:
        """启动服务器"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(10)
            
            self.port = self.server_socket.getsockname()[1]
            self.running = True
            
            logger.info(f"Server started on {self.host}:{self.port}")
            print(f"PORT:{self.port}", flush=True)
            
            if self.parent_pid:
                monitor_thread = threading.Thread(
                    target=self._monitor_parent_process,
                    name="ParentMonitor",
                    daemon=True
                )
                monitor_thread.start()
            
            memory_monitor_thread = threading.Thread(
                target=self._monitor_memory,
                name="MemoryMonitor",
                daemon=True
            )
            memory_monitor_thread.start()
            
            while self.running:
                try:
                    self.server_socket.settimeout(1.0)
                    client_socket, address = self.server_socket.accept()
                    logger.info(f"Client connected: {address}")
                    
                    client_thread = threading.Thread(
                        target=self._handle_client,
                        args=(client_socket, address),
                        name=f"ClientHandler-{address[1]}",
                        daemon=True
                    )
                    
                    with self._lock:
                        self._client_threads.add(client_thread)
                    
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except OSError:
                    break
                    
        except Exception as e:
            logger.error(f"Server error: {e}")
            raise
        finally:
            self.shutdown()
        
        return self.port
    
    def _monitor_parent_process(self):
        """监控父进程是否存活"""
        import psutil
        
        logger.info(f"Starting parent process monitor for PID: {self.parent_pid}")
        
        try:
            parent = psutil.Process(self.parent_pid)
            while self.running:
                if not parent.is_running():
                    logger.warning(f"Parent process {self.parent_pid} is not running, shutting down...")
                    self.shutdown()
                    break
                threading.Event().wait(2.0)
        except psutil.NoSuchProcess:
            logger.warning(f"Parent process {self.parent_pid} does not exist, shutting down...")
            self.shutdown()
        except Exception as e:
            logger.error(f"Error monitoring parent process: {e}")
    
    def _monitor_memory(self):
        """监控内存使用情况"""
        import time
        
        logger.info("Starting memory monitor thread")
        
        while self.running:
            try:
                stats = self.file_manager.get_memory_stats()
                rss_mb = stats.get('rssMB', 0)
                
                if rss_mb > 240:  # 300MB限制的80%警告阈值
                    logger.warning(f"High memory usage detected: {rss_mb:.1f}MB, approaching 300MB limit")
                
                if int(time.time()) % 30 == 0:
                    logger.info(f"Memory stats: RSS={rss_mb:.1f}MB, "
                              f"OpenFiles={stats.get('openFiles', 0)}, "
                              f"Iterators={stats.get('activeIterators', 0)}")
                
                time.sleep(5.0)
            except Exception as e:
                logger.error(f"Error in memory monitor: {e}")
                time.sleep(10.0)
    
    def _handle_client(self, client_socket: socket.socket, address):
        """处理客户端连接"""
        try:
            client_socket.settimeout(300.0)
            
            while self.running:
                try:
                    message = ProtocolHelper.receive_message(client_socket)
                    request = Request.from_json(message)
                    
                    logger.debug(f"Received request: {request.request_type}, id: {request.request_id}")
                    
                    response = self._process_request(request)
                    
                    ProtocolHelper.send_message(client_socket, response.to_json())
                    
                    if request.request_type == RequestType.SHUTDOWN:
                        break
                        
                except socket.timeout:
                    logger.warning(f"Client {address} timeout")
                    break
                except ConnectionError as e:
                    logger.info(f"Client {address} disconnected: {e}")
                    break
                except Exception as e:
                    logger.error(f"Error handling client {address}: {e}")
                    try:
                        error_response = Response.error(
                            request.request_id if 'request' in locals() else 'unknown',
                            str(e)
                        )
                        ProtocolHelper.send_message(client_socket, error_response.to_json())
                    except:
                        pass
                    break
                    
        finally:
            client_socket.close()
            with self._lock:
                self._client_threads.discard(threading.current_thread())
            logger.info(f"Client handler stopped: {address}")
    
    def _process_request(self, request: Request) -> Response:
        """处理请求"""
        try:
            req_type = request.request_type
            
            if isinstance(req_type, str):
                req_type = RequestType(req_type)
            
            handlers = {
                RequestType.OPEN_FILE: self._handle_open_file,
                RequestType.CREATE_FILE: self._handle_create_file,
                RequestType.CLOSE_FILE: self._handle_close_file,
                RequestType.READ_DATA: self._handle_read_data,
                RequestType.READ_NEXT_CHUNK: self._handle_read_next_chunk,
                RequestType.CLOSE_ITERATOR: self._handle_close_iterator,
                RequestType.READ_BATCH: self._handle_read_batch,
                RequestType.WRITE_DATA: self._handle_write_data,
                RequestType.GET_INFO: self._handle_get_info,
                RequestType.GET_CHANNELS: self._handle_get_channels,
                RequestType.GET_CHANNEL_INFO: self._handle_get_channel_info,
                RequestType.FIND_CHANNEL: self._handle_find_channel,
                RequestType.SAVE_FILE: self._handle_save_file,
                RequestType.GET_MEMORY_STATS: self._handle_get_memory_stats,
                RequestType.PING: lambda r: Response.success(r.request_id, {'pong': True}),
                RequestType.SHUTDOWN: self._handle_shutdown,
            }
            
            handler = handlers.get(req_type)
            if handler:
                return handler(request)
            else:
                return Response.error(request.request_id, f"Unknown request type: {req_type}")
                
        except Exception as e:
            logger.error(f"Error processing request {request.request_id}: {e}")
            return Response.error(request.request_id, str(e))
    
    def _handle_open_file(self, request: Request) -> Response:
        """处理打开文件请求"""
        file_path = request.data.get('filePath')
        create_if_not_exists = request.data.get('createIfNotExists', False)
        
        if not file_path:
            return Response.error(request.request_id, "filePath is required")
        
        file_id = self.file_manager.open_file(file_path, 'r', create_if_not_exists)
        
        return Response.success(request.request_id, {
            'fileId': file_id,
            'filePath': file_path
        })
    
    def _handle_create_file(self, request: Request) -> Response:
        """处理创建文件请求"""
        file_path = request.data.get('filePath')
        overwrite = request.data.get('overwrite', False)
        
        if not file_path:
            return Response.error(request.request_id, "filePath is required")
        
        if os.path.exists(file_path) and not overwrite:
            return Response.error(request.request_id, f"File already exists: {file_path}")
        
        file_id = self.file_manager.open_file(file_path, 'w', True)
        
        return Response.success(request.request_id, {
            'fileId': file_id,
            'filePath': file_path
        })
    
    def _handle_close_file(self, request: Request) -> Response:
        """处理关闭文件请求"""
        file_id = request.file_id
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        success = self.file_manager.close_file(file_id)
        
        return Response.success(request.request_id, {'success': success})
    
    def _handle_read_data(self, request: Request) -> Response:
        """处理读取数据请求"""
        file_id = request.file_id
        data = request.data
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        result = self.file_manager.read_data(
            file_id=file_id,
            group_index=data.get('groupIndex', 0),
            channel_index=data.get('channelIndex'),
            start=data.get('start'),
            end=data.get('end'),
            samples=data.get('samples'),
            use_iterator=data.get('useIterator', False)
        )
        
        return Response.success(request.request_id, result)
    
    def _handle_read_next_chunk(self, request: Request) -> Response:
        """处理读取下一个数据块请求"""
        iterator_id = request.data.get('iteratorId')
        
        if not iterator_id:
            return Response.error(request.request_id, "iteratorId is required")
        
        try:
            result = self.file_manager.read_next_chunk(iterator_id)
            
            if result is None:
                return Response.success(request.request_id, {
                    'iteratorId': iterator_id,
                    'hasMore': False,
                    'sampleCount': 0
                })
            
            return Response.success(request.request_id, result)
            
        except ValueError as e:
            return Response.error(request.request_id, str(e))
    
    def _handle_close_iterator(self, request: Request) -> Response:
        """处理关闭迭代器请求"""
        iterator_id = request.data.get('iteratorId')
        
        if not iterator_id:
            return Response.error(request.request_id, "iteratorId is required")
        
        self.file_manager.close_iterator(iterator_id)
        
        return Response.success(request.request_id, {'success': True})
    
    def _handle_read_batch(self, request: Request) -> Response:
        """处理批量读取请求"""
        file_id = request.file_id
        data = request.data
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        result = self.file_manager.read_data(
            file_id=file_id,
            group_index=data.get('groupIndex', 0),
            channel_index=None,
            start=data.get('start'),
            end=data.get('end'),
            samples=data.get('maxSamples')
        )
        
        return Response.success(request.request_id, result)
    
    def _handle_write_data(self, request: Request) -> Response:
        """处理写入数据请求"""
        file_id = request.file_id
        data = request.data
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        result = self.file_manager.write_data(
            file_id=file_id,
            group_index=data.get('groupIndex', 0),
            channel_data=data.get('channelData', []),
            batch_size=data.get('batchSize', 10000),
            write_mode=data.get('writeMode', 'append')
        )
        
        return Response.success(request.request_id, result)
    
    def _handle_get_info(self, request: Request) -> Response:
        """处理获取文件信息请求"""
        file_id = request.file_id
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        info = self.file_manager.get_file_info(file_id)
        
        return Response.success(request.request_id, info)
    
    def _handle_get_channels(self, request: Request) -> Response:
        """处理获取通道列表请求"""
        file_id = request.file_id
        data = request.data or {}
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        channels = self.file_manager.get_channels(
            file_id=file_id,
            group_index=data.get('groupIndex')
        )
        
        return Response.success(request.request_id, {'channels': channels})
    
    def _handle_get_channel_info(self, request: Request) -> Response:
        """处理获取单个通道详细信息请求"""
        file_id = request.file_id
        data = request.data or {}
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        group_index = data.get('groupIndex', 0)
        channel_index = data.get('channelIndex', 0)
        
        try:
            info = self.file_manager.get_channel_info(
                file_id=file_id,
                group_index=group_index,
                channel_index=channel_index
            )
            return Response.success(request.request_id, info)
        except ValueError as e:
            return Response.error(request.request_id, str(e))
    
    def _handle_find_channel(self, request: Request) -> Response:
        """处理按名称查找通道请求"""
        file_id = request.file_id
        data = request.data or {}
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        channel_name = data.get('channelName')
        if not channel_name:
            return Response.error(request.request_id, "channelName is required")
        
        try:
            results = self.file_manager.find_channel(
                file_id=file_id,
                channel_name=channel_name
            )
            return Response.success(request.request_id, {'channels': results})
        except ValueError as e:
            return Response.error(request.request_id, str(e))
    
    def _handle_save_file(self, request: Request) -> Response:
        """处理保存文件请求"""
        file_id = request.file_id
        data = request.data or {}
        
        if not file_id:
            return Response.error(request.request_id, "fileId is required")
        
        saved_path = self.file_manager.save_file(
            file_id=file_id,
            file_path=data.get('filePath'),
            overwrite=data.get('overwrite', False)
        )
        
        return Response.success(request.request_id, {'savedPath': saved_path})
    
    def _handle_get_memory_stats(self, request: Request) -> Response:
        """处理获取内存统计请求"""
        stats = self.file_manager.get_memory_stats()
        return Response.success(request.request_id, stats)
    
    def _handle_shutdown(self, request: Request) -> Response:
        """处理关闭服务器请求"""
        threading.Thread(target=self.shutdown, daemon=True).start()
        return Response.success(request.request_id, {'shuttingDown': True})
    
    def shutdown(self):
        """关闭服务器"""
        logger.info("Shutting down server...")
        self.running = False
        
        self.file_manager.close_all()
        
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        
        with self._lock:
            threads = list(self._client_threads)
        
        for thread in threads:
            thread.join(timeout=5.0)
        
        logger.info("Server shutdown complete")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='MF4 File Server')
    parser.add_argument('--port', type=int, default=0, help='Server port (0 for auto)')
    parser.add_argument('--host', type=str, default='127.0.0.1', help='Server host')
    parser.add_argument('--log-dir', type=str, help='Log directory')
    parser.add_argument('--parent-pid', type=int, help='Parent process PID to monitor')
    parser.add_argument('--max-memory', type=int, default=300, help='Max memory limit in MB (default: 300)')
    
    args = parser.parse_args()
    
    server = Mf4Server(
        host=args.host,
        port=args.port,
        log_dir=args.log_dir,
        parent_pid=args.parent_pid,
        max_memory_mb=args.max_memory
    )
    
    try:
        server.start()
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        server.shutdown()
    except Exception as e:
        logger.error(f"Server error: {e}")
        raise


if __name__ == '__main__':
    main()
