"""
服务器集成测试
"""
import pytest
import socket
import threading
import time
import os
import tempfile
import numpy as np
from asammdf import MDF, Signal

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from protocol import Request, Response, RequestType, ProtocolHelper
from mf4_server import Mf4Server


class TestMf4ServerIntegration:
    """服务器集成测试"""
    
    @pytest.fixture(scope="class")
    def server(self):
        """启动测试服务器"""
        server = Mf4Server(host='127.0.0.1', port=0, max_memory_mb=256)
        
        server_thread = threading.Thread(target=server.start, daemon=True)
        server_thread.start()
        
        # 等待服务器启动
        time.sleep(1)
        
        yield server
        
        server.shutdown()
    
    @pytest.fixture
    def client_socket(self, server):
        """创建客户端socket"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((server.host, server.port))
        sock.settimeout(10.0)
        yield sock
        sock.close()
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    def send_request(self, sock, request):
        """发送请求并接收响应"""
        ProtocolHelper.send_message(sock, request.to_json())
        response_json = ProtocolHelper.receive_message(sock)
        return Response.from_json(response_json)
    
    def test_ping(self, client_socket):
        """测试ping请求"""
        request = Request(RequestType.PING)
        response = self.send_request(client_socket, request)
        
        assert response.status.value == 'success'
        assert response.data.get('pong') is True
    
    def test_create_and_open_file(self, client_socket, temp_dir):
        """测试创建和打开文件"""
        file_path = os.path.join(temp_dir, "server_test.mf4")
        
        # 创建文件
        request = Request(RequestType.CREATE_FILE)
        request.addData("filePath", file_path)
        request.addData("overwrite", True)
        
        response = self.send_request(client_socket, request)
        assert response.status.value == 'success'
        assert 'fileId' in response.data
        
        file_id = response.data['fileId']
        
        # 关闭文件
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        close_response = self.send_request(client_socket, close_request)
        assert close_response.status.value == 'success'
        
        # 打开文件
        open_request = Request(RequestType.OPEN_FILE)
        open_request.addData("filePath", file_path)
        open_request.addData("createIfNotExists", False)
        
        open_response = self.send_request(client_socket, open_request)
        assert open_response.status.value == 'success'
        
        # 关闭
        close_request2 = Request(RequestType.CLOSE_FILE, open_response.data['fileId'])
        self.send_request(client_socket, close_request2)
    
    def test_write_and_read_data(self, client_socket, temp_dir):
        """测试写入和读取数据"""
        file_path = os.path.join(temp_dir, "write_read_test.mf4")
        
        # 创建文件
        create_request = Request(RequestType.CREATE_FILE)
        create_request.addData("filePath", file_path)
        create_request.addData("overwrite", True)
        
        create_response = self.send_request(client_socket, create_request)
        file_id = create_response.data['fileId']
        
        # 写入数据
        write_request = Request(RequestType.WRITE_DATA, file_id)
        write_request.addData("groupIndex", 0)
        write_request.addData("channelData", [{
            'name': 'TestSignal',
            'unit': 'V',
            'timestamps': [0.0, 0.1, 0.2, 0.3, 0.4],
            'values': [1.0, 2.0, 3.0, 4.0, 5.0]
        }])
        write_request.addData("writeMode", "create_new")
        
        write_response = self.send_request(client_socket, write_request)
        assert write_response.status.value == 'success'
        assert write_response.data.get('channelsCreated') == 1
        
        # 保存文件
        save_request = Request(RequestType.SAVE_FILE, file_id)
        save_response = self.send_request(client_socket, save_request)
        assert save_response.status.value == 'success'
        
        # 关闭文件
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
        
        # 重新打开读取
        open_request = Request(RequestType.OPEN_FILE)
        open_request.addData("filePath", file_path)
        open_request.addData("createIfNotExists", False)
        
        open_response = self.send_request(client_socket, open_request)
        file_id = open_response.data['fileId']
        
        # 读取数据
        read_request = Request(RequestType.READ_DATA, file_id)
        read_request.addData("groupIndex", 0)
        read_request.addData("channelIndex", 0)
        
        read_response = self.send_request(client_socket, read_request)
        assert read_response.status.value == 'success'
        assert 'timestamps' in read_response.data
        assert 'values' in read_response.data
        assert read_response.data.get('sampleCount') == 5
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
    
    def test_get_channels(self, client_socket, temp_dir):
        """测试获取通道列表"""
        file_path = os.path.join(temp_dir, "channels_test.mf4")
        
        # 创建文件并写入数据
        create_request = Request(RequestType.CREATE_FILE)
        create_request.addData("filePath", file_path)
        create_request.addData("overwrite", True)
        
        create_response = self.send_request(client_socket, create_request)
        file_id = create_response.data['fileId']
        
        # 写入多个通道
        write_request = Request(RequestType.WRITE_DATA, file_id)
        write_request.addData("groupIndex", 0)
        write_request.addData("channelData", [
            {'name': 'Channel1', 'unit': 'V', 'timestamps': [0.0], 'values': [1.0]},
            {'name': 'Channel2', 'unit': 'A', 'timestamps': [0.0], 'values': [2.0]}
        ])
        write_request.addData("writeMode", "create_new")
        
        self.send_request(client_socket, write_request)
        
        # 保存
        save_request = Request(RequestType.SAVE_FILE, file_id)
        self.send_request(client_socket, save_request)
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
        
        # 重新打开
        open_request = Request(RequestType.OPEN_FILE)
        open_request.addData("filePath", file_path)
        open_request.addData("createIfNotExists", False)
        
        open_response = self.send_request(client_socket, open_request)
        file_id = open_response.data['fileId']
        
        # 获取通道列表
        channels_request = Request(RequestType.GET_CHANNELS, file_id)
        channels_response = self.send_request(client_socket, channels_request)
        
        assert channels_response.status.value == 'success'
        assert 'channels' in channels_response.data
        assert len(channels_response.data['channels']) == 2
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
    
    def test_get_channel_info(self, client_socket, temp_dir):
        """测试获取通道详细信息"""
        file_path = os.path.join(temp_dir, "channel_info_test.mf4")
        
        # 创建文件
        create_request = Request(RequestType.CREATE_FILE)
        create_request.addData("filePath", file_path)
        create_request.addData("overwrite", True)
        
        create_response = self.send_request(client_socket, create_request)
        file_id = create_response.data['fileId']
        
        # 写入数据
        write_request = Request(RequestType.WRITE_DATA, file_id)
        write_request.addData("groupIndex", 0)
        write_request.addData("channelData", [{
            'name': 'InfoChannel',
            'unit': 'V',
            'timestamps': [0.0, 0.1, 0.2],
            'values': [1.0, 2.0, 3.0]
        }])
        write_request.addData("writeMode", "create_new")
        
        self.send_request(client_socket, write_request)
        
        # 保存
        save_request = Request(RequestType.SAVE_FILE, file_id)
        self.send_request(client_socket, save_request)
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
        
        # 重新打开
        open_request = Request(RequestType.OPEN_FILE)
        open_request.addData("filePath", file_path)
        open_request.addData("createIfNotExists", False)
        
        open_response = self.send_request(client_socket, open_request)
        file_id = open_response.data['fileId']
        
        # 获取通道详细信息
        info_request = Request(RequestType.GET_CHANNEL_INFO, file_id)
        info_request.addData("groupIndex", 0)
        info_request.addData("channelIndex", 0)
        
        info_response = self.send_request(client_socket, info_request)
        
        assert info_response.status.value == 'success'
        assert 'name' in info_response.data
        assert 'unit' in info_response.data
        assert info_response.data['name'] == 'InfoChannel'
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
    
    def test_find_channel(self, client_socket, temp_dir):
        """测试查找通道"""
        file_path = os.path.join(temp_dir, "find_test.mf4")
        
        # 创建文件
        create_request = Request(RequestType.CREATE_FILE)
        create_request.addData("filePath", file_path)
        create_request.addData("overwrite", True)
        
        create_response = self.send_request(client_socket, create_request)
        file_id = create_response.data['fileId']
        
        # 写入数据
        write_request = Request(RequestType.WRITE_DATA, file_id)
        write_request.addData("groupIndex", 0)
        write_request.addData("channelData", [
            {'name': 'Voltage_1', 'unit': 'V', 'timestamps': [0.0], 'values': [1.0]},
            {'name': 'Voltage_2', 'unit': 'V', 'timestamps': [0.0], 'values': [2.0]},
            {'name': 'Current_1', 'unit': 'A', 'timestamps': [0.0], 'values': [3.0]}
        ])
        write_request.addData("writeMode", "create_new")
        
        self.send_request(client_socket, write_request)
        
        # 保存
        save_request = Request(RequestType.SAVE_FILE, file_id)
        self.send_request(client_socket, save_request)
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
        
        # 重新打开
        open_request = Request(RequestType.OPEN_FILE)
        open_request.addData("filePath", file_path)
        open_request.addData("createIfNotExists", False)
        
        open_response = self.send_request(client_socket, open_request)
        file_id = open_response.data['fileId']
        
        # 查找通道
        find_request = Request(RequestType.FIND_CHANNEL, file_id)
        find_request.addData("channelName", "Voltage")
        
        find_response = self.send_request(client_socket, find_request)
        
        assert find_response.status.value == 'success'
        assert 'channels' in find_response.data
        assert len(find_response.data['channels']) == 2  # Voltage_1 and Voltage_2
        
        # 关闭
        close_request = Request(RequestType.CLOSE_FILE, file_id)
        self.send_request(client_socket, close_request)
    
    def test_get_memory_stats(self, client_socket):
        """测试获取内存统计"""
        request = Request(RequestType.GET_MEMORY_STATS)
        response = self.send_request(client_socket, request)
        
        assert response.status.value == 'success'
        assert 'openFiles' in response.data
        assert 'activeIterators' in response.data
