"""
协议模块测试
"""
import pytest
import json
from protocol import Request, Response, RequestType, ResponseStatus, ProtocolHelper


class TestRequest:
    """测试Request类"""
    
    def test_request_creation(self):
        """测试Request创建"""
        req = Request(RequestType.OPEN_FILE)
        assert req.request_type == RequestType.OPEN_FILE
        assert req.request_id is not None
        assert req.data == {}
    
    def test_request_to_dict(self):
        """测试Request转字典"""
        req = Request(RequestType.READ_DATA, file_id="test-file")
        req.addData("groupIndex", 0)
        req.addData("channelIndex", 1)
        
        data = req.to_dict()
        assert data['requestType'] == 'read_data'
        assert data['fileId'] == 'test-file'
        assert data['data']['groupIndex'] == 0
        assert data['data']['channelIndex'] == 1
    
    def test_request_from_json(self):
        """测试从JSON解析Request"""
        json_str = '{"requestType": "ping", "requestId": "123", "fileId": null, "data": {}}'
        req = Request.from_json(json_str)
        
        assert req.request_type == RequestType.PING
        assert req.request_id == "123"
    
    def test_request_all_types(self):
        """测试所有请求类型"""
        for req_type in RequestType:
            req = Request(req_type)
            assert req.request_type == req_type


class TestResponse:
    """测试Response类"""
    
    def test_response_success(self):
        """测试成功响应"""
        resp = Response.success("req-123", {"fileId": "test"})
        
        assert resp.request_id == "req-123"
        assert resp.status == ResponseStatus.SUCCESS
        assert resp.data['fileId'] == "test"
    
    def test_response_error(self):
        """测试错误响应"""
        resp = Response.error("req-123", "File not found")
        
        assert resp.request_id == "req-123"
        assert resp.status == ResponseStatus.ERROR
        assert resp.message == "File not found"
    
    def test_response_from_json(self):
        """测试从JSON解析Response"""
        json_str = '{"requestId": "123", "status": "success", "message": null, "data": {"pong": true}}'
        resp = Response.from_json(json_str)
        
        assert resp.request_id == "123"
        assert resp.status == ResponseStatus.SUCCESS
        assert resp.data['pong'] == True


class TestProtocolHelper:
    """测试ProtocolHelper类"""
    
    def test_encode_decode_message(self):
        """测试消息编码解码"""
        message = '{"test": "data"}'
        encoded = ProtocolHelper.encode_message(message)
        
        # 验证协议头
        assert encoded[:4] == b'MF4P'
        assert encoded[4] == 1  # version
        
        # 验证数据长度
        version, data_length = ProtocolHelper.decode_header(encoded[:12])
        assert version == 1
        assert data_length == len(message.encode('utf-8'))
