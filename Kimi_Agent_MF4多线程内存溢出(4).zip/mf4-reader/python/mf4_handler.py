"""
MF4文件处理模块 - 处理MF4文件的具体操作
支持多线程、大文件分段读取、extend追加数据、自动分片存储
"""
import os
import threading
import uuid
import gc
import re
from typing import Dict, List, Optional, Any, Iterator, Tuple
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

from asammdf import MDF, Signal

import logging

logger = logging.getLogger('mf4_server')


# 文件分片常量
SHARD_SIZE_LIMIT = 1024 * 1024 * 1024  # 1GB分片大小
SHARD_FILE_PATTERN = re.compile(r'(.+)\.shard(\d+)\.mf4$')  # 分片文件名模式


class WriteMode(Enum):
    """写入模式枚举"""
    APPEND = "append"          # 使用extend追加数据
    OVERWRITE = "overwrite"    # 覆盖现有通道
    CREATE_NEW = "create_new"  # 创建新通道（如果存在则报错）


@dataclass
class FileHandle:
    """文件句柄封装类"""
    file_id: str
    file_path: str
    mdf: MDF
    mode: str
    ref_count: int = 0
    lock: threading.RLock = None
    shards: List['FileShard'] = field(default_factory=list)  # 分片列表
    is_sharded: bool = False  # 是否已分片
    last_shard_mdf: Optional[MDF] = None  # 最后一个分片的MDF（用于extend）
    last_shard_path: Optional[str] = None  # 最后一个分片路径
    
    def __post_init__(self):
        if self.lock is None:
            self.lock = threading.RLock()


@dataclass
class FileShard:
    """文件分片信息"""
    index: int  # 分片索引
    file_path: str  # 分片文件路径
    start_time: float  # 起始时间戳
    end_time: float  # 结束时间戳
    sample_count: int  # 样本数
    mdf: Optional[MDF] = None  # 懒加载的MDF对象


class FileShardManager:
    """文件分片管理器 - 处理大文件的自动分片存储"""
    
    def __init__(self, shard_size_limit: int = SHARD_SIZE_LIMIT):
        self.shard_size_limit = shard_size_limit
        self._shard_cache: Dict[str, MDF] = {}  # 分片MDF缓存
        self._cache_lock = threading.RLock()
    
    def get_base_path(self, file_path: str) -> str:
        """获取基础路径（去除分片后缀）"""
        match = SHARD_FILE_PATTERN.match(file_path)
        if match:
            return match.group(1) + '.mf4'
        return file_path
    
    def get_shard_path(self, base_path: str, shard_index: int) -> str:
        """获取分片文件路径"""
        base, ext = os.path.splitext(base_path)
        return f"{base}.shard{shard_index}{ext}"
    
    def discover_shards(self, base_path: str) -> List[FileShard]:
        """发现并加载所有分片文件"""
        shards = []
        base_dir = os.path.dirname(base_path) or '.'
        base_name = os.path.basename(base_path)
        base_name_no_ext = os.path.splitext(base_name)[0]
        
        # 查找所有分片文件
        if os.path.exists(base_dir):
            for filename in os.listdir(base_dir):
                match = SHARD_FILE_PATTERN.match(filename)
                if match and match.group(1).endswith(base_name_no_ext):
                    shard_path = os.path.join(base_dir, filename)
                    shard_index = int(match.group(2))
                    
                    try:
                        mdf = MDF(shard_path)
                        # 获取时间范围
                        start_time = float('inf')
                        end_time = float('-inf')
                        total_samples = 0
                        
                        if hasattr(mdf, 'groups') and mdf.groups:
                            for group in mdf.groups:
                                if hasattr(group, 'channels') and group.channels:
                                    for ch in group.channels:
                                        try:
                                            sig = mdf.get(group=mdf.groups.index(group), 
                                                         index=group.channels.index(ch), 
                                                         samples_only=False)
                                            if hasattr(sig, 'timestamps') and len(sig.timestamps) > 0:
                                                start_time = min(start_time, sig.timestamps[0])
                                                end_time = max(end_time, sig.timestamps[-1])
                                                total_samples += len(sig.timestamps)
                                        except:
                                            pass
                        
                        shard = FileShard(
                            index=shard_index,
                            file_path=shard_path,
                            start_time=start_time if start_time != float('inf') else 0,
                            end_time=end_time if end_time != float('-inf') else 0,
                            sample_count=total_samples
                        )
                        shards.append(shard)
                        mdf.close()
                        
                    except Exception as e:
                        logger.warning(f"Failed to load shard {shard_path}: {e}")
        
        # 按索引排序
        shards.sort(key=lambda s: s.index)
        return shards
    
    def check_need_sharding(self, handle: FileHandle) -> bool:
        """检查是否需要分片"""
        if handle.is_sharded:
            return False
        
        try:
            # 估算当前文件大小
            total_samples = 0
            if hasattr(handle.mdf, 'groups'):
                for group in handle.mdf.groups:
                    if hasattr(group, 'channels'):
                        for ch in group.channels:
                            try:
                                sig = handle.mdf.get(group=handle.mdf.groups.index(group),
                                                    index=group.channels.index(ch),
                                                    samples_only=True)
                                if hasattr(sig, 'timestamps'):
                                    total_samples += len(sig.timestamps)
                            except:
                                pass
            
            # 估算大小：每个样本约16字节（8字节timestamp + 8字节value）
            estimated_size = total_samples * 16
            return estimated_size >= self.shard_size_limit
            
        except Exception as e:
            logger.warning(f"Error checking sharding need: {e}")
            return False
    
    def create_shards(self, handle: FileHandle) -> bool:
        """将文件分片存储"""
        if handle.is_sharded:
            return True
        
        try:
            base_path = self.get_base_path(handle.file_path)
            shards = []
            shard_index = 0
            
            # 按通道组和时间范围分片
            if hasattr(handle.mdf, 'groups'):
                for group_idx, group in enumerate(handle.mdf.groups):
                    if not hasattr(group, 'channels') or not group.channels:
                        continue
                    
                    # 计算每个分片的样本数
                    total_samples = 0
                    for ch_idx in range(len(group.channels)):
                        try:
                            sig = handle.mdf.get(group=group_idx, index=ch_idx, samples_only=True)
                            if hasattr(sig, 'timestamps'):
                                total_samples = max(total_samples, len(sig.timestamps))
                        except:
                            pass
                    
                    if total_samples == 0:
                        continue
                    
                    # 计算分片数量
                    samples_per_shard = self.shard_size_limit // (len(group.channels) * 16)
                    num_shards = max(1, (total_samples + samples_per_shard - 1) // samples_per_shard)
                    
                    for shard_idx in range(num_shards):
                        start_sample = shard_idx * samples_per_shard
                        end_sample = min((shard_idx + 1) * samples_per_shard, total_samples)
                        
                        # 创建分片MDF
                        shard_mdf = MDF(version='4.11')
                        shard_signals = []
                        
                        for ch_idx in range(len(group.channels)):
                            try:
                                sig = handle.mdf.get(group=group_idx, index=ch_idx, samples_only=False)
                                if hasattr(sig, 'timestamps') and len(sig.timestamps) > 0:
                                    # 截取分片范围的数据
                                    ts = sig.timestamps[start_sample:end_sample]
                                    vals = sig.samples[start_sample:end_sample]
                                    
                                    shard_sig = Signal(
                                        samples=vals,
                                        timestamps=ts,
                                        name=sig.name,
                                        unit=sig.unit if hasattr(sig, 'unit') else '',
                                        comment=sig.comment if hasattr(sig, 'comment') else ''
                                    )
                                    shard_signals.append(shard_sig)
                            except Exception as e:
                                logger.warning(f"Error processing channel {ch_idx} for shard: {e}")
                        
                        if shard_signals:
                            shard_mdf.append(shard_signals, comment=f"Shard {shard_idx}")
                            
                            shard_path = self.get_shard_path(base_path, shard_index)
                            shard_mdf.save(shard_path, overwrite=True)
                            shard_mdf.close()
                            
                            # 获取分片的时间范围
                            start_time = min(sig.timestamps[0] for sig in shard_signals)
                            end_time = max(sig.timestamps[-1] for sig in shard_signals)
                            
                            shard = FileShard(
                                index=shard_index,
                                file_path=shard_path,
                                start_time=start_time,
                                end_time=end_time,
                                sample_count=end_sample - start_sample
                            )
                            shards.append(shard)
                            shard_index += 1
                            
                            del shard_signals
                            gc.collect()
            
            if shards:
                handle.shards = shards
                handle.is_sharded = True
                logger.info(f"Created {len(shards)} shards for {base_path}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error creating shards: {e}")
            return False
    
    def get_shard_for_time(self, handle: FileHandle, timestamp: float) -> Optional[FileShard]:
        """根据时间戳获取对应的分片"""
        if not handle.is_sharded:
            return None
        
        for shard in handle.shards:
            if shard.start_time <= timestamp <= shard.end_time:
                return shard
        
        # 返回最接近的分片
        if handle.shards:
            if timestamp < handle.shards[0].start_time:
                return handle.shards[0]
            if timestamp > handle.shards[-1].end_time:
                return handle.shards[-1]
        
        return None
    
    def get_shards_for_range(self, handle: FileHandle, start: float, end: float) -> List[FileShard]:
        """获取时间范围内的所有分片"""
        if not handle.is_sharded:
            return []
        
        result = []
        for shard in handle.shards:
            # 检查分片时间范围是否与查询范围重叠
            if not (shard.end_time < start or shard.start_time > end):
                result.append(shard)
        
        return result
    
    def load_shard_mdf(self, shard: FileShard) -> MDF:
        """懒加载分片的MDF对象"""
        with self._cache_lock:
            if shard.file_path not in self._shard_cache:
                self._shard_cache[shard.file_path] = MDF(shard.file_path)
            return self._shard_cache[shard.file_path]
    
    def close_shard_cache(self):
        """关闭所有缓存的分片MDF"""
        with self._cache_lock:
            for mdf in self._shard_cache.values():
                try:
                    mdf.close()
                except:
                    pass
            self._shard_cache.clear()
    
    def get_last_shard_for_append(self, handle: FileHandle) -> Optional[Tuple[str, MDF]]:
        """获取最后一个分片用于追加数据（extend）"""
        if not handle.is_sharded or not handle.shards:
            return None
        
        last_shard = handle.shards[-1]
        
        # 如果handle已经加载了last_shard_mdf，直接使用
        if handle.last_shard_mdf is not None and handle.last_shard_path == last_shard.file_path:
            return (handle.last_shard_path, handle.last_shard_mdf)
        
        # 检查最后一个分片是否还能容纳更多数据（小于1GB）
        try:
            if os.path.exists(last_shard.file_path):
                file_size = os.path.getsize(last_shard.file_path)
                if file_size < self.shard_size_limit * 0.9:  # 小于90%容量可以追加
                    # 加载或获取MDF
                    mdf = self.load_shard_mdf(last_shard)
                    # 更新handle的last_shard_mdf
                    handle.last_shard_mdf = mdf
                    handle.last_shard_path = last_shard.file_path
                    return (last_shard.file_path, mdf)
        except Exception as e:
            logger.warning(f"Error checking last shard: {e}")
        
        return None
    
    def create_new_shard_for_append(self, handle: FileHandle) -> Optional[Tuple[str, MDF]]:
        """创建新的分片用于追加数据"""
        new_index = len(handle.shards)
        shard_path = self.get_shard_path(handle.file_path, new_index)
        
        try:
            mdf = MDF(version='4.11')
            
            new_shard = FileShard(
                index=new_index,
                file_path=shard_path,
                start_time=0,
                end_time=0,
                sample_count=0
            )
            handle.shards.append(new_shard)
            
            return (shard_path, mdf)
        except Exception as e:
            logger.error(f"Error creating new shard: {e}")
            return None


class DataChunker:
    """数据分块器 - 将大数据分割成小块，控制内存使用"""
    
    DEFAULT_SAMPLES_PER_CHUNK = 50000  # 每块5万样本
    DEFAULT_BYTES_PER_CHUNK = 5 * 1024 * 1024  # 每块5MB
    
    def __init__(self, samples_per_chunk: int = None, bytes_per_chunk: int = None):
        self.samples_per_chunk = samples_per_chunk or self.DEFAULT_SAMPLES_PER_CHUNK
        self.bytes_per_chunk = bytes_per_chunk or self.DEFAULT_BYTES_PER_CHUNK
    
    def estimate_chunk_size(self, sample_count: int, dtype_size: int = 8) -> int:
        """估算合适的分块大小"""
        samples_limit = self.samples_per_chunk
        bytes_per_sample = dtype_size * 2
        memory_limit = self.bytes_per_chunk // bytes_per_sample
        return min(samples_limit, memory_limit, sample_count)
    
    def create_iterator(self, handle: FileHandle, group_index: int, channel_index: int,
                        start: float = None, end: float = None,
                        samples: int = None) -> Iterator[Dict[str, Any]]:
        """创建数据迭代器 - 惰性加载数据"""
        try:
            signal = handle.mdf.get(
                group=group_index,
                index=channel_index,
                samples_only=False
            )
            
            timestamps = signal.timestamps
            values = signal.samples
            
            if start is not None or end is not None:
                mask = np.ones(len(timestamps), dtype=bool)
                if start is not None:
                    mask &= timestamps >= start
                if end is not None:
                    mask &= timestamps <= end
                timestamps = timestamps[mask]
                values = values[mask]
                del mask
            
            if samples is not None and len(timestamps) > samples:
                timestamps = timestamps[:samples]
                values = values[:samples]
            
            total_samples = len(timestamps)
            chunk_size = self.estimate_chunk_size(total_samples)
            
            name = signal.name
            unit = signal.unit if hasattr(signal, 'unit') else ''
            total_chunks = (total_samples + chunk_size - 1) // chunk_size
            
            for i in range(0, total_samples, chunk_size):
                end_idx = min(i + chunk_size, total_samples)
                
                chunk = {
                    'timestamps': timestamps[i:end_idx].tolist(),
                    'values': values[i:end_idx].tolist() if not isinstance(values[i:end_idx], np.ndarray) 
                             else values[i:end_idx].tolist(),
                    'name': name,
                    'unit': unit,
                    'sampleCount': end_idx - i,
                    'chunkIndex': i // chunk_size,
                    'totalChunks': total_chunks,
                    'startOffset': i
                }
                
                yield chunk
                
                if i // chunk_size % 10 == 0:
                    gc.collect()
                    
        except Exception as e:
            logger.error(f"Error creating iterator: {e}")
            raise


class Mf4FileManager:
    """MF4文件管理器 - 内存限制300MB，支持自动分片"""
    
    DEFAULT_MAX_SAMPLES_PER_READ = 500000  # 单次最大读取50万样本
    DEFAULT_MAX_BYTES_PER_READ = 50 * 1024 * 1024  # 单次最大50MB
    MEMORY_LIMIT_MB = 300  # 内存限制300MB
    SHARD_SIZE_LIMIT = 1024 * 1024 * 1024  # 1GB分片大小
    
    def __init__(self, max_memory_mb: int = 300):
        self._files: Dict[str, FileHandle] = {}
        self._path_to_ids: Dict[str, set] = {}
        self._global_lock = threading.RLock()
        self._chunker = DataChunker()
        self._iterators: Dict[str, Iterator] = {}
        self._iterator_lock = threading.RLock()
        self._max_memory_mb = max_memory_mb
        self._shard_manager = FileShardManager(self.SHARD_SIZE_LIMIT)
    
    def _check_memory(self, operation: str = "") -> bool:
        """检查内存使用情况，超过阈值时触发GC"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            rss_mb = memory_info.rss / 1024 / 1024
            
            if rss_mb > self._max_memory_mb * 0.9:  # 超过90%触发GC
                logger.warning(f"Memory high ({rss_mb:.1f}MB) before {operation}, triggering GC")
                gc.collect()
                
                # 再次检查
                memory_info = process.memory_info()
                rss_mb = memory_info.rss / 1024 / 1024
                
                if rss_mb > self._max_memory_mb:
                    logger.error(f"Memory limit exceeded: {rss_mb:.1f}MB > {self._max_memory_mb}MB")
                    return False
            
            return True
        except ImportError:
            return True
    
    def open_file(self, file_path: str, mode: str = 'r', create_if_not_exists: bool = False) -> str:
        """打开MF4文件 - 自动检测和加载分片"""
        with self._global_lock:
            # 获取基础路径（去除分片后缀）
            base_path = self._shard_manager.get_base_path(file_path)
            file_exists = os.path.exists(file_path)
            
            # 检查是否存在分片文件
            shards = []
            if mode == 'r' or (mode == 'rw' and not file_exists and create_if_not_exists):
                shards = self._shard_manager.discover_shards(base_path)
            
            if not file_exists and mode == 'r' and not create_if_not_exists and not shards:
                raise FileNotFoundError(f"File not found: {file_path}")
            
            # 检查是否已打开（使用base_path）
            if base_path in self._path_to_ids:
                for fid in self._path_to_ids[base_path]:
                    handle = self._files.get(fid)
                    if handle and handle.mode == mode:
                        with handle.lock:
                            handle.ref_count += 1
                        logger.info(f"Reused file handle: {fid}, ref_count: {handle.ref_count}")
                        return fid
            
            file_id = str(uuid.uuid4())
            
            try:
                if mode == 'w' or (mode == 'rw' and not file_exists and create_if_not_exists and not shards):
                    mdf = MDF(version='4.11')
                else:
                    mdf = MDF(file_path)
                
                # 如果是分片文件且是写模式，加载最后一个分片的MDF用于extend
                last_shard_mdf = None
                last_shard_path = None
                if shards and mode in ('w', 'rw'):
                    last_shard = shards[-1]
                    try:
                        last_shard_mdf = MDF(last_shard.file_path)
                        last_shard_path = last_shard.file_path
                        logger.info(f"Loaded last shard for extend: {last_shard_path}")
                    except Exception as e:
                        logger.warning(f"Could not load last shard: {e}")
                
                handle = FileHandle(
                    file_id=file_id,
                    file_path=base_path,
                    mdf=mdf,
                    mode=mode,
                    shards=shards,
                    is_sharded=len(shards) > 0,
                    last_shard_mdf=last_shard_mdf,
                    last_shard_path=last_shard_path
                )
                handle.ref_count = 1
                
                self._files[file_id] = handle
                
                if base_path not in self._path_to_ids:
                    self._path_to_ids[base_path] = set()
                self._path_to_ids[base_path].add(file_id)
                
                if shards:
                    logger.info(f"Opened sharded file: {base_path}, {len(shards)} shards, mode: {mode}, file_id: {file_id}")
                else:
                    logger.info(f"Opened file: {file_path}, mode: {mode}, file_id: {file_id}")
                return file_id
                
            except Exception as e:
                logger.error(f"Failed to open file {file_path}: {e}")
                raise
    
    def close_file(self, file_id: str) -> bool:
        """关闭文件"""
        with self._global_lock:
            handle = self._files.get(file_id)
            if not handle:
                logger.warning(f"File not found for closing: {file_id}")
                return False
            
            with handle.lock:
                handle.ref_count -= 1
                
                if handle.ref_count <= 0:
                    try:
                        handle.mdf.close()
                        # 关闭最后一个分片的MDF（如果已加载）
                        if handle.last_shard_mdf is not None:
                            try:
                                handle.last_shard_mdf.close()
                                logger.info(f"Closed last shard MDF: {handle.last_shard_path}")
                            except Exception as e:
                                logger.warning(f"Error closing last shard MDF: {e}")
                        logger.info(f"Closed file: {handle.file_path}, file_id: {file_id}")
                    except Exception as e:
                        logger.error(f"Error closing file {file_id}: {e}")
                    finally:
                        del self._files[file_id]
                        self._path_to_ids[handle.file_path].discard(file_id)
                        if not self._path_to_ids[handle.file_path]:
                            del self._path_to_ids[handle.file_path]
                        
                        with self._iterator_lock:
                            iterator_keys = [k for k in self._iterators.keys() if k.startswith(file_id)]
                            for key in iterator_keys:
                                del self._iterators[key]
                        
                        gc.collect()
                else:
                    logger.info(f"Decreased ref_count for {file_id}: {handle.ref_count}")
            
            return True
    
    def get_file_info(self, file_id: str) -> Dict[str, Any]:
        """获取文件信息 - 包含分片信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            info = {
                'filePath': handle.file_path,
                'mode': handle.mode,
                'version': handle.mdf.version_str if hasattr(handle.mdf, 'version_str') else 'unknown',
                'channelCount': len(handle.mdf.channels_db) if hasattr(handle.mdf, 'channels_db') else 0,
                'isSharded': handle.is_sharded,
            }
            
            # 添加分片信息
            if handle.is_sharded and handle.shards:
                info['shardCount'] = len(handle.shards)
                info['shards'] = [
                    {
                        'index': s.index,
                        'startTime': s.start_time,
                        'endTime': s.end_time,
                        'sampleCount': s.sample_count
                    }
                    for s in handle.shards
                ]
            
            groups = []
            if hasattr(handle.mdf, 'groups'):
                for i, group in enumerate(handle.mdf.groups):
                    group_info = {
                        'index': i,
                        'channelCount': len(group.channels) if hasattr(group, 'channels') else 0
                    }
                    groups.append(group_info)
            
            info['groups'] = groups
            return info
    
    def get_channels(self, file_id: str, group_index: int = None) -> List[Dict[str, Any]]:
        """获取通道列表"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            channels = []
            
            if hasattr(handle.mdf, 'groups'):
                groups_to_process = [handle.mdf.groups[group_index]] if group_index is not None else handle.mdf.groups
                
                for g_idx, group in enumerate(groups_to_process):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            ch_info = {
                                'name': channel.name if hasattr(channel, 'name') else f'Channel_{c_idx}',
                                'groupIndex': g_idx if group_index is None else group_index,
                                'channelIndex': c_idx,
                            }
                            
                            if hasattr(channel, 'unit'):
                                ch_info['unit'] = channel.unit
                            if hasattr(channel, 'comment'):
                                ch_info['comment'] = str(channel.comment) if channel.comment else ''
                            
                            channels.append(ch_info)
            
            return channels
    
    def get_channel_info(self, file_id: str, group_index: int, channel_index: int) -> Dict[str, Any]:
        """获取指定通道的详细信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            if not hasattr(handle.mdf, 'groups'):
                raise ValueError("File has no channel groups")
            
            if group_index >= len(handle.mdf.groups):
                raise ValueError(f"Group index {group_index} out of range")
            
            group = handle.mdf.groups[group_index]
            
            if not hasattr(group, 'channels'):
                raise ValueError("Group has no channels")
            
            if channel_index >= len(group.channels):
                raise ValueError(f"Channel index {channel_index} out of range")
            
            channel = group.channels[channel_index]
            
            info = {
                'name': channel.name if hasattr(channel, 'name') else f'Channel_{channel_index}',
                'groupIndex': group_index,
                'channelIndex': channel_index,
            }
            
            if hasattr(channel, 'unit'):
                info['unit'] = channel.unit
            if hasattr(channel, 'comment'):
                info['comment'] = str(channel.comment) if channel.comment else ''
            if hasattr(channel, 'dtype'):
                info['dataType'] = str(channel.dtype)
            if hasattr(channel, 'conversion') and channel.conversion is not None:
                info['conversion'] = str(channel.conversion)
            
            try:
                signal = handle.mdf.get(group=group_index, index=channel_index, samples_only=False)
                if signal is not None:
                    if hasattr(signal, 'timestamps') and len(signal.timestamps) > 0:
                        info['startTime'] = float(signal.timestamps[0])
                        info['endTime'] = float(signal.timestamps[-1])
                        info['sampleCount'] = len(signal.timestamps)
            except Exception as e:
                logger.warning(f"Could not get signal info: {e}")
            
            return info
    
    def find_channel(self, file_id: str, channel_name: str) -> List[Dict[str, Any]]:
        """根据名称查找通道"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            results = []
            
            if hasattr(handle.mdf, 'groups'):
                for g_idx, group in enumerate(handle.mdf.groups):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            name = channel.name if hasattr(channel, 'name') else ''
                            
                            if channel_name.lower() in name.lower():
                                ch_info = {
                                    'name': name,
                                    'groupIndex': g_idx,
                                    'channelIndex': c_idx,
                                }
                                
                                if hasattr(channel, 'unit'):
                                    ch_info['unit'] = channel.unit
                                if hasattr(channel, 'comment'):
                                    ch_info['comment'] = str(channel.comment) if channel.comment else ''
                                
                                results.append(ch_info)
            
            return results
    
    def _find_channel_in_group(self, handle: FileHandle, group_index: int, channel_name: str) -> Tuple[bool, int]:
        """在指定组中查找通道"""
        if not hasattr(handle.mdf, 'groups'):
            return False, -1
        
        if group_index >= len(handle.mdf.groups):
            return False, -1
        
        group = handle.mdf.groups[group_index]
        if not hasattr(group, 'channels'):
            return False, -1
        
        for idx, channel in enumerate(group.channels):
            name = channel.name if hasattr(channel, 'name') else ''
            if name == channel_name:
                return True, idx
        
        return False, -1
    
    def _read_from_shards(self, handle: FileHandle, group_index: int, channel_index: int,
                          start: float, end: float, samples: int) -> Dict[str, Any]:
        """从分片文件中读取数据并合并"""
        if not handle.is_sharded or not handle.shards:
            return None
        
        # 获取需要读取的分片
        shards_to_read = self._shard_manager.get_shards_for_range(handle, start, end) if (start is not None or end is not None) else handle.shards
        
        if not shards_to_read:
            shards_to_read = handle.shards
        
        all_timestamps = []
        all_values = []
        channel_name = None
        channel_unit = ''
        
        for shard in shards_to_read:
            try:
                shard_mdf = self._shard_manager.load_shard_mdf(shard)
                
                if group_index < len(shard_mdf.groups):
                    group = shard_mdf.groups[group_index]
                    if channel_index is not None and channel_index < len(group.channels):
                        signal = shard_mdf.get(group=group_index, index=channel_index, samples_only=False)
                        
                        if signal is not None:
                            timestamps = signal.timestamps
                            values = signal.samples
                            
                            # 应用时间范围过滤
                            if start is not None or end is not None:
                                mask = np.ones(len(timestamps), dtype=bool)
                                if start is not None:
                                    mask &= timestamps >= start
                                if end is not None:
                                    mask &= timestamps <= end
                                timestamps = timestamps[mask]
                                values = values[mask]
                            
                            all_timestamps.append(timestamps)
                            all_values.append(values)
                            
                            if channel_name is None:
                                channel_name = signal.name
                                channel_unit = signal.unit if hasattr(signal, 'unit') else ''
                            
                            del timestamps, values
                            if len(all_timestamps) % 5 == 0:
                                gc.collect()
            except Exception as e:
                logger.warning(f"Error reading from shard {shard.file_path}: {e}")
        
        if not all_timestamps:
            return {
                'timestamps': [],
                'values': [],
                'name': channel_name or 'Unknown',
                'unit': channel_unit,
                'sampleCount': 0,
                'hasMore': False
            }
        
        # 合并所有分片的数据
        merged_timestamps = np.concatenate(all_timestamps)
        merged_values = np.concatenate(all_values)
        
        # 按时间戳排序
        sort_indices = np.argsort(merged_timestamps)
        merged_timestamps = merged_timestamps[sort_indices]
        merged_values = merged_values[sort_indices]
        
        # 应用样本数限制
        if samples is not None and len(merged_timestamps) > samples:
            merged_timestamps = merged_timestamps[:samples]
            merged_values = merged_values[:samples]
        
        result = {
            'timestamps': merged_timestamps.tolist(),
            'values': merged_values.tolist() if not isinstance(merged_values, np.ndarray) else merged_values.tolist(),
            'name': channel_name or 'Unknown',
            'unit': channel_unit,
            'sampleCount': len(merged_timestamps),
            'hasMore': False,
            'isSharded': True,
            'shardCount': len(shards_to_read)
        }
        
        del all_timestamps, all_values, merged_timestamps, merged_values
        gc.collect()
        
        return result
    
    def read_data(self, file_id: str, group_index: int, channel_index: int = None,
                  start: float = None, end: float = None, 
                  samples: int = None, use_iterator: bool = False) -> Dict[str, Any]:
        """读取数据 - 带内存保护，支持分片文件"""
        if not self._check_memory("read_data"):
            raise MemoryError("Memory limit exceeded (300MB), cannot read data")
        
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if samples is None or samples > self.DEFAULT_MAX_SAMPLES_PER_READ:
            samples = self.DEFAULT_MAX_SAMPLES_PER_READ
        
        with handle.lock:
            try:
                # 如果是分片文件，使用分片读取逻辑
                if handle.is_sharded and channel_index is not None:
                    result = self._read_from_shards(handle, group_index, channel_index, start, end, samples)
                    if result is not None:
                        return result
                
                if use_iterator:
                    iterator_id = f"{file_id}_{group_index}_{channel_index}_{uuid.uuid4().hex[:8]}"
                    iterator = self._chunker.create_iterator(
                        handle, group_index, channel_index, start, end, samples
                    )
                    
                    with self._iterator_lock:
                        self._iterators[iterator_id] = iterator
                    
                    try:
                        first_chunk = next(iterator)
                        first_chunk['iteratorId'] = iterator_id
                        first_chunk['hasMore'] = True
                        return first_chunk
                    except StopIteration:
                        return {
                            'iteratorId': iterator_id,
                            'hasMore': False,
                            'sampleCount': 0
                        }
                
                if channel_index is not None:
                    signal = handle.mdf.get(
                        group=group_index,
                        index=channel_index,
                        samples_only=False
                    )
                    
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                        del mask
                    
                    if samples is not None and len(timestamps) > samples:
                        timestamps = timestamps[:samples]
                        values = values[:samples]
                    
                    total_samples = len(timestamps)
                    estimated_bytes = total_samples * 16
                    
                    if estimated_bytes > self.DEFAULT_MAX_BYTES_PER_READ:
                        chunk_samples = self.DEFAULT_MAX_BYTES_PER_READ // 16
                        total_chunks = (total_samples + chunk_samples - 1) // chunk_samples
                        
                        end_idx = min(chunk_samples, total_samples)
                        first_chunk = {
                            'timestamps': timestamps[:end_idx].tolist(),
                            'values': values[:end_idx].tolist() if not isinstance(values, np.ndarray) 
                                     else values[:end_idx].tolist(),
                            'name': signal.name,
                            'unit': signal.unit if hasattr(signal, 'unit') else '',
                            'sampleCount': end_idx,
                            'chunkIndex': 0,
                            'totalChunks': total_chunks,
                            'hasMore': total_chunks > 1,
                            'startOffset': 0,
                            'totalSamples': total_samples
                        }
                        
                        del timestamps
                        del values
                        gc.collect()
                        
                        return first_chunk
                    
                    result = {
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps),
                        'hasMore': False
                    }
                    
                    del timestamps
                    del values
                    gc.collect()
                    
                    return result
                else:
                    group_data = []
                    total_samples = 0
                    
                    if group_index < len(handle.mdf.groups):
                        group = handle.mdf.groups[group_index]
                        if hasattr(group, 'channels'):
                            max_channels = 10
                            channels_to_read = min(len(group.channels), max_channels)
                            
                            for idx in range(channels_to_read):
                                signal = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                
                                timestamps = signal.timestamps
                                values = signal.samples
                                
                                if start is not None or end is not None:
                                    mask = np.ones(len(timestamps), dtype=bool)
                                    if start is not None:
                                        mask &= timestamps >= start
                                    if end is not None:
                                        mask &= timestamps <= end
                                    timestamps = timestamps[mask]
                                    values = values[mask]
                                    del mask
                                
                                if samples is not None and len(timestamps) > samples:
                                    timestamps = timestamps[:samples]
                                    values = values[:samples]
                                
                                channel_samples = len(timestamps)
                                total_samples += channel_samples
                                
                                group_data.append({
                                    'timestamps': timestamps.tolist(),
                                    'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                                    'name': signal.name,
                                    'unit': signal.unit if hasattr(signal, 'unit') else '',
                                    'sampleCount': channel_samples
                                })
                                
                                if idx % 5 == 0:
                                    gc.collect()
                    
                    result = {
                        'groupIndex': group_index,
                        'channels': group_data,
                        'channelCount': len(group_data),
                        'totalSamples': total_samples,
                        'hasMore': False
                    }
                    
                    gc.collect()
                    return result
                    
            except Exception as e:
                logger.error(f"Error reading data from file {file_id}: {e}")
                raise
    
    def read_next_chunk(self, iterator_id: str) -> Optional[Dict[str, Any]]:
        """读取迭代器的下一个数据块"""
        with self._iterator_lock:
            iterator = self._iterators.get(iterator_id)
            if iterator is None:
                raise ValueError(f"Iterator not found: {iterator_id}")
            
            try:
                chunk = next(iterator)
                chunk['iteratorId'] = iterator_id
                chunk['hasMore'] = True
                return chunk
            except StopIteration:
                del self._iterators[iterator_id]
                gc.collect()
                return {
                    'iteratorId': iterator_id,
                    'hasMore': False,
                    'sampleCount': 0
                }
    
    def close_iterator(self, iterator_id: str):
        """关闭迭代器"""
        with self._iterator_lock:
            if iterator_id in self._iterators:
                del self._iterators[iterator_id]
                gc.collect()
    
    def _write_channel_append(self, handle: FileHandle, group_index: int, 
                               channel_data: Dict[str, Any], batch_size: int) -> Dict[str, Any]:
        """
        简化写入逻辑：
        - 通道不存在时使用append创建新通道
        - 通道已存在时使用extend追加数据
        """
        channel_name = channel_data['name']
        timestamps = np.array(channel_data['timestamps'])
        values = np.array(channel_data['values'])
        unit = channel_data.get('unit', '')
        comment = channel_data.get('comment', '')
        
        # 检查通道是否已存在
        exists, existing_idx = self._find_channel_in_group(handle, group_index, channel_name)
        
        result = {
            'name': channel_name,
            'action': 'unknown',
            'sampleCount': len(timestamps)
        }
        
        # 确定要使用的MDF对象（主文件或最后一个分片）
        target_mdf = handle.mdf
        target_path = handle.file_path
        is_shard = False
        
        # 如果是分片文件，获取最后一个分片用于追加
        if handle.is_sharded:
            last_shard_info = self._shard_manager.get_last_shard_for_append(handle)
            if last_shard_info:
                target_path, target_mdf = last_shard_info
                is_shard = True
                logger.debug(f"Using last shard for append: {target_path}")
            else:
                # 最后一个分片已满，创建新分片
                new_shard_info = self._shard_manager.create_new_shard_for_append(handle)
                if new_shard_info:
                    target_path, target_mdf = new_shard_info
                    is_shard = True
                    logger.info(f"Created new shard for append: {target_path}")
        
        if exists:
            # 通道已存在，使用extend追加
            logger.info(f"Channel '{channel_name}' exists, using extend to append {len(timestamps)} samples")
            
            try:
                # 创建新信号
                new_signal = Signal(
                    samples=values,
                    timestamps=timestamps,
                    name=channel_name,
                    unit=unit,
                    comment=comment
                )
                
                # 使用extend追加到目标MDF
                target_mdf.extend(group_index, [new_signal])
                
                # 保存分片文件
                if is_shard:
                    target_mdf.save(target_path, overwrite=True)
                
                result['action'] = 'extended'
                result['newSamples'] = len(timestamps)
                
                del new_signal
                gc.collect()
                
            except Exception as e:
                logger.error(f"Extend failed for channel '{channel_name}': {e}")
                # 如果extend失败，回退到重建方式
                logger.info(f"Falling back to rebuild for channel '{channel_name}'")
                return self._write_channel_rebuild(handle, group_index, channel_data, existing_idx)
        else:
            # 通道不存在，使用append创建
            logger.info(f"Channel '{channel_name}' not exists, using append to create {len(timestamps)} samples")
            
            if len(timestamps) > batch_size:
                # 大批量数据分批写入
                logger.info(f"Large write ({len(timestamps)} samples), processing in batches of {batch_size}")
                
                for i in range(0, len(timestamps), batch_size):
                    end_idx = min(i + batch_size, len(timestamps))
                    
                    batch_signal = Signal(
                        samples=values[i:end_idx],
                        timestamps=timestamps[i:end_idx],
                        name=channel_name,
                        unit=unit,
                        comment=comment if i == 0 else f"{comment} (batch {i//batch_size})"
                    )
                    
                    target_mdf.append([batch_signal], comment=f"Batch {i//batch_size}")
                    
                    del batch_signal
                    if i // batch_size % 10 == 0:
                        gc.collect()
            else:
                # 小批量数据直接写入
                new_signal = Signal(
                    samples=values,
                    timestamps=timestamps,
                    name=channel_name,
                    unit=unit,
                    comment=comment
                )
                target_mdf.append([new_signal], comment=comment or 'Written by mf4_server')
                del new_signal
            
            # 保存分片文件
            if is_shard:
                target_mdf.save(target_path, overwrite=True)
            
            result['action'] = 'appended'
        
        return result
    
    def _write_channel_rebuild(self, handle: FileHandle, group_index: int,
                                channel_data: Dict[str, Any], existing_idx: int) -> Dict[str, Any]:
        """
        重建方式写入（当extend失败时使用）
        读取现有数据，合并新数据，然后重新写入
        """
        channel_name = channel_data['name']
        new_timestamps = np.array(channel_data['timestamps'])
        new_values = np.array(channel_data['values'])
        
        logger.info(f"Rebuilding channel '{channel_name}' with merged data")
        
        # 读取现有数据
        existing_signal = handle.mdf.get(group=group_index, index=existing_idx, samples_only=False)
        existing_timestamps = existing_signal.timestamps
        existing_values = existing_signal.samples
        
        # 合并数据
        combined_timestamps = np.concatenate([existing_timestamps, new_timestamps])
        combined_values = np.concatenate([existing_values, new_values])
        
        # 按时间戳排序
        sort_indices = np.argsort(combined_timestamps)
        combined_timestamps = combined_timestamps[sort_indices]
        combined_values = combined_values[sort_indices]
        
        # 读取组内所有通道
        existing_signals = []
        group = handle.mdf.groups[group_index]
        for idx in range(len(group.channels)):
            if idx != existing_idx:
                try:
                    sig = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                    existing_signals.append(sig)
                except Exception as e:
                    logger.warning(f"Could not read channel {idx}: {e}")
        
        # 创建合并后的信号
        combined_signal = Signal(
            samples=combined_values,
            timestamps=combined_timestamps,
            name=channel_name,
            unit=existing_signal.unit if hasattr(existing_signal, 'unit') else '',
            comment=channel_data.get('comment', '')
        )
        existing_signals.append(combined_signal)
        
        # 保存并重新打开
        temp_path = handle.file_path + ".tmp"
        handle.mdf.save(temp_path, overwrite=True)
        handle.mdf.close()
        
        new_mdf = MDF(version='4.11')
        new_mdf.append(existing_signals, comment=f"Rebuilt channel {channel_name}")
        new_mdf.save(handle.file_path, overwrite=True)
        new_mdf.close()
        
        handle.mdf = MDF(handle.file_path)
        
        del existing_signals, combined_signal
        gc.collect()
        
        return {
            'name': channel_name,
            'action': 'rebuilt',
            'oldSamples': len(existing_timestamps),
            'newSamples': len(combined_timestamps)
        }
    
    def write_data(self, file_id: str, group_index: int, channel_data: List[Dict[str, Any]],
                   batch_size: int = 5000, write_mode: str = "append") -> Dict[str, Any]:
        """
        写入数据 - 简化操作：
        - 通道不存在时使用append创建
        - 通道已存在时使用extend追加（分片文件使用最后一个分片）
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_data: 通道数据列表
            batch_size: 每批写入的最大样本数（默认5000）
            write_mode: 写入模式（保留参数，但内部逻辑已简化）
        
        Returns:
            写入结果字典
        """
        if not self._check_memory("write_data"):
            raise MemoryError("Memory limit exceeded (300MB), cannot write data")
        
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if handle.mode == 'r':
            raise PermissionError("File opened in read-only mode")
        
        result = {
            'success': False,
            'channelsWritten': 0,
            'channelsAppended': 0,
            'channelsExtended': 0,
            'channelsRebuilt': 0,
            'details': []
        }
        
        with handle.lock:
            try:
                for ch in channel_data:
                    channel_result = self._write_channel_append(handle, group_index, ch, batch_size)
                    
                    # 统计结果
                    action = channel_result.get('action', '')
                    if action == 'appended':
                        result['channelsAppended'] += 1
                    elif action == 'extended':
                        result['channelsExtended'] += 1
                    elif action == 'rebuilt':
                        result['channelsRebuilt'] += 1
                    
                    result['channelsWritten'] += 1
                    result['details'].append(channel_result)
                
                result['success'] = True
                gc.collect()
                
                logger.info(f"Written {result['channelsWritten']} channels: "
                          f"{result['channelsCreated']} created, "
                          f"{result['channelsAppended']} appended, "
                          f"{result['channelsOverwritten']} overwritten")
                
                return result
                
            except Exception as e:
                logger.error(f"Error writing data to file {file_id}: {e}")
                result['error'] = str(e)
                raise
    
    def save_file(self, file_id: str, file_path: str = None, overwrite: bool = False) -> str:
        """保存文件 - 支持自动分片存储（超过1GB自动分片）"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        target_path = file_path or handle.file_path
        base_path = self._shard_manager.get_base_path(target_path)
        
        if os.path.exists(target_path) and not overwrite and not handle.is_sharded:
            raise FileExistsError(f"File already exists: {target_path}")
        
        with handle.lock:
            try:
                # 检查是否需要分片
                need_sharding = self._shard_manager.check_need_sharding(handle)
                
                if need_sharding:
                    # 创建分片
                    logger.info(f"File size exceeds 1GB, creating shards for {base_path}")
                    success = self._shard_manager.create_shards(handle)
                    
                    if success:
                        # 删除原始文件，只保留分片
                        if os.path.exists(base_path) and base_path != target_path:
                            try:
                                os.remove(base_path)
                                logger.info(f"Removed original file after sharding: {base_path}")
                            except Exception as e:
                                logger.warning(f"Could not remove original file: {e}")
                        
                        logger.info(f"Saved sharded file: {base_path}, {len(handle.shards)} shards")
                        
                        # 更新handle的路径
                        if base_path != handle.file_path:
                            old_path = handle.file_path
                            self._path_to_ids[old_path].discard(file_id)
                            if not self._path_to_ids[old_path]:
                                del self._path_to_ids[old_path]
                            
                            handle.file_path = base_path
                            if base_path not in self._path_to_ids:
                                self._path_to_ids[base_path] = set()
                            self._path_to_ids[base_path].add(file_id)
                        
                        gc.collect()
                        return base_path
                
                # 普通保存（不分片）
                handle.mdf.save(target_path, overwrite=overwrite)
                logger.info(f"Saved file: {target_path}")
                
                if target_path != handle.file_path:
                    old_path = handle.file_path
                    self._path_to_ids[old_path].discard(file_id)
                    if not self._path_to_ids[old_path]:
                        del self._path_to_ids[old_path]
                    
                    handle.file_path = target_path
                    if target_path not in self._path_to_ids:
                        self._path_to_ids[target_path] = set()
                    self._path_to_ids[target_path].add(file_id)
                
                gc.collect()
                
                return target_path
                
            except Exception as e:
                logger.error(f"Error saving file {file_id}: {e}")
                raise
    
    def close_all(self):
        """关闭所有文件和分片缓存"""
        with self._global_lock:
            file_ids = list(self._files.keys())
            for file_id in file_ids:
                try:
                    handle = self._files.get(file_id)
                    if handle:
                        handle.mdf.close()
                        logger.info(f"Closed file during shutdown: {handle.file_path}")
                except Exception as e:
                    logger.error(f"Error closing file {file_id}: {e}")
            
            # 关闭分片缓存
            self._shard_manager.close_shard_cache()
            
            self._files.clear()
            self._path_to_ids.clear()
            self._iterators.clear()
            
            gc.collect()
            logger.info("All files closed and memory cleaned up")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取内存使用统计"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            return {
                'rss': memory_info.rss,
                'rssMB': memory_info.rss / 1024 / 1024,
                'vms': memory_info.vms,
                'vmsMB': memory_info.vms / 1024 / 1024,
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
        except ImportError:
            return {
                'error': 'psutil not available',
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
    
    def _get_handle(self, file_id: str) -> Optional[FileHandle]:
        """获取文件句柄"""
        return self._files.get(file_id)
