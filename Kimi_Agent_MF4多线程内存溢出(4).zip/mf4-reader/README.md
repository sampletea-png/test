# MF4 File Reader - Java + Python 混合实现

支持多线程读写的MF4（ASAM MDF4）文件处理库，Java端提供接口，Python端处理具体的文件操作，通过Socket进行通信。

## 特性

- ✅ **多线程支持**：多个线程可以同时处理不同的MF4文件
- ✅ **单一Python进程**：整个生命周期只有一个Python进程
- ✅ **自动生命周期管理**：Java关闭时Python自动关闭
- ✅ **大文件支持**：支持GB级MF4文件的分段读取
- ✅ **流式读取**：超大文件支持迭代器模式
- ✅ **内存监控**：实时监控Python端内存使用
- ✅ **通道详细信息**：支持获取通道的comment、dataType等信息
- ✅ **通道搜索**：支持按名称查找通道
- ✅ **写入模式**：支持追加(APPEND)、覆盖(OVERWRITE)、新建(CREATE_NEW)
- ✅ **extend追加**：相同group_index和名称的signal使用extend追加数据
- ✅ **完善的日志系统**：Python端独立日志
- ✅ **内存限制**：处理GB级数据时内存占用不超过300MB
- ✅ **自动分片存储**：超过1GB自动分片，对外接口透明

## 项目结构

```
mf4-reader/
├── README.md
├── python/
│   ├── requirements.txt
│   ├── pytest.ini
│   ├── protocol.py          # 通信协议
│   ├── logger_config.py     # 日志配置
│   ├── mf4_handler.py       # MF4文件处理核心
│   ├── mf4_server.py        # Socket服务器
│   └── tests/               # Python测试
│       ├── test_protocol.py
│       ├── test_mf4_handler.py
│       └── test_server.py
└── java/
    ├── pom.xml
    └── src/main/java/com/mf4/
        ├── Main.java
        ├── Mf4Service.java
        ├── Mf4ServiceImpl.java
        ├── Mf4File.java
        ├── Mf4FileImpl.java
        ├── SocketClient.java
        ├── PythonProcessManager.java
        ├── ChannelDataIterator.java
        ├── MemoryStats.java
        ├── model/
        │   ├── Request.java
        │   ├── Response.java
        │   ├── FileInfo.java
        │   ├── ChannelInfo.java
        │   ├── ChannelDetailInfo.java
        │   └── ChannelData.java
        └── exception/
            └── Mf4Exception.java
```

## 快速开始

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
```

### 2. 运行Python测试

```bash
cd python
pytest -v
```

### 3. 构建Java项目

```bash
cd java
mvn clean package
```

### 4. 使用示例

```java
import com.mf4.*;
import com.mf4.model.*;

public class Example {
    public static void main(String[] args) {
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4Service service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            
            // 创建新文件
            Mf4File file = service.createFile("/path/to/output.mf4");
            
            // 或打开现有文件
            // Mf4File file = service.openFile("/path/to/input.mf4");
            
            // 获取文件信息
            FileInfo info = file.getInfo();
            System.out.println("Version: " + info.getVersion());
            
            // 获取通道列表
            List<ChannelInfo> channels = file.getChannels();
            
            // 获取通道详细信息
            ChannelDetailInfo detail = file.getChannelInfo(0, 0);
            System.out.println("Comment: " + detail.getComment());
            
            // 查找通道
            List<ChannelInfo> found = file.findChannel("Voltage");
            
            // 读取数据
            ChannelData data = file.readChannel(0, 0);
            
            // 写入数据（追加模式）
            ChannelData newData = new ChannelData();
            newData.setName("NewChannel");
            newData.setUnit("V");
            newData.setTimestamps(Arrays.asList(0.0, 0.1, 0.2));
            newData.setValues(Arrays.asList(1.0, 2.0, 3.0));
            
            file.writeChannel(0, newData, Mf4File.WriteMode.APPEND);
            
            // 保存文件
            file.save();
            file.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

## 写入模式

| 模式 | 说明 |
|------|------|
| `APPEND` | 追加到现有通道（使用extend方式合并数据） |
| `OVERWRITE` | 覆盖现有通道 |
| `CREATE_NEW` | 创建新通道（如果存在则报错） |

```java
// 追加模式（默认）- 相同group_index和名称的signal会extend追加
file.writeChannel(0, data, Mf4File.WriteMode.APPEND);

// 覆盖模式
file.writeChannel(0, data, Mf4File.WriteMode.OVERWRITE);

// 新建模式
file.writeChannel(0, data, Mf4File.WriteMode.CREATE_NEW);
```

## 自动分片存储

当文件大小超过1GB时，系统会自动将文件分片存储，每个分片约1GB。分片对调用端完全透明。

### 分片文件名格式
```
original.mf4              # 原始文件（小于1GB）
original.shard0.mf4       # 分片0（超过1GB时）
original.shard1.mf4       # 分片1
original.shard2.mf4       # 分片2
...
```

### 使用方式
```java
// 保存时自动分片（超过1GB）
file.save();  // 自动创建分片

// 读取时自动合并
ChannelData data = file.readChannel(0, 0);  // 自动从所有分片读取并合并

// 获取分片信息
FileInfo info = file.getInfo();
if (info.isSharded()) {
    System.out.println("Shard count: " + info.getShardCount());
}
```

### 分片策略
- 每个分片大小约1GB
- 按时间范围分片，保证数据连续性
- 读取时自动从多个分片合并数据
- 支持按时间范围查询时只读取相关分片

## Python测试

```bash
cd python

# 运行所有测试
pytest -v

# 运行特定测试文件
pytest tests/test_protocol.py -v
pytest tests/test_mf4_handler.py -v
pytest tests/test_server.py -v

# 运行集成测试
pytest tests/test_server.py -v -m integration
```

## 日志

Python端日志保存在 `python/logs/` 目录下：
- 日志文件: `mf4_server_YYYYMMDD.log`
- 单文件最大50MB，保留10个备份

## 许可证

MIT License
