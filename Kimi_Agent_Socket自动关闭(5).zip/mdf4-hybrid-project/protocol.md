# Socket Communication Protocol

## Overview

Custom socket-based protocol for Java-Python communication in MDF4 hybrid project.

## Message Format

All messages are JSON-encoded with length-prefix framing.

### Framing

```
[4 bytes: message length (big-endian)][N bytes: JSON message]
```

### Request Message

```json
{
  "cmd": "command_name",
  "params": { ... },
  "reqId": "unique_request_id"
}
```

### Response Message

```json
{
  "success": true/false,
  "data": { ... },
  "error": "error message if success=false",
  "reqId": "matching_request_id"
}
```

## Handshake Protocol

1. Client connects to server
2. Client sends: `{"cmd": "HANDSHAKE", "params": {}, "reqId": "0"}`
3. Server responds: `{"success": true, "data": {"version": "1.0"}, "reqId": "0"}`
4. If no handshake within 30 seconds, server closes connection

## Commands

### File Operations

| Command | Description | Params | Response Data |
|---------|-------------|--------|---------------|
| `createNewFile` | Create new MDF4 | `filePath` | `{}` |
| `openFile` | Open existing file | `filePath`, `readOnly` | `{}` |
| `closeFile` | Close current file | - | `{}` |
| `saveFile` | Save file | `filePath`, `compression` | `{}` |

### Write Operations

| Command | Description | Params | Response Data |
|---------|-------------|--------|---------------|
| `addChannel` | Add single channel | `channelName`, `timestamps`, `values`, `unit`, `comment`, `dataType` | `{}` |
| `writeMultipleChannels` | Batch write | `channels` | `{}` |

### Read Operations

| Command | Description | Params | Response Data |
|---------|-------------|--------|---------------|
| `getChannelNames` | Get all names | - | `names: []` |
| `getChannelInfo` | Get channel info | `channelName` | `info: {}` |
| `readChannel` | Read full channel | `channelName` | `record: {}` |
| `readMultipleChannels` | Batch read | `channelNames` | `records: []` |
| `readChannelPartial` | Partial by index | `channelName`, `startIndex`, `count` | `record: {}` |
| `readChannelsPartial` | Partial by time | `channelNames`, `startTime`, `endTime` | `records: []` |
| `getSampleCount` | Get sample count | `channelName` | `count: int` |
| `getTimeRange` | Get time range | - | `range: [start, end]` |

### Utility Operations

| Command | Description | Params | Response Data |
|---------|-------------|--------|---------------|
| `filterChannels` | Filter channels | `channelNames` | `{}` |
| `cutTimeRange` | Cut by time | `startTime`, `endTime` | `{}` |

## Error Codes

| Error | Description |
|-------|-------------|
| `NO_FILE_OPEN` | No MDF file is currently open |
| `CHANNEL_NOT_FOUND` | Requested channel does not exist |
| `FILE_NOT_FOUND` | File does not exist |
| `INVALID_PARAMS` | Invalid parameters provided |
| `INTERNAL_ERROR` | Internal server error |

## Timeout Configuration

- Handshake timeout: 30 seconds
- Socket read timeout: 60 seconds
- Connection keepalive: enabled
