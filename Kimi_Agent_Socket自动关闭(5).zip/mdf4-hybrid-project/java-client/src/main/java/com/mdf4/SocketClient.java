package com.mdf4;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * SocketClient - Java client for MDF4 operations via custom socket protocol.
 * Features automatic reconnection, service restart, and JSON metadata parsing.
 * Optimized for GB-level data with chunked transfer.
 * 
 * Uses Jackson for automatic Java object <-> ObjectNode conversion.
 * Metadata is stored as JSON string in MDF4 comment field.
 */
public class SocketClient implements AutoCloseable {
    
    private static final int DEFAULT_PORT = 25333;
    private static final String DEFAULT_HOST = "localhost";
    private static final int CONNECT_TIMEOUT_MS = 5000;
    private static final int READ_TIMEOUT_MS = 120000; // 2 minutes for large data
    private static final int MAX_RECONNECT_ATTEMPTS = 3;
    private static final int RECONNECT_DELAY_MS = 1000;
    private static final int MAX_CHUNK_SIZE = 1024 * 1024; // 1MB chunks for large data
    
    private final String host;
    private int port;
    private final String portFilePath;
    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;
    private final ObjectMapper mapper;
    private final AtomicInteger requestIdGenerator;
    private boolean connected;
    private PythonServiceManager serviceManager;
    private boolean autoReconnect;
    private boolean autoRestartService;
    
    /**
     * Default constructor - connects to localhost:25333
     */
    public SocketClient() {
        this(DEFAULT_HOST, DEFAULT_PORT);
    }
    
    /**
     * Constructor with custom host and port
     */
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.portFilePath = System.getProperty("user.dir") + "/python-service/mdf4_server.port";
        this.mapper = new ObjectMapper();
        this.requestIdGenerator = new AtomicInteger(0);
        this.connected = false;
        this.autoReconnect = true;
        this.autoRestartService = true;
    }
    
    /**
     * Read actual port from port file
     */
    private int readActualPortFromFile() {
        try {
            String[] possiblePaths = {
                "python-service/mdf4_server.port",
                "../python-service/mdf4_server.port",
                "../../python-service/mdf4_server.port",
                System.getProperty("user.dir") + "/python-service/mdf4_server.port"
            };
            
            for (String path : possiblePaths) {
                java.io.File file = new java.io.File(path);
                if (file.exists()) {
                    String content = new String(Files.readAllBytes(file.toPath())).trim();
                    return Integer.parseInt(content);
                }
            }
        } catch (Exception e) {
            // Ignore and use default
        }
        return port;
    }
    
    /**
     * Set service manager for auto-restart capability
     */
    public void setServiceManager(PythonServiceManager serviceManager) {
        this.serviceManager = serviceManager;
    }
    
    /**
     * Enable or disable auto-reconnect
     */
    public void setAutoReconnect(boolean enabled) {
        this.autoReconnect = enabled;
    }
    
    /**
     * Enable or disable auto-restart service
     */
    public void setAutoRestartService(boolean enabled) {
        this.autoRestartService = enabled;
    }
    
    /**
     * Connect to the Python service and perform handshake
     */
    public void connect() throws Mdf4Exception {
        int actualPort = readActualPortFromFile();
        if (actualPort != port) {
            System.out.println("Using actual port from file: " + actualPort + " (preferred was: " + port + ")");
            this.port = actualPort;
        }
        connectWithRetry(0);
    }
    
    /**
     * Connect with retry logic
     */
    private void connectWithRetry(int attempt) throws Mdf4Exception {
        try {
            doConnect();
        } catch (Mdf4Exception e) {
            if (attempt < MAX_RECONNECT_ATTEMPTS && autoReconnect) {
                System.out.println("Connection failed, retrying in " + RECONNECT_DELAY_MS + "ms... (attempt " + 
                    (attempt + 1) + "/" + MAX_RECONNECT_ATTEMPTS + ")");
                
                if (autoRestartService && serviceManager != null) {
                    System.out.println("Attempting to restart Python service...");
                    if (serviceManager.restartService()) {
                        int newPort = readActualPortFromFile();
                        if (newPort != port) {
                            System.out.println("Server now using port: " + newPort);
                            this.port = newPort;
                        }
                        System.out.println("Service restarted, retrying connection...");
                    }
                }
                
                try {
                    Thread.sleep(RECONNECT_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new Mdf4Exception("Connection interrupted", ie);
                }
                connectWithRetry(attempt + 1);
            } else {
                throw e;
            }
        }
    }
    
    /**
     * Perform actual connection
     */
    private void doConnect() throws Mdf4Exception {
        try {
            socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            socket.setSoTimeout(READ_TIMEOUT_MS);
            socket.setKeepAlive(true);
            socket.setTcpNoDelay(true);
            
            input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            
            if (!performHandshake()) {
                close();
                throw new Mdf4Exception("Handshake failed with server");
            }
            
            connected = true;
            System.out.println("Connected to MDF4 Socket Server at " + host + ":" + port);
            
        } catch (java.net.ConnectException e) {
            throw new Mdf4Exception("Failed to connect to server at " + host + ":" + port + 
                    ". Make sure the Python service is running.", e);
        } catch (IOException e) {
            throw new Mdf4Exception("Connection error: " + e.getMessage(), e);
        }
    }
    
    /**
     * Perform handshake with server
     */
    private boolean performHandshake() throws IOException {
        ObjectNode request = mapper.createObjectNode();
        request.put("cmd", "HANDSHAKE");
        request.put("reqId", "0");
        request.set("params", mapper.createObjectNode());
        
        sendMessage(request);
        ObjectNode response = receiveMessage();
        
        if (response == null) {
            return false;
        }
        
        boolean success = response.get("success").asBoolean();
        if (success) {
            ObjectNode data = (ObjectNode) response.get("data");
            String version = data.get("version").asText();
            System.out.println("Handshake successful, server version: " + version);
        }
        return success;
    }
    
    /**
     * Check if connection is alive by sending ping
     */
    public boolean isConnectionAlive() {
        if (!isConnected()) {
            return false;
        }
        try {
            ObjectNode params = mapper.createObjectNode();
            ObjectNode result = sendCommand("PING", params);
            return result != null && result.has("status");
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Reconnect to server
     */
    public boolean reconnect() {
        System.out.println("Attempting to reconnect...");
        disconnect();
        
        int actualPort = readActualPortFromFile();
        if (actualPort != port) {
            System.out.println("Using port from file: " + actualPort);
            this.port = actualPort;
        }
        
        try {
            connect();
            return true;
        } catch (Mdf4Exception e) {
            System.err.println("Reconnection failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Disconnect from the server
     */
    public void disconnect() {
        close();
    }
    
    /**
     * Check if connected
     */
    public boolean isConnected() {
        return connected && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    /**
     * Get current port
     */
    public int getPort() {
        return port;
    }
    
    /**
     * Set port (used when service starts on different port)
     */
    public void setPort(int port) {
        this.port = port;
    }
    
    // ==================== Private Communication Methods ====================
    
    /**
     * Send a message to the server (with chunked transfer for large messages)
     */
    private void sendMessage(ObjectNode message) throws IOException {
        byte[] jsonBytes = mapper.writeValueAsBytes(message);
        
        synchronized (output) {
            output.writeInt(jsonBytes.length);
            for (int i = 0; i < jsonBytes.length; i += MAX_CHUNK_SIZE) {
                int chunkSize = Math.min(MAX_CHUNK_SIZE, jsonBytes.length - i);
                output.write(jsonBytes, i, chunkSize);
            }
            output.flush();
        }
    }
    
    /**
     * Receive a message from the server (with chunked transfer for large messages)
     */
    private ObjectNode receiveMessage() throws IOException {
        byte[] lengthBytes = new byte[4];
        input.readFully(lengthBytes);
        int messageLength = ByteBuffer.wrap(lengthBytes).getInt();
        
        byte[] messageBytes = new byte[messageLength];
        int bytesRead = 0;
        
        while (bytesRead < messageLength) {
            int chunkSize = Math.min(MAX_CHUNK_SIZE, messageLength - bytesRead);
            int read = input.read(messageBytes, bytesRead, chunkSize);
            if (read < 0) {
                throw new IOException("Unexpected end of stream");
            }
            bytesRead += read;
        }
        
        return (ObjectNode) mapper.readTree(messageBytes);
    }
    
    /**
     * Send a command and receive response
     */
    private ObjectNode sendCommand(String command, ObjectNode params) throws Mdf4Exception {
        return sendCommand(command, params, true);
    }
    
    private ObjectNode sendCommand(String command, ObjectNode params, boolean allowReconnect) throws Mdf4Exception {
        checkConnection();
        
        try {
            ObjectNode request = mapper.createObjectNode();
            request.put("cmd", command);
            request.put("reqId", String.valueOf(requestIdGenerator.incrementAndGet()));
            request.set("params", params != null ? params : mapper.createObjectNode());
            
            sendMessage(request);
            ObjectNode response = receiveMessage();
            
            if (response == null) {
                throw new Mdf4Exception("No response from server");
            }
            
            if (!response.get("success").asBoolean()) {
                String error = response.has("error") ? response.get("error").asText() : "Unknown error";
                throw new Mdf4Exception("Server error: " + error);
            }
            
            return (ObjectNode) response.get("data");
            
        } catch (IOException e) {
            connected = false;
            
            if (allowReconnect && autoReconnect) {
                System.out.println("Connection lost, attempting to reconnect...");
                
                if (autoRestartService && serviceManager != null) {
                    serviceManager.restartService();
                }
                
                if (reconnect()) {
                    return sendCommand(command, params, false);
                }
            }
            
            throw new Mdf4Exception("Communication error: " + e.getMessage(), e);
        }
    }
    
    private void checkConnection() throws Mdf4Exception {
        if (!isConnected()) {
            if (autoReconnect) {
                if (!reconnect()) {
                    throw new Mdf4Exception("Not connected to server and reconnection failed");
                }
            } else {
                throw new Mdf4Exception("Not connected to server. Call connect() first.");
            }
        }
    }
    
    @Override
    public void close() {
        connected = false;
        try {
            if (input != null) input.close();
        } catch (IOException e) { }
        try {
            if (output != null) output.close();
        } catch (IOException e) { }
        try {
            if (socket != null) socket.close();
        } catch (IOException e) { }
        System.out.println("Disconnected from server");
    }
    
    // ==================== File Operations ====================
    
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        return createNewFile(filePath, null, true);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata) throws Mdf4Exception {
        return createNewFile(filePath, metadata, true);
    }
    
    /**
     * Create new file with metadata stored in comment
     */
    public boolean createNewFile(String filePath, FileMetadata metadata, boolean autoCreateDirs) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("filePath", filePath);
        params.put("autoCreateDirs", autoCreateDirs);
        
        if (metadata != null) {
            // Java对象 -> ObjectNode 自动转换
            params.set("metadata", mapper.valueToTree(metadata));
        }
        
        ObjectNode result = sendCommand("createNewFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean openFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, true, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        return openFile(filePath, readOnly, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate) throws Mdf4Exception {
        return openFile(filePath, readOnly, autoCreate, null);
    }
    
    /**
     * Open file with optional metadata
     */
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate, FileMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("filePath", filePath);
        params.put("readOnly", readOnly);
        params.put("autoCreate", autoCreate);
        
        if (metadata != null) {
            params.set("metadata", mapper.valueToTree(metadata));
        }
        
        ObjectNode result = sendCommand("openFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean closeFile() throws Mdf4Exception {
        ObjectNode result = sendCommand("closeFile", null);
        return result.get("success").asBoolean();
    }
    
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        if (filePath != null) {
            params.put("filePath", filePath);
        }
        params.put("compression", compression);
        ObjectNode result = sendCommand("saveFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean saveFile() throws Mdf4Exception {
        return saveFile(null, 0);
    }
    
    // ==================== File Metadata Operations ====================
    
    /**
     * Set file metadata - stored as JSON string in MDF4 comment
     */
    public boolean setFileMetadata(FileMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("metadata", mapper.valueToTree(metadata));
        ObjectNode result = sendCommand("setFileMetadata", params);
        return result.get("success").asBoolean();
    }
    
    /**
     * Get file metadata - parsed from JSON string in MDF4 comment
     */
    public FileMetadata getFileMetadata() throws Mdf4Exception {
        ObjectNode result = sendCommand("getFileMetadata", null);
        ObjectNode metaNode = (ObjectNode) result.get("metadata");
        
        if (metaNode == null) {
            return new FileMetadata();
        }
        
        // ObjectNode -> Java对象 自动转换
        return mapper.convertValue(metaNode, FileMetadata.class);
    }
    
    // ==================== Channel Write Operations ====================
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, unit, comment, dataType, null);
    }
    
    /**
     * Add channel with metadata stored in comment as JSON string
     */
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType,
                              ChannelMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        params.put("timestamps", mapper.valueToTree(timestamps));
        params.put("values", mapper.valueToTree(values));
        params.put("unit", unit);
        params.put("comment", comment);
        params.put("dataType", dataType);
        
        if (metadata != null) {
            params.set("metadata", mapper.valueToTree(metadata));
        }
        
        ObjectNode result = sendCommand("addChannel", params);
        return result.get("success").asBoolean();
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, "", "", "float", null);
    }
    
    /**
     * Write multiple channels at once
     */
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        // List<Java对象> -> ArrayNode 自动转换
        params.set("channels", mapper.valueToTree(channelDataList));
        ObjectNode result = sendCommand("writeMultipleChannels", params);
        return result.get("success").asBoolean();
    }
    
    // ==================== Channel Metadata Operations ====================
    
    /**
     * Set channel metadata - stored as JSON string in comment
     */
    public boolean setChannelMetadata(String channelName, ChannelMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        params.set("metadata", mapper.valueToTree(metadata));
        ObjectNode result = sendCommand("setChannelMetadata", params);
        return result.get("success").asBoolean();
    }
    
    /**
     * Get channel metadata - parsed from JSON string in comment
     */
    public ChannelMetadata getChannelMetadata(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getChannelMetadata", params);
        ObjectNode metaNode = (ObjectNode) result.get("metadata");
        
        if (metaNode == null) {
            return new ChannelMetadata();
        }
        
        return mapper.convertValue(metaNode, ChannelMetadata.class);
    }
    
    // ==================== Read Operations ====================
    
    /**
     * Get all channel names
     */
    public List<String> getChannelNames() throws Mdf4Exception {
        ObjectNode result = sendCommand("getChannelNames", null);
        ArrayNode namesArray = (ArrayNode) result.get("names");
        
        // ArrayNode -> List<String> 自动转换
        return mapper.convertValue(namesArray, new TypeReference<List<String>>() {});
    }
    
    /**
     * Get channel info including metadata from comment
     */
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getChannelInfo", params);
        ObjectNode infoObj = (ObjectNode) result.get("info");
        
        if (infoObj == null) {
            return null;
        }
        
        // ObjectNode -> ChannelInfo 自动转换
        ChannelInfo info = mapper.convertValue(infoObj, ChannelInfo.class);
        
        // Parse metadata from JSON string stored in comment
        String metadataJson = infoObj.path("metadata_json").asText("{}");
        if (!"{}".equals(metadataJson) && !metadataJson.isEmpty()) {
            try {
                ChannelMetadata metadata = mapper.readValue(metadataJson, ChannelMetadata.class);
                info.setMetadata(metadata);
            } catch (Exception e) {
                System.err.println("Failed to parse channel metadata JSON: " + e.getMessage());
                info.setMetadata(new ChannelMetadata());
            }
        }
        
        return info;
    }
    
    /**
     * Read full channel data
     */
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("readChannel", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        if (recordObj == null) {
            return null;
        }
        
        return mapper.convertValue(recordObj, DataRecord.class);
    }
    
    /**
     * Read multiple channels at once
     */
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        
        ObjectNode result = sendCommand("readMultipleChannels", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        if (recordsArray == null) {
            return new ArrayList<>();
        }
        
        return mapper.convertValue(recordsArray, new TypeReference<List<DataRecord>>() {});
    }
    
    /**
     * Read partial channel data by index range
     */
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        params.put("startIndex", startIndex);
        params.put("count", count);
        
        ObjectNode result = sendCommand("readChannelPartial", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        if (recordObj == null) {
            return null;
        }
        
        return mapper.convertValue(recordObj, DataRecord.class);
    }
    
    /**
     * Read partial channel data by time range
     */
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("readChannelsPartial", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        if (recordsArray == null) {
            return new ArrayList<>();
        }
        
        return mapper.convertValue(recordsArray, new TypeReference<List<DataRecord>>() {});
    }
    
    public int getSampleCount(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getSampleCount", params);
        return result.get("count").asInt();
    }
    
    public double[] getTimeRange() throws Mdf4Exception {
        ObjectNode result = sendCommand("getTimeRange", null);
        ArrayNode rangeArray = (ArrayNode) result.get("range");
        
        List<Double> range = mapper.convertValue(rangeArray, new TypeReference<List<Double>>() {});
        return new double[]{range.get(0), range.get(1)};
    }
    
    // ==================== Utility Operations ====================
    
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        
        ObjectNode result = sendCommand("filterChannels", params);
        return result.get("success").asBoolean();
    }
    
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("cutTimeRange", params);
        return result.get("success").asBoolean();
    }
}
