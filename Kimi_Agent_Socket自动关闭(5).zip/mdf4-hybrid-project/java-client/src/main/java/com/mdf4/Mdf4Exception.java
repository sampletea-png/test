package com.mdf4;

/**
 * Mdf4Exception - Custom exception for MDF4 related errors.
 */
public class Mdf4Exception extends Exception {
    
    /**
     * Constructor with message
     */
    public Mdf4Exception(String message) {
        super(message);
    }
    
    /**
     * Constructor with message and cause
     */
    public Mdf4Exception(String message, Throwable cause) {
        super(message, cause);
    }
    
    /**
     * Constructor with cause
     */
    public Mdf4Exception(Throwable cause) {
        super(cause);
    }
}
