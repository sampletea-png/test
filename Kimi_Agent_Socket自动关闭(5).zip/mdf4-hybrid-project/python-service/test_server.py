"""
Simple test script for the MDF4 Socket Server.
Tests basic connectivity and handshake.
"""

import socket
import struct
import json
import sys
import time


def encode_message(data):
    """Encode message with length prefix"""
    json_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
    length_prefix = struct.pack('>I', len(json_bytes))
    return length_prefix + json_bytes


def decode_message(data):
    """Decode message from bytes"""
    return json.loads(data.decode('utf-8'))


def read_message(sock):
    """Read a complete message"""
    length_bytes = sock.recv(4)
    if len(length_bytes) < 4:
        return None
    message_length = struct.unpack('>I', length_bytes)[0]
    message_bytes = sock.recv(message_length)
    return decode_message(message_bytes)


def send_message(sock, data):
    """Send a message"""
    message_bytes = encode_message(data)
    sock.sendall(message_bytes)


def test_handshake():
    """Test handshake with server"""
    print("Testing handshake...")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    
    try:
        sock.connect(('localhost', 25333))
        print("✓ Connected to server")
        
        # Send handshake
        send_message(sock, {"cmd": "HANDSHAKE", "params": {}, "reqId": "0"})
        print("✓ Sent handshake")
        
        # Receive response
        response = read_message(sock)
        if response and response.get('success'):
            print(f"✓ Handshake successful: {response['data']}")
            return True
        else:
            print(f"✗ Handshake failed: {response}")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False
    finally:
        sock.close()


def test_create_file():
    """Test creating a file"""
    print("\nTesting create file...")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    
    try:
        sock.connect(('localhost', 25333))
        
        # Handshake
        send_message(sock, {"cmd": "HANDSHAKE", "params": {}, "reqId": "0"})
        read_message(sock)
        
        # Create file
        send_message(sock, {
            "cmd": "createNewFile",
            "params": {"filePath": "test.mf4"},
            "reqId": "1"
        })
        response = read_message(sock)
        
        if response and response.get('success') and response['data'].get('success'):
            print("✓ File created successfully")
            return True
        else:
            print(f"✗ Failed to create file: {response}")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False
    finally:
        sock.close()


def test_handshake_timeout():
    """Test that server closes connection on handshake timeout"""
    print("\nTesting handshake timeout (this will take ~30 seconds)...")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(35)  # Wait up to 35 seconds
    
    try:
        sock.connect(('localhost', 25333))
        print("✓ Connected to server")
        print("  Waiting for server to timeout (no handshake sent)...")
        
        # Don't send handshake, just wait
        start = time.time()
        try:
            data = sock.recv(1024)
            elapsed = time.time() - start
            if not data:
                print(f"✓ Server closed connection after {elapsed:.1f}s (expected ~30s)")
                return True
            else:
                print(f"✗ Unexpected data received: {data}")
                return False
        except socket.timeout:
            elapsed = time.time() - start
            print(f"✗ Socket timeout after {elapsed:.1f}s (server should have closed)")
            return False
            
    except Exception as e:
        print(f"✗ Error: {e}")
        return False
    finally:
        sock.close()


def main():
    """Run all tests"""
    print("=" * 50)
    print("MDF4 Socket Server Test")
    print("=" * 50)
    print()
    
    # Check if server is running
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect(('localhost', 25333))
        sock.close()
    except:
        print("✗ Cannot connect to server at localhost:25333")
        print("  Please start the server first:")
        print("  python socket_server.py")
        sys.exit(1)
    
    print("✓ Server is running at localhost:25333")
    print()
    
    # Run tests
    results = []
    
    results.append(("Handshake", test_handshake()))
    results.append(("Create File", test_create_file()))
    # Uncomment to test timeout (takes 30 seconds)
    # results.append(("Handshake Timeout", test_handshake_timeout()))
    
    # Summary
    print("\n" + "=" * 50)
    print("Test Summary")
    print("=" * 50)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"  {status}: {name}")
    
    print()
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
        return 0
    else:
        print("Some tests failed!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
