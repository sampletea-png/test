# MDF4 Hybrid Project - Architecture

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Java Application                                │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         Mdf4Client                                   │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   write()   │  │   read()    │  │ partial()   │  │  info()    │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        SocketClient                                  │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   Socket    │  │   Jackson   │  │   Length    │  │  Handshake │ │   │
│  │  │   (TCP)     │  │   (JSON)    │  │   Prefix    │  │            │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ TCP Socket (Port 25333)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Python Service                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Mdf4SocketServer                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   Socket    │  │   Thread    │  │   Length    │  │  Handshake │ │   │
│  │  │   Server    │  │   Pool      │  │   Prefix    │  │  (30s)     │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      ClientHandler (per client)                      │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   Receive   │  │   Parse     │  │   Execute   │  │   Send     │ │   │
│  │  │   Message   │  │   JSON      │  │   Command   │  │   Response │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Mdf4SocketHandler                               │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │createNewFile│  │addChannel() │  │readChannel()│  │getInfo()   │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Mdf4Handler (Core)                              │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │    MDF()    │  │  Signal()   │  │  append()   │  │   get()    │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         asammdf Library                              │   │
│  │              (ASAM MDF4 Standard Implementation)                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ File I/O
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MDF4 File (.mf4)                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐   │   │
│  │  │ Header  │  │ Channel │  │ Channel │  │ Channel │  │  Data   │   │   │
│  │  │ Block   │  │  Info   │  │  Info   │  │  Info   │  │ Blocks  │   │   │
│  │  └─────────┘  │ Block 1 │  │ Block 2 │  │ Block N │  └─────────┘   │   │
│  │               └─────────┘  └─────────┘  └─────────┘                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Communication Flow

### Connection and Handshake

```
Java Client                              Python Server
     │                                         │
     │ 1. Connect TCP socket                   │
     │────────────────────────────────────────>│
     │                                         │
     │ 2. Set 30s handshake timeout            │
     │                                         │◄────┐
     │                                         │     │
     │ 3. Send HANDSHAKE                       │     │
     │{"cmd":"HANDSHAKE"}                      │     │
     │────────────────────────────────────────>│     │
     │                                         │     │
     │ 4. Response                             │     │
     │{"success":true,"data":{"version":"1.0"}}│     │
     │<────────────────────────────────────────│     │
     │                                         │     │
     │ 5. Clear timeout, set normal timeout    │◄────┘
     │                                         │
     │ 6. Ready for commands                   │
```

### Handshake Timeout Scenario

```
Java Client                              Python Server
     │                                         │
     │ 1. Connect TCP socket                   │
     │────────────────────────────────────────>│
     │                                         │
     │ 2. Set 30s handshake timeout            │
     │                                         │◄────┐
     │                                         │     │
     │ (No handshake sent)                     │     │
     │                                         │     │ Wait 30s
     │                                         │     │
     │ 3. Timeout! Close connection            │◄────┘
     │<─X─X─X─X─X─X─X─X─X─X─X─X─X─X─X─X─X─X─X─│
     │    Connection closed                    │
```

### Write Operation

```
Java Application
       │
       │ 1. client.addChannel(name, timestamps, values)
       ▼
Mdf4Client
       │
       │ 2. socketClient.addChannel(...)
       ▼
SocketClient
       │
       │ 3. Build JSON request
       │    {"cmd":"addChannel","params":{...},"reqId":"1"}
       ▼
       │
       │ 4. Send length-prefixed message
       │    [4 bytes length][JSON bytes]
       ▼
Socket (TCP)
       │
       ▼
Python Server
       │
       │ 5. Read length prefix
       │ 6. Read JSON message
       ▼
ClientHandler
       │
       │ 7. Parse JSON
       │ 8. Execute command
       ▼
Mdf4SocketHandler
       │
       │ 9. handler.add_channel(...)
       ▼
Mdf4Handler
       │
       │ 10. mdf.append(signal)
       ▼
asammdf MDF Object
       │
       │ 11. File I/O
       ▼
MDF4 File
```

### Read Operation (Full)

```
Java Application
       │
       │ 1. client.readChannel(name)
       ▼
SocketClient
       │
       │ 2. Send request
       │    {"cmd":"readChannel","params":{"channelName":"..."}}
       ▼
Socket (TCP)
       │
       ▼
Python Server
       │
       │ 3. Execute read_channel(name)
       ▼
Mdf4Handler
       │
       │ 4. mdf.get(name)
       ▼
asammdf MDF Object
       │
       │ 5. File I/O (read all samples)
       ▼
MDF4 File
       │
       │ 6. Return Signal object
       ▼
Mdf4Handler
       │
       │ 7. Convert to DataRecord
       ▼
Mdf4SocketHandler
       │
       │ 8. Convert to JSON response
       │    {"record":{"channelName":"...","timestamps":[...],"values":[...]}}
       ▼
SocketClient
       │
       │ 9. Parse JSON response
       │ 10. Convert to DataRecord object
       ▼
Java Application
```

### Partial Read Operation (By Index)

```
Java Application
       │
       │ 1. client.readChannelPartial(name, startIndex, count)
       ▼
SocketClient
       │
       │ 2. Send request
       │    {"cmd":"readChannelPartial","params":{"channelName":"...","startIndex":100,"count":50}}
       ▼
Python Server
       │
       │ 3. Execute read_channel_partial(name, start, count)
       ▼
Mdf4Handler
       │
       │ 4. mdf.get(name) - reads all
       │ 5. Slice array[start:start+count] - extracts subset
       ▼
       │
       │ 6. Return only sliced data
       ▼
Java Application (receives only requested subset)
```

### Partial Read Operation (By Time Range)

```
Java Application
       │
       │ 1. client.readChannelsPartial(names, startTime, endTime)
       ▼
SocketClient
       │
       │ 2. Send request
       │    {"cmd":"readChannelsPartial","params":{"channelNames":[...],"startTime":2.0,"endTime":5.0}}
       ▼
Python Server
       │
       │ 3. For each channel:
       │    a. mdf.get(name) - reads all
       │    b. mask = (timestamps >= start) & (timestamps <= end)
       │    c. filtered = data[mask] - extracts time range
       ▼
       │
       │ 4. Return filtered data for all channels
       ▼
Java Application (receives only time range data)
```

## Data Flow

### Write Data Flow

```
Java List<Double> (timestamps, values)
       │
       │ Jackson serialization
       ▼
JSON Array [0.0, 0.1, 0.2, ...]
       │
       │ Socket send
       ▼
Python receives JSON
       │
       │ json.loads()
       ▼
Python list
       │
       │ numpy.array()
       ▼
numpy arrays
       │
       │ Signal constructor
       ▼
Signal object (asammdf)
       │
       │ MDF.append()
       ▼
MDF internal structure
       │
       │ MDF.save()
       ▼
Binary MDF4 file
```

### Read Data Flow

```
Binary MDF4 file
       │
       │ MDF.get()
       ▼
Signal object (asammdf)
       │
       │ Extract samples, timestamps
       ▼
numpy arrays
       │
       │ .tolist() conversion
       ▼
Python lists
       │
       │ json.dumps()
       ▼
JSON string
       │
       │ Socket send
       ▼
Java receives JSON
       │
       │ Jackson parsing
       ▼
JsonNode / ObjectNode
       │
       │ DataRecord constructor
       ▼
DataRecord object
```

## Message Protocol

### Length-Prefixed Framing

```
┌─────────────────┬─────────────────────────────────────────┐
│  Length (4 bytes│  JSON Message (N bytes)                 │
│  Big-endian int │                                         │
└─────────────────┴─────────────────────────────────────────┘
```

### Example Request

```
Length: 78 (0x0000004E)
JSON: {"cmd":"addChannel","params":{"channelName":"Temp","timestamps":[0.0,0.1],"values":[10.0,20.0]},"reqId":"1"}

Bytes:
00 00 00 4E 7B 22 63 6D 64 22 3A 22 61 64 64 43 68 61 6E 6E 65 6C 22 2C 22 70 61 72 61 6D 73 22 3A 7B 22 63 68 61 6E 6E 65 6C 4E 61 6D 65 22 3A 22 54 65 6D 70 22 2C 22 74 69 6D 65 73 74 61 6D 70 73 22 3A 5B 30 2E 30 2C 30 2E 31 5D 2C 22 76 61 6C 75 65 73 22 3A 5B 31 30 2E 30 2C 32 30 2E 30 5D 7D 2C 22 72 65 71 49 64 22 3A 22 31 22 7D
```

## Class Diagram

### Java Classes

```
┌─────────────────────────────────────────────────────────────────┐
│                        <<interface>>                            │
│                       AutoCloseable                             │
└─────────────────────────────────────────────────────────────────┘
                              △
                              │ implements
┌─────────────────────────────────────────────────────────────────┐
│                          Mdf4Client                             │
│─────────────────────────────────────────────────────────────────│
│ - socketClient: SocketClient                                    │
│─────────────────────────────────────────────────────────────────│
│ + Mdf4Client()                                                  │
│ + Mdf4Client(host, port)                                        │
│ + connect(): void                                               │
│ + disconnect(): void                                            │
│ + createNewFile(path): boolean                                  │
│ + openFile(path): boolean                                       │
│ + openFile(path, readOnly): boolean                             │
│ + closeFile(): boolean                                          │
│ + saveFile(): boolean                                           │
│ + saveFile(path, compression): boolean                          │
│ + addChannel(name, timestamps, values): boolean                 │
│ + addChannel(name, ts, vals, unit, comment, type): boolean      │
│ + writeMultipleChannels(list): boolean                          │
│ + getChannelNames(): List<String>                               │
│ + getChannelInfo(name): ChannelInfo                             │
│ + readChannel(name): DataRecord                                 │
│ + readMultipleChannels(names): List<DataRecord>                 │
│ + readChannelPartial(name, start, count): DataRecord            │
│ + readChannelsPartial(names, startTime, endTime): List          │
│ + getSampleCount(name): int                                     │
│ + getTimeRange(): double[]                                      │
│ + filterChannels(names): boolean                                │
│ + cutTimeRange(start, end): boolean                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ uses
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         SocketClient                            │
│─────────────────────────────────────────────────────────────────│
│ - host: String                                                  │
│ - port: int                                                     │
│ - socket: Socket                                                │
│ - input: DataInputStream                                        │
│ - output: DataOutputStream                                      │
│ - mapper: ObjectMapper                                          │
│ - requestIdGenerator: AtomicInteger                             │
│ - connected: boolean                                            │
│─────────────────────────────────────────────────────────────────│
│ + connect(): void                                               │
│ + disconnect(): void                                            │
│ + isConnected(): boolean                                        │
│ - sendMessage(message): void                                    │
│ - receiveMessage(): ObjectNode                                  │
│ - sendCommand(cmd, params): ObjectNode                          │
│ - performHandshake(): boolean                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Python Classes

```
┌─────────────────────────────────────────────────────────────────┐
│                      Mdf4SocketServer                           │
│─────────────────────────────────────────────────────────────────│
│ - _host: str                                                    │
│ - _port: int                                                    │
│ - _server_socket: socket.socket                                 │
│ - _running: bool                                                │
│ - _clients: list                                                │
│ - _lock: threading.Lock                                         │
│─────────────────────────────────────────────────────────────────│
│ + start(): void                                                 │
│ + stop(): void                                                  │
│ + is_running(): bool                                            │
│ + remove_client(client): void                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ creates
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        ClientHandler                            │
│─────────────────────────────────────────────────────────────────│
│ - HANDSHAKE_TIMEOUT: int = 30                                   │
│ - _socket: socket.socket                                        │
│ - _address: tuple                                               │
│ - _server: Mdf4SocketServer                                     │
│ - _mdf_handler: Mdf4SocketHandler                               │
│ - _connected: bool                                              │
│ - _handshake_received: bool                                     │
│─────────────────────────────────────────────────────────────────│
│ + run(): void                                                   │
│ - _wait_for_handshake(): bool                                   │
│ - _handle_message(message): void                                │
│ - _cleanup(): void                                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ uses
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Mdf4SocketHandler                          │
│─────────────────────────────────────────────────────────────────│
│ - _handler: Mdf4Handler                                         │
│ - _commands: Dict[str, Callable]                                │
│─────────────────────────────────────────────────────────────────│
│ + handle_command(cmd, params): Dict                             │
│ - _cmd_create_new_file(params): Dict                            │
│ - _cmd_open_file(params): Dict                                  │
│ - _cmd_add_channel(params): Dict                                │
│ - _cmd_read_channel(params): Dict                               │
│ ... (other command handlers)                                    │
└─────────────────────────────────────────────────────────────────┘
```

## Handshake Timeout Mechanism

### Purpose
- Prevent resource exhaustion from idle connections
- Ensure protocol compliance from clients
- Protect against malicious/hanging connections

### Implementation

```python
class ClientHandler(threading.Thread):
    HANDSHAKE_TIMEOUT = 30  # seconds
    
    def run(self):
        # Set handshake timeout
        self._socket.settimeout(self.HANDSHAKE_TIMEOUT)
        
        # Wait for handshake
        if not self._wait_for_handshake():
            logger.warning(f"Handshake timeout for {self._address}")
            return
        
        # Handshake successful, continue with normal operation
        self._socket.settimeout(60)  # Normal read timeout
        ...
```

### Configuration

The handshake timeout can be modified in `socket_server.py`:

```python
class ClientHandler(threading.Thread):
    HANDSHAKE_TIMEOUT = 60  # Change to 60 seconds
```

## Benefits of This Architecture

1. **Language Best Practices**
   - Python: Excellent for data processing (asammdf)
   - Java: Excellent for enterprise applications

2. **Simple Protocol**
   - Length-prefixed JSON is easy to debug
   - No complex serialization frameworks
   - Human-readable messages

3. **Reliability**
   - Handshake timeout prevents resource leaks
   - Thread-per-client isolation
   - Clear error handling

4. **Flexibility**
   - Can upgrade either side independently
   - Protocol version in handshake for future compatibility
   - Can run on different machines

5. **Memory Efficiency**
   - Partial reads reduce memory usage
   - Large files can be processed in chunks

6. **No External Dependencies**
   - No Py4J or similar bridge libraries
   - Standard library sockets
   - Jackson for JSON (widely used)
