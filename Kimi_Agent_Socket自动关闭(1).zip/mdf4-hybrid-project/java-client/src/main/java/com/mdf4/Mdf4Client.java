package com.mdf4;

import java.util.List;

/**
 * Mdf4Client - Java client for MDF4 file operations.
 * Uses SocketClient for communication with Python service.
 * Includes service management and auto-restart capabilities.
 */
public class Mdf4Client implements AutoCloseable {
    
    private final SocketClient socketClient;
    private final PythonServiceManager serviceManager;
    private boolean manageService;
    
    /**
     * Default constructor - connects to localhost:25333
     * Automatically manages Python service lifecycle.
     */
    public Mdf4Client() {
        this("localhost", 25333, true);
    }
    
    /**
     * Constructor with custom host and port
     * 
     * @param host Server host
     * @param port Server port
     * @param manageService Whether to manage Python service lifecycle
     */
    public Mdf4Client(String host, int port, boolean manageService) {
        this.manageService = manageService;
        this.socketClient = new SocketClient(host, port);
        
        if (manageService) {
            this.serviceManager = new PythonServiceManager(host, port, 
                PythonServiceManager.findPythonExecutable(), 
                PythonServiceManager.findServerScript());
            this.socketClient.setServiceManager(serviceManager);
        } else {
            this.serviceManager = null;
        }
    }
    
    /**
     * Constructor with service manager
     */
    public Mdf4Client(SocketClient socketClient, PythonServiceManager serviceManager) {
        this.socketClient = socketClient;
        this.serviceManager = serviceManager;
        this.manageService = (serviceManager != null);
        
        if (serviceManager != null) {
            socketClient.setServiceManager(serviceManager);
        }
    }
    
    /**
     * Connect to the Python service
     * If manageService is true, will start the service if not running.
     */
    public void connect() throws Mdf4Exception {
        if (manageService && serviceManager != null) {
            // Ensure service is running
            if (!serviceManager.isServiceRunning()) {
                System.out.println("Python service is not running, starting it...");
                if (!serviceManager.startService()) {
                    throw new Mdf4Exception("Failed to start Python service");
                }
            }
        }
        
        socketClient.connect();
    }
    
    /**
     * Disconnect from the Python service
     */
    public void disconnect() {
        socketClient.disconnect();
    }
    
    /**
     * Stop the Python service (if managed)
     */
    public void stopService() {
        if (manageService && serviceManager != null) {
            serviceManager.stopService();
        }
    }
    
    /**
     * Check if connected to the service
     */
    public boolean isConnected() {
        return socketClient.isConnected();
    }
    
    /**
     * Check if the service is running
     */
    public boolean isServiceRunning() {
        if (serviceManager != null) {
            return serviceManager.isServiceRunning();
        }
        return socketClient.isConnectionAlive();
    }
    
    // ==================== File Operations ====================
    
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        return socketClient.createNewFile(filePath);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata) throws Mdf4Exception {
        return socketClient.createNewFile(filePath, metadata);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata, boolean autoCreateDirs) throws Mdf4Exception {
        return socketClient.createNewFile(filePath, metadata, autoCreateDirs);
    }
    
    public boolean openFile(String filePath) throws Mdf4Exception {
        return socketClient.openFile(filePath);
    }
    
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        return socketClient.openFile(filePath, readOnly);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate) throws Mdf4Exception {
        return socketClient.openFile(filePath, readOnly, autoCreate);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate, FileMetadata metadata) throws Mdf4Exception {
        return socketClient.openFile(filePath, readOnly, autoCreate, metadata);
    }
    
    public boolean closeFile() throws Mdf4Exception {
        return socketClient.closeFile();
    }
    
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        return socketClient.saveFile(filePath, compression);
    }
    
    public boolean saveFile() throws Mdf4Exception {
        return socketClient.saveFile();
    }
    
    // ==================== File Metadata Operations ====================
    
    public boolean setFileMetadata(FileMetadata metadata) throws Mdf4Exception {
        return socketClient.setFileMetadata(metadata);
    }
    
    public FileMetadata getFileMetadata() throws Mdf4Exception {
        return socketClient.getFileMetadata();
    }
    
    // ==================== Channel Write Operations ====================
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        return socketClient.addChannel(channelName, timestamps, values, unit, comment, dataType);
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType,
                              ChannelMetadata metadata) throws Mdf4Exception {
        return socketClient.addChannel(channelName, timestamps, values, unit, comment, dataType, metadata);
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return socketClient.addChannel(channelName, timestamps, values);
    }
    
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        return socketClient.writeMultipleChannels(channelDataList);
    }
    
    // ==================== Channel Metadata Operations ====================
    
    public boolean setChannelMetadata(String channelName, ChannelMetadata metadata) throws Mdf4Exception {
        return socketClient.setChannelMetadata(channelName, metadata);
    }
    
    public ChannelMetadata getChannelMetadata(String channelName) throws Mdf4Exception {
        return socketClient.getChannelMetadata(channelName);
    }
    
    // ==================== Channel Read Operations ====================
    
    public List<String> getChannelNames() throws Mdf4Exception {
        return socketClient.getChannelNames();
    }
    
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        return socketClient.getChannelInfo(channelName);
    }
    
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        return socketClient.readChannel(channelName);
    }
    
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        return socketClient.readMultipleChannels(channelNames);
    }
    
    // ==================== Partial Read Operations ====================
    
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        return socketClient.readChannelPartial(channelName, startIndex, count);
    }
    
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        return socketClient.readChannelsPartial(channelNames, startTime, endTime);
    }
    
    public int getSampleCount(String channelName) throws Mdf4Exception {
        return socketClient.getSampleCount(channelName);
    }
    
    public double[] getTimeRange() throws Mdf4Exception {
        return socketClient.getTimeRange();
    }
    
    // ==================== Utility Operations ====================
    
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        return socketClient.filterChannels(channelNames);
    }
    
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        return socketClient.cutTimeRange(startTime, endTime);
    }
    
    @Override
    public void close() {
        socketClient.close();
        if (manageService && serviceManager != null) {
            serviceManager.stopService();
        }
    }
}
