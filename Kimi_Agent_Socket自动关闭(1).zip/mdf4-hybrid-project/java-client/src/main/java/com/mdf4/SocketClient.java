package com.mdf4;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * SocketClient - Java client for MDF4 operations via custom socket protocol.
 * Features automatic reconnection and service restart.
 */
public class SocketClient implements AutoCloseable {
    
    private static final int DEFAULT_PORT = 25333;
    private static final String DEFAULT_HOST = "localhost";
    private static final int CONNECT_TIMEOUT_MS = 5000;
    private static final int READ_TIMEOUT_MS = 60000;
    private static final int MAX_RECONNECT_ATTEMPTS = 3;
    private static final int RECONNECT_DELAY_MS = 1000;
    
    private final String host;
    private final int port;
    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;
    private final ObjectMapper mapper;
    private final AtomicInteger requestIdGenerator;
    private boolean connected;
    private PythonServiceManager serviceManager;
    private boolean autoReconnect;
    private boolean autoRestartService;
    
    /**
     * Default constructor - connects to localhost:25333
     */
    public SocketClient() {
        this(DEFAULT_HOST, DEFAULT_PORT);
    }
    
    /**
     * Constructor with custom host and port
     */
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.mapper = new ObjectMapper();
        this.requestIdGenerator = new AtomicInteger(0);
        this.connected = false;
        this.autoReconnect = true;
        this.autoRestartService = true;
    }
    
    /**
     * Set service manager for auto-restart capability
     */
    public void setServiceManager(PythonServiceManager serviceManager) {
        this.serviceManager = serviceManager;
    }
    
    /**
     * Enable or disable auto-reconnect
     */
    public void setAutoReconnect(boolean enabled) {
        this.autoReconnect = enabled;
    }
    
    /**
     * Enable or disable auto-restart service
     */
    public void setAutoRestartService(boolean enabled) {
        this.autoRestartService = enabled;
    }
    
    /**
     * Connect to the Python service and perform handshake
     */
    public void connect() throws Mdf4Exception {
        connectWithRetry(0);
    }
    
    /**
     * Connect with retry logic
     */
    private void connectWithRetry(int attempt) throws Mdf4Exception {
        try {
            doConnect();
        } catch (Mdf4Exception e) {
            if (attempt < MAX_RECONNECT_ATTEMPTS && autoReconnect) {
                System.out.println("Connection failed, retrying in " + RECONNECT_DELAY_MS + "ms... (attempt " + 
                    (attempt + 1) + "/" + MAX_RECONNECT_ATTEMPTS + ")");
                
                // Try to restart service if enabled
                if (autoRestartService && serviceManager != null) {
                    System.out.println("Attempting to restart Python service...");
                    if (serviceManager.restartService()) {
                        System.out.println("Service restarted, retrying connection...");
                    }
                }
                
                try {
                    Thread.sleep(RECONNECT_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new Mdf4Exception("Connection interrupted", ie);
                }
                
                connectWithRetry(attempt + 1);
            } else {
                throw e;
            }
        }
    }
    
    /**
     * Perform actual connection
     */
    private void doConnect() throws Mdf4Exception {
        try {
            // Create socket with timeout
            socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            socket.setSoTimeout(READ_TIMEOUT_MS);
            socket.setKeepAlive(true);
            
            input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            
            // Perform handshake
            if (!performHandshake()) {
                close();
                throw new Mdf4Exception("Handshake failed with server");
            }
            
            connected = true;
            System.out.println("Connected to MDF4 Socket Server at " + host + ":" + port);
            
        } catch (java.net.ConnectException e) {
            throw new Mdf4Exception("Failed to connect to server at " + host + ":" + port + 
                    ". Make sure the Python service is running.", e);
        } catch (IOException e) {
            throw new Mdf4Exception("Connection error: " + e.getMessage(), e);
        }
    }
    
    /**
     * Perform handshake with server
     */
    private boolean performHandshake() throws IOException {
        ObjectNode request = mapper.createObjectNode();
        request.put("cmd", "HANDSHAKE");
        request.put("reqId", "0");
        request.set("params", mapper.createObjectNode());
        
        sendMessage(request);
        ObjectNode response = receiveMessage();
        
        if (response == null) {
            return false;
        }
        
        boolean success = response.get("success").asBoolean();
        if (success) {
            ObjectNode data = (ObjectNode) response.get("data");
            String version = data.get("version").asText();
            System.out.println("Handshake successful, server version: " + version);
        }
        
        return success;
    }
    
    /**
     * Check if connection is alive by sending ping
     */
    public boolean isConnectionAlive() {
        if (!isConnected()) {
            return false;
        }
        
        try {
            ObjectNode params = mapper.createObjectNode();
            ObjectNode result = sendCommand("PING", params);
            return result != null && result.has("status");
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Reconnect to server
     */
    public boolean reconnect() {
        System.out.println("Attempting to reconnect...");
        disconnect();
        
        try {
            connect();
            return true;
        } catch (Mdf4Exception e) {
            System.err.println("Reconnection failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Disconnect from the server
     */
    public void disconnect() {
        close();
    }
    
    /**
     * Check if connected
     */
    public boolean isConnected() {
        return connected && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    // ==================== Private Communication Methods ====================
    
    /**
     * Send a message to the server
     */
    private void sendMessage(ObjectNode message) throws IOException {
        byte[] jsonBytes = mapper.writeValueAsBytes(message);
        byte[] lengthPrefix = ByteBuffer.allocate(4).putInt(jsonBytes.length).array();
        
        synchronized (output) {
            output.write(lengthPrefix);
            output.write(jsonBytes);
            output.flush();
        }
    }
    
    /**
     * Receive a message from the server
     */
    private ObjectNode receiveMessage() throws IOException {
        // Read length prefix (4 bytes)
        byte[] lengthBytes = new byte[4];
        input.readFully(lengthBytes);
        int messageLength = ByteBuffer.wrap(lengthBytes).getInt();
        
        // Read message body
        byte[] messageBytes = new byte[messageLength];
        input.readFully(messageBytes);
        
        return (ObjectNode) mapper.readTree(messageBytes);
    }
    
    /**
     * Send a command and receive response with auto-reconnect
     */
    private ObjectNode sendCommand(String command, ObjectNode params) throws Mdf4Exception {
        return sendCommand(command, params, true);
    }
    
    /**
     * Send a command and receive response
     */
    private ObjectNode sendCommand(String command, ObjectNode params, boolean allowReconnect) throws Mdf4Exception {
        checkConnection();
        
        try {
            ObjectNode request = mapper.createObjectNode();
            request.put("cmd", command);
            request.put("reqId", String.valueOf(requestIdGenerator.incrementAndGet()));
            request.set("params", params != null ? params : mapper.createObjectNode());
            
            sendMessage(request);
            ObjectNode response = receiveMessage();
            
            if (response == null) {
                throw new Mdf4Exception("No response from server");
            }
            
            if (!response.get("success").asBoolean()) {
                String error = response.has("error") ? response.get("error").asText() : "Unknown error";
                throw new Mdf4Exception("Server error: " + error);
            }
            
            return (ObjectNode) response.get("data");
            
        } catch (IOException e) {
            connected = false;
            
            // Try to reconnect and retry
            if (allowReconnect && autoReconnect) {
                System.out.println("Connection lost, attempting to reconnect...");
                
                // Try to restart service if enabled
                if (autoRestartService && serviceManager != null) {
                    serviceManager.restartService();
                }
                
                if (reconnect()) {
                    // Retry the command
                    return sendCommand(command, params, false);
                }
            }
            
            throw new Mdf4Exception("Communication error: " + e.getMessage(), e);
        }
    }
    
    private void checkConnection() throws Mdf4Exception {
        if (!isConnected()) {
            if (autoReconnect) {
                if (!reconnect()) {
                    throw new Mdf4Exception("Not connected to server and reconnection failed");
                }
            } else {
                throw new Mdf4Exception("Not connected to server. Call connect() first.");
            }
        }
    }
    
    @Override
    public void close() {
        connected = false;
        try {
            if (input != null) input.close();
        } catch (IOException e) {
            // Ignore
        }
        try {
            if (output != null) output.close();
        } catch (IOException e) {
            // Ignore
        }
        try {
            if (socket != null) socket.close();
        } catch (IOException e) {
            // Ignore
        }
        System.out.println("Disconnected from server");
    }
    
    // ==================== File Operations ====================
    
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        return createNewFile(filePath, null, true);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata) throws Mdf4Exception {
        return createNewFile(filePath, metadata, true);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata, boolean autoCreateDirs) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("filePath", filePath);
        params.put("autoCreateDirs", autoCreateDirs);
        
        if (metadata != null) {
            ObjectNode metaNode = mapper.createObjectNode();
            metaNode.put("title", metadata.getTitle());
            metaNode.put("author", metadata.getAuthor());
            metaNode.put("description", metadata.getDescription());
            metaNode.put("project", metadata.getProject());
            metaNode.put("version", metadata.getVersion());
            
            if (metadata.getCustomProperties() != null) {
                ObjectNode customNode = mapper.createObjectNode();
                for (Map.Entry<String, String> entry : metadata.getCustomProperties().entrySet()) {
                    customNode.put(entry.getKey(), entry.getValue());
                }
                metaNode.set("customProperties", customNode);
            }
            
            params.set("metadata", metaNode);
        }
        
        ObjectNode result = sendCommand("createNewFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean openFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, true, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        return openFile(filePath, readOnly, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate) throws Mdf4Exception {
        return openFile(filePath, readOnly, autoCreate, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate, FileMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("filePath", filePath);
        params.put("readOnly", readOnly);
        params.put("autoCreate", autoCreate);
        
        if (metadata != null) {
            ObjectNode metaNode = mapper.createObjectNode();
            metaNode.put("title", metadata.getTitle());
            metaNode.put("author", metadata.getAuthor());
            metaNode.put("description", metadata.getDescription());
            metaNode.put("project", metadata.getProject());
            metaNode.put("version", metadata.getVersion());
            params.set("metadata", metaNode);
        }
        
        ObjectNode result = sendCommand("openFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean closeFile() throws Mdf4Exception {
        ObjectNode result = sendCommand("closeFile", null);
        return result.get("success").asBoolean();
    }
    
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        if (filePath != null) {
            params.put("filePath", filePath);
        }
        params.put("compression", compression);
        ObjectNode result = sendCommand("saveFile", params);
        return result.get("success").asBoolean();
    }
    
    public boolean saveFile() throws Mdf4Exception {
        return saveFile(null, 0);
    }
    
    // ==================== File Metadata Operations ====================
    
    public boolean setFileMetadata(FileMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        ObjectNode metaNode = mapper.createObjectNode();
        
        metaNode.put("title", metadata.getTitle());
        metaNode.put("author", metadata.getAuthor());
        metaNode.put("description", metadata.getDescription());
        metaNode.put("project", metadata.getProject());
        metaNode.put("version", metadata.getVersion());
        
        if (metadata.getCustomProperties() != null) {
            ObjectNode customNode = mapper.createObjectNode();
            for (Map.Entry<String, String> entry : metadata.getCustomProperties().entrySet()) {
                customNode.put(entry.getKey(), entry.getValue());
            }
            metaNode.set("customProperties", customNode);
        }
        
        params.set("metadata", metaNode);
        ObjectNode result = sendCommand("setFileMetadata", params);
        return result.get("success").asBoolean();
    }
    
    public FileMetadata getFileMetadata() throws Mdf4Exception {
        ObjectNode result = sendCommand("getFileMetadata", null);
        ObjectNode metaNode = (ObjectNode) result.get("metadata");
        
        FileMetadata metadata = new FileMetadata();
        if (metaNode != null) {
            metadata.setTitle(metaNode.path("title").asText(""));
            metadata.setAuthor(metaNode.path("author").asText(""));
            metadata.setDescription(metaNode.path("description").asText(""));
            metadata.setProject(metaNode.path("project").asText(""));
            metadata.setVersion(metaNode.path("version").asText("1.0"));
            metadata.setCreatedAt(metaNode.path("createdAt").asText(""));
            metadata.setModifiedAt(metaNode.path("modifiedAt").asText(""));
            
            ObjectNode customNode = (ObjectNode) metaNode.get("customProperties");
            if (customNode != null) {
                Map<String, String> customProps = new HashMap<>();
                Iterator<String> fieldNames = customNode.fieldNames();
                while (fieldNames.hasNext()) {
                    String key = fieldNames.next();
                    customProps.put(key, customNode.get(key).asText());
                }
                metadata.setCustomProperties(customProps);
            }
        }
        
        return metadata;
    }
    
    // ==================== Write Operations ====================
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, unit, comment, dataType, null);
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType,
                              ChannelMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ArrayNode tsArray = params.putArray("timestamps");
        for (Double ts : timestamps) {
            tsArray.add(ts);
        }
        
        ArrayNode valArray = params.putArray("values");
        for (Double val : values) {
            valArray.add(val);
        }
        
        params.put("unit", unit);
        params.put("comment", comment);
        params.put("dataType", dataType);
        
        if (metadata != null) {
            ObjectNode metaNode = mapper.createObjectNode();
            metaNode.put("source", metadata.getSource());
            metaNode.put("sensorType", metadata.getSensorType());
            metaNode.put("calibrationDate", metadata.getCalibrationDate());
            metaNode.put("samplingRate", metadata.getSamplingRate());
            metaNode.put("minValue", metadata.getMinValue());
            metaNode.put("maxValue", metadata.getMaxValue());
            
            if (metadata.getCustomProperties() != null) {
                ObjectNode customNode = mapper.createObjectNode();
                for (Map.Entry<String, String> entry : metadata.getCustomProperties().entrySet()) {
                    customNode.put(entry.getKey(), entry.getValue());
                }
                metaNode.set("customProperties", customNode);
            }
            
            params.set("metadata", metaNode);
        }
        
        ObjectNode result = sendCommand("addChannel", params);
        return result.get("success").asBoolean();
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, "", "", "float", null);
    }
    
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        ArrayNode channelsArray = params.putArray("channels");
        
        for (ChannelData data : channelDataList) {
            ObjectNode channelObj = channelsArray.addObject();
            channelObj.put("name", data.getName());
            
            ArrayNode tsArray = channelObj.putArray("timestamps");
            for (Double ts : data.getTimestamps()) {
                tsArray.add(ts);
            }
            
            ArrayNode valArray = channelObj.putArray("values");
            for (Double val : data.getValues()) {
                valArray.add(val);
            }
            
            channelObj.put("unit", data.getUnit());
            channelObj.put("comment", data.getComment());
            channelObj.put("dataType", data.getDataType());
        }
        
        ObjectNode result = sendCommand("writeMultipleChannels", params);
        return result.get("success").asBoolean();
    }
    
    // ==================== Channel Metadata Operations ====================
    
    public boolean setChannelMetadata(String channelName, ChannelMetadata metadata) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode metaNode = mapper.createObjectNode();
        metaNode.put("source", metadata.getSource());
        metaNode.put("sensorType", metadata.getSensorType());
        metaNode.put("calibrationDate", metadata.getCalibrationDate());
        metaNode.put("samplingRate", metadata.getSamplingRate());
        metaNode.put("minValue", metadata.getMinValue());
        metaNode.put("maxValue", metadata.getMaxValue());
        
        if (metadata.getCustomProperties() != null) {
            ObjectNode customNode = mapper.createObjectNode();
            for (Map.Entry<String, String> entry : metadata.getCustomProperties().entrySet()) {
                customNode.put(entry.getKey(), entry.getValue());
            }
            metaNode.set("customProperties", customNode);
        }
        
        params.set("metadata", metaNode);
        ObjectNode result = sendCommand("setChannelMetadata", params);
        return result.get("success").asBoolean();
    }
    
    public ChannelMetadata getChannelMetadata(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getChannelMetadata", params);
        ObjectNode metaNode = (ObjectNode) result.get("metadata");
        
        ChannelMetadata metadata = new ChannelMetadata();
        if (metaNode != null) {
            metadata.setSource(metaNode.path("source").asText(""));
            metadata.setSensorType(metaNode.path("sensorType").asText(""));
            metadata.setCalibrationDate(metaNode.path("calibrationDate").asText(""));
            metadata.setSamplingRate(metaNode.path("samplingRate").asDouble(0));
            metadata.setMinValue(metaNode.path("minValue").asDouble(0));
            metadata.setMaxValue(metaNode.path("maxValue").asDouble(0));
            
            ObjectNode customNode = (ObjectNode) metaNode.get("customProperties");
            if (customNode != null) {
                Map<String, String> customProps = new HashMap<>();
                Iterator<String> fieldNames = customNode.fieldNames();
                while (fieldNames.hasNext()) {
                    String key = fieldNames.next();
                    customProps.put(key, customNode.get(key).asText());
                }
                metadata.setCustomProperties(customProps);
            }
        }
        
        return metadata;
    }
    
    // ==================== Read Operations ====================
    
    public List<String> getChannelNames() throws Mdf4Exception {
        ObjectNode result = sendCommand("getChannelNames", null);
        ArrayNode namesArray = (ArrayNode) result.get("names");
        
        List<String> names = new ArrayList<>();
        for (int i = 0; i < namesArray.size(); i++) {
            names.add(namesArray.get(i).asText());
        }
        return names;
    }
    
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getChannelInfo", params);
        ObjectNode infoObj = (ObjectNode) result.get("info");
        
        if (infoObj == null) {
            return null;
        }
        
        ChannelInfo info = new ChannelInfo();
        info.setName(infoObj.get("name").asText());
        info.setUnit(infoObj.get("unit").asText());
        info.setComment(infoObj.get("comment").asText());
        info.setSamplesCount(infoObj.get("samples_count").asInt());
        info.setFirstTimestamp(infoObj.get("first_timestamp").asDouble());
        info.setLastTimestamp(infoObj.get("last_timestamp").asDouble());
        
        // Parse metadata
        ObjectNode metaNode = (ObjectNode) infoObj.get("metadata");
        if (metaNode != null) {
            ChannelMetadata metadata = new ChannelMetadata();
            metadata.setSource(metaNode.path("source").asText(""));
            metadata.setSensorType(metaNode.path("sensorType").asText(""));
            info.setMetadata(metadata);
        }
        
        return info;
    }
    
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("readChannel", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        return parseDataRecord(recordObj);
    }
    
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        ArrayNode namesArray = params.putArray("channelNames");
        for (String name : channelNames) {
            namesArray.add(name);
        }
        
        ObjectNode result = sendCommand("readMultipleChannels", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        List<DataRecord> records = new ArrayList<>();
        for (int i = 0; i < recordsArray.size(); i++) {
            records.add(parseDataRecord((ObjectNode) recordsArray.get(i)));
        }
        return records;
    }
    
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        params.put("startIndex", startIndex);
        params.put("count", count);
        
        ObjectNode result = sendCommand("readChannelPartial", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        return parseDataRecord(recordObj);
    }
    
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        ArrayNode namesArray = params.putArray("channelNames");
        for (String name : channelNames) {
            namesArray.add(name);
        }
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("readChannelsPartial", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        List<DataRecord> records = new ArrayList<>();
        for (int i = 0; i < recordsArray.size(); i++) {
            records.add(parseDataRecord((ObjectNode) recordsArray.get(i)));
        }
        return records;
    }
    
    public int getSampleCount(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getSampleCount", params);
        return result.get("count").asInt();
    }
    
    public double[] getTimeRange() throws Mdf4Exception {
        ObjectNode result = sendCommand("getTimeRange", null);
        ArrayNode rangeArray = (ArrayNode) result.get("range");
        return new double[]{rangeArray.get(0).asDouble(), rangeArray.get(1).asDouble()};
    }
    
    // ==================== Utility Operations ====================
    
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        ArrayNode namesArray = params.putArray("channelNames");
        for (String name : channelNames) {
            namesArray.add(name);
        }
        
        ObjectNode result = sendCommand("filterChannels", params);
        return result.get("success").asBoolean();
    }
    
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("cutTimeRange", params);
        return result.get("success").asBoolean();
    }
    
    // ==================== Helper Methods ====================
    
    private DataRecord parseDataRecord(ObjectNode recordObj) {
        if (recordObj == null) {
            return null;
        }
        
        DataRecord record = new DataRecord();
        record.setChannelName(recordObj.get("channelName").asText());
        record.setUnit(recordObj.get("unit").asText());
        
        ArrayNode tsArray = (ArrayNode) recordObj.get("timestamps");
        List<Double> timestamps = new ArrayList<>();
        for (int i = 0; i < tsArray.size(); i++) {
            timestamps.add(tsArray.get(i).asDouble());
        }
        record.setTimestamps(timestamps);
        
        ArrayNode valArray = (ArrayNode) recordObj.get("values");
        List<Double> values = new ArrayList<>();
        for (int i = 0; i < valArray.size(); i++) {
            values.add(valArray.get(i).asDouble());
        }
        record.setValues(values);
        
        return record;
    }
}
