# MDF4 Hybrid Project - Quick Start Guide

## 5-Minute Quick Start

### Step 1: Install Python Dependencies (1 minute)

```bash
cd python-service
pip install -r requirements.txt
cd ..
```

### Step 2: Build Java Client (1 minute)

```bash
cd java-client
mvn clean package -DskipTests
cd ..
```

### Step 3: Run Java Example (自动启动Python服务)

```bash
cd java-client
java -jar target/mdf4-java-client-1.0.0.jar
```

Java会自动检测并启动Python服务！

## 核心功能演示

### 1. 自动管理服务

```java
// Java自动管理Python服务生命周期
Mdf4Client client = new Mdf4Client();
client.connect();  // 服务未运行？自动启动！

// ... 使用客户端 ...

client.close();  // 自动停止服务
```

### 2. 创建带元数据的MDF4文件

```java
// 文件元数据
FileMetadata fileMeta = FileMetadata.builder()
    .title("Engine Test Data")
    .author("Test Engineer")
    .description("Performance test session 1")
    .project("Project Alpha")
    .customProperty("testId", "T-001")
    .build();

// 自动创建文件和目录
client.createNewFile("data/test.mf4", fileMeta, true);

// 通道元数据
ChannelMetadata channelMeta = ChannelMetadata.builder()
    .source("ECU")
    .sensorType("RPM Sensor")
    .samplingRate(100.0)
    .build();

// 添加数据
client.addChannel("EngineSpeed", timestamps, values, 
                  "RPM", "Engine RPM", "float", channelMeta);

client.saveFile();
```

### 3. 文件不存在时自动创建

```java
// 如果文件不存在，自动创建
client.openFile("data.mf4", false, true);  // autoCreate=true

// 带元数据自动创建
client.openFile("data.mf4", false, true, fileMeta);
```

### 4. 服务自动重启

```java
// 如果服务因超时关闭，Java会自动重启
Mdf4Client client = new Mdf4Client();
client.connect();

// 长时间操作...
Thread.sleep(60000);  // 假设服务超时关闭

// 下次操作时自动重连和重启
client.readChannel("EngineSpeed");  // 自动处理
```

## Python服务命令

```bash
cd python-service

# 前台运行（调试）
python socket_server.py foreground

# 后台运行
python socket_server.py start

# 检查状态
python socket_server.py status

# 停止服务
python socket_server.py stop
```

## 快速代码示例

### 完整示例

```java
import com.mdf4.*;
import java.util.*;

public class QuickExample {
    public static void main(String[] args) throws Exception {
        // 创建客户端（自动管理服务）
        Mdf4Client client = new Mdf4Client();
        client.connect();
        
        // 创建文件元数据
        FileMetadata fileMeta = FileMetadata.builder()
            .title("Vehicle Data")
            .author("Engineer")
            .description("Test drive data")
            .build();
        
        // 创建文件（自动创建目录）
        client.createNewFile("output/vehicle.mf4", fileMeta, true);
        
        // 准备数据
        List<Double> timestamps = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            timestamps.add(i * 0.01);
            values.add(1000.0 + i * 10);
        }
        
        // 通道元数据
        ChannelMetadata channelMeta = ChannelMetadata.builder()
            .source("CAN Bus")
            .sensorType("Engine RPM")
            .samplingRate(100.0)
            .build();
        
        // 写入数据
        client.addChannel("EngineRPM", timestamps, values, 
                         "rpm", "Engine RPM", "float", channelMeta);
        
        client.saveFile();
        
        // 读取元数据
        FileMetadata loadedFileMeta = client.getFileMetadata();
        System.out.println("File: " + loadedFileMeta.getTitle());
        
        ChannelMetadata loadedChannelMeta = client.getChannelMetadata("EngineRPM");
        System.out.println("Source: " + loadedChannelMeta.getSource());
        
        // 读取数据
        DataRecord record = client.readChannel("EngineRPM");
        System.out.println("Samples: " + record.getSampleCount());
        
        client.close();
    }
}
```

## 常见问题

### Q: Java如何知道Python服务是否运行？
A: Java会尝试连接端口，如果失败且配置了服务管理，会自动启动服务。

### Q: 服务超时后如何恢复？
A: Java会自动检测连接断开，尝试重新连接并重启服务。

### Q: 元数据存储在哪里？
A: 文件元数据存储在MDF4文件头中，通道元数据嵌入在通道注释中。

### Q: 可以在没有Java的情况下使用Python服务吗？
A: 可以！直接运行 `python socket_server.py foreground` 即可。

## 下一步

- 查看完整文档: [README.md](README.md)
- 了解架构: [ARCHITECTURE.md](ARCHITECTURE.md)
- 查看协议: [protocol.md](protocol.md)
