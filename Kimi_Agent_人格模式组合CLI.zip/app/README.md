# 模式编排器 (Pattern Orchestrator)

命令行工具，用于管理人格(Persona)、思维模型(Thinking Model)和对话模式(Dialogue Pattern)的组合，为 opencode 生成可复用的模式配置。

## 安装

```bash
cd opencode-patterns
npm install
npm run build
npm link          # 全局安装命令
```

## 目录结构

```
./
personas/              # 人格 .md 文件
thinking-models/       # 思维模型 .md 文件
dialogue-patterns/     # 对话模式 .md 文件
```

## 命令

### 添加组件

```bash
# 添加人格
opencode-patterns add-persona ./personas/java_engineer.md

# 添加思维模型
opencode-patterns add-thinking ./thinking-models/OODA_loop.md

# 添加对话模式
opencode-patterns add-dialogue ./dialogue-patterns/socratic.md
```

### 移除组件

```bash
opencode-patterns remove-persona java_engineer
opencode-patterns remove-thinking OODA_loop
opencode-patterns remove-dialogue socratic
```

### 创建模式（组合）

```bash
# 创建基础模式
opencode-patterns create-pattern Plan \\
  --persona java_engineer \\
  --thinking OODA_loop \\
  --dialogue socratic

# 创建继承模式（继承 Plan，仅替换人格）
opencode-patterns create-pattern NewPlan \\
  --inherit Plan \\
  --persona python_expert

# 等效于: NewPlan = Plan + python_expert(替代java_engineer)
```

### 查看模式

```bash
# 显示模式详情
opencode-patterns show Plan

# 导出到文件
opencode-patterns show Plan --export ./output.md
```

### 使用模式（输出到 opencode）

```bash
# 将组合后的配置输出到标准输出
opencode-patterns use Plan | opencode

# 或保存到文件
opencode-patterns use Plan > system-prompt.md
```

### 修改模式槽位

```bash
# 设置单个槽位
opencode-patterns set-persona Plan python_expert
opencode-patterns set-thinking Plan first_principles
opencode-patterns set-dialogue Plan direct_answer

# 清空槽位
opencode-patterns clear-persona Plan
opencode-patterns clear-thinking Plan
opencode-patterns clear-dialogue Plan
```

### 删除模式

```bash
opencode-patterns delete-pattern Plan
```

### 列出所有内容

```bash
opencode-patterns list              # 列出全部
opencode-patterns list personas     # 仅列出人格
opencode-patterns list thinking     # 仅列出思维模型
opencode-patterns list dialogue     # 仅列出对话模式
opencode-patterns list patterns     # 仅列出模式
```

## 继承机制

模式支持链式继承。当创建 `--inherit` 模式时：

1. 子模式自动复制父模式的所有槽位
2. 子模式可以覆写任意槽位
3. 查看时自动解析继承链，显示合并后的结果

示例：

```bash
# [Base] = java + OODA + socratic
opencode-patterns create-pattern Base --persona java --thinking OODA --dialogue socratic

# [Advanced] 继承 [Base]，只改思维模型
opencode-patterns create-pattern Advanced --inherit Base --thinking first_principles

# [Advanced] 实际 = java + first_principles + socratic
```

## 完整工作流示例

```bash
# 1. 添加组件
opencode-patterns add-persona ./personas/java_engineer.md
opencode-patterns add-thinking ./thinking-models/OODA_loop.md
opencode-patterns add-dialogue ./dialogue-patterns/socratic.md

# 2. 创建 Plan 模式
opencode-patterns create-pattern Plan --persona java_engineer --thinking OODA_loop --dialogue socratic

# 3. 创建 Build 模式（继承 Plan，改人格和对话模式）
opencode-patterns create-pattern Build --inherit Plan --persona python_expert --dialogue direct_answer

# 4. 查看
opencode-patterns list
opencode-patterns show Build

# 5. 使用
opencode-patterns use Build | opencode
```
