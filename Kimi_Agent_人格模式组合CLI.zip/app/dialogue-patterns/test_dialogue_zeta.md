# 测试对话模式 Zeta

## 模式说明
这是用于测试的 Zeta 对话模式。用于验证对话模式切换。

## 测试标记
- DIALOGUE_TYPE: ZETA
- TEST_CHECKSUM: dialogue-zeta-2a8f4c
- EXPECTED_OUTPUT: 包含"Zeta 测试对话模式已通过"标记

## 对话规则
1. 每句话开头加上 "[ZETA] " 前缀
2. 每段回复结尾加上：「Zeta 测试对话模式已通过」
