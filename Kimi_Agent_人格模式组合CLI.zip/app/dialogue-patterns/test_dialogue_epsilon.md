# 测试对话模式 Epsilon

## 模式说明
这是用于测试的 Epsilon 对话模式。验证对话模式配置是否正确生效。

## 测试标记
- DIALOGUE_TYPE: EPSILON
- TEST_CHECKSUM: dialogue-epsilon-9c3e7d
- EXPECTED_OUTPUT: 包含"Epsilon 测试对话模式已通过"标记

## 对话规则
1. 每句话开头加上 "[EPSILON] " 前缀
2. 每段回复结尾加上：「Epsilon 测试对话模式已通过」
