import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import type { Config, BaseComponent, Pattern, ComponentType } from '../types';

const CONFIG_DIR = path.join(os.homedir(), '.opencode-patterns');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

const DEFAULT_PERSONAS_DIR = path.join(process.cwd(), 'personas');
const DEFAULT_THINKING_DIR = path.join(process.cwd(), 'thinking-models');
const DEFAULT_DIALOGUE_DIR = path.join(process.cwd(), 'dialogue-patterns');
const DEFAULT_PATTERNS_DIR = path.join(process.cwd(), 'patterns');

export function getConfigDir(): string {
  return CONFIG_DIR;
}

export function ensureDirectories(): void {
  const dirs = [CONFIG_DIR, DEFAULT_PERSONAS_DIR, DEFAULT_THINKING_DIR, DEFAULT_DIALOGUE_DIR, DEFAULT_PATTERNS_DIR];
  for (const dir of dirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

export function loadConfig(): Config {
  ensureDirectories();
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
    } catch {
      return createDefaultConfig();
    }
  }
  return createDefaultConfig();
}

export function saveConfig(config: Config): void {
  ensureDirectories();
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

function createDefaultConfig(): Config {
  return {
    version: '1.0.0',
    personas: [],
    thinkingModels: [],
    dialoguePatterns: [],
    patterns: [],
  };
}

// Load .md file from disk and create a component
export function loadMdFile(filePath: string, type: ComponentType): BaseComponent {
  const content = fs.readFileSync(filePath, 'utf-8');
  const fileName = path.basename(filePath);
  const name = fileName.replace(/\.md$/, '');
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');

  // Extract first non-empty line as description
  const lines = content.split('\n').filter((l) => l.trim());
  const description = lines.length > 1 ? lines[1].trim() : lines[0]?.trim() || '';

  return { id, name, fileName, description, content, type };
}

// Get component by id from config
export function getComponent(config: Config, id: string, type: ComponentType): BaseComponent | undefined {
  return findComponent(config, id, type);
}

// Find component with fuzzy matching (id, name, or filename)
export function findComponent(config: Config, query: string, type: ComponentType): BaseComponent | undefined {
  const arr = type === 'persona' ? config.personas
    : type === 'thinking' ? config.thinkingModels
    : config.dialoguePatterns;

  const q = query.toLowerCase();

  // Exact match (id, name, filename)
  let found = arr.find((c) => c.id === q || c.name.toLowerCase() === q || c.fileName.toLowerCase() === q);
  if (found) return found;

  // Partial match (id contains query, or name contains query)
  found = arr.find((c) => c.id.includes(q) || c.name.toLowerCase().includes(q) || c.fileName.toLowerCase().includes(q));
  return found;
}

// Resolve pattern: combine with parent if inherits
export function resolvePattern(config: Config, pattern: Pattern): Pattern {
  if (!pattern.inheritsFrom) return pattern;

  const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
  if (!parent) return pattern;

  const resolvedParent = resolvePattern(config, parent);

  return {
    ...pattern,
    slots: {
      persona: pattern.slots.persona ?? resolvedParent.slots.persona,
      thinking: pattern.slots.thinking ?? resolvedParent.slots.thinking,
      dialogue: pattern.slots.dialogue ?? resolvedParent.slots.dialogue,
    },
  };
}

// Export pattern config for opencode use
export function exportPatternConfig(config: Config, pattern: Pattern): string {
  const resolved = resolvePattern(config, pattern);
  const parts: string[] = [];

  parts.push(`# Pattern: ${pattern.label}`);
  if (pattern.inheritsFrom) {
    const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
    parts.push(`# Inherits from: ${parent?.label || pattern.inheritsFrom}`);
  }
  parts.push('');

  const persona = resolved.slots.persona ? getComponent(config, resolved.slots.persona, 'persona') : null;
  const thinking = resolved.slots.thinking ? getComponent(config, resolved.slots.thinking, 'thinking') : null;
  const dialogue = resolved.slots.dialogue ? getComponent(config, resolved.slots.dialogue, 'dialogue') : null;

  if (persona) {
    parts.push(`## Persona: ${persona.name}`);
    parts.push(persona.content);
    parts.push('');
  }

  if (thinking) {
    parts.push(`## Thinking Model: ${thinking.name}`);
    parts.push(thinking.content);
    parts.push('');
  }

  if (dialogue) {
    parts.push(`## Dialogue Pattern: ${dialogue.name}`);
    parts.push(dialogue.content);
    parts.push('');
  }

  return parts.join('\n');
}
