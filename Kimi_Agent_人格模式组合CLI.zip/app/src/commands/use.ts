import chalk from 'chalk';
import { loadConfig, resolvePattern, getComponent } from '../core/config';

export function useCommand(name: string): void {
  const config = loadConfig();

  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(
    (p) => p.id === id || p.name === name || p.label === name
  );

  if (!pattern) {
    console.log(chalk.red(`  Pattern "${name}" not found.`));
    process.exit(1);
  }

  const resolved = resolvePattern(config, pattern);

  // Output raw merged config to stdout (for piping)
  const parts: string[] = [];

  const persona = resolved.slots.persona ? getComponent(config, resolved.slots.persona, 'persona') : null;
  const thinking = resolved.slots.thinking ? getComponent(config, resolved.slots.thinking, 'thinking') : null;
  const dialogue = resolved.slots.dialogue ? getComponent(config, resolved.slots.dialogue, 'dialogue') : null;

  if (persona) {
    parts.push(`# === Persona: ${persona.name} ===\n`);
    parts.push(persona.content);
    parts.push('');
  }

  if (thinking) {
    parts.push(`# === Thinking Model: ${thinking.name} ===\n`);
    parts.push(thinking.content);
    parts.push('');
  }

  if (dialogue) {
    parts.push(`# === Dialogue Pattern: ${dialogue.name} ===\n`);
    parts.push(dialogue.content);
    parts.push('');
  }

  console.log(parts.join('\n'));
}
