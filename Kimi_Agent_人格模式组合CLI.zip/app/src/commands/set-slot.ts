import chalk from 'chalk';
import { loadConfig, saveConfig, findComponent } from '../core/config';
import type { ComponentType } from '../types';

export function setSlotCommand(
  patternName: string,
  slotType: ComponentType,
  componentId: string
): void {
  const config = loadConfig();

  const patternId = patternName.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(
    (p) => p.id === patternId || p.name === patternName || p.label === patternName
  );

  if (!pattern) {
    console.log(chalk.red(`  Pattern "${patternName}" not found.`));
    process.exit(1);
  }

  // Validate component exists
  const component = findComponent(config, componentId, slotType);

  if (!component) {
    console.log(chalk.red(`  ${slotType} "${componentId}" not found.`));
    process.exit(1);
  }

  // Update slot
  const slotKey = slotType === 'persona' ? 'persona'
    : slotType === 'thinking' ? 'thinking'
    : 'dialogue';

  pattern.slots[slotKey] = component.id;
  saveConfig(config);

  const color = slotType === 'persona' ? chalk.blue
    : slotType === 'thinking' ? chalk.magenta
    : chalk.green;

  console.log(color(`  Set ${slotType} of ${pattern.label} to ${component.name}\n`));
}
