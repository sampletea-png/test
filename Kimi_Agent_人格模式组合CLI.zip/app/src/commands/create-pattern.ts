import chalk from 'chalk';
import { loadConfig, saveConfig, resolvePattern, findComponent } from '../core/config';

export function createPatternCommand(
  name: string,
  options: { inherit?: string; persona?: string; thinking?: string; dialogue?: string }
): void {
  const config = loadConfig();

  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const label = `[${name}]`;

  // Check if already exists
  if (config.patterns.some((p) => p.id === id)) {
    console.log(chalk.red(`  Pattern "${label}" already exists. Use a different name.`));
    process.exit(1);
  }

  // Build slots
  let slots = { persona: null as string | null, thinking: null as string | null, dialogue: null as string | null };

  if (options.inherit) {
    const parentId = options.inherit.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const parent = config.patterns.find((p) => p.id === parentId || p.name === options.inherit);
    if (!parent) {
      console.log(chalk.red(`  Parent pattern "${options.inherit}" not found.`));
      console.log(chalk.gray(`  Available: ${config.patterns.map((p) => p.label).join(', ') || '(none)'}`));
      process.exit(1);
    }
    const resolved = resolvePattern(config, parent);
    slots = { ...resolved.slots };
    console.log(chalk.cyan(`  Inheriting from ${parent.label}`));
  }

  // Override with explicit options
  if (options.persona) {
    const p = findComponent(config, options.persona, 'persona');
    if (!p) {
      console.log(chalk.red(`  Persona "${options.persona}" not found.`));
      process.exit(1);
    }
    slots.persona = p.id;
    console.log(chalk.blue(`  Persona: ${p.name}`));
  }

  if (options.thinking) {
    const t = findComponent(config, options.thinking, 'thinking');
    if (!t) {
      console.log(chalk.red(`  Thinking model "${options.thinking}" not found.`));
      process.exit(1);
    }
    slots.thinking = t.id;
    console.log(chalk.magenta(`  Thinking: ${t.name}`));
  }

  if (options.dialogue) {
    const d = findComponent(config, options.dialogue, 'dialogue');
    if (!d) {
      console.log(chalk.red(`  Dialogue pattern "${options.dialogue}" not found.`));
      process.exit(1);
    }
    slots.dialogue = d.id;
    console.log(chalk.green(`  Dialogue: ${d.name}`));
  }

  const newPattern = {
    id,
    name,
    label,
    inheritsFrom: options.inherit
      ? (config.patterns.find((p) => p.id === options.inherit?.toLowerCase().replace(/[^a-z0-9]/g, '-') || p.name === options.inherit)?.id || null)
      : null,
    slots,
  };

  config.patterns.push(newPattern);
  saveConfig(config);

  console.log(chalk.green(`\n  Created pattern: ${chalk.bold(label)}\n`));
}
