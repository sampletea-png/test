import * as fs from 'fs';
import * as path from 'path';
import chalk from 'chalk';
import { loadConfig, saveConfig, loadMdFile, ensureDirectories } from '../core/config';
import type { ComponentType } from '../types';

const DIR_MAP: Record<ComponentType, string> = {
  persona: 'personas',
  thinking: 'thinking-models',
  dialogue: 'dialogue-patterns',
};

export function addCommand(type: ComponentType, sourcePath: string): void {
  if (!fs.existsSync(sourcePath)) {
    console.log(chalk.red(`  File not found: ${sourcePath}`));
    process.exit(1);
  }

  const config = loadConfig();
  const component = loadMdFile(sourcePath, type);

  // Copy file to project's directory
  ensureDirectories();
  const targetDir = path.join(process.cwd(), DIR_MAP[type]);
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  const targetPath = path.join(targetDir, component.fileName);
  fs.copyFileSync(sourcePath, targetPath);

  // Add to config
  const arr = type === 'persona' ? config.personas
    : type === 'thinking' ? config.thinkingModels
    : config.dialoguePatterns;

  const existing = arr.findIndex((c) => c.id === component.id);
  if (existing >= 0) {
    arr[existing] = component;
    console.log(chalk.yellow(`  Updated ${type}: ${chalk.bold(component.fileName)}`));
  } else {
    arr.push(component);
    console.log(chalk.green(`  Added ${type}: ${chalk.bold(component.fileName)}`));
  }

  saveConfig(config);
  console.log(chalk.gray(`  Saved to: ${targetPath}\n`));
}
