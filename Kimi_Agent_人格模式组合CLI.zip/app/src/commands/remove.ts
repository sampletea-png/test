import chalk from 'chalk';
import { loadConfig, saveConfig } from '../core/config';
import type { ComponentType } from '../types';

export function removeCommand(type: ComponentType, idOrName: string): void {
  const config = loadConfig();

  const arr = type === 'persona' ? config.personas
    : type === 'thinking' ? config.thinkingModels
    : config.dialoguePatterns;

  const idx = arr.findIndex(
    (c) => c.id === idOrName || c.name === idOrName || c.fileName === idOrName
  );

  if (idx < 0) {
    console.log(chalk.red(`  ${type} not found: ${idOrName}`));
    process.exit(1);
  }

  const removed = arr.splice(idx, 1)[0];

  // Remove from patterns that use this component
  config.patterns = config.patterns.map((p) => {
    const slotKey = type === 'persona' ? 'persona'
      : type === 'thinking' ? 'thinking'
      : 'dialogue';
    if (p.slots[slotKey] === removed.id) {
      return { ...p, slots: { ...p.slots, [slotKey]: null } };
    }
    return p;
  });

  saveConfig(config);
  console.log(chalk.green(`  Removed ${type}: ${chalk.bold(removed.fileName)}\n`));
}
