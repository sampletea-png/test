import chalk from 'chalk';
import { loadConfig, saveConfig } from '../core/config';
import type { ComponentType } from '../types';

export function clearSlotCommand(patternName: string, slotType: ComponentType): void {
  const config = loadConfig();

  const patternId = patternName.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(
    (p) => p.id === patternId || p.name === patternName || p.label === patternName
  );

  if (!pattern) {
    console.log(chalk.red(`  Pattern "${patternName}" not found.`));
    process.exit(1);
  }

  const slotKey = slotType === 'persona' ? 'persona'
    : slotType === 'thinking' ? 'thinking'
    : 'dialogue';

  pattern.slots[slotKey] = null;
  saveConfig(config);

  console.log(chalk.yellow(`  Cleared ${slotType} from ${pattern.label}\n`));
}
