import chalk from 'chalk';
import { loadConfig, resolvePattern, getComponent, exportPatternConfig } from '../core/config';
import * as fs from 'fs';
import * as path from 'path';

export function showCommand(name: string, options: { export?: string }): void {
  const config = loadConfig();

  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(
    (p) => p.id === id || p.name === name || p.label === name
  );

  if (!pattern) {
    console.log(chalk.red(`  Pattern "${name}" not found.`));
    process.exit(1);
  }

  const resolved = resolvePattern(config, pattern);

  if (options.export) {
    const output = exportPatternConfig(config, pattern);
    const outPath = path.resolve(options.export);
    fs.writeFileSync(outPath, output, 'utf-8');
    console.log(chalk.green(`  Exported to: ${outPath}\n`));
    return;
  }

  // Display in terminal
  console.log(chalk.bold('\n  ============================================\n'));

  if (pattern.inheritsFrom) {
    const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
    console.log(chalk.cyan(`  ${pattern.label} ${chalk.yellow(`(inherits from ${parent?.label || pattern.inheritsFrom})`)}\n`));
  } else {
    console.log(chalk.cyan(`  ${pattern.label}\n`));
  }

  if (resolved.slots.persona) {
    const c = getComponent(config, resolved.slots.persona, 'persona');
    console.log(chalk.blueBright('  [PERSONA]'));
    console.log(chalk.white(`  ${c?.name || resolved.slots.persona}`));
    if (c?.description) console.log(chalk.gray(`  ${c.description}`));
    console.log();
  }

  if (resolved.slots.thinking) {
    const c = getComponent(config, resolved.slots.thinking, 'thinking');
    console.log(chalk.magentaBright('  [THINKING MODEL]'));
    console.log(chalk.white(`  ${c?.name || resolved.slots.thinking}`));
    if (c?.description) console.log(chalk.gray(`  ${c.description}`));
    console.log();
  }

  if (resolved.slots.dialogue) {
    const c = getComponent(config, resolved.slots.dialogue, 'dialogue');
    console.log(chalk.greenBright('  [DIALOGUE PATTERN]'));
    console.log(chalk.white(`  ${c?.name || resolved.slots.dialogue}`));
    if (c?.description) console.log(chalk.gray(`  ${c.description}`));
    console.log();
  }

  console.log(chalk.bold('  ============================================\n'));

  // Show merged content preview
  console.log(chalk.gray('  Preview (first 10 lines of merged config):\n'));
  const preview = exportPatternConfig(config, pattern).split('\n').slice(0, 10).join('\n');
  console.log(chalk.gray(preview));
  console.log(chalk.gray('  ...\n'));
}
