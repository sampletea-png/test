import chalk from 'chalk';
import { loadConfig, resolvePattern } from '../core/config';
import type { Config } from '../types';

export function listCommand(type?: string): void {
  const config = loadConfig();

  if (!type || type === 'all') {
    listAll(config);
  } else if (type === 'personas') {
    listComponents(config.personas, 'Personas', chalk.blueBright);
  } else if (type === 'thinking') {
    listComponents(config.thinkingModels, 'Thinking Models', chalk.magentaBright);
  } else if (type === 'dialogue') {
    listComponents(config.dialoguePatterns, 'Dialogue Patterns', chalk.greenBright);
  } else if (type === 'patterns') {
    listPatterns(config);
  } else {
    console.log(chalk.red(`Unknown type: ${type}`));
    console.log(chalk.gray('Available: personas, thinking, dialogue, patterns, all'));
  }
}

function listAll(config: Config): void {
  console.log(chalk.bold('\n  === Pattern Orchestrator ===\n'));

  listComponents(config.personas, 'Personas', chalk.blueBright);
  listComponents(config.thinkingModels, 'Thinking Models', chalk.magentaBright);
  listComponents(config.dialoguePatterns, 'Dialogue Patterns', chalk.greenBright);
  listPatterns(config);
}

function listComponents<T extends { id: string; name: string; fileName: string; description: string }>(
  items: T[],
  title: string,
  color: (s: string) => string
): void {
  console.log(color(`  [${title}]`));
  if (items.length === 0) {
    console.log(chalk.gray('    (none)\n'));
    return;
  }
  for (const item of items) {
    console.log(`    ${chalk.white.bold(item.fileName)}`);
    console.log(chalk.gray(`      ${item.description || '(no description)'}\n`));
  }
}

function listPatterns(config: Config): void {
  console.log(chalk.cyanBright('  [Patterns]'));
  if (config.patterns.length === 0) {
    console.log(chalk.gray('    (none)\n'));
    return;
  }

  for (const pattern of config.patterns) {
    const resolved = resolvePattern(config, pattern);
    const inherits = pattern.inheritsFrom
      ? chalk.yellow(` <- [${pattern.inheritsFrom}]`)
      : '';

    console.log(`    ${chalk.white.bold(pattern.label)}${inherits}`);

    const slots = [];
    if (resolved.slots.persona) {
      const c = config.personas.find((p) => p.id === resolved.slots.persona);
      slots.push(chalk.blue(`persona:${c?.name || resolved.slots.persona}`));
    }
    if (resolved.slots.thinking) {
      const c = config.thinkingModels.find((t) => t.id === resolved.slots.thinking);
      slots.push(chalk.magenta(`thinking:${c?.name || resolved.slots.thinking}`));
    }
    if (resolved.slots.dialogue) {
      const c = config.dialoguePatterns.find((d) => d.id === resolved.slots.dialogue);
      slots.push(chalk.green(`dialogue:${c?.name || resolved.slots.dialogue}`));
    }

    if (slots.length > 0) {
      console.log(`      ${slots.join(' | ')}\n`);
    } else {
      console.log(chalk.gray('      (empty slots)\n'));
    }
  }
}
