import chalk from 'chalk';
import { loadConfig, saveConfig } from '../core/config';

export function deletePatternCommand(name: string): void {
  const config = loadConfig();

  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const idx = config.patterns.findIndex(
    (p) => p.id === id || p.name === name || p.label === name
  );

  if (idx < 0) {
    console.log(chalk.red(`  Pattern "${name}" not found.`));
    process.exit(1);
  }

  const removed = config.patterns.splice(idx, 1)[0];

  // Update patterns that inherit from this one
  config.patterns = config.patterns.map((p) => {
    if (p.inheritsFrom === removed.id) {
      return { ...p, inheritsFrom: null };
    }
    return p;
  });

  saveConfig(config);
  console.log(chalk.green(`  Deleted pattern: ${chalk.bold(removed.label)}\n`));
}
