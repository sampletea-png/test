export type ComponentType = 'persona' | 'thinking' | 'dialogue';

export interface BaseComponent {
  id: string;
  name: string;
  fileName: string;
  description: string;
  content: string;
  type: ComponentType;
}

export interface Pattern {
  id: string;
  name: string;
  label: string;
  inheritsFrom: string | null;
  slots: {
    persona: string | null;   // component id
    thinking: string | null;
    dialogue: string | null;
  };
}

export interface Config {
  version: string;
  personas: BaseComponent[];
  thinkingModels: BaseComponent[];
  dialoguePatterns: BaseComponent[];
  patterns: Pattern[];
}
