#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import { listCommand } from './commands/list';
import { addCommand } from './commands/add';
import { removeCommand } from './commands/remove';
import { createPatternCommand } from './commands/create-pattern';
import { deletePatternCommand } from './commands/delete-pattern';
import { showCommand } from './commands/show';
import { useCommand } from './commands/use';
import { setSlotCommand } from './commands/set-slot';
import { clearSlotCommand } from './commands/clear-slot';

const program = new Command();

program
  .name('opencode-patterns')
  .description('Pattern Orchestrator - Manage personas, thinking models, and dialogue patterns')
  .version('1.0.0');

// list command
program
  .command('list [type]')
  .description('List all components and patterns. Types: personas, thinking, dialogue, patterns, all')
  .action(listCommand);

// add commands
program
  .command('add-persona <file>')
  .description('Add a persona from a .md file')
  .action((file: string) => addCommand('persona', file));

program
  .command('add-thinking <file>')
  .description('Add a thinking model from a .md file')
  .action((file: string) => addCommand('thinking', file));

program
  .command('add-dialogue <file>')
  .description('Add a dialogue pattern from a .md file')
  .action((file: string) => addCommand('dialogue', file));

// remove commands
program
  .command('remove-persona <name>')
  .description('Remove a persona by id, name, or filename')
  .action((name: string) => removeCommand('persona', name));

program
  .command('remove-thinking <name>')
  .description('Remove a thinking model by id, name, or filename')
  .action((name: string) => removeCommand('thinking', name));

program
  .command('remove-dialogue <name>')
  .description('Remove a dialogue pattern by id, name, or filename')
  .action((name: string) => removeCommand('dialogue', name));

// create-pattern command
program
  .command('create-pattern <name>')
  .description('Create a new pattern. Use --inherit to base on existing pattern')
  .option('-i, --inherit <pattern>', 'Inherit from an existing pattern')
  .option('-p, --persona <persona>', 'Set persona')
  .option('-t, --thinking <thinking>', 'Set thinking model')
  .option('-d, --dialogue <dialogue>', 'Set dialogue pattern')
  .action(createPatternCommand);

// delete-pattern command
program
  .command('delete-pattern <name>')
  .description('Delete a pattern')
  .action(deletePatternCommand);

// show command
program
  .command('show <pattern>')
  .description('Show pattern details with merged slots')
  .option('-e, --export <file>', 'Export merged config to file')
  .action(showCommand);

// use command
program
  .command('use <pattern>')
  .description('Output merged pattern config (for piping to opencode)')
  .action(useCommand);

// set-slot commands
program
  .command('set-persona <pattern> <persona>')
  .description('Set persona for a pattern')
  .action((pattern: string, persona: string) => setSlotCommand(pattern, 'persona', persona));

program
  .command('set-thinking <pattern> <thinking>')
  .description('Set thinking model for a pattern')
  .action((pattern: string, thinking: string) => setSlotCommand(pattern, 'thinking', thinking));

program
  .command('set-dialogue <pattern> <dialogue>')
  .description('Set dialogue pattern for a pattern')
  .action((pattern: string, dialogue: string) => setSlotCommand(pattern, 'dialogue', dialogue));

// clear-slot commands
program
  .command('clear-persona <pattern>')
  .description('Clear persona from a pattern')
  .action((pattern: string) => clearSlotCommand(pattern, 'persona'));

program
  .command('clear-thinking <pattern>')
  .description('Clear thinking model from a pattern')
  .action((pattern: string) => clearSlotCommand(pattern, 'thinking'));

program
  .command('clear-dialogue <pattern>')
  .description('Clear dialogue pattern from a pattern')
  .action((pattern: string) => clearSlotCommand(pattern, 'dialogue'));

// help
program.on('--help', () => {
  console.log('');
  console.log(chalk.cyan('  Examples:'));
  console.log('');
  console.log(chalk.gray('    $ opencode-patterns add-persona ./java_engineer.md'));
  console.log(chalk.gray('    $ opencode-patterns add-thinking ./OODA_loop.md'));
  console.log(chalk.gray('    $ opencode-patterns add-dialogue ./socratic.md'));
  console.log(chalk.gray('    $ opencode-patterns create-pattern Plan --persona java_engineer --thinking OODA_loop --dialogue socratic'));
  console.log(chalk.gray('    $ opencode-patterns create-pattern NewPlan --inherit Plan --persona python_expert'));
  console.log(chalk.gray('    $ opencode-patterns show Plan'));
  console.log(chalk.gray('    $ opencode-patterns use Plan | opencode'));
  console.log('');
});

program.parse();
