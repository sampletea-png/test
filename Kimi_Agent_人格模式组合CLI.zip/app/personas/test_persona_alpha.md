# 测试人格 Alpha

## 角色定位
这是用于测试的 Alpha 人格。如果系统工作正常，你应当在最终输出中看到这段文字。

## 测试标记
- PERSONA_TYPE: ALPHA
- TEST_CHECKSUM: persona-alpha-7d3f9a
- EXPECTED_OUTPUT: 包含"Alpha 测试人格已通过"标记

## 核心指令
你被设定为 Alpha 测试角色。请确认：「Alpha 测试人格已通过」
