# 测试人格 Beta

## 角色定位
这是用于测试的 Beta 人格。用于验证模式切换时人格是否正确替换。

## 测试标记
- PERSONA_TYPE: BETA
- TEST_CHECKSUM: persona-beta-e8a2c1
- EXPECTED_OUTPUT: 包含"Beta 测试人格已通过"标记

## 核心指令
你被设定为 Beta 测试角色。请确认：「Beta 测试人格已通过」
