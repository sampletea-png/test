#!/bin/bash

# 模式编排器 - 完整演示脚本
# 展示从0开始创建组件、组合模式、继承扩展的完整流程

set -e

echo ""
echo "========================================"
echo "  模式编排器 - 完整工作流演示"
echo "========================================"
echo ""

CLI="node bin/opencode-patterns"

# 1. 清理环境
echo ">> 1. 清理环境..."
rm -rf ~/.opencode-patterns
echo "   Done"
echo ""

# 2. 添加组件
echo ">> 2. 添加基础组件..."
$CLI add-persona ./personas/java_engineer.md
$CLI add-persona ./personas/python_expert.md
$CLI add-thinking ./thinking-models/OODA_loop.md
$CLI add-thinking ./thinking-models/first_principles.md
$CLI add-dialogue ./dialogue-patterns/socratic.md
$CLI add-dialogue ./dialogue-patterns/direct_answer.md
echo ""

# 3. 查看所有组件
echo ">> 3. 查看所有组件..."
$CLI list
echo ""

# 4. 创建 [Plan] 模式
echo ">> 4. 创建 [Plan] 模式..."
$CLI create-pattern Plan --persona java_engineer --thinking OODA_loop --dialogue socratic
echo ""

# 5. 创建 [Build] 模式（继承 Plan，替换人格和对话模式）
echo ">> 5. 创建 [Build] 模式（继承 Plan，替换人格和对话模式）..."
$CLI create-pattern Build --inherit Plan --persona python_expert --dialogue direct_answer
echo ""

# 6. 查看模式列表
echo ">> 6. 查看模式列表..."
$CLI list patterns
echo ""

# 7. 查看 [Build] 模式详情
echo ">> 7. 查看 [Build] 模式详情（含继承解析）..."
$CLI show Build
echo ""

# 8. 修改模式槽位
echo ">> 8. 修改 [Build] 的思维模型..."
$CLI set-thinking Build first_principles
echo ""

# 9. 再次查看
echo ">> 9. 查看修改后的 [Build]..."
$CLI show Build
echo ""

# 10. 导出模式配置
echo ">> 10. 导出 [Plan] 配置到文件..."
$CLI show Plan --export ./patterns/plan-config.md
echo "   已导出到: ./patterns/plan-config.md"
echo ""

# 11. 模拟 use 命令（输出到 stdout）
echo ">> 11. 模拟 use 命令输出（前15行）..."
$CLI use Plan | head -15
echo "   ..."
echo ""

# 12. 删除模式
echo ">> 12. 删除 [Build] 模式..."
$CLI delete-pattern Build
echo ""

# 13. 最终状态
echo ">> 13. 最终状态..."
$CLI list
echo ""

echo "========================================"
echo "  演示完成！"
echo "========================================"
echo ""
