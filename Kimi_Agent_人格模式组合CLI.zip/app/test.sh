#!/bin/bash
# 模式编排器 - 功能测试脚本
# 验证：添加组件、创建模式、继承模式、use 命令输出

set -e

CLI="node bin/opencode-patterns"
TEST_CONFIG="/tmp/opencode-patterns-test-config"

echo "========================================"
echo "  模式编排器 - 功能测试"
echo "========================================"
echo ""

# 使用独立测试配置目录
export HOME=/tmp/test-home-$$
mkdir -p $HOME

# --- 测试1: 添加测试组件 ---
echo ">> 测试1: 添加测试组件..."
$CLI add-persona ./test-personas/test_persona_alpha.md >/dev/null
$CLI add-persona ./test-personas/test_persona_beta.md >/dev/null
$CLI add-thinking ./test-thinking/test_thinking_gamma.md >/dev/null
$CLI add-thinking ./test-thinking/test_thinking_delta.md >/dev/null
$CLI add-dialogue ./test-dialogue/test_dialogue_epsilon.md >/dev/null
$CLI add-dialogue ./test-dialogue/test_dialogue_zeta.md >/dev/null
echo "   [PASS] 6个测试组件添加成功"
echo ""

# --- 测试2: 列出组件 ---
echo ">> 测试2: 验证组件列表..."
LIST_OUTPUT=$($CLI list personas 2>&1)
if echo "$LIST_OUTPUT" | grep -q "test_persona_alpha"; then
  echo "   [PASS] Alpha 人格在列表中"
else
  echo "   [FAIL] Alpha 人格不在列表中"
  exit 1
fi

LIST_OUTPUT=$($CLI list thinking 2>&1)
if echo "$LIST_OUTPUT" | grep -q "test_thinking_delta"; then
  echo "   [PASS] Delta 思维模型在列表中"
else
  echo "   [FAIL] Delta 思维模型不在列表中"
  exit 1
fi
echo ""

# --- 测试3: 创建基础模式 ---
echo ">> 测试3: 创建基础模式 [TestBase]..."
$CLI create-pattern TestBase \
  --persona test_persona_alpha \
  --thinking test_thinking_gamma \
  --dialogue test_dialogue_epsilon >/dev/null
echo "   [PASS] 基础模式创建成功"
echo ""

# --- 测试4: 验证 use 命令输出包含正确内容 ---
echo ">> 测试4: 验证 use 命令输出..."
USE_OUTPUT=$($CLI use TestBase 2>&1)

CHECKS=0
if echo "$USE_OUTPUT" | grep -q "Alpha 测试人格已通过"; then
  echo "   [PASS] 人格内容正确包含"
  CHECKS=$((CHECKS+1))
else
  echo "   [FAIL] 人格内容缺失"
fi

if echo "$USE_OUTPUT" | grep -q "Gamma 测试思维模型已通过"; then
  echo "   [PASS] 思维模型内容正确包含"
  CHECKS=$((CHECKS+1))
else
  echo "   [FAIL] 思维模型内容缺失"
fi

if echo "$USE_OUTPUT" | grep -q "Epsilon 测试对话模式已通过"; then
  echo "   [PASS] 对话模式内容正确包含"
  CHECKS=$((CHECKS+1))
else
  echo "   [FAIL] 对话模式内容缺失"
fi
echo ""

# --- 测试5: 创建继承模式 ---
echo ">> 测试5: 创建继承模式 [TestInherit]..."
$CLI create-pattern TestInherit \
  --inherit TestBase \
  --persona test_persona_beta \
  --dialogue test_dialogue_zeta >/dev/null
echo "   [PASS] 继承模式创建成功"
echo ""

# --- 测试6: 验证继承模式输出 ---
echo ">> 测试6: 验证继承模式 use 输出..."
INHERIT_OUTPUT=$($CLI use TestInherit 2>&1)

if echo "$INHERIT_OUTPUT" | grep -q "Beta 测试人格已通过"; then
  echo "   [PASS] 继承模式人格已替换为 Beta"
else
  echo "   [FAIL] 继承模式人格替换失败"
  exit 1
fi

if echo "$INHERIT_OUTPUT" | grep -q "Gamma 测试思维模型已通过"; then
  echo "   [PASS] 继承模式思维模型保留 Gamma"
else
  echo "   [FAIL] 继承模式思维模型未正确保留"
  exit 1
fi

if echo "$INHERIT_OUTPUT" | grep -q "Zeta 测试对话模式已通过"; then
  echo "   [PASS] 继承模式对话模式已替换为 Zeta"
else
  echo "   [FAIL] 继承模式对话模式替换失败"
  exit 1
fi

# 验证不应包含被替换的内容
if echo "$INHERIT_OUTPUT" | grep -q "Alpha 测试人格已通过"; then
  echo "   [FAIL] 继承模式不应包含 Alpha 人格"
  exit 1
else
  echo "   [PASS] 继承模式正确排除了 Alpha 人格"
fi
echo ""

# --- 测试7: 验证 show 命令 ---
echo ">> 测试7: 验证 show 命令输出..."
SHOW_OUTPUT=$($CLI show TestInherit 2>&1)
if echo "$SHOW_OUTPUT" | grep -q "inherits from"; then
  echo "   [PASS] show 命令显示继承关系"
else
  echo "   [FAIL] show 命令未显示继承关系"
  exit 1
fi
echo ""

# --- 测试8: 验证导出功能 ---
echo ">> 测试8: 验证导出功能..."
EXPORT_FILE="/tmp/test-export-$$.md"
$CLI show TestBase --export "$EXPORT_FILE" >/dev/null
if grep -q "Alpha 测试人格已通过" "$EXPORT_FILE"; then
  echo "   [PASS] 导出文件内容正确"
else
  echo "   [FAIL] 导出文件内容不正确"
  exit 1
fi
rm -f "$EXPORT_FILE"
echo ""

# --- 测试9: 修改槽位 ---
echo ">> 测试9: 验证 set-slot 功能..."
$CLI set-thinking TestBase test_thinking_delta >/dev/null
SET_OUTPUT=$($CLI use TestBase 2>&1)
if echo "$SET_OUTPUT" | grep -q "Delta 测试思维模型已通过"; then
  echo "   [PASS] set-thinking 成功修改槽位"
else
  echo "   [FAIL] set-thinking 修改失败"
  exit 1
fi
echo ""

# --- 测试10: 删除模式 ---
echo ">> 测试10: 验证 delete-pattern 功能..."
PATTERN_COUNT_BEFORE=$($CLI list patterns 2>&1 | grep -c "\[Test" || true)
$CLI delete-pattern TestInherit >/dev/null
PATTERN_COUNT_AFTER=$($CLI list patterns 2>&1 | grep -c "\[Test" || true)
if [ "$PATTERN_COUNT_AFTER" -lt "$PATTERN_COUNT_BEFORE" ]; then
  echo "   [PASS] 模式删除成功"
else
  echo "   [FAIL] 模式删除失败"
  exit 1
fi
echo ""

# --- 测试11: 生产级文件加载 ---
echo ">> 测试11: 验证生产级文件加载..."
rm -rf $HOME/.opencode-patterns

$CLI add-persona ./personas/java_engineer.md >/dev/null
$CLI add-thinking ./thinking-models/OODA_loop.md >/dev/null
$CLI add-dialogue ./dialogue-patterns/socratic_dialogue.md >/dev/null
$CLI create-pattern ProdTest --persona java_engineer --thinking OODA_loop --dialogue socratic >/dev/null

PROD_OUTPUT=$($CLI use ProdTest 2>&1)
WORD_COUNT=$(echo "$PROD_OUTPUT" | wc -w)
if [ "$WORD_COUNT" -gt 500 ]; then
  echo "   [PASS] 生产级文件正确加载（$WORD_COUNT 词）"
else
  echo "   [FAIL] 生产级文件内容不足（仅 $WORD_COUNT 词）"
  exit 1
fi
echo ""

# 清理
rm -rf $HOME

echo "========================================"
echo "  全部 11 项测试通过！"
echo "========================================"
