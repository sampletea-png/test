export type ComponentType = 'persona' | 'thinking' | 'dialogue';

export interface BaseComponent {
  id: string;
  name: string;
  fileName: string;
  description: string;
  content: string;
  type: ComponentType;
}

export interface Pattern {
  id: string;
  name: string;
  label: string;
  inheritsFrom: string | null;
  slots: {
    persona: BaseComponent | null;
    thinking: BaseComponent | null;
    dialogue: BaseComponent | null;
  };
  isModified: boolean;
}

export const COMPONENT_TYPE_CONFIG: Record<ComponentType, { label: string; color: string; glowColor: string }> = {
  persona: { label: '人格', color: '#3B82F6', glowColor: 'rgba(59, 130, 246, 0.15)' },
  thinking: { label: '思维模型', color: '#8B5CF6', glowColor: 'rgba(139, 92, 246, 0.15)' },
  dialogue: { label: '对话模式', color: '#10B981', glowColor: 'rgba(16, 185, 129, 0.15)' },
};

export const SLOT_TYPE_MAP: Record<string, ComponentType> = {
  persona: 'persona',
  thinking: 'thinking',
  dialogue: 'dialogue',
};
