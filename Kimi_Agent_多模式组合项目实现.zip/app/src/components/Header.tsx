import { useAppStore } from '@/store/useAppStore';
import { Logo } from './Logo';
import { Plus, Trash2 } from 'lucide-react';

export function Header() {
  const openCreateModal = useAppStore((s) => s.openCreateModal);
  const removingPatternId = useAppStore((s) => s.removingPatternId);
  const startRemovePattern = useAppStore((s) => s.startRemovePattern);
  const confirmRemovePattern = useAppStore((s) => s.confirmRemovePattern);
  const patterns = useAppStore((s) => s.patterns);
  const activePatternId = useAppStore((s) => s.activePatternId);

  const isRemoving = removingPatternId !== null;

  const handleRemoveClick = () => {
    if (isRemoving) {
      confirmRemovePattern();
    } else {
      if (activePatternId) {
        startRemovePattern(activePatternId);
      }
    }
  };

  const handleCancelRemove = () => {
    startRemovePattern(null);
  };

  return (
    <header
      style={{
        height: 64,
        backgroundColor: 'var(--bg-panel)',
        borderBottom: '1px solid var(--border-primary)',
      }}
      className="flex items-center justify-between px-6 flex-shrink-0"
    >
      <div className="flex items-center gap-3">
        <Logo />
        <h1
          style={{
            fontSize: 20,
            fontWeight: 700,
            letterSpacing: '-0.5px',
            color: 'var(--text-primary)',
          }}
        >
          模式编排器
        </h1>
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.5px',
            color: 'var(--text-secondary)',
            backgroundColor: 'var(--bg-card)',
            padding: '2px 8px',
            borderRadius: 4,
            marginLeft: 8,
          }}
        >
          {patterns.length} 模式
        </span>
      </div>

      <div className="flex items-center gap-3">
        {isRemoving && (
          <button
            onClick={handleCancelRemove}
            style={{
              height: 36,
              padding: '0 16px',
              borderRadius: 6,
              border: '1px solid var(--border-primary)',
              backgroundColor: 'var(--bg-card)',
              color: 'var(--text-secondary)',
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 150ms ease',
            }}
            className="hover:opacity-80"
          >
            取消
          </button>
        )}
        <button
          onClick={handleRemoveClick}
          disabled={patterns.length === 0}
          style={{
            height: 36,
            padding: '0 16px',
            borderRadius: 6,
            border: '1px solid var(--border-primary)',
            backgroundColor: isRemoving ? 'rgba(239, 68, 68, 0.15)' : 'var(--bg-card)',
            color: isRemoving ? '#EF4444' : 'var(--text-primary)',
            fontSize: 13,
            fontWeight: 500,
            cursor: patterns.length === 0 ? 'not-allowed' : 'pointer',
            opacity: patterns.length === 0 ? 0.5 : 1,
            transition: 'all 150ms ease',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}
          className="hover:opacity-90 active:scale-[0.98]"
        >
          <Trash2 size={14} />
          {isRemoving ? '确认移除' : '移除模式'}
        </button>
        <button
          onClick={openCreateModal}
          style={{
            height: 36,
            padding: '0 16px',
            borderRadius: 6,
            border: 'none',
            backgroundColor: 'var(--accent-blue)',
            color: '#fff',
            fontSize: 13,
            fontWeight: 500,
            cursor: 'pointer',
            boxShadow: '0 0 12px rgba(59,130,246,0.3)',
            transition: 'all 150ms ease',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}
          className="hover:brightness-110 active:scale-[0.98]"
        >
          <Plus size={14} />
          新增模式
        </button>
      </div>
    </header>
  );
}
