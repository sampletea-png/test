export function Logo({ className = '' }: { className?: string }) {
  return (
    <svg
      width="28"
      height="28"
      viewBox="0 0 28 28"
      fill="none"
      className={className}
    >
      <path
        d="M14 2L25.5 8.5V19.5L14 26L2.5 19.5V8.5L14 2Z"
        stroke="url(#logoGradient)"
        strokeWidth="1.5"
        fill="none"
      />
      <path
        d="M14 8L20 11.5V18.5L14 22L8 18.5V11.5L14 8Z"
        stroke="url(#logoGradient)"
        strokeWidth="1"
        fill="none"
        opacity="0.6"
      />
      <circle cx="14" cy="15" r="2" fill="url(#logoGradient)" opacity="0.8" />
      <defs>
        <linearGradient id="logoGradient" x1="2.5" y1="2" x2="25.5" y2="26">
          <stop stopColor="#3B82F6" />
          <stop offset="1" stopColor="#60A5FA" />
        </linearGradient>
      </defs>
    </svg>
  );
}
