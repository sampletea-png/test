import { useAppStore } from '@/store/useAppStore';
import type { Pattern } from '@/types';

export function PatternSelector() {
  const patterns = useAppStore((s) => s.patterns);
  const activePatternId = useAppStore((s) => s.activePatternId);
  const setActivePattern = useAppStore((s) => s.setActivePattern);
  const removingPatternId = useAppStore((s) => s.removingPatternId);

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '8px 16px',
        borderBottom: '1px solid var(--border-primary)',
        overflowX: 'auto',
      }}
    >
      <span
        style={{
          fontSize: 10,
          fontWeight: 600,
          color: 'var(--text-secondary)',
          letterSpacing: '0.5px',
          whiteSpace: 'nowrap',
          marginRight: 4,
        }}
      >
        模式
      </span>
      {patterns.map((pattern: Pattern) => {
        const isActive = pattern.id === activePatternId;
        const isRemoving = pattern.id === removingPatternId;

        return (
          <button
            key={pattern.id}
            onClick={() => setActivePattern(pattern.id)}
            style={{
              padding: '6px 14px',
              borderRadius: 6,
              border: isActive
                ? '1px solid var(--accent-blue)'
                : '1px solid var(--border-primary)',
              backgroundColor: isActive
                ? 'rgba(59, 130, 246, 0.1)'
                : isRemoving
                ? 'rgba(239, 68, 68, 0.1)'
                : 'var(--bg-card)',
              color: isActive
                ? 'var(--accent-blue)'
                : isRemoving
                ? '#EF4444'
                : 'var(--text-secondary)',
              fontSize: 12,
              fontWeight: isActive ? 600 : 500,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              transition: 'all 150ms ease',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
            className="hover:border-[var(--border-accent)]"
          >
            {pattern.label}
            {pattern.isModified && (
              <span
                style={{
                  width: 5,
                  height: 5,
                  borderRadius: '50%',
                  backgroundColor: 'var(--accent-blue)',
                }}
              />
            )}
            {pattern.inheritsFrom && (
              <span
                style={{
                  fontSize: 9,
                  opacity: 0.5,
                  fontWeight: 400,
                }}
              >
                ←
                {patterns.find((p) => p.id === pattern.inheritsFrom)?.label || pattern.inheritsFrom}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
