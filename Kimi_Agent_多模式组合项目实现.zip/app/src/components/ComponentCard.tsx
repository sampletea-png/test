import { COMPONENT_TYPE_CONFIG } from '@/types';
import type { BaseComponent, ComponentType } from '@/types';
import { Pencil, X } from 'lucide-react';
import { useAppStore } from '@/store/useAppStore';

interface ComponentCardProps {
  component: BaseComponent;
  variant?: 'sidebar' | 'slot';
  onRemove?: () => void;
}

export function ComponentCard({ component, variant = 'sidebar', onRemove }: ComponentCardProps) {
  const openEditor = useAppStore((s) => s.openEditor);
  const assignComponentToSlot = useAppStore((s) => s.assignComponentToSlot);
  const config = COMPONENT_TYPE_CONFIG[component.type as ComponentType];

  const handleClick = () => {
    if (variant === 'sidebar') {
      assignComponentToSlot(component.id, component.type as ComponentType);
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    openEditor(component);
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    onRemove?.();
  };

  return (
    <div
      onClick={handleClick}
      style={{
        width: '100%',
        padding: 12,
        borderRadius: 6,
        backgroundColor: variant === 'slot' ? 'transparent' : 'var(--bg-card)',
        border: variant === 'slot' ? 'none' : '1px solid transparent',
        cursor: variant === 'sidebar' ? 'pointer' : 'default',
        display: 'flex',
        alignItems: 'flex-start',
        gap: 10,
        position: 'relative',
        transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
      }}
      className="group hover:border-[#444]"
      onMouseEnter={(e) => {
        if (variant === 'sidebar') {
          e.currentTarget.style.backgroundColor = 'var(--bg-card-hover)';
          e.currentTarget.style.borderColor = 'var(--border-accent)';
        }
      }}
      onMouseLeave={(e) => {
        if (variant === 'sidebar') {
          e.currentTarget.style.backgroundColor = 'var(--bg-card)';
          e.currentTarget.style.borderColor = 'transparent';
        }
      }}
    >
      {/* Color indicator bar */}
      <div
        style={{
          width: 4,
          minHeight: 36,
          borderRadius: 2,
          backgroundColor: config.color,
          flexShrink: 0,
          marginTop: 2,
        }}
      />

      {/* Content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: 13,
            fontWeight: 500,
            color: 'var(--text-primary)',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {component.fileName}
        </div>
        <div
          style={{
            fontSize: 11,
            color: 'var(--text-secondary)',
            marginTop: 2,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            lineHeight: '1.4',
          }}
        >
          {component.description}
        </div>
      </div>

      {/* Actions */}
      <div
        style={{
          display: 'flex',
          gap: 4,
          opacity: variant === 'slot' ? 1 : 0,
          transition: 'opacity 150ms ease',
        }}
        className={variant === 'sidebar' ? 'group-hover:opacity-100' : ''}
      >
        <button
          onClick={handleEdit}
          style={{
            width: 24,
            height: 24,
            borderRadius: 4,
            border: 'none',
            backgroundColor: 'transparent',
            color: 'var(--text-secondary)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 150ms ease',
          }}
          className="hover:bg-[#333] hover:text-white"
        >
          <Pencil size={12} />
        </button>
        {variant === 'slot' && onRemove && (
          <button
            onClick={handleRemove}
            style={{
              width: 24,
              height: 24,
              borderRadius: 4,
              border: 'none',
              backgroundColor: 'transparent',
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 150ms ease',
            }}
            className="hover:bg-red-900/30 hover:text-red-400"
          >
            <X size={12} />
          </button>
        )}
      </div>
    </div>
  );
}
