import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import type { Pattern } from '@/types';
import { X, GitBranch } from 'lucide-react';

export function CreatePatternModal() {
  const isOpen = useAppStore((s) => s.isCreateModalOpen);
  const closeCreateModal = useAppStore((s) => s.closeCreateModal);
  const createPattern = useAppStore((s) => s.createPattern);
  const patterns = useAppStore((s) => s.patterns);

  const [name, setName] = useState('');
  const [inheritsFrom, setInheritsFrom] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    createPattern(
      name.trim(),
      inheritsFrom || null
    );
    setName('');
    setInheritsFrom('');
  };

  const handleClose = () => {
    closeCreateModal();
    setName('');
    setInheritsFrom('');
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 200,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Backdrop */}
      <div
        onClick={handleClose}
        style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.6)',
          backdropFilter: 'blur(4px)',
          animation: 'fadeIn 0.2s ease-out',
        }}
      />

      {/* Modal */}
      <div
        style={{
          width: 500,
          maxWidth: 'calc(100vw - 32px)',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-primary)',
          borderRadius: 8,
          position: 'relative',
          zIndex: 1,
          animation: 'scaleIn 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '20px 24px',
            borderBottom: '1px solid var(--border-primary)',
          }}
        >
          <h2
            style={{
              fontSize: 16,
              fontWeight: 600,
              color: 'var(--text-primary)',
            }}
          >
            创建新模式
          </h2>
          <button
            onClick={handleClose}
            style={{
              width: 32,
              height: 32,
              borderRadius: 6,
              border: 'none',
              backgroundColor: 'transparent',
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 150ms ease',
            }}
            className="hover:bg-[#333] hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit}>
          <div
            style={{
              padding: '20px 24px',
              display: 'flex',
              flexDirection: 'column',
              gap: 20,
            }}
          >
            {/* Pattern Name */}
            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: 12,
                  fontWeight: 600,
                  color: 'var(--text-secondary)',
                  marginBottom: 6,
                  letterSpacing: '0.5px',
                }}
              >
                模式名称
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="例如: NewPattern"
                autoFocus
                style={{
                  width: '100%',
                  height: 40,
                  padding: '0 12px',
                  borderRadius: 6,
                  border: '1px solid var(--border-primary)',
                  backgroundColor: 'var(--bg-base)',
                  color: 'var(--text-primary)',
                  fontSize: 13,
                  fontFamily: 'inherit',
                  outline: 'none',
                  transition: 'border-color 200ms ease',
                }}
                className="focus:border-[var(--accent-blue)]"
              />
            </div>

            {/* Inheritance */}
            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: 12,
                  fontWeight: 600,
                  color: 'var(--text-secondary)',
                  marginBottom: 6,
                  letterSpacing: '0.5px',
                }}
              >
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <GitBranch size={12} />
                  继承自
                </span>
              </label>
              <select
                value={inheritsFrom}
                onChange={(e) => setInheritsFrom(e.target.value)}
                style={{
                  width: '100%',
                  height: 40,
                  padding: '0 12px',
                  borderRadius: 6,
                  border: '1px solid var(--border-primary)',
                  backgroundColor: 'var(--bg-base)',
                  color: 'var(--text-primary)',
                  fontSize: 13,
                  fontFamily: 'inherit',
                  outline: 'none',
                  cursor: 'pointer',
                  transition: 'border-color 200ms ease',
                  appearance: 'none',
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239CA3AF' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center',
                  paddingRight: 36,
                }}
                className="focus:border-[var(--accent-blue)]"
              >
                <option value="">无（创建全新模式）</option>
                {patterns.map((p: Pattern) => (
                  <option key={p.id} value={p.id}>
                    {p.label} {p.inheritsFrom ? `(继承自 ${p.inheritsFrom})` : ''}
                  </option>
                ))}
              </select>
              <p
                style={{
                  fontSize: 11,
                  color: 'var(--text-secondary)',
                  marginTop: 6,
                  opacity: 0.7,
                }}
              >
                新模式将自动继承父模式的组件组合，您可在此基础上进行覆写。
              </p>
            </div>
          </div>

          {/* Footer */}
          <div
            style={{
              padding: '12px 24px',
              borderTop: '1px solid var(--border-primary)',
              display: 'flex',
              justifyContent: 'flex-end',
              gap: 8,
            }}
          >
            <button
              type="button"
              onClick={handleClose}
              style={{
                padding: '8px 16px',
                borderRadius: 6,
                border: '1px solid var(--border-primary)',
                backgroundColor: 'var(--bg-card)',
                color: 'var(--text-primary)',
                fontSize: 13,
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 150ms ease',
              }}
              className="hover:bg-[#333]"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={!name.trim()}
              style={{
                padding: '8px 16px',
                borderRadius: 6,
                border: 'none',
                backgroundColor: name.trim() ? 'var(--accent-blue)' : '#333',
                color: name.trim() ? '#fff' : 'var(--text-secondary)',
                fontSize: 13,
                fontWeight: 500,
                cursor: name.trim() ? 'pointer' : 'not-allowed',
                transition: 'all 150ms ease',
                boxShadow: name.trim() ? '0 0 12px rgba(59,130,246,0.3)' : 'none',
              }}
              className={name.trim() ? 'hover:brightness-110 active:scale-[0.98]' : ''}
            >
              创建模式
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
