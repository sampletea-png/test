import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ComponentCard } from './ComponentCard';
import { COMPONENT_TYPE_CONFIG } from '@/types';
import type { ComponentType } from '@/types';
import { Plus } from 'lucide-react';

const SLOT_CONFIG: { type: ComponentType; label: string; subLabel: string }[] = [
  { type: 'persona', label: '人格', subLabel: 'PERSONA' },
  { type: 'thinking', label: '思维模型', subLabel: 'THINKING MODEL' },
  { type: 'dialogue', label: '对话模式', subLabel: 'DIALOGUE PATTERN' },
];

export function SlotArea() {
  const activePattern = useAppStore((s) => s.getActivePattern());
  const clearSlot = useAppStore((s) => s.clearSlot);
  const removingPatternId = useAppStore((s) => s.removingPatternId);
  const patterns = useAppStore((s) => s.patterns);

  const [dragOverSlot, setDragOverSlot] = useState<string | null>(null);
  const [shakingSlot, setShakingSlot] = useState<string | null>(null);

  const isRemoving = removingPatternId !== null;

  if (!activePattern) {
    return (
      <div
        style={{
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--text-secondary)',
          fontSize: 14,
        }}
      >
        请选择一个模式或创建新模式
      </div>
    );
  }

  const handleDragOver = (e: React.DragEvent, slotType: ComponentType) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    setDragOverSlot(slotType);
  };

  const handleDragLeave = () => {
    setDragOverSlot(null);
  };

  const handleDrop = (e: React.DragEvent, slotType: ComponentType) => {
    e.preventDefault();
    setDragOverSlot(null);

    const componentId = e.dataTransfer.getData('componentId');
    const componentType = e.dataTransfer.getData('componentType') as ComponentType;

    if (!componentId) {
      // Handle file drop
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        handleFileDrop(files[0], slotType);
      }
      return;
    }

    if (componentType !== slotType) {
      setShakingSlot(slotType);
      setTimeout(() => setShakingSlot(null), 300);
      return;
    }

    const store = useAppStore.getState();
    store.assignComponentToSlot(componentId, slotType);
  };

  const handleFileDrop = (file: File, slotType: ComponentType) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const id = file.name.replace(/\.md$/, '').toLowerCase().replace(/[^a-z0-9]/g, '-');
      const newComponent = {
        id,
        name: file.name.replace(/\.md$/, ''),
        fileName: file.name,
        description: content.slice(0, 100) + '...',
        type: slotType,
        content,
      };

      const store = useAppStore.getState();
      store.components.push(newComponent);
      store.assignComponentToSlot(id, slotType);
    };
    reader.readAsText(file);
  };

  const handleSlotClick = (slotType: ComponentType) => {
    // Create a hidden file input and trigger it
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.md';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleFileDrop(file, slotType);
      }
    };
    input.click();
  };

  return (
    <div
      style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        padding: 24,
        overflowY: 'auto',
      }}
    >
      {/* Pattern Label Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <div
          style={{
            padding: '6px 14px',
            borderRadius: 4,
            backgroundColor: 'rgba(255,255,255,0.05)',
            color: 'var(--text-primary)',
            fontSize: 14,
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          {activePattern.label}
          {activePattern.isModified && (
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                backgroundColor: 'var(--accent-blue)',
              }}
            />
          )}
        </div>

        {/* Inheritance indicator */}
        {activePattern.inheritsFrom && (
          <>
            <span style={{ color: 'var(--text-secondary)', fontSize: 12 }}>继承自</span>
            <div
              style={{
                padding: '4px 10px',
                borderRadius: 4,
                backgroundColor: 'rgba(255,255,255,0.03)',
                color: 'var(--text-secondary)',
                fontSize: 12,
                fontWeight: 500,
                border: '1px dashed var(--border-primary)',
              }}
            >
              {patterns.find((p) => p.id === activePattern.inheritsFrom)?.label || activePattern.inheritsFrom}
            </div>
          </>
        )}
      </div>

      {/* Slots */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, flex: 1 }}>
        {SLOT_CONFIG.map(({ type, label, subLabel }) => {
          const slotComponent = activePattern.slots[type];
          const config = COMPONENT_TYPE_CONFIG[type];
          const isDragOver = dragOverSlot === type;
          const isShaking = shakingSlot === type;
          const slotFilled = !!slotComponent;

          return (
            <div
              key={type}
              onDragOver={(e) => handleDragOver(e, type)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, type)}
              onClick={() => !slotFilled && handleSlotClick(type)}
              style={{
                minHeight: 120,
                borderRadius: 6,
                border: isDragOver
                  ? `2px solid ${config.color}`
                  : slotFilled
                  ? '1px solid var(--border-primary)'
                  : '2px dashed #333',
                backgroundColor: isDragOver
                  ? config.glowColor
                  : slotFilled
                  ? 'var(--bg-card)'
                  : 'var(--bg-base)',
                padding: slotFilled ? 12 : 0,
                display: 'flex',
                alignItems: slotFilled ? 'flex-start' : 'center',
                justifyContent: slotFilled ? 'flex-start' : 'center',
                cursor: slotFilled ? 'default' : 'pointer',
                transition: 'all 200ms ease',
                position: 'relative',
                boxShadow: isDragOver ? `0 0 16px ${config.glowColor}` : 'none',
              }}
              className={isShaking ? 'animate-shake' : ''}
            >
              {slotFilled && slotComponent ? (
                <div style={{ width: '100%' }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 6,
                      marginBottom: 8,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: 600,
                        letterSpacing: '0.5px',
                        color: config.color,
                        textTransform: 'uppercase',
                      }}
                    >
                      {subLabel}
                    </span>
                    <div
                      style={{
                        height: 1,
                        flex: 1,
                        backgroundColor: 'var(--border-primary)',
                      }}
                    />
                  </div>
                  <ComponentCard
                    component={slotComponent}
                    variant="slot"
                    onRemove={() => clearSlot(type)}
                  />
                </div>
              ) : (
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 8,
                    color: 'var(--text-secondary)',
                    opacity: 0.5,
                    pointerEvents: 'none',
                  }}
                >
                  <Plus size={20} style={{ color: config.color }} />
                  <span style={{ fontSize: 13, fontWeight: 500 }}>
                    + {label} ({subLabel})
                  </span>
                  <span style={{ fontSize: 11, opacity: 0.6 }}>
                    拖拽组件或点击上传 .md 文件
                  </span>
                </div>
              )}

              {/* Remove overlay */}
              {isRemoving && removingPatternId === activePattern.id && (
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    borderRadius: 6,
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    border: '2px dashed #EF4444',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#EF4444',
                    fontSize: 13,
                    fontWeight: 600,
                    animation: 'pulseGlow 2s ease-in-out infinite',
                  }}
                >
                  此模式将被移除
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
