import { useEffect, useRef, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';

export function PreviewConsole() {
  const activeTab = useAppStore((s) => s.activeTab);
  const setActiveTab = useAppStore((s) => s.setActiveTab);
  const activePattern = useAppStore((s) => s.getActivePattern());

  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const generateJson = () => {
    if (!activePattern) return '';
    const output = {
      mode: activePattern.label,
      inheritsFrom: activePattern.inheritsFrom,
      systemPrompt: {
        persona: activePattern.slots.persona
          ? {
              name: activePattern.slots.persona.name,
              file: activePattern.slots.persona.fileName,
              content: activePattern.slots.persona.content.slice(0, 200) + '...',
            }
          : null,
        thinking: activePattern.slots.thinking
          ? {
              name: activePattern.slots.thinking.name,
              file: activePattern.slots.thinking.fileName,
              content: activePattern.slots.thinking.content.slice(0, 200) + '...',
            }
          : null,
        dialogue: activePattern.slots.dialogue
          ? {
              name: activePattern.slots.dialogue.name,
              file: activePattern.slots.dialogue.fileName,
              content: activePattern.slots.dialogue.content.slice(0, 200) + '...',
            }
          : null,
      },
    };
    return JSON.stringify(output, null, 2);
  };

  const generateSystemPrompt = () => {
    if (!activePattern) return '';
    const parts: string[] = [];
    parts.push(`# ${activePattern.label} 模式`);
    if (activePattern.inheritsFrom) {
      parts.push(`\n> 继承自: ${activePattern.inheritsFrom}`);
    }
    if (activePattern.slots.persona) {
      parts.push(`\n## 人格配置`);
      parts.push(activePattern.slots.persona.content.slice(0, 300));
    }
    if (activePattern.slots.thinking) {
      parts.push(`\n## 思维模型`);
      parts.push(activePattern.slots.thinking.content.slice(0, 300));
    }
    if (activePattern.slots.dialogue) {
      parts.push(`\n## 对话模式`);
      parts.push(activePattern.slots.dialogue.content.slice(0, 300));
    }
    return parts.join('\n');
  };

  // Typewriter effect
  useEffect(() => {
    if (activeTab !== 'simulation') return;

    const text = generateSystemPrompt();
    setDisplayedText('');
    setIsTyping(true);

    let index = 0;
    if (intervalRef.current) clearInterval(intervalRef.current);

    intervalRef.current = setInterval(() => {
      if (index < text.length) {
        setDisplayedText(text.slice(0, index + 1));
        index++;
      } else {
        setIsTyping(false);
        if (intervalRef.current) clearInterval(intervalRef.current);
      }
    }, 15);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, activePattern?.id]);

  const json = generateJson();

  return (
    <div
      style={{
        height: 240,
        backgroundColor: 'var(--bg-panel)',
        borderTop: '1px solid var(--border-primary)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Tabs */}
      <div
        style={{
          display: 'flex',
          gap: 0,
          borderBottom: '1px solid var(--border-primary)',
          padding: '0 16px',
        }}
      >
        {(['json', 'simulation'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              padding: '10px 16px',
              background: 'transparent',
              border: 'none',
              borderBottom: activeTab === tab ? '2px solid var(--accent-blue)' : '2px solid transparent',
              color: activeTab === tab ? 'var(--text-primary)' : 'var(--text-secondary)',
              fontSize: 12,
              fontWeight: 600,
              letterSpacing: '0.5px',
              cursor: 'pointer',
              transition: 'all 150ms ease',
            }}
          >
            {tab === 'json' ? 'JSON 预览' : '效果模拟'}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {activeTab === 'json' ? (
          <pre
            style={{
              margin: 0,
              padding: '12px 16px',
              fontSize: 11,
              lineHeight: 1.6,
              overflow: 'auto',
              height: '100%',
              color: 'var(--text-secondary)',
            }}
            className="font-mono-code"
          >
            <code>{json}</code>
          </pre>
        ) : (
          <div
            style={{
              padding: '12px 16px',
              height: '100%',
              overflow: 'auto',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {/* Terminal header */}
            <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
              <span style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#EF4444' }} />
              <span style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#EAB308' }} />
              <span style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#22C55E' }} />
              <span
                style={{
                  marginLeft: 8,
                  fontSize: 10,
                  color: 'var(--text-secondary)',
                  opacity: 0.6,
                }}
                className="font-mono-code"
              >
                system-prompt-preview
              </span>
            </div>

            {/* Terminal content */}
            <div
              style={{
                flex: 1,
                fontSize: 11,
                lineHeight: 1.7,
                color: 'var(--text-secondary)',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
              }}
              className="font-mono-code"
            >
              {displayedText}
              {isTyping && (
                <span className="animate-blink" style={{ color: 'var(--accent-blue)' }}>
                  _
                </span>
              )}
              {!isTyping && displayedText && (
                <span className="animate-blink" style={{ color: 'var(--accent-blue)' }}>
                  _
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
