import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ComponentCard } from './ComponentCard';
import { DraggableWrapper } from './DraggableWrapper';
import { Search, ChevronDown, ChevronRight } from 'lucide-react';
import type { ComponentType } from '@/types';

const SECTIONS: { type: ComponentType; label: string; bracketLabel: string }[] = [
  { type: 'persona', label: '人格', bracketLabel: 'PERSONAS' },
  { type: 'thinking', label: '思维模型', bracketLabel: 'THINKING MODELS' },
  { type: 'dialogue', label: '对话模式', bracketLabel: 'DIALOGUE PATTERNS' },
];

export function Sidebar() {
  const searchQuery = useAppStore((s) => s.searchQuery);
  const setSearchQuery = useAppStore((s) => s.setSearchQuery);
  const getFilteredComponents = useAppStore((s) => s.getFilteredComponents);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});

  const filtered = getFilteredComponents();

  const toggleSection = (type: string) => {
    setCollapsedSections((prev) => ({ ...prev, [type]: !prev[type] }));
  };

  return (
    <aside
      style={{
        width: 280,
        minWidth: 280,
        backgroundColor: 'var(--bg-panel)',
        borderRight: '1px solid var(--border-primary)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Search */}
      <div
        style={{
          padding: 16,
          borderBottom: '1px solid var(--border-primary)',
        }}
      >
        <div
          style={{
            height: 36,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            borderBottom: '1px solid var(--border-primary)',
            padding: '0 4px',
            transition: 'border-color 200ms ease',
          }}
          className="focus-within:border-[var(--accent-blue)]"
        >
          <Search size={14} style={{ color: 'var(--text-secondary)', flexShrink: 0 }} />
          <input
            type="text"
            placeholder="搜索组件..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1,
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: 'var(--text-primary)',
              fontSize: 13,
              fontFamily: 'inherit',
            }}
          />
        </div>
      </div>

      {/* Sections */}
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '8px 12px',
          display: 'flex',
          flexDirection: 'column',
          gap: 4,
        }}
      >
        {SECTIONS.map(({ type, bracketLabel }) => {
          const sectionComponents = filtered.filter((c) => c.type === type);
          const isCollapsed = collapsedSections[type];

          if (searchQuery && sectionComponents.length === 0) return null;

          return (
            <div key={type}>
              <button
                onClick={() => toggleSection(type)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '8px 4px',
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: 'var(--text-secondary)',
                }}
              >
                {isCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                <span
                  style={{
                    fontSize: 14,
                    fontWeight: 600,
                    letterSpacing: '0.5px',
                  }}
                >
                  [{bracketLabel}]
                </span>
                <span
                  style={{
                    fontSize: 11,
                    color: 'var(--text-secondary)',
                    opacity: 0.6,
                    marginLeft: 'auto',
                  }}
                >
                  {sectionComponents.length}
                </span>
              </button>

              {!isCollapsed && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {sectionComponents.map((component) => (
                    <DraggableWrapper
                      key={component.id}
                      componentId={component.id}
                      componentType={component.type as ComponentType}
                    >
                      <ComponentCard
                        component={component}
                        variant="sidebar"
                      />
                    </DraggableWrapper>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
}
