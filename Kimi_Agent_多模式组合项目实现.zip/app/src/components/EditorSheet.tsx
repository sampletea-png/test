import { useState, useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { COMPONENT_TYPE_CONFIG } from '@/types';
import type { BaseComponent } from '@/types';
import { X } from 'lucide-react';

export function EditorSheet() {
  const isEditorOpen = useAppStore((s) => s.isEditorOpen);
  const editingComponent = useAppStore((s) => s.editingComponent);
  const closeEditor = useAppStore((s) => s.closeEditor);
  const saveComponent = useAppStore((s) => s.saveComponent);

  const [form, setForm] = useState<BaseComponent | null>(null);

  useEffect(() => {
    if (editingComponent) {
      setForm({ ...editingComponent });
    }
  }, [editingComponent]);

  if (!isEditorOpen || !form) return null;

  const config = COMPONENT_TYPE_CONFIG[form.type];

  const handleSave = () => {
    if (form) {
      saveComponent(form);
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 100,
        display: 'flex',
        justifyContent: 'flex-end',
      }}
    >
      {/* Backdrop */}
      <div
        onClick={closeEditor}
        style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          backdropFilter: 'blur(4px)',
          animation: 'fadeIn 0.2s ease-out',
        }}
      />

      {/* Drawer */}
      <div
        style={{
          width: 480,
          maxWidth: '100vw',
          height: '100%',
          backgroundColor: 'var(--bg-panel)',
          borderLeft: '1px solid var(--border-primary)',
          position: 'relative',
          zIndex: 1,
          display: 'flex',
          flexDirection: 'column',
          animation: 'slideInRight 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-primary)',
          }}
        >
          <div>
            <h2
              style={{
                fontSize: 16,
                fontWeight: 600,
                color: 'var(--text-primary)',
              }}
            >
              编辑{config.label}
            </h2>
            <p
              style={{
                fontSize: 11,
                color: 'var(--text-secondary)',
                marginTop: 2,
              }}
            >
              {form.fileName}
            </p>
          </div>
          <button
            onClick={closeEditor}
            style={{
              width: 32,
              height: 32,
              borderRadius: 6,
              border: 'none',
              backgroundColor: 'transparent',
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 150ms ease',
            }}
            className="hover:bg-[#333] hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: 20,
            display: 'flex',
            flexDirection: 'column',
            gap: 16,
          }}
        >
          {/* Description */}
          <div>
            <label
              style={{
                display: 'block',
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-secondary)',
                marginBottom: 6,
                letterSpacing: '0.5px',
              }}
            >
              描述
            </label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              style={{
                width: '100%',
                minHeight: 60,
                padding: '8px 12px',
                borderRadius: 4,
                border: '1px solid var(--border-primary)',
                backgroundColor: 'var(--bg-base)',
                color: 'var(--text-primary)',
                fontSize: 13,
                fontFamily: 'inherit',
                resize: 'vertical',
                outline: 'none',
                transition: 'border-color 200ms ease',
              }}
              className="focus:border-[var(--accent-blue)]"
            />
          </div>

          {/* Content editor with line numbers */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            <label
              style={{
                display: 'block',
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-secondary)',
                marginBottom: 6,
                letterSpacing: '0.5px',
              }}
            >
              内容
            </label>
            <div
              style={{
                flex: 1,
                display: 'flex',
                borderRadius: 4,
                border: '1px solid var(--border-primary)',
                backgroundColor: 'var(--bg-base)',
                overflow: 'hidden',
                minHeight: 300,
              }}
            >
              {/* Line numbers */}
              <LineNumbers text={form.content} />

              {/* Textarea */}
              <textarea
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
                style={{
                  flex: 1,
                  padding: '8px 12px',
                  border: 'none',
                  backgroundColor: 'transparent',
                  color: 'var(--text-primary)',
                  fontSize: 12,
                  lineHeight: 1.7,
                  resize: 'none',
                  outline: 'none',
                  fontFamily: "'JetBrains Mono', 'Courier New', monospace",
                }}
                spellCheck={false}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          style={{
            padding: '12px 20px',
            borderTop: '1px solid var(--border-primary)',
            display: 'flex',
            justifyContent: 'flex-end',
            gap: 8,
            backgroundColor: 'var(--bg-panel)',
          }}
        >
          <button
            onClick={closeEditor}
            style={{
              padding: '8px 16px',
              borderRadius: 6,
              border: '1px solid var(--border-primary)',
              backgroundColor: 'var(--bg-card)',
              color: 'var(--text-primary)',
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 150ms ease',
            }}
            className="hover:bg-[#333]"
          >
            取消
          </button>
          <button
            onClick={handleSave}
            style={{
              padding: '8px 16px',
              borderRadius: 6,
              border: 'none',
              backgroundColor: 'var(--accent-blue)',
              color: '#fff',
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 150ms ease',
              boxShadow: '0 0 12px rgba(59,130,246,0.3)',
            }}
            className="hover:brightness-110 active:scale-[0.98]"
          >
            保存
          </button>
        </div>
      </div>
    </div>
  );
}

function LineNumbers({ text }: { text: string }) {
  const lines = text.split('\n').length;
  return (
    <div
      style={{
        padding: '8px 8px',
        backgroundColor: 'rgba(255,255,255,0.02)',
        borderRight: '1px solid var(--border-primary)',
        textAlign: 'right',
        userSelect: 'none',
        overflow: 'hidden',
      }}
      className="font-mono-code"
    >
      {Array.from({ length: Math.max(lines, 1) }, (_, i) => (
        <div
          key={i}
          style={{
            fontSize: 12,
            lineHeight: 1.7,
            color: '#555',
            minWidth: 24,
          }}
        >
          {i + 1}
        </div>
      ))}
    </div>
  );
}
