import type { ReactNode } from 'react';
import type { ComponentType } from '@/types';

interface DraggableWrapperProps {
  children: ReactNode;
  componentId: string;
  componentType: ComponentType;
}

export function DraggableWrapper({ children, componentId, componentType }: DraggableWrapperProps) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('componentId', componentId);
    e.dataTransfer.setData('componentType', componentType);
    e.dataTransfer.effectAllowed = 'copy';

    // Add a drag image or styling
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '0.6';
  };

  const handleDragEnd = (e: React.DragEvent) => {
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '1';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      style={{ cursor: 'grab' }}
    >
      {children}
    </div>
  );
}
