import type { Pattern } from '@/types';
import { personas, thinkingModels, dialoguePatterns } from './components';

export const defaultPatterns: Pattern[] = [
  {
    id: 'plan',
    name: 'Plan',
    label: '[Plan]',
    inheritsFrom: null,
    isModified: false,
    slots: {
      persona: personas[0],
      thinking: thinkingModels[0],
      dialogue: dialoguePatterns[0],
    },
  },
  {
    id: 'build',
    name: 'Build',
    label: '[Build]',
    inheritsFrom: null,
    isModified: false,
    slots: {
      persona: personas[1],
      thinking: thinkingModels[1],
      dialogue: dialoguePatterns[1],
    },
  },
  {
    id: 'research',
    name: 'Research',
    label: '[Research]',
    inheritsFrom: null,
    isModified: false,
    slots: {
      persona: personas[2],
      thinking: thinkingModels[2],
      dialogue: dialoguePatterns[2],
    },
  },
];
