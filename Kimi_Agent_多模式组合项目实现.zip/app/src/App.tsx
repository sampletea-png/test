import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { PatternSelector } from '@/components/PatternSelector';
import { SlotArea } from '@/components/SlotArea';
import { PreviewConsole } from '@/components/PreviewConsole';
import { EditorSheet } from '@/components/EditorSheet';
import { CreatePatternModal } from '@/components/CreatePatternModal';

export default function App() {
  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        backgroundColor: 'var(--bg-base)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <Header />

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Sidebar */}
        <Sidebar />

        {/* Workspace */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Pattern tabs */}
          <PatternSelector />

          {/* Slot area */}
          <SlotArea />

          {/* Preview */}
          <PreviewConsole />
        </div>
      </div>

      {/* Overlays */}
      <EditorSheet />
      <CreatePatternModal />
    </div>
  );
}
