import { create } from 'zustand';
import type { Pattern, BaseComponent, ComponentType } from '@/types';
import { defaultPatterns } from '@/data/patterns';
import { allComponents } from '@/data/components';

interface AppState {
  // Data
  patterns: Pattern[];
  components: BaseComponent[];
  
  // Active state
  activePatternId: string | null;
  activeTab: 'json' | 'simulation';
  searchQuery: string;
  
  // UI state
  isCreateModalOpen: boolean;
  isEditorOpen: boolean;
  editingComponent: BaseComponent | null;
  removingPatternId: string | null;
  
  // Actions
  setActivePattern: (id: string) => void;
  setActiveTab: (tab: 'json' | 'simulation') => void;
  setSearchQuery: (query: string) => void;
  
  // Slot operations
  assignComponentToSlot: (componentId: string, slotType: ComponentType) => void;
  clearSlot: (slotType: ComponentType) => void;
  
  // Pattern CRUD
  createPattern: (name: string, inheritsFrom: string | null) => void;
  removePattern: (id: string) => void;
  startRemovePattern: (id: string | null) => void;
  confirmRemovePattern: () => void;
  
  // Editor
  openEditor: (component: BaseComponent) => void;
  closeEditor: () => void;
  saveComponent: (updated: BaseComponent) => void;
  
  // Modal
  openCreateModal: () => void;
  closeCreateModal: () => void;
  
  // Getters
  getActivePattern: () => Pattern | undefined;
  getFilteredComponents: () => BaseComponent[];
  getParentPattern: () => Pattern | undefined;
}

export const useAppStore = create<AppState>((set, get) => ({
  // Initial data
  patterns: [...defaultPatterns],
  components: [...allComponents],
  activePatternId: defaultPatterns[0]?.id || null,
  activeTab: 'json',
  searchQuery: '',
  isCreateModalOpen: false,
  isEditorOpen: false,
  editingComponent: null,
  removingPatternId: null,

  setActivePattern: (id) => set({ activePatternId: id }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setSearchQuery: (query) => set({ searchQuery: query }),

  assignComponentToSlot: (componentId, slotType) => {
    const state = get();
    const component = state.components.find((c) => c.id === componentId);
    if (!component || !state.activePatternId) return;

    set({
      patterns: state.patterns.map((p) =>
        p.id === state.activePatternId
          ? {
              ...p,
              isModified: true,
              slots: {
                ...p.slots,
                [slotType]: component,
              },
            }
          : p
      ),
    });
  },

  clearSlot: (slotType) => {
    const state = get();
    if (!state.activePatternId) return;

    set({
      patterns: state.patterns.map((p) =>
        p.id === state.activePatternId
          ? {
              ...p,
              isModified: true,
              slots: {
                ...p.slots,
                [slotType]: null,
              },
            }
          : p
      ),
    });
  },

  createPattern: (name, inheritsFrom) => {
    const state = get();
    const id = name.toLowerCase().replace(/\s+/g, '-');
    const label = `[${name}]`;

    let slots = { persona: null, thinking: null, dialogue: null } as Pattern['slots'];

    if (inheritsFrom) {
      const parent = state.patterns.find((p) => p.id === inheritsFrom);
      if (parent) {
        slots = { ...parent.slots };
      }
    }

    const newPattern: Pattern = {
      id,
      name,
      label,
      inheritsFrom,
      isModified: false,
      slots,
    };

    set({
      patterns: [...state.patterns, newPattern],
      activePatternId: id,
      isCreateModalOpen: false,
    });
  },

  removePattern: (id) => {
    const state = get();
    const filtered = state.patterns.filter((p) => p.id !== id);
    set({
      patterns: filtered,
      activePatternId:
        state.activePatternId === id
          ? filtered[0]?.id || null
          : state.activePatternId,
      removingPatternId: null,
    });
  },

  startRemovePattern: (id) => set({ removingPatternId: id }),
  
  confirmRemovePattern: () => {
    const state = get();
    if (state.removingPatternId) {
      get().removePattern(state.removingPatternId);
    }
  },

  openEditor: (component) => set({ isEditorOpen: true, editingComponent: component }),
  closeEditor: () => set({ isEditorOpen: false, editingComponent: null }),

  saveComponent: (updated) => {
    const state = get();
    set({
      components: state.components.map((c) => (c.id === updated.id ? updated : c)),
      patterns: state.patterns.map((p) => {
        const updatedSlots = { ...p.slots };
        let hasChange = false;
        (Object.keys(updatedSlots) as ComponentType[]).forEach((key) => {
          if (updatedSlots[key]?.id === updated.id) {
            updatedSlots[key] = updated;
            hasChange = true;
          }
        });
        return hasChange ? { ...p, slots: updatedSlots } : p;
      }),
      isEditorOpen: false,
      editingComponent: null,
    });
  },

  openCreateModal: () => set({ isCreateModalOpen: true }),
  closeCreateModal: () => set({ isCreateModalOpen: false }),

  getActivePattern: () => {
    const state = get();
    return state.patterns.find((p) => p.id === state.activePatternId);
  },

  getFilteredComponents: () => {
    const state = get();
    const query = state.searchQuery.toLowerCase();
    if (!query) return state.components;
    return state.components.filter(
      (c) =>
        c.name.toLowerCase().includes(query) ||
        c.fileName.toLowerCase().includes(query) ||
        c.description.toLowerCase().includes(query)
    );
  },

  getParentPattern: () => {
    const state = get();
    const active = state.getActivePattern();
    if (!active?.inheritsFrom) return undefined;
    return state.patterns.find((p) => p.id === active.inheritsFrom);
  },
}));
