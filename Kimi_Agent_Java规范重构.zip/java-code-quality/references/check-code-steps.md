# 判断代码是否符合规范的步骤：七层递进检查法

## 步骤1：结构化扫描
1.1 类/接口/枚举命名：UpperCamelCase
1.2 包声明：反向域名
1.3 类行数：>300行 → 过大类
1.4 方法数量：>20个 → 可能职责过多
1.5 字段数量：>10个 → 考虑拆分
1.6 导入语句：无未使用导入，无通配符导入
1.7 类修饰符：public/final/abstract正确
1.8 继承深度：不超过3层
1.9 类注释：Javadoc完整

## 步骤2：封装检查
2.1 字段是否private（常量除外）
2.2 是否存在不必要的setter暴露
2.3 集合getter是否返回防御性拷贝/不可变视图
2.4 可变对象引用是否在getter中返回拷贝
2.5 setter是否包含参数校验
2.6 构造方法是否null检查
2.7 是否存在public字段
2.8 内部状态是否可被外部修改

## 步骤3：SOLID检查
3.1 SRP：类名准确？多个变更原因？方法>15？
3.2 OCP：新增功能是否需修改现有代码？是否存在类型判断？
3.3 LSP：子类可替换父类？构造方法调用可重写方法？
3.4 ISP：接口方法>10？空实现？
3.5 DIP：高层依赖具体类？使用new创建依赖？

## 步骤4：方法级检查
4.1 命名：lowerCamelCase，动词开头
4.2 长度：<30行
4.3 参数数量：<=4个
4.4 返回值：空集合优于null？Optional正确？
4.5 嵌套深度：不超过3层
4.6 圈复杂度：不超过10
4.7 重复代码检测
4.8 单一职责
4.9 副作用检查

## 步骤5：异常与资源检查
5.1 异常使用而非返回码
5.2 受检/非受检选择正确
5.3 无空catch块
5.4 异常链保留原始异常
5.5 try-with-resources
5.6 finally不抛异常
5.7 InterruptedException处理
5.8 自定义异常命名/继承正确

## 步骤6：并发与安全检查
6.1 共享可变状态线程安全？
6.2 同步范围最小化
6.3 死锁风险
6.4 volatile正确使用
6.5 原子操作使用AtomicXxx
6.6 ThreadLocal清理
6.7 SQL注入检查（PreparedStatement？）
6.8 XSS防护
6.9 敏感数据处理

## 步骤7：现代Java检查
7.1 instanceof pattern matching
7.2 switch表达式
7.3 record使用
7.4 Optional正确使用
7.5 Stream API
7.6 text blocks
7.7 var合理使用
7.8 sealed class
7.9 virtual threads（Java 21+）
