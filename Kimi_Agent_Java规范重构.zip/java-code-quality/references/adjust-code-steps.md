# 将代码调整为符合规范的步骤：渐进式重构法

## Phase 1：安全防护
1.1 确保测试覆盖当前行为
1.2 运行测试全部通过
1.3 版本控制提交基线
1.4 小步提交策略

## Phase 2：低垂果实（Quick Wins）
2.1 格式化统一
2.2 命名修正（IDE重构Shift+F6）
2.3 删除未使用导入
2.4 删除死代码
2.5 魔法数字提取为常量
2.6 访问修饰符收紧
2.7 添加@Override
2.8 布尔表达式简化

## Phase 3：结构重塑
3.1 提取方法（Extract Method，Ctrl+Alt+M）
   - 识别独立逻辑块
   - 命名表达意图
   - 确定参数和返回值

3.2 提取类（Extract Class）
   - 识别内聚数据子集
   - 创建新类，移动字段方法
   - 原类持有引用

3.3 搬移方法（Move Method）
   - 识别特性依恋
   - 方法移至数据所在类

3.4 引入参数对象（Introduce Parameter Object）
   - 识别一起传递的参数组
   - 创建record或class

3.5 用多态替代条件（Replace Conditional with Polymorphism）
   - 提取策略接口
   - 各类型创建实现类
   - 工厂创建实例

## Phase 4：依赖治理
4.1 提取接口（Extract Interface）
4.2 依赖注入改造（new→构造函数参数）
4.3 打破循环依赖
4.4 用组合替代继承

## Phase 5：质量提升
5.1 防御式编程：Objects.requireNonNull，前置条件验证
5.2 异常处理：自定义异常，异常链，上下文信息
5.3 资源管理：try-with-resources
5.4 不可变性：final字段/类，防御性拷贝，record

## Phase 6：现代化升级
6.1 Stream API迁移（for→filter/map/collect）
6.2 Optional引入（返回null→Optional）
6.3 Pattern Matching（强制转换→instanceof pattern）
6.4 Text blocks（多行字符串拼接→"""）
6.5 Record迁移（纯数据POJO→record）
6.6 Virtual Threads（Java 21+，避免synchronized pinning）

## Phase 7：验证确认
7.1 运行所有测试通过
7.2 代码审查
7.3 静态分析（SonarQube/SpotBugs）
7.4 性能测试无退化
7.5 文档更新
