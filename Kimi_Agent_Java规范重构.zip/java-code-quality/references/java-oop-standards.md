# Java与面向对象编程完整规范体系

## 一、面向对象基础规范

### 1.1 封装
- 所有字段private，通过getter/setter访问
- 禁止直接暴露可变对象引用（返回防御性拷贝或不可变视图）
- 类内部状态不得被外部直接修改
- setter应包含参数校验逻辑
- 避免"贫血模型"——类应包含行为而不仅是数据

### 1.2 继承
- 优先使用组合而非继承
- 继承必须满足"is-a"关系
- 子类遵守Liskov替换原则（LSP）
- 重写方法保持前置条件不变或更弱、后置条件不变或更强
- 禁止在构造方法中调用可重写方法
- 可重写方法必须文档化内部调用模式

### 1.3 多态
- 面向接口编程，而非面向实现
- 优先使用接口类型声明变量、参数和返回值
- 利用多态消除条件判断
- 避免使用instanceof进行类型检查

### 1.4 抽象
- 抽象层次与领域模型一致
- 抽象类定义模板方法，文档化算法骨架
- 接口定义行为契约，非数据持有
- 接口隔离：接口小而专注

## 二、SOLID原则

### 2.1 单一职责（SRP）
- 一个类只有一个引起变化的原因
- 类名清晰表达职责
- 方法只做一件事
- 类行数<300，方法行数<30

### 2.2 开闭原则（OCP）
- 对扩展开放，对修改关闭
- 新增功能通过新增代码
- 使用策略模式、模板方法模式实现扩展点

### 2.3 Liskov替换（LSP）
- 子类必须可替换父类
- 子类不得strengthening前置条件
- 子类不得weakening后置条件
- 子类必须保持父类不变式

### 2.4 接口隔离（ISP）
- 客户端不依赖不使用的接口
- 接口细化到最小功能单元
- 避免"胖接口"

### 2.5 依赖倒置（DIP）
- 高层模块不依赖低层模块，两者依赖抽象
- 通过依赖注入管理依赖
- 避免new关键字在业务逻辑中创建依赖

## 三、Java语言规范

### 3.1 命名
- 类名：UpperCamelCase，名词
- 方法名：lowerCamelCase，动词短语
- 变量名：lowerCamelCase，有意义名称
- 常量：UPPER_SNAKE_CASE
- 包名：全小写，反向域名
- 泛型参数：单字母大写（T、E、K、V）
- 布尔方法：is/has/can/should + 形容词
- 测试方法：should_xxx_when_xxx

### 3.2 异常处理
- 使用异常而非返回码
- 受检异常用于可恢复错误，非受检用于编程错误
- 不得捕获Exception/Throwable后空处理
- 抛出新异常时保留原始异常（initCause）
- 自定义异常继承合适类型
- 异常信息包含上下文
- finally块不抛出异常
- 使用try-with-resources
- 不忽略InterruptedException

### 3.3 集合与数据结构
- 面向接口声明：List<T>而非ArrayList<T>
- 返回空集合而非null
- 使用不可变集合防御修改
- 优先使用Stream API
- 重写equals必须重写hashCode
- Comparable与equals一致

### 3.4 并发
- 优先使用java.util.concurrent
- 不可变对象天然线程安全
- 最小化同步范围
- 避免持有锁时调用外部方法
- ThreadLocal确保清理
- volatile仅保证可见性
- 原子类优于synchronized简单操作
- 使用CompletableFuture
- 线程池自定义命名和拒绝策略

### 3.5 泛型
- 消除原始类型
- 利用有界通配符（PECS原则）
- 避免泛型数组创建
- @SafeVarargs仅在安全时使用

### 3.6 Lambda与Stream
- Lambda简洁（<3行），复杂提取方法引用
- 避免Stream中修改外部变量
- Stream链不宜过长
- 并行Stream仅在大量数据时使用
- Optional仅作为返回值，不作为参数/字段

## 四、现代Java特性（Java 9-21）

- Record类用于数据载体
- Pattern Matching替代强制转换
- Sealed Classes控制继承
- Text Blocks用于多行字符串
- Switch Expressions箭头语法
- Virtual Threads高并发（避免synchronized pinning）
- String Templates（Java 21+ preview）

## 五、设计模式

### 5.1 创建型
- Builder（多参数）、Factory（多实现）、枚举单例

### 5.2 结构型
- Adapter、Decorator、Proxy、Facade

### 5.3 行为型
- Strategy、Template Method、Observer、Chain of Responsibility、Command

## 六、代码质量

### 6.1 可读性
- 代码自文档化（命名即注释）
- 注释解释"为什么"
- 避免魔法数字
- 控制嵌套深度（不超过3层）
- 卫语句、尽早返回

### 6.2 可测试性
- 依赖注入使单元测试可mock
- 静态方法无状态
- 避免硬编码依赖
- 测试独立、可重复、快速

### 6.3 防御式编程
- 参数校验（Objects.requireNonNull）
- Null安全（Optional或Null Object）
- 边界条件检查
- 输入验证永不信任外部数据

### 6.4 资源管理
- try-with-resources自动关闭
- 实现AutoCloseable
- 避免内存泄漏

## 七、架构规范

### 7.1 分层架构
- 层间依赖单向向下
- 层间通过DTO传输
- 领域层不依赖基础设施

### 7.2 DDD
- 区分Entity与Value Object
- 聚合根维护一致性边界
- 仓储抽象持久化
- 领域事件解耦子系统

### 7.3 API设计
- 参数最多4个，超则用Builder
- 返回空集合优于null
- 最小惊讶原则
- 线程安全性文档化

## 八、Spring/Boot规范

- 构造函数注入优于字段注入
- Controller仅HTTP适配，无业务逻辑
- @Transactional在Service层
- RESTful：URI资源+HTTP方法+正确状态码
- 配置外部化+敏感配置加密

## 九、数据访问

- JPA：懒加载默认，N+1检测，乐观锁@Version
- 查询用JPQL/Specification而非原生SQL
- JDBC：NamedParameterJdbcTemplate，批量更新
- 连接池：HikariCP

## 十、安全

- SQL注入：PreparedStatement
- XSS：输出编码
- 敏感信息不硬编码、不日志输出
- 密码强哈希（bcrypt/scrypt）
- 输入验证白名单策略

## 十一、日志与监控

- SLF4J/Logback，非System.out
- 参数化日志避免拼接
- 敏感信息不记录
- 日志包含上下文（TraceId）
- 结构化日志（JSON格式）

## 十二、软件工程原则

- KISS：简单优先
- DRY：提取重复，适度重复优于错误抽象
- YAGNI：不实现当前不需要的功能
- Law of Demeter：链式调用不超过一层
- Tell, Don't Ask：行为封装在对象内
