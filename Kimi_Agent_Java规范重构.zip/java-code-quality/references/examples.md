# 多场景示例

## 场景1：检查代码是否符合规范

**输入：** 一个Java类
**处理流程：**
1. 结构化扫描：检查命名、行数、导入
2. 封装检查：字段private？getter防御性拷贝？
3. SOLID检查：SRP？OCP？DIP？
4. 方法级：长度<30？参数<=4？
5. 异常与资源：try-with-resources？异常链？
6. 并发安全：线程安全？synchronized范围？
7. 现代特性：Stream？Optional？Pattern Matching？

**输出格式：**
```
## 检查结果

### 违规项（Critical）
- [封装] Line 15: 字段`items`为public，应改为private
- [SRP] Line 1: 类`OrderManager`同时处理订单+支付+库存，违反单一职责
- [异常] Line 45: 空catch块捕获Exception

### 建议项（Warning）
- [Lombok] Line 20: 使用@Data过于宽泛，建议显式@Getter/@Builder
- [Stream] Line 78: for循环可替换为stream.filter().map().collect()
- [Optional] Line 90: 方法返回null，建议返回Optional<T>

### 现代特性建议
- [Pattern Matching] Line 55: (Order)obj强制转换→使用instanceof Order o
- [Record] Line 10: 纯数据类OrderDTO可改为record

### 评分
- 规范符合度: 62/100
- 主要问题: 封装缺失、职责过多、异常处理不当
- 建议优先级: 先修复Critical，再优化Warning
```

## 场景2：将代码调整为符合规范

**输入：** 一段不符合规范的Java代码
**处理流程：**
1. Phase 1安全防护：写测试→运行通过→提交基线
2. Phase 2低垂果实：格式化→命名修正→删除死代码
3. Phase 3结构重塑：提取方法→提取类→搬移方法
4. Phase 4依赖治理：提取接口→依赖注入→打破循环依赖
5. Phase 5质量提升：防御性编程→异常处理→try-with-resources
6. Phase 6现代化：Stream API→Optional→Pattern Matching→Record
7. Phase 7验证：测试→静态分析→性能测试

**输出格式：**
```
## 重构方案

### 步骤1：测试先行
```java
// 先写测试捕获当前行为
@Test
void shouldCalculateTotalWithDiscount() {
    // Given
    var order = new Order(List.of(item1, item2));
    // When
    var total = order.calculateTotal();
    // Then
    assertThat(total).isEqualTo(Money.of(180));
}
```

### 步骤2：提取方法
```java
// 重构前：30行的calculateTotal方法
// 重构后：
public Money calculateTotal() {
    var subtotal = calculateSubtotal();
    var discount = calculateDiscount(subtotal);
    return subtotal.subtract(discount);
}

private Money calculateSubtotal() {
    return items.stream()
        .map(OrderItem::getPrice)
        .reduce(Money.ZERO, Money::add);
}
```

### 步骤3：引入Record
```java
// 重构前
public class OrderDTO {
    private Long id;
    private String customerName;
    // getter/setter/toString/equals/hashCode
}

// 重构后
public record OrderDTO(Long id, String customerName) {}
```

### 验证结果
- 测试: 全部通过
- 覆盖率: 85%（重构前72%）
- SonarQube: 0新增异味
```

## 场景3：从零开发符合规范的代码

**输入：** 用户故事（如"创建订单功能"）
**处理流程：**
1. 需求分析：名词→Order/OrderItem/Customer；动词→create/validate/calculate
2. 架构设计：分层架构，接口契约
3. 类设计：Order聚合根，OrderItem值对象
4. 方法设计：createOrder参数<=4，返回OrderResult
5. TDD实现：红-绿-重构
6. 单元测试：Given-When-Then，边界条件
7. 代码审查：对照规范清单

**输出：** 完整符合规范的Java代码+测试

## 场景4：遗留代码重构

**输入：** 无测试的遗留代码
**处理流程：**
1. 创建Characterization Test（捕捉现有行为）
2. 理解代码（类图+数据流）
3. 低风险重构（命名+格式+死代码）
4. 方法级重构（Extract Method+Guard Clauses）
5. 类级重构（Extract Class+Move Method）
6. 现代化（Stream+Optional+Record）
7. 验证（测试+SonarQube+性能）

**输出：** 重构后的代码+完整的回归测试套件

## 场景5：并发代码重构

**输入：** 线程不安全的代码
**处理流程：**
1. 识别共享可变状态
2. 同步范围缩小（synchronized方法→synchronized块）
3. 原子变量（AtomicInteger替代synchronized计数器）
4. 不可变对象替代同步
5. 并发集合（ConcurrentHashMap替代synchronizedMap）
6. CompletableFuture替代阻塞调用
7. JCStress测试验证线程安全

**输出：** 线程安全的重构代码+并发测试
