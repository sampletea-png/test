# 代码重构为符合规范的步骤：安全重构方法论

## Phase 0：准备
0.1 代码基线：git tag + 独立分支
0.2 测试基线：记录覆盖率，补充关键测试
0.3 范围界定：目标、边界、风险区域、回滚策略
0.4 工具准备：IDE重构快捷键、SonarLint

## Phase 1：理解代码
1.1 类关系图（继承/组合/依赖）
1.2 数据流分析（输入流向、状态变更、副作用）
1.3 代码异味识别（长方法、大类、重复、特性依恋等13种）
1.4 依赖关系分析（耦合度、循环依赖）

## Phase 2：低风险重构
2.1 格式化、导入优化
2.2 命名修正（IDE Shift+F6）
2.3 访问修饰符收紧
2.4 魔法数字提取
2.5 死代码删除
2.6 添加@Override
2.7 布尔表达式简化

## Phase 3：方法级重构
3.1 提取方法（Extract Method，Ctrl+Alt+M）
3.2 内联方法（Inline Method）
3.3 提取变量（Extract Variable）
3.4 卫语句替代嵌套（Guard Clauses）
3.5 合并条件表达式
3.6 分解条件（Decompose Conditional）
3.7 引入参数对象
3.8 移除标记参数

## Phase 4：类级重构
4.1 提取类（Extract Class）
4.2 搬移方法（Move Method）
4.3 隐藏委托（Hide Delegate）
4.4 用组合替代继承

## Phase 5：继承与多态
5.1 方法上移/下移
5.2 提取超类/子类
5.3 提取接口
5.4 用多态替代条件
5.5 引入Null Object

## Phase 6：异常与资源
6.1 异常替代返回码
6.2 异常包装（保留initCause）
6.3 引入try-with-resources
6.4 引入断言

## Phase 7：数据组织
7.1 封装集合（返回不可变视图）
7.2 用对象替代数组
7.3 封装字段

## Phase 8：现代化
8.1 循环→Stream API
8.2 null→Optional
8.3 强制转换→Pattern Matching
8.4 switch→switch表达式
8.5 POJO→Record
8.6 匿名类→Lambda
8.7 字符串拼接→Text Blocks
8.8 synchronized→java.util.concurrent

## Phase 9：验证收尾
9.1 编译验证
9.2 单元测试100%通过
9.3 集成测试
9.4 静态分析（SonarQube）
9.5 代码审查
9.6 性能验证（JMH）
9.7 文档更新

## 补充：大规模重构策略
- 分支抽象（Branch by Abstraction）
- 绞杀者模式（Strangler Fig）
- 特性开关保护
- 数据库迁移：添加→双写→迁移→删除
- Boy Scout Rule：每次提交比来时干净
- 大重构拆分为可独立发布的小步骤
