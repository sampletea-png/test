---
name: java-code-quality
description: Java代码质量保障体系，包含面向对象规范、代码检查步骤、代码调整步骤、开发规范步骤和重构规范步骤。用于（1）检查Java代码是否符合OO规范和最佳实践，（2）将不符合规范的代码调整为符合规范，（3）从零开发符合规范的Java代码，（4）重构遗留代码为符合规范的代码。适用于任何Java代码质量相关任务。
---

# Java代码质量保障

Java代码质量保障skill提供完整的规范体系、检查步骤和调整步骤，覆盖面向对象基础、SOLID原则、Java语言规范、现代Java特性、设计模式、代码质量、架构规范等维度。

## 何时使用此skill

- 检查Java代码是否符合面向对象规范和最佳实践
- 将不符合规范的代码重构为符合规范
- 从零开发符合规范的Java代码
- 审查Java代码并给出规范改进建议
- 学习Java编码规范和质量标准

## 规范体系

完整规范参考 [references/java-oop-standards.md](references/java-oop-standards.md)，包含：

| 类别 | 核心要点 |
|------|----------|
| 面向对象基础 | 封装、继承、多态、抽象 |
| SOLID原则 | 单一职责、开闭、Liskov替换、接口隔离、依赖倒置 |
| Java语言规范 | 命名、异常、集合、并发、泛型、Lambda |
| 现代Java特性 | Record、Pattern Matching、Sealed Class、Virtual Threads |
| 设计模式 | 创建型、结构型、行为型 |
| 代码质量 | 可读性、可测试性、防御式编程、资源管理 |
| 架构规范 | 分层、DDD、API设计 |
| 框架规范 | Spring/Boot依赖注入、事务、RESTful API |
| 安全 | SQL注入防护、XSS防护、敏感数据处理 |

## 检查流程

判断代码是否符合规范，使用七层递进检查法。详见 [references/check-code-steps.md](references/check-code-steps.md)：

1. **结构化扫描** — 命名、行数、继承深度
2. **封装检查** — 字段private、防御性拷贝
3. **SOLID检查** — SRP、OCP、LSP、ISP、DIP
4. **方法级检查** — 长度<30行、参数<=4、圈复杂度<10
5. **异常与资源** — try-with-resources、异常链
6. **并发与安全** — 线程安全、SQL注入、XSS
7. **现代特性** — Stream、Optional、Pattern Matching

## 调整流程

将代码调整为符合规范，使用渐进式重构法。详见 [references/adjust-code-steps.md](references/adjust-code-steps.md)：

1. **安全防护** — 测试覆盖、版本控制基线
2. **低垂果实** — 格式化、命名修正、死代码删除
3. **结构重塑** — 提取方法/类、搬移方法、多态替代条件
4. **依赖治理** — 提取接口、依赖注入、组合替代继承
5. **质量提升** — 防御式编程、异常处理、不可变性
6. **现代化** — Stream API、Optional、Pattern Matching、Record
7. **验证确认** — 测试、审查、静态分析、性能测试

## 开发流程

从零开发符合规范的代码。详见 [references/dev-steps.md](references/dev-steps.md)：

1. **需求分析** — 识别领域对象、聚合边界
2. **架构设计** — 分层、模块、接口契约
3. **类设计** — SRP、封装、不可变对象
4. **方法设计** — 命名、参数<=4、Optional返回
5. **TDD编码** — 红绿重构、充血模型、依赖注入
6. **单元测试** — Given-When-Then、边界条件
7. **代码审查** — 对照规范清单
8. **持续集成** — 静态分析、质量门禁

## 重构流程

重构遗留代码为符合规范。详见 [references/refactor-steps.md](references/refactor-steps.md)：

1. **准备** — 基线、测试、范围、工具
2. **理解代码** — 类图、数据流、异味识别
3. **低风险重构** — 格式化、命名、死代码
4. **方法级** — Extract Method、Guard Clauses
5. **类级** — Extract Class、Move Method
6. **多态** — 多态替代条件、Null Object
7. **异常资源** — try-with-resources、异常链
8. **现代化** — Stream、Optional、Record
9. **验证** — 测试、SonarQube、性能

## 多场景示例

详见 [references/examples.md](references/examples.md)，覆盖：
- 场景1：检查代码是否符合规范
- 场景2：将代码调整为符合规范
- 场景3：从零开发符合规范的代码
- 场景4：遗留代码重构
- 场景5：并发代码重构

## 使用原则

1. **先检查再调整** — 先用检查流程识别问题，再用调整流程修复
2. **安全重构** — 始终确保测试覆盖，小步提交
3. **循序渐进** — 从低垂果实开始，逐步深入结构重构
4. **现代化升级** — 充分利用Java 17+现代特性简化代码
