"""
MF4文件处理模块测试
"""
import pytest
import os
import tempfile
import numpy as np
from asammdf import MDF, Signal

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mf4_handler import Mf4FileManager, WriteMode, DataChunker


class TestMf4FileManager:
    """测试Mf4FileManager类"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    @pytest.fixture
    def manager(self):
        """创建文件管理器"""
        return Mf4FileManager(max_memory_mb=256)
    
    @pytest.fixture
    def sample_mf4_file(self, temp_dir):
        """创建示例MF4文件"""
        file_path = os.path.join(temp_dir, "test.mf4")
        
        # 创建测试数据
        timestamps = np.linspace(0, 10, 1000)
        values = np.sin(timestamps)
        
        signal = Signal(
            samples=values,
            timestamps=timestamps,
            name="TestChannel",
            unit="V"
        )
        
        mdf = MDF(version='4.11')
        mdf.append([signal], comment="Test file")
        mdf.save(file_path, overwrite=True)
        mdf.close()
        
        return file_path
    
    def test_open_file_read_mode(self, manager, sample_mf4_file):
        """测试以只读模式打开文件"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        assert file_id is not None
        assert len(file_id) > 0
        
        # 清理
        manager.close_file(file_id)
    
    def test_open_file_not_exists(self, manager, temp_dir):
        """测试打开不存在的文件"""
        non_existent = os.path.join(temp_dir, "non_existent.mf4")
        
        with pytest.raises(FileNotFoundError):
            manager.open_file(non_existent, 'r', create_if_not_exists=False)
    
    def test_open_file_create_if_not_exists(self, manager, temp_dir):
        """测试打开不存在的文件时创建"""
        new_file = os.path.join(temp_dir, "new.mf4")
        
        file_id = manager.open_file(new_file, 'w', create_if_not_exists=True)
        assert file_id is not None
        
        manager.close_file(file_id)
        assert os.path.exists(new_file)
    
    def test_close_file(self, manager, sample_mf4_file):
        """测试关闭文件"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        success = manager.close_file(file_id)
        assert success is True
    
    def test_get_file_info(self, manager, sample_mf4_file):
        """测试获取文件信息"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        info = manager.get_file_info(file_id)
        assert 'filePath' in info
        assert 'version' in info
        assert 'channelCount' in info
        
        manager.close_file(file_id)
    
    def test_get_channels(self, manager, sample_mf4_file):
        """测试获取通道列表"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        channels = manager.get_channels(file_id)
        assert isinstance(channels, list)
        assert len(channels) > 0
        
        first_ch = channels[0]
        assert 'name' in first_ch
        assert 'groupIndex' in first_ch
        assert 'channelIndex' in first_ch
        
        manager.close_file(file_id)
    
    def test_get_channel_info(self, manager, sample_mf4_file):
        """测试获取通道详细信息"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        info = manager.get_channel_info(file_id, 0, 0)
        assert 'name' in info
        assert 'groupIndex' in info
        assert 'channelIndex' in info
        
        manager.close_file(file_id)
    
    def test_find_channel(self, manager, sample_mf4_file):
        """测试查找通道"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        results = manager.find_channel(file_id, "Test")
        assert isinstance(results, list)
        assert len(results) > 0
        
        manager.close_file(file_id)
    
    def test_read_data(self, manager, sample_mf4_file):
        """测试读取数据"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        result = manager.read_data(file_id, 0, 0)
        assert 'timestamps' in result
        assert 'values' in result
        assert 'name' in result
        assert 'sampleCount' in result
        
        manager.close_file(file_id)
    
    def test_read_data_with_time_range(self, manager, sample_mf4_file):
        """测试按时间范围读取数据"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        result = manager.read_data(file_id, 0, 0, start=2.0, end=5.0)
        assert 'timestamps' in result
        assert 'values' in result
        
        # 验证时间范围
        timestamps = result['timestamps']
        if timestamps:
            assert timestamps[0] >= 2.0
            assert timestamps[-1] <= 5.0
        
        manager.close_file(file_id)
    
    def test_read_data_with_samples_limit(self, manager, sample_mf4_file):
        """测试限制采样数读取"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        result = manager.read_data(file_id, 0, 0, samples=100)
        assert result['sampleCount'] <= 100
        
        manager.close_file(file_id)
    
    def test_write_data_create_new(self, manager, temp_dir):
        """测试创建新通道写入数据"""
        file_path = os.path.join(temp_dir, "write_test.mf4")
        file_id = manager.open_file(file_path, 'w', create_if_not_exists=True)
        
        channel_data = [{
            'name': 'NewChannel',
            'unit': 'A',
            'timestamps': [0.0, 0.1, 0.2, 0.3],
            'values': [1.0, 2.0, 3.0, 4.0]
        }]
        
        result = manager.write_data(file_id, 0, channel_data, write_mode='create_new')
        assert result['success'] is True
        assert result['channelsCreated'] == 1
        
        manager.close_file(file_id)
    
    def test_write_data_append(self, manager, temp_dir):
        """测试追加数据到现有通道（extend方式）"""
        file_path = os.path.join(temp_dir, "append_test.mf4")
        file_id = manager.open_file(file_path, 'w', create_if_not_exists=True)
        
        # 首先创建通道
        channel_data = [{
            'name': 'TestChannel',
            'unit': 'V',
            'timestamps': [0.0, 0.1, 0.2],
            'values': [1.0, 2.0, 3.0]
        }]
        
        result = manager.write_data(file_id, 0, channel_data, write_mode='create_new')
        assert result['success'] is True
        
        # 追加数据
        append_data = [{
            'name': 'TestChannel',
            'unit': 'V',
            'timestamps': [0.3, 0.4, 0.5],
            'values': [4.0, 5.0, 6.0]
        }]
        
        result = manager.write_data(file_id, 0, append_data, write_mode='append')
        assert result['success'] is True
        assert result['channelsAppended'] == 1
        
        # 验证数据已追加
        read_result = manager.read_data(file_id, 0, 0)
        assert read_result['sampleCount'] == 6  # 3 + 3
        
        manager.close_file(file_id)
    
    def test_write_data_overwrite(self, manager, temp_dir):
        """测试覆盖现有通道"""
        file_path = os.path.join(temp_dir, "overwrite_test.mf4")
        file_id = manager.open_file(file_path, 'w', create_if_not_exists=True)
        
        # 创建通道
        channel_data = [{
            'name': 'TestChannel',
            'unit': 'V',
            'timestamps': [0.0, 0.1, 0.2],
            'values': [1.0, 2.0, 3.0]
        }]
        
        manager.write_data(file_id, 0, channel_data, write_mode='create_new')
        
        # 覆盖数据
        new_data = [{
            'name': 'TestChannel',
            'unit': 'A',
            'timestamps': [0.0, 0.1],
            'values': [10.0, 20.0]
        }]
        
        result = manager.write_data(file_id, 0, new_data, write_mode='overwrite')
        assert result['success'] is True
        assert result['channelsOverwritten'] == 1
        
        # 验证数据已覆盖
        read_result = manager.read_data(file_id, 0, 0)
        assert read_result['sampleCount'] == 2
        
        manager.close_file(file_id)
    
    def test_save_file(self, manager, temp_dir):
        """测试保存文件"""
        file_path = os.path.join(temp_dir, "save_test.mf4")
        file_id = manager.open_file(file_path, 'w', create_if_not_exists=True)
        
        # 写入一些数据
        channel_data = [{
            'name': 'SaveChannel',
            'unit': 'V',
            'timestamps': [0.0, 0.1],
            'values': [1.0, 2.0]
        }]
        manager.write_data(file_id, 0, channel_data, write_mode='create_new')
        
        # 保存到新路径
        new_path = os.path.join(temp_dir, "saved.mf4")
        saved_path = manager.save_file(file_id, new_path, overwrite=True)
        
        assert saved_path == new_path
        assert os.path.exists(new_path)
        
        manager.close_file(file_id)
    
    def test_get_memory_stats(self, manager, sample_mf4_file):
        """测试获取内存统计"""
        file_id = manager.open_file(sample_mf4_file, 'r')
        
        stats = manager.get_memory_stats()
        assert 'openFiles' in stats
        assert 'activeIterators' in stats
        
        manager.close_file(file_id)
    
    def test_close_all(self, manager, sample_mf4_file, temp_dir):
        """测试关闭所有文件"""
        file_id1 = manager.open_file(sample_mf4_file, 'r')
        
        file_path2 = os.path.join(temp_dir, "test2.mf4")
        file_id2 = manager.open_file(file_path2, 'w', create_if_not_exists=True)
        
        manager.close_all()
        
        # 验证所有文件已关闭
        stats = manager.get_memory_stats()
        assert stats['openFiles'] == 0


class TestDataChunker:
    """测试DataChunker类"""
    
    @pytest.fixture
    def chunker(self):
        """创建分块器"""
        return DataChunker(samples_per_chunk=100, bytes_per_chunk=1024)
    
    def test_estimate_chunk_size(self, chunker):
        """测试分块大小估算"""
        size = chunker.estimate_chunk_size(1000, 8)
        assert size <= 100  # 不超过samples_per_chunk
    
    def test_create_iterator(self, chunker):
        """测试创建迭代器"""
        # 创建测试文件句柄
        timestamps = np.linspace(0, 10, 500)
        values = np.sin(timestamps)
        
        signal = Signal(
            samples=values,
            timestamps=timestamps,
            name="Test",
            unit="V"
        )
        
        mdf = MDF(version='4.11')
        mdf.append([signal])
        
        handle = type('MockHandle', (), {'mdf': mdf, 'lock': type('MockLock', (), {'__enter__': lambda s: s, '__exit__': lambda s, *a: None})()})()
        
        iterator = chunker.create_iterator(handle, 0, 0)
        
        chunks = list(iterator)
        assert len(chunks) > 0
        
        first_chunk = chunks[0]
        assert 'timestamps' in first_chunk
        assert 'values' in first_chunk
        assert 'chunkIndex' in first_chunk
        
        mdf.close()
