package com.mdf4;

import java.util.List;

/**
 * DataRecord - Represents a channel's data in an MDF4 file.
 * This class holds timestamps, values, and metadata for a single channel.
 */
public class DataRecord {
    
    private String channelName;
    private List<Double> timestamps;
    private List<Double> values;
    private String unit;
    
    /**
     * Default constructor
     */
    public DataRecord() {
    }
    
    /**
     * Constructor with all fields
     */
    public DataRecord(String channelName, List<Double> timestamps, 
                      List<Double> values, String unit) {
        this.channelName = channelName;
        this.timestamps = timestamps;
        this.values = values;
        this.unit = unit;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getChannelName() {
        return channelName;
    }
    
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    
    public List<Double> getTimestamps() {
        return timestamps;
    }
    
    public void setTimestamps(List<Double> timestamps) {
        this.timestamps = timestamps;
    }
    
    public List<Double> getValues() {
        return values;
    }
    
    public void setValues(List<Double> values) {
        this.values = values;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    // ==================== Utility Methods ====================
    
    /**
     * Get the number of samples in this record
     */
    public int getSampleCount() {
        return values != null ? values.size() : 0;
    }
    
    /**
     * Get the start time of this record
     */
    public double getStartTime() {
        return timestamps != null && !timestamps.isEmpty() ? timestamps.get(0) : 0.0;
    }
    
    /**
     * Get the end time of this record
     */
    public double getEndTime() {
        return timestamps != null && !timestamps.isEmpty() ? 
               timestamps.get(timestamps.size() - 1) : 0.0;
    }
    
    /**
     * Get the duration of this record
     */
    public double getDuration() {
        return getEndTime() - getStartTime();
    }
    
    @Override
    public String toString() {
        return String.format("DataRecord{channel='%s', samples=%d, unit='%s', timeRange=[%.3f, %.3f]}",
                channelName, getSampleCount(), unit, getStartTime(), getEndTime());
    }
}
