package com.mdf4;

import java.io.*;
import java.net.Socket;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

/**
 * PythonServiceManager - Manages the Python MDF4 service lifecycle.
 * Handles starting, stopping, and monitoring the Python service.
 * Supports automatic port detection and graceful shutdown.
 */
public class PythonServiceManager {
    
    private static final String DEFAULT_HOST = "localhost";
    private static final int DEFAULT_PORT = 25333;
    private static final int CONNECT_TIMEOUT_MS = 2000;
    private static final int MAX_STARTUP_WAIT_MS = 30000;
    private static final int STARTUP_CHECK_INTERVAL_MS = 500;
    
    private final String host;
    private int port;
    private final String pythonExecutable;
    private final String serverScriptPath;
    private final String portFilePath;
    private Process serviceProcess;
    private boolean autoRestartEnabled;
    
    /**
     * Constructor with default settings
     */
    public PythonServiceManager() {
        this(DEFAULT_HOST, DEFAULT_PORT, findPythonExecutable(), findServerScript());
    }
    
    /**
     * Constructor with custom settings
     */
    public PythonServiceManager(String host, int port, String pythonExecutable, String serverScriptPath) {
        this.host = host;
        this.port = port;
        this.pythonExecutable = pythonExecutable;
        this.serverScriptPath = serverScriptPath;
        this.portFilePath = new File(serverScriptPath).getParent() + File.separator + "mdf4_server.port";
        this.autoRestartEnabled = true;
    }
    
    /**
     * Find Python executable
     */
    public static String findPythonExecutable() {
        String[] candidates = {"python3", "python", "py"};
        for (String candidate : candidates) {
            try {
                ProcessBuilder pb = new ProcessBuilder(candidate, "--version");
                pb.inheritIO().redirectOutput(ProcessBuilder.Redirect.DISCARD);
                Process p = pb.start();
                if (p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0) {
                    return candidate;
                }
            } catch (Exception e) {
                // Try next candidate
            }
        }
        return "python3"; // Default fallback
    }
    
    /**
     * Find server script path
     */
    public static String findServerScript() {
        // Try to find relative to current directory
        Path[] candidates = {
            Paths.get("python-service", "socket_server.py"),
            Paths.get("..", "python-service", "socket_server.py"),
            Paths.get("..", "..", "python-service", "socket_server.py"),
        };
        
        for (Path candidate : candidates) {
            if (Files.exists(candidate)) {
                return candidate.toAbsolutePath().toString();
            }
        }
        
        return "python-service/socket_server.py"; // Default fallback
    }
    
    /**
     * Read actual port from port file (in case server picked different port)
     */
    public int readActualPortFromFile() {
        try {
            File portFile = new File(portFilePath);
            if (portFile.exists()) {
                String content = new String(Files.readAllBytes(portFile.toPath())).trim();
                return Integer.parseInt(content);
            }
        } catch (Exception e) {
            logger.warning("Failed to read port file: " + e.getMessage());
        }
        return port;
    }
    
    /**
     * Update port from file
     */
    public void updatePortFromFile() {
        this.port = readActualPortFromFile();
    }
    
    // ==================== Service Control ====================
    
    /**
     * Start the Python service
     * 
     * @param waitForReady Whether to wait for service to be ready
     * @return true if service started successfully
     */
    public synchronized boolean startService(boolean waitForReady) {
        if (isServiceRunning()) {
            System.out.println("Python service is already running");
            updatePortFromFile();
            return true;
        }
        
        try {
            System.out.println("Starting Python service...");
            System.out.println("  Python: " + pythonExecutable);
            System.out.println("  Script: " + serverScriptPath);
            System.out.println("  Preferred Port: " + port);
            
            // Check if script exists
            if (!Files.exists(Paths.get(serverScriptPath))) {
                System.err.println("Server script not found: " + serverScriptPath);
                return false;
            }
            
            // Build command
            ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                serverScriptPath,
                "foreground",
                "--host", host,
                "--port", String.valueOf(port)
            );
            
            // Redirect output to log file
            Path logDir = Paths.get(serverScriptPath).getParent();
            Path logFile = logDir.resolve("mdf4_server.log");
            pb.redirectOutput(logFile.toFile());
            pb.redirectError(ProcessBuilder.Redirect.INHERIT);
            
            // Start process
            serviceProcess = pb.start();
            
            // Add shutdown hook to stop service
            Runtime.getRuntime().addShutdownHook(new Thread(this::stopServiceSync));
            
            System.out.println("Python service process started (PID: " + serviceProcess.pid() + ")");
            
            // Wait for service to be ready
            if (waitForReady) {
                boolean ready = waitForServiceReady();
                if (ready) {
                    // Update port from file (in case server used different port)
                    updatePortFromFile();
                    System.out.println("Server is listening on port: " + port);
                }
                return ready;
            }
            
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to start Python service: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Start the Python service and wait for it to be ready
     */
    public boolean startService() {
        return startService(true);
    }
    
    /**
     * Stop the Python service (asynchronous)
     * 
     * @return true if service stopped successfully
     */
    public synchronized boolean stopService() {
        return stopServiceInternal(false);
    }
    
    /**
     * Stop the Python service (synchronous - waits for process to exit)
     * 
     * @return true if service stopped successfully
     */
    public synchronized boolean stopServiceSync() {
        return stopServiceInternal(true);
    }
    
    /**
     * Internal stop service method
     */
    private boolean stopServiceInternal(boolean sync) {
        System.out.println("Stopping Python service...");
        boolean stopped = false;
        
        // First try graceful shutdown via socket
        try {
            int actualPort = readActualPortFromFile();
            Socket socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, actualPort), 3000);
            
            // Send shutdown command
            java.io.DataOutputStream out = new java.io.DataOutputStream(socket.getOutputStream());
            String shutdownJson = "{\"cmd\":\"SHUTDOWN\",\"params\":{},\"reqId\":\"999\"}";
            byte[] jsonBytes = shutdownJson.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            out.writeInt(jsonBytes.length);
            out.write(jsonBytes);
            out.flush();
            socket.close();
            
            System.out.println("Sent graceful shutdown command to server");
            stopped = true;
            
            // Wait a bit for graceful shutdown
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Graceful shutdown failed: " + e.getMessage());
        }
        
        // Kill process if still running
        if (serviceProcess != null && serviceProcess.isAlive()) {
            System.out.println("Terminating Python service process...");
            serviceProcess.destroy();
            
            if (sync) {
                try {
                    if (!serviceProcess.waitFor(5, TimeUnit.SECONDS)) {
                        System.out.println("Force killing Python service...");
                        serviceProcess.destroyForcibly();
                        serviceProcess.waitFor(2, TimeUnit.SECONDS);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            stopped = true;
        }
        
        // Also try to stop via Python command
        try {
            ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                serverScriptPath,
                "stop"
            );
            pb.inheritIO();
            Process p = pb.start();
            if (p.waitFor(5, TimeUnit.SECONDS)) {
                stopped = true;
            }
        } catch (Exception e) {
            // Ignore
        }
        
        serviceProcess = null;
        
        if (stopped) {
            System.out.println("Python service stopped");
        }
        return stopped;
    }
    
    /**
     * Restart the Python service
     */
    public boolean restartService() {
        System.out.println("Restarting Python service...");
        stopServiceSync();
        try {
            Thread.sleep(1000); // Wait for port to be released
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return startService();
    }
    
    /**
     * Check if the service is running
     */
    public boolean isServiceRunning() {
        // First try to connect
        try {
            int actualPort = readActualPortFromFile();
            Socket socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, actualPort), CONNECT_TIMEOUT_MS);
            socket.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Wait for service to be ready
     */
    private boolean waitForServiceReady() {
        System.out.println("Waiting for service to be ready...");
        
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < MAX_STARTUP_WAIT_MS) {
            if (isServiceRunning()) {
                System.out.println("Python service is ready");
                return true;
            }
            
            // Check if process died
            if (serviceProcess != null && !serviceProcess.isAlive()) {
                System.err.println("Python service process exited unexpectedly");
                return false;
            }
            
            try {
                Thread.sleep(STARTUP_CHECK_INTERVAL_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        
        System.err.println("Timeout waiting for Python service to start");
        return false;
    }
    
    // ==================== Auto-Restart ====================
    
    /**
     * Enable or disable auto-restart
     */
    public void setAutoRestartEnabled(boolean enabled) {
        this.autoRestartEnabled = enabled;
    }
    
    /**
     * Check if auto-restart is enabled
     */
    public boolean isAutoRestartEnabled() {
        return autoRestartEnabled;
    }
    
    /**
     * Ensure service is running (start if not running)
     * 
     * @return true if service is running or was successfully started
     */
    public boolean ensureServiceRunning() {
        if (isServiceRunning()) {
            return true;
        }
        
        if (autoRestartEnabled) {
            System.out.println("Service not running, attempting to restart...");
            return restartService();
        }
        
        return false;
    }
    
    // ==================== Getters ====================
    
    public String getHost() {
        return host;
    }
    
    public int getPort() {
        updatePortFromFile();
        return port;
    }
    
    public String getPythonExecutable() {
        return pythonExecutable;
    }
    
    public String getServerScriptPath() {
        return serverScriptPath;
    }
    
    // Simple logger
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PythonServiceManager.class.getName());
}
