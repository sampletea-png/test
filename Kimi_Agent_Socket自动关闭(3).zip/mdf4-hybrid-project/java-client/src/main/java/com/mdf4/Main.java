package com.mdf4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Main - Example application demonstrating MDF4 Java client usage.
 * 
 * This example shows how to:
 * 1. Connect to the Python service
 * 2. Create a new MDF4 file
 * 3. Write data to the file
 * 4. Read data from the file (including partial reads)
 * 5. Close the file and disconnect
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("MDF4 Java Client - Example Application");
        System.out.println("========================================\n");
        
        // Create client instance
        Mdf4Client client = new Mdf4Client("localhost", 25333);
        
        try {
            // Step 1: Connect to Python service
            System.out.println("Step 1: Connecting to Python service...");
            client.connect();
            System.out.println("✓ Connected successfully\n");
            
            // Step 2: Create a new MDF4 file
            String filePath = "example_data.mf4";
            System.out.println("Step 2: Creating new MDF4 file: " + filePath);
            if (!client.createNewFile(filePath)) {
                System.err.println("✗ Failed to create file");
                return;
            }
            System.out.println("✓ File created successfully\n");
            
            // Step 3: Write sample data
            System.out.println("Step 3: Writing sample data...");
            writeSampleData(client);
            System.out.println("✓ Data written successfully\n");
            
            // Step 4: Save the file
            System.out.println("Step 4: Saving file...");
            if (!client.saveFile()) {
                System.err.println("✗ Failed to save file");
                return;
            }
            System.out.println("✓ File saved successfully\n");
            
            // Step 5: Close and reopen for reading
            System.out.println("Step 5: Closing and reopening file for reading...");
            client.closeFile();
            if (!client.openFile(filePath)) {
                System.err.println("✗ Failed to open file for reading");
                return;
            }
            System.out.println("✓ File opened successfully\n");
            
            // Step 6: Read and display file information
            System.out.println("Step 6: Reading file information...");
            displayFileInfo(client);
            System.out.println();
            
            // Step 7: Demonstrate full channel read
            System.out.println("Step 7: Reading full channel data...");
            demonstrateFullRead(client);
            System.out.println();
            
            // Step 8: Demonstrate partial read by index
            System.out.println("Step 8: Demonstrating partial read by index...");
            demonstratePartialReadByIndex(client);
            System.out.println();
            
            // Step 9: Demonstrate partial read by time range
            System.out.println("Step 9: Demonstrating partial read by time range...");
            demonstratePartialReadByTime(client);
            System.out.println();
            
            // Step 10: Demonstrate batch read
            System.out.println("Step 10: Demonstrating batch read...");
            demonstrateBatchRead(client);
            System.out.println();
            
            // Cleanup
            System.out.println("Step 11: Cleaning up...");
            client.closeFile();
            System.out.println("✓ File closed\n");
            
            System.out.println("========================================");
            System.out.println("All operations completed successfully!");
            System.out.println("========================================");
            
        } catch (Mdf4Exception e) {
            System.err.println("\n✗ Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Always disconnect
            client.disconnect();
        }
    }
    
    /**
     * Write sample data to the MDF4 file
     */
    private static void writeSampleData(Mdf4Client client) throws Mdf4Exception {
        // Create sample data for EngineSpeed channel
        List<Double> timestamps1 = new ArrayList<>();
        List<Double> values1 = new ArrayList<>();
        
        for (int i = 0; i < 1000; i++) {
            timestamps1.add(i * 0.01);  // 10ms intervals
            values1.add(1000.0 + 500.0 * Math.sin(i * 0.1));  // Sine wave around 1000 RPM
        }
        
        client.addChannel("EngineSpeed", timestamps1, values1, 
                         "RPM", "Engine speed in revolutions per minute", "float");
        System.out.println("  - Written: EngineSpeed (1000 samples)");
        
        // Create sample data for VehicleSpeed channel
        List<Double> timestamps2 = new ArrayList<>();
        List<Double> values2 = new ArrayList<>();
        
        for (int i = 0; i < 1000; i++) {
            timestamps2.add(i * 0.01);
            values2.add(Math.min(120.0, i * 0.12));  // Linear acceleration to 120 km/h
        }
        
        client.addChannel("VehicleSpeed", timestamps2, values2,
                         "km/h", "Vehicle speed", "float");
        System.out.println("  - Written: VehicleSpeed (1000 samples)");
        
        // Create sample data for ThrottlePosition channel
        List<Double> timestamps3 = new ArrayList<>();
        List<Double> values3 = new ArrayList<>();
        
        for (int i = 0; i < 1000; i++) {
            timestamps3.add(i * 0.01);
            values3.add(50.0 + 30.0 * Math.sin(i * 0.05));  // Varying throttle position
        }
        
        client.addChannel("ThrottlePosition", timestamps3, values3,
                         "%", "Throttle pedal position percentage", "float");
        System.out.println("  - Written: ThrottlePosition (1000 samples)");
    }
    
    /**
     * Display file information
     */
    private static void displayFileInfo(Mdf4Client client) throws Mdf4Exception {
        List<String> channelNames = client.getChannelNames();
        System.out.println("  Channels in file: " + channelNames.size());
        
        for (String name : channelNames) {
            ChannelInfo info = client.getChannelInfo(name);
            if (info != null) {
                System.out.println("    - " + info.getName() + 
                    ": " + info.getSamplesCount() + " samples, " +
                    "time range [" + String.format("%.3f", info.getFirstTimestamp()) + 
                    ", " + String.format("%.3f", info.getLastTimestamp()) + "]");
            }
        }
        
        double[] timeRange = client.getTimeRange();
        System.out.println("  Overall time range: [" + 
            String.format("%.3f", timeRange[0]) + ", " + 
            String.format("%.3f", timeRange[1]) + "] seconds");
    }
    
    /**
     * Demonstrate reading full channel data
     */
    private static void demonstrateFullRead(Mdf4Client client) throws Mdf4Exception {
        DataRecord record = client.readChannel("EngineSpeed");
        if (record != null) {
            System.out.println("  Full read - " + record);
            System.out.println("    First 5 values: " + 
                record.getValues().subList(0, Math.min(5, record.getValues().size())));
        }
    }
    
    /**
     * Demonstrate partial read by index range
     */
    private static void demonstratePartialReadByIndex(Mdf4Client client) throws Mdf4Exception {
        // Read samples 100-109 (10 samples)
        DataRecord record = client.readChannelPartial("VehicleSpeed", 100, 10);
        if (record != null) {
            System.out.println("  Partial read (index 100-109) - " + record);
            System.out.println("    Values: " + record.getValues());
            System.out.println("    Timestamps: " + record.getTimestamps());
        }
    }
    
    /**
     * Demonstrate partial read by time range
     */
    private static void demonstratePartialReadByTime(Mdf4Client client) throws Mdf4Exception {
        // Read data between 2.0 and 3.0 seconds
        List<String> channels = Arrays.asList("EngineSpeed", "ThrottlePosition");
        List<DataRecord> records = client.readChannelsPartial(channels, 2.0, 3.0);
        
        System.out.println("  Partial read (time 2.0-3.0s) - " + records.size() + " channels");
        for (DataRecord record : records) {
            System.out.println("    - " + record.getChannelName() + ": " + 
                record.getSampleCount() + " samples");
        }
    }
    
    /**
     * Demonstrate batch read of multiple channels
     */
    private static void demonstrateBatchRead(Mdf4Client client) throws Mdf4Exception {
        List<String> channels = Arrays.asList("EngineSpeed", "VehicleSpeed", "ThrottlePosition");
        List<DataRecord> records = client.readMultipleChannels(channels);
        
        System.out.println("  Batch read - " + records.size() + " channels");
        for (DataRecord record : records) {
            System.out.println("    - " + record.getChannelName() + ": " + 
                record.getSampleCount() + " samples, unit=" + record.getUnit());
        }
    }
}
