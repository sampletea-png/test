# MDF4 Hybrid Project - Java & Python

A hybrid Java and Python project for reading and writing MDF4 (Measurement Data Format version 4) files, with support for partial data reading, automatic service management, and comprehensive metadata storage.

## New Features

### 1. Java端控制Python服务
- Java端可以**启动**、**停止**、**重启**Python服务
- 自动检测服务状态，服务未运行时自动启动
- 服务因超时关闭时，Java端自动重新启动服务

### 2. 自动创建MDF4文件
- 文件不存在时自动创建
- 自动创建父目录
- 支持文件级元数据

### 3. 文件和信号描述信息
- **文件元数据**: 标题、作者、描述、项目、版本、自定义属性
- **通道元数据**: 信号源、传感器类型、校准日期、采样率、量程、自定义属性
- 元数据存储在MDF4文件头中，随文件保存

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              Java Application                            │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Mdf4Client (with Service Management)                            │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │   │
│  │  │  start()    │  │  stop()     │  │  auto-restart on timeout│  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                    │                                    │
│                                    ▼                                    │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    PythonServiceManager                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │   │
│  │  │ startService│  │ stopService │  │  isServiceRunning()     │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                    │                                    │
│                                    ▼                                    │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                        SocketClient                              │   │
│  └─────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ TCP Socket (Port 25333)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                           Python Service                                 │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                     socket_server.py                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │   │
│  │  │  start      │  │  stop       │  │  status (PID file)      │  │   │
│  │  │  foreground │  │             │  │  handshake timeout: 30s │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                    │                                    │
│                                    ▼                                    │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      mdf4_handler.py                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │   │
│  │  │ FileMetadata│  │ ChannelMetadata│  │ Auto-create file      │  │   │
│  │  │ read/write  │  │ read/write     │  │ Auto-create dirs      │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                              MDF4 File (.mf4)
```

## Project Structure

```
mdf4-hybrid-project/
├── python-service/
│   ├── socket_server.py         # Socket服务器 (支持start/stop/status/foreground)
│   ├── mdf4_handler.py          # MDF4核心处理 (支持元数据)
│   ├── test_server.py           # 测试脚本
│   ├── requirements.txt         # Python依赖
│   ├── start_service.sh         # Linux/Mac启动脚本
│   └── start_service.bat        # Windows启动脚本
├── java-client/
│   ├── pom.xml                  # Maven配置 (Jackson)
│   └── src/main/java/com/mdf4/
│       ├── PythonServiceManager.java  # Python服务管理器 (NEW)
│       ├── SocketClient.java          # Socket客户端 (支持自动重连)
│       ├── Mdf4Client.java            # 主API客户端
│       ├── FileMetadata.java          # 文件元数据 (NEW)
│       ├── ChannelMetadata.java       # 通道元数据 (NEW)
│       ├── DataRecord.java            # 数据记录
│       ├── ChannelInfo.java           # 通道信息
│       ├── ChannelData.java           # 写入数据
│       └── Mdf4Exception.java         # 自定义异常
├── README.md                    # 本文档
├── QUICKSTART.md               # 快速入门
├── ARCHITECTURE.md             # 架构文档
└── protocol.md                 # 通信协议
```

## Prerequisites

- Python 3.10+
- Java 11+
- Maven 3.6+

## Installation

```bash
# 1. 安装Python依赖
cd python-service
pip install -r requirements.txt

# 2. 构建Java项目
cd ../java-client
mvn clean package
```

## Usage

### 方式1: Java自动管理服务（推荐）

```java
// Java会自动启动Python服务
Mdf4Client client = new Mdf4Client();
client.connect();  // 如果服务未运行，会自动启动

// 使用客户端...
client.createNewFile("data.mf4");

// 关闭时自动停止服务
client.close();
```

### 方式2: 手动管理Python服务

**启动服务:**
```bash
cd python-service
python socket_server.py foreground  # 前台运行
# 或
python socket_server.py start       # 后台运行 (Linux/Mac)
```

**检查状态:**
```bash
python socket_server.py status
```

**停止服务:**
```bash
python socket_server.py stop
```

### 创建带元数据的MDF4文件

```java
Mdf4Client client = new Mdf4Client();
client.connect();

// 创建文件元数据
FileMetadata fileMeta = FileMetadata.builder()
    .title("Vehicle Test Data")
    .author("Test Engineer")
    .description("Engine performance test data")
    .project("Project Alpha")
    .version("1.0")
    .customProperty("testId", "TEST-001")
    .customProperty("location", "Test Track A")
    .build();

// 创建文件（如果不存在会自动创建）
client.createNewFile("test_data.mf4", fileMeta, true);

// 创建通道元数据
ChannelMetadata channelMeta = ChannelMetadata.builder()
    .source("ECU")
    .sensorType("RPM Sensor")
    .calibrationDate("2024-01-15")
    .samplingRate(100.0)
    .minValue(0)
    .maxValue(8000)
    .customProperty("location", "Engine Block")
    .build();

// 添加通道
List<Double> timestamps = Arrays.asList(0.0, 0.1, 0.2, 0.3);
List<Double> values = Arrays.asList(1000.0, 1500.0, 2000.0, 1800.0);

client.addChannel("EngineSpeed", timestamps, values, 
                  "RPM", "Engine speed", "float", channelMeta);

// 保存文件
client.saveFile();

// 读取文件元数据
FileMetadata loadedMeta = client.getFileMetadata();
System.out.println("Title: " + loadedMeta.getTitle());
System.out.println("Author: " + loadedMeta.getAuthor());

// 读取通道元数据
ChannelMetadata loadedChannelMeta = client.getChannelMetadata("EngineSpeed");
System.out.println("Source: " + loadedChannelMeta.getSource());
System.out.println("Sampling Rate: " + loadedChannelMeta.getSamplingRate());

client.close();
```

### 自动创建文件（如果不存在）

```java
// 如果文件不存在，会自动创建
client.openFile("data.mf4", false, true);  // readOnly=false, autoCreate=true

// 或者带元数据创建
FileMetadata meta = FileMetadata.builder()
    .title("Auto-created File")
    .author("System")
    .build();

client.openFile("data.mf4", false, true, meta);
```

### 服务自动重启

```java
Mdf4Client client = new Mdf4Client();

// 如果服务因超时关闭，会自动重启
client.connect();

// 长时间操作后检查连接
if (!client.isServiceRunning()) {
    // 会自动尝试重启
    client.connect();
}
```

## Python服务端命令

```bash
# 前台运行（调试使用）
python socket_server.py foreground

# 后台运行（Linux/Mac）
python socket_server.py start

# 停止服务
python socket_server.py stop

# 检查状态
python socket_server.py status

# 指定主机和端口
python socket_server.py foreground --host 0.0.0.0 --port 25333
```

## API Reference

### File Operations

| Method | Description |
|--------|-------------|
| `createNewFile(path)` | Create new MDF4 file |
| `createNewFile(path, metadata)` | Create with metadata |
| `createNewFile(path, metadata, autoCreateDirs)` | Create with options |
| `openFile(path)` | Open existing file |
| `openFile(path, readOnly, autoCreate)` | Open with auto-create |
| `openFile(path, readOnly, autoCreate, metadata)` | Open with metadata |
| `closeFile()` | Close current file |
| `saveFile()` | Save file |

### Metadata Operations

| Method | Description |
|--------|-------------|
| `setFileMetadata(metadata)` | Set file metadata |
| `getFileMetadata()` | Get file metadata |
| `setChannelMetadata(name, metadata)` | Set channel metadata |
| `getChannelMetadata(name)` | Get channel metadata |

### Service Management

| Method | Description |
|--------|-------------|
| `connect()` | Connect (auto-start service) |
| `disconnect()` | Disconnect |
| `stopService()` | Stop Python service |
| `isServiceRunning()` | Check service status |
| `isConnected()` | Check connection |

## FileMetadata Fields

| Field | Type | Description |
|-------|------|-------------|
| `title` | String | File title |
| `author` | String | Author name |
| `description` | String | File description |
| `project` | String | Project name |
| `version` | String | File version |
| `createdAt` | String | Creation time (auto) |
| `modifiedAt` | String | Modification time (auto) |
| `customProperties` | Map | Custom key-value pairs |

## ChannelMetadata Fields

| Field | Type | Description |
|-------|------|-------------|
| `source` | String | Data source (e.g., "ECU") |
| `sensorType` | String | Sensor type |
| `calibrationDate` | String | Calibration date |
| `samplingRate` | Double | Sampling rate in Hz |
| `minValue` | Double | Minimum expected value |
| `maxValue` | Double | Maximum expected value |
| `customProperties` | Map | Custom key-value pairs |

## Handshake Timeout

Python服务端设置30秒握手超时：
- 客户端连接后必须在30秒内发送握手消息
- 超时后服务端自动关闭连接
- Java端检测到连接断开会自动尝试重启服务

## Troubleshooting

### 服务启动失败
```bash
# 检查Python依赖
pip install -r requirements.txt

# 手动启动查看错误
python socket_server.py foreground
```

### 端口被占用
```bash
# 查找占用端口的进程
lsof -i :25333  # Linux/Mac
netstat -ano | findstr :25333  # Windows

# 使用不同端口
python socket_server.py foreground --port 25334
```

### Java连接失败
```java
// 检查服务状态
if (!client.isServiceRunning()) {
    // 尝试重启
    client.connect();  // 会自动启动服务
}
```

## License

This project is provided as-is for educational and development purposes.
