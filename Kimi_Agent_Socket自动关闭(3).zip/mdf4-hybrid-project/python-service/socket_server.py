#!/usr/bin/env python3
"""
MDF4 Socket Server
Custom socket-based server for Java-Python communication.
Features:
- Length-prefixed JSON message protocol
- Handshake with timeout (auto-close if no handshake)
- Thread-per-client model
- PID file management for service control
- Enhanced MDF4 metadata support (JSON in comment)
- Auto port selection if default port is in use
- Idle timeout (3 minutes) - auto shutdown when no clients
"""

import socket
import struct
import json
import threading
import logging
import time
import os
import sys
import signal
import atexit
from typing import Dict, Any, Optional, Callable, Tuple
from datetime import datetime
from mdf4_handler import Mdf4Handler, get_handler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants
DEFAULT_HOST = '0.0.0.0'
DEFAULT_PORT = 25333
PID_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdf4_server.pid')
PORT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdf4_server.port')
HANDSHAKE_TIMEOUT = 30  # seconds
IDLE_TIMEOUT = 180  # 3 minutes in seconds
MAX_PORT_ATTEMPTS = 10


class MessageProtocol:
    """Message protocol handler for length-prefixed JSON messages"""
    
    @staticmethod
    def encode_message(data: Dict[str, Any]) -> bytes:
        """Encode a dictionary to length-prefixed JSON bytes"""
        json_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
        length_prefix = struct.pack('>I', len(json_bytes))
        return length_prefix + json_bytes
    
    @staticmethod
    def decode_message(data: bytes) -> Dict[str, Any]:
        """Decode length-prefixed JSON bytes to dictionary"""
        return json.loads(data.decode('utf-8'))
    
    @staticmethod
    def read_message(sock: socket.socket) -> Optional[Dict[str, Any]]:
        """Read a complete message from socket"""
        try:
            # Read length prefix (4 bytes)
            length_bytes = sock.recv(4)
            if len(length_bytes) < 4:
                return None
            
            message_length = struct.unpack('>I', length_bytes)[0]
            
            # For large messages, read in chunks to avoid memory issues
            MAX_CHUNK_SIZE = 1024 * 1024  # 1MB chunks
            message_bytes = b''
            remaining = message_length
            
            while remaining > 0:
                chunk_size = min(remaining, MAX_CHUNK_SIZE)
                chunk = sock.recv(chunk_size)
                if not chunk:
                    return None
                message_bytes += chunk
                remaining -= len(chunk)
            
            return MessageProtocol.decode_message(message_bytes)
        except (socket.timeout, ConnectionResetError, BrokenPipeError):
            return None
        except Exception as e:
            logger.error(f"Error reading message: {e}")
            return None
    
    @staticmethod
    def send_message(sock: socket.socket, data: Dict[str, Any]) -> bool:
        """Send a message to socket"""
        try:
            message_bytes = MessageProtocol.encode_message(data)
            
            # Send in chunks for large messages
            MAX_CHUNK_SIZE = 1024 * 1024  # 1MB chunks
            sock.sendall(struct.pack('>I', len(message_bytes)))
            
            for i in range(0, len(message_bytes), MAX_CHUNK_SIZE):
                chunk = message_bytes[i:i + MAX_CHUNK_SIZE]
                sock.sendall(chunk)
            
            return True
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            return False


class Mdf4SocketHandler:
    """Handler for MDF4 operations via socket"""
    
    def __init__(self):
        self._handler = get_handler()
        self._commands: Dict[str, Callable] = {
            # Service operations
            'PING': self._cmd_ping,
            'HANDSHAKE': self._cmd_handshake,
            'SHUTDOWN': self._cmd_shutdown,
            # File operations
            'createNewFile': self._cmd_create_new_file,
            'openFile': self._cmd_open_file,
            'closeFile': self._cmd_close_file,
            'saveFile': self._cmd_save_file,
            'setFileMetadata': self._cmd_set_file_metadata,
            'getFileMetadata': self._cmd_get_file_metadata,
            # Write operations
            'addChannel': self._cmd_add_channel,
            'writeMultipleChannels': self._cmd_write_multiple_channels,
            'setChannelMetadata': self._cmd_set_channel_metadata,
            # Read operations
            'getChannelNames': self._cmd_get_channel_names,
            'getChannelInfo': self._cmd_get_channel_info,
            'getChannelMetadata': self._cmd_get_channel_metadata,
            'readChannel': self._cmd_read_channel,
            'readMultipleChannels': self._cmd_read_multiple_channels,
            'readChannelPartial': self._cmd_read_channel_partial,
            'readChannelsPartial': self._cmd_read_channels_partial,
            'getSampleCount': self._cmd_get_sample_count,
            'getTimeRange': self._cmd_get_time_range,
            # Utility operations
            'filterChannels': self._cmd_filter_channels,
            'cutTimeRange': self._cmd_cut_time_range,
        }
    
    def handle_command(self, cmd: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle a command and return result"""
        handler = self._commands.get(cmd)
        if handler is None:
            return {'error': f'Unknown command: {cmd}'}
        
        try:
            return handler(params)
        except Exception as e:
            logger.error(f"Error executing command {cmd}: {e}")
            return {'error': str(e)}
    
    def _cmd_ping(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Ping command for health check"""
        return {'status': 'ok', 'timestamp': datetime.now().isoformat()}
    
    def _cmd_handshake(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handshake command"""
        return {'version': '1.0', 'status': 'ready', 'server_time': datetime.now().isoformat()}
    
    def _cmd_shutdown(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Shutdown command from Java client"""
        logger.info("Received shutdown command from client")
        return {'success': True, 'message': 'Server shutting down'}
    
    # ==================== File Operations ====================
    
    def _cmd_create_new_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        file_path = params.get('filePath')
        auto_create_dirs = params.get('autoCreateDirs', True)
        
        # Auto-create parent directories if needed
        if auto_create_dirs and file_path:
            parent_dir = os.path.dirname(file_path)
            if parent_dir and not os.path.exists(parent_dir):
                os.makedirs(parent_dir, exist_ok=True)
                logger.info(f"Created directory: {parent_dir}")
        
        success = self._handler.create_new_file(file_path)
        
        # Set initial file metadata if provided
        if success and 'metadata' in params:
            self._handler.set_file_metadata(params['metadata'])
        
        return {'success': success, 'filePath': file_path}
    
    def _cmd_open_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        file_path = params.get('filePath')
        read_only = params.get('readOnly', True)
        auto_create = params.get('autoCreate', False)
        
        # Check if file exists
        file_exists = os.path.exists(file_path) if file_path else False
        
        if not file_exists and auto_create and file_path:
            # Auto-create the file
            parent_dir = os.path.dirname(file_path)
            if parent_dir and not os.path.exists(parent_dir):
                os.makedirs(parent_dir, exist_ok=True)
            
            success = self._handler.create_new_file(file_path)
            if success and 'metadata' in params:
                self._handler.set_file_metadata(params['metadata'])
            return {'success': success, 'filePath': file_path, 'created': True}
        
        success = self._handler.open_file(file_path, read_only)
        return {'success': success, 'filePath': file_path, 'created': False}
    
    def _cmd_close_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        success = self._handler.close_file()
        return {'success': success}
    
    def _cmd_save_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        file_path = params.get('filePath')
        compression = params.get('compression', 0)
        success = self._handler.save_file(file_path, compression)
        return {'success': success}
    
    def _cmd_set_file_metadata(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Set file-level metadata (stored as JSON string in comment)"""
        metadata = params.get('metadata', {})
        success = self._handler.set_file_metadata(metadata)
        return {'success': success}
    
    def _cmd_get_file_metadata(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get file-level metadata (parsed from JSON string in comment)"""
        metadata = self._handler.get_file_metadata()
        return {'metadata': metadata}
    
    # ==================== Write Operations ====================
    
    def _cmd_add_channel(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_name = params.get('channelName')
        timestamps = params.get('timestamps', [])
        values = params.get('values', [])
        unit = params.get('unit', '')
        comment = params.get('comment', '')
        data_type = params.get('dataType', 'float')
        metadata = params.get('metadata', {})  # Channel-specific metadata
        
        success = self._handler.add_channel(channel_name, timestamps, values, 
                                           unit, comment, data_type, metadata)
        return {'success': success}
    
    def _cmd_write_multiple_channels(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channels = params.get('channels', [])
        success = self._handler.write_multiple_channels(channels)
        return {'success': success}
    
    def _cmd_set_channel_metadata(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Set metadata for a specific channel (stored as JSON string in comment)"""
        channel_name = params.get('channelName')
        metadata = params.get('metadata', {})
        success = self._handler.set_channel_metadata(channel_name, metadata)
        return {'success': success}
    
    # ==================== Read Operations ====================
    
    def _cmd_get_channel_names(self, params: Dict[str, Any]) -> Dict[str, Any]:
        names = self._handler.get_channel_names()
        return {'names': list(names)}
    
    def _cmd_get_channel_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_name = params.get('channelName')
        info = self._handler.get_channel_info(channel_name)
        return {'info': info}
    
    def _cmd_get_channel_metadata(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get metadata for a specific channel (parsed from JSON string in comment)"""
        channel_name = params.get('channelName')
        metadata = self._handler.get_channel_metadata(channel_name)
        return {'metadata': metadata}
    
    def _cmd_read_channel(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_name = params.get('channelName')
        record = self._handler.read_channel(channel_name)
        if record is None:
            return {'error': 'Channel not found'}
        return {'record': {
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }}
    
    def _cmd_read_multiple_channels(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_names = params.get('channelNames', [])
        records = self._handler.read_multiple_channels(channel_names)
        return {'records': [{
            'channelName': r.channel_name,
            'timestamps': r.timestamps,
            'values': r.values,
            'unit': r.unit
        } for r in records]}
    
    def _cmd_read_channel_partial(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_name = params.get('channelName')
        start_index = params.get('startIndex', 0)
        count = params.get('count', 0)
        record = self._handler.read_channel_partial(channel_name, start_index, count)
        if record is None:
            return {'error': 'Channel not found'}
        return {'record': {
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }}
    
    def _cmd_read_channels_partial(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_names = params.get('channelNames', [])
        start_time = params.get('startTime', 0.0)
        end_time = params.get('endTime', 0.0)
        records = self._handler.read_channels_partial(channel_names, start_time, end_time)
        return {'records': [{
            'channelName': r.channel_name,
            'timestamps': r.timestamps,
            'values': r.values,
            'unit': r.unit
        } for r in records]}
    
    def _cmd_get_sample_count(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_name = params.get('channelName')
        count = self._handler.get_sample_count(channel_name)
        return {'count': count}
    
    def _cmd_get_time_range(self, params: Dict[str, Any]) -> Dict[str, Any]:
        range_tuple = self._handler.get_time_range()
        return {'range': list(range_tuple)}
    
    # ==================== Utility Operations ====================
    
    def _cmd_filter_channels(self, params: Dict[str, Any]) -> Dict[str, Any]:
        channel_names = params.get('channelNames', [])
        success = self._handler.filter_channels(channel_names)
        return {'success': success}
    
    def _cmd_cut_time_range(self, params: Dict[str, Any]) -> Dict[str, Any]:
        start_time = params.get('startTime', 0.0)
        end_time = params.get('endTime', 0.0)
        success = self._handler.cut_time_range(start_time, end_time)
        return {'success': success}


class ClientHandler(threading.Thread):
    """Handler for individual client connections"""
    
    def __init__(self, client_socket: socket.socket, address: tuple, server: 'Mdf4SocketServer'):
        super().__init__(daemon=True)
        self._socket = client_socket
        self._address = address
        self._server = server
        self._mdf_handler = Mdf4SocketHandler()
        self._connected = False
        self._handshake_received = False
        self._last_activity = time.time()
        
    def run(self):
        """Main client handling loop"""
        logger.info(f"Client connected from {self._address}")
        self._server.update_last_activity()
        
        try:
            # Set handshake timeout
            self._socket.settimeout(HANDSHAKE_TIMEOUT)
            
            # Wait for handshake
            if not self._wait_for_handshake():
                logger.warning(f"Handshake timeout for {self._address}, closing connection")
                return
            
            # Handshake successful, set normal timeout
            self._socket.settimeout(60)
            self._connected = True
            
            # Main message loop
            while self._connected and self._server.is_running():
                message = MessageProtocol.read_message(self._socket)
                
                if message is None:
                    logger.info(f"Client {self._address} disconnected")
                    break
                
                self._last_activity = time.time()
                self._server.update_last_activity()
                
                # Check for shutdown command
                if message.get('cmd') == 'SHUTDOWN':
                    logger.info("Shutdown command received, stopping server...")
                    self._handle_message(message)
                    self._server.stop()
                    break
                
                self._handle_message(message)
                
        except socket.timeout:
            if not self._handshake_received:
                logger.warning(f"Handshake timeout for {self._address}")
            else:
                logger.info(f"Read timeout for {self._address}")
        except Exception as e:
            logger.error(f"Error handling client {self._address}: {e}")
        finally:
            self._cleanup()
    
    def _wait_for_handshake(self) -> bool:
        """Wait for handshake message with timeout"""
        try:
            message = MessageProtocol.read_message(self._socket)
            
            if message is None:
                return False
            
            cmd = message.get('cmd')
            
            if cmd == 'HANDSHAKE':
                self._handshake_received = True
                # Send handshake response
                response = {
                    'success': True,
                    'data': {'version': '1.0', 'status': 'ready'},
                    'reqId': message.get('reqId', '0')
                }
                MessageProtocol.send_message(self._socket, response)
                logger.info(f"Handshake successful with {self._address}")
                return True
            else:
                # First message was not handshake
                response = {
                    'success': False,
                    'error': 'Expected HANDSHAKE command',
                    'reqId': message.get('reqId', '0')
                }
                MessageProtocol.send_message(self._socket, response)
                return False
                
        except socket.timeout:
            logger.warning(f"Handshake timeout after {HANDSHAKE_TIMEOUT} seconds")
            return False
    
    def _handle_message(self, message: Dict[str, Any]):
        """Handle a single message"""
        cmd = message.get('cmd', '')
        params = message.get('params', {})
        req_id = message.get('reqId', '0')
        
        logger.debug(f"Received command: {cmd} from {self._address}")
        
        # Execute command
        result = self._mdf_handler.handle_command(cmd, params)
        
        # Build response
        if 'error' in result:
            response = {
                'success': False,
                'error': result['error'],
                'reqId': req_id
            }
        else:
            response = {
                'success': True,
                'data': result,
                'reqId': req_id
            }
        
        # Send response
        if not MessageProtocol.send_message(self._socket, response):
            logger.error(f"Failed to send response to {self._address}")
            self._connected = False
    
    def _cleanup(self):
        """Clean up resources"""
        try:
            self._socket.close()
        except:
            pass
        self._server.remove_client(self)
        logger.info(f"Client handler for {self._address} cleaned up")


class Mdf4SocketServer:
    """MDF4 Socket Server - Main server class"""
    
    def __init__(self, host: str = DEFAULT_HOST, preferred_port: int = DEFAULT_PORT):
        self._host = host
        self._preferred_port = preferred_port
        self._actual_port: Optional[int] = None
        self._server_socket: Optional[socket.socket] = None
        self._running = False
        self._clients: list = []
        self._lock = threading.Lock()
        self._start_time: Optional[datetime] = None
        self._last_activity_time = time.time()
        self._idle_check_thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()
        
    def find_available_port(self, start_port: int, max_attempts: int = MAX_PORT_ATTEMPTS) -> int:
        """Find an available port starting from start_port"""
        for port in range(start_port, start_port + max_attempts):
            try:
                test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                test_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                test_socket.bind((self._host, port))
                test_socket.close()
                logger.info(f"Found available port: {port}")
                return port
            except OSError:
                logger.debug(f"Port {port} is in use, trying next...")
                continue
        
        raise RuntimeError(f"Could not find available port in range {start_port}-{start_port + max_attempts}")
    
    def start(self):
        """Start the server"""
        try:
            # Find available port
            self._actual_port = self.find_available_port(self._preferred_port)
            
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind((self._host, self._actual_port))
            self._server_socket.listen(5)
            
            self._running = True
            self._start_time = datetime.now()
            self._last_activity_time = time.time()
            
            # Write PID and port files
            self._write_pid_file()
            self._write_port_file()
            
            # Start idle check thread
            self._idle_check_thread = threading.Thread(target=self._idle_check_loop, daemon=True)
            self._idle_check_thread.start()
            
            logger.info(f"MDF4 Socket Server started on {self._host}:{self._actual_port}")
            logger.info(f"Preferred port was {self._preferred_port}, using port {self._actual_port}")
            logger.info(f"Handshake timeout: {HANDSHAKE_TIMEOUT} seconds")
            logger.info(f"Idle timeout: {IDLE_TIMEOUT} seconds")
            logger.info(f"PID: {os.getpid()}")
            logger.info("Waiting for connections...")
            
            while self._running:
                try:
                    self._server_socket.settimeout(1.0)
                    client_socket, address = self._server_socket.accept()
                    
                    # Create and start client handler
                    handler = ClientHandler(client_socket, address, self)
                    with self._lock:
                        self._clients.append(handler)
                    handler.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self._running:
                        logger.error(f"Error accepting connection: {e}")
                    
        except Exception as e:
            logger.error(f"Server error: {e}")
        finally:
            self.stop()
    
    def stop(self):
        """Stop the server"""
        if not self._running:
            return
            
        logger.info("Stopping server...")
        self._running = False
        self._shutdown_event.set()
        
        # Close all client connections
        with self._lock:
            for client in self._clients:
                try:
                    client._connected = False
                    client._socket.close()
                except:
                    pass
            self._clients.clear()
        
        # Close server socket
        if self._server_socket:
            try:
                self._server_socket.close()
            except:
                pass
        
        # Remove PID and port files
        self._remove_pid_file()
        self._remove_port_file()
        
        logger.info("Server stopped")
    
    def _idle_check_loop(self):
        """Check for idle timeout and shutdown if no activity"""
        while not self._shutdown_event.is_set():
            try:
                self._shutdown_event.wait(10)  # Check every 10 seconds
                
                if not self._running:
                    break
                
                idle_time = time.time() - self._last_activity_time
                if idle_time > IDLE_TIMEOUT:
                    logger.info(f"Server idle for {idle_time:.0f} seconds, shutting down...")
                    self.stop()
                    break
                    
            except Exception as e:
                logger.error(f"Error in idle check loop: {e}")
    
    def update_last_activity(self):
        """Update last activity timestamp"""
        self._last_activity_time = time.time()
    
    def is_running(self) -> bool:
        """Check if server is running"""
        return self._running
    
    def get_port(self) -> int:
        """Get the actual port the server is listening on"""
        return self._actual_port if self._actual_port else self._preferred_port
    
    def get_stats(self) -> Dict[str, Any]:
        """Get server statistics"""
        with self._lock:
            return {
                'running': self._running,
                'port': self._actual_port,
                'start_time': self._start_time.isoformat() if self._start_time else None,
                'active_connections': len(self._clients),
                'pid': os.getpid()
            }
    
    def remove_client(self, client: ClientHandler):
        """Remove a client from the list"""
        with self._lock:
            if client in self._clients:
                self._clients.remove(client)
    
    def _write_pid_file(self):
        """Write PID to file"""
        try:
            with open(PID_FILE, 'w') as f:
                f.write(str(os.getpid()))
            logger.info(f"PID file written: {PID_FILE}")
        except Exception as e:
            logger.warning(f"Failed to write PID file: {e}")
    
    def _remove_pid_file(self):
        """Remove PID file"""
        try:
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)
                logger.info(f"PID file removed: {PID_FILE}")
        except Exception as e:
            logger.warning(f"Failed to remove PID file: {e}")
    
    def _write_port_file(self):
        """Write port to file"""
        try:
            with open(PORT_FILE, 'w') as f:
                f.write(str(self._actual_port))
            logger.info(f"Port file written: {PORT_FILE} (port={self._actual_port})")
        except Exception as e:
            logger.warning(f"Failed to write port file: {e}")
    
    def _remove_port_file(self):
        """Remove port file"""
        try:
            if os.path.exists(PORT_FILE):
                os.remove(PORT_FILE)
                logger.info(f"Port file removed: {PORT_FILE}")
        except Exception as e:
            logger.warning(f"Failed to remove port file: {e}")


# ==================== Service Management Functions ====================

def get_server_pid() -> Optional[int]:
    """Get server PID from PID file"""
    try:
        if os.path.exists(PID_FILE):
            with open(PID_FILE, 'r') as f:
                return int(f.read().strip())
    except Exception as e:
        logger.warning(f"Failed to read PID file: {e}")
    return None


def get_server_port() -> int:
    """Get server port from port file"""
    try:
        if os.path.exists(PORT_FILE):
            with open(PORT_FILE, 'r') as f:
                return int(f.read().strip())
    except Exception as e:
        logger.warning(f"Failed to read port file: {e}")
    return DEFAULT_PORT


def is_server_running(host: str = DEFAULT_HOST, port: int = None) -> bool:
    """Check if server is running"""
    if port is None:
        port = get_server_port()
    
    # First try to connect
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((host, port))
        
        # Try to ping
        ping_msg = MessageProtocol.encode_message({'cmd': 'PING', 'params': {}, 'reqId': '0'})
        sock.sendall(ping_msg)
        
        # Read response
        length_bytes = sock.recv(4)
        if len(length_bytes) == 4:
            msg_len = struct.unpack('>I', length_bytes)[0]
            response_bytes = sock.recv(msg_len)
            response = json.loads(response_bytes.decode('utf-8'))
            sock.close()
            return response.get('success', False)
        
        sock.close()
        return True
    except Exception:
        return False


def stop_server():
    """Stop the running server"""
    port = get_server_port()
    pid = get_server_pid()
    
    # First try graceful shutdown via socket
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        sock.connect(('localhost', port))
        
        shutdown_msg = MessageProtocol.encode_message({
            'cmd': 'SHUTDOWN', 
            'params': {}, 
            'reqId': '999'
        })
        sock.sendall(shutdown_msg)
        sock.close()
        
        # Wait for server to stop
        time.sleep(1)
        
        if not is_server_running(port=port):
            print("Server stopped gracefully")
            return True
    except Exception as e:
        logger.debug(f"Graceful shutdown failed: {e}")
    
    # Fall back to killing process
    if pid is not None:
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"Sent termination signal to server (PID: {pid})")
            
            # Wait for server to stop
            for i in range(10):
                time.sleep(0.5)
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    print("Server stopped successfully")
                    return True
            
            # Force kill if still running
            try:
                os.kill(pid, signal.SIGKILL)
                print("Force killed server")
            except ProcessLookupError:
                pass
            
            return True
        except ProcessLookupError:
            print("Server is not running")
            return True
        except Exception as e:
            print(f"Error stopping server: {e}")
            return False
    
    print("No server to stop")
    return True


def start_server_daemon(preferred_port: int = DEFAULT_PORT):
    """Start server as daemon process"""
    if is_server_running(port=preferred_port):
        print("Server is already running")
        return True, get_server_port()
    
    try:
        # Fork to background
        pid = os.fork()
        if pid > 0:
            # Parent process - wait for server to start
            time.sleep(2)
            
            # Read actual port from file
            actual_port = get_server_port()
            
            if is_server_running(port=actual_port):
                print(f"Server started successfully on port {actual_port}")
                return True, actual_port
            else:
                print("Failed to start server")
                return False, preferred_port
        
        # Child process
        os.setsid()  # Create new session
        os.umask(0)
        
        # Redirect stdout/stderr to log file
        log_file = os.path.join(os.path.dirname(PID_FILE), 'mdf4_server.log')
        sys.stdout = open(log_file, 'a')
        sys.stderr = sys.stdout
        
        server = Mdf4SocketServer(port=preferred_port)
        server.start()
        
    except OSError as e:
        print(f"Fork failed: {e}")
        return False, preferred_port


def main():
    """Main entry point with command line argument handling"""
    import argparse
    
    parser = argparse.ArgumentParser(description='MDF4 Socket Server')
    parser.add_argument('action', choices=['start', 'stop', 'status', 'foreground'], 
                       default='foreground', nargs='?',
                       help='Action to perform (default: foreground)')
    parser.add_argument('--host', default=DEFAULT_HOST, help='Host to bind to')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help='Preferred port to bind to')
    
    args = parser.parse_args()
    
    if args.action == 'start':
        if is_server_running(port=args.port):
            actual_port = get_server_port()
            print(f"Server is already running on port {actual_port}")
            sys.exit(0)
        
        # Start in background
        if sys.platform != 'win32':
            success, port = start_server_daemon(args.port)
            sys.exit(0 if success else 1)
        else:
            print("Background mode not supported on Windows, use 'foreground'")
            sys.exit(1)
            
    elif args.action == 'stop':
        if stop_server():
            sys.exit(0)
        else:
            sys.exit(1)
            
    elif args.action == 'status':
        port = get_server_port()
        if is_server_running(port=port):
            pid = get_server_pid()
            print(f"Server is running on port {port} (PID: {pid})")
            sys.exit(0)
        else:
            print("Server is not running")
            sys.exit(1)
            
    elif args.action == 'foreground':
        # Run in foreground
        port = get_server_port()
        if is_server_running(port=port):
            print(f"Server is already running on port {port}")
            print("Stop it first or use 'status' to check")
            sys.exit(1)
        
        server = Mdf4SocketServer(args.host, args.port)
        
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}")
            server.stop()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        try:
            server.start()
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt")
        finally:
            server.stop()


if __name__ == "__main__":
    main()
