@echo off
chcp 65001 >nul
echo ========================================
echo MDFLib 项目构建脚本 (Windows)
echo ========================================
echo.

REM 检查Maven是否安装
where mvn >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到 Maven。请确保 Maven 已安装并添加到 PATH。
    echo 下载地址: https://maven.apache.org/download.cgi
    exit /b 1
)

echo 正在清理并构建项目...
mvn clean package

if %errorlevel% neq 0 (
    echo.
    echo 错误: 构建失败！
    exit /b 1
)

echo.
echo ========================================
echo 构建成功！
echo ========================================
echo 可执行JAR文件位置:
echo   target\mdflib-project-1.0.0.jar
echo.
echo 使用方法:
echo   run.bat ^<mdf文件路径^>
echo.

pause
