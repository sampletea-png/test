#!/bin/bash

echo "========================================"
echo "MDFLib 项目构建脚本 (Linux)"
echo "========================================"
echo ""

# 检查Maven是否安装
if ! command -v mvn &> /dev/null; then
    echo "错误: 未找到 Maven。请确保 Maven 已安装并添加到 PATH。"
    echo "安装方法:"
    echo "  Ubuntu/Debian: sudo apt-get install maven"
    echo "  CentOS/RHEL:   sudo yum install maven"
    echo "  或手动下载:   https://maven.apache.org/download.cgi"
    exit 1
fi

echo "正在清理并构建项目..."
mvn clean package

if [ $? -ne 0 ]; then
    echo ""
    echo "错误: 构建失败！"
    exit 1
fi

echo ""
echo "========================================"
echo "构建成功！"
echo "========================================"
echo "可执行JAR文件位置:"
echo "  target/mdflib-project-1.0.0.jar"
echo ""
echo "使用方法:"
echo "  ./run.sh <mdf文件路径>"
echo "  或"
echo "  java -jar target/mdflib-project-1.0.0.jar <mdf文件路径>"
echo ""
