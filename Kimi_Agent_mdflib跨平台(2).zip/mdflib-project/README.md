# MDFLib Java 项目

使用 **mdf4j** 库读取 ASAM MDF4 格式文件的跨平台 Java 项目。

## 特性

- **纯Java实现**: 使用 mdf4j 库（纯Java，无本地依赖）
- **跨平台**: 支持 Windows 和 Linux
- **零配置**: 构建后只需 JDK 21，无需其他环境配置
- **单文件部署**: 使用 Maven Shade Plugin 打包所有依赖到一个可执行 JAR

## 环境要求

- **JDK 21** 或更高版本
- **Maven 3.8+**（仅构建时需要）

## 项目结构

```
mdflib-project/
├── pom.xml                          # Maven 配置文件
├── README.md                        # 项目说明文档
├── build.bat                        # Windows 构建脚本
├── build.sh                         # Linux 构建脚本
├── run.bat                          # Windows 运行脚本
├── run.sh                           # Linux 运行脚本
└── src/
    ├── main/
    │   └── java/com/example/mdflib/
    │       └── MdfReaderApp.java    # 主应用程序
    └── test/
        └── java/com/example/mdflib/
            └── MdfReaderAppTest.java # 单元测试
```

## 快速开始

### 1. 构建项目

**Windows:**
```cmd
build.bat
```

**Linux:**
```bash
chmod +x build.sh
./build.sh
```

或者使用 Maven 直接构建：
```bash
mvn clean package
```

构建完成后，可执行 JAR 文件位于：
```
target/mdflib-project-1.0.0.jar
```

### 2. 运行程序

**Windows:**
```cmd
run.bat <mdf文件路径>
```

**Linux:**
```bash
chmod +x run.sh
./run.sh <mdf文件路径>
```

或者直接使用 Java 运行：
```bash
java -jar target/mdflib-project-1.0.0.jar <mdf文件路径>
```

### 3. 示例输出

```
========================================
MDF文件读取器
========================================
文件路径: /path/to/data.mf4

【文件信息】
----------------------------------------
数据组数量: 1

【数据组 0】
----------------------------------------
  通道组数量: 1

  【通道组 0】
  名称: TestGroup
  描述: Test Description
  记录数: 1000
  通道数量: 3

  【通道列表】
    [0] 名称=Time, 类型=FLOAT64, 单位=s
    [1] 名称=Speed, 类型=FLOAT32, 单位=km/h
    [2] 名称=Temperature, 类型=FLOAT32, 单位=°C

  【数据样本】(最多10条记录)
    记录号 | Time | Speed | Temperature
    --------------------------------------------------
    [0] | 0.0 | 0.0 | 20.5
    [1] | 0.1 | 5.2 | 20.7
    [2] | 0.2 | 10.5 | 21.0
    ...

========================================
MDF文件读取完成
========================================
```

## 依赖说明

| 依赖 | 版本 | 说明 |
|------|------|------|
| mdf4j | 0.2.0 | ASAM MDF4 读取库（纯Java） |
| slf4j-simple | 2.0.9 | 简单日志实现 |
| junit-jupiter | 5.10.0 | 单元测试框架 |

## 技术细节

### mdf4j 库特性

- **支持的 MDF 版本**: 4.00 - 4.20
- **读取功能**: 通道数据、通道信息、总线事件
- **数据类型**: UINT8/16/32/64, INT8/16/32/64, FLOAT16/32/64, 字符串, 字节数组
- **延迟加载**: 减少初始加载时间

### 打包配置

使用 **Maven Shade Plugin** 将所有依赖打包到单个 JAR：

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-shade-plugin</artifactId>
    <version>3.5.1</version>
    <configuration>
        <transformers>
            <!-- 合并 META-INF/services 文件 -->
            <transformer implementation="org.apache.maven.plugins.shade.resource.ServicesResourceTransformer"/>
            <!-- 设置 Main-Class -->
            <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                <mainClass>com.example.mdflib.MdfReaderApp</mainClass>
            </transformer>
        </transformers>
    </configuration>
</plugin>
```

## 平台兼容性

| 平台 | 支持状态 | 测试情况 |
|------|----------|----------|
| Windows 10/11 | ✅ 完全支持 | 已测试 |
| Windows Server 2019+ | ✅ 完全支持 | 已测试 |
| Ubuntu 20.04+ | ✅ 完全支持 | 已测试 |
| CentOS 8+ | ✅ 完全支持 | 已测试 |
| macOS | ✅ 理论上支持 | 未测试 |

## 常见问题

### Q: 需要安装额外的本地库吗？
**A:** 不需要。mdf4j 是纯 Java 实现，不依赖任何本地库。

### Q: 支持 MDF3 格式吗？
**A:** mdf4j 仅支持 MDF4 格式（版本 4.00-4.20）。如需读取 MDF3 文件，建议先转换为 MDF4 格式。

### Q: 如何处理大文件？
**A:** mdf4j 使用延迟加载机制，只读取需要的数据。对于大文件，建议使用流式处理避免内存溢出。

### Q: 可以在 Java 8 上运行吗？
**A:** 本项目使用 JDK 21 特性。如需在旧版本 Java 上运行，请修改 `pom.xml` 中的 `maven.compiler.source` 和 `maven.compiler.target`。

## 许可证

本项目示例代码使用 MIT 许可证。

mdf4j 库使用 Apache-2.0 许可证。

## 参考链接

- [mdf4j GitHub](https://github.com/R1tschY/mdf4j)
- [ASAM MDF 标准](https://www.asam.net/standards/detail/mdf/)
- [Maven Shade Plugin](https://maven.apache.org/plugins/maven-shade-plugin/)
