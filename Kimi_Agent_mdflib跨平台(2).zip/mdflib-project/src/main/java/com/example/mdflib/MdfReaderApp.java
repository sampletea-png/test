package com.example.mdflib;

import de.richardliebscher.mdf4.*;
import de.richardliebscher.mdf4.extract.ChannelDeFactory;
import de.richardliebscher.mdf4.extract.de.DeserializeInto;
import de.richardliebscher.mdf4.extract.de.Deserializer;
import de.richardliebscher.mdf4.extract.de.UnsignedByte;
import de.richardliebscher.mdf4.extract.de.UnsignedInteger;
import de.richardliebscher.mdf4.extract.de.UnsignedLong;
import de.richardliebscher.mdf4.extract.de.UnsignedShort;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * MDF文件读取器应用程序
 * 
 * 使用mdf4j库读取ASAM MDF4格式文件
 * 纯Java实现，支持Windows和Linux平台
 * 
 * 使用方法: java -jar mdflib-project-1.0.0.jar <mdf文件路径>
 */
public class MdfReaderApp {

    public static void main(String[] args) {
        // 检查命令行参数
        if (args.length < 1) {
            System.out.println("MDF文件读取器 - 使用mdf4j库");
            System.out.println("用法: java -jar mdflib-project-1.0.0.jar <mdf文件路径>");
            System.out.println("示例: java -jar mdflib-project-1.0.0.jar data.mf4");
            System.out.println();
            System.out.println("环境要求:");
            System.out.println("  - JDK 21 或更高版本");
            System.out.println("  - 无需其他环境配置");
            System.out.println();
            System.out.println("支持的平台:");
            System.out.println("  - Windows");
            System.out.println("  - Linux");
            System.exit(1);
        }

        String filePath = args[0];
        Path path = Paths.get(filePath);

        System.out.println("========================================");
        System.out.println("MDF文件读取器");
        System.out.println("========================================");
        System.out.println("文件路径: " + path.toAbsolutePath());
        System.out.println();

        try {
            // 打开MDF文件
            readMdfFile(path);
        } catch (Exception e) {
            System.err.println("错误: 无法读取MDF文件");
            System.err.println("详情: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * 读取并显示MDF文件内容
     */
    private static void readMdfFile(Path path) throws IOException {
        try (Mdf4File mdf4File = Mdf4File.open(path)) {
            // 获取文件信息
            System.out.println("【文件信息】");
            System.out.println("----------------------------------------");
            
            // 获取所有数据组
            List<DataGroup> dataGroups = mdf4File.getDataGroups();
            System.out.println("数据组数量: " + dataGroups.size());
            System.out.println();

            // 遍历每个数据组
            for (int dgIndex = 0; dgIndex < dataGroups.size(); dgIndex++) {
                DataGroup dataGroup = dataGroups.get(dgIndex);
                System.out.println("【数据组 " + dgIndex + "】");
                System.out.println("----------------------------------------");

                // 获取通道组
                List<ChannelGroup> channelGroups = dataGroup.getChannelGroups();
                System.out.println("  通道组数量: " + channelGroups.size());

                // 遍历每个通道组
                for (int cgIndex = 0; cgIndex < channelGroups.size(); cgIndex++) {
                    ChannelGroup channelGroup = channelGroups.get(cgIndex);
                    System.out.println();
                    System.out.println("  【通道组 " + cgIndex + "】");
                    System.out.println("  名称: " + channelGroup.getName().orElse("N/A"));
                    System.out.println("  描述: " + channelGroup.getDescription().orElse("N/A"));
                    System.out.println("  记录数: " + channelGroup.getRecordCount());

                    // 获取通道列表
                    List<Channel> channels = channelGroup.getChannels();
                    System.out.println("  通道数量: " + channels.size());
                    System.out.println();
                    System.out.println("  【通道列表】");

                    // 显示每个通道的信息
                    for (int chIndex = 0; chIndex < channels.size(); chIndex++) {
                        Channel channel = channels.get(chIndex);
                        System.out.println("    [" + chIndex + "] " + formatChannelInfo(channel));
                    }

                    // 读取并显示数据样本（最多显示10条）
                    System.out.println();
                    System.out.println("  【数据样本】(最多10条记录)");
                    readSampleData(mdf4File, dgIndex, channelGroup, channels);
                }
            }

            System.out.println();
            System.out.println("========================================");
            System.out.println("MDF文件读取完成");
            System.out.println("========================================");
        }
    }

    /**
     * 格式化通道信息
     */
    private static String formatChannelInfo(Channel channel) {
        StringBuilder sb = new StringBuilder();
        sb.append("名称=").append(channel.getName().orElse("N/A"));
        sb.append(", 类型=").append(channel.getDataType());
        channel.getUnit().ifPresent(unit -> sb.append(", 单位=").append(unit));
        channel.getDescription().ifPresent(desc -> sb.append(", 描述=").append(desc));
        return sb.toString();
    }

    /**
     * 读取样本数据
     */
    private static void readSampleData(Mdf4File mdf4File, int dgIndex, 
                                       ChannelGroup channelGroup, List<Channel> channels) {
        try {
            // 创建记录读取器
            var reader = mdf4File.newRecordReader(dgIndex, new SampleChannelDeFactory(channels));
            
            // 读取最多10条记录
            long recordCount = channelGroup.getRecordCount();
            long samplesToRead = Math.min(recordCount, 10);
            
            if (samplesToRead == 0) {
                System.out.println("    (无数据记录)");
                return;
            }

            // 打印表头
            System.out.print("    记录号");
            for (Channel channel : channels) {
                System.out.print(" | " + channel.getName().orElse("Unknown"));
            }
            System.out.println();
            System.out.println("    " + "-".repeat(50));

            // 读取记录
            SampleRecord record = new SampleRecord(channels.size());
            for (int i = 0; i < samplesToRead && reader.readInto(record); i++) {
                System.out.print("    [" + i + "]");
                for (Object value : record.values) {
                    System.out.print(" | " + (value != null ? value.toString() : "null"));
                }
                System.out.println();
            }

            if (recordCount > 10) {
                System.out.println("    ... (共 " + recordCount + " 条记录)");
            }

        } catch (Exception e) {
            System.out.println("    无法读取数据: " + e.getMessage());
        }
    }

    /**
     * 样本记录类
     */
    private static class SampleRecord {
        final Object[] values;
        int index = 0;

        SampleRecord(int channelCount) {
            this.values = new Object[channelCount];
        }

        void reset() {
            index = 0;
        }

        void addValue(Object value) {
            if (index < values.length) {
                values[index++] = value;
            }
        }
    }

    /**
     * 样本通道反序列化工厂
     */
    private static class SampleChannelDeFactory implements ChannelDeFactory<SampleRecord> {
        private final List<Channel> channels;
        private int channelIndex = 0;

        SampleChannelDeFactory(List<Channel> channels) {
            this.channels = channels;
        }

        @Override
        public DeserializeInto<SampleRecord> createDeserialization(
                DataGroup dg, ChannelGroup group, Channel channel) {
            
            final int currentIndex = channelIndex++;
            final Channel currentChannel = channels.get(currentIndex);
            
            return (deserializer, record) -> {
                Object value = deserializeValue(deserializer, currentChannel.getDataType());
                record.addValue(value);
            };
        }

        private Object deserializeValue(Deserializer deserializer, Channel.DataType dataType) {
            try {
                return switch (dataType) {
                    case UINT8 -> deserializer.deserialize(UnsignedByte.class);
                    case UINT16 -> deserializer.deserialize(UnsignedShort.class);
                    case UINT32 -> deserializer.deserialize(UnsignedInteger.class);
                    case UINT64 -> deserializer.deserialize(UnsignedLong.class);
                    case INT8 -> deserializer.deserializeByte();
                    case INT16 -> deserializer.deserializeShort();
                    case INT32 -> deserializer.deserializeInt();
                    case INT64 -> deserializer.deserializeLong();
                    case FLOAT16 -> deserializer.deserializeHalf();
                    case FLOAT32 -> deserializer.deserializeFloat();
                    case FLOAT64 -> deserializer.deserializeDouble();
                    case STRING, STRING_UTF8, STRING_UTF16, STRING_UTF16LE, STRING_UTF16BE -> 
                        deserializer.deserializeString();
                    case BYTE_ARRAY -> deserializer.deserializeByteArray();
                    default -> "<unsupported>";
                };
            } catch (IOException e) {
                return "<error>";
            }
        }
    }
}
