package com.example.mdflib;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * MDF读取器应用程序单元测试
 */
public class MdfReaderAppTest {

    @Test
    @DisplayName("测试应用程序入口参数检查")
    public void testMainWithNoArgs() {
        // 测试无参数时应用程序应该显示帮助信息并退出
        // 注意：实际测试时会调用System.exit，这里仅验证类存在
        assertNotNull(MdfReaderApp.class);
    }

    @Test
    @DisplayName("测试类可实例化")
    public void testClassInstantiation() {
        // 验证主类可以被加载
        assertDoesNotThrow(() -> {
            Class<?> clazz = Class.forName("com.example.mdflib.MdfReaderApp");
            assertNotNull(clazz);
        });
    }

    @Test
    @DisplayName("测试Java版本兼容性")
    public void testJavaVersion() {
        // 验证运行时的Java版本
        String javaVersion = System.getProperty("java.version");
        assertNotNull(javaVersion);
        System.out.println("当前Java版本: " + javaVersion);
        
        // 检查是否为Java 21或更高版本
        int majorVersion = Runtime.version().feature();
        assertTrue(majorVersion >= 21, 
            "需要Java 21或更高版本，当前版本: " + majorVersion);
    }

    @Test
    @DisplayName("测试系统属性")
    public void testSystemProperties() {
        // 验证必要的系统属性
        assertNotNull(System.getProperty("java.home"));
        assertNotNull(System.getProperty("os.name"));
        assertNotNull(System.getProperty("file.encoding"));
        
        System.out.println("Java Home: " + System.getProperty("java.home"));
        System.out.println("OS Name: " + System.getProperty("os.name"));
        System.out.println("OS Arch: " + System.getProperty("os.arch"));
        System.out.println("File Encoding: " + System.getProperty("file.encoding"));
    }
}
