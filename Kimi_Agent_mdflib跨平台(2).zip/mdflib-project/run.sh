#!/bin/bash

echo "========================================"
echo "MDFLib 项目运行脚本 (Linux)"
echo "========================================"
echo ""

# 检查Java是否安装
if ! command -v java &> /dev/null; then
    echo "错误: 未找到 Java。请确保 JDK 21 或更高版本已安装。"
    echo "安装方法:"
    echo "  Ubuntu/Debian: sudo apt-get install openjdk-21-jdk"
    echo "  CentOS/RHEL:   sudo yum install java-21-openjdk-devel"
    echo "  或手动下载:   https://adoptium.net/"
    exit 1
fi

# 检查Java版本
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "检测到Java版本: $java_version"

# 检查JAR文件是否存在
if [ ! -f "target/mdflib-project-1.0.0.jar" ]; then
    echo "错误: 未找到JAR文件。请先运行 ./build.sh 构建项目。"
    exit 1
fi

# 检查参数
if [ -z "$1" ]; then
    echo "用法: $0 <mdf文件路径>"
    echo "示例: $0 data.mf4"
    echo ""
    echo "帮助信息:"
    java -jar target/mdflib-project-1.0.0.jar
    exit 1
fi

echo "正在运行MDF文件读取器..."
echo "文件: $1"
echo ""

java -jar target/mdflib-project-1.0.0.jar "$1"

exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo ""
    echo "程序执行失败，错误码: $exit_code"
    exit $exit_code
fi

echo ""
echo "程序执行完成。"
