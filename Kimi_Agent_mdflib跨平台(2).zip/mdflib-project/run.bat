@echo off
chcp 65001 >nul
echo ========================================
echo MDFLib 项目运行脚本 (Windows)
echo ========================================
echo.

REM 检查Java是否安装
where java >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到 Java。请确保 JDK 21 或更高版本已安装。
    echo 下载地址: https://adoptium.net/
    exit /b 1
)

REM 检查JAR文件是否存在
if not exist "target\mdflib-project-1.0.0.jar" (
    echo 错误: 未找到JAR文件。请先运行 build.bat 构建项目。
    exit /b 1
)

REM 检查参数
if "%~1"=="" (
    echo 用法: run.bat ^<mdf文件路径^>
    echo 示例: run.bat data.mf4
    echo.
    echo 帮助信息:
    java -jar target\mdflib-project-1.0.0.jar
    exit /b 1
)

echo 正在运行MDF文件读取器...
echo 文件: %~1
echo.

java -jar target\mdflib-project-1.0.0.jar "%1"

if %errorlevel% neq 0 (
    echo.
    echo 程序执行失败，错误码: %errorlevel%
    exit /b %errorlevel%
)

echo.
echo 程序执行完成。
pause
