@echo off
chcp 65001 >nul
setlocal

echo ========================================
echo MDFLib JNI 运行脚本 (Windows)
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "PROJECT_DIR=%SCRIPT_DIR%"
set "BUILD_DIR=%PROJECT_DIR%\target"
set "JAR_FILE=%BUILD_DIR%\mdflib-jni-1.0.0.jar"

rem 检查 Java
java -version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到 Java
    exit /b 1
)

rem 检查 JAR 文件
if not exist "%JAR_FILE%" (
    echo 错误: 未找到 JAR 文件: %JAR_FILE%
    echo 请先运行构建: scripts\build-windows.bat
    exit /b 1
)

rem 检查本地库
set "LIB_FILE=%BUILD_DIR%\mdflib_jni.dll"
if not exist "%LIB_FILE%" (
    echo 警告: 未找到本地库: %LIB_FILE%
    echo 尝试从 JAR 中加载...
)

rem 运行程序
if "%~1"=="" (
    echo 用法: %0 ^<命令^> [参数]
    echo.
    java -Djava.library.path="%BUILD_DIR%" -jar "%JAR_FILE%" help
) else (
    java -Djava.library.path="%BUILD_DIR%" -jar "%JAR_FILE%" %*
)

endlocal
