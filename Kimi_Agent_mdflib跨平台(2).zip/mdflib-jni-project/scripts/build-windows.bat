@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

echo ========================================
echo MDFLib JNI 构建脚本 (Windows)
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "PROJECT_DIR=%SCRIPT_DIR%.."
set "BUILD_DIR=%PROJECT_DIR%\target"
set "NATIVE_DIR=%PROJECT_DIR%\src\main\native"

echo 项目目录: %PROJECT_DIR%
echo 构建目录: %BUILD_DIR%
echo.

rem 检查 Java 环境
java -version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到 Java
    exit /b 1
)

javac -version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到 javac
    exit /b 1
)

for /f "tokens=3" %%g in ('java -version 2^>^&1 ^| findstr /i "version"') do (
    set "JAVA_VERSION=%%g"
    set "JAVA_VERSION=!JAVA_VERSION:"=!"
)
echo Java 版本: %JAVA_VERSION%

rem 检查 JAVA_HOME
if "%JAVA_HOME%"=="" (
    echo 警告: JAVA_HOME 未设置，尝试自动检测...
    for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\JavaSoft\Java Development Kit" /s 2^>nul ^| findstr "JavaHome"') do (
        set "JAVA_HOME=%%b"
    )
)

if "%JAVA_HOME%"=="" (
    echo 错误: 无法检测到 JAVA_HOME
    exit /b 1
)
echo JAVA_HOME: %JAVA_HOME%
echo.

rem 检查 Visual Studio 编译器
where cl >nul 2>&1
if errorlevel 1 (
    echo 正在查找 Visual Studio...
    
    rem 尝试查找 VS2022, VS2019, VS2017
    set "VS_PATH="
    
    if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
    ) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"
    ) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\VC\Auxiliary\Build\vcvarsall.bat" (
        set "VS_PATH=C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\VC\Auxiliary\Build\vcvarsall.bat"
    )
    
    if "!VS_PATH!"=="" (
        echo 错误: 未找到 Visual Studio 编译器
        echo 请安装 Visual Studio 2017 或更高版本，并包含 C++ 开发工具
        exit /b 1
    )
    
    echo 找到 Visual Studio: !VS_PATH!
    call "!VS_PATH!" x64
)

echo C++ 编译器: 
cl 2>&1 | findstr "Microsoft"
echo.

rem 创建构建目录
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
if not exist "%BUILD_DIR%\native" mkdir "%BUILD_DIR%\native"

rem 编译 JNI 头文件
echo 生成 JNI 头文件...
cd /d "%PROJECT_DIR%"

rem 先编译 Java 类
if not exist "%BUILD_DIR%\classes" mkdir "%BUILD_DIR%\classes"

javac -d "%BUILD_DIR%\classes" ^
    -sourcepath "%PROJECT_DIR%\src\main\java" ^
    "%PROJECT_DIR%\src\main\java\com\example\mdflib\MdfLibJNI.java"

if errorlevel 1 (
    echo Java 编译失败!
    exit /b 1
)

rem 生成头文件
javah -jni -d "%NATIVE_DIR%\include" ^
    -classpath "%BUILD_DIR%\classes" ^
    com.example.mdflib.MdfLibJNI

echo 头文件生成完成
echo.

rem 编译 C++ 代码
echo 编译 C++ 代码...

set "CXX_FLAGS=/O2 /EHsc /MD /W3 /nologo"
set "CXX_FLAGS=%CXX_FLAGS% /I"%JAVA_HOME%\include""
set "CXX_FLAGS=%CXX_FLAGS% /I"%JAVA_HOME%\include\win32""
set "CXX_FLAGS=%CXX_FLAGS% /I"%NATIVE_DIR%\include""

set "SOURCE_FILES=%NATIVE_DIR%\src\common\MdfLibJNI.cpp"
set "OUTPUT_LIB=%BUILD_DIR%\mdflib_jni.dll"

echo 编译选项: %CXX_FLAGS%
echo 源文件: %SOURCE_FILES%
echo 输出: %OUTPUT_LIB%
echo.

rem 编译 DLL
cl %CXX_FLAGS% /Fe"%OUTPUT_LIB%" /LD %SOURCE_FILES%

if errorlevel 1 (
    echo 编译失败!
    exit /b 1
)

echo 编译成功!
echo.

rem 复制库文件到 resources 目录
copy /Y "%OUTPUT_LIB%" "%BUILD_DIR%\native\" >nul

echo ========================================
echo 构建完成!
echo ========================================
echo 库文件位置:
echo   %OUTPUT_LIB%
echo.
echo 使用方法:
echo   java -Djava.library.path=%BUILD_DIR% -jar target\mdflib-jni-1.0.0.jar
echo.

rem 显示库信息
dumpbin /headers "%OUTPUT_LIB%" 2>nul | findstr "machine" || echo.

pause
