#!/bin/bash

# MDFLib JNI Linux 构建脚本

set -e

echo "========================================"
echo "MDFLib JNI 构建脚本 (Linux)"
echo "========================================"
echo ""

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_DIR/target"
NATIVE_DIR="$PROJECT_DIR/src/main/native"

echo "项目目录: $PROJECT_DIR"
echo "构建目录: $BUILD_DIR"
echo ""

# 检查 Java 环境
if ! command -v java &> /dev/null; then
    echo "错误: 未找到 Java"
    exit 1
fi

if ! command -v javac &> /dev/null; then
    echo "错误: 未找到 javac"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "Java 版本: $JAVA_VERSION"

# 获取 JAVA_HOME
if [ -z "$JAVA_HOME" ]; then
    JAVA_HOME=$(readlink -f $(which java) | sed 's|/bin/java||' | sed 's|/jre||')
    echo "检测到 JAVA_HOME: $JAVA_HOME"
fi

# 检查编译器
if ! command -v g++ &> /dev/null; then
    echo "错误: 未找到 g++ 编译器"
    echo "请安装: sudo apt-get install g++ (Ubuntu/Debian)"
    echo "        sudo yum install gcc-c++ (CentOS/RHEL)"
    exit 1
fi

GPP_VERSION=$(g++ --version | head -n1)
echo "C++ 编译器: $GPP_VERSION"
echo ""

# 创建构建目录
mkdir -p "$BUILD_DIR"
mkdir -p "$BUILD_DIR/native"

# 编译 JNI 头文件
echo "生成 JNI 头文件..."
cd "$PROJECT_DIR"

# 先编译 Java 类
mkdir -p "$BUILD_DIR/classes"
javac -d "$BUILD_DIR/classes" \
    -sourcepath "$PROJECT_DIR/src/main/java" \
    "$PROJECT_DIR/src/main/java/com/example/mdflib/MdfLibJNI.java"

# 生成头文件
javah -jni -d "$NATIVE_DIR/include" \
    -classpath "$BUILD_DIR/classes" \
    com.example.mdflib.MdfLibJNI

echo "头文件生成完成"
echo ""

# 编译 C++ 代码
echo "编译 C++ 代码..."

# 设置编译选项
CXX_FLAGS="-fPIC -std=c++17 -O2 -shared"
CXX_FLAGS="$CXX_FLAGS -I$JAVA_HOME/include"
CXX_FLAGS="$CXX_FLAGS -I$JAVA_HOME/include/linux"
CXX_FLAGS="$CXX_FLAGS -I$NATIVE_DIR/include"

# 源文件
SOURCE_FILES="$NATIVE_DIR/src/common/MdfLibJNI.cpp"

# 输出库
OUTPUT_LIB="$BUILD_DIR/libmdflib_jni.so"

echo "编译选项: $CXX_FLAGS"
echo "源文件: $SOURCE_FILES"
echo "输出: $OUTPUT_LIB"
echo ""

# 编译
g++ $CXX_FLAGS -o "$OUTPUT_LIB" $SOURCE_FILES

if [ $? -eq 0 ]; then
    echo "编译成功!"
    echo ""
else
    echo "编译失败!"
    exit 1
fi

# 复制库文件到 resources 目录
cp "$OUTPUT_LIB" "$BUILD_DIR/native/"

echo "========================================"
echo "构建完成!"
echo "========================================"
echo "库文件位置:"
echo "  $OUTPUT_LIB"
echo ""
echo "使用方法:"
echo "  java -Djava.library.path=$BUILD_DIR -jar target/mdflib-jni-1.0.0.jar"
echo ""

# 显示库信息
if command -v file &> /dev/null; then
    echo "库文件信息:"
    file "$OUTPUT_LIB"
fi

if command -v ldd &> /dev/null; then
    echo ""
    echo "库依赖:"
    ldd "$OUTPUT_LIB" 2>/dev/null || true
fi
