# MDFLib JNI 项目

使用 **mdflib C++ 库** + **JNI** 实现 MF4 文件读写的跨平台 Java 项目。

## 特性

- **mdflib C++ 库**: 使用原生 mdflib 库实现高性能 MDF 文件操作
- **JNI 桥接**: 通过 JNI 实现 Java 与 C++ 的互操作
- **读写支持**: 完整支持 MDF 文件的读取和写入
- **跨平台**: 支持 Windows 和 Linux 平台
- **零配置运行**: 构建后只需 JDK 21，无需其他环境配置

## 环境要求

### 构建环境

| 组件 | Windows | Linux |
|------|---------|-------|
| JDK | 21+ | 21+ |
| C++ 编译器 | Visual Studio 2017+ | GCC 7+ |
| 构建工具 | Maven 3.8+ | Maven 3.8+ |

### 运行环境

- **JDK 21** 或更高版本
- 支持的操作系统: Windows 10/11, Linux (Ubuntu 18.04+, CentOS 7+)

## 项目结构

```
mdflib-jni-project/
├── pom.xml                          # Maven 配置文件
├── README.md                        # 项目说明文档
├── scripts/
│   ├── build-linux.sh               # Linux 构建脚本
│   └── build-windows.bat            # Windows 构建脚本
├── src/
│   ├── main/
│   │   ├── java/com/example/mdflib/
│   │   │   ├── MdfLibJNI.java       # JNI 接口类
│   │   │   ├── MdfFile.java         # MDF 文件操作类
│   │   │   ├── MdfChannel.java      # 通道模型
│   │   │   ├── MdfChannelGroup.java # 通道组模型
│   │   │   ├── MdfFileInfo.java     # 文件信息模型
│   │   │   ├── MdfJsonParser.java   # JSON 解析器
│   │   │   ├── DataType.java        # 数据类型枚举
│   │   │   ├── MdfException.java    # 异常类
│   │   │   └── MdfTool.java         # 命令行工具
│   │   └── native/
│   │       ├── include/             # JNI 头文件
│   │       └── src/
│   │           └── common/
│   │               └── MdfLibJNI.cpp # JNI C++ 实现
│   └── test/java/com/example/mdflib/
│       └── MdfLibTest.java          # 单元测试
└── target/                          # 构建输出目录
```

## 快速开始

### 1. 克隆和构建

**Linux:**
```bash
# 克隆项目
cd mdflib-jni-project

# 运行构建脚本
chmod +x scripts/build-linux.sh
./scripts/build-linux.sh

# 或使用 Maven
mvn clean package
```

**Windows:**
```cmd
:: 克隆项目
cd mdflib-jni-project

:: 运行构建脚本
scripts\build-windows.bat

:: 或使用 Maven
mvn clean package
```

### 2. 运行程序

```bash
# 显示帮助
java -jar target/mdflib-jni-1.0.0.jar help

# 查看版本信息
java -jar target/mdflib-jni-1.0.0.jar version

# 读取 MDF 文件
java -jar target/mdflib-jni-1.0.0.jar read data.mf4

# 显示 MDF 文件信息
java -jar target/mdflib-jni-1.0.0.jar info data.mf4

# 创建示例 MDF 文件
java -jar target/mdflib-jni-1.0.0.jar write output.mf4

# 转换 MDF 文件格式
java -jar target/mdflib-jni-1.0.0.jar convert input.mf4 output.mf4
```

## API 使用示例

### 读取 MDF 文件

```java
import com.example.mdflib.*;

// 打开 MDF 文件
try (MdfFile mdfFile = new MdfFile("data.mf4")) {
    mdfFile.open();
    
    // 获取文件信息
    MdfFileInfo info = mdfFile.getFileInfo();
    System.out.println("版本: " + info.getVersion());
    System.out.println("程序: " + info.getProgram());
    
    // 获取通道组
    List<MdfChannelGroup> groups = mdfFile.getChannelGroups();
    for (MdfChannelGroup group : groups) {
        System.out.println("通道组: " + group.getName());
        System.out.println("记录数: " + group.getRecordCount());
        
        // 获取通道
        List<MdfChannel> channels = mdfFile.getChannels(group.getIndex());
        for (MdfChannel channel : channels) {
            System.out.println("  通道: " + channel.getName() + 
                " [" + channel.getDataType() + "]");
        }
        
        // 读取通道数据
        double[] timeData = mdfFile.readChannelDataDouble(
            group.getIndex(), 0, 0, group.getRecordCount());
        double[] speedData = mdfFile.readChannelDataDouble(
            group.getIndex(), 1, 0, group.getRecordCount());
    }
}
```

### 写入 MDF 文件

```java
import com.example.mdflib.*;

// 创建 MDF 4.0 文件
try (MdfFile mdfFile = new MdfFile("output.mf4", 4, "MyApp")) {
    
    // 添加通道组
    int groupIndex = mdfFile.addChannelGroup("Measurements", "Test data");
    
    // 添加时间通道
    int timeChannel = mdfFile.addTimeChannel(groupIndex, "Time", "s");
    
    // 添加数据通道
    int speedChannel = mdfFile.addChannel(groupIndex, "Speed", "km/h", 
        "Vehicle speed", DataType.DOUBLE);
    int tempChannel = mdfFile.addChannel(groupIndex, "Temperature", "°C", 
        "Engine temp", DataType.DOUBLE);
    
    // 准备数据
    int sampleCount = 1000;
    double[] timeData = new double[sampleCount];
    double[] speedData = new double[sampleCount];
    double[] tempData = new double[sampleCount];
    
    for (int i = 0; i < sampleCount; i++) {
        timeData[i] = i * 0.01;  // 10ms 间隔
        speedData[i] = Math.sin(i * 0.1) * 50 + 60;
        tempData[i] = 80 + Math.random() * 20;
    }
    
    // 写入数据
    mdfFile.writeChannelData(groupIndex, timeChannel, timeData);
    mdfFile.writeChannelData(groupIndex, speedChannel, speedData);
    mdfFile.writeChannelData(groupIndex, tempChannel, tempData);
    
}  // 文件自动保存并关闭
```

## 支持的 MDF 版本

| 版本 | 读取 | 写入 | 说明 |
|------|------|------|------|
| MDF 3.0 | ✅ | ✅ | 传统格式 |
| MDF 3.1 | ✅ | ✅ | 传统格式 |
| MDF 4.0 | ✅ | ✅ | 推荐格式 |
| MDF 4.1 | ✅ | ✅ | 支持压缩 |
| MDF 4.2 | ✅ | ✅ | 最新版本 |

## 数据类型支持

| 类型 | Java 类型 | 说明 |
|------|-----------|------|
| DOUBLE | double | 双精度浮点数 |
| FLOAT | float | 单精度浮点数 |
| INT64 | long | 64位有符号整数 |
| INT32 | int | 32位有符号整数 |
| INT16 | short | 16位有符号整数 |
| INT8 | byte | 8位有符号整数 |
| UINT64 | long | 64位无符号整数 |
| UINT32 | long | 32位无符号整数 |
| UINT16 | int | 16位无符号整数 |
| UINT8 | int | 8位无符号整数 |
| STRING | String | 字符串 |

## 构建配置

### Maven 配置

```xml
<properties>
    <maven.compiler.source>21</maven.compiler.source>
    <maven.compiler.target>21</maven.compiler.target>
</properties>
```

### 本地库加载

项目使用自动库加载机制：
1. 首先尝试从 JAR 包中提取并加载对应平台的库
2. 如果失败，尝试从 `java.library.path` 加载

### 跨平台库文件

| 平台 | 库文件名 | 位置 |
|------|----------|------|
| Windows | `mdflib_jni.dll` | `target/` |
| Linux | `libmdflib_jni.so` | `target/` |
| macOS | `libmdflib_jni.dylib` | `target/` |

## 常见问题

### Q: 如何链接真正的 mdflib 库？

A: 当前实现是一个简化框架。要链接真正的 mdflib 库：

1. 下载并编译 [ihedvall/mdflib](https://github.com/ihedvall/mdflib)
2. 修改 `MdfLibJNI.cpp` 中的实现，调用真正的 mdflib API
3. 在构建脚本中添加 mdflib 库的链接选项

### Q: 编译时出现 "找不到 jni.h" 错误？

A: 确保 `JAVA_HOME` 环境变量正确设置：

```bash
# Linux
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk

# Windows
set JAVA_HOME=C:\Program Files\Java\jdk-21
```

### Q: 运行时出现 `UnsatisfiedLinkError`？

A: 确保本地库在正确的位置：

```bash
# 指定库路径运行
java -Djava.library.path=target -jar target/mdflib-jni-1.0.0.jar
```

### Q: 支持哪些操作系统？

A: 理论上支持所有支持 JNI 的平台：
- ✅ Windows 10/11 (x64)
- ✅ Linux (x64, ARM64)
- ⚠️ macOS (需要额外配置)

## 技术细节

### JNI 接口设计

```
Java (MdfLibJNI) <--JNI--> C++ (MdfLibJNI.cpp) <---> MDF 文件
```

### 数据流

```
读取: MDF 文件 -> C++ 缓冲区 -> JNI -> Java 数组
写入: Java 数组 -> JNI -> C++ 缓冲区 -> MDF 文件
```

### 性能优化

- 使用直接缓冲区减少数据拷贝
- 批量读写操作
- 延迟加载通道数据

## 许可证

本项目示例代码使用 MIT 许可证。

mdflib 库使用 MIT 许可证。

## 参考链接

- [ihedvall/mdflib](https://github.com/ihedvall/mdflib) - mdflib C++ 库
- [ASAM MDF 标准](https://www.asam.net/standards/detail/mdf/) - MDF 格式规范
- [JNI 规范](https://docs.oracle.com/javase/8/docs/technotes/guides/jni/) - Java Native Interface

## 贡献

欢迎提交 Issue 和 Pull Request！

## 联系方式

如有问题，请通过 GitHub Issues 联系。
