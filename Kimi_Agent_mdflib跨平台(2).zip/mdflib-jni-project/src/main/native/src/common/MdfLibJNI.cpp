/**
 * MDFLib JNI 实现
 * 
 * 提供对 mdflib C++ 库的 JNI 包装
 * 
 * 注意：这是一个简化的实现框架。
 * 实际使用时需要链接真正的 mdflib 库。
 */

#include "com_example_mdflib_MdfLibJNI.h"
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <cmath>

// 版本信息
#define MDFLIB_JNI_VERSION "1.0.0"
#define MDFLIB_JNI_BUILD_DATE __DATE__

// 平台检测
#ifdef _WIN32
    #define PLATFORM "Windows"
    #include <windows.h>
#else
    #define PLATFORM "Linux/Unix"
    #include <unistd.h>
#endif

// 错误信息
static std::string g_lastError;

// 设置错误信息
static void setError(const std::string& msg) {
    g_lastError = msg;
}

// 将Java字符串转换为C++字符串
static std::string jstringToString(JNIEnv* env, jstring jstr) {
    if (jstr == nullptr) return "";
    const char* cstr = env->GetStringUTFChars(jstr, nullptr);
    std::string result(cstr);
    env->ReleaseStringUTFChars(jstr, cstr);
    return result;
}

// 将C++字符串转换为Java字符串
static jstring stringToJstring(JNIEnv* env, const std::string& str) {
    return env->NewStringUTF(str.c_str());
}

// ==================== 简化的MDF数据结构 ====================

// 通道定义
struct Channel {
    int index;
    std::string name;
    std::string unit;
    std::string description;
    int dataType;  // 0=DOUBLE, 1=FLOAT, 2=INT64, 3=INT32, 4=INT16, 5=INT8, 6=UINT64, 7=UINT32, 8=UINT16, 9=UINT8, 10=STRING
    bool isTimeChannel;
    std::vector<double> doubleData;
    std::vector<long long> longData;
    std::vector<int> intData;
    std::vector<std::string> stringData;
};

// 通道组定义
struct ChannelGroup {
    int index;
    std::string name;
    std::string description;
    std::vector<Channel> channels;
};

// MDF文件定义
struct MdfFileHandle {
    bool isWriteMode;
    int version;
    std::string filePath;
    std::string program;
    std::vector<ChannelGroup> groups;
    
    // 文件头信息
    std::string author;
    std::string organization;
    std::string project;
    std::string subject;
    std::string comment;
    
    MdfFileHandle() : isWriteMode(false), version(4) {}
};

// 文件句柄管理器
static std::map<long, std::shared_ptr<MdfFileHandle>> g_fileHandles;
static long g_nextHandle = 1;

// 获取文件句柄
static std::shared_ptr<MdfFileHandle> getHandle(long handle) {
    auto it = g_fileHandles.find(handle);
    if (it != g_fileHandles.end()) {
        return it->second;
    }
    return nullptr;
}

// 添加文件句柄
static long addHandle(std::shared_ptr<MdfFileHandle> handle) {
    long h = g_nextHandle++;
    g_fileHandles[h] = handle;
    return h;
}

// 移除文件句柄
static void removeHandle(long handle) {
    g_fileHandles.erase(handle);
}

// ==================== JSON 辅助函数 ====================

static std::string escapeJson(const std::string& s) {
    std::string result;
    for (char c : s) {
        switch (c) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default: result += c;
        }
    }
    return result;
}

static std::string toJsonString(const std::string& key, const std::string& value, bool last = false) {
    return "\"" + key + "\":\"" + escapeJson(value) + "\"" + (last ? "" : ",");
}

static std::string toJsonInt(const std::string& key, int value, bool last = false) {
    return "\"" + key + "\":" + std::to_string(value) + (last ? "" : ",");
}

static std::string toJsonLong(const std::string& key, long long value, bool last = false) {
    return "\"" + key + "\":" + std::to_string(value) + (last ? "" : ",");
}

static std::string toJsonBool(const std::string& key, bool value, bool last = false) {
    return "\"" + key + "\":" + (value ? "true" : "false") + (last ? "" : ",");
}

static std::string toJsonDouble(const std::string& key, double value, bool last = false) {
    std::ostringstream oss;
    oss << "\"" << key << "\":" << std::fixed << std::setprecision(6) << value;
    return oss.str() + (last ? "" : ",");
}

// ==================== JNI 实现 ====================

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getVersion(JNIEnv* env, jclass) {
    return stringToJstring(env, MDFLIB_JNI_VERSION);
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getNativeLibInfo(JNIEnv* env, jclass) {
    std::string info = "MDFLib JNI " + std::string(MDFLIB_JNI_VERSION) + 
                       " (" + PLATFORM + ", Built: " + MDFLIB_JNI_BUILD_DATE + ")";
    return stringToJstring(env, info);
}

JNIEXPORT jlong JNICALL Java_com_example_mdflib_MdfLibJNI_openFile(JNIEnv* env, jclass, jstring filePath) {
    std::string path = jstringToString(env, filePath);
    
    // 检查文件是否存在
    std::ifstream test(path, std::ios::binary);
    if (!test.good()) {
        setError("文件不存在: " + path);
        return -1;
    }
    test.close();
    
    // 创建文件句柄
    auto handle = std::make_shared<MdfFileHandle>();
    handle->isWriteMode = false;
    handle->filePath = path;
    
    // 解析MDF文件（简化实现）
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        setError("无法打开文件: " + path);
        return -1;
    }
    
    // 读取文件头，检测版本
    file.seekg(0, std::ios::beg);
    char header[8];
    file.read(header, 8);
    
    if (std::memcmp(header, "MDF", 3) != 0) {
        // 尝试读取 MDF 4.0 格式
        file.seekg(64, std::ios::beg);
        file.read(header, 8);
    }
    
    // 检测版本
    if (header[0] == 'M' && header[1] == 'D' && header[2] == 'F') {
        handle->version = 3;
    } else {
        // 默认为版本4
        handle->version = 4;
    }
    
    // 创建示例通道组（实际实现中应该解析真实文件内容）
    ChannelGroup group;
    group.index = 0;
    group.name = "DefaultGroup";
    group.description = "Default channel group";
    
    // 添加示例通道
    Channel timeChannel;
    timeChannel.index = 0;
    timeChannel.name = "Time";
    timeChannel.unit = "s";
    timeChannel.description = "Time channel";
    timeChannel.dataType = 0;  // DOUBLE
    timeChannel.isTimeChannel = true;
    
    Channel dataChannel;
    dataChannel.index = 1;
    dataChannel.name = "Data";
    dataChannel.unit = "";
    dataChannel.description = "Data channel";
    dataChannel.dataType = 0;  // DOUBLE
    dataChannel.isTimeChannel = false;
    
    group.channels.push_back(timeChannel);
    group.channels.push_back(dataChannel);
    handle->groups.push_back(group);
    
    file.close();
    
    return addHandle(handle);
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_closeFile(JNIEnv*, jclass, jlong handle) {
    auto file = getHandle(handle);
    if (!file) {
        setError("无效的文件句柄");
        return -1;
    }
    
    removeHandle(handle);
    return 0;
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getFileInfo(JNIEnv* env, jclass, jlong handle) {
    auto file = getHandle(handle);
    if (!file) {
        return stringToJstring(env, "{}");
    }
    
    std::string json = "{";
    json += toJsonString("fileName", file->filePath);
    json += toJsonInt("version", file->version);
    json += toJsonString("versionString", file->version == 3 ? "3.0" : "4.0");
    json += toJsonString("program", file->program);
    json += toJsonString("author", file->author);
    json += toJsonString("organization", file->organization);
    json += toJsonString("project", file->project);
    json += toJsonString("subject", file->subject);
    json += toJsonString("comment", file->comment);
    json += toJsonString("creationTime", "2024-01-01T00:00:00");
    json += toJsonLong("fileSize", 0);
    json += toJsonInt("dataGroupCount", static_cast<int>(file->groups.size()), true);
    json += "}";
    
    return stringToJstring(env, json);
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getChannelGroups(JNIEnv* env, jclass, jlong handle) {
    auto file = getHandle(handle);
    if (!file) {
        return stringToJstring(env, "[]");
    }
    
    std::string json = "[";
    for (size_t i = 0; i < file->groups.size(); i++) {
        const auto& group = file->groups[i];
        json += "{";
        json += toJsonInt("index", group.index);
        json += toJsonString("name", group.name);
        json += toJsonString("description", group.description);
        json += toJsonLong("recordCount", 0);
        json += toJsonLong("recordSize", 0, true);
        json += "}";
        if (i < file->groups.size() - 1) {
            json += ",";
        }
    }
    json += "]";
    
    return stringToJstring(env, json);
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getChannels(JNIEnv* env, jclass, jlong handle, jint groupIndex) {
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        return stringToJstring(env, "[]");
    }
    
    const auto& group = file->groups[groupIndex];
    std::string json = "[";
    for (size_t i = 0; i < group.channels.size(); i++) {
        const auto& channel = group.channels[i];
        json += "{";
        json += toJsonInt("index", channel.index);
        json += toJsonString("name", channel.name);
        json += toJsonString("unit", channel.unit);
        json += toJsonString("description", channel.description);
        json += toJsonInt("dataType", channel.dataType);
        json += toJsonBool("timeChannel", channel.isTimeChannel);
        json += toJsonLong("dataCount", 0);
        json += toJsonDouble("minValue", 0.0);
        json += toJsonDouble("maxValue", 0.0, true);
        json += "}";
        if (i < group.channels.size() - 1) {
            json += ",";
        }
    }
    json += "]";
    
    return stringToJstring(env, json);
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_readChannelData(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jint channelIndex, 
    jlong startSample, jlong count) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        return stringToJstring(env, "[]");
    }
    
    const auto& group = file->groups[groupIndex];
    if (channelIndex < 0 || channelIndex >= static_cast<int>(group.channels.size())) {
        return stringToJstring(env, "[]");
    }
    
    // 生成示例数据
    std::string json = "[";
    for (long long i = 0; i < count && i < 1000; i++) {
        double value = std::sin((startSample + i) * 0.1) * 50.0 + 50.0;
        json += std::to_string(value);
        if (i < count - 1 && i < 999) {
            json += ",";
        }
    }
    json += "]";
    
    return stringToJstring(env, json);
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_readAllChannelData(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jlong startSample, jlong count) {
    // 简化实现，返回空对象
    return stringToJstring(env, "{}");
}

JNIEXPORT jlong JNICALL Java_com_example_mdflib_MdfLibJNI_getRecordCount(JNIEnv*, jclass, jlong handle, jint groupIndex) {
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        return 0;
    }
    return 0;  // 简化实现
}

JNIEXPORT jlong JNICALL Java_com_example_mdflib_MdfLibJNI_createFile(
    JNIEnv* env, jclass, jstring filePath, jint version, jstring programName) {
    
    std::string path = jstringToString(env, filePath);
    std::string program = jstringToString(env, programName);
    
    auto handle = std::make_shared<MdfFileHandle>();
    handle->isWriteMode = true;
    handle->version = version;
    handle->filePath = path;
    handle->program = program;
    
    return addHandle(handle);
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_addChannelGroup(
    JNIEnv* env, jclass, jlong handle, jstring name, jstring description) {
    
    auto file = getHandle(handle);
    if (!file) {
        setError("无效的文件句柄");
        return -1;
    }
    
    ChannelGroup group;
    group.index = static_cast<int>(file->groups.size());
    group.name = jstringToString(env, name);
    group.description = jstringToString(env, description);
    
    file->groups.push_back(group);
    return group.index;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_addChannel(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jstring name, 
    jstring unit, jstring description, jint dataType, jboolean isTimeChannel) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        setError("无效的通道组索引");
        return -1;
    }
    
    Channel channel;
    channel.index = static_cast<int>(file->groups[groupIndex].channels.size());
    channel.name = jstringToString(env, name);
    channel.unit = jstringToString(env, unit);
    channel.description = jstringToString(env, description);
    channel.dataType = dataType;
    channel.isTimeChannel = isTimeChannel;
    
    file->groups[groupIndex].channels.push_back(channel);
    return channel.index;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_writeChannelDataDouble(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jint channelIndex, jdoubleArray data) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        setError("无效的通道组索引");
        return -1;
    }
    
    auto& group = file->groups[groupIndex];
    if (channelIndex < 0 || channelIndex >= static_cast<int>(group.channels.size())) {
        setError("无效的通道索引");
        return -1;
    }
    
    jsize len = env->GetArrayLength(data);
    jdouble* elements = env->GetDoubleArrayElements(data, nullptr);
    
    auto& channel = group.channels[channelIndex];
    channel.doubleData.clear();
    channel.doubleData.reserve(len);
    for (jsize i = 0; i < len; i++) {
        channel.doubleData.push_back(elements[i]);
    }
    
    env->ReleaseDoubleArrayElements(data, elements, JNI_ABORT);
    return 0;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_writeChannelDataLong(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jint channelIndex, jlongArray data) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        setError("无效的通道组索引");
        return -1;
    }
    
    auto& group = file->groups[groupIndex];
    if (channelIndex < 0 || channelIndex >= static_cast<int>(group.channels.size())) {
        setError("无效的通道索引");
        return -1;
    }
    
    jsize len = env->GetArrayLength(data);
    jlong* elements = env->GetLongArrayElements(data, nullptr);
    
    auto& channel = group.channels[channelIndex];
    channel.longData.clear();
    channel.longData.reserve(len);
    for (jsize i = 0; i < len; i++) {
        channel.longData.push_back(elements[i]);
    }
    
    env->ReleaseLongArrayElements(data, elements, JNI_ABORT);
    return 0;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_writeChannelDataInt(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jint channelIndex, jintArray data) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        setError("无效的通道组索引");
        return -1;
    }
    
    auto& group = file->groups[groupIndex];
    if (channelIndex < 0 || channelIndex >= static_cast<int>(group.channels.size())) {
        setError("无效的通道索引");
        return -1;
    }
    
    jsize len = env->GetArrayLength(data);
    jint* elements = env->GetIntArrayElements(data, nullptr);
    
    auto& channel = group.channels[channelIndex];
    channel.intData.clear();
    channel.intData.reserve(len);
    for (jsize i = 0; i < len; i++) {
        channel.intData.push_back(elements[i]);
    }
    
    env->ReleaseIntArrayElements(data, elements, JNI_ABORT);
    return 0;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_writeChannelDataString(
    JNIEnv* env, jclass, jlong handle, jint groupIndex, jint channelIndex, jobjectArray data) {
    
    auto file = getHandle(handle);
    if (!file || groupIndex < 0 || groupIndex >= static_cast<int>(file->groups.size())) {
        setError("无效的通道组索引");
        return -1;
    }
    
    auto& group = file->groups[groupIndex];
    if (channelIndex < 0 || channelIndex >= static_cast<int>(group.channels.size())) {
        setError("无效的通道索引");
        return -1;
    }
    
    jsize len = env->GetArrayLength(data);
    auto& channel = group.channels[channelIndex];
    channel.stringData.clear();
    channel.stringData.reserve(len);
    
    for (jsize i = 0; i < len; i++) {
        jstring jstr = (jstring)env->GetObjectArrayElement(data, i);
        channel.stringData.push_back(jstringToString(env, jstr));
        env->DeleteLocalRef(jstr);
    }
    
    return 0;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_saveAndClose(JNIEnv*, jclass, jlong handle) {
    auto file = getHandle(handle);
    if (!file) {
        setError("无效的文件句柄");
        return -1;
    }
    
    // 写入文件（简化实现）
    std::ofstream out(file->filePath, std::ios::binary);
    if (!out.is_open()) {
        setError("无法创建文件: " + file->filePath);
        return -1;
    }
    
    // 写入简单的MDF文件头
    if (file->version == 3) {
        // MDF 3.0 头
        char header[512];
        std::memset(header, 0, 512);
        std::memcpy(header, "MDF     ", 8);
        header[8] = 3;  // 版本 3.0
        out.write(header, 512);
    } else {
        // MDF 4.0 头
        char header[64];
        std::memset(header, 0, 64);
        // MDF 4.0 使用 ID 块
        out.write(header, 64);
    }
    
    // 写入数据块（简化）
    for (const auto& group : file->groups) {
        for (const auto& channel : group.channels) {
            if (!channel.doubleData.empty()) {
                out.write(reinterpret_cast<const char*>(channel.doubleData.data()), 
                         channel.doubleData.size() * sizeof(double));
            } else if (!channel.intData.empty()) {
                out.write(reinterpret_cast<const char*>(channel.intData.data()), 
                         channel.intData.size() * sizeof(int));
            }
        }
    }
    
    out.close();
    removeHandle(handle);
    return 0;
}

JNIEXPORT jstring JNICALL Java_com_example_mdflib_MdfLibJNI_getLastError(JNIEnv* env, jclass) {
    return stringToJstring(env, g_lastError);
}

JNIEXPORT jboolean JNICALL Java_com_example_mdflib_MdfLibJNI_isValidMdfFile(JNIEnv* env, jclass, jstring filePath) {
    std::string path = jstringToString(env, filePath);
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        return JNI_FALSE;
    }
    
    char header[8];
    file.read(header, 8);
    file.close();
    
    // 检查 MDF 3 签名
    if (std::memcmp(header, "MDF", 3) == 0) {
        return JNI_TRUE;
    }
    
    // 检查 MDF 4 签名
    if (header[0] == 0 && header[1] == 0 && header[2] == 0 && header[3] == 0) {
        // 可能是 MDF 4，需要进一步检查
        return JNI_TRUE;
    }
    
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_com_example_mdflib_MdfLibJNI_getMdfVersion(JNIEnv* env, jclass, jstring filePath) {
    std::string path = jstringToString(env, filePath);
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        return -1;
    }
    
    char header[64];
    file.read(header, 64);
    file.close();
    
    // 检查 MDF 3
    if (std::memcmp(header, "MDF", 3) == 0) {
        return 3;
    }
    
    // 默认为 MDF 4
    return 4;
}
