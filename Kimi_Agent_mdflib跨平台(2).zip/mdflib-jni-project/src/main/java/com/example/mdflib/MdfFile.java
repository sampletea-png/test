package com.example.mdflib;

import java.util.*;

/**
 * MDF 文件操作类
 * 
 * 提供面向对象的 MDF 文件读写接口
 */
public class MdfFile implements AutoCloseable {
    
    private long handle = -1;
    private final String filePath;
    private final boolean isWriteMode;
    private boolean isOpen = false;
    
    /**
     * 构造函数（读取模式）
     * @param filePath MDF文件路径
     */
    public MdfFile(String filePath) {
        this.filePath = filePath;
        this.isWriteMode = false;
    }
    
    /**
     * 构造函数（写入模式）
     * @param filePath MDF文件路径
     * @param version MDF版本（3或4）
     * @param programName 程序名称
     */
    public MdfFile(String filePath, int version, String programName) {
        this.filePath = filePath;
        this.isWriteMode = true;
        this.handle = MdfLibJNI.createFile(filePath, version, programName);
        if (this.handle < 0) {
            throw new MdfException("无法创建MDF文件: " + MdfLibJNI.getLastError());
        }
        this.isOpen = true;
    }
    
    /**
     * 打开文件进行读取
     */
    public void open() {
        if (isWriteMode) {
            throw new MdfException("写入模式下不能打开文件进行读取");
        }
        if (isOpen) {
            return;
        }
        this.handle = MdfLibJNI.openFile(filePath);
        if (this.handle < 0) {
            throw new MdfException("无法打开MDF文件: " + MdfLibJNI.getLastError());
        }
        this.isOpen = true;
    }
    
    @Override
    public void close() {
        if (isOpen && handle >= 0) {
            if (isWriteMode) {
                MdfLibJNI.saveAndClose(handle);
            } else {
                MdfLibJNI.closeFile(handle);
            }
            isOpen = false;
            handle = -1;
        }
    }
    
    /**
     * 获取文件信息
     */
    public MdfFileInfo getFileInfo() {
        ensureOpen();
        String json = MdfLibJNI.getFileInfo(handle);
        return MdfJsonParser.parseFileInfo(json);
    }
    
    /**
     * 获取所有通道组
     */
    public List<MdfChannelGroup> getChannelGroups() {
        ensureOpen();
        String json = MdfLibJNI.getChannelGroups(handle);
        return MdfJsonParser.parseChannelGroups(json);
    }
    
    /**
     * 获取指定通道组
     */
    public MdfChannelGroup getChannelGroup(int index) {
        List<MdfChannelGroup> groups = getChannelGroups();
        if (index < 0 || index >= groups.size()) {
            throw new IndexOutOfBoundsException("通道组索引越界: " + index);
        }
        return groups.get(index);
    }
    
    /**
     * 获取通道组中的通道
     */
    public List<MdfChannel> getChannels(int groupIndex) {
        ensureOpen();
        String json = MdfLibJNI.getChannels(handle, groupIndex);
        return MdfJsonParser.parseChannels(json);
    }
    
    /**
     * 读取通道数据（double类型）
     */
    public double[] readChannelDataDouble(int groupIndex, int channelIndex, 
                                          long startSample, long count) {
        ensureOpen();
        String json = MdfLibJNI.readChannelData(handle, groupIndex, channelIndex, 
                                                  startSample, count);
        return MdfJsonParser.parseDoubleArray(json);
    }
    
    /**
     * 读取通道所有数据（double类型）
     */
    public double[] readChannelDataDouble(int groupIndex, int channelIndex) {
        long count = getRecordCount(groupIndex);
        return readChannelDataDouble(groupIndex, channelIndex, 0, count);
    }
    
    /**
     * 读取通道数据（long类型）
     */
    public long[] readChannelDataLong(int groupIndex, int channelIndex, 
                                      long startSample, long count) {
        ensureOpen();
        String json = MdfLibJNI.readChannelData(handle, groupIndex, channelIndex, 
                                                  startSample, count);
        return MdfJsonParser.parseLongArray(json);
    }
    
    /**
     * 读取通道所有数据（long类型）
     */
    public long[] readChannelDataLong(int groupIndex, int channelIndex) {
        long count = getRecordCount(groupIndex);
        return readChannelDataLong(groupIndex, channelIndex, 0, count);
    }
    
    /**
     * 获取记录数
     */
    public long getRecordCount(int groupIndex) {
        ensureOpen();
        return MdfLibJNI.getRecordCount(handle, groupIndex);
    }
    
    // ==================== 写入操作 ====================
    
    /**
     * 添加通道组
     */
    public int addChannelGroup(String name, String description) {
        ensureWriteMode();
        return MdfLibJNI.addChannelGroup(handle, name, description);
    }
    
    /**
     * 添加通道
     */
    public int addChannel(int groupIndex, String name, String unit, 
                          String description, DataType dataType, boolean isTimeChannel) {
        ensureWriteMode();
        return MdfLibJNI.addChannel(handle, groupIndex, name, unit, description, 
                                     dataType.getValue(), isTimeChannel);
    }
    
    /**
     * 添加数值通道
     */
    public int addChannel(int groupIndex, String name, String unit, 
                          String description, DataType dataType) {
        return addChannel(groupIndex, name, unit, description, dataType, false);
    }
    
    /**
     * 添加时间通道
     */
    public int addTimeChannel(int groupIndex, String name, String unit) {
        return addChannel(groupIndex, name, unit, "Time channel", DataType.DOUBLE, true);
    }
    
    /**
     * 写入double数据
     */
    public void writeChannelData(int groupIndex, int channelIndex, double[] data) {
        ensureWriteMode();
        int result = MdfLibJNI.writeChannelDataDouble(handle, groupIndex, channelIndex, data);
        if (result != 0) {
            throw new MdfException("写入数据失败: " + MdfLibJNI.getLastError());
        }
    }
    
    /**
     * 写入long数据
     */
    public void writeChannelData(int groupIndex, int channelIndex, long[] data) {
        ensureWriteMode();
        int result = MdfLibJNI.writeChannelDataLong(handle, groupIndex, channelIndex, data);
        if (result != 0) {
            throw new MdfException("写入数据失败: " + MdfLibJNI.getLastError());
        }
    }
    
    /**
     * 写入int数据
     */
    public void writeChannelData(int groupIndex, int channelIndex, int[] data) {
        ensureWriteMode();
        int result = MdfLibJNI.writeChannelDataInt(handle, groupIndex, channelIndex, data);
        if (result != 0) {
            throw new MdfException("写入数据失败: " + MdfLibJNI.getLastError());
        }
    }
    
    /**
     * 写入字符串数据
     */
    public void writeChannelData(int groupIndex, int channelIndex, String[] data) {
        ensureWriteMode();
        int result = MdfLibJNI.writeChannelDataString(handle, groupIndex, channelIndex, data);
        if (result != 0) {
            throw new MdfException("写入数据失败: " + MdfLibJNI.getLastError());
        }
    }
    
    // ==================== 辅助方法 ====================
    
    private void ensureOpen() {
        if (!isOpen) {
            throw new IllegalStateException("文件未打开");
        }
    }
    
    private void ensureWriteMode() {
        if (!isWriteMode) {
            throw new MdfException("当前不是写入模式");
        }
    }
    
    public boolean isOpen() {
        return isOpen;
    }
    
    public boolean isWriteMode() {
        return isWriteMode;
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    // ==================== 静态工具方法 ====================
    
    /**
     * 检查文件是否为有效的MDF文件
     */
    public static boolean isValidMdfFile(String filePath) {
        return MdfLibJNI.isValidMdfFile(filePath);
    }
    
    /**
     * 获取MDF文件版本
     */
    public static int getMdfVersion(String filePath) {
        return MdfLibJNI.getMdfVersion(filePath);
    }
    
    /**
     * 获取库版本信息
     */
    public static String getVersion() {
        return MdfLibJNI.getVersion();
    }
    
    /**
     * 获取本地库信息
     */
    public static String getNativeLibInfo() {
        return MdfLibJNI.getNativeLibInfo();
    }
}
