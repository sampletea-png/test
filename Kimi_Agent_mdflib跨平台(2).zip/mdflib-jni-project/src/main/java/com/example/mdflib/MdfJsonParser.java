package com.example.mdflib;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * MDF JSON 数据解析器
 * 
 * 简单的JSON解析器，用于解析JNI返回的JSON字符串
 */
public class MdfJsonParser {
    
    /**
     * 解析文件信息
     */
    public static MdfFileInfo parseFileInfo(String json) {
        MdfFileInfo info = new MdfFileInfo();
        if (json == null || json.isEmpty()) {
            return info;
        }
        
        Map<String, String> map = parseSimpleJson(json);
        info.setFileName(getString(map, "fileName"));
        info.setVersion(getInt(map, "version"));
        info.setVersionString(getString(map, "versionString"));
        info.setProgram(getString(map, "program"));
        info.setAuthor(getString(map, "author"));
        info.setOrganization(getString(map, "organization"));
        info.setProject(getString(map, "project"));
        info.setSubject(getString(map, "subject"));
        info.setComment(getString(map, "comment"));
        info.setFileSize(getLong(map, "fileSize"));
        info.setDataGroupCount(getInt(map, "dataGroupCount"));
        
        String timeStr = getString(map, "creationTime");
        if (!timeStr.isEmpty()) {
            try {
                info.setCreationTime(LocalDateTime.parse(timeStr, 
                    DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            } catch (Exception e) {
                // 忽略解析错误
            }
        }
        
        return info;
    }
    
    /**
     * 解析通道组列表
     */
    public static List<MdfChannelGroup> parseChannelGroups(String json) {
        List<MdfChannelGroup> groups = new ArrayList<>();
        if (json == null || json.isEmpty()) {
            return groups;
        }
        
        // 解析JSON数组
        List<String> objects = parseJsonArray(json);
        for (String obj : objects) {
            groups.add(parseChannelGroup(obj));
        }
        
        return groups;
    }
    
    /**
     * 解析单个通道组
     */
    public static MdfChannelGroup parseChannelGroup(String json) {
        MdfChannelGroup group = new MdfChannelGroup();
        Map<String, String> map = parseSimpleJson(json);
        
        group.setIndex(getInt(map, "index"));
        group.setName(getString(map, "name"));
        group.setDescription(getString(map, "description"));
        group.setRecordCount(getLong(map, "recordCount"));
        group.setRecordSize(getLong(map, "recordSize"));
        
        return group;
    }
    
    /**
     * 解析通道列表
     */
    public static List<MdfChannel> parseChannels(String json) {
        List<MdfChannel> channels = new ArrayList<>();
        if (json == null || json.isEmpty()) {
            return channels;
        }
        
        List<String> objects = parseJsonArray(json);
        for (String obj : objects) {
            channels.add(parseChannel(obj));
        }
        
        return channels;
    }
    
    /**
     * 解析单个通道
     */
    public static MdfChannel parseChannel(String json) {
        MdfChannel channel = new MdfChannel();
        Map<String, String> map = parseSimpleJson(json);
        
        channel.setIndex(getInt(map, "index"));
        channel.setName(getString(map, "name"));
        channel.setUnit(getString(map, "unit"));
        channel.setDescription(getString(map, "description"));
        channel.setTimeChannel(getBoolean(map, "timeChannel"));
        channel.setDataCount(getLong(map, "dataCount"));
        channel.setMinValue(getDouble(map, "minValue"));
        channel.setMaxValue(getDouble(map, "maxValue"));
        
        int typeValue = getInt(map, "dataType");
        try {
            channel.setDataType(DataType.fromValue(typeValue));
        } catch (Exception e) {
            channel.setDataType(DataType.DOUBLE);
        }
        
        return channel;
    }
    
    /**
     * 解析double数组
     */
    public static double[] parseDoubleArray(String json) {
        if (json == null || json.isEmpty()) {
            return new double[0];
        }
        
        List<String> values = parseJsonArray(json);
        double[] result = new double[values.size()];
        for (int i = 0; i < values.size(); i++) {
            try {
                result[i] = Double.parseDouble(values.get(i).trim());
            } catch (NumberFormatException e) {
                result[i] = Double.NaN;
            }
        }
        return result;
    }
    
    /**
     * 解析long数组
     */
    public static long[] parseLongArray(String json) {
        if (json == null || json.isEmpty()) {
            return new long[0];
        }
        
        List<String> values = parseJsonArray(json);
        long[] result = new long[values.size()];
        for (int i = 0; i < values.size(); i++) {
            try {
                result[i] = Long.parseLong(values.get(i).trim());
            } catch (NumberFormatException e) {
                result[i] = 0;
            }
        }
        return result;
    }
    
    /**
     * 解析int数组
     */
    public static int[] parseIntArray(String json) {
        if (json == null || json.isEmpty()) {
            return new int[0];
        }
        
        List<String> values = parseJsonArray(json);
        int[] result = new int[values.size()];
        for (int i = 0; i < values.size(); i++) {
            try {
                result[i] = Integer.parseInt(values.get(i).trim());
            } catch (NumberFormatException e) {
                result[i] = 0;
            }
        }
        return result;
    }
    
    // ==================== 私有辅助方法 ====================
    
    /**
     * 解析简单JSON对象
     */
    private static Map<String, String> parseSimpleJson(String json) {
        Map<String, String> map = new HashMap<>();
        if (json == null || json.isEmpty()) {
            return map;
        }
        
        // 去除首尾大括号
        json = json.trim();
        if (json.startsWith("{")) json = json.substring(1);
        if (json.endsWith("}")) json = json.substring(0, json.length() - 1);
        
        // 解析键值对
        String[] pairs = splitJsonPairs(json);
        for (String pair : pairs) {
            int colonIndex = pair.indexOf(':');
            if (colonIndex > 0) {
                String key = pair.substring(0, colonIndex).trim();
                String value = pair.substring(colonIndex + 1).trim();
                
                // 去除引号
                key = unquote(key);
                value = unquote(value);
                
                map.put(key, value);
            }
        }
        
        return map;
    }
    
    /**
     * 解析JSON数组
     */
    private static List<String> parseJsonArray(String json) {
        List<String> list = new ArrayList<>();
        if (json == null || json.isEmpty()) {
            return list;
        }
        
        json = json.trim();
        if (json.startsWith("[")) json = json.substring(1);
        if (json.endsWith("]")) json = json.substring(0, json.length() - 1);
        
        // 解析数组元素
        String[] elements = splitJsonArray(json);
        for (String elem : elements) {
            elem = elem.trim();
            if (!elem.isEmpty()) {
                list.add(elem);
            }
        }
        
        return list;
    }
    
    /**
     * 分割JSON键值对
     */
    private static String[] splitJsonPairs(String json) {
        List<String> pairs = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int depth = 0;
        boolean inString = false;
        
        for (char c : json.toCharArray()) {
            if (c == '"' && (current.length() == 0 || current.charAt(current.length() - 1) != '\\')) {
                inString = !inString;
            }
            
            if (!inString) {
                if (c == '{' || c == '[') depth++;
                if (c == '}' || c == ']') depth--;
                
                if (c == ',' && depth == 0) {
                    pairs.add(current.toString());
                    current = new StringBuilder();
                    continue;
                }
            }
            
            current.append(c);
        }
        
        if (current.length() > 0) {
            pairs.add(current.toString());
        }
        
        return pairs.toArray(new String[0]);
    }
    
    /**
     * 分割JSON数组
     */
    private static String[] splitJsonArray(String json) {
        return splitJsonPairs(json);
    }
    
    /**
     * 去除引号
     */
    private static String unquote(String s) {
        s = s.trim();
        if ((s.startsWith("\"") && s.endsWith("\"")) || 
            (s.startsWith("'") && s.endsWith("'"))) {
            s = s.substring(1, s.length() - 1);
        }
        return s;
    }
    
    private static String getString(Map<String, String> map, String key) {
        String value = map.get(key);
        return value != null ? value : "";
    }
    
    private static int getInt(Map<String, String> map, String key) {
        try {
            return Integer.parseInt(getString(map, key));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    private static long getLong(Map<String, String> map, String key) {
        try {
            return Long.parseLong(getString(map, key));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    private static double getDouble(Map<String, String> map, String key) {
        try {
            return Double.parseDouble(getString(map, key));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
    
    private static boolean getBoolean(Map<String, String> map, String key) {
        return Boolean.parseBoolean(getString(map, key));
    }
}
