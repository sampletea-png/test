package com.example.mdflib;

/**
 * MDF 通道数据类型枚举
 */
public enum DataType {
    DOUBLE(0, "DOUBLE", double.class),
    FLOAT(1, "FLOAT", float.class),
    INT64(2, "INT64", long.class),
    INT32(3, "INT32", int.class),
    INT16(4, "INT16", short.class),
    INT8(5, "INT8", byte.class),
    UINT64(6, "UINT64", long.class),
    UINT32(7, "UINT32", long.class),
    UINT16(8, "UINT16", int.class),
    UINT8(9, "UINT8", int.class),
    STRING(10, "STRING", String.class);
    
    private final int value;
    private final String name;
    private final Class<?> javaType;
    
    DataType(int value, String name, Class<?> javaType) {
        this.value = value;
        this.name = name;
        this.javaType = javaType;
    }
    
    public int getValue() {
        return value;
    }
    
    public String getName() {
        return name;
    }
    
    public Class<?> getJavaType() {
        return javaType;
    }
    
    public static DataType fromValue(int value) {
        for (DataType type : values()) {
            if (type.value == value) {
                return type;
            }
        }
        throw new IllegalArgumentException("未知的数据类型值: " + value);
    }
    
    public static DataType fromName(String name) {
        for (DataType type : values()) {
            if (type.name.equalsIgnoreCase(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException("未知的数据类型名称: " + name);
    }
}
