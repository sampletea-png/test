package com.example.mdflib;

import java.io.*;
import java.util.*;

/**
 * MDF 工具主程序
 * 
 * 命令行工具，用于读取和写入 MDF 文件
 */
public class MdfTool {
    
    public static void main(String[] args) {
        if (args.length == 0) {
            printHelp();
            return;
        }
        
        String command = args[0].toLowerCase();
        
        try {
            switch (command) {
                case "info":
                    if (args.length < 2) {
                        System.err.println("错误: 请指定MDF文件路径");
                        System.exit(1);
                    }
                    showInfo(args[1]);
                    break;
                    
                case "read":
                    if (args.length < 2) {
                        System.err.println("错误: 请指定MDF文件路径");
                        System.exit(1);
                    }
                    readFile(args[1]);
                    break;
                    
                case "write":
                    if (args.length < 2) {
                        System.err.println("错误: 请指定输出文件路径");
                        System.exit(1);
                    }
                    writeSampleFile(args[1]);
                    break;
                    
                case "convert":
                    if (args.length < 3) {
                        System.err.println("错误: 请指定输入和输出文件路径");
                        System.exit(1);
                    }
                    convertFile(args[1], args[2]);
                    break;
                    
                case "version":
                    showVersion();
                    break;
                    
                case "help":
                case "-h":
                case "--help":
                    printHelp();
                    break;
                    
                default:
                    System.err.println("错误: 未知命令: " + command);
                    printHelp();
                    System.exit(1);
            }
        } catch (Exception e) {
            System.err.println("错误: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     * 显示帮助信息
     */
    private static void printHelp() {
        System.out.println("========================================");
        System.out.println("MDF 工具 - 使用 mdflib + JNI");
        System.out.println("========================================");
        System.out.println();
        System.out.println("用法: java -jar mdflib-jni-1.0.0.jar <命令> [参数]");
        System.out.println();
        System.out.println("命令:");
        System.out.println("  info <文件>        显示MDF文件信息");
        System.out.println("  read <文件>        读取并显示MDF文件内容");
        System.out.println("  write <文件>       创建示例MDF文件");
        System.out.println("  convert <in> <out> 转换MDF文件格式");
        System.out.println("  version            显示版本信息");
        System.out.println("  help               显示此帮助信息");
        System.out.println();
        System.out.println("示例:");
        System.out.println("  java -jar mdflib-jni-1.0.0.jar info data.mf4");
        System.out.println("  java -jar mdflib-jni-1.0.0.jar read data.mf4");
        System.out.println("  java -jar mdflib-jni-1.0.0.jar write output.mf4");
        System.out.println();
        System.out.println("环境要求:");
        System.out.println("  - JDK 21 或更高版本");
        System.out.println("  - Windows 或 Linux 操作系统");
        System.out.println();
        System.out.println("版本: " + MdfFile.getVersion());
        System.out.println("========================================");
    }
    
    /**
     * 显示版本信息
     */
    private static void showVersion() {
        System.out.println("MDF 工具版本: " + MdfFile.getVersion());
        System.out.println("本地库信息: " + MdfFile.getNativeLibInfo());
        System.out.println("Java版本: " + System.getProperty("java.version"));
        System.out.println("操作系统: " + System.getProperty("os.name"));
    }
    
    /**
     * 显示文件信息
     */
    private static void showInfo(String filePath) {
        System.out.println("========================================");
        System.out.println("MDF 文件信息");
        System.out.println("========================================");
        System.out.println("文件路径: " + filePath);
        System.out.println();
        
        // 检查文件是否存在
        File file = new File(filePath);
        if (!file.exists()) {
            System.err.println("错误: 文件不存在");
            System.exit(1);
        }
        
        // 检查是否为有效的MDF文件
        if (!MdfFile.isValidMdfFile(filePath)) {
            System.err.println("错误: 不是有效的MDF文件");
            System.exit(1);
        }
        
        int version = MdfFile.getMdfVersion(filePath);
        System.out.println("MDF版本: " + version);
        System.out.println("文件大小: " + formatFileSize(file.length()));
        System.out.println();
        
        try (MdfFile mdfFile = new MdfFile(filePath)) {
            mdfFile.open();
            MdfFileInfo info = mdfFile.getFileInfo();
            
            System.out.println("【基本信息】");
            System.out.println("  程序: " + info.getProgram());
            System.out.println("  作者: " + info.getAuthor());
            System.out.println("  组织: " + info.getOrganization());
            System.out.println("  项目: " + info.getProject());
            System.out.println("  主题: " + info.getSubject());
            System.out.println("  创建时间: " + info.getCreationTime());
            System.out.println();
            
            System.out.println("【通道组信息】");
            List<MdfChannelGroup> groups = mdfFile.getChannelGroups();
            System.out.println("  通道组数量: " + groups.size());
            System.out.println();
            
            for (MdfChannelGroup group : groups) {
                System.out.println("  【通道组 " + group.getIndex() + "】");
                System.out.println("    名称: " + group.getName());
                System.out.println("    描述: " + group.getDescription());
                System.out.println("    记录数: " + group.getRecordCount());
                System.out.println("    记录大小: " + group.getRecordSize() + " 字节");
                
                List<MdfChannel> channels = mdfFile.getChannels(group.getIndex());
                System.out.println("    通道数量: " + channels.size());
                
                for (MdfChannel channel : channels) {
                    System.out.println("      - " + channel.getName() + 
                        " [" + channel.getDataType() + "]" +
                        (channel.getUnit().isEmpty() ? "" : " (" + channel.getUnit() + ")"));
                }
                System.out.println();
            }
        }
        
        System.out.println("========================================");
    }
    
    /**
     * 读取并显示文件内容
     */
    private static void readFile(String filePath) {
        System.out.println("========================================");
        System.out.println("读取 MDF 文件");
        System.out.println("========================================");
        System.out.println("文件路径: " + filePath);
        System.out.println();
        
        File file = new File(filePath);
        if (!file.exists()) {
            System.err.println("错误: 文件不存在");
            System.exit(1);
        }
        
        try (MdfFile mdfFile = new MdfFile(filePath)) {
            mdfFile.open();
            
            List<MdfChannelGroup> groups = mdfFile.getChannelGroups();
            for (MdfChannelGroup group : groups) {
                System.out.println("【通道组: " + group.getName() + "】");
                System.out.println("记录数: " + group.getRecordCount());
                System.out.println();
                
                List<MdfChannel> channels = mdfFile.getChannels(group.getIndex());
                
                // 读取前10条记录
                long sampleCount = Math.min(group.getRecordCount(), 10);
                if (sampleCount == 0) {
                    System.out.println("  (无数据)");
                    continue;
                }
                
                // 打印表头
                System.out.print("  序号");
                for (MdfChannel channel : channels) {
                    System.out.print(" | " + channel.getName());
                }
                System.out.println();
                System.out.println("  " + "-".repeat(60));
                
                // 读取并显示数据
                for (int i = 0; i < channels.size(); i++) {
                    MdfChannel channel = channels.get(i);
                    double[] data = mdfFile.readChannelDataDouble(group.getIndex(), i, 0, sampleCount);
                    
                    for (int j = 0; j < data.length; j++) {
                        if (i == 0) {
                            System.out.print("  [" + j + "]");
                        }
                        System.out.printf(" | %.4f", data[j]);
                        if (i == channels.size() - 1) {
                            System.out.println();
                        }
                    }
                }
                
                if (group.getRecordCount() > 10) {
                    System.out.println("  ... (共 " + group.getRecordCount() + " 条记录)");
                }
                System.out.println();
            }
        }
        
        System.out.println("========================================");
    }
    
    /**
     * 创建示例MDF文件
     */
    private static void writeSampleFile(String filePath) {
        System.out.println("========================================");
        System.out.println("创建示例 MDF 文件");
        System.out.println("========================================");
        System.out.println("输出文件: " + filePath);
        System.out.println();
        
        // 删除已存在的文件
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
        
        // 创建MDF 4.0文件
        try (MdfFile mdfFile = new MdfFile(filePath, 4, "MdfTool")) {
            System.out.println("正在创建文件...");
            
            // 添加通道组
            int groupIndex = mdfFile.addChannelGroup("TestData", "Test measurement data");
            System.out.println("添加通道组: " + groupIndex);
            
            // 添加时间通道
            int timeChannel = mdfFile.addTimeChannel(groupIndex, "Time", "s");
            System.out.println("添加时间通道: " + timeChannel);
            
            // 添加数据通道
            int speedChannel = mdfFile.addChannel(groupIndex, "Speed", "km/h", 
                "Vehicle speed", DataType.DOUBLE);
            System.out.println("添加速度通道: " + speedChannel);
            
            int tempChannel = mdfFile.addChannel(groupIndex, "Temperature", "°C", 
                "Engine temperature", DataType.DOUBLE);
            System.out.println("添加温度通道: " + tempChannel);
            
            int rpmChannel = mdfFile.addChannel(groupIndex, "RPM", "rpm", 
                "Engine RPM", DataType.INT32);
            System.out.println("添加转速通道: " + rpmChannel);
            
            // 生成示例数据
            int sampleCount = 100;
            double[] timeData = new double[sampleCount];
            double[] speedData = new double[sampleCount];
            double[] tempData = new double[sampleCount];
            int[] rpmData = new int[sampleCount];
            
            for (int i = 0; i < sampleCount; i++) {
                timeData[i] = i * 0.1;  // 0.1秒间隔
                speedData[i] = Math.sin(i * 0.1) * 50 + 60;  // 10-110 km/h
                tempData[i] = 80 + Math.random() * 20;  // 80-100 °C
                rpmData[i] = 1000 + (int)(Math.random() * 3000);  // 1000-4000 rpm
            }
            
            System.out.println("写入数据...");
            mdfFile.writeChannelData(groupIndex, timeChannel, timeData);
            mdfFile.writeChannelData(groupIndex, speedChannel, speedData);
            mdfFile.writeChannelData(groupIndex, tempChannel, tempData);
            mdfFile.writeChannelData(groupIndex, rpmChannel, rpmData);
            
            System.out.println("写入 " + sampleCount + " 条记录");
            System.out.println();
            System.out.println("文件创建成功!");
        }
        
        // 显示文件信息
        File createdFile = new File(filePath);
        System.out.println("文件大小: " + formatFileSize(createdFile.length()));
        System.out.println("========================================");
    }
    
    /**
     * 转换文件格式
     */
    private static void convertFile(String inputPath, String outputPath) {
        System.out.println("========================================");
        System.out.println("转换 MDF 文件");
        System.out.println("========================================");
        System.out.println("输入文件: " + inputPath);
        System.out.println("输出文件: " + outputPath);
        System.out.println();
        
        File inputFile = new File(inputPath);
        if (!inputFile.exists()) {
            System.err.println("错误: 输入文件不存在");
            System.exit(1);
        }
        
        // 删除已存在的输出文件
        File outputFile = new File(outputPath);
        if (outputFile.exists()) {
            outputFile.delete();
        }
        
        // 读取输入文件
        try (MdfFile inputMdf = new MdfFile(inputPath)) {
            inputMdf.open();
            
            // 获取输入文件版本
            int inputVersion = MdfFile.getMdfVersion(inputPath);
            int outputVersion = (inputVersion == 3) ? 4 : 3;
            
            System.out.println("输入文件版本: MDF " + inputVersion);
            System.out.println("输出文件版本: MDF " + outputVersion);
            System.out.println();
            
            // 创建输出文件
            try (MdfFile outputMdf = new MdfFile(outputPath, outputVersion, "MdfTool Converter")) {
                List<MdfChannelGroup> groups = inputMdf.getChannelGroups();
                
                for (MdfChannelGroup group : groups) {
                    System.out.println("转换通道组: " + group.getName());
                    
                    // 添加通道组
                    int newGroupIndex = outputMdf.addChannelGroup(group.getName(), group.getDescription());
                    
                    // 获取通道并转换
                    List<MdfChannel> channels = inputMdf.getChannels(group.getIndex());
                    long recordCount = group.getRecordCount();
                    
                    // 添加通道
                    int[] newChannelIndices = new int[channels.size()];
                    for (int i = 0; i < channels.size(); i++) {
                        MdfChannel channel = channels.get(i);
                        newChannelIndices[i] = outputMdf.addChannel(newGroupIndex, 
                            channel.getName(), channel.getUnit(), channel.getDescription(), 
                            channel.getDataType(), channel.isTimeChannel());
                    }
                    
                    // 读取并写入数据
                    int batchSize = 1000;
                    for (long start = 0; start < recordCount; start += batchSize) {
                        long count = Math.min(batchSize, recordCount - start);
                        
                        for (int i = 0; i < channels.size(); i++) {
                            MdfChannel channel = channels.get(i);
                            
                            switch (channel.getDataType()) {
                                case INT32:
                                case UINT32:
                                    int[] intData = inputMdf.readChannelDataInt(group.getIndex(), i, start, count);
                                    outputMdf.writeChannelData(newGroupIndex, newChannelIndices[i], intData);
                                    break;
                                default:
                                    double[] doubleData = inputMdf.readChannelDataDouble(group.getIndex(), i, start, count);
                                    outputMdf.writeChannelData(newGroupIndex, newChannelIndices[i], doubleData);
                                    break;
                            }
                        }
                        
                        System.out.println("  已转换 " + Math.min(start + count, recordCount) + "/" + recordCount + " 条记录");
                    }
                }
                
                System.out.println();
                System.out.println("转换完成!");
            }
        }
        
        File resultFile = new File(outputPath);
        System.out.println("输出文件大小: " + formatFileSize(resultFile.length()));
        System.out.println("========================================");
    }
    
    /**
     * 格式化文件大小
     */
    private static String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.2f MB", size / (1024.0 * 1024));
        } else {
            return String.format("%.2f GB", size / (1024.0 * 1024 * 1024));
        }
    }
}
