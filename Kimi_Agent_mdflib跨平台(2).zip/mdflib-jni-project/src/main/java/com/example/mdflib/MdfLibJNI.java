package com.example.mdflib;

import java.io.*;
import java.nio.file.*;

/**
 * MDFLib JNI 接口类
 * 
 * 提供对 mdflib C++ 库的 JNI 调用接口
 * 支持 MDF 文件的读写操作
 */
public class MdfLibJNI {
    
    // 加载本地库
    static {
        loadNativeLibrary();
    }
    
    /**
     * 自动加载本地库
     * 从JAR包中提取并加载对应平台的库文件
     */
    private static void loadNativeLibrary() {
        String osName = System.getProperty("os.name").toLowerCase();
        String libName;
        
        if (osName.contains("win")) {
            libName = "mdflib_jni.dll";
        } else if (osName.contains("nix") || osName.contains("nux") || osName.contains("aix")) {
            libName = "libmdflib_jni.so";
        } else if (osName.contains("mac")) {
            libName = "libmdflib_jni.dylib";
        } else {
            throw new RuntimeException("不支持的操作系统: " + osName);
        }
        
        try {
            // 尝试从JAR中提取并加载库
            loadLibraryFromJar(libName);
        } catch (Exception e) {
            // 如果提取失败，尝试从java.library.path加载
            try {
                System.loadLibrary("mdflib_jni");
            } catch (UnsatisfiedLinkError e2) {
                throw new RuntimeException("无法加载本地库 " + libName + ": " + e.getMessage(), e);
            }
        }
    }
    
    /**
     * 从JAR包中提取并加载本地库
     */
    private static void loadLibraryFromJar(String libName) throws IOException {
        // 创建临时目录
        Path tempDir = Files.createTempDirectory("mdflib_jni_");
        tempDir.toFile().deleteOnExit();
        
        // 库文件在JAR中的路径
        String libPathInJar = "/native/" + libName;
        
        // 提取库文件
        Path tempLib = tempDir.resolve(libName);
        
        try (InputStream is = MdfLibJNI.class.getResourceAsStream(libPathInJar)) {
            if (is == null) {
                throw new FileNotFoundException("在JAR中找不到库文件: " + libPathInJar);
            }
            Files.copy(is, tempLib, StandardCopyOption.REPLACE_EXISTING);
        }
        
        // 加载库
        System.load(tempLib.toAbsolutePath().toString());
        
        // 设置删除钩子
        tempLib.toFile().deleteOnExit();
    }
    
    // ==================== 原生方法声明 ====================
    
    // 版本信息
    public static native String getVersion();
    public static native String getNativeLibInfo();
    
    // ==================== 文件操作 ====================
    
    /**
     * 打开MDF文件进行读取
     * @param filePath 文件路径
     * @return 文件句柄（正整数），失败返回-1
     */
    public static native long openFile(String filePath);
    
    /**
     * 关闭MDF文件
     * @param handle 文件句柄
     * @return 成功返回0
     */
    public static native int closeFile(long handle);
    
    /**
     * 获取文件信息
     * @param handle 文件句柄
     * @return 文件信息JSON字符串
     */
    public static native String getFileInfo(long handle);
    
    // ==================== 读取操作 ====================
    
    /**
     * 获取所有通道组信息
     * @param handle 文件句柄
     * @return 通道组信息JSON数组
     */
    public static native String getChannelGroups(long handle);
    
    /**
     * 获取通道组中的所有通道
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @return 通道信息JSON数组
     */
    public static native String getChannels(long handle, int groupIndex);
    
    /**
     * 读取通道数据
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param channelIndex 通道索引
     * @param startSample 起始样本
     * @param count 读取样本数
     * @return 通道数据JSON数组
     */
    public static native String readChannelData(long handle, int groupIndex, int channelIndex, 
                                                 long startSample, long count);
    
    /**
     * 读取所有通道数据（批量读取）
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param startSample 起始样本
     * @param count 读取样本数
     * @return 所有通道数据JSON对象
     */
    public static native String readAllChannelData(long handle, int groupIndex, 
                                                    long startSample, long count);
    
    /**
     * 获取记录总数
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @return 记录数
     */
    public static native long getRecordCount(long handle, int groupIndex);
    
    // ==================== 写入操作 ====================
    
    /**
     * 创建新的MDF文件
     * @param filePath 文件路径
     * @param version MDF版本（3或4）
     * @param programName 程序名称
     * @return 文件句柄（正整数），失败返回-1
     */
    public static native long createFile(String filePath, int version, String programName);
    
    /**
     * 添加通道组
     * @param handle 文件句柄
     * @param name 通道组名称
     * @param description 描述
     * @return 通道组索引
     */
    public static native int addChannelGroup(long handle, String name, String description);
    
    /**
     * 添加通道
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param name 通道名称
     * @param unit 单位
     * @param description 描述
     * @param dataType 数据类型（0=DOUBLE, 1=FLOAT, 2=INT64, 3=INT32, 4=INT16, 5=INT8, 6=UINT64, 7=UINT32, 8=UINT16, 9=UINT8, 10=STRING）
     * @param isTimeChannel 是否为时间通道
     * @return 通道索引
     */
    public static native int addChannel(long handle, int groupIndex, String name, 
                                        String unit, String description, int dataType, 
                                        boolean isTimeChannel);
    
    /**
     * 写入通道数据（double数组）
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param channelIndex 通道索引
     * @param data 数据数组
     * @return 成功返回0
     */
    public static native int writeChannelDataDouble(long handle, int groupIndex, 
                                                     int channelIndex, double[] data);
    
    /**
     * 写入通道数据（long数组）
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param channelIndex 通道索引
     * @param data 数据数组
     * @return 成功返回0
     */
    public static native int writeChannelDataLong(long handle, int groupIndex, 
                                                   int channelIndex, long[] data);
    
    /**
     * 写入通道数据（int数组）
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param channelIndex 通道索引
     * @param data 数据数组
     * @return 成功返回0
     */
    public static native int writeChannelDataInt(long handle, int groupIndex, 
                                                  int channelIndex, int[] data);
    
    /**
     * 写入通道数据（字符串数组）
     * @param handle 文件句柄
     * @param groupIndex 通道组索引
     * @param channelIndex 通道索引
     * @param data 数据数组
     * @return 成功返回0
     */
    public static native int writeChannelDataString(long handle, int groupIndex, 
                                                     int channelIndex, String[] data);
    
    /**
     * 保存并关闭写入的文件
     * @param handle 文件句柄
     * @return 成功返回0
     */
    public static native int saveAndClose(long handle);
    
    // ==================== 辅助方法 ====================
    
    /**
     * 获取最后错误信息
     * @return 错误信息字符串
     */
    public static native String getLastError();
    
    /**
     * 检查文件是否为有效的MDF文件
     * @param filePath 文件路径
     * @return 有效返回true
     */
    public static native boolean isValidMdfFile(String filePath);
    
    /**
     * 获取MDF文件版本
     * @param filePath 文件路径
     * @return 版本号（3或4），无效返回-1
     */
    public static native int getMdfVersion(String filePath);
}
