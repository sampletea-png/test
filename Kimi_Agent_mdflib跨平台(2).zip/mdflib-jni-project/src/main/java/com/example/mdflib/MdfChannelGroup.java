package com.example.mdflib;

import java.util.*;

/**
 * MDF 通道组
 */
public class MdfChannelGroup {
    
    private int index;
    private String name;
    private String description;
    private long recordCount;
    private long recordSize;
    private List<MdfChannel> channels;
    
    public MdfChannelGroup() {
        this.channels = new ArrayList<>();
    }
    
    public MdfChannelGroup(int index, String name, String description) {
        this();
        this.index = index;
        this.name = name;
        this.description = description;
    }
    
    // Getters and Setters
    
    public int getIndex() {
        return index;
    }
    
    public void setIndex(int index) {
        this.index = index;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public long getRecordCount() {
        return recordCount;
    }
    
    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }
    
    public long getRecordSize() {
        return recordSize;
    }
    
    public void setRecordSize(long recordSize) {
        this.recordSize = recordSize;
    }
    
    public List<MdfChannel> getChannels() {
        return channels;
    }
    
    public void setChannels(List<MdfChannel> channels) {
        this.channels = channels;
    }
    
    /**
     * 获取时间通道
     */
    public MdfChannel getTimeChannel() {
        for (MdfChannel channel : channels) {
            if (channel.isTimeChannel()) {
                return channel;
            }
        }
        return null;
    }
    
    /**
     * 获取指定名称的通道
     */
    public MdfChannel getChannel(String name) {
        for (MdfChannel channel : channels) {
            if (channel.getName().equals(name)) {
                return channel;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return "MdfChannelGroup{" +
                "index=" + index +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", recordCount=" + recordCount +
                ", recordSize=" + recordSize +
                ", channels=" + channels.size() +
                '}';
    }
}
