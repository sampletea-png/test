package com.example.mdflib;

/**
 * MDF 通道
 */
public class MdfChannel {
    
    private int index;
    private String name;
    private String unit;
    private String description;
    private DataType dataType;
    private boolean timeChannel;
    private long dataCount;
    private double minValue;
    private double maxValue;
    
    public MdfChannel() {
    }
    
    public MdfChannel(int index, String name, String unit, DataType dataType) {
        this.index = index;
        this.name = name;
        this.unit = unit;
        this.dataType = dataType;
    }
    
    // Getters and Setters
    
    public int getIndex() {
        return index;
    }
    
    public void setIndex(int index) {
        this.index = index;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public DataType getDataType() {
        return dataType;
    }
    
    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }
    
    public boolean isTimeChannel() {
        return timeChannel;
    }
    
    public void setTimeChannel(boolean timeChannel) {
        this.timeChannel = timeChannel;
    }
    
    public long getDataCount() {
        return dataCount;
    }
    
    public void setDataCount(long dataCount) {
        this.dataCount = dataCount;
    }
    
    public double getMinValue() {
        return minValue;
    }
    
    public void setMinValue(double minValue) {
        this.minValue = minValue;
    }
    
    public double getMaxValue() {
        return maxValue;
    }
    
    public void setMaxValue(double maxValue) {
        this.maxValue = maxValue;
    }
    
    @Override
    public String toString() {
        return "MdfChannel{" +
                "index=" + index +
                ", name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", description='" + description + '\'' +
                ", dataType=" + dataType +
                ", timeChannel=" + timeChannel +
                ", dataCount=" + dataCount +
                ", minValue=" + minValue +
                ", maxValue=" + maxValue +
                '}';
    }
}
