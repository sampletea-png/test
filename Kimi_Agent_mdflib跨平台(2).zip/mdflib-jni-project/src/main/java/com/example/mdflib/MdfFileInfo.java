package com.example.mdflib;

import java.time.LocalDateTime;
import java.util.*;

/**
 * MDF 文件信息
 */
public class MdfFileInfo {
    
    private String fileName;
    private int version;
    private String versionString;
    private String program;
    private LocalDateTime creationTime;
    private String author;
    private String organization;
    private String project;
    private String subject;
    private String comment;
    private long fileSize;
    private int dataGroupCount;
    private List<MdfChannelGroup> channelGroups;
    
    public MdfFileInfo() {
        this.channelGroups = new ArrayList<>();
    }
    
    // Getters and Setters
    
    public String getFileName() {
        return fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public int getVersion() {
        return version;
    }
    
    public void setVersion(int version) {
        this.version = version;
    }
    
    public String getVersionString() {
        return versionString;
    }
    
    public void setVersionString(String versionString) {
        this.versionString = versionString;
    }
    
    public String getProgram() {
        return program;
    }
    
    public void setProgram(String program) {
        this.program = program;
    }
    
    public LocalDateTime getCreationTime() {
        return creationTime;
    }
    
    public void setCreationTime(LocalDateTime creationTime) {
        this.creationTime = creationTime;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }
    
    public String getOrganization() {
        return organization;
    }
    
    public void setOrganization(String organization) {
        this.organization = organization;
    }
    
    public String getProject() {
        return project;
    }
    
    public void setProject(String project) {
        this.project = project;
    }
    
    public String getSubject() {
        return subject;
    }
    
    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public long getFileSize() {
        return fileSize;
    }
    
    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }
    
    public int getDataGroupCount() {
        return dataGroupCount;
    }
    
    public void setDataGroupCount(int dataGroupCount) {
        this.dataGroupCount = dataGroupCount;
    }
    
    public List<MdfChannelGroup> getChannelGroups() {
        return channelGroups;
    }
    
    public void setChannelGroups(List<MdfChannelGroup> channelGroups) {
        this.channelGroups = channelGroups;
    }
    
    @Override
    public String toString() {
        return "MdfFileInfo{" +
                "fileName='" + fileName + '\'' +
                ", version=" + version +
                ", versionString='" + versionString + '\'' +
                ", program='" + program + '\'' +
                ", creationTime=" + creationTime +
                ", author='" + author + '\'' +
                ", organization='" + organization + '\'' +
                ", project='" + project + '\'' +
                ", subject='" + subject + '\'' +
                ", comment='" + comment + '\'' +
                ", fileSize=" + fileSize +
                ", dataGroupCount=" + dataGroupCount +
                ", channelGroups=" + channelGroups.size() +
                '}';
    }
}
