package com.example.mdflib;

/**
 * MDF 操作异常
 */
public class MdfException extends RuntimeException {
    
    public MdfException(String message) {
        super(message);
    }
    
    public MdfException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public MdfException(Throwable cause) {
        super(cause);
    }
}
