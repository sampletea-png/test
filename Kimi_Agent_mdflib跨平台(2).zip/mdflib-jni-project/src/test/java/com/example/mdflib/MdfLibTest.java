package com.example.mdflib;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.*;

/**
 * MDFLib JNI 单元测试
 */
public class MdfLibTest {
    
    private static final String TEST_DIR = "target/test-output";
    private static final String TEST_FILE = TEST_DIR + "/test.mf4";
    
    @BeforeAll
    public static void setUpClass() {
        // 创建测试目录
        new File(TEST_DIR).mkdirs();
        
        // 打印版本信息
        System.out.println("========================================");
        System.out.println("MDFLib JNI 测试");
        System.out.println("========================================");
        System.out.println("版本: " + MdfFile.getVersion());
        System.out.println("本地库: " + MdfFile.getNativeLibInfo());
        System.out.println("Java版本: " + System.getProperty("java.version"));
        System.out.println("操作系统: " + System.getProperty("os.name"));
        System.out.println("========================================");
    }
    
    @BeforeEach
    public void setUp() {
        // 删除已存在的测试文件
        File testFile = new File(TEST_FILE);
        if (testFile.exists()) {
            testFile.delete();
        }
    }
    
    @AfterEach
    public void tearDown() {
        // 清理测试文件
        File testFile = new File(TEST_FILE);
        if (testFile.exists()) {
            testFile.delete();
        }
    }
    
    @Test
    @DisplayName("测试版本信息")
    public void testVersion() {
        String version = MdfFile.getVersion();
        assertNotNull(version);
        assertFalse(version.isEmpty());
        System.out.println("版本: " + version);
    }
    
    @Test
    @DisplayName("测试本地库信息")
    public void testNativeLibInfo() {
        String info = MdfFile.getNativeLibInfo();
        assertNotNull(info);
        assertFalse(info.isEmpty());
        System.out.println("本地库信息: " + info);
    }
    
    @Test
    @DisplayName("测试创建和写入MDF文件")
    public void testCreateAndWrite() {
        // 创建 MDF 4.0 文件
        try (MdfFile mdfFile = new MdfFile(TEST_FILE, 4, "TestApp")) {
            assertTrue(mdfFile.isWriteMode());
            assertTrue(mdfFile.isOpen());
            
            // 添加通道组
            int groupIndex = mdfFile.addChannelGroup("TestGroup", "Test Description");
            assertEquals(0, groupIndex);
            
            // 添加时间通道
            int timeChannel = mdfFile.addTimeChannel(groupIndex, "Time", "s");
            assertEquals(0, timeChannel);
            
            // 添加数据通道
            int dataChannel = mdfFile.addChannel(groupIndex, "Data", "unit", 
                "Test data", DataType.DOUBLE);
            assertEquals(1, dataChannel);
            
            // 准备数据
            int sampleCount = 100;
            double[] timeData = new double[sampleCount];
            double[] dataValues = new double[sampleCount];
            
            for (int i = 0; i < sampleCount; i++) {
                timeData[i] = i * 0.01;
                dataValues[i] = Math.sin(i * 0.1) * 50 + 50;
            }
            
            // 写入数据
            assertDoesNotThrow(() -> {
                mdfFile.writeChannelData(groupIndex, timeChannel, timeData);
                mdfFile.writeChannelData(groupIndex, dataChannel, dataValues);
            });
            
        } catch (Exception e) {
            fail("创建文件失败: " + e.getMessage());
        }
        
        // 验证文件已创建
        File file = new File(TEST_FILE);
        assertTrue(file.exists(), "文件应该被创建");
        assertTrue(file.length() > 0, "文件应该有内容");
        
        System.out.println("文件创建成功，大小: " + file.length() + " 字节");
    }
    
    @Test
    @DisplayName("测试读取MDF文件")
    public void testRead() {
        // 首先创建测试文件
        testCreateAndWrite();
        
        // 读取文件
        try (MdfFile mdfFile = new MdfFile(TEST_FILE)) {
            mdfFile.open();
            assertFalse(mdfFile.isWriteMode());
            assertTrue(mdfFile.isOpen());
            
            // 获取文件信息
            MdfFileInfo info = mdfFile.getFileInfo();
            assertNotNull(info);
            assertEquals(4, info.getVersion());
            
            // 获取通道组
            List<MdfChannelGroup> groups = mdfFile.getChannelGroups();
            assertNotNull(groups);
            assertFalse(groups.isEmpty());
            
            for (MdfChannelGroup group : groups) {
                System.out.println("通道组: " + group.getName());
                
                // 获取通道
                List<MdfChannel> channels = mdfFile.getChannels(group.getIndex());
                assertNotNull(channels);
                assertFalse(channels.isEmpty());
                
                for (MdfChannel channel : channels) {
                    System.out.println("  通道: " + channel.getName() + 
                        " [" + channel.getDataType() + "]");
                }
            }
            
        } catch (Exception e) {
            fail("读取文件失败: " + e.getMessage());
        }
    }
    
    @Test
    @DisplayName("测试数据类型枚举")
    public void testDataType() {
        assertEquals(0, DataType.DOUBLE.getValue());
        assertEquals(1, DataType.FLOAT.getValue());
        assertEquals(3, DataType.INT32.getValue());
        assertEquals(10, DataType.STRING.getValue());
        
        assertEquals("DOUBLE", DataType.DOUBLE.getName());
        assertEquals(double.class, DataType.DOUBLE.getJavaType());
        
        // 测试从值获取类型
        assertEquals(DataType.DOUBLE, DataType.fromValue(0));
        assertEquals(DataType.INT32, DataType.fromValue(3));
        
        // 测试从名称获取类型
        assertEquals(DataType.DOUBLE, DataType.fromName("DOUBLE"));
        assertEquals(DataType.INT32, DataType.fromName("INT32"));
    }
    
    @Test
    @DisplayName("测试无效文件处理")
    public void testInvalidFile() {
        String invalidFile = TEST_DIR + "/nonexistent.mf4";
        
        // 检查无效文件
        assertFalse(MdfFile.isValidMdfFile(invalidFile));
        assertEquals(-1, MdfFile.getMdfVersion(invalidFile));
        
        // 尝试打开不存在的文件
        assertThrows(MdfException.class, () -> {
            try (MdfFile mdfFile = new MdfFile(invalidFile)) {
                mdfFile.open();
            }
        });
    }
    
    @Test
    @DisplayName("测试通道组操作")
    public void testChannelGroup() {
        MdfChannelGroup group = new MdfChannelGroup(0, "TestGroup", "Test Description");
        
        assertEquals(0, group.getIndex());
        assertEquals("TestGroup", group.getName());
        assertEquals("Test Description", group.getDescription());
        
        // 添加通道
        MdfChannel channel1 = new MdfChannel(0, "Channel1", "unit1", DataType.DOUBLE);
        MdfChannel channel2 = new MdfChannel(1, "Channel2", "unit2", DataType.INT32);
        
        group.getChannels().add(channel1);
        group.getChannels().add(channel2);
        
        assertEquals(2, group.getChannels().size());
        assertEquals(channel1, group.getChannel("Channel1"));
        assertNull(group.getChannel("NonExistent"));
    }
    
    @Test
    @DisplayName("测试通道操作")
    public void testChannel() {
        MdfChannel channel = new MdfChannel(0, "TestChannel", "m/s", DataType.DOUBLE);
        
        assertEquals(0, channel.getIndex());
        assertEquals("TestChannel", channel.getName());
        assertEquals("m/s", channel.getUnit());
        assertEquals(DataType.DOUBLE, channel.getDataType());
        assertFalse(channel.isTimeChannel());
        
        channel.setTimeChannel(true);
        assertTrue(channel.isTimeChannel());
        
        channel.setMinValue(0.0);
        channel.setMaxValue(100.0);
        assertEquals(0.0, channel.getMinValue());
        assertEquals(100.0, channel.getMaxValue());
    }
    
    @Test
    @DisplayName("测试JSON解析器")
    public void testJsonParser() {
        // 测试 double 数组解析
        String doubleJson = "[1.5, 2.5, 3.5, 4.5, 5.5]";
        double[] doubleArray = MdfJsonParser.parseDoubleArray(doubleJson);
        assertEquals(5, doubleArray.length);
        assertEquals(1.5, doubleArray[0], 0.001);
        assertEquals(5.5, doubleArray[4], 0.001);
        
        // 测试 long 数组解析
        String longJson = "[100, 200, 300, 400, 500]";
        long[] longArray = MdfJsonParser.parseLongArray(longJson);
        assertEquals(5, longArray.length);
        assertEquals(100, longArray[0]);
        assertEquals(500, longArray[4]);
        
        // 测试空数组
        assertEquals(0, MdfJsonParser.parseDoubleArray("").length);
        assertEquals(0, MdfJsonParser.parseDoubleArray("[]").length);
    }
    
    @Test
    @DisplayName("测试异常处理")
    public void testException() {
        MdfException exception1 = new MdfException("Test error");
        assertEquals("Test error", exception1.getMessage());
        
        Throwable cause = new RuntimeException("Cause");
        MdfException exception2 = new MdfException("Test error", cause);
        assertEquals("Test error", exception2.getMessage());
        assertEquals(cause, exception2.getCause());
    }
    
    @Test
    @DisplayName("测试多数据类型写入")
    public void testMultipleDataTypes() {
        try (MdfFile mdfFile = new MdfFile(TEST_FILE, 4, "TestApp")) {
            int groupIndex = mdfFile.addChannelGroup("MultiTypeGroup", "Test");
            
            // 添加不同类型通道
            int doubleChannel = mdfFile.addChannel(groupIndex, "DoubleData", "unit", 
                "Double data", DataType.DOUBLE);
            int intChannel = mdfFile.addChannel(groupIndex, "IntData", "unit", 
                "Int data", DataType.INT32);
            int longChannel = mdfFile.addChannel(groupIndex, "LongData", "unit", 
                "Long data", DataType.INT64);
            
            // 准备数据
            int count = 50;
            double[] doubleData = new double[count];
            int[] intData = new int[count];
            long[] longData = new long[count];
            
            for (int i = 0; i < count; i++) {
                doubleData[i] = i * 1.5;
                intData[i] = i * 10;
                longData[i] = i * 100L;
            }
            
            // 写入数据
            mdfFile.writeChannelData(groupIndex, doubleChannel, doubleData);
            mdfFile.writeChannelData(groupIndex, intChannel, intData);
            mdfFile.writeChannelData(groupIndex, longChannel, longData);
            
        } catch (Exception e) {
            fail("多数据类型写入失败: " + e.getMessage());
        }
        
        File file = new File(TEST_FILE);
        assertTrue(file.exists());
        System.out.println("多数据类型文件创建成功，大小: " + file.length() + " 字节");
    }
}
