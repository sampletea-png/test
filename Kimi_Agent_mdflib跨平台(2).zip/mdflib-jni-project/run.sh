#!/bin/bash

# MDFLib JNI 运行脚本 (Linux)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
BUILD_DIR="$PROJECT_DIR/target"
JAR_FILE="$BUILD_DIR/mdflib-jni-1.0.0.jar"

echo "========================================"
echo "MDFLib JNI 运行脚本"
echo "========================================"
echo ""

# 检查 Java
if ! command -v java &> /dev/null; then
    echo "错误: 未找到 Java"
    exit 1
fi

# 检查 JAR 文件
if [ ! -f "$JAR_FILE" ]; then
    echo "错误: 未找到 JAR 文件: $JAR_FILE"
    echo "请先运行构建: ./scripts/build-linux.sh"
    exit 1
fi

# 检查本地库
LIB_FILE="$BUILD_DIR/libmdflib_jni.so"
if [ ! -f "$LIB_FILE" ]; then
    echo "警告: 未找到本地库: $LIB_FILE"
    echo "尝试从 JAR 中加载..."
fi

# 运行程序
if [ $# -eq 0 ]; then
    echo "用法: $0 <命令> [参数]"
    echo ""
    java -Djava.library.path="$BUILD_DIR" -jar "$JAR_FILE" help
else
    java -Djava.library.path="$BUILD_DIR" -jar "$JAR_FILE" "$@"
fi
