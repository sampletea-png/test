// Types
export * from './types';

// Storage & Config
export {
  loadConfig,
  saveConfig,
  loadMdFile,
  findComponent,
  getComponent,
  scanDirectoryForMd,
  scanAllProjectDirs,
  syncProjectDirsToConfig,
  ensureDirectories,
  getConfigPath,
  getOpencodeModesDir,
  getProjectOpencodeModesDir,
  DIRS,
} from './storage';

// Patterns
export {
  resolvePattern,
  getResolvedComponents,
  exportPatternMarkdown,
  createPattern,
  validatePattern,
  generatePatternId,
  generatePatternLabel,
  getSlotTypeLabel,
} from './patterns';

// OpenCode Export
export {
  exportAsOpenCodeJson,
  exportAsOpenCodeMarkdown,
  writeOpenCodeModeFile,
  installPatternsToOpenCode,
  generateOpenCodeJson,
  writeOpenCodeJson,
} from './opencode-export';
