import type { Config, Pattern, BaseComponent, ComponentType } from './types';
import { findComponent } from './storage';

/**
 * Resolve a pattern by combining with parent (inheritance)
 */
export function resolvePattern(config: Config, pattern: Pattern): Pattern {
  if (!pattern.inheritsFrom) return pattern;

  const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
  if (!parent) return pattern;

  const resolvedParent = resolvePattern(config, parent);

  return {
    ...pattern,
    slots: {
      persona: pattern.slots.persona ?? resolvedParent.slots.persona,
      thinking: pattern.slots.thinking ?? resolvedParent.slots.thinking,
      dialogue: pattern.slots.dialogue ?? resolvedParent.slots.dialogue,
    },
  };
}

/**
 * Get all resolved components for a pattern
 */
export function getResolvedComponents(
  config: Config,
  pattern: Pattern
): {
  persona: BaseComponent | null;
  thinking: BaseComponent | null;
  dialogue: BaseComponent | null;
} {
  const resolved = resolvePattern(config, pattern);
  return {
    persona: resolved.slots.persona
      ? findComponent(config, resolved.slots.persona, 'persona') ?? null
      : null,
    thinking: resolved.slots.thinking
      ? findComponent(config, resolved.slots.thinking, 'thinking') ?? null
      : null,
    dialogue: resolved.slots.dialogue
      ? findComponent(config, resolved.slots.dialogue, 'dialogue') ?? null
      : null,
  };
}

/**
 * Export pattern as a merged markdown string (for display/use)
 */
export function exportPatternMarkdown(config: Config, pattern: Pattern): string {
  const resolved = resolvePattern(config, pattern);
  const components = getResolvedComponents(config, resolved);
  const parts: string[] = [];

  parts.push(`# Pattern: ${pattern.label}`);
  if (pattern.inheritsFrom) {
    const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
    parts.push(`# Inherits from: ${parent?.label || pattern.inheritsFrom}`);
  }
  parts.push('');

  if (components.persona) {
    parts.push(`## Persona: ${components.persona.name}`);
    parts.push(components.persona.content);
    parts.push('');
  }
  if (components.thinking) {
    parts.push(`## Thinking Model: ${components.thinking.name}`);
    parts.push(components.thinking.content);
    parts.push('');
  }
  if (components.dialogue) {
    parts.push(`## Dialogue Pattern: ${components.dialogue.name}`);
    parts.push(components.dialogue.content);
    parts.push('');
  }

  return parts.join('\n');
}

/**
 * Generate pattern ID from name
 */
export function generatePatternId(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '-');
}

/**
 * Generate pattern label from name
 */
export function generatePatternLabel(name: string): string {
  return `[${name}]`;
}

/**
 * Create a new pattern
 */
export function createPattern(
  config: Config,
  name: string,
  options: {
    inherit?: string;
    persona?: string;
    thinking?: string;
    dialogue?: string;
  }
): { pattern: Pattern; errors: string[] } {
  const errors: string[] = [];
  const id = generatePatternId(name);
  const label = generatePatternLabel(name);

  if (config.patterns.some((p) => p.id === id)) {
    errors.push(`Pattern "${label}" already exists`);
    return { pattern: null as any, errors };
  }

  let slots = { persona: null as string | null, thinking: null as string | null, dialogue: null as string | null };
  let inheritsFrom: string | null = null;

  // Handle inheritance
  if (options.inherit) {
    const parent = config.patterns.find(
      (p) => p.id === options.inherit || p.name === options.inherit || p.label === options.inherit
    );
    if (parent) {
      const resolved = resolvePattern(config, parent);
      slots = { ...resolved.slots };
      inheritsFrom = parent.id;
    } else {
      errors.push(`Parent pattern "${options.inherit}" not found`);
    }
  }

  // Override slots
  if (options.persona) {
    const p = findComponent(config, options.persona, 'persona');
    if (p) slots.persona = p.id;
    else errors.push(`Persona "${options.persona}" not found`);
  }
  if (options.thinking) {
    const t = findComponent(config, options.thinking, 'thinking');
    if (t) slots.thinking = t.id;
    else errors.push(`Thinking model "${options.thinking}" not found`);
  }
  if (options.dialogue) {
    const d = findComponent(config, options.dialogue, 'dialogue');
    if (d) slots.dialogue = d.id;
    else errors.push(`Dialogue pattern "${options.dialogue}" not found`);
  }

  const pattern: Pattern = {
    id,
    name,
    label,
    inheritsFrom,
    slots,
  };

  return { pattern, errors };
}

/**
 * Validate that all pattern slots point to existing components
 */
export function validatePattern(config: Config, pattern: Pattern): string[] {
  const errors: string[] = [];
  const resolved = resolvePattern(config, pattern);

  if (resolved.slots.persona && !findComponent(config, resolved.slots.persona, 'persona')) {
    errors.push(`Persona "${resolved.slots.persona}" not found`);
  }
  if (resolved.slots.thinking && !findComponent(config, resolved.slots.thinking, 'thinking')) {
    errors.push(`Thinking model "${resolved.slots.thinking}" not found`);
  }
  if (resolved.slots.dialogue && !findComponent(config, resolved.slots.dialogue, 'dialogue')) {
    errors.push(`Dialogue pattern "${resolved.slots.dialogue}" not found`);
  }

  return errors;
}

/**
 * Get pattern slot type label
 */
export function getSlotTypeLabel(type: ComponentType): string {
  const labels: Record<ComponentType, string> = {
    persona: 'Persona',
    thinking: 'Thinking Model',
    dialogue: 'Dialogue Pattern',
  };
  return labels[type];
}
