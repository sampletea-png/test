import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import type { Config, BaseComponent, ComponentType } from './types';

const CONFIG_DIR = path.join(os.homedir(), '.opencode-patterns');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

export const DIRS = {
  persona: 'personas',
  thinking: 'thinking-models',
  dialogue: 'dialogue-patterns',
  patterns: 'patterns',
} as const;

export function getConfigPath(): string {
  return CONFIG_FILE;
}

export function getOpencodeModesDir(): string {
  return path.join(os.homedir(), '.config', 'opencode', 'modes');
}

export function getProjectOpencodeModesDir(): string {
  return path.join(process.cwd(), '.opencode', 'modes');
}

export function ensureDirectories(): void {
  const dirs = [
    CONFIG_DIR,
    ...Object.values(DIRS).map((d) => path.join(process.cwd(), d)),
    getOpencodeModesDir(),
  ];
  for (const dir of dirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

export function loadConfig(): Config {
  ensureDirectories();
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
    } catch {
      return createDefaultConfig();
    }
  }
  return createDefaultConfig();
}

export function saveConfig(config: Config): void {
  ensureDirectories();
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

function createDefaultConfig(): Config {
  return {
    version: '2.0.0',
    personas: [],
    thinkingModels: [],
    dialoguePatterns: [],
    patterns: [],
  };
}

export function loadMdFile(filePath: string, type: ComponentType): BaseComponent {
  const content = fs.readFileSync(filePath, 'utf-8');
  const fileName = path.basename(filePath);
  const name = fileName.replace(/\.md$/, '');
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const lines = content.split('\n').filter((l) => l.trim());
  // Extract description: first non-heading line, or first H2 content
  let description = '';
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('#') && trimmed.length > 0) {
      description = trimmed;
      break;
    }
  }
  if (!description && lines.length > 0) {
    description = lines[0].replace(/^#+\s*/, '');
  }
  return { id, name, fileName, description, content, type };
}

export function findComponent(
  config: Config,
  query: string,
  type: ComponentType
): BaseComponent | undefined {
  const arr =
    type === 'persona'
      ? config.personas
      : type === 'thinking'
        ? config.thinkingModels
        : config.dialoguePatterns;
  const q = query.toLowerCase();
  let found = arr.find(
    (c) => c.id === q || c.name.toLowerCase() === q || c.fileName.toLowerCase() === q
  );
  if (found) return found;
  found = arr.find(
    (c) =>
      c.id.includes(q) ||
      c.name.toLowerCase().includes(q) ||
      c.fileName.toLowerCase().includes(q)
  );
  return found;
}

export function getComponent(
  config: Config,
  id: string,
  type: ComponentType
): BaseComponent | undefined {
  return findComponent(config, id, type);
}

export function scanDirectoryForMd(dirPath: string, type: ComponentType): BaseComponent[] {
  if (!fs.existsSync(dirPath)) return [];
  const files = fs.readdirSync(dirPath).filter((f) => f.endsWith('.md'));
  return files.map((f) => loadMdFile(path.join(dirPath, f), type));
}

export function scanAllProjectDirs(): {
  personas: BaseComponent[];
  thinkingModels: BaseComponent[];
  dialoguePatterns: BaseComponent[];
} {
  return {
    personas: scanDirectoryForMd(path.join(process.cwd(), DIRS.persona), 'persona'),
    thinkingModels: scanDirectoryForMd(
      path.join(process.cwd(), DIRS.thinking),
      'thinking'
    ),
    dialoguePatterns: scanDirectoryForMd(
      path.join(process.cwd(), DIRS.dialogue),
      'dialogue'
    ),
  };
}

export function syncProjectDirsToConfig(config: Config): Config {
  const scanned = scanAllProjectDirs();
  // Merge scanned components into config, preserving existing ones and adding new ones
  for (const comp of scanned.personas) {
    const idx = config.personas.findIndex((c) => c.id === comp.id);
    if (idx >= 0) config.personas[idx] = comp;
    else config.personas.push(comp);
  }
  for (const comp of scanned.thinkingModels) {
    const idx = config.thinkingModels.findIndex((c) => c.id === comp.id);
    if (idx >= 0) config.thinkingModels[idx] = comp;
    else config.thinkingModels.push(comp);
  }
  for (const comp of scanned.dialoguePatterns) {
    const idx = config.dialoguePatterns.findIndex((c) => c.id === comp.id);
    if (idx >= 0) config.dialoguePatterns[idx] = comp;
    else config.dialoguePatterns.push(comp);
  }
  return config;
}
