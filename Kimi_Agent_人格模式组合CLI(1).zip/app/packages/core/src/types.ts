export type ComponentType = 'persona' | 'thinking' | 'dialogue';

export interface BaseComponent {
  id: string;
  name: string;
  fileName: string;
  description: string;
  content: string;
  type: ComponentType;
}

export interface Pattern {
  id: string;
  name: string;
  label: string;
  inheritsFrom: string | null;
  slots: {
    persona: string | null;
    thinking: string | null;
    dialogue: string | null;
  };
}

export interface Config {
  version: string;
  personas: BaseComponent[];
  thinkingModels: BaseComponent[];
  dialoguePatterns: BaseComponent[];
  patterns: Pattern[];
}

// OpenCode export format
export interface OpenCodeModeConfig {
  model?: string;
  temperature?: number;
  prompt?: string;
  tools?: {
    write?: boolean;
    edit?: boolean;
    bash?: boolean;
    read?: boolean;
    grep?: boolean;
    glob?: boolean;
  };
}

export interface OpenCodeJsonConfig {
  $schema?: string;
  mode?: Record<string, OpenCodeModeConfig>;
}

export interface OpenCodeMarkdownMode {
  name: string;
  frontmatter: {
    model?: string;
    temperature?: number;
    tools?: Record<string, boolean>;
  };
  body: string;
}
