import * as fs from 'fs';
import * as path from 'path';
import type { Config, Pattern, OpenCodeModeConfig, OpenCodeMarkdownMode } from './types';
import { resolvePattern, getResolvedComponents } from './patterns';
import { getOpencodeModesDir, getProjectOpencodeModesDir } from './storage';

/**
 * Export pattern as OpenCode JSON mode config
 */
export function exportAsOpenCodeJson(
  config: Config,
  pattern: Pattern
): { key: string; modeConfig: OpenCodeModeConfig } {
  const resolved = resolvePattern(config, pattern);
  const components = getResolvedComponents(config, resolved);

  // Build the prompt content from merged components
  const promptParts: string[] = [];

  if (components.persona) {
    promptParts.push(`# Persona: ${components.persona.name}\n${components.persona.content}`);
  }
  if (components.thinking) {
    promptParts.push(`# Thinking Model: ${components.thinking.name}\n${components.thinking.content}`);
  }
  if (components.dialogue) {
    promptParts.push(`# Dialogue Pattern: ${components.dialogue.name}\n${components.dialogue.content}`);
  }

  const prompt = promptParts.join('\n\n---\n\n');

  const modeConfig: OpenCodeModeConfig = {
    temperature: 0.2,
    tools: {
      write: true,
      edit: true,
      bash: true,
      read: true,
      grep: true,
      glob: true,
    },
  };

  return {
    key: pattern.id,
    modeConfig: {
      ...modeConfig,
      prompt,
    },
  };
}

/**
 * Export pattern as OpenCode Markdown mode
 */
export function exportAsOpenCodeMarkdown(
  config: Config,
  pattern: Pattern
): OpenCodeMarkdownMode {
  const resolved = resolvePattern(config, pattern);
  const components = getResolvedComponents(config, resolved);

  const bodyParts: string[] = [];

  if (components.persona) {
    bodyParts.push(components.persona.content);
  }
  if (components.thinking) {
    bodyParts.push(`## Thinking Framework\n\n${components.thinking.content}`);
  }
  if (components.dialogue) {
    bodyParts.push(`## Dialogue Guidelines\n\n${components.dialogue.content}`);
  }

  return {
    name: pattern.id,
    frontmatter: {
      temperature: 0.2,
      tools: {
        write: true,
        edit: true,
        bash: true,
        read: true,
        grep: true,
        glob: true,
      },
    },
    body: bodyParts.join('\n\n---\n\n'),
  };
}

/**
 * Write pattern as OpenCode markdown mode file
 * This creates a .md file that opencode can directly load via Tab
 */
export function writeOpenCodeModeFile(
  config: Config,
  pattern: Pattern,
  targetDir: string
): string {
  const mdMode = exportAsOpenCodeMarkdown(config, pattern);

  const frontmatterEntries: string[] = [];
  if (mdMode.frontmatter.temperature !== undefined) {
    frontmatterEntries.push(`temperature: ${mdMode.frontmatter.temperature}`);
  }
  if (mdMode.frontmatter.tools) {
    const toolEntries = Object.entries(mdMode.frontmatter.tools)
      .map(([k, v]) => `  ${k}: ${v}`)
      .join('\n');
    frontmatterEntries.push(`tools:\n${toolEntries}`);
  }

  const content = `---\n${frontmatterEntries.join('\n')}\n---\n\n${mdMode.body}\n`;

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  const filePath = path.join(targetDir, `${mdMode.name}.md`);
  fs.writeFileSync(filePath, content, 'utf-8');
  return filePath;
}

/**
 * Install all patterns as OpenCode modes
 * Writes to ~/.config/opencode/modes/ so they're available globally via Tab
 */
export function installPatternsToOpenCode(config: Config): { installed: string[]; errors: string[] } {
  const installed: string[] = [];
  const errors: string[] = [];
  const modesDir = getOpencodeModesDir();

  for (const pattern of config.patterns) {
    try {
      const filePath = writeOpenCodeModeFile(config, pattern, modesDir);
      installed.push(`${pattern.label} -> ${filePath}`);
    } catch (err: any) {
      errors.push(`Failed to export ${pattern.label}: ${err.message}`);
    }
  }

  return { installed, errors };
}

/**
 * Export all patterns to a single opencode.json file
 */
export function generateOpenCodeJson(config: Config): Record<string, OpenCodeModeConfig> {
  const modes: Record<string, OpenCodeModeConfig> = {};

  for (const pattern of config.patterns) {
    const { key, modeConfig } = exportAsOpenCodeJson(config, pattern);
    modes[key] = modeConfig;
  }

  return modes;
}

/**
 * Write opencode.json config file
 */
export function writeOpenCodeJson(
  config: Config,
  targetPath: string
): void {
  const modes = generateOpenCodeJson(config);
  const opencodeConfig = {
    $schema: 'https://opencode.ai/config.json',
    mode: modes,
  };

  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(targetPath, JSON.stringify(opencodeConfig, null, 2), 'utf-8');
}
