#!/bin/bash
# 模式编排器 v2.0 - 完整演示脚本

set -e

PROJECT_ROOT="/mnt/agents/output/app"
CLI="node $PROJECT_ROOT/packages/cli/dist/index.js"
TEST_HOME="/tmp/opencode-demo-home-$$"
export HOME="$TEST_HOME"
mkdir -p "$TEST_HOME"

echo ""
echo "========================================"
echo "  Pattern Orchestrator v2.0 Demo"
echo "========================================"
echo ""

# 1. Sync project directories (from project root)
echo ">> 1. Sync project directories..."
cd "$PROJECT_ROOT" && $CLI sync 2>&1
echo ""

# 2. List all components
echo ">> 2. All available components:"
$CLI list 2>&1
echo ""

# 3. Create [Plan] pattern
echo ">> 3. Create [Plan] pattern..."
$CLI create-pattern Plan --persona java-engineer --thinking ooda-loop --dialogue socratic-dialogue 2>&1
echo ""

# 4. Create [Build] inheriting Plan
echo ">> 4. Create [Build] (inherits Plan, swaps persona + dialogue)..."
$CLI create-pattern Build --inherit Plan --persona python-expert --dialogue direct-answer 2>&1
echo ""

# 5. List patterns
echo ">> 5. Pattern list:"
$CLI list patterns 2>&1
echo ""

# 6. Show Build detail
echo ">> 6. Show [Build] (inherits OODA_loop from Plan):"
$CLI show Build 2>&1
echo ""

# 7. Export as OpenCode mode
echo ">> 7. Export [Plan] as OpenCode mode:"
rm -rf /tmp/demo-modes && mkdir -p /tmp/demo-modes
$CLI export-opencode-mode Plan /tmp/demo-modes/ 2>&1
echo ""

# 8. Preview exported file
echo ">> 8. OpenCode mode file (first 20 lines):"
head -20 /tmp/demo-modes/plan.md 2>&1
echo ""

# 9. Create custom pattern
echo ">> 9. Create [CodeReview] (DevOps + Inversion + Direct)..."
$CLI create-pattern CodeReview --persona devops-engineer --thinking inversion-thinking --dialogue direct-answer 2>&1
echo ""

# 10. Final state
echo ">> 10. Final patterns:"
$CLI list patterns 2>&1
echo ""

# Cleanup
rm -rf "$TEST_HOME"

echo "========================================"
echo "  Demo complete!"
echo ""
echo "  Interactive wizard:"
echo "    $ cd $PROJECT_ROOT"
echo "    $ opencode-patterns wizard"
echo ""
echo "  Install to OpenCode (Tab switchable):"
echo "    $ cd $PROJECT_ROOT"
echo "    $ opencode-patterns install-opencode"
echo "========================================"
echo ""
