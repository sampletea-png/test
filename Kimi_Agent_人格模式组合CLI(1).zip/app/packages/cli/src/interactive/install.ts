import inquirer from 'inquirer';
import chalk from 'chalk';
import {
  type Config,
  installPatternsToOpenCode,
  getOpencodeModesDir,
} from '@opencode-patterns/core';

export async function interactiveInstall(config: Config): Promise<void> {
  if (config.patterns.length === 0) {
    console.log(chalk.yellow('\n  No patterns to install. Create patterns first!\n'));
    return;
  }

  // Validate patterns
  const validPatterns = config.patterns.filter((p) => {
    const errors: string[] = [];
    if (!p.slots.persona && !p.inheritsFrom) errors.push('no persona');
    // Allow empty slots for now
    return errors.length === 0;
  });

  console.log(chalk.cyan('\n  --- Install to OpenCode ---\n'));
  console.log(chalk.gray('  This will create .md mode files in ~/.config/opencode/modes/'));
  console.log(chalk.gray('  After installation, restart OpenCode and press Tab to switch modes.\n'));

  const { selectedIds } = await inquirer.prompt([
    {
      type: 'checkbox',
      name: 'selectedIds',
      message: 'Select patterns to install as OpenCode modes:',
      choices: config.patterns.map((p) => ({
        name: `${p.label}${p.inheritsFrom ? chalk.gray(` (inherits ${p.inheritsFrom})`) : ''}`,
        value: p.id,
        checked: true,
      })),
      validate: (input: string[]) => input.length > 0 || 'Select at least one pattern',
    },
  ]);

  if (selectedIds.length === 0) {
    console.log(chalk.gray('\n  Cancelled.\n'));
    return;
  }

  const { confirm } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'confirm',
      message: `Install ${selectedIds.length} pattern(s) as OpenCode modes?`,
      default: true,
    },
  ]);

  if (!confirm) {
    console.log(chalk.gray('\n  Cancelled.\n'));
    return;
  }

  // Temporarily filter config to only selected patterns
  const originalPatterns = config.patterns;
  config.patterns = config.patterns.filter((p) => selectedIds.includes(p.id));

  const { installed, errors } = installPatternsToOpenCode(config);

  // Restore
  config.patterns = originalPatterns;

  if (installed.length > 0) {
    console.log(chalk.green(`\n  ✓ Installed ${installed.length} mode(s):\n`));
    installed.forEach((i) => console.log(`    ${chalk.cyan('•')} ${i}`));
  }

  if (errors.length > 0) {
    console.log(chalk.red('\n  Errors:'));
    errors.forEach((e) => console.log(`    ${chalk.red('✗')} ${e}`));
  }

  console.log(chalk.gray(`\n  Modes directory: ${getOpencodeModesDir()}`));
  console.log(chalk.yellow('  → Restart OpenCode and press Tab to switch between your custom modes!\n'));
}
