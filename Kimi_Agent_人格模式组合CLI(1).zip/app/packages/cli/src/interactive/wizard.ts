import inquirer from 'inquirer';
import chalk from 'chalk';
import type { Config } from '@opencode-patterns/core';
import { interactiveCreate } from './create';
import { interactiveRemove } from './remove';
import { interactiveInstall } from './install';

export async function interactiveWizard(config: Config): Promise<void> {
  console.log(chalk.bold('\n  ╔══════════════════════════════════════════╗'));
  console.log(chalk.bold('  ║     Pattern Orchestrator - Wizard       ║'));
  console.log(chalk.bold('  ╚══════════════════════════════════════════╝\n'));

  const { action } = await inquirer.prompt([
    {
      type: 'list',
      name: 'action',
      message: 'What would you like to do?',
      choices: [
        { name: chalk.cyan('Create a new pattern') + chalk.gray(' (interactive)'), value: 'create' },
        { name: chalk.blue('List all patterns & components'), value: 'list' },
        { name: chalk.magenta('Show pattern details'), value: 'show' },
        { name: chalk.yellow('Edit pattern slots'), value: 'edit' },
        { name: chalk.red('Remove a pattern'), value: 'remove' },
        { name: chalk.green('Install to OpenCode') + chalk.gray(' (Tab-switchable modes)'), value: 'install' },
        new inquirer.Separator(),
        { name: chalk.gray('Exit'), value: 'exit' },
      ],
    },
  ]);

  switch (action) {
    case 'create':
      await interactiveCreate(config);
      break;
    case 'list':
      await interactiveList(config);
      break;
    case 'show':
      await interactiveShow(config);
      break;
    case 'edit':
      await interactiveEdit(config);
      break;
    case 'remove':
      await interactiveRemove(config);
      break;
    case 'install':
      await interactiveInstall(config);
      break;
    case 'exit':
      console.log(chalk.gray('\n  Goodbye!\n'));
      return;
  }

  // Return to menu
  console.log('');
  const { again } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'again',
      message: 'Return to main menu?',
      default: true,
    },
  ]);

  if (again) {
    await interactiveWizard(config);
  }
}

async function interactiveList(config: Config): Promise<void> {
  const {
    resolvePattern,
    getResolvedComponents,
  } = await import('@opencode-patterns/core');

  console.log(chalk.bold('\n  === Components ===\n'));

  console.log(chalk.blueBright(`  Personas (${config.personas.length}):`));
  config.personas.forEach((p) => console.log(`    • ${p.name}`));

  console.log(chalk.magentaBright(`\n  Thinking Models (${config.thinkingModels.length}):`));
  config.thinkingModels.forEach((t) => console.log(`    • ${t.name}`));

  console.log(chalk.greenBright(`\n  Dialogue Patterns (${config.dialoguePatterns.length}):`));
  config.dialoguePatterns.forEach((d) => console.log(`    • ${d.name}`));

  console.log(chalk.cyanBright(`\n  Patterns (${config.patterns.length}):`));
  for (const pattern of config.patterns) {
    const resolved = resolvePattern(config, pattern);
    const comps = getResolvedComponents(config, resolved);
    const inherits = pattern.inheritsFrom ? chalk.yellow(` <- ${pattern.inheritsFrom}`) : '';
    console.log(`\n    ${chalk.bold(pattern.label)}${inherits}`);
    if (comps.persona) console.log(chalk.blue(`      persona: ${comps.persona.name}`));
    if (comps.thinking) console.log(chalk.magenta(`      thinking: ${comps.thinking.name}`));
    if (comps.dialogue) console.log(chalk.green(`      dialogue: ${comps.dialogue.name}`));
  }
  console.log('');
}

async function interactiveShow(config: Config): Promise<void> {
  const { exportPatternMarkdown } = await import('@opencode-patterns/core');

  if (config.patterns.length === 0) {
    console.log(chalk.yellow('\n  No patterns found. Create one first!\n'));
    return;
  }

  const { patternId } = await inquirer.prompt([
    {
      type: 'list',
      name: 'patternId',
      message: 'Select a pattern to view:',
      choices: config.patterns.map((p) => ({
        name: `${p.label}${p.inheritsFrom ? chalk.gray(` (inherits ${p.inheritsFrom})`) : ''}`,
        value: p.id,
      })),
    },
  ]);

  const pattern = config.patterns.find((p) => p.id === patternId);
  if (!pattern) return;

  const output = exportPatternMarkdown(config, pattern);
  console.log(chalk.bold('\n  --- Preview (first 30 lines) ---\n'));
  console.log(output.split('\n').slice(0, 30).join('\n'));
  console.log(chalk.gray('\n  ... (truncated)\n'));
}

async function interactiveEdit(config: Config): Promise<void> {
  const { saveConfig, findComponent, resolvePattern } = await import('@opencode-patterns/core');

  if (config.patterns.length === 0) {
    console.log(chalk.yellow('\n  No patterns found.\n'));
    return;
  }

  const { patternId } = await inquirer.prompt([
    {
      type: 'list',
      name: 'patternId',
      message: 'Select a pattern to edit:',
      choices: config.patterns.map((p) => ({ name: p.label, value: p.id })),
    },
  ]);

  const pattern = config.patterns.find((p) => p.id === patternId);
  if (!pattern) return;

  const { slot } = await inquirer.prompt([
    {
      type: 'list',
      name: 'slot',
      message: `Edit which slot of ${pattern.label}?`,
      choices: [
        { name: `Persona ${chalk.gray(`(current: ${pattern.slots.persona || 'none'})`)}`, value: 'persona' },
        { name: `Thinking Model ${chalk.gray(`(current: ${pattern.slots.thinking || 'none'})`)}`, value: 'thinking' },
        { name: `Dialogue Pattern ${chalk.gray(`(current: ${pattern.slots.dialogue || 'none'})`)}`, value: 'dialogue' },
      ],
    },
  ]);

  const arr = slot === 'persona' ? config.personas
    : slot === 'thinking' ? config.thinkingModels
    : config.dialoguePatterns;

  if (arr.length === 0) {
    console.log(chalk.red(`\n  No ${slot} components available.\n`));
    return;
  }

  const { componentId } = await inquirer.prompt([
    {
      type: 'list',
      name: 'componentId',
      message: `Select a new ${slot}:`,
      choices: [
        { name: chalk.gray('(none / clear)'), value: '__CLEAR__' },
        ...arr.map((c) => ({ name: `${c.name} ${chalk.gray(c.fileName)}`, value: c.id })),
      ],
    },
  ]);

  const slotKey = slot as 'persona' | 'thinking' | 'dialogue';
  if (componentId === '__CLEAR__') {
    pattern.slots[slotKey] = null;
    console.log(chalk.yellow(`  Cleared ${slot} from ${pattern.label}`));
  } else {
    pattern.slots[slotKey] = componentId;
    const comp = arr.find((c) => c.id === componentId);
    console.log(chalk.green(`  Set ${slot} to ${comp?.name || componentId}`));
  }

  saveConfig(config);
  console.log();
}
