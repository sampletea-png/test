import inquirer from 'inquirer';
import chalk from 'chalk';
import {
  type Config,
  createPattern,
  saveConfig,
  resolvePattern,
  getResolvedComponents,
} from '@opencode-patterns/core';

export async function interactiveCreate(config: Config): Promise<void> {
  console.log(chalk.cyan('\n  --- Create New Pattern ---\n'));

  // Step 1: Pattern name
  const { name } = await inquirer.prompt([
    {
      type: 'input',
      name: 'name',
      message: 'Pattern name (e.g., CodeReview, Debug, Architecture):',
      validate: (input: string) => {
        if (!input.trim()) return 'Name is required';
        const id = input.toLowerCase().replace(/[^a-z0-9]/g, '-');
        if (config.patterns.some((p) => p.id === id)) return `Pattern "${input}" already exists`;
        return true;
      },
    },
  ]);

  // Step 2: Inheritance
  const inheritChoices = [
    { name: chalk.gray('None (create from scratch)'), value: '' },
    ...config.patterns.map((p) => ({
      name: `${p.label} ${chalk.gray(`(${p.slots.persona || '-'} | ${p.slots.thinking || '-'} | ${p.slots.dialogue || '-'})`)}`,
      value: p.id,
    })),
  ];

  const { inherit } = await inquirer.prompt([
    {
      type: 'list',
      name: 'inherit',
      message: 'Inherit from an existing pattern?',
      choices: inheritChoices,
    },
  ]);

  // Step 3: Persona
  const personaChoices = [
    { name: chalk.gray('None'), value: '' },
    ...config.personas.map((p) => ({ name: `${p.name} ${chalk.gray(p.description.slice(0, 50))}`, value: p.id })),
  ];

  const { persona } = await inquirer.prompt([
    {
      type: 'list',
      name: 'persona',
      message: 'Select Persona:',
      choices: personaChoices,
    },
  ]);

  // Step 4: Thinking Model
  const thinkingChoices = [
    { name: chalk.gray('None'), value: '' },
    ...config.thinkingModels.map((t) => ({ name: `${t.name} ${chalk.gray(t.description.slice(0, 50))}`, value: t.id })),
  ];

  const { thinking } = await inquirer.prompt([
    {
      type: 'list',
      name: 'thinking',
      message: 'Select Thinking Model:',
      choices: thinkingChoices,
    },
  ]);

  // Step 5: Dialogue Pattern
  const dialogueChoices = [
    { name: chalk.gray('None'), value: '' },
    ...config.dialoguePatterns.map((d) => ({ name: `${d.name} ${chalk.gray(d.description.slice(0, 50))}`, value: d.id })),
  ];

  const { dialogue } = await inquirer.prompt([
    {
      type: 'list',
      name: 'dialogue',
      message: 'Select Dialogue Pattern:',
      choices: dialogueChoices,
    },
  ]);

  // Create pattern
  const options = {
    inherit: inherit || undefined,
    persona: persona || undefined,
    thinking: thinking || undefined,
    dialogue: dialogue || undefined,
  };

  const { pattern, errors } = createPattern(config, name, options);

  if (errors.length > 0) {
    errors.forEach((e) => console.log(chalk.red(`  Warning: ${e}`)));
  }

  if (pattern) {
    config.patterns.push(pattern);
    saveConfig(config);

    console.log(chalk.green(`\n  ✓ Created pattern: ${chalk.bold(pattern.label)}`));

    const resolved = resolvePattern(config, pattern);
    const comps = getResolvedComponents(config, resolved);

    console.log(chalk.gray('\n  Composition:'));
    if (comps.persona) console.log(chalk.blue(`    Persona:      ${comps.persona.name}`));
    if (comps.thinking) console.log(chalk.magenta(`    Thinking:     ${comps.thinking.name}`));
    if (comps.dialogue) console.log(chalk.green(`    Dialogue:     ${comps.dialogue.name}`));

    if (pattern.inheritsFrom) {
      console.log(chalk.cyan(`    Inherits:     ${pattern.inheritsFrom}`));
    }

    console.log(chalk.gray(`\n  Use it:`));
    console.log(chalk.gray(`    $ opencode-patterns use ${pattern.name}`));
    console.log(chalk.gray(`    $ opencode-patterns install-opencode  # Make it Tab-switchable`));
    console.log();
  }
}
