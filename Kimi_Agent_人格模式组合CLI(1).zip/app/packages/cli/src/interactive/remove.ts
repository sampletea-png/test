import inquirer from 'inquirer';
import chalk from 'chalk';
import { type Config, saveConfig } from '@opencode-patterns/core';

export async function interactiveRemove(config: Config): Promise<void> {
  if (config.patterns.length === 0) {
    console.log(chalk.yellow('\n  No patterns to remove.\n'));
    return;
  }

  const { patternIds } = await inquirer.prompt([
    {
      type: 'checkbox',
      name: 'patternIds',
      message: 'Select patterns to remove (space to select, enter to confirm):',
      choices: config.patterns.map((p) => {
        const childCount = config.patterns.filter((child) => child.inheritsFrom === p.id).length;
        const warning = childCount > 0 ? chalk.red(` [${childCount} child patterns]`) : '';
        return {
          name: `${p.label}${warning}`,
          value: p.id,
        };
      }),
    },
  ]);

  if (patternIds.length === 0) {
    console.log(chalk.gray('\n  No patterns selected.\n'));
    return;
  }

  // Check for children
  const patternsWithChildren = patternIds.filter((id: string) =>
    config.patterns.some((p) => p.inheritsFrom === id)
  );

  if (patternsWithChildren.length > 0) {
    const { confirmBreak } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmBreak',
        message: chalk.yellow(`Some patterns have children. Removing them will break inheritance links. Continue?`),
        default: false,
      },
    ]);
    if (!confirmBreak) {
      console.log(chalk.gray('\n  Cancelled.\n'));
      return;
    }
  }

  const { confirm } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'confirm',
      message: `Remove ${patternIds.length} pattern(s)? This cannot be undone.`,
      default: false,
    },
  ]);

  if (!confirm) {
    console.log(chalk.gray('\n  Cancelled.\n'));
    return;
  }

  // Remove patterns
  const removed: string[] = [];
  for (const id of patternIds) {
    const idx = config.patterns.findIndex((p) => p.id === id);
    if (idx >= 0) {
      removed.push(config.patterns[idx].label);
      config.patterns.splice(idx, 1);
    }
  }

  // Break inheritance links to removed patterns
  config.patterns = config.patterns.map((p) => {
    if (p.inheritsFrom && patternIds.includes(p.inheritsFrom)) {
      return { ...p, inheritsFrom: null };
    }
    return p;
  });

  saveConfig(config);

  console.log(chalk.green(`\n  Removed ${removed.length} pattern(s):`));
  removed.forEach((r) => console.log(`    ${chalk.red('✗')} ${r}`));
  console.log();
}
