#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import {
  loadConfig,
  saveConfig,
  loadMdFile,
  findComponent,
  syncProjectDirsToConfig,
  DIRS,
  resolvePattern,
  getResolvedComponents,
  exportPatternMarkdown,
  createPattern,
  validatePattern,
  installPatternsToOpenCode,
  writeOpenCodeJson,
  generateOpenCodeJson,
  getOpencodeModesDir,
  getProjectOpencodeModesDir,
  getConfigPath,
  type Config,
  type ComponentType,
  type Pattern,
} from '@opencode-patterns/core';
import * as fs from 'fs';
import * as path from 'path';

// Import interactive modules
import { interactiveCreate } from './interactive/create';
import { interactiveRemove } from './interactive/remove';
import { interactiveWizard } from './interactive/wizard';

const program = new Command();

program
  .name('opencode-patterns')
  .description('Pattern Orchestrator - Manage personas, thinking models, and dialogue patterns')
  .version('2.0.0');

// Helper: get config with sync
function getConfig(): Config {
  const config = loadConfig();
  return syncProjectDirsToConfig(config);
}

// ==================== INTERACTIVE COMMANDS ====================

program
  .command('wizard')
  .alias('w')
  .description('Interactive wizard for creating and managing patterns')
  .action(() => {
    const config = getConfig();
    interactiveWizard(config);
  });

program
  .command('interactive-create')
  .alias('ic')
  .description('Interactive pattern creation wizard')
  .action(() => {
    const config = getConfig();
    interactiveCreate(config);
  });

program
  .command('interactive-remove')
  .alias('ir')
  .description('Interactive pattern removal wizard')
  .action(() => {
    const config = getConfig();
    interactiveRemove(config);
  });

// ==================== LIST COMMANDS ====================

program
  .command('list [type]')
  .description('List all components and patterns')
  .action((type?: string) => {
    const config = getConfig();

    if (!type || type === 'all') {
      listAll(config);
    } else if (type === 'personas') {
      listComponents(config.personas, 'Personas', chalk.blueBright);
    } else if (type === 'thinking') {
      listComponents(config.thinkingModels, 'Thinking Models', chalk.magentaBright);
    } else if (type === 'dialogue') {
      listComponents(config.dialoguePatterns, 'Dialogue Patterns', chalk.greenBright);
    } else if (type === 'patterns') {
      listPatterns(config);
    } else {
      console.log(chalk.red(`  Unknown type: ${type}`));
    }
  });

// ==================== ADD COMMANDS ====================

program
  .command('add-persona <file>')
  .description('Add a persona from a .md file')
  .action((file: string) => addComponent('persona', file));

program
  .command('add-thinking <file>')
  .description('Add a thinking model from a .md file')
  .action((file: string) => addComponent('thinking', file));

program
  .command('add-dialogue <file>')
  .description('Add a dialogue pattern from a .md file')
  .action((file: string) => addComponent('dialogue', file));

// ==================== REMOVE COMMANDS ====================

program
  .command('remove-persona <name>')
  .description('Remove a persona')
  .action((name: string) => removeComponent('persona', name));

program
  .command('remove-thinking <name>')
  .description('Remove a thinking model')
  .action((name: string) => removeComponent('thinking', name));

program
  .command('remove-dialogue <name>')
  .description('Remove a dialogue pattern')
  .action((name: string) => removeComponent('dialogue', name));

// ==================== PATTERN COMMANDS ====================

program
  .command('create-pattern <name>')
  .description('Create a new pattern. Use --inherit to base on existing pattern')
  .option('-i, --inherit <pattern>', 'Inherit from an existing pattern')
  .option('-p, --persona <persona>', 'Set persona')
  .option('-t, --thinking <thinking>', 'Set thinking model')
  .option('-d, --dialogue <dialogue>', 'Set dialogue pattern')
  .action((name: string, options: any) => {
    const config = getConfig();
    const { pattern, errors } = createPattern(config, name, options);

    if (errors.length > 0) {
      errors.forEach((e) => console.log(chalk.red(`  Error: ${e}`)));
      if (!pattern) process.exit(1);
    }

    if (pattern) {
      config.patterns.push(pattern);
      saveConfig(config);
      console.log(chalk.green(`\n  Created pattern: ${chalk.bold(pattern.label)}`));
      if (pattern.inheritsFrom) {
        const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
        console.log(chalk.cyan(`  Inherits from: ${parent?.label || pattern.inheritsFrom}`));
      }

      const resolved = resolvePattern(config, pattern);
      const comps = getResolvedComponents(config, resolved);
      if (comps.persona) console.log(chalk.blue(`  Persona: ${comps.persona.name}`));
      if (comps.thinking) console.log(chalk.magenta(`  Thinking: ${comps.thinking.name}`));
      if (comps.dialogue) console.log(chalk.green(`  Dialogue: ${comps.dialogue.name}`));
      console.log();
    }
  });

program
  .command('delete-pattern <name>')
  .description('Delete a pattern')
  .action((name: string) => {
    const config = getConfig();
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const idx = config.patterns.findIndex(
      (p) => p.id === id || p.name === name || p.label === name
    );

    if (idx < 0) {
      console.log(chalk.red(`  Pattern "${name}" not found.`));
      process.exit(1);
    }

    const removed = config.patterns.splice(idx, 1)[0];
    config.patterns = config.patterns.map((p) => {
      if (p.inheritsFrom === removed.id) return { ...p, inheritsFrom: null };
      return p;
    });

    saveConfig(config);
    console.log(chalk.green(`  Deleted pattern: ${chalk.bold(removed.label)}\n`));
  });

// ==================== SHOW & USE ====================

program
  .command('show <pattern>')
  .description('Show pattern details')
  .option('-e, --export <file>', 'Export merged config to file')
  .action((name: string, options: { export?: string }) => {
    const config = getConfig();
    const pattern = findPattern(config, name);
    if (!pattern) {
      console.log(chalk.red(`  Pattern "${name}" not found.`));
      process.exit(1);
    }

    if (options.export) {
      const output = exportPatternMarkdown(config, pattern);
      fs.writeFileSync(path.resolve(options.export), output, 'utf-8');
      console.log(chalk.green(`  Exported to: ${path.resolve(options.export)}\n`));
      return;
    }

    const resolved = resolvePattern(config, pattern);
    const comps = getResolvedComponents(config, resolved);

    console.log(chalk.bold('\n  ============================================\n'));
    if (pattern.inheritsFrom) {
      const parent = config.patterns.find((p) => p.id === pattern.inheritsFrom);
      console.log(chalk.cyan(`  ${pattern.label} ${chalk.yellow(`(inherits from ${parent?.label || pattern.inheritsFrom})`)}\n`));
    } else {
      console.log(chalk.cyan(`  ${pattern.label}\n`));
    }

    if (comps.persona) {
      console.log(chalk.blueBright('  [PERSONA]'));
      console.log(`  ${comps.persona.name}`);
      console.log(chalk.gray(`  ${comps.persona.description}`));
      console.log();
    }
    if (comps.thinking) {
      console.log(chalk.magentaBright('  [THINKING MODEL]'));
      console.log(`  ${comps.thinking.name}`);
      console.log(chalk.gray(`  ${comps.thinking.description}`));
      console.log();
    }
    if (comps.dialogue) {
      console.log(chalk.greenBright('  [DIALOGUE PATTERN]'));
      console.log(`  ${comps.dialogue.name}`);
      console.log(chalk.gray(`  ${comps.dialogue.description}`));
      console.log();
    }
    console.log(chalk.bold('  ============================================\n'));
  });

program
  .command('use <pattern>')
  .description('Output merged pattern config (for piping to opencode)')
  .action((name: string) => {
    const config = getConfig();
    const pattern = findPattern(config, name);
    if (!pattern) {
      console.log(chalk.red(`  Pattern "${name}" not found.`));
      process.exit(1);
    }
    console.log(exportPatternMarkdown(config, pattern));
  });

// ==================== SLOT COMMANDS ====================

program
  .command('set-persona <pattern> <persona>')
  .description('Set persona for a pattern')
  .action((p: string, c: string) => setSlot(p, 'persona', c));

program
  .command('set-thinking <pattern> <thinking>')
  .description('Set thinking model for a pattern')
  .action((p: string, c: string) => setSlot(p, 'thinking', c));

program
  .command('set-dialogue <pattern> <dialogue>')
  .description('Set dialogue pattern for a pattern')
  .action((p: string, c: string) => setSlot(p, 'dialogue', c));

program
  .command('clear-persona <pattern>')
  .description('Clear persona from a pattern')
  .action((p: string) => clearSlot(p, 'persona'));

program
  .command('clear-thinking <pattern>')
  .description('Clear thinking model from a pattern')
  .action((p: string) => clearSlot(p, 'thinking'));

program
  .command('clear-dialogue <pattern>')
  .description('Clear dialogue pattern from a pattern')
  .action((p: string) => clearSlot(p, 'dialogue'));

// ==================== OPENCODE EXPORT ====================

program
  .command('install-opencode')
  .description('Install all patterns as OpenCode modes (Tab-switchable)')
  .option('--project', 'Install to project .opencode/modes/ instead of global')
  .action((options: { project?: boolean }) => {
    const config = getConfig();
    const { installed, errors } = installPatternsToOpenCode(config);

    if (installed.length > 0) {
      console.log(chalk.green('\n  Installed patterns as OpenCode modes:\n'));
      installed.forEach((i) => console.log(`    ${chalk.cyan('✓')} ${i}`));
    }

    if (errors.length > 0) {
      console.log(chalk.red('\n  Errors:'));
      errors.forEach((e) => console.log(`    ${chalk.red('✗')} ${e}`));
    }

    console.log(chalk.gray(`\n  Modes directory: ${options.project ? getProjectOpencodeModesDir() : getOpencodeModesDir()}`));
    console.log(chalk.gray('  Restart OpenCode and press Tab to switch between modes\n'));
  });

program
  .command('export-opencode-json [file]')
  .description('Export all patterns as OpenCode JSON config')
  .action((file?: string) => {
    const config = getConfig();
    const outPath = file || 'opencode.json';
    writeOpenCodeJson(config, path.resolve(outPath));
    console.log(chalk.green(`\n  Exported OpenCode config to: ${path.resolve(outPath)}\n`));
    console.log(chalk.gray('  Add to your opencode.json or use as a standalone config\n'));
  });

program
  .command('export-opencode-mode <pattern> [file]')
  .description('Export a single pattern as OpenCode markdown mode')
  .action((name: string, file?: string) => {
    const config = getConfig();
    const pattern = findPattern(config, name);
    if (!pattern) {
      console.log(chalk.red(`  Pattern "${name}" not found.`));
      process.exit(1);
    }

    const { writeOpenCodeModeFile } = require('@opencode-patterns/core');
    const targetDir = file
      ? (file.endsWith('/') || file.endsWith('\\') ? path.resolve(file) : path.dirname(path.resolve(file)))
      : getOpencodeModesDir();
    const filePath = writeOpenCodeModeFile(config, pattern, targetDir);

    console.log(chalk.green(`\n  Exported mode: ${chalk.bold(pattern.label)}`));
    console.log(chalk.gray(`  File: ${filePath}`));
    console.log(chalk.gray('  Press Tab in OpenCode to switch to this mode\n'));
  });

// ==================== SYNC ====================

program
  .command('sync')
  .description('Scan project directories and sync all .md files to config')
  .action(() => {
    const config = getConfig();
    saveConfig(config);
    console.log(chalk.green(`\n  Synced project directories to config`));
    console.log(chalk.gray(`  Config: ${getConfigPath()}`));
    console.log(chalk.gray(`  Personas: ${config.personas.length}`));
    console.log(chalk.gray(`  Thinking Models: ${config.thinkingModels.length}`));
    console.log(chalk.gray(`  Dialogue Patterns: ${config.dialoguePatterns.length}`));
    console.log(chalk.gray(`  Patterns: ${config.patterns.length}\n`));
  });

// ==================== HELP ====================

program.on('--help', () => {
  console.log('');
  console.log(chalk.cyan('  Quick Start:'));
  console.log('');
  console.log(chalk.gray('    $ opencode-patterns wizard                    # Interactive wizard'));
  console.log(chalk.gray('    $ opencode-patterns sync                        # Scan and sync .md files'));
  console.log(chalk.gray('    $ opencode-patterns create-pattern Plan -p java -t OODA -d socratic'));
  console.log(chalk.gray('    $ opencode-patterns create-pattern NewPlan --inherit Plan -p python'));
  console.log(chalk.gray('    $ opencode-patterns install-opencode            # Install as OpenCode modes'));
  console.log(chalk.gray('    $ opencode-patterns use Plan | opencode         # Pipe to OpenCode'));
  console.log('');
  console.log(chalk.cyan('  OpenCode Integration:'));
  console.log('');
  console.log(chalk.gray('    After install-opencode, restart OpenCode and press Tab to switch modes.'));
  console.log(chalk.gray('    Patterns become first-class OpenCode modes like [Plan] and [Build].'));
  console.log('');
});

// ==================== HELPERS ====================

function listAll(config: Config): void {
  console.log(chalk.bold('\n  === Pattern Orchestrator ===\n'));
  listComponents(config.personas, 'Personas', chalk.blueBright);
  listComponents(config.thinkingModels, 'Thinking Models', chalk.magentaBright);
  listComponents(config.dialoguePatterns, 'Dialogue Patterns', chalk.greenBright);
  listPatterns(config);
}

function listComponents<T extends { fileName: string; description: string }>(
  items: T[],
  title: string,
  color: (s: string) => string
): void {
  console.log(color(`  [${title}]`));
  if (items.length === 0) {
    console.log(chalk.gray('    (none)\n'));
    return;
  }
  for (const item of items) {
    console.log(`    ${chalk.white.bold(item.fileName)}`);
    console.log(chalk.gray(`      ${item.description || '(no description)'}\n`));
  }
}

function listPatterns(config: Config): void {
  console.log(chalk.cyanBright('  [Patterns]'));
  if (config.patterns.length === 0) {
    console.log(chalk.gray('    (none)\n'));
    return;
  }
  for (const pattern of config.patterns) {
    const resolved = resolvePattern(config, pattern);
    const inherits = pattern.inheritsFrom
      ? chalk.yellow(` <- [${pattern.inheritsFrom}]`)
      : '';

    console.log(`    ${chalk.white.bold(pattern.label)}${inherits}`);

    const slots = [];
    if (resolved.slots.persona) {
      const c = config.personas.find((p) => p.id === resolved.slots.persona);
      slots.push(chalk.blue(`persona:${c?.name || resolved.slots.persona}`));
    }
    if (resolved.slots.thinking) {
      const c = config.thinkingModels.find((t) => t.id === resolved.slots.thinking);
      slots.push(chalk.magenta(`thinking:${c?.name || resolved.slots.thinking}`));
    }
    if (resolved.slots.dialogue) {
      const c = config.dialoguePatterns.find((d) => d.id === resolved.slots.dialogue);
      slots.push(chalk.green(`dialogue:${c?.name || resolved.slots.dialogue}`));
    }

    if (slots.length > 0) {
      console.log(`      ${slots.join(' | ')}\n`);
    } else {
      console.log(chalk.gray('      (empty slots)\n'));
    }
  }
}

function addComponent(type: ComponentType, sourcePath: string): void {
  if (!fs.existsSync(sourcePath)) {
    console.log(chalk.red(`  File not found: ${sourcePath}`));
    process.exit(1);
  }

  const config = getConfig();
  const component = loadMdFile(sourcePath, type);

  const targetDir = path.join(process.cwd(), DIRS[type]);
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
  const targetPath = path.join(targetDir, component.fileName);
  fs.copyFileSync(sourcePath, targetPath);

  const arr =
    type === 'persona'
      ? config.personas
      : type === 'thinking'
        ? config.thinkingModels
        : config.dialoguePatterns;

  const existing = arr.findIndex((c) => c.id === component.id);
  if (existing >= 0) {
    arr[existing] = component;
    console.log(chalk.yellow(`  Updated ${type}: ${chalk.bold(component.fileName)}`));
  } else {
    arr.push(component);
    console.log(chalk.green(`  Added ${type}: ${chalk.bold(component.fileName)}`));
  }

  saveConfig(config);
  console.log(chalk.gray(`  Saved to: ${targetPath}\n`));
}

function removeComponent(type: ComponentType, idOrName: string): void {
  const config = getConfig();
  const arr =
    type === 'persona'
      ? config.personas
      : type === 'thinking'
        ? config.thinkingModels
        : config.dialoguePatterns;

  const idx = arr.findIndex(
    (c) => c.id === idOrName || c.name === idOrName || c.fileName === idOrName
  );
  if (idx < 0) {
    console.log(chalk.red(`  ${type} "${idOrName}" not found.`));
    process.exit(1);
  }

  const removed = arr.splice(idx, 1)[0];
  const slotKey = type === 'persona' ? 'persona' : type === 'thinking' ? 'thinking' : 'dialogue';
  config.patterns = config.patterns.map((p) => {
    if (p.slots[slotKey] === removed.id) {
      return { ...p, slots: { ...p.slots, [slotKey]: null } };
    }
    return p;
  });

  saveConfig(config);
  console.log(chalk.green(`  Removed ${type}: ${chalk.bold(removed.fileName)}\n`));
}

function findPattern(config: Config, name: string): Pattern | undefined {
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  return config.patterns.find((p) => p.id === id || p.name === name || p.label === name);
}

function setSlot(patternName: string, slotType: ComponentType, componentId: string): void {
  const config = getConfig();
  const pattern = findPattern(config, patternName);
  if (!pattern) {
    console.log(chalk.red(`  Pattern "${patternName}" not found.`));
    process.exit(1);
  }

  const component = findComponent(config, componentId, slotType);
  if (!component) {
    console.log(chalk.red(`  ${slotType} "${componentId}" not found.`));
    process.exit(1);
  }

  const slotKey = slotType === 'persona' ? 'persona' : slotType === 'thinking' ? 'thinking' : 'dialogue';
  pattern.slots[slotKey] = component.id;
  saveConfig(config);

  const color = slotType === 'persona' ? chalk.blue : slotType === 'thinking' ? chalk.magenta : chalk.green;
  console.log(color(`  Set ${slotType} of ${pattern.label} to ${component.name}\n`));
}

function clearSlot(patternName: string, slotType: ComponentType): void {
  const config = getConfig();
  const pattern = findPattern(config, patternName);
  if (!pattern) {
    console.log(chalk.red(`  Pattern "${patternName}" not found.`));
    process.exit(1);
  }

  const slotKey = slotType === 'persona' ? 'persona' : slotType === 'thinking' ? 'thinking' : 'dialogue';
  pattern.slots[slotKey] = null;
  saveConfig(config);
  console.log(chalk.yellow(`  Cleared ${slotType} from ${pattern.label}\n`));
}

program.parse();
