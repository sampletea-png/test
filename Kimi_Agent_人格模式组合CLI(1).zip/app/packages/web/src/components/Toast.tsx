import { CheckCircle, Info } from 'lucide-react';

interface Props {
  message: string;
  type: 'success' | 'info';
}

export function Toast({ message, type }: Props) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-lg 
                    bg-[#1A1A1A] border border-[#333] shadow-xl"
         style={{ animation: 'fadeIn 0.2s ease-out' }}>
      {type === 'success'
        ? <CheckCircle size={14} className="text-emerald-400" />
        : <Info size={14} className="text-blue-400" />
      }
      <span className="text-xs text-[#F3F4F6]">{message}</span>
    </div>
  );
}
