import type { Pattern } from '../data/types';
import { Plus, Trash2 } from 'lucide-react';

interface Props {
  patterns: Pattern[];
  activePatternId: string;
  onSelectPattern: (id: string) => void;
  onCreateClick: () => void;
  onDeletePattern: (id: string) => void;
}

export function Header({ patterns, activePatternId, onSelectPattern, onCreateClick, onDeletePattern }: Props) {
  return (
    <header className="h-14 flex-shrink-0 flex items-center justify-between px-5 border-b border-[#333] bg-[#111]">
      <div className="flex items-center gap-2.5">
        <svg width="22" height="22" viewBox="0 0 28 28" fill="none">
          <path d="M14 2L25.5 8.5V19.5L14 26L2.5 19.5V8.5L14 2Z" stroke="#3B82F6" strokeWidth="1.5" fill="none" />
          <path d="M14 8L20 11.5V18.5L14 22L8 18.5V11.5L14 8Z" stroke="#3B82F6" strokeWidth="1" fill="none" opacity="0.6" />
          <circle cx="14" cy="15" r="2" fill="#3B82F6" opacity="0.8" />
        </svg>
        <h1 className="text-sm font-bold tracking-tight text-[#F3F4F6]">模式编排器</h1>
        <span className="text-[10px] font-semibold text-[#9CA3AF] bg-[#1A1A1A] px-1.5 py-0.5 rounded">
          {patterns.length} 模式
        </span>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 mr-3">
          {patterns.map((p) => (
            <button
              key={p.id}
              onClick={() => onSelectPattern(p.id)}
              className={`
                px-2.5 py-1 rounded text-xs font-medium transition-all
                ${activePatternId === p.id
                  ? 'bg-blue-500/15 text-blue-400 border border-blue-500/40'
                  : 'bg-[#1A1A1A] text-[#9CA3AF] border border-[#333] hover:border-[#444] hover:text-[#F3F4F6]'
                }
              `}
            >
              {p.label}
              {p.inheritsFrom && (
                <span className="text-[9px] opacity-50 ml-1">←[{p.inheritsFrom}]</span>
              )}
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            const toDelete = patterns.find((p) => p.id === activePatternId);
            if (toDelete && confirm(`Delete ${toDelete.label}?`)) {
              onDeletePattern(activePatternId);
            }
          }}
          className="h-8 px-3 rounded-md border border-[#333] bg-[#1A1A1A] text-[#9CA3AF] 
                     text-xs font-medium hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30
                     transition-all flex items-center gap-1.5"
        >
          <Trash2 size={12} />
          Remove
        </button>

        <button
          onClick={onCreateClick}
          className="h-8 px-3 rounded-md border-0 bg-blue-600 text-white text-xs font-medium
                     hover:bg-blue-500 transition-all flex items-center gap-1.5
                     shadow-[0_0_12px_rgba(59,130,246,0.3)]"
        >
          <Plus size={12} />
          New Pattern
        </button>
      </div>
    </header>
  );
}
