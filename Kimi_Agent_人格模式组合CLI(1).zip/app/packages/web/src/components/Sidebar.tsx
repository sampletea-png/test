import { useState } from 'react';
import type { BaseComponent, ComponentType } from '../data/types';
import { COMPONENT_COLORS } from '../data/types';
import { Search, ChevronDown, ChevronRight } from 'lucide-react';

interface Props {
  personas: BaseComponent[];
  thinkingModels: BaseComponent[];
  dialoguePatterns: BaseComponent[];
  onSelectComponent: (comp: BaseComponent) => void;
}

const SECTIONS: { type: ComponentType; label: string; bracket: string }[] = [
  { type: 'persona', label: '人格', bracket: 'PERSONAS' },
  { type: 'thinking', label: '思维模型', bracket: 'THINKING MODELS' },
  { type: 'dialogue', label: '对话模式', bracket: 'DIALOGUE PATTERNS' },
];

export function Sidebar({ personas, thinkingModels, dialoguePatterns, onSelectComponent }: Props) {
  const [search, setSearch] = useState('');
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const allComponents = { persona: personas, thinking: thinkingModels, dialogue: dialoguePatterns };

  const toggleSection = (type: string) => setCollapsed((p) => ({ ...p, [type]: !p[type] }));

  return (
    <aside className="w-72 min-w-[288px] bg-[#111] border-r border-[#333] flex flex-col overflow-hidden">
      <div className="p-4 border-b border-[#333]">
        <div className="h-8 flex items-center gap-2 px-2 border-b border-[#333] focus-within:border-blue-500 transition-colors">
          <Search size={13} className="text-[#9CA3AF] flex-shrink-0" />
          <input
            type="text"
            placeholder="Search components..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent border-0 outline-0 text-[13px] text-[#F3F4F6] placeholder:text-[#555]"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {SECTIONS.map(({ type, bracket }) => {
          const items = allComponents[type].filter((c) =>
            !search ||
            c.name.toLowerCase().includes(search.toLowerCase()) ||
            c.description.toLowerCase().includes(search.toLowerCase())
          );
          if (search && items.length === 0) return null;

          const isCollapsed = collapsed[type];
          const colors = COMPONENT_COLORS[type];

          return (
            <div key={type} className="mb-1">
              <button
                onClick={() => toggleSection(type)}
                className="w-full flex items-center gap-1.5 py-1.5 px-1 text-[11px] font-semibold text-[#9CA3AF] 
                           tracking-wider hover:text-[#F3F4F6] transition-colors"
              >
                {isCollapsed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
                [{bracket}]
                <span className="ml-auto text-[10px] opacity-50">{items.length}</span>
              </button>

              {!isCollapsed && (
                <div className="flex flex-col gap-1">
                  {items.map((comp) => (
                    <button
                      key={comp.id}
                      onClick={() => onSelectComponent(comp)}
                      className="w-full text-left p-2.5 rounded-md bg-[#1A1A1A] border border-transparent
                                 hover:bg-[#222] hover:border-[#444] transition-all group"
                    >
                      <div className="flex items-start gap-2">
                        <div className={`w-1 min-h-[28px] rounded-full flex-shrink-0 ${colors.bg.replace('bg-', 'bg-').replace('/10', '')}`} 
                             style={{ backgroundColor: type === 'persona' ? '#3B82F6' : type === 'thinking' ? '#8B5CF6' : '#10B981' }} />
                        <div className="min-w-0 flex-1">
                          <div className="text-[12px] font-medium text-[#F3F4F6] truncate">{comp.fileName}</div>
                          <div className="text-[11px] text-[#9CA3AF] leading-relaxed line-clamp-2">{comp.description}</div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
}
