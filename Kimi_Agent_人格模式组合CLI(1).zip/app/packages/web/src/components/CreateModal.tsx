import { useState } from 'react';
import type { Pattern, BaseComponent } from '../data/types';
import { X, GitBranch } from 'lucide-react';

interface Props {
  patterns: Pattern[];
  personas: BaseComponent[];
  thinkingModels: BaseComponent[];
  dialoguePatterns: BaseComponent[];
  onCreate: (name: string, opts: {
    inherit?: string | null;
    persona?: string | null;
    thinking?: string | null;
    dialogue?: string | null;
  }) => void;
  onClose: () => void;
}

export function CreateModal({ patterns, personas, thinkingModels, dialoguePatterns, onCreate, onClose }: Props) {
  const [name, setName] = useState('');
  const [inherit, setInherit] = useState('');
  const [persona, setPersona] = useState('');
  const [thinking, setThinking] = useState('');
  const [dialogue, setDialogue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onCreate(name.trim(), {
      inherit: inherit || null,
      persona: persona || null,
      thinking: thinking || null,
      dialogue: dialogue || null,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-[500px] max-w-[calc(100vw-32px)] bg-[#111] border border-[#333] rounded-lg 
                      shadow-2xl" style={{ animation: 'scaleIn 0.4s cubic-bezier(0.16,1,0.3,1)' }}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#333]">
          <h2 className="text-sm font-semibold text-[#F3F4F6]">Create New Pattern</h2>
          <button onClick={onClose}
            className="w-8 h-8 rounded-md flex items-center justify-center text-[#9CA3AF] hover:bg-[#222] hover:text-white transition-all">
            <X size={16} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit}>
          <div className="px-6 py-5 flex flex-col gap-4">
            {/* Name */}
            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1.5 tracking-wider">PATTERN NAME</label>
              <input
                type="text" value={name} onChange={(e) => setName(e.target.value)}
                placeholder="e.g., CodeReview, Debug, Architecture"
                autoFocus
                className="w-full h-10 px-3 rounded-md border border-[#333] bg-[#0A0A0A] text-[#F3F4F6] text-sm
                           outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Inherit */}
            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1.5 tracking-wider flex items-center gap-1">
                <GitBranch size={10} /> INHERIT FROM
              </label>
              <select
                value={inherit} onChange={(e) => setInherit(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-[#333] bg-[#0A0A0A] text-[#F3F4F6] text-sm
                           outline-none focus:border-blue-500 transition-colors appearance-none"
              >
                <option value="">None (create from scratch)</option>
                {patterns.map((p) => (
                  <option key={p.id} value={p.id}>{p.label} {p.inheritsFrom ? `(inherits ${p.inheritsFrom})` : ''}</option>
                ))}
              </select>
              <p className="text-[10px] text-[#9CA3AF] mt-1.5 opacity-60">
                New pattern will auto-inherit parent's components, you can override any slot.
              </p>
            </div>

            {/* Slots */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[10px] font-semibold text-blue-400 mb-1.5">PERSONA</label>
                <select value={persona} onChange={(e) => setPersona(e.target.value)}
                  className="w-full h-9 px-2 rounded border border-[#333] bg-[#0A0A0A] text-[#F3F4F6] text-xs outline-none focus:border-blue-500">
                  <option value="">None</option>
                  {personas.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-purple-400 mb-1.5">THINKING</label>
                <select value={thinking} onChange={(e) => setThinking(e.target.value)}
                  className="w-full h-9 px-2 rounded border border-[#333] bg-[#0A0A0A] text-[#F3F4F6] text-xs outline-none focus:border-blue-500">
                  <option value="">None</option>
                  {thinkingModels.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-emerald-400 mb-1.5">DIALOGUE</label>
                <select value={dialogue} onChange={(e) => setDialogue(e.target.value)}
                  className="w-full h-9 px-2 rounded border border-[#333] bg-[#0A0A0A] text-[#F3F4F6] text-xs outline-none focus:border-blue-500">
                  <option value="">None</option>
                  {dialoguePatterns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-3 border-t border-[#333] flex justify-end gap-2">
            <button type="button" onClick={onClose}
              className="h-8 px-4 rounded-md border border-[#333] bg-[#1A1A1A] text-[#F3F4F6] text-xs font-medium
                         hover:bg-[#222] transition-all">Cancel</button>
            <button type="submit" disabled={!name.trim()}
              className={`h-8 px-4 rounded-md border-0 text-xs font-medium transition-all
                ${name.trim()
                  ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                  : 'bg-[#333] text-[#9CA3AF] cursor-not-allowed'
                }`}>
              Create Pattern
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
