import type { usePatternStore } from '../hooks/usePatternStore';
import type { ComponentType } from '../data/types';
import { COMPONENT_COLORS } from '../data/types';
import { X, Download, FileCode, Copy, Check } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

interface Props {
  store: ReturnType<typeof usePatternStore>;
  showToast: (msg: string, type?: 'success' | 'info') => void;
}

const SLOT_ORDER: { key: ComponentType; label: string; subLabel: string }[] = [
  { key: 'persona', label: '人格', subLabel: 'PERSONA' },
  { key: 'thinking', label: '思维模型', subLabel: 'THINKING MODEL' },
  { key: 'dialogue', label: '对话模式', subLabel: 'DIALOGUE PATTERN' },
];

export function Workspace({ store, showToast }: Props) {
  const { activePattern, resolvedActive, resolvedComponents, patterns } = store;
  const [activeTab, setActiveTab] = useState<'json' | 'simulation'>('json');
  const [typedText, setTypedText] = useState('');
  const [copied, setCopied] = useState(false);
  const typingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  if (!activePattern || !resolvedActive) {
    return (
      <div className="flex-1 flex items-center justify-center text-[#9CA3AF] text-sm">
        Select or create a pattern to get started
      </div>
    );
  }

  const jsonOutput = store.generateJson(activePattern);
  const fullMarkdown = store.exportPatternMarkdown(activePattern);

  // Typewriter effect
  useEffect(() => {
    if (activeTab !== 'simulation') return;
    const text = fullMarkdown.slice(0, 2000);
    setTypedText('');
    let i = 0;
    if (typingRef.current) clearInterval(typingRef.current);
    typingRef.current = setInterval(() => {
      if (i < text.length) { setTypedText(text.slice(0, ++i)); }
      else if (typingRef.current) clearInterval(typingRef.current);
    }, 5);
    return () => { if (typingRef.current) clearInterval(typingRef.current); };
  }, [activeTab, activePattern.id]);

  const handleCopy = () => {
    navigator.clipboard.writeText(fullMarkdown);
    setCopied(true);
    showToast('Copied to clipboard', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportMd = () => {
    store.downloadFile(`${activePattern.id}.md`, fullMarkdown);
    showToast(`Exported ${activePattern.id}.md`, 'success');
  };

  const handleExportOpenCode = () => {
    const mode = store.exportAsOpenCodeMode(activePattern);
    store.downloadFile(`${mode.name}.md`, mode.content);
    showToast(`Exported OpenCode mode: ${mode.name}.md`, 'success');
  };

  const handleExportJson = () => {
    store.downloadFile('opencode.json', jsonOutput, 'application/json');
    showToast('Exported opencode.json', 'success');
  };

  const parent = activePattern.inheritsFrom
    ? patterns.find((p) => p.id === activePattern.inheritsFrom)
    : null;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Pattern Info */}
      <div className="px-6 pt-5 pb-3 flex items-center gap-3 flex-wrap">
        <div className="px-3.5 py-1.5 rounded bg-white/5 text-sm font-semibold text-[#F3F4F6] flex items-center gap-2">
          {activePattern.label}
          {activePattern.inheritsFrom && (
            <span className="text-blue-400 text-xs">(modified)</span>
          )}
        </div>
        {parent && (
          <>
            <span className="text-xs text-[#9CA3AF]">inherits from</span>
            <div className="px-2.5 py-1 rounded bg-white/[0.03] text-xs text-[#9CA3AF] border border-dashed border-[#333]">
              {parent.label}
            </div>
          </>
        )}
        <div className="ml-auto flex items-center gap-2">
          <button onClick={handleCopy}
            className="h-7 px-2.5 rounded-md bg-[#1A1A1A] border border-[#333] text-[#9CA3AF] text-xs
                       hover:bg-[#222] hover:text-white transition-all flex items-center gap-1.5">
            {copied ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
          <button onClick={handleExportMd}
            className="h-7 px-2.5 rounded-md bg-[#1A1A1A] border border-[#333] text-[#9CA3AF] text-xs
                       hover:bg-[#222] hover:text-white transition-all flex items-center gap-1.5">
            <FileCode size={11} />
            .md
          </button>
          <button onClick={handleExportOpenCode}
            className="h-7 px-2.5 rounded-md bg-blue-600/20 border border-blue-500/30 text-blue-400 text-xs
                       hover:bg-blue-600/30 transition-all flex items-center gap-1.5">
            <Download size={11} />
            OpenCode
          </button>
          <button onClick={handleExportJson}
            className="h-7 px-2.5 rounded-md bg-[#1A1A1A] border border-[#333] text-[#9CA3AF] text-xs
                       hover:bg-[#222] hover:text-white transition-all flex items-center gap-1.5">
            <FileCode size={11} />
            .json
          </button>
        </div>
      </div>

      {/* Slots */}
      <div className="px-6 pb-3 flex-1 overflow-y-auto">
        <div className="flex flex-col gap-3">
          {SLOT_ORDER.map(({ key, label, subLabel }) => {
            const comp = resolvedComponents[key];
            const colors = COMPONENT_COLORS[key];

            return (
              <div key={key} className="min-h-[100px] rounded-lg border border-[#333] bg-[#0A0A0A] p-3 relative">
                {comp ? (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10px] font-bold tracking-wider ${colors.text}`}>{subLabel}</span>
                      <div className="h-px flex-1 bg-[#333]" />
                    </div>
                    <div className="flex items-start gap-2">
                      <div className={`w-1 min-h-[30px] rounded-full ${colors.bg}`} 
                           style={{ backgroundColor: key === 'persona' ? '#3B82F6' : key === 'thinking' ? '#8B5CF6' : '#10B981' }} />
                      <div className="flex-1 min-w-0">
                        <div className="text-[12px] font-medium text-[#F3F4F6]">{comp.fileName}</div>
                        <div className="text-[11px] text-[#9CA3AF] line-clamp-2 leading-relaxed">{comp.description}</div>
                      </div>
                      <button
                        onClick={() => { store.setSlot(activePattern.id, key, null); showToast(`Cleared ${key}`, 'info'); }}
                        className="w-6 h-6 rounded flex items-center justify-center text-[#9CA3AF] 
                                   hover:bg-red-500/10 hover:text-red-400 transition-all flex-shrink-0"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center gap-1.5 text-[#9CA3AF] opacity-40 min-h-[80px]">
                    <span className="text-xs font-medium">+ {label} ({subLabel})</span>
                    <span className="text-[10px]">Click a component from sidebar or drop here</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Preview Console */}
      <div className="h-[220px] bg-[#111] border-t border-[#333] flex flex-col flex-shrink-0">
        <div className="flex border-b border-[#333] px-4">
          {(['json', 'simulation'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2.5 text-xs font-semibold tracking-wider transition-all border-b-2
                ${activeTab === tab
                  ? 'text-[#F3F4F6] border-blue-500'
                  : 'text-[#9CA3AF] border-transparent hover:text-[#F3F4F6]'
                }`}
            >
              {tab === 'json' ? 'JSON Preview' : 'Terminal Simulation'}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-hidden p-3">
          {activeTab === 'json' ? (
            <pre className="h-full overflow-auto text-[11px] leading-relaxed text-[#9CA3AF] font-mono m-0">
              <code>{jsonOutput}</code>
            </pre>
          ) : (
            <div className="h-full overflow-auto flex flex-col">
              <div className="flex items-center gap-1.5 mb-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
                <span className="text-[10px] text-[#9CA3AF] opacity-50 ml-2 font-mono">system-prompt-preview</span>
              </div>
              <pre className="text-[11px] leading-relaxed text-[#9CA3AF] font-mono whitespace-pre-wrap break-words m-0 flex-1">
                {typedText}
                <span className="text-blue-400 animate-pulse">_</span>
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
