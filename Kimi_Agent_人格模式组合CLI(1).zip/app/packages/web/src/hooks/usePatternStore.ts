import { useState, useCallback, useMemo } from 'react';
import type { BaseComponent, Pattern, ComponentType } from '../data/types';
import { personas } from '../data/personas';
import { thinkingModels } from '../data/thinking';
import { dialoguePatterns } from '../data/dialogue';

export function usePatternStore() {
  const [allPersonas] = useState<BaseComponent[]>(personas);
  const [allThinking] = useState<BaseComponent[]>(thinkingModels);
  const [allDialogue] = useState<BaseComponent[]>(dialoguePatterns);

  const [patterns, setPatterns] = useState<Pattern[]>([
    {
      id: 'plan',
      name: 'Plan',
      label: '[Plan]',
      inheritsFrom: null,
      slots: { persona: 'java-engineer', thinking: 'ooda-loop', dialogue: 'socratic-dialogue' },
    },
    {
      id: 'build',
      name: 'Build',
      label: '[Build]',
      inheritsFrom: null,
      slots: { persona: 'python-expert', thinking: 'first-principles', dialogue: 'direct-answer' },
    },
    {
      id: 'research',
      name: 'Research',
      label: '[Research]',
      inheritsFrom: null,
      slots: { persona: 'frontend-architect', thinking: 'systems-thinking', dialogue: 'exploration-mode' },
    },
  ]);

  const [activePatternId, setActivePatternId] = useState<string>('plan');
  const [activeTab, setActiveTab] = useState<'json' | 'simulation'>('json');

  const getComponent = useCallback((id: string | null, type: ComponentType): BaseComponent | null => {
    if (!id) return null;
    const arr = type === 'persona' ? allPersonas : type === 'thinking' ? allThinking : allDialogue;
    return arr.find((c) => c.id === id) ?? null;
  }, [allPersonas, allThinking, allDialogue]);

  const resolvePattern = useCallback((pattern: Pattern): Pattern => {
    if (!pattern.inheritsFrom) return pattern;
    const parent = patterns.find((p) => p.id === pattern.inheritsFrom);
    if (!parent) return pattern;
    const resolvedParent = resolvePattern(parent);
    return {
      ...pattern,
      slots: {
        persona: pattern.slots.persona ?? resolvedParent.slots.persona,
        thinking: pattern.slots.thinking ?? resolvedParent.slots.thinking,
        dialogue: pattern.slots.dialogue ?? resolvedParent.slots.dialogue,
      },
    };
  }, [patterns]);

  const activePattern = useMemo(() => patterns.find((p) => p.id === activePatternId) ?? null, [patterns, activePatternId]);

  const resolvedActive = useMemo(() => activePattern ? resolvePattern(activePattern) : null, [activePattern, resolvePattern]);

  const resolvedComponents = useMemo(() => {
    if (!resolvedActive) return { persona: null, thinking: null, dialogue: null };
    return {
      persona: getComponent(resolvedActive.slots.persona, 'persona'),
      thinking: getComponent(resolvedActive.slots.thinking, 'thinking'),
      dialogue: getComponent(resolvedActive.slots.dialogue, 'dialogue'),
    };
  }, [resolvedActive, getComponent]);

  const createPattern = useCallback((name: string, options: {
    inherit?: string | null;
    persona?: string | null;
    thinking?: string | null;
    dialogue?: string | null;
  }) => {
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const label = `[${name}]`;

    if (patterns.some((p) => p.id === id)) return null;

    let slots = { persona: null as string | null, thinking: null as string | null, dialogue: null as string | null };
    let inheritsFrom: string | null = null;

    if (options.inherit) {
      const parent = patterns.find((p) => p.id === options.inherit);
      if (parent) {
        const resolved = resolvePattern(parent);
        slots = { ...resolved.slots };
        inheritsFrom = parent.id;
      }
    }

    if (options.persona) slots.persona = options.persona;
    if (options.thinking) slots.thinking = options.thinking;
    if (options.dialogue) slots.dialogue = options.dialogue;

    const newPattern: Pattern = { id, name, label, inheritsFrom, slots };
    setPatterns((prev) => [...prev, newPattern]);
    setActivePatternId(id);
    return newPattern;
  }, [patterns, resolvePattern]);

  const deletePattern = useCallback((id: string) => {
    setPatterns((prev) => {
      const filtered = prev.filter((p) => p.id !== id);
      return filtered.map((p) => p.inheritsFrom === id ? { ...p, inheritsFrom: null } : p);
    });
    if (activePatternId === id) {
      const remaining = patterns.filter((p) => p.id !== id);
      setActivePatternId(remaining[0]?.id ?? '');
    }
  }, [activePatternId, patterns]);

  const setSlot = useCallback((patternId: string, slotType: ComponentType, componentId: string | null) => {
    setPatterns((prev) => prev.map((p) => {
      if (p.id !== patternId) return p;
      return { ...p, slots: { ...p.slots, [slotType]: componentId } };
    }));
  }, []);

  const exportPatternMarkdown = useCallback((pattern: Pattern): string => {
    const resolved = resolvePattern(pattern);
    const parts: string[] = [];
    parts.push(`# Pattern: ${pattern.label}`);
    if (pattern.inheritsFrom) parts.push(`# Inherits from: ${pattern.inheritsFrom}`);
    parts.push('');
    const p = getComponent(resolved.slots.persona, 'persona');
    const t = getComponent(resolved.slots.thinking, 'thinking');
    const d = getComponent(resolved.slots.dialogue, 'dialogue');
    if (p) { parts.push(`## Persona: ${p.name}`); parts.push(p.content); parts.push(''); }
    if (t) { parts.push(`## Thinking Model: ${t.name}`); parts.push(t.content); parts.push(''); }
    if (d) { parts.push(`## Dialogue Pattern: ${d.name}`); parts.push(d.content); parts.push(''); }
    return parts.join('\n');
  }, [resolvePattern, getComponent]);

  const exportAsOpenCodeMode = useCallback((pattern: Pattern): { name: string; content: string } => {
    const resolved = resolvePattern(pattern);
    const p = getComponent(resolved.slots.persona, 'persona');
    const t = getComponent(resolved.slots.thinking, 'thinking');
    const d = getComponent(resolved.slots.dialogue, 'dialogue');

    const bodyParts: string[] = [];
    if (p) bodyParts.push(p.content);
    if (t) bodyParts.push(`## Thinking Framework\n\n${t.content}`);
    if (d) bodyParts.push(`## Dialogue Guidelines\n\n${d.content}`);

    const tools = ['write', 'edit', 'bash', 'read', 'grep', 'glob']
      .map((t) => `  ${t}: true`)
      .join('\n');

    const content = `---\ntemperature: 0.2\ntools:\n${tools}\n---\n\n${bodyParts.join('\n\n---\n\n')}\n`;

    return { name: pattern.id, content };
  }, [resolvePattern, getComponent]);

  const generateJson = useCallback((pattern: Pattern): string => {
    const md = exportPatternMarkdown(pattern);
    return JSON.stringify({
      mode: { [pattern.id]: { temperature: 0.2, prompt: md, tools: { write: true, edit: true, bash: true, read: true, grep: true, glob: true } } },
    }, null, 2);
  }, [exportPatternMarkdown]);

  const downloadFile = useCallback((filename: string, content: string, type: string = 'text/plain') => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  return {
    allPersonas,
    allThinking,
    allDialogue,
    patterns,
    activePatternId,
    activePattern,
    resolvedActive,
    resolvedComponents,
    activeTab,
    setActivePatternId,
    setActiveTab,
    createPattern,
    deletePattern,
    setSlot,
    exportPatternMarkdown,
    exportAsOpenCodeMode,
    generateJson,
    downloadFile,
    getComponent,
  };
}
