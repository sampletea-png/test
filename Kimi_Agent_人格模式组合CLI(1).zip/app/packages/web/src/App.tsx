import { useState } from 'react';
import { usePatternStore } from './hooks/usePatternStore';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Workspace } from './components/Workspace';
import { CreateModal } from './components/CreateModal';
import { Toast } from './components/Toast';

export default function App() {
  const store = usePatternStore();
  const [showCreate, setShowCreate] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="h-screen w-screen bg-[#050505] text-[#F3F4F6] flex flex-col overflow-hidden font-sans">
      <Header
        patterns={store.patterns}
        activePatternId={store.activePatternId}
        onSelectPattern={store.setActivePatternId}
        onCreateClick={() => setShowCreate(true)}
        onDeletePattern={(id) => {
          store.deletePattern(id);
          showToast('Pattern deleted', 'success');
        }}
      />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          personas={store.allPersonas}
          thinkingModels={store.allThinking}
          dialoguePatterns={store.allDialogue}
          onSelectComponent={(comp) => {
            if (store.activePattern) {
              store.setSlot(store.activePattern.id, comp.type, comp.id);
              showToast(`${comp.name} added to ${comp.type}`, 'success');
            }
          }}
        />
        <Workspace
          store={store}
          showToast={showToast}
        />
      </div>

      {showCreate && (
        <CreateModal
          patterns={store.patterns}
          personas={store.allPersonas}
          thinkingModels={store.allThinking}
          dialoguePatterns={store.allDialogue}
          onCreate={(name, opts) => {
            const p = store.createPattern(name, opts);
            if (p) {
              showToast(`Created ${p.label}`, 'success');
              setShowCreate(false);
            } else {
              showToast('Pattern already exists', 'info');
            }
          }}
          onClose={() => setShowCreate(false)}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
}
