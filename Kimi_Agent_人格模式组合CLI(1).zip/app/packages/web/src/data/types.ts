export type ComponentType = 'persona' | 'thinking' | 'dialogue';

export interface BaseComponent {
  id: string;
  name: string;
  fileName: string;
  description: string;
  content: string;
  type: ComponentType;
}

export interface Pattern {
  id: string;
  name: string;
  label: string;
  inheritsFrom: string | null;
  slots: {
    persona: string | null;
    thinking: string | null;
    dialogue: string | null;
  };
}

export interface OpenCodeMarkdownMode {
  name: string;
  frontmatter: {
    temperature?: number;
    tools?: Record<string, boolean>;
  };
  body: string;
}

export const COMPONENT_COLORS: Record<ComponentType, { bg: string; text: string; border: string; label: string }> = {
  persona: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/30', label: '人格' },
  thinking: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/30', label: '思维模型' },
  dialogue: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30', label: '对话模式' },
};
