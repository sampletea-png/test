# 模式编排器 (Pattern Orchestrator) v2.0

管理人格(Persona)、思维模型(Thinking Model)和对话模式(Dialogue Pattern)的组合，为 OpenCode 生成可复用的、可通过 Tab 切换的模式。

## 项目结构

```
./
packages/
  core/               # 共享核心逻辑（模式管理、OpenCode 导出）
  cli/                # 命令行工具
  web/                # Web 前端（React）
personas/             # 人格 .md 文件（5个生产级 + 2个测试）
thinking-models/      # 思维模型 .md 文件（4个生产级 + 2个测试）
dialogue-patterns/    # 对话模式 .md 文件（4个生产级 + 2个测试）
```

## 快速开始

```bash
# 安装依赖
cd /mnt/agents/output/app
npm install

# 构建所有包
npm run build

# CLI 全局安装
cd packages/cli
npm link
```

## CLI 命令

### 交互式向导（推荐新手使用）

```bash
# 主菜单向导
opencode-patterns wizard

# 交互式创建
opencode-patterns interactive-create

# 交互式移除
opencode-patterns interactive-remove
```

### 模式管理

```bash
# 创建基础模式
opencode-patterns create-pattern Plan \\
  --persona java_engineer \\
  --thinking OODA_loop \\
  --dialogue socratic

# 创建继承模式（自动继承父模式组件，可覆写）
opencode-patterns create-pattern Build \\
  --inherit Plan \\
  --persona python_expert \\
  --dialogue direct_answer

# 删除模式
opencode-patterns delete-pattern Build

# 查看模式详情
opencode-patterns show Plan

# 导出为合并配置
opencode-patterns use Plan
```

### 组件管理

```bash
# 添加组件
opencode-patterns add-persona ./personas/my_role.md
opencode-patterns add-thinking ./thinking-models/my_model.md
opencode-patterns add-dialogue ./dialogue-patterns/my_pattern.md

# 移除组件
opencode-patterns remove-persona java_engineer

# 列出所有
opencode-patterns list
```

### OpenCode 集成（Tab 切换）

```bash
# 导出所有模式为 OpenCode 模式文件
# 安装后重启 OpenCode，按 Tab 即可切换
opencode-patterns install-opencode

# 导出单个模式
opencode-patterns export-opencode-mode Plan ~/.config/opencode/modes/

# 导出为 opencode.json
opencode-patterns export-opencode-json
```

### 完整工作流示例

```bash
# 1. 同步项目目录中的 .md 文件
cd /mnt/agents/output/app && opencode-patterns sync

# 2. 创建 [Plan] 模式
opencode-patterns create-pattern Plan \\
  --persona java_engineer \\
  --thinking OODA_loop \\
  --dialogue socratic

# 3. 创建 [Build] 继承 Plan，只改人格和对话
opencode-patterns create-pattern Build \\
  --inherit Plan \\
  --persona python_expert \\
  --dialogue direct_answer

# 4. 安装到 OpenCode
opencode-patterns install-opencode

# 5. 重启 OpenCode，按 Tab 切换 [Plan] / [Build]
```

## Web 前端

Web 前端部署在: https://nfvn2tzi4o6yu.ok.kimi.link

功能：
- 可视化组件库（人格/思维模型/对话模式）
- 点击组件填充到模式槽位
- 创建新模式（支持继承）
- 导出 OpenCode 模式文件
- JSON 预览 + 终端模拟

## OpenCode Tab 切换原理

1. 运行 `opencode-patterns install-opencode`
2. 工具将每个模式导出为 `~/.config/opencode/modes/{pattern-id}.md`
3. 重启 OpenCode 后，按 **Tab** 键即可在 [Plan]、[Build] 等自定义模式间切换
4. 每个模式包含完整的人格 + 思维模型 + 对话模式组合

## 生产级 .md 文件

### 人格 (5个)
| 文件 | 定位 |
|------|------|
| `java_engineer.md` | 15年Java企业级，Spring/微服务/性能 |
| `python_expert.md` | 全栈Python，数据科学/MLOps/Web |
| `frontend_architect.md` | 前端架构师，React/Vue/性能工程 |
| `rust_systems_engineer.md` | Rust系统编程，底层/网络/存储 |
| `devops_engineer.md` | DevOps/平台工程，K8s/云原生 |

### 思维模型 (4个)
| 文件 | 定位 |
|------|------|
| `OODA_loop.md` | 观察-判断-决策-行动循环 |
| `first_principles.md` | 第一性原理，从零构建 |
| `systems_thinking.md` | 系统思维，反馈回路/杠杆点 |
| `inversion_thinking.md` | 逆向思维，预演/排除法 |

### 对话模式 (4个)
| 文件 | 定位 |
|------|------|
| `socratic_dialogue.md` | 苏格拉底追问 |
| `direct_answer.md` | 直接回答 |
| `exploration_mode.md` | 探索/发散模式 |
| `mentor_mode.md` | 导师/长期辅导 |

## 测试文件

6个测试文件用于验证配置正确性：
- `test_persona_alpha.md` / `test_persona_beta.md`
- `test_thinking_gamma.md` / `test_thinking_delta.md`
- `test_dialogue_epsilon.md` / `test_dialogue_zeta.md`

运行测试：`bash packages/cli/demo.sh`
