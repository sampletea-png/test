@echo off
chcp 65001 >nul

:: MF4 Project Build Script for Windows
:: 构建Java-Python MF4项目

echo ============================================
echo MF4 Project Build Script
echo ============================================

setlocal enabledelayedexpansion

:: 检查Python
echo Checking Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python not found! Please install Python 3.7+
    exit /b 1
)
python --version

:: 检查Java
echo.
echo Checking Java...
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo Java not found! Please install JDK 11+
    exit /b 1
)
java -version 2>&1 | findstr "version"

:: 检查Maven
echo.
echo Checking Maven...
mvn -version >nul 2>&1
if %errorlevel% neq 0 (
    echo Maven not found! Please install Maven
    exit /b 1
)
mvn -version 2>&1 | findstr "Apache Maven"

:: 安装Python依赖
echo.
echo Installing Python dependencies...
cd python
python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo Failed to install Python dependencies
    exit /b 1
)
cd ..

:: 编译Java项目
echo.
echo Building Java project...
cd java
mvn clean package -DskipTests
if %errorlevel% neq 0 (
    echo Java build failed!
    exit /b 1
)
cd ..

:: 检查构建结果
echo.
echo Checking build artifacts...
set JAR_FILE=java\target\mf4-java-client-1.0.0-jar-with-dependencies.jar
if exist "%JAR_FILE%" (
    echo Build successful!
    echo JAR file: %JAR_FILE%
) else (
    echo Build failed! JAR file not found.
    exit /b 1
)

:: 创建运行脚本
echo.
echo Creating run scripts...

echo @echo off > run_python.bat
echo cd /d "%%~dp0" >> run_python.bat
echo cd python >> run_python.bat
echo python main.py %%* >> run_python.bat

echo @echo off > run_java.bat
echo cd /d "%%~dp0" >> run_java.bat
echo java -jar java\target\mf4-java-client-1.0.0-jar-with-dependencies.jar %%* >> run_java.bat

echo @echo off > run_demo.bat
echo cd /d "%%~dp0" >> run_demo.bat
echo echo Running MF4 Demo... >> run_demo.bat
echo java -jar java\target\mf4-java-client-1.0.0-jar-with-dependencies.jar >> run_demo.bat

echo.
echo ============================================
echo Build completed successfully!
echo ============================================
echo.
echo Usage:
echo   run_python.bat [options]  - Start Python service
echo   run_java.bat [options]    - Run Java client
echo   run_demo.bat              - Run demo
echo.
echo Or manually:
echo   cd python ^&^& python main.py
echo   cd java ^&^& java -jar target\mf4-java-client-1.0.0-jar-with-dependencies.jar
echo.

pause
