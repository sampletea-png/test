"""
日志系统模块 - 提供独立的日志记录功能
"""
import logging
import logging.handlers
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


class MF4Logger:
    """
    MF4服务专用日志记录器
    
    特性：
    - 独立的日志文件
    - 按大小轮转
    - 控制台和文件双输出
    - 多线程安全
    """
    
    _instance = None
    _lock = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._lock = __import__('threading').Lock()
        return cls._instance
    
    def __init__(self, 
                 log_dir: Optional[str] = None,
                 log_level: int = logging.DEBUG,
                 max_bytes: int = 10 * 1024 * 1024,  # 10MB
                 backup_count: int = 5):
        """
        初始化日志记录器
        
        Args:
            log_dir: 日志目录，默认为当前目录下的logs文件夹
            log_level: 日志级别
            max_bytes: 单个日志文件最大字节数
            backup_count: 保留的备份文件数量
        """
        if hasattr(self, '_initialized'):
            return
            
        with self._lock:
            if hasattr(self, '_initialized'):
                return
                
            self.log_dir = log_dir or os.path.join(os.path.dirname(__file__), "..", "logs")
            self.log_level = log_level
            self.max_bytes = max_bytes
            self.backup_count = backup_count
            
            # 创建日志目录
            Path(self.log_dir).mkdir(parents=True, exist_ok=True)
            
            # 创建日志记录器
            self.logger = logging.getLogger("mf4_service")
            self.logger.setLevel(log_level)
            
            # 清除现有处理器
            self.logger.handlers.clear()
            
            # 创建格式器
            formatter = logging.Formatter(
                '[%(asctime)s] [%(levelname)s] [%(threadName)s] [%(filename)s:%(lineno)d] - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            
            # 文件处理器（按大小轮转）
            log_file = os.path.join(self.log_dir, f"mf4_service_{datetime.now().strftime('%Y%m%d')}.log")
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setLevel(log_level)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
            # 控制台处理器
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
            
            # 错误日志单独文件
            error_log_file = os.path.join(self.log_dir, f"mf4_service_error_{datetime.now().strftime('%Y%m%d')}.log")
            error_handler = logging.handlers.RotatingFileHandler(
                error_log_file,
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding='utf-8'
            )
            error_handler.setLevel(logging.ERROR)
            error_handler.setFormatter(formatter)
            self.logger.addHandler(error_handler)
            
            self._initialized = True
            self.logger.info("=" * 60)
            self.logger.info("MF4 Service Logger Initialized")
            self.logger.info(f"Log directory: {self.log_dir}")
            self.logger.info(f"Log level: {logging.getLevelName(log_level)}")
            self.logger.info("=" * 60)
    
    def debug(self, message: str, *args, **kwargs):
        """记录DEBUG级别日志"""
        self.logger.debug(message, *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs):
        """记录INFO级别日志"""
        self.logger.info(message, *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs):
        """记录WARNING级别日志"""
        self.logger.warning(message, *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs):
        """记录ERROR级别日志"""
        self.logger.error(message, *args, **kwargs)
    
    def exception(self, message: str, *args, **kwargs):
        """记录EXCEPTION级别日志（包含堆栈信息）"""
        self.logger.exception(message, *args, **kwargs)
    
    def critical(self, message: str, *args, **kwargs):
        """记录CRITICAL级别日志"""
        self.logger.critical(message, *args, **kwargs)
    
    def log_request(self, request_id: str, request_type: str, file_id: Optional[str] = None, 
                    comment: str = ""):
        """记录请求日志"""
        self.logger.info(f"[REQUEST] ID={request_id}, Type={request_type}, "
                        f"FileID={file_id}, Comment={comment}")
    
    def log_response(self, request_id: str, status: str, has_more: bool = False, 
                     error_msg: Optional[str] = None, comment: str = ""):
        """记录响应日志"""
        msg = f"[RESPONSE] ID={request_id}, Status={status}, HasMore={has_more}"
        if error_msg:
            msg += f", Error={error_msg}"
        if comment:
            msg += f", Comment={comment}"
        self.logger.info(msg)
    
    def log_file_operation(self, operation: str, file_id: str, file_path: str, 
                          success: bool = True, details: str = ""):
        """记录文件操作日志"""
        status = "SUCCESS" if success else "FAILED"
        self.logger.info(f"[FILE] Operation={operation}, FileID={file_id}, "
                        f"Path={file_path}, Status={status}, Details={details}")
    
    def log_signal_operation(self, operation: str, signal_name: str, file_id: str,
                            success: bool = True, details: str = ""):
        """记录信号操作日志"""
        status = "SUCCESS" if success else "FAILED"
        self.logger.info(f"[SIGNAL] Operation={operation}, Signal={signal_name}, "
                        f"FileID={file_id}, Status={status}, Details={details}")
    
    def log_memory_usage(self, operation: str, memory_mb: float):
        """记录内存使用日志"""
        self.logger.debug(f"[MEMORY] Operation={operation}, Usage={memory_mb:.2f}MB")
    
    def get_log_files(self) -> list:
        """获取所有日志文件路径"""
        log_files = []
        if os.path.exists(self.log_dir):
            for f in os.listdir(self.log_dir):
                if f.endswith('.log'):
                    log_files.append(os.path.join(self.log_dir, f))
        return sorted(log_files)


# 全局日志实例
def get_logger(log_dir: Optional[str] = None, log_level: int = logging.DEBUG) -> MF4Logger:
    """获取日志记录器实例"""
    return MF4Logger(log_dir=log_dir, log_level=log_level)
