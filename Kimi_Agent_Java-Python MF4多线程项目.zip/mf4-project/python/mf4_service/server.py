"""
Socket服务器 - 处理Java端的连接和请求

特性：
- 多线程处理并发请求
- 心跳检测
- 优雅关闭
- 异常处理
"""
import socket
import threading
import signal
import sys
import os
import time
import json
from typing import Optional
from datetime import datetime

from .protocol import Request, Response, PROTOCOL_VERSION, DEFAULT_PORT, DEFAULT_HOST, BUFFER_SIZE, MESSAGE_DELIMITER
from .mf4_manager import MF4Manager
from .handler import RequestHandler
from .logger import get_logger


class MF4Server:
    """
    MF4 Socket服务器
    
    负责：
    - 监听Java端连接
    - 多线程处理请求
    - 生命周期管理
    """
    
    def __init__(self, 
                 host: str = DEFAULT_HOST,
                 port: int = DEFAULT_PORT,
                 chunk_size: int = 100000,
                 max_workers: int = 10):
        """
        初始化服务器
        
        Args:
            host: 监听地址
            port: 监听端口
            chunk_size: 默认分段大小
            max_workers: 最大工作线程数
        """
        self.logger = get_logger()
        self.host = host
        self.port = port
        self.max_workers = max_workers
        
        # 创建MF4管理器
        self.mf4_manager = MF4Manager(chunk_size=chunk_size)
        
        # 创建请求处理器
        self.request_handler = RequestHandler(self.mf4_manager)
        
        # Socket服务器
        self.server_socket: Optional[socket.socket] = None
        
        # 运行状态
        self._running = False
        self._shutdown_event = threading.Event()
        
        # 客户端连接管理
        self._clients: Dict[socket.socket, threading.Thread] = {}
        self._clients_lock = threading.Lock()
        
        # 线程池
        self._thread_semaphore = threading.Semaphore(max_workers)
        
        # 启动时间
        self._start_time: Optional[datetime] = None
        
        # 注册信号处理
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
        
        self.logger.info(f"MF4Server initialized on {host}:{port}, max_workers={max_workers}")
    
    def _signal_handler(self, signum, frame):
        """信号处理函数"""
        self.logger.info(f"Received signal {signum}, shutting down...")
        self.shutdown()
    
    def start(self):
        """启动服务器"""
        if self._running:
            self.logger.warning("Server is already running")
            return
        
        try:
            # 创建Socket
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(self.max_workers)
            
            self._running = True
            self._start_time = datetime.now()
            
            self.logger.info(f"Server started on {self.host}:{self.port}")
            self.logger.info(f"Protocol version: {PROTOCOL_VERSION}")
            
            # 接受连接循环
            while self._running and not self._shutdown_event.is_set():
                try:
                    # 设置超时以便定期检查关闭事件
                    self.server_socket.settimeout(1.0)
                    try:
                        client_socket, address = self.server_socket.accept()
                        self.logger.info(f"New connection from {address}")
                        
                        # 使用信号量限制并发数
                        if not self._thread_semaphore.acquire(timeout=5.0):
                            self.logger.warning("Max workers reached, rejecting connection")
                            client_socket.close()
                            continue
                        
                        # 创建客户端处理线程
                        client_thread = threading.Thread(
                            target=self._handle_client,
                            args=(client_socket, address),
                            name=f"Client-{address[0]}:{address[1]}"
                        )
                        client_thread.daemon = True
                        
                        with self._clients_lock:
                            self._clients[client_socket] = client_thread
                        
                        client_thread.start()
                        
                    except socket.timeout:
                        continue
                    
                except OSError as e:
                    if self._running:
                        self.logger.error(f"Socket error: {e}")
                    break
                except Exception as e:
                    self.logger.exception(f"Error accepting connection: {e}")
                    
        except Exception as e:
            self.logger.exception(f"Failed to start server: {e}")
            raise
        finally:
            self._cleanup()
    
    def _handle_client(self, client_socket: socket.socket, address):
        """
        处理客户端连接
        
        Args:
            client_socket: 客户端Socket
            address: 客户端地址
        """
        try:
            client_socket.settimeout(30.0)  # 30秒超时
            
            buffer = b""
            
            while self._running and not self._shutdown_event.is_set():
                try:
                    # 接收数据
                    data = client_socket.recv(BUFFER_SIZE)
                    
                    if not data:
                        # 连接关闭
                        self.logger.info(f"Connection closed by {address}")
                        break
                    
                    buffer += data
                    
                    # 处理完整的消息
                    while MESSAGE_DELIMITER in buffer:
                        # 分割消息
                        message, buffer = buffer.split(MESSAGE_DELIMITER, 1)
                        
                        try:
                            # 解析JSON请求
                            request_json = message.decode('utf-8')
                            self.logger.debug(f"Received request from {address}: {request_json[:200]}...")
                            
                            # 处理请求
                            response_json = self.request_handler.handle(request_json)
                            
                            # 发送响应
                            response_bytes = response_json.encode('utf-8') + MESSAGE_DELIMITER
                            client_socket.sendall(response_bytes)
                            
                            self.logger.debug(f"Sent response to {address}")
                            
                            # 检查是否是关闭请求
                            request_data = json.loads(request_json)
                            if request_data.get('request_type') == 'shutdown':
                                self.logger.info(f"Shutdown requested by {address}")
                                self._shutdown_event.set()
                                break
                                
                        except json.JSONDecodeError as e:
                            self.logger.error(f"Invalid JSON from {address}: {e}")
                            error_response = Response.error(
                                request_id="unknown",
                                error_message=f"Invalid JSON: {str(e)}"
                            ).to_json()
                            client_socket.sendall(error_response.encode('utf-8') + MESSAGE_DELIMITER)
                    
                except socket.timeout:
                    # 发送心跳
                    try:
                        ping_response = Response.success(
                            request_id="heartbeat",
                            data={'heartbeat': True}
                        ).to_json()
                        client_socket.sendall(ping_response.encode('utf-8') + MESSAGE_DELIMITER)
                    except:
                        break
                    continue
                    
                except Exception as e:
                    self.logger.exception(f"Error handling client {address}: {e}")
                    break
                    
        except Exception as e:
            self.logger.exception(f"Client handler error for {address}: {e}")
        finally:
            # 清理客户端连接
            self._remove_client(client_socket)
            self._thread_semaphore.release()
    
    def _remove_client(self, client_socket: socket.socket):
        """移除客户端连接"""
        try:
            client_socket.close()
        except:
            pass
        
        with self._clients_lock:
            if client_socket in self._clients:
                del self._clients[client_socket]
    
    def shutdown(self):
        """关闭服务器"""
        if not self._running:
            return
        
        self.logger.info("Shutting down server...")
        self._running = False
        self._shutdown_event.set()
        
        # 关闭所有客户端连接
        with self._clients_lock:
            clients = list(self._clients.keys())
        
        for client in clients:
            self._remove_client(client)
        
        self.logger.info("All client connections closed")
        
        # 关闭服务器Socket
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        
        # 关闭所有文件
        if self.mf4_manager:
            self.mf4_manager.close_all_files()
        
        self.logger.info("Server shutdown complete")
    
    def _cleanup(self):
        """清理资源"""
        self.logger.info("Cleaning up resources...")
        
        # 确保所有文件已关闭
        if self.mf4_manager:
            self.mf4_manager.close_all_files()
        
        self.logger.info("Cleanup complete")
    
    def get_status(self) -> dict:
        """获取服务器状态"""
        uptime = None
        if self._start_time:
            uptime = (datetime.now() - self._start_time).total_seconds()
        
        with self._clients_lock:
            client_count = len(self._clients)
        
        return {
            'running': self._running,
            'host': self.host,
            'port': self.port,
            'uptime_seconds': uptime,
            'connected_clients': client_count,
            'max_workers': self.max_workers,
            'available_workers': self._thread_semaphore._value if self._thread_semaphore else 0,
            'mf4_manager': self.mf4_manager.get_status() if self.mf4_manager else None
        }


def start_server(host: str = DEFAULT_HOST, 
                 port: int = DEFAULT_PORT,
                 chunk_size: int = 100000,
                 max_workers: int = 10,
                 log_dir: Optional[str] = None):
    """
    启动MF4服务器的便捷函数
    
    Args:
        host: 监听地址
        port: 监听端口
        chunk_size: 默认分段大小
        max_workers: 最大工作线程数
        log_dir: 日志目录
    """
    # 初始化日志
    if log_dir:
        get_logger(log_dir=log_dir)
    
    # 创建并启动服务器
    server = MF4Server(
        host=host,
        port=port,
        chunk_size=chunk_size,
        max_workers=max_workers
    )
    
    try:
        server.start()
    except KeyboardInterrupt:
        print("\nReceived keyboard interrupt")
    finally:
        server.shutdown()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='MF4 Python Service')
    parser.add_argument('--host', default=DEFAULT_HOST, help='Host to bind')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help='Port to bind')
    parser.add_argument('--chunk-size', type=int, default=100000, help='Default chunk size for reading')
    parser.add_argument('--max-workers', type=int, default=10, help='Maximum worker threads')
    parser.add_argument('--log-dir', default=None, help='Log directory')
    
    args = parser.parse_args()
    
    start_server(
        host=args.host,
        port=args.port,
        chunk_size=args.chunk_size,
        max_workers=args.max_workers,
        log_dir=args.log_dir
    )
