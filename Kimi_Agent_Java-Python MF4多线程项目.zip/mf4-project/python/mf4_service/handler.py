"""
请求处理器 - 处理来自Java端的请求
"""
import json
import traceback
from typing import Dict, Any

from .protocol import Request, Response, RequestType, ResponseStatus, SignalInfo, ChunkInfo
from .mf4_manager import MF4Manager
from .logger import get_logger


class RequestHandler:
    """
    请求处理器
    
    处理所有来自Java端的请求，调用MF4Manager执行具体操作
    """
    
    def __init__(self, mf4_manager: MF4Manager):
        """
        初始化请求处理器
        
        Args:
            mf4_manager: MF4文件管理器实例
        """
        self.logger = get_logger()
        self.mf4_manager = mf4_manager
        
        # 请求处理映射表
        self._handlers = {
            # 文件操作
            RequestType.OPEN_FILE.value: self._handle_open_file,
            RequestType.CREATE_FILE.value: self._handle_create_file,
            RequestType.CLOSE_FILE.value: self._handle_close_file,
            RequestType.SAVE_FILE.value: self._handle_save_file,
            
            # 信号操作
            RequestType.READ_SIGNAL.value: self._handle_read_signal,
            RequestType.READ_SIGNAL_CHUNK.value: self._handle_read_signal_chunk,
            RequestType.WRITE_SIGNAL.value: self._handle_write_signal,
            RequestType.APPEND_SIGNAL.value: self._handle_append_signal,
            RequestType.GET_SIGNAL_INFO.value: self._handle_get_signal_info,
            RequestType.LIST_SIGNALS.value: self._handle_list_signals,
            RequestType.DELETE_SIGNAL.value: self._handle_delete_signal,
            
            # 通道组操作
            RequestType.LIST_CHANNEL_GROUPS.value: self._handle_list_channel_groups,
            
            # 元数据操作
            RequestType.GET_METADATA.value: self._handle_get_metadata,
            
            # 系统操作
            RequestType.PING.value: self._handle_ping,
            RequestType.GET_STATUS.value: self._handle_get_status,
        }
        
        self.logger.info("RequestHandler initialized")
    
    def handle(self, request_json: str) -> str:
        """
        处理请求
        
        Args:
            request_json: JSON格式的请求字符串
        
        Returns:
            JSON格式的响应字符串
        """
        try:
            # 解析请求
            request = Request.from_json(request_json)
            self.logger.log_request(request.request_id, request.request_type, 
                                   request.file_id, request.comment)
            
            # 查找处理器
            handler = self._handlers.get(request.request_type)
            if handler is None:
                response = Response.error(
                    request_id=request.request_id,
                    error_message=f"Unknown request type: {request.request_type}",
                    comment="Request type not supported"
                )
            else:
                # 执行处理
                response = handler(request)
            
            self.logger.log_response(request.request_id, response.status, 
                                    response.has_more, response.error_message, 
                                    response.comment)
            
            return response.to_json()
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse request JSON: {e}")
            return Response.error(
                request_id="unknown",
                error_message=f"Invalid JSON: {str(e)}",
                comment="Request parsing failed"
            ).to_json()
            
        except Exception as e:
            self.logger.exception(f"Unexpected error handling request: {e}")
            return Response.error(
                request_id="unknown",
                error_message=f"Internal error: {str(e)}",
                comment="Unexpected error occurred"
            ).to_json()
    
    def _handle_open_file(self, request: Request) -> Response:
        """处理打开文件请求"""
        try:
            file_path = request.parameters.get('file_path')
            mode = request.parameters.get('mode', 'r')
            create_if_not_exists = request.parameters.get('create_if_not_exists', False)
            
            if not file_path:
                return Response.error(request.request_id, "file_path is required", "Missing required parameter")
            
            file_id = self.mf4_manager.open_file(file_path, mode, create_if_not_exists)
            
            return Response.success(
                request_id=request.request_id,
                data={'file_id': file_id, 'file_path': file_path},
                comment=f"File opened successfully in {mode} mode"
            )
            
        except FileNotFoundError as e:
            return Response.error(request.request_id, str(e), "File not found")
        except Exception as e:
            self.logger.exception(f"Error opening file: {e}")
            return Response.error(request.request_id, str(e), "Failed to open file")
    
    def _handle_create_file(self, request: Request) -> Response:
        """处理创建文件请求"""
        try:
            file_path = request.parameters.get('file_path')
            overwrite = request.parameters.get('overwrite', False)
            
            if not file_path:
                return Response.error(request.request_id, "file_path is required", "Missing required parameter")
            
            file_id = self.mf4_manager.create_file(file_path, overwrite)
            
            return Response.success(
                request_id=request.request_id,
                data={'file_id': file_id, 'file_path': file_path},
                comment=f"File created successfully, overwrite={overwrite}"
            )
            
        except FileExistsError as e:
            return Response.error(request.request_id, str(e), "File already exists")
        except Exception as e:
            self.logger.exception(f"Error creating file: {e}")
            return Response.error(request.request_id, str(e), "Failed to create file")
    
    def _handle_close_file(self, request: Request) -> Response:
        """处理关闭文件请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            
            if not file_id:
                return Response.error(request.request_id, "file_id is required", "Missing required parameter")
            
            success = self.mf4_manager.close_file(file_id)
            
            if success:
                return Response.success(
                    request_id=request.request_id,
                    data={'file_id': file_id},
                    comment="File closed successfully"
                )
            else:
                return Response.error(request.request_id, "File not found or already closed", "Close failed")
                
        except Exception as e:
            self.logger.exception(f"Error closing file: {e}")
            return Response.error(request.request_id, str(e), "Failed to close file")
    
    def _handle_save_file(self, request: Request) -> Response:
        """处理保存文件请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            overwrite = request.parameters.get('overwrite', False)
            
            if not file_id:
                return Response.error(request.request_id, "file_id is required", "Missing required parameter")
            
            saved_path = self.mf4_manager.save_file(file_id, overwrite)
            
            return Response.success(
                request_id=request.request_id,
                data={'file_id': file_id, 'saved_path': saved_path},
                comment=f"File saved successfully, overwrite={overwrite}"
            )
            
        except Exception as e:
            self.logger.exception(f"Error saving file: {e}")
            return Response.error(request.request_id, str(e), "Failed to save file")
    
    def _handle_read_signal(self, request: Request) -> Response:
        """处理读取信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            start_index = request.parameters.get('start_index', 0)
            end_index = request.parameters.get('end_index')
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required", 
                                    "Missing required parameters")
            
            data = self.mf4_manager.read_signal(file_id, signal_name, start_index, end_index)
            
            return Response.success(
                request_id=request.request_id,
                data=data,
                comment=f"Signal {signal_name} read successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error reading signal: {e}")
            return Response.error(request.request_id, str(e), "Failed to read signal")
    
    def _handle_read_signal_chunk(self, request: Request) -> Response:
        """处理分段读取信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            chunk_index = request.parameters.get('chunk_index', 0)
            chunk_size = request.parameters.get('chunk_size')
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required",
                                    "Missing required parameters")
            
            data, chunk_info = self.mf4_manager.read_signal_chunk(
                file_id, signal_name, chunk_index, chunk_size
            )
            
            return Response.partial(
                request_id=request.request_id,
                data=data,
                chunk_info=chunk_info.to_dict(),
                has_more=not chunk_info.is_last,
                comment=f"Signal {signal_name} chunk {chunk_index} read successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error reading signal chunk: {e}")
            return Response.error(request.request_id, str(e), "Failed to read signal chunk")
    
    def _handle_write_signal(self, request: Request) -> Response:
        """处理写入信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            timestamps = request.parameters.get('timestamps', [])
            samples = request.parameters.get('samples', [])
            unit = request.parameters.get('unit', '')
            comment = request.parameters.get('comment', '')
            overwrite = request.parameters.get('overwrite', False)
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required",
                                    "Missing required parameters")
            
            if len(timestamps) != len(samples):
                return Response.error(request.request_id, "timestamps and samples must have same length",
                                    "Invalid data")
            
            success = self.mf4_manager.write_signal(
                file_id, signal_name, timestamps, samples, unit, comment, overwrite
            )
            
            return Response.success(
                request_id=request.request_id,
                data={'success': success, 'signal_name': signal_name, 'sample_count': len(samples)},
                comment=f"Signal {signal_name} written successfully, overwrite={overwrite}"
            )
            
        except Exception as e:
            self.logger.exception(f"Error writing signal: {e}")
            return Response.error(request.request_id, str(e), "Failed to write signal")
    
    def _handle_append_signal(self, request: Request) -> Response:
        """处理追加信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            timestamps = request.parameters.get('timestamps', [])
            samples = request.parameters.get('samples', [])
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required",
                                    "Missing required parameters")
            
            if len(timestamps) != len(samples):
                return Response.error(request.request_id, "timestamps and samples must have same length",
                                    "Invalid data")
            
            success = self.mf4_manager.append_signal(file_id, signal_name, timestamps, samples)
            
            return Response.success(
                request_id=request.request_id,
                data={'success': success, 'signal_name': signal_name, 'appended_count': len(samples)},
                comment=f"Signal {signal_name} appended successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error appending signal: {e}")
            return Response.error(request.request_id, str(e), "Failed to append signal")
    
    def _handle_get_signal_info(self, request: Request) -> Response:
        """处理获取信号信息请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required",
                                    "Missing required parameters")
            
            info = self.mf4_manager.get_signal_info(file_id, signal_name)
            
            return Response.success(
                request_id=request.request_id,
                data=info.to_dict(),
                comment=f"Signal {signal_name} info retrieved successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error getting signal info: {e}")
            return Response.error(request.request_id, str(e), "Failed to get signal info")
    
    def _handle_list_signals(self, request: Request) -> Response:
        """处理列出信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            
            if not file_id:
                return Response.error(request.request_id, "file_id is required",
                                    "Missing required parameter")
            
            signals = self.mf4_manager.list_signals(file_id)
            
            return Response.success(
                request_id=request.request_id,
                data={'signals': signals, 'count': len(signals)},
                comment=f"Listed {len(signals)} signals"
            )
            
        except Exception as e:
            self.logger.exception(f"Error listing signals: {e}")
            return Response.error(request.request_id, str(e), "Failed to list signals")
    
    def _handle_delete_signal(self, request: Request) -> Response:
        """处理删除信号请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            signal_name = request.parameters.get('signal_name')
            
            if not file_id or not signal_name:
                return Response.error(request.request_id, "file_id and signal_name are required",
                                    "Missing required parameters")
            
            success = self.mf4_manager.delete_signal(file_id, signal_name)
            
            return Response.success(
                request_id=request.request_id,
                data={'success': success, 'signal_name': signal_name},
                comment=f"Signal {signal_name} deleted successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error deleting signal: {e}")
            return Response.error(request.request_id, str(e), "Failed to delete signal")
    
    def _handle_list_channel_groups(self, request: Request) -> Response:
        """处理列出通道组请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            
            if not file_id:
                return Response.error(request.request_id, "file_id is required",
                                    "Missing required parameter")
            
            groups = self.mf4_manager.list_channel_groups(file_id)
            
            return Response.success(
                request_id=request.request_id,
                data={'channel_groups': groups, 'count': len(groups)},
                comment=f"Listed {len(groups)} channel groups"
            )
            
        except Exception as e:
            self.logger.exception(f"Error listing channel groups: {e}")
            return Response.error(request.request_id, str(e), "Failed to list channel groups")
    
    def _handle_get_metadata(self, request: Request) -> Response:
        """处理获取元数据请求"""
        try:
            file_id = request.file_id or request.parameters.get('file_id')
            
            if not file_id:
                return Response.error(request.request_id, "file_id is required",
                                    "Missing required parameter")
            
            metadata = self.mf4_manager.get_metadata(file_id)
            
            return Response.success(
                request_id=request.request_id,
                data=metadata,
                comment="Metadata retrieved successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error getting metadata: {e}")
            return Response.error(request.request_id, str(e), "Failed to get metadata")
    
    def _handle_ping(self, request: Request) -> Response:
        """处理ping请求（心跳检测）"""
        return Response.success(
            request_id=request.request_id,
            data={'pong': True, 'timestamp': str(__import__('datetime').datetime.now())},
            comment="Service is alive"
        )
    
    def _handle_get_status(self, request: Request) -> Response:
        """处理获取状态请求"""
        try:
            status = self.mf4_manager.get_status()
            
            return Response.success(
                request_id=request.request_id,
                data=status,
                comment="Status retrieved successfully"
            )
            
        except Exception as e:
            self.logger.exception(f"Error getting status: {e}")
            return Response.error(request.request_id, str(e), "Failed to get status")
    
    def handle_shutdown(self, request: Request) -> Response:
        """处理关闭请求"""
        try:
            self.mf4_manager.close_all_files()
            
            return Response.success(
                request_id=request.request_id,
                data={'shutdown': True},
                comment="Service is shutting down"
            )
            
        except Exception as e:
            self.logger.exception(f"Error during shutdown: {e}")
            return Response.error(request.request_id, str(e), "Error during shutdown")
