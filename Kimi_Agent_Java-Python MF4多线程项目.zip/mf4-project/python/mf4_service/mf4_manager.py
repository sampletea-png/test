"""
MF4文件管理器 - 处理MF4文件的具体操作

特性：
- 大文件支持（GB级别）
- 分段读取
- 内存管理
- 多线程安全
- 信号覆盖和追加
"""
import os
import gc
import threading
import numpy as np
from typing import Dict, List, Optional, Tuple, Any, BinaryIO
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime
import tempfile

try:
    from asammdf import MDF
    from asammdf.blocks.mdf_v4 import MDF4
    HAS_ASAMMDF = True
except ImportError:
    HAS_ASAMMDF = False

from .protocol import SignalInfo, ChunkInfo
from .logger import get_logger


@dataclass
class FileHandle:
    """文件句柄封装"""
    file_id: str
    file_path: str
    mdf: Any  # MDF对象
    mode: str  # 'r', 'w', 'rw'
    created_at: datetime
    last_accessed: datetime
    access_count: int = 0
    lock: threading.RLock = None
    
    def __post_init__(self):
        if self.lock is None:
            self.lock = threading.RLock()


class MF4Manager:
    """
    MF4文件管理器
    
    负责：
    - 文件的打开、关闭、保存
    - 信号的读取、写入、追加
    - 大文件分段读取
    - 内存管理
    """
    
    # 默认分段大小（采样点数）
    DEFAULT_CHUNK_SIZE = 100000
    # 最大内存缓存（MB）
    MAX_MEMORY_CACHE_MB = 500
    # 文件句柄最大空闲时间（秒）
    MAX_IDLE_TIME = 300
    
    def __init__(self, chunk_size: int = DEFAULT_CHUNK_SIZE):
        """
        初始化MF4管理器
        
        Args:
            chunk_size: 默认分段大小（采样点数）
        """
        self.logger = get_logger()
        self.chunk_size = chunk_size
        
        # 文件句柄字典：file_id -> FileHandle
        self._files: Dict[str, FileHandle] = {}
        self._files_lock = threading.RLock()
        
        # 路径到file_id的映射
        self._path_to_id: Dict[str, str] = {}
        
        # ID生成锁
        self._id_lock = threading.Lock()
        self._id_counter = 0
        
        if not HAS_ASAMMDF:
            self.logger.error("asammdf library not found. Please install: pip install asammdf")
            raise ImportError("asammdf library is required")
        
        self.logger.info(f"MF4Manager initialized with chunk_size={chunk_size}")
    
    def _generate_file_id(self) -> str:
        """生成唯一的文件ID"""
        with self._id_lock:
            self._id_counter += 1
            return f"file_{self._id_counter}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    
    def _get_memory_usage_mb(self) -> float:
        """获取当前内存使用量（MB）"""
        import psutil
        process = psutil.Process(os.getpid())
        return process.memory_info().rss / 1024 / 1024
    
    def _check_memory(self):
        """检查内存使用情况，必要时触发垃圾回收"""
        memory_mb = self._get_memory_usage_mb()
        self.logger.log_memory_usage("check", memory_mb)
        
        if memory_mb > self.MAX_MEMORY_CACHE_MB:
            self.logger.warning(f"Memory usage high ({memory_mb:.2f}MB), triggering GC")
            gc.collect()
            new_memory_mb = self._get_memory_usage_mb()
            self.logger.log_memory_usage("after_gc", new_memory_mb)
    
    def open_file(self, file_path: str, mode: str = 'r', 
                  create_if_not_exists: bool = False) -> str:
        """
        打开MF4文件
        
        Args:
            file_path: 文件路径
            mode: 打开模式 ('r', 'w', 'rw')
            create_if_not_exists: 文件不存在时是否创建
        
        Returns:
            file_id: 文件唯一标识
        
        Raises:
            FileNotFoundError: 文件不存在且create_if_not_exists为False
            Exception: 其他打开错误
        """
        # 检查文件是否存在
        path_exists = os.path.exists(file_path)
        
        if not path_exists and not create_if_not_exists:
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # 检查是否已打开
        with self._files_lock:
            if file_path in self._path_to_id:
                file_id = self._path_to_id[file_path]
                handle = self._files[file_id]
                with handle.lock:
                    handle.access_count += 1
                    handle.last_accessed = datetime.now()
                self.logger.log_file_operation("open_existing", file_id, file_path, True)
                return file_id
        
        # 打开文件
        try:
            if mode == 'w' or (not path_exists and create_if_not_exists):
                # 创建新文件
                mdf = MDF(version='4.00')
                if path_exists:
                    # 如果文件存在但模式为w，先删除
                    os.remove(file_path)
            else:
                # 读取现有文件
                mdf = MDF(file_path)
            
            file_id = self._generate_file_id()
            handle = FileHandle(
                file_id=file_id,
                file_path=file_path,
                mdf=mdf,
                mode=mode,
                created_at=datetime.now(),
                last_accessed=datetime.now(),
                access_count=1
            )
            
            with self._files_lock:
                self._files[file_id] = handle
                self._path_to_id[file_path] = file_id
            
            self.logger.log_file_operation("open", file_id, file_path, True, f"mode={mode}")
            return file_id
            
        except Exception as e:
            self.logger.log_file_operation("open", "unknown", file_path, False, str(e))
            raise
    
    def create_file(self, file_path: str, overwrite: bool = False) -> str:
        """
        创建新的MF4文件
        
        Args:
            file_path: 文件路径
            overwrite: 是否覆盖已存在的文件
        
        Returns:
            file_id: 文件唯一标识
        """
        if os.path.exists(file_path):
            if not overwrite:
                raise FileExistsError(f"File already exists: {file_path}")
            # 如果已打开，先关闭
            with self._files_lock:
                if file_path in self._path_to_id:
                    old_id = self._path_to_id[file_path]
                    self._close_file_internal(old_id)
            os.remove(file_path)
        
        # 确保目录存在
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        
        return self.open_file(file_path, mode='w', create_if_not_exists=True)
    
    def close_file(self, file_id: str) -> bool:
        """
        关闭文件
        
        Args:
            file_id: 文件ID
        
        Returns:
            是否成功关闭
        """
        return self._close_file_internal(file_id)
    
    def _close_file_internal(self, file_id: str) -> bool:
        """内部关闭文件方法"""
        with self._files_lock:
            if file_id not in self._files:
                self.logger.warning(f"Attempt to close unknown file: {file_id}")
                return False
            
            handle = self._files[file_id]
            
            with handle.lock:
                try:
                    file_path = handle.file_path
                    # 关闭MDF对象
                    if handle.mdf is not None:
                        handle.mdf.close()
                    
                    # 从映射中移除
                    if file_path in self._path_to_id:
                        del self._path_to_id[file_path]
                    del self._files[file_id]
                    
                    self.logger.log_file_operation("close", file_id, file_path, True)
                    return True
                    
                except Exception as e:
                    self.logger.log_file_operation("close", file_id, handle.file_path, False, str(e))
                    return False
    
    def save_file(self, file_id: str, overwrite: bool = False) -> str:
        """
        保存文件
        
        Args:
            file_id: 文件ID
            overwrite: 是否覆盖原文件
        
        Returns:
            保存的文件路径
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                file_path = handle.file_path
                
                # 如果不覆盖，生成新路径
                if not overwrite and os.path.exists(file_path):
                    base, ext = os.path.splitext(file_path)
                    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                    file_path = f"{base}_{timestamp}{ext}"
                
                # 保存文件
                handle.mdf.save(file_path, overwrite=overwrite)
                handle.file_path = file_path
                
                self.logger.log_file_operation("save", file_id, file_path, True, f"overwrite={overwrite}")
                return file_path
                
            except Exception as e:
                self.logger.log_file_operation("save", file_id, handle.file_path, False, str(e))
                raise
    
    def _get_file_handle(self, file_id: str) -> Optional[FileHandle]:
        """获取文件句柄"""
        with self._files_lock:
            handle = self._files.get(file_id)
            if handle:
                with handle.lock:
                    handle.last_accessed = datetime.now()
            return handle
    
    def get_signal_info(self, file_id: str, signal_name: str) -> SignalInfo:
        """
        获取信号信息（不加载数据）
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
        
        Returns:
            SignalInfo对象
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                # 查找信号
                channel = handle.mdf.get(signal_name)
                if channel is None:
                    raise ValueError(f"Signal not found: {signal_name}")
                
                # 获取信号元数据
                info = SignalInfo(
                    name=signal_name,
                    unit=channel.unit if hasattr(channel, 'unit') else "",
                    comment=channel.comment if hasattr(channel, 'comment') else "",
                    data_type=str(channel.samples.dtype) if hasattr(channel, 'samples') else "",
                    sample_count=len(channel.samples) if hasattr(channel, 'samples') else 0,
                    sample_rate=float(channel.sample_rate) if hasattr(channel, 'sample_rate') else 0.0,
                    start_time=float(channel.timestamps[0]) if hasattr(channel, 'timestamps') and len(channel.timestamps) > 0 else 0.0,
                    end_time=float(channel.timestamps[-1]) if hasattr(channel, 'timestamps') and len(channel.timestamps) > 0 else 0.0,
                    min_value=float(np.min(channel.samples)) if hasattr(channel, 'samples') and len(channel.samples) > 0 else None,
                    max_value=float(np.max(channel.samples)) if hasattr(channel, 'samples') and len(channel.samples) > 0 else None,
                )
                
                self.logger.log_signal_operation("get_info", signal_name, file_id, True)
                return info
                
            except Exception as e:
                self.logger.log_signal_operation("get_info", signal_name, file_id, False, str(e))
                raise
    
    def read_signal(self, file_id: str, signal_name: str, 
                    start_index: int = 0, end_index: Optional[int] = None) -> Dict[str, Any]:
        """
        读取信号数据
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
            start_index: 起始索引
            end_index: 结束索引（None表示到最后）
        
        Returns:
            包含timestamps和samples的字典
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                channel = handle.mdf.get(signal_name)
                if channel is None:
                    raise ValueError(f"Signal not found: {signal_name}")
                
                timestamps = channel.timestamps
                samples = channel.samples
                
                # 切片
                if end_index is None:
                    end_index = len(samples)
                
                timestamps_slice = timestamps[start_index:end_index]
                samples_slice = samples[start_index:end_index]
                
                # 转换为列表以便JSON序列化
                result = {
                    'timestamps': timestamps_slice.tolist(),
                    'samples': samples_slice.tolist(),
                    'start_index': start_index,
                    'end_index': end_index,
                    'total_samples': len(samples)
                }
                
                self.logger.log_signal_operation("read", signal_name, file_id, True, 
                                                f"range=[{start_index}:{end_index}]")
                return result
                
            except Exception as e:
                self.logger.log_signal_operation("read", signal_name, file_id, False, str(e))
                raise
    
    def read_signal_chunk(self, file_id: str, signal_name: str,
                         chunk_index: int, chunk_size: Optional[int] = None) -> Tuple[Dict[str, Any], ChunkInfo]:
        """
        分段读取信号
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
            chunk_index: 块索引（从0开始）
            chunk_size: 块大小（None使用默认值）
        
        Returns:
            (数据字典, ChunkInfo对象)
        """
        if chunk_size is None:
            chunk_size = self.chunk_size
        
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                channel = handle.mdf.get(signal_name)
                if channel is None:
                    raise ValueError(f"Signal not found: {signal_name}")
                
                total_samples = len(channel.samples)
                start_index = chunk_index * chunk_size
                end_index = min(start_index + chunk_size, total_samples)
                
                if start_index >= total_samples:
                    raise IndexError(f"Chunk index {chunk_index} out of range")
                
                timestamps = channel.timestamps[start_index:end_index]
                samples = channel.samples[start_index:end_index]
                
                chunk_info = ChunkInfo(
                    start_index=start_index,
                    end_index=end_index,
                    total_samples=total_samples,
                    chunk_size=len(samples),
                    is_last=(end_index >= total_samples)
                )
                
                result = {
                    'timestamps': timestamps.tolist(),
                    'samples': samples.tolist(),
                }
                
                self.logger.log_signal_operation("read_chunk", signal_name, file_id, True,
                                                f"chunk={chunk_index}, range=[{start_index}:{end_index}]")
                
                # 检查内存
                self._check_memory()
                
                return result, chunk_info
                
            except Exception as e:
                self.logger.log_signal_operation("read_chunk", signal_name, file_id, False, str(e))
                raise
    
    def write_signal(self, file_id: str, signal_name: str,
                    timestamps: List[float], samples: List[float],
                    unit: str = "", comment: str = "",
                    overwrite: bool = False) -> bool:
        """
        写入信号（覆盖或新建）
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
            timestamps: 时间戳数组
            samples: 采样值数组
            unit: 单位
            comment: 注释
            overwrite: 是否覆盖同名信号
        
        Returns:
            是否成功
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                # 检查是否已存在
                existing = handle.mdf.get(signal_name)
                if existing is not None and not overwrite:
                    raise ValueError(f"Signal {signal_name} already exists. Use overwrite=True to replace.")
                
                # 转换为numpy数组
                timestamps_arr = np.array(timestamps, dtype=np.float64)
                samples_arr = np.array(samples)
                
                # 添加信号
                handle.mdf.append({
                    signal_name: {
                        'timestamps': timestamps_arr,
                        'samples': samples_arr,
                        'unit': unit,
                        'comment': comment
                    }
                })
                
                self.logger.log_signal_operation("write", signal_name, file_id, True,
                                                f"samples={len(samples)}, overwrite={overwrite}")
                return True
                
            except Exception as e:
                self.logger.log_signal_operation("write", signal_name, file_id, False, str(e))
                raise
    
    def append_signal(self, file_id: str, signal_name: str,
                     timestamps: List[float], samples: List[float]) -> bool:
        """
        追加数据到现有信号
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
            timestamps: 时间戳数组
            samples: 采样值数组
        
        Returns:
            是否成功
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                # 获取现有信号
                channel = handle.mdf.get(signal_name)
                if channel is None:
                    raise ValueError(f"Signal not found: {signal_name}. Use write_signal to create new.")
                
                # 获取现有数据
                existing_timestamps = channel.timestamps
                existing_samples = channel.samples
                
                # 合并数据
                new_timestamps = np.concatenate([existing_timestamps, np.array(timestamps)])
                new_samples = np.concatenate([existing_samples, np.array(samples)])
                
                # 获取元数据
                unit = channel.unit if hasattr(channel, 'unit') else ""
                comment = channel.comment if hasattr(channel, 'comment') else ""
                
                # 删除旧信号并写入新信号
                # 注意：asammdf不直接支持追加，需要重新写入
                handle.mdf.remove(signal_name)
                handle.mdf.append({
                    signal_name: {
                        'timestamps': new_timestamps,
                        'samples': new_samples,
                        'unit': unit,
                        'comment': comment
                    }
                })
                
                self.logger.log_signal_operation("append", signal_name, file_id, True,
                                                f"appended={len(samples)}, total={len(new_samples)}")
                return True
                
            except Exception as e:
                self.logger.log_signal_operation("append", signal_name, file_id, False, str(e))
                raise
    
    def list_signals(self, file_id: str) -> List[str]:
        """
        列出文件中的所有信号名称
        
        Args:
            file_id: 文件ID
        
        Returns:
            信号名称列表
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                # 获取所有通道
                channels = handle.mdf.channels_db
                signal_names = list(channels.keys()) if channels else []
                
                self.logger.info(f"Listed {len(signal_names)} signals from {file_id}")
                return signal_names
                
            except Exception as e:
                self.logger.error(f"Failed to list signals from {file_id}: {e}")
                raise
    
    def delete_signal(self, file_id: str, signal_name: str) -> bool:
        """
        删除信号
        
        Args:
            file_id: 文件ID
            signal_name: 信号名称
        
        Returns:
            是否成功
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                handle.mdf.remove(signal_name)
                self.logger.log_signal_operation("delete", signal_name, file_id, True)
                return True
                
            except Exception as e:
                self.logger.log_signal_operation("delete", signal_name, file_id, False, str(e))
                raise
    
    def list_channel_groups(self, file_id: str) -> List[Dict[str, Any]]:
        """
        列出通道组信息
        
        Args:
            file_id: 文件ID
        
        Returns:
            通道组信息列表
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                groups = []
                for i, group in enumerate(handle.mdf.groups):
                    groups.append({
                        'index': i,
                        'channel_count': len(group.channels) if hasattr(group, 'channels') else 0,
                        'sample_count': group.channel_group.cycles_nr if hasattr(group, 'channel_group') else 0
                    })
                return groups
                
            except Exception as e:
                self.logger.error(f"Failed to list channel groups from {file_id}: {e}")
                raise
    
    def get_metadata(self, file_id: str) -> Dict[str, Any]:
        """
        获取文件元数据
        
        Args:
            file_id: 文件ID
        
        Returns:
            元数据字典
        """
        handle = self._get_file_handle(file_id)
        if handle is None:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                mdf = handle.mdf
                metadata = {
                    'version': mdf.version if hasattr(mdf, 'version') else 'unknown',
                    'program': mdf.header.program if hasattr(mdf, 'header') and hasattr(mdf.header, 'program') else '',
                    'date': mdf.header.date if hasattr(mdf, 'header') and hasattr(mdf.header, 'date') else '',
                    'start_time': str(mdf.header.start_time) if hasattr(mdf, 'header') and hasattr(mdf.header, 'start_time') else '',
                    'channel_group_count': len(mdf.groups) if hasattr(mdf, 'groups') else 0,
                }
                return metadata
                
            except Exception as e:
                self.logger.error(f"Failed to get metadata from {file_id}: {e}")
                raise
    
    def close_all_files(self):
        """关闭所有文件"""
        with self._files_lock:
            file_ids = list(self._files.keys())
        
        for file_id in file_ids:
            self._close_file_internal(file_id)
        
        self.logger.info("All files closed")
    
    def get_status(self) -> Dict[str, Any]:
        """获取管理器状态"""
        with self._files_lock:
            return {
                'open_files': len(self._files),
                'file_ids': list(self._files.keys()),
                'memory_usage_mb': self._get_memory_usage_mb()
            }
