"""
通信协议模块 - 定义Java与Python之间的通信格式
"""
import json
from enum import Enum
from typing import Any, Dict, Optional
from dataclasses import dataclass, asdict


class RequestType(Enum):
    """请求类型枚举"""
    # 文件操作
    OPEN_FILE = "open_file"
    CREATE_FILE = "create_file"
    CLOSE_FILE = "close_file"
    SAVE_FILE = "save_file"
    
    # 信号操作
    READ_SIGNAL = "read_signal"
    READ_SIGNAL_CHUNK = "read_signal_chunk"
    WRITE_SIGNAL = "write_signal"
    APPEND_SIGNAL = "append_signal"
    GET_SIGNAL_INFO = "get_signal_info"
    LIST_SIGNALS = "list_signals"
    DELETE_SIGNAL = "delete_signal"
    
    # 通道组操作
    LIST_CHANNEL_GROUPS = "list_channel_groups"
    GET_CHANNEL_GROUP_INFO = "get_channel_group_info"
    
    # 元数据操作
    GET_METADATA = "get_metadata"
    SET_METADATA = "set_metadata"
    
    # 系统操作
    PING = "ping"
    SHUTDOWN = "shutdown"
    GET_STATUS = "get_status"


class ResponseStatus(Enum):
    """响应状态枚举"""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"  # 用于分段读取


@dataclass
class Request:
    """
    请求类 - Java端发送给Python端的请求
    
    Attributes:
        request_id: 请求唯一标识（用于多线程匹配）
        request_type: 请求类型
        file_id: 文件标识（可选）
        parameters: 请求参数
        comment: 请求注释/描述
    """
    request_id: str
    request_type: str
    file_id: Optional[str] = None
    parameters: Dict[str, Any] = None
    comment: str = ""
    
    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}
    
    def to_json(self) -> str:
        """序列化为JSON字符串"""
        data = asdict(self)
        data['request_type'] = self.request_type
        return json.dumps(data, ensure_ascii=False)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Request':
        """从JSON字符串反序列化"""
        data = json.loads(json_str)
        return cls(**data)


@dataclass
class Response:
    """
    响应类 - Python端返回给Java端的响应
    
    Attributes:
        request_id: 对应请求的ID
        status: 响应状态
        data: 响应数据
        error_message: 错误信息（当status为error时）
        has_more: 是否还有更多数据（用于分段读取）
        chunk_info: 分段信息
        comment: 响应注释/描述
    """
    request_id: str
    status: str
    data: Any = None
    error_message: Optional[str] = None
    has_more: bool = False
    chunk_info: Optional[Dict[str, Any]] = None
    comment: str = ""
    
    def to_json(self) -> str:
        """序列化为JSON字符串"""
        data = asdict(self)
        data['status'] = self.status
        return json.dumps(data, ensure_ascii=False)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Response':
        """从JSON字符串反序列化"""
        data = json.loads(json_str)
        return cls(**data)
    
    @classmethod
    def success(cls, request_id: str, data: Any = None, comment: str = "") -> 'Response':
        """创建成功响应"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.SUCCESS.value,
            data=data,
            comment=comment
        )
    
    @classmethod
    def error(cls, request_id: str, error_message: str, comment: str = "") -> 'Response':
        """创建错误响应"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.ERROR.value,
            error_message=error_message,
            comment=comment
        )
    
    @classmethod
    def partial(cls, request_id: str, data: Any, chunk_info: Dict[str, Any], 
                has_more: bool = True, comment: str = "") -> 'Response':
        """创建部分数据响应（用于分段读取）"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.PARTIAL.value,
            data=data,
            has_more=has_more,
            chunk_info=chunk_info,
            comment=comment
        )


@dataclass
class SignalInfo:
    """
    信号信息类 - 不包含实际数据，仅包含信号元数据
    
    Attributes:
        name: 信号名称
        unit: 单位
        comment: 信号注释
        data_type: 数据类型
        sample_count: 采样点数
        sample_rate: 采样率
        start_time: 开始时间
        end_time: 结束时间
        min_value: 最小值
        max_value: 最大值
        channel_group_id: 所属通道组ID
        source: 信号来源
    """
    name: str
    unit: str = ""
    comment: str = ""
    data_type: str = ""
    sample_count: int = 0
    sample_rate: float = 0.0
    start_time: float = 0.0
    end_time: float = 0.0
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    channel_group_id: Optional[int] = None
    source: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SignalInfo':
        return cls(**data)


@dataclass
class ChunkInfo:
    """
    分段信息类 - 用于大文件分段读取
    
    Attributes:
        start_index: 起始索引
        end_index: 结束索引
        total_samples: 总采样点数
        chunk_size: 当前块大小
        is_last: 是否为最后一块
    """
    start_index: int
    end_index: int
    total_samples: int
    chunk_size: int
    is_last: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# 协议常量
PROTOCOL_VERSION = "1.0"
DEFAULT_PORT = 8765
DEFAULT_HOST = "127.0.0.1"
BUFFER_SIZE = 8192  # 8KB 缓冲区
MAX_MESSAGE_SIZE = 10 * 1024 * 1024  # 10MB 最大消息大小

# 消息分隔符
MESSAGE_DELIMITER = b"\n\nEND_OF_MESSAGE\n\n"
