#!/usr/bin/env python3
"""
MF4 Python Service - 主入口

用法：
    python main.py [--host HOST] [--port PORT] [--chunk-size SIZE] [--max-workers N] [--log-dir DIR]

示例：
    python main.py --port 8765 --max-workers 10
    python main.py --host 0.0.0.0 --port 8765 --log-dir ./logs
"""
import sys
import os
import argparse

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mf4_service import start_server, get_logger
from mf4_service.protocol import DEFAULT_HOST, DEFAULT_PORT


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='MF4 Python Service - MF4 file processing server',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
环境变量：
    MF4_HOST        默认监听地址 (default: 127.0.0.1)
    MF4_PORT        默认监听端口 (default: 8765)
    MF4_LOG_DIR     日志目录 (default: ./logs)
    MF4_CHUNK_SIZE  默认分段大小 (default: 100000)
    MF4_MAX_WORKERS 最大工作线程数 (default: 10)
        """
    )
    
    parser.add_argument('--host', 
                        default=os.environ.get('MF4_HOST', DEFAULT_HOST),
                        help='Host to bind (default: 127.0.0.1)')
    
    parser.add_argument('--port', 
                        type=int,
                        default=int(os.environ.get('MF4_PORT', DEFAULT_PORT)),
                        help='Port to bind (default: 8765)')
    
    parser.add_argument('--chunk-size',
                        type=int,
                        default=int(os.environ.get('MF4_CHUNK_SIZE', '100000')),
                        help='Default chunk size for reading signals (default: 100000)')
    
    parser.add_argument('--max-workers',
                        type=int,
                        default=int(os.environ.get('MF4_MAX_WORKERS', '10')),
                        help='Maximum worker threads (default: 10)')
    
    parser.add_argument('--log-dir',
                        default=os.environ.get('MF4_LOG_DIR', None),
                        help='Log directory (default: ./logs)')
    
    parser.add_argument('--version', action='version', version='%(prog)s 1.0.0')
    
    args = parser.parse_args()
    
    # 打印启动信息
    print("=" * 60)
    print("MF4 Python Service v1.0.0")
    print("=" * 60)
    print(f"Host:        {args.host}")
    print(f"Port:        {args.port}")
    print(f"Chunk Size:  {args.chunk_size}")
    print(f"Max Workers: {args.max_workers}")
    print(f"Log Dir:     {args.log_dir or './logs'}")
    print("=" * 60)
    print("Press Ctrl+C to stop")
    print()
    
    # 启动服务器
    try:
        start_server(
            host=args.host,
            port=args.port,
            chunk_size=args.chunk_size,
            max_workers=args.max_workers,
            log_dir=args.log_dir
        )
    except KeyboardInterrupt:
        print("\n\nShutdown requested by user")
    except Exception as e:
        print(f"\n\nError: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    print("\nService stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
