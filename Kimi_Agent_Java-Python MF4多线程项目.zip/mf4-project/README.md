# MF4 Java-Python 项目

一个支持多线程的MF4（MDF4）文件读写解决方案，Java端提供调用接口，Python端处理具体的文件操作。

## 特性

- **多线程支持**：Java端多线程请求，Python端单进程处理
- **大文件处理**：支持GB级文件，分段读取防止内存溢出
- **信号操作**：支持信号覆盖和追加
- **生命周期管理**：Java端关闭时自动关闭Python进程
- **Socket通信**：自定义Request/Response协议
- **独立日志**：Python端打印独立日志文件
- **信号信息接口**：获取信号元数据而不加载数据

## 项目结构

```
mf4-project/
├── python/                    # Python端代码
│   ├── mf4_service/          # Python服务包
│   │   ├── __init__.py
│   │   ├── protocol.py       # 通信协议
│   │   ├── server.py         # Socket服务器
│   │   ├── handler.py        # 请求处理器
│   │   ├── mf4_manager.py    # MF4文件管理器
│   │   └── logger.py         # 日志系统
│   ├── main.py               # Python服务入口
│   └── requirements.txt      # Python依赖
└── java/                     # Java端代码
    ├── src/main/java/com/mf4/
    │   ├── protocol/         # 通信协议
    │   ├── client/           # 客户端API
    │   ├── process/          # 进程管理
    │   ├── model/            # 数据模型
    │   └── Main.java         # 示例程序
    ├── src/test/java/        # 测试代码
    └── pom.xml               # Maven配置
```

## 快速开始

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
```

### 2. 编译Java项目

```bash
cd java
mvn clean package
```

### 3. 运行示例

```bash
# 方式1：Java自动启动Python服务
cd java
java -jar target/mf4-java-client-1.0.0-jar-with-dependencies.jar

# 方式2：手动启动Python服务
cd python
python main.py --port 8765

# 然后Java连接到已有服务
```

## Java API 使用示例

### 基本使用

```java
// 创建服务（自动启动Python）
MF4Service service = MF4Service.builder()
    .pythonScriptPath("../python/main.py")
    .port(8765)
    .build();

// 初始化
service.initialize();

// 获取客户端
MF4Client client = service.getClient();

// 创建文件
String fileId = client.createFile("test.mf4", true);

// 写入信号
double[] timestamps = {0.0, 0.1, 0.2, 0.3, 0.4};
double[] samples = {1.0, 2.0, 3.0, 4.0, 5.0};
client.writeSignal(fileId, "Signal1", timestamps, samples, "V", "Test", false);

// 获取信号信息（不加载数据）
SignalInfo info = client.getSignalInfo(fileId, "Signal1");
System.out.println("Samples: " + info.getSampleCount());

// 读取信号
SignalData data = client.readSignal(fileId, "Signal1");

// 保存文件
client.saveFile(fileId, true);

// 关闭文件
client.closeFile(fileId);

// 关闭服务
service.shutdown();
```

### 大文件分段读取

```java
// 分段读取，每段10000个样本
int chunkSize = 10000;
int chunkIndex = 0;

while (true) {
    MF4Client.ChunkedSignalData chunked = client.readSignalChunk(
        fileId, "LargeSignal", chunkIndex, chunkSize);
    
    SignalData data = chunked.getData();
    // 处理数据...
    
    if (!chunked.hasMore()) {
        break;
    }
    chunkIndex++;
}

// 或使用便捷方法
SignalData allData = client.readSignalComplete(fileId, "LargeSignal", 10000, 
    (progress, current, total) -> {
        System.out.printf("Progress: %.1f%%\n", progress * 100);
    });
```

### 多线程操作

```java
// 多线程写入不同信号
ExecutorService executor = Executors.newFixedThreadPool(5);

for (int i = 0; i < 5; i++) {
    final int threadId = i;
    executor.submit(() -> {
        String signalName = "Signal_" + threadId;
        double[] timestamps = ...;
        double[] samples = ...;
        client.writeSignal(fileId, signalName, timestamps, samples, "V", "", false);
    });
}
```

### 连接到已有Python服务

```java
// 如果Python服务已运行，只连接不启动
MF4Service service = MF4Service.createForExistingServer("127.0.0.1", 8765);
service.initialize();
```

## Python服务配置

### 命令行参数

```bash
python main.py [options]

Options:
  --host HOST         监听地址 (default: 127.0.0.1)
  --port PORT         监听端口 (default: 8765)
  --chunk-size SIZE   默认分段大小 (default: 100000)
  --max-workers N     最大工作线程数 (default: 10)
  --log-dir DIR       日志目录 (default: ./logs)
```

### 环境变量

```bash
export MF4_HOST=127.0.0.1
export MF4_PORT=8765
export MF4_LOG_DIR=./logs
export MF4_CHUNK_SIZE=100000
export MF4_MAX_WORKERS=10
```

## 通信协议

### Request格式

```json
{
  "request_id": "uuid-string",
  "request_type": "open_file|create_file|read_signal|...",
  "file_id": "optional-file-id",
  "parameters": {
    "key": "value"
  },
  "comment": "optional comment"
}
```

### Response格式

```json
{
  "request_id": "uuid-string",
  "status": "success|error|partial",
  "data": { ... },
  "error_message": "error description",
  "has_more": false,
  "chunk_info": { ... },
  "comment": "optional comment"
}
```

## 日志

Python端日志保存在 `./logs/` 目录：
- `mf4_service_YYYYMMDD.log` - 主日志
- `mf4_service_error_YYYYMMDD.log` - 错误日志

## 支持的文件操作

| 操作 | 说明 |
|------|------|
| open_file | 打开文件，支持创建不存在文件 |
| create_file | 创建新文件，支持覆盖 |
| close_file | 关闭文件 |
| save_file | 保存文件，支持覆盖 |
| read_signal | 读取信号数据 |
| read_signal_chunk | 分段读取信号 |
| write_signal | 写入信号，支持覆盖 |
| append_signal | 追加数据到现有信号 |
| get_signal_info | 获取信号元数据 |
| list_signals | 列出所有信号 |
| delete_signal | 删除信号 |
| list_channel_groups | 列出通道组 |
| get_metadata | 获取文件元数据 |

## 系统要求

- **Java**: JDK 11+ (兼容JDK 8)
- **Python**: 3.7+
- **依赖**: asammdf, numpy, psutil

## 许可证

MIT License
