#!/bin/bash

# MF4 Project Build Script
# 构建Java-Python MF4项目

set -e

echo "============================================"
echo "MF4 Project Build Script"
echo "============================================"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 检查Python
echo -e "${YELLOW}Checking Python...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo -e "${RED}Python not found!${NC}"
    exit 1
fi

echo "Python: $PYTHON"
$PYTHON --version

# 检查Java
echo -e "${YELLOW}Checking Java...${NC}"
if command -v java &> /dev/null; then
    java -version 2>&1 | head -1
else
    echo -e "${RED}Java not found!${NC}"
    exit 1
fi

if command -v mvn &> /dev/null; then
    echo "Maven: $(mvn -version | head -1)"
else
    echo -e "${RED}Maven not found!${NC}"
    exit 1
fi

# 安装Python依赖
echo ""
echo -e "${YELLOW}Installing Python dependencies...${NC}"
cd python
$PYTHON -m pip install -r requirements.txt
cd ..

# 编译Java项目
echo ""
echo -e "${YELLOW}Building Java project...${NC}"
cd java
mvn clean package -DskipTests
cd ..

# 检查构建结果
echo ""
echo -e "${YELLOW}Checking build artifacts...${NC}"
JAR_FILE="java/target/mf4-java-client-1.0.0-jar-with-dependencies.jar"
if [ -f "$JAR_FILE" ]; then
    echo -e "${GREEN}Build successful!${NC}"
    echo "JAR file: $JAR_FILE"
else
    echo -e "${RED}Build failed! JAR file not found.${NC}"
    exit 1
fi

# 创建运行脚本
echo ""
echo -e "${YELLOW}Creating run scripts...${NC}"

cat > run_python.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
cd python
python main.py "$@"
EOF
chmod +x run_python.sh

cat > run_java.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
java -jar java/target/mf4-java-client-1.0.0-jar-with-dependencies.jar "$@"
EOF
chmod +x run_java.sh

cat > run_demo.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "Running MF4 Demo..."
java -jar java/target/mf4-java-client-1.0.0-jar-with-dependencies.jar
EOF
chmod +x run_demo.sh

echo ""
echo "============================================"
echo -e "${GREEN}Build completed successfully!${NC}"
echo "============================================"
echo ""
echo "Usage:"
echo "  ./run_python.sh [options]  - Start Python service"
echo "  ./run_java.sh [options]    - Run Java client"
echo "  ./run_demo.sh              - Run demo"
echo ""
echo "Or manually:"
echo "  cd python && python main.py"
echo "  cd java && java -jar target/mf4-java-client-1.0.0-jar-with-dependencies.jar"
echo ""
