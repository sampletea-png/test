# MF4 项目结构说明

## 整体架构

```
┌─────────────────────────────────────────────────────────────────┐
│                         Java Application                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   MF4Client │  │ MF4Service  │  │ PythonProcessManager    │  │
│  │  (文件操作)  │  │ (生命周期)   │  │    (进程管理)            │  │
│  └──────┬──────┘  └──────┬──────┘  └─────────────────────────┘  │
│         │                │                                       │
│  ┌──────┴──────┐  ┌──────┴──────┐                                │
│  │MF4SocketClient│  │  Request/   │                               │
│  │  (Socket通信) │  │  Response   │                               │
│  └──────┬──────┘  └─────────────┘                                │
└─────────┼────────────────────────────────────────────────────────┘
          │ Socket (TCP)
          ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Python Service                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │MF4Server    │  │RequestHandler│  │     MF4Manager         │  │
│  │ (Socket服务) │  │  (请求处理)  │  │   (文件操作核心)        │  │
│  └──────┬──────┘  └──────┬──────┘  └─────────────────────────┘  │
│         │                │                                       │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌─────────────────────────┐  │
│  │  protocol   │  │   logger    │  │      asammdf            │  │
│  │ (通信协议)   │  │   (日志)    │  │   (MF4文件库)           │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## 模块说明

### Python端 (`python/`)

| 文件 | 说明 | 职责 |
|------|------|------|
| `main.py` | 服务入口 | 命令行参数解析、服务启动 |
| `requirements.txt` | 依赖列表 | Python包依赖 |
| `demo.py` | 演示脚本 | 独立演示Python端功能 |

#### `mf4_service/` 包

| 文件 | 说明 | 核心类/函数 |
|------|------|-------------|
| `__init__.py` | 包初始化 | 导出公共API |
| `protocol.py` | 通信协议 | `Request`, `Response`, `SignalInfo`, `ChunkInfo` |
| `server.py` | Socket服务器 | `MF4Server`, `start_server()` |
| `handler.py` | 请求处理器 | `RequestHandler` |
| `mf4_manager.py` | MF4文件管理 | `MF4Manager`, `FileHandle` |
| `logger.py` | 日志系统 | `MF4Logger`, `get_logger()` |

### Java端 (`java/src/main/java/com/mf4/`)

| 包 | 文件 | 说明 | 核心类 |
|----|------|------|--------|
| `protocol/` | `Request.java` | 请求类 | `Request`, `Builder` |
| `protocol/` | `Response.java` | 响应类 | `Response` |
| `protocol/` | `RequestType.java` | 请求类型枚举 | `RequestType` |
| `protocol/` | `ResponseStatus.java` | 响应状态枚举 | `ResponseStatus` |
| `client/` | `MF4Client.java` | MF4客户端 | `MF4Client`, `ChunkedSignalData`, `ProgressCallback` |
| `client/` | `MF4Service.java` | 服务生命周期 | `MF4Service`, `Builder` |
| `client/` | `MF4SocketClient.java` | Socket客户端 | `MF4SocketClient` |
| `process/` | `PythonProcessManager.java` | Python进程管理 | `PythonProcessManager`, `Builder`, `ProcessOutput` |
| `model/` | `SignalInfo.java` | 信号信息 | `SignalInfo` |
| `model/` | `SignalData.java` | 信号数据 | `SignalData` |
| `model/` | `ChunkInfo.java` | 分段信息 | `ChunkInfo` |

### 测试 (`java/src/test/java/com/mf4/`)

| 文件 | 说明 | 测试内容 |
|------|------|----------|
| `MF4ClientTest.java` | 客户端测试 | 文件操作、信号读写、多线程等 |

## 通信流程

### 1. 服务启动流程

```
Java端                                    Python端
  │                                         │
  │  1. MF4Service.initialize()            │
  │     - 启动Python进程                    │
  │     - 建立Socket连接                    │
  │                                         │
  │ ───────────── Socket ─────────────────> │
  │                                         │  2. MF4Server.start()
  │                                         │     - 监听端口
  │                                         │     - 等待连接
  │ <────────────────────────────────────── │
  │                                         │
  │  3. 发送ping验证                        │
  │                                         │
  │ ─────────── Request(ping) ────────────> │
  │                                         │  4. 处理请求
  │ <────────── Response(success) ──────── │
  │                                         │
  │  5. 服务就绪                            │
```

### 2. 文件操作流程

```
Java端                                    Python端
  │                                         │
  │  1. client.createFile(path, overwrite) │
  │                                         │
  │ ─────── Request(create_file) ─────────> │
  │                                         │  2. MF4Manager.create_file()
  │                                         │     - 创建MDF对象
  │                                         │     - 生成file_id
  │ <────── Response(file_id) ──────────── │
  │                                         │
  │  3. 返回file_id给调用者                 │
```

### 3. 信号读取流程（分段）

```
Java端                                    Python端
  │                                         │
  │  1. client.readSignalChunk(...)        │
  │                                         │
  │ ───── Request(read_signal_chunk) ─────> │
  │                                         │  2. MF4Manager.read_signal_chunk()
  │                                         │     - 读取指定范围数据
  │                                         │     - 返回数据和chunk_info
  │ <──── Response(data, chunk_info) ───── │
  │                                         │
  │  3. 返回ChunkedSignalData               │
  │                                         │
  │  4. 检查hasMore，继续读取下一块          │
```

## 多线程处理

### Java端多线程

```java
// 每个线程使用同一个MF4Client实例
// 所有方法都是synchronized，保证线程安全

ExecutorService executor = Executors.newFixedThreadPool(5);

for (int i = 0; i < 5; i++) {
    executor.submit(() -> {
        // 线程安全的调用
        client.writeSignal(fileId, "Signal_" + i, ...);
    });
}
```

### Python端处理

- 单进程多线程Socket服务器
- 每个连接一个处理线程
- MF4Manager使用RLock保护文件句柄
- 信号量限制最大并发数

## 内存管理

### 大文件处理策略

1. **分段读取**：默认每段10万样本点
2. **内存检查**：定期检测内存使用，触发GC
3. **流式处理**：不缓存完整数据
4. **及时关闭**：文件使用完毕立即关闭

### 配置参数

```python
# Python端
DEFAULT_CHUNK_SIZE = 100000      # 分段大小
MAX_MEMORY_CACHE_MB = 500        # 最大内存缓存
MAX_IDLE_TIME = 300             # 文件句柄最大空闲时间
```

```java
// Java端
DEFAULT_TIMEOUT_MS = 30000;      // 请求超时
BUFFER_SIZE = 8192;              // Socket缓冲区
```

## 错误处理

### 异常类型

| 异常 | 说明 | 处理 |
|------|------|------|
| `IOException` | 通信错误 | 重连或关闭服务 |
| `TimeoutException` | 请求超时 | 增加超时时间或检查Python端 |
| `FileNotFoundError` | 文件不存在 | 检查路径或启用create_if_not_exists |
| `ValueError` | 参数错误 | 检查参数有效性 |

### 重试机制

```java
// 连接重试
for (int i = 0; i < CONNECTION_RETRY_COUNT; i++) {
    try {
        if (client.connect()) {
            return;
        }
    } catch (IOException e) {
        if (i < CONNECTION_RETRY_COUNT - 1) {
            Thread.sleep(CONNECTION_RETRY_DELAY_MS);
        }
    }
}
```

## 日志系统

### Python端日志

```
logs/
├── mf4_service_YYYYMMDD.log       # 主日志
└── mf4_service_error_YYYYMMDD.log # 错误日志
```

日志格式：
```
[2024-01-15 10:30:45] [INFO] [MainThread] [server.py:123] - Server started
```

### Java端输出

- 标准输出：正常信息
- 标准错误：错误信息
- 回调函数：可自定义处理

## 扩展开发

### 添加新的请求类型

1. **Python端**：
   - 在 `protocol.py` 添加 `RequestType`
   - 在 `handler.py` 添加处理方法
   - 在 `mf4_manager.py` 实现具体逻辑

2. **Java端**：
   - 在 `RequestType.java` 添加枚举值
   - 在 `Request.java` 添加工厂方法
   - 在 `MF4Client.java` 添加API方法

### 自定义数据处理

```java
// 实现进度回调
client.readSignalComplete(fileId, "Signal", 10000, 
    (progress, current, total) -> {
        // 更新进度条
        updateProgressBar(progress);
    });
```
