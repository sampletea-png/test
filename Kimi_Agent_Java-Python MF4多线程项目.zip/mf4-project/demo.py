#!/usr/bin/env python3
"""
MF4 Python Service - 独立演示脚本
演示Python端的基本功能
"""
import sys
import os
import tempfile
import numpy as np

# 添加mf4_service到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from mf4_service import MF4Manager, get_logger
except ImportError as e:
    print(f"Error importing mf4_service: {e}")
    print("Please install dependencies: pip install -r python/requirements.txt")
    sys.exit(1)


def demo_basic_operations():
    """演示基本操作"""
    print("\n" + "=" * 60)
    print("MF4 Python Service - Basic Operations Demo")
    print("=" * 60)
    
    # 创建临时目录
    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, "demo.mf4")
    
    print(f"\nTest file: {test_file}")
    
    # 创建MF4管理器
    manager = MF4Manager(chunk_size=1000)
    
    try:
        # 1. 创建文件
        print("\n1. Creating file...")
        file_id = manager.create_file(test_file, overwrite=True)
        print(f"   File ID: {file_id}")
        
        # 2. 写入信号
        print("\n2. Writing signals...")
        
        # 信号1：正弦波
        timestamps1 = np.linspace(0, 10, 1000)
        samples1 = np.sin(2 * np.pi * timestamps1)
        manager.write_signal(file_id, "SineWave", timestamps1.tolist(), samples1.tolist(),
                            "V", "Sine wave signal", overwrite=False)
        print(f"   Written SineWave: {len(samples1)} samples")
        
        # 信号2：方波
        samples2 = np.sign(np.sin(2 * np.pi * timestamps1))
        manager.write_signal(file_id, "SquareWave", timestamps1.tolist(), samples2.tolist(),
                            "V", "Square wave signal", overwrite=False)
        print(f"   Written SquareWave: {len(samples2)} samples")
        
        # 3. 获取信号信息
        print("\n3. Getting signal info...")
        info1 = manager.get_signal_info(file_id, "SineWave")
        print(f"   SineWave:")
        print(f"     - Sample count: {info1.sample_count}")
        print(f"     - Sample rate: {info1.sample_rate:.2f} Hz")
        print(f"     - Duration: {info1.getDuration():.2f} s")
        print(f"     - Min/Max: {info1.min_value:.2f} / {info1.max_value:.2f}")
        
        # 4. 列出信号
        print("\n4. Listing signals...")
        signals = manager.list_signals(file_id)
        print(f"   Signals in file: {signals}")
        
        # 5. 读取信号（完整）
        print("\n5. Reading full signal...")
        data = manager.read_signal(file_id, "SineWave", 0, None)
        print(f"   Read {len(data['samples'])} samples")
        print(f"   First 5 samples: {data['samples'][:5]}")
        
        # 6. 分段读取
        print("\n6. Reading signal in chunks...")
        chunk_index = 0
        total_read = 0
        while True:
            chunk_data, chunk_info = manager.read_signal_chunk(file_id, "SineWave", chunk_index, 100)
            total_read += len(chunk_data['samples'])
            if chunk_info.is_last:
                break
            chunk_index += 1
        print(f"   Read {total_read} samples in {chunk_index + 1} chunks")
        
        # 7. 追加数据
        print("\n7. Appending data to signal...")
        more_timestamps = np.linspace(10, 12, 200).tolist()
        more_samples = np.sin(2 * np.pi * np.array(more_timestamps)).tolist()
        manager.append_signal(file_id, "SineWave", more_timestamps, more_samples)
        
        info_after = manager.get_signal_info(file_id, "SineWave")
        print(f"   Sample count after append: {info_after.sample_count}")
        
        # 8. 获取元数据
        print("\n8. Getting file metadata...")
        metadata = manager.get_metadata(file_id)
        print(f"   Version: {metadata.get('version')}")
        print(f"   Channel groups: {metadata.get('channel_group_count')}")
        
        # 9. 保存文件
        print("\n9. Saving file...")
        saved_path = manager.save_file(file_id, overwrite=True)
        print(f"   Saved to: {saved_path}")
        
        # 10. 获取状态
        print("\n10. Getting manager status...")
        status = manager.get_status()
        print(f"    Open files: {status['open_files']}")
        print(f"    Memory usage: {status['memory_usage_mb']:.2f} MB")
        
        # 11. 关闭文件
        print("\n11. Closing file...")
        manager.close_file(file_id)
        print("    File closed")
        
        # 12. 重新打开并验证
        print("\n12. Reopening file and verifying...")
        file_id2 = manager.open_file(test_file, "r", False)
        signals2 = manager.list_signals(file_id2)
        print(f"    Signals: {signals2}")
        manager.close_file(file_id2)
        
        print("\n" + "=" * 60)
        print("Demo completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # 清理
        manager.close_all_files()
        try:
            os.remove(test_file)
            os.rmdir(temp_dir)
        except:
            pass


def demo_large_file():
    """演示大文件处理"""
    print("\n" + "=" * 60)
    print("MF4 Python Service - Large File Demo")
    print("=" * 60)
    
    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, "large_demo.mf4")
    
    print(f"\nTest file: {test_file}")
    
    manager = MF4Manager(chunk_size=50000)
    
    try:
        # 创建大文件（100万样本点）
        print("\n1. Creating large file with 1,000,000 samples...")
        file_id = manager.create_file(test_file, overwrite=True)
        
        num_samples = 1000000
        timestamps = np.linspace(0, 100, num_samples)
        samples = np.sin(2 * np.pi * timestamps) + np.random.normal(0, 0.1, num_samples)
        
        print("   Writing signal...")
        manager.write_signal(file_id, "LargeSignal", timestamps.tolist(), samples.tolist(),
                            "V", "Large signal for testing", overwrite=False)
        
        info = manager.get_signal_info(file_id, "LargeSignal")
        print(f"   Written: {info.sample_count} samples")
        
        # 分段读取
        print("\n2. Reading in chunks...")
        chunk_size = 100000
        chunk_index = 0
        total_read = 0
        
        while True:
            chunk_data, chunk_info = manager.read_signal_chunk(file_id, "LargeSignal", chunk_index, chunk_size)
            total_read += len(chunk_data['samples'])
            
            if chunk_index % 5 == 0:
                print(f"   Chunk {chunk_index}: {chunk_info.getProgress() * 100:.1f}%")
            
            if chunk_info.is_last:
                break
            chunk_index += 1
        
        print(f"   Total read: {total_read} samples in {chunk_index + 1} chunks")
        
        # 内存使用
        status = manager.get_status()
        print(f"\n3. Memory usage: {status['memory_usage_mb']:.2f} MB")
        
        manager.close_file(file_id)
        
        print("\n" + "=" * 60)
        print("Large file demo completed!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        manager.close_all_files()
        try:
            os.remove(test_file)
            os.rmdir(temp_dir)
        except:
            pass


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='MF4 Python Service Demo')
    parser.add_argument('--large', action='store_true', help='Run large file demo')
    
    args = parser.parse_args()
    
    if args.large:
        demo_large_file()
    else:
        demo_basic_operations()
