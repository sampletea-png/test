package com.mf4;

import com.mf4.client.MF4Client;
import com.mf4.client.MF4Service;
import com.mf4.model.SignalData;
import com.mf4.model.SignalInfo;

import java.util.List;
import java.util.Map;

/**
 * MF4 Java Client - 主入口和示例程序
 * 
 * 演示如何使用MF4Service和MF4Client进行MF4文件操作
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("============================================");
        System.out.println("MF4 Java Client v1.0.0");
        System.out.println("============================================");
        
        if (args.length > 0 && args[0].equals("--help")) {
            printUsage();
            return;
        }
        
        // 示例1：基本使用（自动启动Python服务）
        demoBasicUsage();
        
        // 示例2：连接到已有服务
        // demoConnectToExistingServer();
        
        // 示例3：大文件分段读取
        // demoChunkedReading();
        
        // 示例4：多线程操作
        // demoMultiThreading();
    }
    
    /**
     * 示例1：基本使用
     */
    private static void demoBasicUsage() {
        System.out.println("\n--- Demo: Basic Usage ---\n");
        
        // Python脚本路径（根据实际情况修改）
        String pythonScriptPath = "../python/main.py";
        
        // 创建服务
        MF4Service service = MF4Service.builder()
                .pythonScriptPath(pythonScriptPath)
                .port(8765)
                .onPythonOutput(line -> System.out.println("[Python] " + line))
                .onPythonError(line -> System.err.println("[Python-ERR] " + line))
                .build();
        
        try {
            // 初始化服务（启动Python进程并连接）
            service.initialize();
            System.out.println("Service initialized successfully\n");
            
            // 获取客户端
            MF4Client client = service.getClient();
            
            // 创建新文件
            String testFile = "test_output.mf4";
            String fileId = client.createFile(testFile, true);
            System.out.println("Created file: " + testFile + " (ID: " + fileId + ")");
            
            // 写入信号
            double[] timestamps = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5};
            double[] samples = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
            client.writeSignal(fileId, "TestSignal", timestamps, samples, "V", "Test signal", false);
            System.out.println("Written signal: TestSignal (" + samples.length + " samples)");
            
            // 追加数据到信号
            double[] moreTimestamps = {0.6, 0.7, 0.8};
            double[] moreSamples = {7.0, 8.0, 9.0};
            client.appendSignal(fileId, "TestSignal", moreTimestamps, moreSamples);
            System.out.println("Appended " + moreSamples.length + " samples to TestSignal");
            
            // 获取信号信息（不加载数据）
            SignalInfo info = client.getSignalInfo(fileId, "TestSignal");
            System.out.println("\nSignal Info:");
            System.out.println("  Name: " + info.getName());
            System.out.println("  Unit: " + info.getUnit());
            System.out.println("  Sample Count: " + info.getSampleCount());
            System.out.println("  Sample Rate: " + info.getSampleRate());
            System.out.println("  Duration: " + info.getDuration() + "s");
            
            // 读取信号数据
            SignalData data = client.readSignal(fileId, "TestSignal");
            System.out.println("\nRead " + data.getLength() + " samples");
            
            // 列出所有信号
            List<String> signals = client.listSignals(fileId);
            System.out.println("\nSignals in file: " + signals);
            
            // 保存文件
            String savedPath = client.saveFile(fileId);
            System.out.println("\nFile saved to: " + savedPath);
            
            // 关闭文件
            client.closeFile(fileId);
            System.out.println("File closed");
            
            // 获取服务器状态
            Map<String, Object> status = client.getStatus();
            System.out.println("\nServer Status:");
            System.out.println("  Open Files: " + status.get("open_files"));
            System.out.println("  Memory Usage: " + status.get("memory_usage_mb") + " MB");
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 关闭服务
            service.shutdown();
            System.out.println("\nService shutdown complete");
        }
    }
    
    /**
     * 示例2：连接到已有服务
     */
    private static void demoConnectToExistingServer() {
        System.out.println("\n--- Demo: Connect to Existing Server ---\n");
        
        // 连接到已运行的Python服务
        MF4Service service = MF4Service.createForExistingServer("127.0.0.1", 8765);
        
        try {
            service.initialize();
            System.out.println("Connected to existing server");
            
            MF4Client client = service.getClient();
            
            // 执行操作...
            boolean pong = client.ping();
            System.out.println("Ping: " + (pong ? "Success" : "Failed"));
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            service.shutdown();
        }
    }
    
    /**
     * 示例3：大文件分段读取
     */
    private static void demoChunkedReading() {
        System.out.println("\n--- Demo: Chunked Reading ---\n");
        
        String pythonScriptPath = "../python/main.py";
        
        MF4Service service = MF4Service.builder()
                .pythonScriptPath(pythonScriptPath)
                .build();
        
        try {
            service.initialize();
            MF4Client client = service.getClient();
            
            // 假设有一个大文件
            String fileId = client.openFile("large_file.mf4", "r", false);
            
            // 获取信号信息
            SignalInfo info = client.getSignalInfo(fileId, "LargeSignal");
            System.out.println("Signal has " + info.getSampleCount() + " samples");
            
            // 分段读取，每段10000个样本
            int chunkSize = 10000;
            int chunkIndex = 0;
            
            while (true) {
                MF4Client.ChunkedSignalData chunked = client.readSignalChunk(
                        fileId, "LargeSignal", chunkIndex, chunkSize);
                
                SignalData data = chunked.getData();
                System.out.println("Read chunk " + chunkIndex + ": " + data.getLength() + " samples");
                
                // 处理数据...
                processChunk(data);
                
                if (!chunked.hasMore()) {
                    break;
                }
                chunkIndex++;
            }
            
            // 或者使用便捷方法读取完整信号
            SignalData allData = client.readSignalComplete(fileId, "LargeSignal", 10000, 
                    (progress, current, total) -> {
                        System.out.printf("Progress: %.1f%% (%d/%d chunks)\n", 
                                progress * 100, current, total);
                    });
            
            System.out.println("Total samples read: " + allData.getLength());
            
            client.closeFile(fileId);
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            service.shutdown();
        }
    }
    
    /**
     * 示例4：多线程操作
     */
    private static void demoMultiThreading() {
        System.out.println("\n--- Demo: Multi-Threading ---\n");
        
        String pythonScriptPath = "../python/main.py";
        
        MF4Service service = MF4Service.builder()
                .pythonScriptPath(pythonScriptPath)
                .maxWorkers(20)
                .build();
        
        try {
            service.initialize();
            MF4Client client = service.getClient();
            
            // 创建测试文件
            String fileId = client.createFile("multi_thread_test.mf4", true);
            
            // 多线程写入不同信号
            int numThreads = 5;
            Thread[] threads = new Thread[numThreads];
            
            for (int i = 0; i < numThreads; i++) {
                final int threadId = i;
                threads[i] = new Thread(() -> {
                    try {
                        String signalName = "Signal_" + threadId;
                        int numSamples = 1000;
                        double[] timestamps = new double[numSamples];
                        double[] samples = new double[numSamples];
                        
                        for (int j = 0; j < numSamples; j++) {
                            timestamps[j] = j * 0.01;
                            samples[j] = Math.sin(j * 0.1 + threadId);
                        }
                        
                        client.writeSignal(fileId, signalName, timestamps, samples, 
                                "V", "Thread " + threadId, false);
                        System.out.println("Thread " + threadId + " wrote " + signalName);
                        
                    } catch (Exception e) {
                        System.err.println("Thread " + threadId + " error: " + e.getMessage());
                    }
                });
                threads[i].start();
            }
            
            // 等待所有线程完成
            for (Thread t : threads) {
                t.join();
            }
            
            System.out.println("\nAll threads completed");
            
            // 列出所有信号
            List<String> signals = client.listSignals(fileId);
            System.out.println("Signals in file: " + signals.size());
            
            client.saveFile(fileId);
            client.closeFile(fileId);
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            service.shutdown();
        }
    }
    
    /**
     * 处理数据块（示例）
     */
    private static void processChunk(SignalData data) {
        // 实际应用中在这里处理数据
        // 例如：计算统计信息、写入数据库等
    }
    
    /**
     * 打印使用说明
     */
    private static void printUsage() {
        System.out.println("Usage: java -jar mf4-java-client.jar [options]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  --help          Show this help message");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  # Run basic demo");
        System.out.println("  java -jar mf4-java-client.jar");
        System.out.println();
        System.out.println("Environment Variables:");
        System.out.println("  MF4_HOST        Python service host (default: 127.0.0.1)");
        System.out.println("  MF4_PORT        Python service port (default: 8765)");
    }
}
