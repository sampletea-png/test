package com.mf4.model;

import com.google.gson.annotations.SerializedName;

/**
 * 信号信息类 - 不包含实际数据，仅包含信号元数据
 * 
 * 属性说明：
 * - name: 信号名称
 * - unit: 单位
 * - comment: 信号注释
 * - dataType: 数据类型
 * - sampleCount: 采样点数
 * - sampleRate: 采样率
 * - startTime: 开始时间
 * - endTime: 结束时间
 * - minValue: 最小值
 * - maxValue: 最大值
 * - channelGroupId: 所属通道组ID
 * - source: 信号来源
 */
public class SignalInfo {
    
    @SerializedName("name")
    private String name;
    
    @SerializedName("unit")
    private String unit;
    
    @SerializedName("comment")
    private String comment;
    
    @SerializedName("data_type")
    private String dataType;
    
    @SerializedName("sample_count")
    private int sampleCount;
    
    @SerializedName("sample_rate")
    private double sampleRate;
    
    @SerializedName("start_time")
    private double startTime;
    
    @SerializedName("end_time")
    private double endTime;
    
    @SerializedName("min_value")
    private Double minValue;
    
    @SerializedName("max_value")
    private Double maxValue;
    
    @SerializedName("channel_group_id")
    private Integer channelGroupId;
    
    @SerializedName("source")
    private String source;
    
    // 默认构造函数
    public SignalInfo() {
    }
    
    // 全参数构造函数
    public SignalInfo(String name, String unit, String comment, String dataType,
                      int sampleCount, double sampleRate, double startTime, double endTime,
                      Double minValue, Double maxValue, Integer channelGroupId, String source) {
        this.name = name;
        this.unit = unit;
        this.comment = comment;
        this.dataType = dataType;
        this.sampleCount = sampleCount;
        this.sampleRate = sampleRate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.channelGroupId = channelGroupId;
        this.source = source;
    }
    
    // Getters
    public String getName() {
        return name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public String getDataType() {
        return dataType;
    }
    
    public int getSampleCount() {
        return sampleCount;
    }
    
    public double getSampleRate() {
        return sampleRate;
    }
    
    public double getStartTime() {
        return startTime;
    }
    
    public double getEndTime() {
        return endTime;
    }
    
    public Double getMinValue() {
        return minValue;
    }
    
    public Double getMaxValue() {
        return maxValue;
    }
    
    public Integer getChannelGroupId() {
        return channelGroupId;
    }
    
    public String getSource() {
        return source;
    }
    
    // Setters
    public void setName(String name) {
        this.name = name;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    public void setSampleCount(int sampleCount) {
        this.sampleCount = sampleCount;
    }
    
    public void setSampleRate(double sampleRate) {
        this.sampleRate = sampleRate;
    }
    
    public void setStartTime(double startTime) {
        this.startTime = startTime;
    }
    
    public void setEndTime(double endTime) {
        this.endTime = endTime;
    }
    
    public void setMinValue(Double minValue) {
        this.minValue = minValue;
    }
    
    public void setMaxValue(Double maxValue) {
        this.maxValue = maxValue;
    }
    
    public void setChannelGroupId(Integer channelGroupId) {
        this.channelGroupId = channelGroupId;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
    /**
     * 获取持续时间
     */
    public double getDuration() {
        return endTime - startTime;
    }
    
    @Override
    public String toString() {
        return "SignalInfo{" +
                "name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", sampleCount=" + sampleCount +
                ", sampleRate=" + sampleRate +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", minValue=" + minValue +
                ", maxValue=" + maxValue +
                '}';
    }
}
