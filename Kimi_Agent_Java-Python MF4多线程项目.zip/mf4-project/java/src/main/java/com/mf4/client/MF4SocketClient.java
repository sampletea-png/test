package com.mf4.client;

import com.google.gson.Gson;
import com.mf4.protocol.Request;
import com.mf4.protocol.Response;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MF4 Socket客户端
 * 
 * 负责与Python服务建立Socket连接并发送/接收消息
 * 支持多线程并发请求
 */
public class MF4SocketClient {
    
    // 协议常量
    private static final String MESSAGE_DELIMITER = "\n\nEND_OF_MESSAGE\n\n";
    private static final int BUFFER_SIZE = 8192;
    private static final int DEFAULT_TIMEOUT_MS = 30000; // 30秒默认超时
    
    private final String host;
    private final int port;
    private final int timeoutMs;
    
    private Socket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    
    private final AtomicBoolean connected = new AtomicBoolean(false);
    private final AtomicInteger requestCounter = new AtomicInteger(0);
    
    private final Gson gson = new Gson();
    private final Object lock = new Object();
    
    // 连接监控
    private ScheduledExecutorService heartbeatExecutor;
    private long lastActivityTime;
    
    /**
     * 构造函数
     * 
     * @param host 服务器地址
     * @param port 服务器端口
     */
    public MF4SocketClient(String host, int port) {
        this(host, port, DEFAULT_TIMEOUT_MS);
    }
    
    /**
     * 构造函数
     * 
     * @param host 服务器地址
     * @param port 服务器端口
     * @param timeoutMs 超时时间（毫秒）
     */
    public MF4SocketClient(String host, int port, int timeoutMs) {
        this.host = host;
        this.port = port;
        this.timeoutMs = timeoutMs;
    }
    
    /**
     * 连接到服务器
     * 
     * @return 是否连接成功
     * @throws IOException 连接失败
     */
    public synchronized boolean connect() throws IOException {
        if (connected.get()) {
            return true;
        }
        
        try {
            socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, port), timeoutMs);
            socket.setSoTimeout(timeoutMs);
            socket.setTcpNoDelay(true);
            socket.setKeepAlive(true);
            
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();
            
            connected.set(true);
            lastActivityTime = System.currentTimeMillis();
            
            // 启动心跳
            startHeartbeat();
            
            System.out.println("Connected to MF4 server at " + host + ":" + port);
            return true;
            
        } catch (IOException e) {
            close();
            throw e;
        }
    }
    
    /**
     * 关闭连接
     */
    public synchronized void close() {
        connected.set(false);
        
        // 停止心跳
        if (heartbeatExecutor != null) {
            heartbeatExecutor.shutdownNow();
        }
        
        // 关闭流
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (IOException e) {
            // 忽略
        }
        
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        } catch (IOException e) {
            // 忽略
        }
        
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            // 忽略
        }
        
        outputStream = null;
        inputStream = null;
        socket = null;
        
        System.out.println("Disconnected from MF4 server");
    }
    
    /**
     * 发送请求并接收响应
     * 
     * @param request 请求对象
     * @return 响应对象
     * @throws IOException 通信错误
     * @throws TimeoutException 超时
     */
    public Response sendRequest(Request request) throws IOException, TimeoutException {
        if (!connected.get()) {
            throw new IOException("Not connected to server");
        }
        
        synchronized (lock) {
            // 序列化请求
            String requestJson = request.toJson();
            byte[] requestBytes = requestJson.getBytes(StandardCharsets.UTF_8);
            
            // 发送请求（带分隔符）
            byte[] message = new byte[requestBytes.length + MESSAGE_DELIMITER.length()];
            System.arraycopy(requestBytes, 0, message, 0, requestBytes.length);
            System.arraycopy(MESSAGE_DELIMITER.getBytes(StandardCharsets.UTF_8), 0, 
                           message, requestBytes.length, MESSAGE_DELIMITER.length());
            
            outputStream.write(message);
            outputStream.flush();
            
            lastActivityTime = System.currentTimeMillis();
            
            // 接收响应
            return receiveResponse();
        }
    }
    
    /**
     * 接收响应
     */
    private Response receiveResponse() throws IOException, TimeoutException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] readBuffer = new byte[BUFFER_SIZE];
        long startTime = System.currentTimeMillis();
        
        while (System.currentTimeMillis() - startTime < timeoutMs) {
            try {
                int available = inputStream.available();
                if (available > 0) {
                    int toRead = Math.min(available, readBuffer.length);
                    int bytesRead = inputStream.read(readBuffer, 0, toRead);
                    
                    if (bytesRead > 0) {
                        buffer.write(readBuffer, 0, bytesRead);
                        
                        // 检查是否收到完整消息
                        byte[] data = buffer.toByteArray();
                        byte[] delimiterBytes = MESSAGE_DELIMITER.getBytes(StandardCharsets.UTF_8);
                        
                        int delimiterIndex = findDelimiter(data, delimiterBytes);
                        if (delimiterIndex >= 0) {
                            // 提取消息
                            byte[] messageBytes = new byte[delimiterIndex];
                            System.arraycopy(data, 0, messageBytes, 0, delimiterIndex);
                            
                            // 剩余数据保留在buffer中
                            byte[] remaining = new byte[data.length - delimiterIndex - delimiterBytes.length];
                            if (remaining.length > 0) {
                                System.arraycopy(data, delimiterIndex + delimiterBytes.length, remaining, 0, remaining.length);
                            }
                            buffer.reset();
                            buffer.write(remaining);
                            
                            // 解析响应
                            String responseJson = new String(messageBytes, StandardCharsets.UTF_8);
                            lastActivityTime = System.currentTimeMillis();
                            return Response.fromJson(responseJson);
                        }
                    }
                } else {
                    // 没有数据，短暂等待
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new IOException("Interrupted while waiting for response");
                    }
                }
            } catch (SocketTimeoutException e) {
                throw new TimeoutException("Timeout waiting for response");
            }
        }
        
        throw new TimeoutException("Timeout waiting for response");
    }
    
    /**
     * 查找分隔符位置
     */
    private int findDelimiter(byte[] data, byte[] delimiter) {
        for (int i = 0; i <= data.length - delimiter.length; i++) {
            boolean found = true;
            for (int j = 0; j < delimiter.length; j++) {
                if (data[i + j] != delimiter[j]) {
                    found = false;
                    break;
                }
            }
            if (found) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * 启动心跳检测
     */
    private void startHeartbeat() {
        heartbeatExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "MF4-Heartbeat");
            t.setDaemon(true);
            return t;
        });
        
        heartbeatExecutor.scheduleAtFixedRate(() -> {
            try {
                // 如果超过60秒没有活动，发送ping
                if (System.currentTimeMillis() - lastActivityTime > 60000) {
                    Request pingRequest = Request.ping();
                    Response response = sendRequest(pingRequest);
                    if (!response.isSuccess()) {
                        System.err.println("Heartbeat failed: " + response.getErrorMessage());
                    }
                }
            } catch (Exception e) {
                System.err.println("Heartbeat error: " + e.getMessage());
            }
        }, 30, 30, TimeUnit.SECONDS);
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return connected.get() && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    /**
     * 获取主机地址
     */
    public String getHost() {
        return host;
    }
    
    /**
     * 获取端口
     */
    public int getPort() {
        return port;
    }
    
    /**
     * 发送ping请求
     */
    public boolean ping() {
        try {
            Response response = sendRequest(Request.ping());
            return response.isSuccess();
        } catch (Exception e) {
            return false;
        }
    }
}
