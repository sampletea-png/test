package com.mf4.protocol;

/**
 * 请求类型枚举
 * 定义Java与Python之间所有可能的请求类型
 */
public enum RequestType {
    // 文件操作
    OPEN_FILE("open_file"),
    CREATE_FILE("create_file"),
    CLOSE_FILE("close_file"),
    SAVE_FILE("save_file"),
    
    // 信号操作
    READ_SIGNAL("read_signal"),
    READ_SIGNAL_CHUNK("read_signal_chunk"),
    WRITE_SIGNAL("write_signal"),
    APPEND_SIGNAL("append_signal"),
    GET_SIGNAL_INFO("get_signal_info"),
    LIST_SIGNALS("list_signals"),
    DELETE_SIGNAL("delete_signal"),
    
    // 通道组操作
    LIST_CHANNEL_GROUPS("list_channel_groups"),
    GET_CHANNEL_GROUP_INFO("get_channel_group_info"),
    
    // 元数据操作
    GET_METADATA("get_metadata"),
    SET_METADATA("set_metadata"),
    
    // 系统操作
    PING("ping"),
    SHUTDOWN("shutdown"),
    GET_STATUS("get_status");
    
    private final String value;
    
    RequestType(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
    
    public static RequestType fromValue(String value) {
        for (RequestType type : values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown request type: " + value);
    }
}
