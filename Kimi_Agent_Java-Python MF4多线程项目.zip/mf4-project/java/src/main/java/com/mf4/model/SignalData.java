package com.mf4.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 信号数据类 - 包含时间戳和采样值
 */
public class SignalData {
    
    @SerializedName("timestamps")
    private List<Double> timestamps;
    
    @SerializedName("samples")
    private List<Double> samples;
    
    @SerializedName("start_index")
    private int startIndex;
    
    @SerializedName("end_index")
    private int endIndex;
    
    @SerializedName("total_samples")
    private int totalSamples;
    
    // 默认构造函数
    public SignalData() {
    }
    
    // 全参数构造函数
    public SignalData(List<Double> timestamps, List<Double> samples, 
                      int startIndex, int endIndex, int totalSamples) {
        this.timestamps = timestamps;
        this.samples = samples;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.totalSamples = totalSamples;
    }
    
    // Getters
    public List<Double> getTimestamps() {
        return timestamps;
    }
    
    public List<Double> getSamples() {
        return samples;
    }
    
    public int getStartIndex() {
        return startIndex;
    }
    
    public int getEndIndex() {
        return endIndex;
    }
    
    public int getTotalSamples() {
        return totalSamples;
    }
    
    // Setters
    public void setTimestamps(List<Double> timestamps) {
        this.timestamps = timestamps;
    }
    
    public void setSamples(List<Double> samples) {
        this.samples = samples;
    }
    
    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }
    
    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }
    
    public void setTotalSamples(int totalSamples) {
        this.totalSamples = totalSamples;
    }
    
    /**
     * 获取当前数据长度
     */
    public int getLength() {
        return timestamps != null ? timestamps.size() : 0;
    }
    
    /**
     * 检查是否还有更多数据
     */
    public boolean hasMore() {
        return endIndex < totalSamples;
    }
    
    @Override
    public String toString() {
        return "SignalData{" +
                "startIndex=" + startIndex +
                ", endIndex=" + endIndex +
                ", totalSamples=" + totalSamples +
                ", length=" + getLength() +
                '}';
    }
}
