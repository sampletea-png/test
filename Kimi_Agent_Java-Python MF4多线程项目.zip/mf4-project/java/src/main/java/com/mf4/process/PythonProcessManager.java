package com.mf4.process;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/**
 * Python进程管理器
 * 
 * 负责：
 * - 启动Python服务进程
 * - 监控进程状态
 * - 优雅关闭进程
 * - Java异常时自动关闭Python进程
 */
public class PythonProcessManager {
    
    private static final long PROCESS_START_TIMEOUT_MS = 30000; // 30秒启动超时
    private static final long PROCESS_SHUTDOWN_TIMEOUT_MS = 10000; // 10秒关闭超时
    private static final int CHECK_INTERVAL_MS = 100; // 检查间隔
    
    private final String pythonExecutable;
    private final String scriptPath;
    private final String[] args;
    
    private Process process;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicReference<ProcessOutput> output = new AtomicReference<>();
    
    private Thread shutdownHook;
    private ExecutorService executorService;
    private ScheduledExecutorService monitorExecutor;
    
    // 回调函数
    private Consumer<String> onOutput;
    private Consumer<String> onError;
    private Consumer<Integer> onExit;
    
    /**
     * 进程输出封装
     */
    public static class ProcessOutput {
        private final StringBuilder stdout = new StringBuilder();
        private final StringBuilder stderr = new StringBuilder();
        
        public synchronized void appendStdout(String line) {
            stdout.append(line).append("\n");
        }
        
        public synchronized void appendStderr(String line) {
            stderr.append(line).append("\n");
        }
        
        public synchronized String getStdout() {
            return stdout.toString();
        }
        
        public synchronized String getStderr() {
            return stderr.toString();
        }
    }
    
    /**
     * Builder类
     */
    public static class Builder {
        private String pythonExecutable = "python";
        private String scriptPath;
        private String[] args = new String[0];
        private Consumer<String> onOutput;
        private Consumer<String> onError;
        private Consumer<Integer> onExit;
        
        public Builder pythonExecutable(String pythonExecutable) {
            this.pythonExecutable = pythonExecutable;
            return this;
        }
        
        public Builder scriptPath(String scriptPath) {
            this.scriptPath = scriptPath;
            return this;
        }
        
        public Builder args(String... args) {
            this.args = args;
            return this;
        }
        
        public Builder onOutput(Consumer<String> onOutput) {
            this.onOutput = onOutput;
            return this;
        }
        
        public Builder onError(Consumer<String> onError) {
            this.onError = onError;
            return this;
        }
        
        public Builder onExit(Consumer<Integer> onExit) {
            this.onExit = onExit;
            return this;
        }
        
        public PythonProcessManager build() {
            if (scriptPath == null || scriptPath.isEmpty()) {
                throw new IllegalStateException("scriptPath is required");
            }
            PythonProcessManager manager = new PythonProcessManager(pythonExecutable, scriptPath, args);
            manager.onOutput = this.onOutput;
            manager.onError = this.onError;
            manager.onExit = this.onExit;
            return manager;
        }
    }
    
    private PythonProcessManager(String pythonExecutable, String scriptPath, String[] args) {
        this.pythonExecutable = pythonExecutable;
        this.scriptPath = scriptPath;
        this.args = args;
    }
    
    /**
     * 启动Python进程
     * 
     * @return 是否成功启动
     * @throws IOException 启动失败
     * @throws TimeoutException 启动超时
     */
    public synchronized boolean start() throws IOException, TimeoutException, InterruptedException {
        if (running.get()) {
            System.out.println("Python process is already running");
            return true;
        }
        
        // 构建命令
        String[] command = new String[2 + args.length];
        command[0] = pythonExecutable;
        command[1] = scriptPath;
        System.arraycopy(args, 0, command, 2, args.length);
        
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(false);
        
        // 设置工作目录为脚本所在目录
        Path scriptDir = Paths.get(scriptPath).getParent();
        if (scriptDir != null) {
            pb.directory(scriptDir.toFile());
        }
        
        // 启动进程
        System.out.println("Starting Python process: " + String.join(" ", command));
        process = pb.start();
        
        // 初始化执行器
        executorService = Executors.newFixedThreadPool(2);
        monitorExecutor = Executors.newSingleThreadScheduledExecutor();
        
        // 启动输出读取线程
        output.set(new ProcessOutput());
        executorService.submit(this::readStdout);
        executorService.submit(this::readStderr);
        
        // 注册关闭钩子
        shutdownHook = new Thread(this::shutdown);
        Runtime.getRuntime().addShutdownHook(shutdownHook);
        
        // 启动监控
        startMonitoring();
        
        // 等待进程启动
        if (!waitForProcessStart()) {
            stop();
            throw new TimeoutException("Python process failed to start within timeout");
        }
        
        running.set(true);
        System.out.println("Python process started successfully, PID: " + process.pid());
        return true;
    }
    
    /**
     * 等待进程启动
     */
    private boolean waitForProcessStart() throws InterruptedException {
        long startTime = System.currentTimeMillis();
        
        while (System.currentTimeMillis() - startTime < PROCESS_START_TIMEOUT_MS) {
            if (!process.isAlive()) {
                // 进程已退出
                return false;
            }
            
            // 检查输出中是否包含启动成功标志
            String stdout = output.get().getStdout();
            if (stdout.contains("Server started") || stdout.contains("MF4 Python Service")) {
                return true;
            }
            
            Thread.sleep(CHECK_INTERVAL_MS);
        }
        
        return false;
    }
    
    /**
     * 读取标准输出
     */
    private void readStdout() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.get().appendStdout(line);
                if (onOutput != null) {
                    onOutput.accept(line);
                }
            }
        } catch (IOException e) {
            if (running.get()) {
                System.err.println("Error reading stdout: " + e.getMessage());
            }
        }
    }
    
    /**
     * 读取标准错误
     */
    private void readStderr() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.get().appendStderr(line);
                if (onError != null) {
                    onError.accept(line);
                }
            }
        } catch (IOException e) {
            if (running.get()) {
                System.err.println("Error reading stderr: " + e.getMessage());
            }
        }
    }
    
    /**
     * 启动进程监控
     */
    private void startMonitoring() {
        monitorExecutor.scheduleAtFixedRate(() -> {
            if (!process.isAlive() && running.get()) {
                int exitCode = process.exitValue();
                System.err.println("Python process exited unexpectedly with code: " + exitCode);
                running.set(false);
                if (onExit != null) {
                    onExit.accept(exitCode);
                }
            }
        }, 1, 1, TimeUnit.SECONDS);
    }
    
    /**
     * 停止Python进程
     */
    public synchronized void stop() {
        if (!running.get() && process == null) {
            return;
        }
        
        System.out.println("Stopping Python process...");
        running.set(false);
        
        // 移除关闭钩子
        if (shutdownHook != null) {
            try {
                Runtime.getRuntime().removeShutdownHook(shutdownHook);
            } catch (IllegalStateException e) {
                // JVM正在关闭，忽略
            }
        }
        
        // 停止监控
        if (monitorExecutor != null) {
            monitorExecutor.shutdownNow();
        }
        
        // 关闭执行器
        if (executorService != null) {
            executorService.shutdownNow();
        }
        
        // 关闭进程
        if (process != null && process.isAlive()) {
            // 先尝试优雅关闭
            process.destroy();
            
            try {
                if (!process.waitFor(PROCESS_SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    // 强制关闭
                    System.err.println("Python process did not terminate gracefully, forcing...");
                    process.destroyForcibly();
                    process.waitFor(5000, TimeUnit.MILLISECONDS);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            }
        }
        
        process = null;
        System.out.println("Python process stopped");
    }
    
    /**
     * 关闭（同stop）
     */
    public void shutdown() {
        stop();
    }
    
    /**
     * 检查进程是否正在运行
     */
    public boolean isRunning() {
        return running.get() && process != null && process.isAlive();
    }
    
    /**
     * 获取进程ID
     */
    public long getPid() {
        return process != null ? process.pid() : -1;
    }
    
    /**
     * 获取标准输出
     */
    public String getStdout() {
        return output.get() != null ? output.get().getStdout() : "";
    }
    
    /**
     * 获取标准错误
     */
    public String getStderr() {
        return output.get() != null ? output.get().getStderr() : "";
    }
    
    /**
     * 发送信号到进程（Unix/Linux）
     */
    public boolean sendSignal(int signal) {
        if (process == null || !process.isAlive()) {
            return false;
        }
        
        try {
            // 使用kill命令发送信号
            Process killProcess = Runtime.getRuntime().exec("kill -" + signal + " " + process.pid());
            return killProcess.waitFor(5, TimeUnit.SECONDS) && killProcess.exitValue() == 0;
        } catch (Exception e) {
            System.err.println("Failed to send signal: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 便捷工厂方法
     */
    public static Builder builder() {
        return new Builder();
    }
    
    /**
     * 从路径自动检测Python可执行文件
     */
    public static String detectPythonExecutable() {
        String[] candidates = {"python3", "python", "py"};
        
        for (String candidate : candidates) {
            try {
                Process process = Runtime.getRuntime().exec(candidate + " --version");
                if (process.waitFor(5, TimeUnit.SECONDS) && process.exitValue() == 0) {
                    return candidate;
                }
            } catch (Exception e) {
                // 继续尝试下一个
            }
        }
        
        return "python"; // 默认返回
    }
}
