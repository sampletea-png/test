package com.mf4.model;

import com.google.gson.annotations.SerializedName;

/**
 * 分段信息类 - 用于大文件分段读取
 * 
 * 属性说明：
 * - startIndex: 起始索引
 * - endIndex: 结束索引
 * - totalSamples: 总采样点数
 * - chunkSize: 当前块大小
 * - isLast: 是否为最后一块
 */
public class ChunkInfo {
    
    @SerializedName("start_index")
    private int startIndex;
    
    @SerializedName("end_index")
    private int endIndex;
    
    @SerializedName("total_samples")
    private int totalSamples;
    
    @SerializedName("chunk_size")
    private int chunkSize;
    
    @SerializedName("is_last")
    private boolean isLast;
    
    // 默认构造函数
    public ChunkInfo() {
    }
    
    // 全参数构造函数
    public ChunkInfo(int startIndex, int endIndex, int totalSamples, int chunkSize, boolean isLast) {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.totalSamples = totalSamples;
        this.chunkSize = chunkSize;
        this.isLast = isLast;
    }
    
    // Getters
    public int getStartIndex() {
        return startIndex;
    }
    
    public int getEndIndex() {
        return endIndex;
    }
    
    public int getTotalSamples() {
        return totalSamples;
    }
    
    public int getChunkSize() {
        return chunkSize;
    }
    
    public boolean isLast() {
        return isLast;
    }
    
    // Setters
    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }
    
    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }
    
    public void setTotalSamples(int totalSamples) {
        this.totalSamples = totalSamples;
    }
    
    public void setChunkSize(int chunkSize) {
        this.chunkSize = chunkSize;
    }
    
    public void setLast(boolean last) {
        isLast = last;
    }
    
    /**
     * 获取下一块的索引
     */
    public int getNextChunkIndex() {
        return isLast ? -1 : (endIndex / chunkSize);
    }
    
    /**
     * 计算总块数
     */
    public int getTotalChunks() {
        return (int) Math.ceil((double) totalSamples / chunkSize);
    }
    
    /**
     * 获取当前块索引（从0开始）
     */
    public int getCurrentChunkIndex() {
        return startIndex / chunkSize;
    }
    
    /**
     * 获取读取进度（0.0 - 1.0）
     */
    public double getProgress() {
        return (double) endIndex / totalSamples;
    }
    
    @Override
    public String toString() {
        return "ChunkInfo{" +
                "startIndex=" + startIndex +
                ", endIndex=" + endIndex +
                ", totalSamples=" + totalSamples +
                ", chunkSize=" + chunkSize +
                ", isLast=" + isLast +
                ", progress=" + String.format("%.2f%%", getProgress() * 100) +
                '}';
    }
}
