package com.mf4.client;

import com.mf4.model.ChunkInfo;
import com.mf4.model.SignalData;
import com.mf4.model.SignalInfo;
import com.mf4.protocol.Request;
import com.mf4.protocol.Response;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeoutException;

/**
 * MF4客户端 - Java端的主要API
 * 
 * 提供对MF4文件的所有操作接口
 * 线程安全：每个方法都是同步的，支持多线程并发调用
 */
public class MF4Client {
    
    private final MF4SocketClient socketClient;
    
    /**
     * 构造函数
     * 
     * @param host Python服务地址
     * @param port Python服务端口
     */
    public MF4Client(String host, int port) {
        this.socketClient = new MF4SocketClient(host, port);
    }
    
    /**
     * 构造函数（带超时）
     * 
     * @param host Python服务地址
     * @param port Python服务端口
     * @param timeoutMs 超时时间（毫秒）
     */
    public MF4Client(String host, int port, int timeoutMs) {
        this.socketClient = new MF4SocketClient(host, port, timeoutMs);
    }
    
    /**
     * 连接到Python服务
     */
    public synchronized boolean connect() throws IOException {
        return socketClient.connect();
    }
    
    /**
     * 关闭连接
     */
    public synchronized void close() {
        socketClient.close();
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return socketClient.isConnected();
    }
    
    // ==================== 文件操作 ====================
    
    /**
     * 打开MF4文件
     * 
     * @param filePath 文件路径
     * @param mode 打开模式（"r"读取, "w"写入, "rw"读写）
     * @param createIfNotExists 文件不存在时是否创建
     * @return 文件ID
     * @throws IOException 打开失败
     */
    public synchronized String openFile(String filePath, String mode, boolean createIfNotExists) 
            throws IOException, TimeoutException {
        Request request = Request.openFile(filePath, mode, createIfNotExists);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to open file: " + response.getErrorMessage());
        }
        
        Map<String, Object> data = response.getDataAsMap();
        return (String) data.get("file_id");
    }
    
    /**
     * 打开MF4文件（读取模式）
     * 
     * @param filePath 文件路径
     * @return 文件ID
     * @throws IOException 打开失败
     */
    public String openFile(String filePath) throws IOException, TimeoutException {
        return openFile(filePath, "r", false);
    }
    
    /**
     * 创建新的MF4文件
     * 
     * @param filePath 文件路径
     * @param overwrite 是否覆盖已存在的文件
     * @return 文件ID
     * @throws IOException 创建失败
     */
    public synchronized String createFile(String filePath, boolean overwrite) 
            throws IOException, TimeoutException {
        Request request = Request.createFile(filePath, overwrite);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to create file: " + response.getErrorMessage());
        }
        
        Map<String, Object> data = response.getDataAsMap();
        return (String) data.get("file_id");
    }
    
    /**
     * 关闭文件
     * 
     * @param fileId 文件ID
     * @throws IOException 关闭失败
     */
    public synchronized void closeFile(String fileId) throws IOException, TimeoutException {
        Request request = Request.closeFile(fileId);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to close file: " + response.getErrorMessage());
        }
    }
    
    /**
     * 保存文件
     * 
     * @param fileId 文件ID
     * @param overwrite 是否覆盖原文件
     * @return 保存的文件路径
     * @throws IOException 保存失败
     */
    public synchronized String saveFile(String fileId, boolean overwrite) 
            throws IOException, TimeoutException {
        Request request = Request.saveFile(fileId, overwrite);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to save file: " + response.getErrorMessage());
        }
        
        Map<String, Object> data = response.getDataAsMap();
        return (String) data.get("saved_path");
    }
    
    /**
     * 保存文件（不覆盖）
     * 
     * @param fileId 文件ID
     * @return 保存的文件路径
     * @throws IOException 保存失败
     */
    public String saveFile(String fileId) throws IOException, TimeoutException {
        return saveFile(fileId, false);
    }
    
    // ==================== 信号读取 ====================
    
    /**
     * 获取信号信息（不加载数据）
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @return 信号信息
     * @throws IOException 获取失败
     */
    public synchronized SignalInfo getSignalInfo(String fileId, String signalName) 
            throws IOException, TimeoutException {
        Request request = Request.getSignalInfo(fileId, signalName);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to get signal info: " + response.getErrorMessage());
        }
        
        return response.getDataAs(SignalInfo.class);
    }
    
    /**
     * 读取信号数据
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param startIndex 起始索引
     * @param endIndex 结束索引（null表示读取全部）
     * @return 信号数据
     * @throws IOException 读取失败
     */
    public synchronized SignalData readSignal(String fileId, String signalName, 
                                               int startIndex, Integer endIndex) 
            throws IOException, TimeoutException {
        Request request = Request.readSignal(fileId, signalName, startIndex, endIndex);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to read signal: " + response.getErrorMessage());
        }
        
        return response.getDataAs(SignalData.class);
    }
    
    /**
     * 读取完整信号数据
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @return 信号数据
     * @throws IOException 读取失败
     */
    public SignalData readSignal(String fileId, String signalName) 
            throws IOException, TimeoutException {
        return readSignal(fileId, signalName, 0, null);
    }
    
    /**
     * 分段读取信号
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param chunkIndex 块索引（从0开始）
     * @param chunkSize 块大小（null使用默认值）
     * @return 信号数据和分段信息
     * @throws IOException 读取失败
     */
    public synchronized ChunkedSignalData readSignalChunk(String fileId, String signalName,
                                                           int chunkIndex, Integer chunkSize) 
            throws IOException, TimeoutException {
        Request request = Request.readSignalChunk(fileId, signalName, chunkIndex, chunkSize);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to read signal chunk: " + response.getErrorMessage());
        }
        
        SignalData data = response.getDataAs(SignalData.class);
        ChunkInfo chunkInfo = null;
        if (response.getChunkInfo() != null) {
            chunkInfo = new ChunkInfo();
            chunkInfo.setStartIndex(((Number) response.getChunkInfo().get("start_index")).intValue());
            chunkInfo.setEndIndex(((Number) response.getChunkInfo().get("end_index")).intValue());
            chunkInfo.setTotalSamples(((Number) response.getChunkInfo().get("total_samples")).intValue());
            chunkInfo.setChunkSize(((Number) response.getChunkInfo().get("chunk_size")).intValue());
            chunkInfo.setLast((Boolean) response.getChunkInfo().get("is_last"));
        }
        
        return new ChunkedSignalData(data, chunkInfo, response.isHasMore());
    }
    
    /**
     * 分段读取信号（使用默认块大小）
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param chunkIndex 块索引
     * @return 信号数据和分段信息
     * @throws IOException 读取失败
     */
    public ChunkedSignalData readSignalChunk(String fileId, String signalName, int chunkIndex) 
            throws IOException, TimeoutException {
        return readSignalChunk(fileId, signalName, chunkIndex, null);
    }
    
    /**
     * 读取完整信号（自动分段）
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param chunkSize 块大小
     * @param callback 进度回调
     * @return 完整信号数据
     * @throws IOException 读取失败
     */
    public SignalData readSignalComplete(String fileId, String signalName, int chunkSize,
                                          ProgressCallback callback) 
            throws IOException, TimeoutException {
        List<Double> allTimestamps = new ArrayList<>();
        List<Double> allSamples = new ArrayList<>();
        int totalSamples = 0;
        int chunkIndex = 0;
        boolean hasMore = true;
        
        while (hasMore) {
            ChunkedSignalData chunked = readSignalChunk(fileId, signalName, chunkIndex, chunkSize);
            SignalData data = chunked.getData();
            ChunkInfo info = chunked.getChunkInfo();
            
            if (data.getTimestamps() != null) {
                allTimestamps.addAll(data.getTimestamps());
            }
            if (data.getSamples() != null) {
                allSamples.addAll(data.getSamples());
            }
            
            if (info != null) {
                totalSamples = info.getTotalSamples();
                if (callback != null) {
                    callback.onProgress(info.getProgress(), chunkIndex + 1, info.getTotalChunks());
                }
            }
            
            hasMore = chunked.hasMore();
            chunkIndex++;
        }
        
        SignalData result = new SignalData();
        result.setTimestamps(allTimestamps);
        result.setSamples(allSamples);
        result.setStartIndex(0);
        result.setEndIndex(allTimestamps.size());
        result.setTotalSamples(totalSamples);
        
        return result;
    }
    
    /**
     * 读取完整信号（无回调）
     */
    public SignalData readSignalComplete(String fileId, String signalName, int chunkSize) 
            throws IOException, TimeoutException {
        return readSignalComplete(fileId, signalName, chunkSize, null);
    }
    
    // ==================== 信号写入 ====================
    
    /**
     * 写入信号
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param timestamps 时间戳数组
     * @param samples 采样值数组
     * @param unit 单位
     * @param comment 注释
     * @param overwrite 是否覆盖同名信号
     * @throws IOException 写入失败
     */
    public synchronized void writeSignal(String fileId, String signalName,
                                          double[] timestamps, double[] samples,
                                          String unit, String comment, boolean overwrite) 
            throws IOException, TimeoutException {
        Request request = Request.writeSignal(fileId, signalName, timestamps, samples, 
                                               unit, comment, overwrite);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to write signal: " + response.getErrorMessage());
        }
    }
    
    /**
     * 写入信号（简化版）
     */
    public void writeSignal(String fileId, String signalName,
                            double[] timestamps, double[] samples) 
            throws IOException, TimeoutException {
        writeSignal(fileId, signalName, timestamps, samples, "", "", false);
    }
    
    /**
     * 追加数据到现有信号
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @param timestamps 时间戳数组
     * @param samples 采样值数组
     * @throws IOException 追加失败
     */
    public synchronized void appendSignal(String fileId, String signalName,
                                           double[] timestamps, double[] samples) 
            throws IOException, TimeoutException {
        Request request = Request.appendSignal(fileId, signalName, timestamps, samples);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to append signal: " + response.getErrorMessage());
        }
    }
    
    /**
     * 删除信号
     * 
     * @param fileId 文件ID
     * @param signalName 信号名称
     * @throws IOException 删除失败
     */
    public synchronized void deleteSignal(String fileId, String signalName) 
            throws IOException, TimeoutException {
        Request request = Request.deleteSignal(fileId, signalName);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to delete signal: " + response.getErrorMessage());
        }
    }
    
    // ==================== 信号列表 ====================
    
    /**
     * 列出文件中的所有信号
     * 
     * @param fileId 文件ID
     * @return 信号名称列表
     * @throws IOException 获取失败
     */
    @SuppressWarnings("unchecked")
    public synchronized List<String> listSignals(String fileId) 
            throws IOException, TimeoutException {
        Request request = Request.listSignals(fileId);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to list signals: " + response.getErrorMessage());
        }
        
        Map<String, Object> data = response.getDataAsMap();
        return (List<String>) data.get("signals");
    }
    
    /**
     * 列出通道组
     * 
     * @param fileId 文件ID
     * @return 通道组信息列表
     * @throws IOException 获取失败
     */
    @SuppressWarnings("unchecked")
    public synchronized List<Map<String, Object>> listChannelGroups(String fileId) 
            throws IOException, TimeoutException {
        Request request = Request.listChannelGroups(fileId);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to list channel groups: " + response.getErrorMessage());
        }
        
        Map<String, Object> data = response.getDataAsMap();
        return (List<Map<String, Object>>) data.get("channel_groups");
    }
    
    // ==================== 元数据 ====================
    
    /**
     * 获取文件元数据
     * 
     * @param fileId 文件ID
     * @return 元数据字典
     * @throws IOException 获取失败
     */
    public synchronized Map<String, Object> getMetadata(String fileId) 
            throws IOException, TimeoutException {
        Request request = Request.getMetadata(fileId);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to get metadata: " + response.getErrorMessage());
        }
        
        return response.getDataAsMap();
    }
    
    // ==================== 系统操作 ====================
    
    /**
     * 发送ping请求
     * 
     * @return 是否成功
     */
    public synchronized boolean ping() {
        try {
            return socketClient.ping();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 获取服务器状态
     * 
     * @return 状态信息
     * @throws IOException 获取失败
     */
    public synchronized Map<String, Object> getStatus() 
            throws IOException, TimeoutException {
        Request request = Request.getStatus();
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to get status: " + response.getErrorMessage());
        }
        
        return response.getDataAsMap();
    }
    
    /**
     * 关闭Python服务
     * 
     * @throws IOException 关闭失败
     */
    public synchronized void shutdownServer() throws IOException, TimeoutException {
        Request request = Request.shutdown();
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new IOException("Failed to shutdown server: " + response.getErrorMessage());
        }
    }
    
    // ==================== 内部类 ====================
    
    /**
     * 分段信号数据封装
     */
    public static class ChunkedSignalData {
        private final SignalData data;
        private final ChunkInfo chunkInfo;
        private final boolean hasMore;
        
        public ChunkedSignalData(SignalData data, ChunkInfo chunkInfo, boolean hasMore) {
            this.data = data;
            this.chunkInfo = chunkInfo;
            this.hasMore = hasMore;
        }
        
        public SignalData getData() {
            return data;
        }
        
        public ChunkInfo getChunkInfo() {
            return chunkInfo;
        }
        
        public boolean hasMore() {
            return hasMore;
        }
    }
    
    /**
     * 进度回调接口
     */
    public interface ProgressCallback {
        void onProgress(double progress, int currentChunk, int totalChunks);
    }
}
