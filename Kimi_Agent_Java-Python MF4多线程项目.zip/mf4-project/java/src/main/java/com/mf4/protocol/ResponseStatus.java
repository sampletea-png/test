package com.mf4.protocol;

/**
 * 响应状态枚举
 */
public enum ResponseStatus {
    SUCCESS("success"),
    ERROR("error"),
    PARTIAL("partial");  // 用于分段读取
    
    private final String value;
    
    ResponseStatus(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
    
    public static ResponseStatus fromValue(String value) {
        for (ResponseStatus status : values()) {
            if (status.value.equals(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown response status: " + value);
    }
}
