package com.mf4.protocol;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 请求类 - Java端发送给Python端的请求
 * 
 * 属性说明：
 * - requestId: 请求唯一标识（用于多线程匹配）
 * - requestType: 请求类型
 * - fileId: 文件标识（可选）
 * - parameters: 请求参数
 * - comment: 请求注释/描述
 */
public class Request {
    
    @SerializedName("request_id")
    private String requestId;
    
    @SerializedName("request_type")
    private String requestType;
    
    @SerializedName("file_id")
    private String fileId;
    
    @SerializedName("parameters")
    private Map<String, Object> parameters;
    
    @SerializedName("comment")
    private String comment;
    
    private static final Gson gson = new Gson();
    
    // 私有构造函数，使用Builder模式
    private Request(Builder builder) {
        this.requestId = builder.requestId;
        this.requestType = builder.requestType;
        this.fileId = builder.fileId;
        this.parameters = builder.parameters;
        this.comment = builder.comment;
    }
    
    // 默认构造函数（用于反序列化）
    public Request() {
        this.parameters = new HashMap<>();
    }
    
    // Getters
    public String getRequestId() {
        return requestId;
    }
    
    public String getRequestType() {
        return requestType;
    }
    
    public String getFileId() {
        return fileId;
    }
    
    public Map<String, Object> getParameters() {
        return parameters;
    }
    
    public String getComment() {
        return comment;
    }
    
    // Setters（用于反序列化）
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    
    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    /**
     * 序列化为JSON字符串
     */
    public String toJson() {
        return gson.toJson(this);
    }
    
    /**
     * 从JSON字符串反序列化
     */
    public static Request fromJson(String json) {
        return gson.fromJson(json, Request.class);
    }
    
    /**
     * 添加参数
     */
    public void addParameter(String key, Object value) {
        if (this.parameters == null) {
            this.parameters = new HashMap<>();
        }
        this.parameters.put(key, value);
    }
    
    @Override
    public String toString() {
        return "Request{" +
                "requestId='" + requestId + '\'' +
                ", requestType='" + requestType + '\'' +
                ", fileId='" + fileId + '\'' +
                ", comment='" + comment + '\'' +
                '}';
    }
    
    /**
     * Builder类
     */
    public static class Builder {
        private String requestId;
        private String requestType;
        private String fileId;
        private Map<String, Object> parameters;
        private String comment;
        
        public Builder() {
            // 自动生成请求ID
            this.requestId = UUID.randomUUID().toString();
            this.parameters = new HashMap<>();
            this.comment = "";
        }
        
        public Builder requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }
        
        public Builder requestType(RequestType requestType) {
            this.requestType = requestType.getValue();
            return this;
        }
        
        public Builder requestType(String requestType) {
            this.requestType = requestType;
            return this;
        }
        
        public Builder fileId(String fileId) {
            this.fileId = fileId;
            return this;
        }
        
        public Builder parameters(Map<String, Object> parameters) {
            this.parameters = new HashMap<>(parameters);
            return this;
        }
        
        public Builder addParameter(String key, Object value) {
            this.parameters.put(key, value);
            return this;
        }
        
        public Builder comment(String comment) {
            this.comment = comment;
            return this;
        }
        
        public Request build() {
            if (requestType == null || requestType.isEmpty()) {
                throw new IllegalStateException("requestType is required");
            }
            return new Request(this);
        }
    }
    
    // 便捷工厂方法
    
    /**
     * 创建打开文件请求
     */
    public static Request openFile(String filePath, String mode, boolean createIfNotExists) {
        return new Builder()
                .requestType(RequestType.OPEN_FILE)
                .addParameter("file_path", filePath)
                .addParameter("mode", mode)
                .addParameter("create_if_not_exists", createIfNotExists)
                .comment("Open file: " + filePath)
                .build();
    }
    
    /**
     * 创建创建文件请求
     */
    public static Request createFile(String filePath, boolean overwrite) {
        return new Builder()
                .requestType(RequestType.CREATE_FILE)
                .addParameter("file_path", filePath)
                .addParameter("overwrite", overwrite)
                .comment("Create file: " + filePath + ", overwrite=" + overwrite)
                .build();
    }
    
    /**
     * 创建关闭文件请求
     */
    public static Request closeFile(String fileId) {
        return new Builder()
                .requestType(RequestType.CLOSE_FILE)
                .fileId(fileId)
                .comment("Close file: " + fileId)
                .build();
    }
    
    /**
     * 创建保存文件请求
     */
    public static Request saveFile(String fileId, boolean overwrite) {
        return new Builder()
                .requestType(RequestType.SAVE_FILE)
                .fileId(fileId)
                .addParameter("overwrite", overwrite)
                .comment("Save file: " + fileId + ", overwrite=" + overwrite)
                .build();
    }
    
    /**
     * 创建读取信号请求
     */
    public static Request readSignal(String fileId, String signalName, int startIndex, Integer endIndex) {
        Builder builder = new Builder()
                .requestType(RequestType.READ_SIGNAL)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .addParameter("start_index", startIndex)
                .comment("Read signal: " + signalName);
        if (endIndex != null) {
            builder.addParameter("end_index", endIndex);
        }
        return builder.build();
    }
    
    /**
     * 创建分段读取信号请求
     */
    public static Request readSignalChunk(String fileId, String signalName, int chunkIndex, Integer chunkSize) {
        Builder builder = new Builder()
                .requestType(RequestType.READ_SIGNAL_CHUNK)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .addParameter("chunk_index", chunkIndex)
                .comment("Read signal chunk: " + signalName + ", chunk=" + chunkIndex);
        if (chunkSize != null) {
            builder.addParameter("chunk_size", chunkSize);
        }
        return builder.build();
    }
    
    /**
     * 创建写入信号请求
     */
    public static Request writeSignal(String fileId, String signalName, 
                                       double[] timestamps, double[] samples,
                                       String unit, String comment, boolean overwrite) {
        return new Builder()
                .requestType(RequestType.WRITE_SIGNAL)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .addParameter("timestamps", timestamps)
                .addParameter("samples", samples)
                .addParameter("unit", unit != null ? unit : "")
                .addParameter("comment", comment != null ? comment : "")
                .addParameter("overwrite", overwrite)
                .comment("Write signal: " + signalName + ", samples=" + samples.length + ", overwrite=" + overwrite)
                .build();
    }
    
    /**
     * 创建追加信号请求
     */
    public static Request appendSignal(String fileId, String signalName,
                                        double[] timestamps, double[] samples) {
        return new Builder()
                .requestType(RequestType.APPEND_SIGNAL)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .addParameter("timestamps", timestamps)
                .addParameter("samples", samples)
                .comment("Append signal: " + signalName + ", samples=" + samples.length)
                .build();
    }
    
    /**
     * 创建获取信号信息请求
     */
    public static Request getSignalInfo(String fileId, String signalName) {
        return new Builder()
                .requestType(RequestType.GET_SIGNAL_INFO)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .comment("Get signal info: " + signalName)
                .build();
    }
    
    /**
     * 创建列出信号请求
     */
    public static Request listSignals(String fileId) {
        return new Builder()
                .requestType(RequestType.LIST_SIGNALS)
                .fileId(fileId)
                .comment("List signals for file: " + fileId)
                .build();
    }
    
    /**
     * 创建删除信号请求
     */
    public static Request deleteSignal(String fileId, String signalName) {
        return new Builder()
                .requestType(RequestType.DELETE_SIGNAL)
                .fileId(fileId)
                .addParameter("signal_name", signalName)
                .comment("Delete signal: " + signalName)
                .build();
    }
    
    /**
     * 创建列出通道组请求
     */
    public static Request listChannelGroups(String fileId) {
        return new Builder()
                .requestType(RequestType.LIST_CHANNEL_GROUPS)
                .fileId(fileId)
                .comment("List channel groups for file: " + fileId)
                .build();
    }
    
    /**
     * 创建获取元数据请求
     */
    public static Request getMetadata(String fileId) {
        return new Builder()
                .requestType(RequestType.GET_METADATA)
                .fileId(fileId)
                .comment("Get metadata for file: " + fileId)
                .build();
    }
    
    /**
     * 创建ping请求
     */
    public static Request ping() {
        return new Builder()
                .requestType(RequestType.PING)
                .comment("Ping server")
                .build();
    }
    
    /**
     * 创建关闭服务请求
     */
    public static Request shutdown() {
        return new Builder()
                .requestType(RequestType.SHUTDOWN)
                .comment("Shutdown server")
                .build();
    }
    
    /**
     * 创建获取状态请求
     */
    public static Request getStatus() {
        return new Builder()
                .requestType(RequestType.GET_STATUS)
                .comment("Get server status")
                .build();
    }
}
