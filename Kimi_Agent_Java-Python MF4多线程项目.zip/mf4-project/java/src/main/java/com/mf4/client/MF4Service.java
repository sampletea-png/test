package com.mf4.client;

import com.mf4.process.PythonProcessManager;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;

/**
 * MF4服务 - 完整的生命周期管理
 * 
 * 整合Python进程管理和Socket客户端，提供：
 * - 自动启动Python服务
 * - 连接管理
 * - 优雅关闭
 * - 异常时自动清理
 */
public class MF4Service {
    
    private static final String DEFAULT_HOST = "127.0.0.1";
    private static final int DEFAULT_PORT = 8765;
    private static final int DEFAULT_TIMEOUT_MS = 30000;
    private static final int CONNECTION_RETRY_COUNT = 3;
    private static final long CONNECTION_RETRY_DELAY_MS = 1000;
    
    private final String host;
    private final int port;
    private final int timeoutMs;
    
    private PythonProcessManager processManager;
    private MF4Client client;
    
    private final boolean autoStartPython;
    private final String pythonScriptPath;
    private final String[] pythonArgs;
    
    private volatile boolean initialized = false;
    
    // 回调
    private Consumer<String> onPythonOutput;
    private Consumer<String> onPythonError;
    
    /**
     * Builder类
     */
    public static class Builder {
        private String host = DEFAULT_HOST;
        private int port = DEFAULT_PORT;
        private int timeoutMs = DEFAULT_TIMEOUT_MS;
        private boolean autoStartPython = true;
        private String pythonScriptPath;
        private String[] pythonArgs = new String[0];
        private Consumer<String> onPythonOutput;
        private Consumer<String> onPythonError;
        
        public Builder host(String host) {
            this.host = host;
            return this;
        }
        
        public Builder port(int port) {
            this.port = port;
            return this;
        }
        
        public Builder timeoutMs(int timeoutMs) {
            this.timeoutMs = timeoutMs;
            return this;
        }
        
        public Builder autoStartPython(boolean autoStartPython) {
            this.autoStartPython = autoStartPython;
            return this;
        }
        
        public Builder pythonScriptPath(String pythonScriptPath) {
            this.pythonScriptPath = pythonScriptPath;
            return this;
        }
        
        public Builder pythonArgs(String... pythonArgs) {
            this.pythonArgs = pythonArgs;
            return this;
        }
        
        public Builder onPythonOutput(Consumer<String> onPythonOutput) {
            this.onPythonOutput = onPythonOutput;
            return this;
        }
        
        public Builder onPythonError(Consumer<String> onPythonError) {
            this.onPythonError = onPythonError;
            return this;
        }
        
        public MF4Service build() {
            return new MF4Service(this);
        }
    }
    
    private MF4Service(Builder builder) {
        this.host = builder.host;
        this.port = builder.port;
        this.timeoutMs = builder.timeoutMs;
        this.autoStartPython = builder.autoStartPython;
        this.pythonScriptPath = builder.pythonScriptPath;
        this.pythonArgs = builder.pythonArgs;
        this.onPythonOutput = builder.onPythonOutput;
        this.onPythonError = builder.onPythonError;
    }
    
    /**
     * 初始化服务
     * 
     * 如果配置了自动启动Python，会先启动Python进程
     * 然后建立Socket连接
     * 
     * @throws IOException 初始化失败
     * @throws TimeoutException 超时
     */
    public synchronized void initialize() throws IOException, TimeoutException, InterruptedException {
        if (initialized) {
            return;
        }
        
        try {
            // 1. 启动Python进程（如果需要）
            if (autoStartPython) {
                startPythonProcess();
            }
            
            // 2. 创建客户端并连接
            connectClient();
            
            initialized = true;
            System.out.println("MF4Service initialized successfully");
            
        } catch (Exception e) {
            // 初始化失败，清理资源
            shutdown();
            throw e;
        }
    }
    
    /**
     * 启动Python进程
     */
    private void startPythonProcess() throws IOException, TimeoutException, InterruptedException {
        if (pythonScriptPath == null || pythonScriptPath.isEmpty()) {
            // 尝试自动检测脚本路径
            String detectedPath = detectPythonScriptPath();
            if (detectedPath == null) {
                throw new IllegalStateException("pythonScriptPath is required when autoStartPython is true");
            }
        }
        
        // 构建参数
        String[] args = new String[pythonArgs.length + 2];
        args[0] = "--host";
        args[1] = host;
        args[2] = "--port";
        args[3] = String.valueOf(port);
        System.arraycopy(pythonArgs, 0, args, 4, pythonArgs.length);
        
        // 创建进程管理器
        processManager = PythonProcessManager.builder()
                .pythonExecutable(PythonProcessManager.detectPythonExecutable())
                .scriptPath(pythonScriptPath)
                .args(args)
                .onOutput(line -> {
                    if (onPythonOutput != null) {
                        onPythonOutput.accept(line);
                    }
                })
                .onError(line -> {
                    if (onPythonError != null) {
                        onPythonError.accept(line);
                    }
                })
                .onExit(exitCode -> {
                    System.err.println("Python process exited with code: " + exitCode);
                    initialized = false;
                })
                .build();
        
        // 启动进程
        boolean started = processManager.start();
        if (!started) {
            throw new IOException("Failed to start Python process");
        }
        
        // 等待服务启动
        Thread.sleep(2000);
    }
    
    /**
     * 连接客户端
     */
    private void connectClient() throws IOException, TimeoutException {
        client = new MF4Client(host, port, timeoutMs);
        
        // 重试连接
        IOException lastException = null;
        for (int i = 0; i < CONNECTION_RETRY_COUNT; i++) {
            try {
                if (client.connect()) {
                    // 验证连接
                    if (client.ping()) {
                        return;
                    }
                }
            } catch (IOException e) {
                lastException = e;
                if (i < CONNECTION_RETRY_COUNT - 1) {
                    try {
                        Thread.sleep(CONNECTION_RETRY_DELAY_MS);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new IOException("Interrupted while connecting", ie);
                    }
                }
            }
        }
        
        throw lastException != null ? lastException : new IOException("Failed to connect to MF4 server");
    }
    
    /**
     * 自动检测Python脚本路径
     */
    private String detectPythonScriptPath() {
        // 尝试常见路径
        String[] possiblePaths = {
            "python/main.py",
            "../python/main.py",
            "../../python/main.py",
            "mf4-python/main.py"
        };
        
        for (String path : possiblePaths) {
            if (Paths.get(path).toFile().exists()) {
                return path;
            }
        }
        
        return null;
    }
    
    /**
     * 获取MF4客户端
     * 
     * @return MF4Client实例
     * @throws IllegalStateException 如果服务未初始化
     */
    public MF4Client getClient() {
        if (!initialized || client == null) {
            throw new IllegalStateException("MF4Service is not initialized. Call initialize() first.");
        }
        return client;
    }
    
    /**
     * 检查是否已初始化
     */
    public boolean isInitialized() {
        return initialized && client != null && client.isConnected();
    }
    
    /**
     * 检查Python进程是否运行
     */
    public boolean isPythonRunning() {
        return processManager != null && processManager.isRunning();
    }
    
    /**
     * 关闭服务
     * 
     * 优雅关闭：
     * 1. 关闭Socket连接
     * 2. 停止Python进程
     */
    public synchronized void shutdown() {
        System.out.println("Shutting down MF4Service...");
        initialized = false;
        
        // 关闭客户端
        if (client != null) {
            try {
                client.close();
            } catch (Exception e) {
                System.err.println("Error closing client: " + e.getMessage());
            }
            client = null;
        }
        
        // 停止Python进程
        if (processManager != null) {
            try {
                processManager.stop();
            } catch (Exception e) {
                System.err.println("Error stopping Python process: " + e.getMessage());
            }
            processManager = null;
        }
        
        System.out.println("MF4Service shutdown complete");
    }
    
    /**
     * 便捷工厂方法
     */
    public static Builder builder() {
        return new Builder();
    }
    
    /**
     * 创建默认配置的服务
     * 
     * @param pythonScriptPath Python脚本路径
     * @return MF4Service实例
     */
    public static MF4Service createDefault(String pythonScriptPath) {
        return builder()
                .pythonScriptPath(pythonScriptPath)
                .build();
    }
    
    /**
     * 创建连接到已有服务的服务（不启动Python）
     * 
     * @param host Python服务地址
     * @param port Python服务端口
     * @return MF4Service实例
     */
    public static MF4Service createForExistingServer(String host, int port) {
        return builder()
                .host(host)
                .port(port)
                .autoStartPython(false)
                .build();
    }
}
