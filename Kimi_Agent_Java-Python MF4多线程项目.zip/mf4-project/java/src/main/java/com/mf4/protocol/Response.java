package com.mf4.protocol;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Map;

/**
 * 响应类 - Python端返回给Java端的响应
 * 
 * 属性说明：
 * - requestId: 对应请求的ID
 * - status: 响应状态
 * - data: 响应数据
 * - errorMessage: 错误信息（当status为error时）
 * - hasMore: 是否还有更多数据（用于分段读取）
 * - chunkInfo: 分段信息
 * - comment: 响应注释/描述
 */
public class Response {
    
    @SerializedName("request_id")
    private String requestId;
    
    @SerializedName("status")
    private String status;
    
    @SerializedName("data")
    private Object data;
    
    @SerializedName("error_message")
    private String errorMessage;
    
    @SerializedName("has_more")
    private boolean hasMore;
    
    @SerializedName("chunk_info")
    private Map<String, Object> chunkInfo;
    
    @SerializedName("comment")
    private String comment;
    
    private static final Gson gson = new Gson();
    
    // 默认构造函数
    public Response() {
    }
    
    // Getters
    public String getRequestId() {
        return requestId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public Object getData() {
        return data;
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
    
    public boolean isHasMore() {
        return hasMore;
    }
    
    public Map<String, Object> getChunkInfo() {
        return chunkInfo;
    }
    
    public String getComment() {
        return comment;
    }
    
    // Setters
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public void setData(Object data) {
        this.data = data;
    }
    
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
    
    public void setChunkInfo(Map<String, Object> chunkInfo) {
        this.chunkInfo = chunkInfo;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    /**
     * 序列化为JSON字符串
     */
    public String toJson() {
        return gson.toJson(this);
    }
    
    /**
     * 从JSON字符串反序列化
     */
    public static Response fromJson(String json) {
        return gson.fromJson(json, Response.class);
    }
    
    /**
     * 检查响应是否成功
     */
    public boolean isSuccess() {
        return ResponseStatus.SUCCESS.getValue().equals(status) ||
               ResponseStatus.PARTIAL.getValue().equals(status);
    }
    
    /**
     * 检查响应是否为部分数据（分段读取）
     */
    public boolean isPartial() {
        return ResponseStatus.PARTIAL.getValue().equals(status);
    }
    
    /**
     * 获取数据为指定类型
     */
    public <T> T getDataAs(Class<T> clazz) {
        if (data == null) {
            return null;
        }
        return gson.fromJson(gson.toJson(data), clazz);
    }
    
    /**
     * 获取数据为Map类型
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getDataAsMap() {
        if (data == null) {
            return null;
        }
        Type type = new TypeToken<Map<String, Object>>(){}.getType();
        return gson.fromJson(gson.toJson(data), type);
    }
    
    @Override
    public String toString() {
        return "Response{" +
                "requestId='" + requestId + '\'' +
                ", status='" + status + '\'' +
                ", hasMore=" + hasMore +
                ", errorMessage='" + errorMessage + '\'' +
                ", comment='" + comment + '\'' +
                '}';
    }
    
    // 便捷工厂方法
    
    /**
     * 创建成功响应
     */
    public static Response success(String requestId, Object data, String comment) {
        Response response = new Response();
        response.setRequestId(requestId);
        response.setStatus(ResponseStatus.SUCCESS.getValue());
        response.setData(data);
        response.setComment(comment);
        return response;
    }
    
    /**
     * 创建错误响应
     */
    public static Response error(String requestId, String errorMessage, String comment) {
        Response response = new Response();
        response.setRequestId(requestId);
        response.setStatus(ResponseStatus.ERROR.getValue());
        response.setErrorMessage(errorMessage);
        response.setComment(comment);
        return response;
    }
    
    /**
     * 创建部分数据响应（用于分段读取）
     */
    public static Response partial(String requestId, Object data, 
                                    Map<String, Object> chunkInfo, boolean hasMore, String comment) {
        Response response = new Response();
        response.setRequestId(requestId);
        response.setStatus(ResponseStatus.PARTIAL.getValue());
        response.setData(data);
        response.setChunkInfo(chunkInfo);
        response.setHasMore(hasMore);
        response.setComment(comment);
        return response;
    }
}
