package com.mf4;

import com.mf4.client.MF4Client;
import com.mf4.client.MF4Service;
import com.mf4.model.SignalData;
import com.mf4.model.SignalInfo;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MF4客户端测试类
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MF4ClientTest {
    
    private static MF4Service service;
    private static MF4Client client;
    private static String pythonScriptPath = "../python/main.py";
    
    @TempDir
    static Path tempDir;
    
    @BeforeAll
    static void setUp() throws Exception {
        // 启动服务
        service = MF4Service.builder()
                .pythonScriptPath(pythonScriptPath)
                .port(8766)  // 使用不同端口避免冲突
                .build();
        
        service.initialize();
        client = service.getClient();
    }
    
    @AfterAll
    static void tearDown() {
        if (service != null) {
            service.shutdown();
        }
    }
    
    @Test
    @Order(1)
    @DisplayName("测试连接")
    void testConnection() {
        assertTrue(client.isConnected());
        assertTrue(client.ping());
    }
    
    @Test
    @Order(2)
    @DisplayName("测试创建文件")
    void testCreateFile() throws Exception {
        String filePath = tempDir.resolve("test_create.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        assertNotNull(fileId);
        assertFalse(fileId.isEmpty());
        
        // 清理
        client.closeFile(fileId);
    }
    
    @Test
    @Order(3)
    @DisplayName("测试打开文件")
    void testOpenFile() throws Exception {
        // 先创建文件
        String filePath = tempDir.resolve("test_open.mf4").toString();
        String createId = client.createFile(filePath, true);
        client.closeFile(createId);
        
        // 再打开
        String fileId = client.openFile(filePath, "r", false);
        assertNotNull(fileId);
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(4)
    @DisplayName("测试写入和读取信号")
    void testWriteAndReadSignal() throws Exception {
        String filePath = tempDir.resolve("test_signal.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        // 写入信号
        double[] timestamps = {0.0, 0.1, 0.2, 0.3, 0.4};
        double[] samples = {1.0, 2.0, 3.0, 4.0, 5.0};
        
        client.writeSignal(fileId, "TestSignal", timestamps, samples, "V", "Test", false);
        
        // 读取信号
        SignalData data = client.readSignal(fileId, "TestSignal");
        
        assertNotNull(data);
        assertEquals(5, data.getLength());
        assertEquals(5, data.getTotalSamples());
        
        // 验证数据
        List<Double> readTimestamps = data.getTimestamps();
        List<Double> readSamples = data.getSamples();
        
        for (int i = 0; i < 5; i++) {
            assertEquals(timestamps[i], readTimestamps.get(i), 0.001);
            assertEquals(samples[i], readSamples.get(i), 0.001);
        }
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(5)
    @DisplayName("测试追加信号")
    void testAppendSignal() throws Exception {
        String filePath = tempDir.resolve("test_append.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        // 写入初始数据
        double[] timestamps1 = {0.0, 0.1, 0.2};
        double[] samples1 = {1.0, 2.0, 3.0};
        client.writeSignal(fileId, "AppendSignal", timestamps1, samples1, "V", "", false);
        
        // 追加数据
        double[] timestamps2 = {0.3, 0.4, 0.5};
        double[] samples2 = {4.0, 5.0, 6.0};
        client.appendSignal(fileId, "AppendSignal", timestamps2, samples2);
        
        // 读取验证
        SignalData data = client.readSignal(fileId, "AppendSignal");
        assertEquals(6, data.getLength());
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(6)
    @DisplayName("测试获取信号信息")
    void testGetSignalInfo() throws Exception {
        String filePath = tempDir.resolve("test_info.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        double[] timestamps = {0.0, 0.1, 0.2, 0.3, 0.4};
        double[] samples = {10.0, 20.0, 30.0, 40.0, 50.0};
        
        client.writeSignal(fileId, "InfoSignal", timestamps, samples, "m/s", "Velocity", false);
        
        SignalInfo info = client.getSignalInfo(fileId, "InfoSignal");
        
        assertNotNull(info);
        assertEquals("InfoSignal", info.getName());
        assertEquals("m/s", info.getUnit());
        assertEquals(5, info.getSampleCount());
        assertEquals(0.0, info.getMinValue(), 0.001);
        assertEquals(50.0, info.getMaxValue(), 0.001);
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(7)
    @DisplayName("测试列出信号")
    void testListSignals() throws Exception {
        String filePath = tempDir.resolve("test_list.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        // 写入多个信号
        double[] timestamps = {0.0, 0.1, 0.2};
        client.writeSignal(fileId, "Signal1", timestamps, new double[]{1, 2, 3}, "", "", false);
        client.writeSignal(fileId, "Signal2", timestamps, new double[]{4, 5, 6}, "", "", false);
        client.writeSignal(fileId, "Signal3", timestamps, new double[]{7, 8, 9}, "", "", false);
        
        List<String> signals = client.listSignals(fileId);
        
        assertNotNull(signals);
        assertEquals(3, signals.size());
        assertTrue(signals.contains("Signal1"));
        assertTrue(signals.contains("Signal2"));
        assertTrue(signals.contains("Signal3"));
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(8)
    @DisplayName("测试删除信号")
    void testDeleteSignal() throws Exception {
        String filePath = tempDir.resolve("test_delete.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        double[] timestamps = {0.0, 0.1, 0.2};
        client.writeSignal(fileId, "ToDelete", timestamps, new double[]{1, 2, 3}, "", "", false);
        
        List<String> signalsBefore = client.listSignals(fileId);
        assertEquals(1, signalsBefore.size());
        
        client.deleteSignal(fileId, "ToDelete");
        
        List<String> signalsAfter = client.listSignals(fileId);
        assertEquals(0, signalsAfter.size());
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(9)
    @DisplayName("测试分段读取")
    void testChunkedReading() throws Exception {
        String filePath = tempDir.resolve("test_chunk.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        // 写入大量数据
        int numSamples = 10000;
        double[] timestamps = new double[numSamples];
        double[] samples = new double[numSamples];
        
        for (int i = 0; i < numSamples; i++) {
            timestamps[i] = i * 0.001;
            samples[i] = Math.sin(i * 0.01);
        }
        
        client.writeSignal(fileId, "ChunkSignal", timestamps, samples, "", "", false);
        
        // 分段读取
        int chunkSize = 1000;
        int chunkIndex = 0;
        int totalRead = 0;
        
        while (true) {
            MF4Client.ChunkedSignalData chunked = client.readSignalChunk(
                    fileId, "ChunkSignal", chunkIndex, chunkSize);
            
            SignalData data = chunked.getData();
            totalRead += data.getLength();
            
            if (!chunked.hasMore()) {
                break;
            }
            chunkIndex++;
        }
        
        assertEquals(numSamples, totalRead);
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(10)
    @DisplayName("测试多线程并发")
    void testMultiThreading() throws Exception {
        String filePath = tempDir.resolve("test_multi.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        int numThreads = 5;
        int samplesPerThread = 100;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        CountDownLatch latch = new CountDownLatch(numThreads);
        
        for (int i = 0; i < numThreads; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    String signalName = "ThreadSignal_" + threadId;
                    double[] timestamps = new double[samplesPerThread];
                    double[] samples = new double[samplesPerThread];
                    
                    for (int j = 0; j < samplesPerThread; j++) {
                        timestamps[j] = j * 0.01;
                        samples[j] = threadId * 100 + j;
                    }
                    
                    client.writeSignal(fileId, signalName, timestamps, samples, "", "", false);
                    
                } catch (Exception e) {
                    fail("Thread " + threadId + " failed: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }
        
        assertTrue(latch.await(30, TimeUnit.SECONDS));
        executor.shutdown();
        
        // 验证所有信号都已写入
        List<String> signals = client.listSignals(fileId);
        assertEquals(numThreads, signals.size());
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(11)
    @DisplayName("测试获取服务器状态")
    void testGetStatus() throws Exception {
        Map<String, Object> status = client.getStatus();
        
        assertNotNull(status);
        assertTrue(status.containsKey("open_files"));
        assertTrue(status.containsKey("memory_usage_mb"));
    }
    
    @Test
    @Order(12)
    @DisplayName("测试信号覆盖")
    void testSignalOverwrite() throws Exception {
        String filePath = tempDir.resolve("test_overwrite.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        double[] timestamps1 = {0.0, 0.1, 0.2};
        double[] samples1 = {1.0, 2.0, 3.0};
        client.writeSignal(fileId, "OverwriteSignal", timestamps1, samples1, "", "", false);
        
        // 覆盖信号
        double[] timestamps2 = {0.0, 0.1};
        double[] samples2 = {10.0, 20.0};
        client.writeSignal(fileId, "OverwriteSignal", timestamps2, samples2, "V", "New", true);
        
        SignalData data = client.readSignal(fileId, "OverwriteSignal");
        assertEquals(2, data.getLength());
        
        SignalInfo info = client.getSignalInfo(fileId, "OverwriteSignal");
        assertEquals("V", info.getUnit());
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(13)
    @DisplayName("测试保存文件")
    void testSaveFile() throws Exception {
        String filePath = tempDir.resolve("test_save.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        double[] timestamps = {0.0, 0.1, 0.2};
        client.writeSignal(fileId, "SaveSignal", timestamps, new double[]{1, 2, 3}, "", "", false);
        
        String savedPath = client.saveFile(fileId, true);
        assertNotNull(savedPath);
        
        client.closeFile(fileId);
    }
    
    @Test
    @Order(14)
    @DisplayName("测试元数据")
    void testMetadata() throws Exception {
        String filePath = tempDir.resolve("test_meta.mf4").toString();
        String fileId = client.createFile(filePath, true);
        
        Map<String, Object> metadata = client.getMetadata(fileId);
        
        assertNotNull(metadata);
        assertTrue(metadata.containsKey("version"));
        assertTrue(metadata.containsKey("channel_group_count"));
        
        client.closeFile(fileId);
    }
}
