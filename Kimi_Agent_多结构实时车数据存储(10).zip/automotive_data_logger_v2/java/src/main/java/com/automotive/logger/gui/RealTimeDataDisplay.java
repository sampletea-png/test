package com.automotive.logger.gui;

import com.automotive.logger.model.VehicleData;
import com.automotive.logger.service.DataLoggerService;
import com.automotive.logger.service.DataSimulatorService;
import com.automotive.logger.storage.StorageFactory;
import com.automotive.logger.storage.StorageInterface;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 实时数据显示弹窗 - Java为主架构
 * 展示车辆数据的实时变化，支持多种存储格式
 */
public class RealTimeDataDisplay extends JFrame {
    
    private final DataSimulatorService dataSimulator;
    private final DataLoggerService dataLogger;
    private final ScheduledExecutorService uiUpdater;
    private final AtomicBoolean isRecording;
    
    // UI组件
    private JLabel statusLabel;
    private JLabel recordTimeLabel;
    private JLabel dataCountLabel;
    private JLabel writeRateLabel;
    private JLabel formatLabel;
    private JLabel fileSizeLabel;
    
    // 数据展示标签
    private JLabel speedValueLabel;
    private JLabel rpmValueLabel;
    private JLabel tempValueLabel;
    private JLabel throttleValueLabel;
    private JLabel brakeValueLabel;
    private JLabel steeringValueLabel;
    private JLabel voltageValueLabel;
    private JLabel fuelValueLabel;
    private JLabel accelXLabel;
    private JLabel accelYLabel;
    private JLabel accelZLabel;
    
    // 控制按钮
    private JButton startButton;
    private JButton stopButton;
    private JComboBox<String> formatComboBox;
    private JButton switchFormatButton;
    
    // 记录状态
    private volatile long recordStartTime = 0;
    private volatile VehicleData latestData = null;
    
    // 颜色定义
    private static final Color BG_COLOR = new Color(30, 30, 30);
    private static final Color PANEL_BG = new Color(45, 45, 45);
    private static final Color TEXT_COLOR = new Color(220, 220, 220);
    private static final Color ACCENT_COLOR = new Color(0, 150, 200);
    private static final Color RECORDING_COLOR = new Color(200, 50, 50);
    private static final Color VALUE_COLOR = new Color(100, 200, 100);
    
    public RealTimeDataDisplay() {
        this.dataSimulator = new DataSimulatorService();
        this.dataLogger = new DataLoggerService();
        this.uiUpdater = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "UI-Updater");
            t.setDaemon(true);
            return t;
        });
        this.isRecording = new AtomicBoolean(false);
        
        // 添加存储状态监听器
        dataLogger.addStatusListener(info -> {
            SwingUtilities.invokeLater(() -> {
                formatLabel.setText(info.getFormatName());
                fileSizeLabel.setText(String.format("%.2f MB", info.getFileSizeMb()));
                dataCountLabel.setText(String.valueOf(info.getRecordCount()));
                writeRateLabel.setText(String.format("%.1f 条/秒", info.getWriteRate()));
            });
        });
        
        initializeUI();
        setupDataPipeline();
    }
    
    private void initializeUI() {
        setTitle("汽车数据实时记录系统 (Java为主)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 750);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        mainPanel.add(createStatusPanel(), BorderLayout.NORTH);
        mainPanel.add(createDataPanel(), BorderLayout.CENTER);
        mainPanel.add(createControlPanel(), BorderLayout.SOUTH);
        
        setContentPane(mainPanel);
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                shutdown();
            }
        });
    }
    
    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 4, 10, 5));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("系统状态"));
        
        statusLabel = createStatusLabel("就绪", TEXT_COLOR);
        recordTimeLabel = createValueLabel("00:00:00");
        dataCountLabel = createValueLabel("0");
        writeRateLabel = createValueLabel("0.0 条/秒");
        formatLabel = createValueLabel("-");
        fileSizeLabel = createValueLabel("0.0 MB");
        
        panel.add(createInfoRow("记录状态:", statusLabel));
        panel.add(createInfoRow("记录时长:", recordTimeLabel));
        panel.add(createInfoRow("数据条数:", dataCountLabel));
        panel.add(createInfoRow("写入速率:", writeRateLabel));
        panel.add(createInfoRow("存储格式:", formatLabel));
        panel.add(createInfoRow("文件大小:", fileSizeLabel));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        
        return panel;
    }
    
    private JPanel createDataPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.setBackground(BG_COLOR);
        
        panel.add(createEnginePanel());
        panel.add(createVehicleDynamicsPanel());
        panel.add(createChassisPanel());
        panel.add(createElectricalPanel());
        
        return panel;
    }
    
    private JPanel createEnginePanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("发动机数据"));
        
        rpmValueLabel = createValueLabel("0 RPM");
        tempValueLabel = createValueLabel("0.0 °C");
        throttleValueLabel = createValueLabel("0.0 %");
        
        panel.add(createInfoRow("发动机转速:", rpmValueLabel));
        panel.add(createInfoRow("发动机温度:", tempValueLabel));
        panel.add(createInfoRow("油门位置:", throttleValueLabel));
        
        return panel;
    }
    
    private JPanel createVehicleDynamicsPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("车辆动态"));
        
        speedValueLabel = createValueLabel("0.0 km/h");
        accelXLabel = createValueLabel("0.000 m/s²");
        accelYLabel = createValueLabel("0.000 m/s²");
        accelZLabel = createValueLabel("0.000 m/s²");
        
        panel.add(createInfoRow("车速:", speedValueLabel));
        panel.add(createInfoRow("横向加速度:", accelXLabel));
        panel.add(createInfoRow("纵向加速度:", accelYLabel));
        panel.add(createInfoRow("垂直加速度:", accelZLabel));
        
        return panel;
    }
    
    private JPanel createChassisPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("底盘系统"));
        
        brakeValueLabel = createValueLabel("0.0 %");
        steeringValueLabel = createValueLabel("0.0 °");
        
        panel.add(createInfoRow("刹车踏板:", brakeValueLabel));
        panel.add(createInfoRow("方向盘角度:", steeringValueLabel));
        
        return panel;
    }
    
    private JPanel createElectricalPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("电气系统"));
        
        voltageValueLabel = createValueLabel("0.0 V");
        fuelValueLabel = createValueLabel("0.0 %");
        
        panel.add(createInfoRow("电池电压:", voltageValueLabel));
        panel.add(createInfoRow("燃油液位:", fuelValueLabel));
        
        return panel;
    }
    
    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panel.setBackground(PANEL_BG);
        panel.setBorder(createTitledBorder("控制"));
        
        startButton = createControlButton("开始记录", new Color(50, 150, 50));
        stopButton = createControlButton("停止记录", new Color(150, 50, 50));
        stopButton.setEnabled(false);
        
        startButton.addActionListener(e -> startRecording());
        stopButton.addActionListener(e -> stopRecording());
        
        panel.add(startButton);
        panel.add(stopButton);
        
        // 格式选择
        panel.add(new JLabel(" "));
        
        formatComboBox = new JComboBox<>();
        formatComboBox.setPreferredSize(new Dimension(120, 30));
        formatComboBox.setEnabled(false);
        
        // 添加可用格式
        for (String format : dataLogger.getAvailableFormats()) {
            formatComboBox.addItem(format);
        }
        
        switchFormatButton = createControlButton("切换格式", ACCENT_COLOR);
        switchFormatButton.setPreferredSize(new Dimension(100, 35));
        switchFormatButton.setEnabled(false);
        switchFormatButton.addActionListener(e -> switchFormat());
        
        panel.add(new JLabel("存储格式:"));
        panel.add(formatComboBox);
        panel.add(switchFormatButton);
        
        return panel;
    }
    
    private void switchFormat() {
        String selectedFormat = (String) formatComboBox.getSelectedItem();
        if (selectedFormat != null && !selectedFormat.equals(dataLogger.getCurrentFormat())) {
            try {
                boolean success = dataLogger.switchFormat(selectedFormat);
                if (success) {
                    JOptionPane.showMessageDialog(this,
                        "已切换到格式: " + selectedFormat,
                        "格式切换成功",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                    "格式切换失败: " + ex.getMessage(),
                    "错误",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private JPanel createInfoRow(String label, JLabel valueLabel) {
        JPanel row = new JPanel(new BorderLayout(5, 0));
        row.setBackground(PANEL_BG);
        
        JLabel nameLabel = new JLabel(label);
        nameLabel.setForeground(TEXT_COLOR);
        nameLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        
        row.add(nameLabel, BorderLayout.WEST);
        row.add(valueLabel, BorderLayout.EAST);
        
        return row;
    }
    
    private JLabel createStatusLabel(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setForeground(color);
        label.setFont(new Font("Microsoft YaHei", Font.BOLD, 12));
        return label;
    }
    
    private JLabel createValueLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(VALUE_COLOR);
        label.setFont(new Font("Consolas", Font.BOLD, 14));
        label.setHorizontalAlignment(SwingConstants.RIGHT);
        return label;
    }
    
    private JButton createControlButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Microsoft YaHei", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(110, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private Border createTitledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(80, 80, 80)),
            title,
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Microsoft YaHei", Font.BOLD, 12),
            ACCENT_COLOR
        );
        return BorderFactory.createCompoundBorder(
            border,
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        );
    }
    
    private void setupDataPipeline() {
        // 数据模拟器 -> GUI更新
        dataSimulator.addDataListener(data -> {
            latestData = data;
        });
        
        // 数据模拟器 -> 数据记录器
        dataSimulator.addDataListener(data -> {
            if (isRecording.get()) {
                try {
                    dataLogger.write(data);
                } catch (IOException e) {
                    System.err.println("写入数据失败: " + e.getMessage());
                }
            }
        });
    }
    
    private void startRecording() {
        if (isRecording.compareAndSet(false, true)) {
            String selectedFormat = (String) formatComboBox.getSelectedItem();
            if (selectedFormat == null) {
                selectedFormat = "csv";
            }
            
            try {
                boolean success = dataLogger.startRecording(selectedFormat);
                
                if (success) {
                    if (!dataSimulator.isRunning()) {
                        dataSimulator.start();
                    }
                    
                    recordStartTime = System.currentTimeMillis();
                    
                    startButton.setEnabled(false);
                    stopButton.setEnabled(true);
                    formatComboBox.setEnabled(true);
                    switchFormatButton.setEnabled(true);
                    statusLabel.setText("正在记录...");
                    statusLabel.setForeground(RECORDING_COLOR);
                    
                    uiUpdater.scheduleAtFixedRate(this::updateUI, 0, 100, TimeUnit.MILLISECONDS);
                    
                    System.out.println("开始记录数据，格式: " + selectedFormat);
                }
            } catch (IOException e) {
                System.err.println("开始记录失败: " + e.getMessage());
                isRecording.set(false);
            }
        }
    }
    
    private void stopRecording() {
        if (isRecording.compareAndSet(true, false)) {
            try {
                dataLogger.stopRecording();
                
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                formatComboBox.setEnabled(false);
                switchFormatButton.setEnabled(false);
                statusLabel.setText("已停止");
                statusLabel.setForeground(TEXT_COLOR);
                
                System.out.println("停止记录数据");
            } catch (IOException e) {
                System.err.println("停止记录失败: " + e.getMessage());
            }
        }
    }
    
    private void updateUI() {
        SwingUtilities.invokeLater(() -> {
            // 更新记录时长
            if (recordStartTime > 0 && isRecording.get()) {
                long elapsed = System.currentTimeMillis() - recordStartTime;
                recordTimeLabel.setText(formatDuration(elapsed));
            }
            
            // 更新最新数据
            VehicleData data = latestData;
            if (data != null) {
                speedValueLabel.setText(String.format("%.1f km/h", data.getVehicleSpeed()));
                rpmValueLabel.setText(String.format("%.0f RPM", data.getEngineRpm()));
                tempValueLabel.setText(String.format("%.1f °C", data.getEngineTemp()));
                throttleValueLabel.setText(String.format("%.1f %%", data.getThrottlePosition()));
                brakeValueLabel.setText(String.format("%.1f %%", data.getBrakePosition()));
                steeringValueLabel.setText(String.format("%.1f °", data.getSteeringAngle()));
                voltageValueLabel.setText(String.format("%.2f V", data.getBatteryVoltage()));
                fuelValueLabel.setText(String.format("%.1f %%", data.getFuelLevel()));
                accelXLabel.setText(String.format("%.3f m/s²", data.getAccelX()));
                accelYLabel.setText(String.format("%.3f m/s²", data.getAccelY()));
                accelZLabel.setText(String.format("%.3f m/s²", data.getAccelZ()));
            }
        });
    }
    
    private String formatDuration(long millis) {
        long hours = millis / 3600000;
        long minutes = (millis % 3600000) / 60000;
        long seconds = (millis % 60000) / 1000;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
    
    private void shutdown() {
        if (isRecording.get()) {
            try {
                dataLogger.stopRecording();
            } catch (IOException e) {
                System.err.println("停止记录失败: " + e.getMessage());
            }
        }
        dataSimulator.stop();
        uiUpdater.shutdown();
        System.out.println("应用已关闭");
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            RealTimeDataDisplay display = new RealTimeDataDisplay();
            display.setVisible(true);
        });
    }
}
