package com.automotive.logger.service;

import com.automotive.logger.model.VehicleData;

import java.util.Random;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * 车辆数据模拟服务
 * 模拟真实的汽车传感器数据生成
 */
public class DataSimulatorService {
    
    private final ScheduledExecutorService executor;
    private final Random random;
    private final CopyOnWriteArrayList<Consumer<VehicleData>> dataListeners;
    
    // 模拟参数
    private volatile boolean running = false;
    private volatile double baseSpeed = 60.0;  // 基础车速
    private volatile double baseRpm = 2500.0;  // 基础转速
    private volatile double baseTemp = 90.0;   // 基础温度
    
    // 数据生成间隔（毫秒）
    private static final int DATA_INTERVAL_MS = 10; // 100Hz
    
    public DataSimulatorService() {
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "DataSimulator");
            t.setDaemon(true);
            return t;
        });
        this.random = new Random();
        this.dataListeners = new CopyOnWriteArrayList<>();
    }
    
    /**
     * 添加数据监听器
     */
    public void addDataListener(Consumer<VehicleData> listener) {
        dataListeners.add(listener);
    }
    
    /**
     * 移除数据监听器
     */
    public void removeDataListener(Consumer<VehicleData> listener) {
        dataListeners.remove(listener);
    }
    
    /**
     * 启动数据模拟
     */
    public void start() {
        if (running) return;
        running = true;
        
        executor.scheduleAtFixedRate(this::generateDataPoint, 0, DATA_INTERVAL_MS, TimeUnit.MILLISECONDS);
        System.out.println("数据模拟器已启动，频率: " + (1000.0/DATA_INTERVAL_MS) + " Hz");
    }
    
    /**
     * 停止数据模拟
     */
    public void stop() {
        running = false;
        executor.shutdown();
        try {
            if (!executor.awaitTermination(1, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
        System.out.println("数据模拟器已停止");
    }
    
    /**
     * 生成单个数据点
     */
    private void generateDataPoint() {
        VehicleData data = new VehicleData();
        
        // 添加一些随机波动使数据更真实
        double speedNoise = (random.nextDouble() - 0.5) * 2.0;
        double rpmNoise = (random.nextDouble() - 0.5) * 100.0;
        double tempNoise = (random.nextDouble() - 0.5) * 2.0;
        
        // 模拟缓慢变化的趋势
        baseSpeed += (random.nextDouble() - 0.5) * 0.5;
        baseSpeed = Math.max(0, Math.min(200, baseSpeed)); // 限制在0-200 km/h
        
        baseRpm = 800 + (baseSpeed / 200.0) * 5500; // 转速与车速相关
        baseRpm += (random.nextDouble() - 0.5) * 200;
        baseRpm = Math.max(800, Math.min(6500, baseRpm));
        
        baseTemp += (random.nextDouble() - 0.5) * 0.2;
        baseTemp = Math.max(70, Math.min(110, baseTemp));
        
        // 设置数据值
        data.setCanChannel(random.nextInt(2) + 1); // CAN通道1或2
        data.setCanId(0x100 + random.nextInt(0x100)); // CAN ID范围
        
        data.setVehicleSpeed(Math.round((baseSpeed + speedNoise) * 100.0) / 100.0);
        data.setEngineRpm(Math.round((baseRpm + rpmNoise) * 10.0) / 10.0);
        data.setEngineTemp(Math.round((baseTemp + tempNoise) * 10.0) / 10.0);
        
        data.setThrottlePosition(Math.round(random.nextDouble() * 100.0 * 100.0) / 100.0);
        data.setBrakePosition(random.nextDouble() > 0.9 ? Math.round(random.nextDouble() * 50.0 * 100.0) / 100.0 : 0.0);
        data.setSteeringAngle(Math.round((random.nextDouble() - 0.5) * 90.0 * 100.0) / 100.0);
        
        data.setBatteryVoltage(Math.round((12.0 + random.nextDouble() * 2.0) * 100.0) / 100.0);
        data.setFuelLevel(Math.round((50.0 + random.nextDouble() * 50.0) * 100.0) / 100.0);
        data.setOdometer(Math.round((12345.6 + baseSpeed * 0.001) * 100.0) / 100.0);
        
        // 加速度数据
        data.setAccelX(Math.round((random.nextDouble() - 0.5) * 2.0 * 10000.0) / 10000.0);
        data.setAccelY(Math.round((random.nextDouble() - 0.5) * 2.0 * 10000.0) / 10000.0);
        data.setAccelZ(Math.round((9.8 + (random.nextDouble() - 0.5)) * 10000.0) / 10000.0);
        
        // 生成原始CAN数据（8字节）
        byte[] rawData = new byte[8];
        random.nextBytes(rawData);
        data.setRawCanData(rawData);
        
        // 通知所有监听器
        for (Consumer<VehicleData> listener : dataListeners) {
            try {
                listener.accept(data);
            } catch (Exception e) {
                System.err.println("数据监听器处理异常: " + e.getMessage());
            }
        }
    }
    
    /**
     * 设置目标车速（用于模拟加速/减速）
     */
    public void setTargetSpeed(double targetSpeed) {
        this.baseSpeed = Math.max(0, Math.min(200, targetSpeed));
    }
    
    /**
     * 获取当前运行状态
     */
    public boolean isRunning() {
        return running;
    }
}
