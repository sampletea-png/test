#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4写入服务
通过Socket接收Java客户端发送的数据，并实时写入MDF4文件
"""

import socket
import threading
import os
import sys
import time
import json
import signal
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict
from dataclasses import dataclass, asdict
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 尝试导入asammdf
try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
    logger.info("asammdf库加载成功")
except ImportError:
    ASAMMDF_AVAILABLE = False
    logger.warning("asammdf库未安装，将使用CSV格式作为后备方案")
    logger.warning("请运行: pip install asammdf")


@dataclass
class VehicleData:
    """车辆数据结构"""
    timestamp: int
    can_channel: int
    can_id: int
    vehicle_speed: float
    engine_rpm: float
    engine_temp: float
    throttle_position: float
    brake_position: float
    steering_angle: float
    battery_voltage: float
    fuel_level: float
    odometer: float
    accel_x: float
    accel_y: float
    accel_z: float


class MDF4Writer:
    """MDF4文件写入器"""
    
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.mdf: Optional[MDF] = None
        self.current_file: Optional[Path] = None
        self.is_open = False
        
        # 数据缓冲区
        self.buffer: List[VehicleData] = []
        self.buffer_size = 100  # 每100条数据写入一次
        
        # 信号数据累积
        self.timestamps: List[float] = []
        self.signals_data: Dict[str, List[float]] = {
            'vehicle_speed': [],
            'engine_rpm': [],
            'engine_temp': [],
            'throttle_position': [],
            'brake_position': [],
            'steering_angle': [],
            'battery_voltage': [],
            'fuel_level': [],
            'odometer': [],
            'accel_x': [],
            'accel_y': [],
            'accel_z': []
        }
        
        self.data_count = 0
        
    def create_new_file(self) -> Path:
        """创建新的MDF4文件"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"vehicle_data_{timestamp}.mf4"
        self.current_file = self.output_dir / filename
        
        if ASAMMDF_AVAILABLE:
            self.mdf = MDF(version='4.10')
        else:
            # 后备方案：创建CSV文件
            csv_file = self.current_file.with_suffix('.csv')
            with open(csv_file, 'w') as f:
                f.write('timestamp,can_channel,can_id,vehicle_speed,engine_rpm,engine_temp,'
                       'throttle_position,brake_position,steering_angle,battery_voltage,'
                       'fuel_level,odometer,accel_x,accel_y,accel_z\n')
            self.current_file = csv_file
            
        self.is_open = True
        self.data_count = 0
        logger.info(f"创建新文件: {self.current_file}")
        return self.current_file
    
    def add_data(self, data: VehicleData):
        """添加数据到缓冲区"""
        self.buffer.append(data)
        
        # 累积信号数据
        self.timestamps.append(data.timestamp / 1000.0)  # 转换为秒
        self.signals_data['vehicle_speed'].append(data.vehicle_speed)
        self.signals_data['engine_rpm'].append(data.engine_rpm)
        self.signals_data['engine_temp'].append(data.engine_temp)
        self.signals_data['throttle_position'].append(data.throttle_position)
        self.signals_data['brake_position'].append(data.brake_position)
        self.signals_data['steering_angle'].append(data.steering_angle)
        self.signals_data['battery_voltage'].append(data.battery_voltage)
        self.signals_data['fuel_level'].append(data.fuel_level)
        self.signals_data['odometer'].append(data.odometer)
        self.signals_data['accel_x'].append(data.accel_x)
        self.signals_data['accel_y'].append(data.accel_y)
        self.signals_data['accel_z'].append(data.accel_z)
        
        # 缓冲区满时写入
        if len(self.buffer) >= self.buffer_size:
            self._flush_buffer()
    
    def _flush_buffer(self):
        """将缓冲区数据写入文件"""
        if not self.buffer:
            return
            
        if ASAMMDF_AVAILABLE and self.mdf is not None:
            self._write_to_mdf4()
        else:
            self._write_to_csv()
            
        # 清空缓冲区
        self.buffer.clear()
        self.timestamps.clear()
        for key in self.signals_data:
            self.signals_data[key].clear()
    
    def _write_to_mdf4(self):
        """写入MDF4格式"""
        try:
            # 创建信号对象列表
            signals = []
            
            for name, values in self.signals_data.items():
                if values:
                    # 定义单位
                    unit = {
                        'vehicle_speed': 'km/h',
                        'engine_rpm': 'rpm',
                        'engine_temp': '°C',
                        'throttle_position': '%',
                        'brake_position': '%',
                        'steering_angle': '°',
                        'battery_voltage': 'V',
                        'fuel_level': '%',
                        'odometer': 'km',
                        'accel_x': 'm/s²',
                        'accel_y': 'm/s²',
                        'accel_z': 'm/s²'
                    }.get(name, '')
                    
                    signal = Signal(
                        samples=np.array(values, dtype=np.float64),
                        timestamps=np.array(self.timestamps, dtype=np.float64),
                        name=name,
                        unit=unit
                    )
                    signals.append(signal)
            
            # 追加到MDF文件
            if signals:
                self.mdf.append(signals, comment=f'Batch {self.data_count}')
                self.data_count += len(self.buffer)
                logger.debug(f"写入 {len(signals)} 个信号到MDF4文件")
                
        except Exception as e:
            logger.error(f"写入MDF4失败: {e}")
    
    def _write_to_csv(self):
        """写入CSV格式（后备方案）"""
        try:
            with open(self.current_file, 'a') as f:
                for data in self.buffer:
                    f.write(f"{data.timestamp},{data.can_channel},{data.can_id},"
                           f"{data.vehicle_speed},{data.engine_rpm},{data.engine_temp},"
                           f"{data.throttle_position},{data.brake_position},{data.steering_angle},"
                           f"{data.battery_voltage},{data.fuel_level},{data.odometer},"
                           f"{data.accel_x},{data.accel_y},{data.accel_z}\n")
            
            self.data_count += len(self.buffer)
            logger.debug(f"写入 {len(self.buffer)} 条数据到CSV文件")
            
        except Exception as e:
            logger.error(f"写入CSV失败: {e}")
    
    def close(self):
        """关闭文件"""
        if not self.is_open:
            return
            
        # 刷新剩余数据
        self._flush_buffer()
        
        if ASAMMDF_AVAILABLE and self.mdf is not None:
            try:
                self.mdf.save(str(self.current_file), overwrite=True)
                logger.info(f"MDF4文件已保存: {self.current_file}")
                
                # 打印文件信息
                info = self.mdf.info()
                logger.info(f"文件包含 {len(self.mdf.channels_db)} 个通道")
                
            except Exception as e:
                logger.error(f"保存MDF4文件失败: {e}")
            finally:
                self.mdf.close()
        else:
            logger.info(f"CSV文件已保存: {self.current_file}")
        
        self.is_open = False


class Mdf4WriterService:
    """MDF4写入服务 - Socket服务器"""
    
    def __init__(self, host: str = 'localhost', port: int = 9999):
        self.host = host
        self.port = port
        self.server_socket: Optional[socket.socket] = None
        self.running = False
        self.writer: Optional[MDF4Writer] = None
        self.header_received = False
        
    def start(self):
        """启动服务"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            
            logger.info(f"MDF4写入服务已启动，监听 {self.host}:{self.port}")
            logger.info(f"asammdf可用: {ASAMMDF_AVAILABLE}")
            
            while self.running:
                try:
                    self.server_socket.settimeout(1.0)
                    client_socket, address = self.server_socket.accept()
                    logger.info(f"客户端连接: {address}")
                    
                    # 处理客户端连接
                    client_thread = threading.Thread(
                        target=self._handle_client,
                        args=(client_socket,),
                        daemon=True
                    )
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        logger.error(f"接受连接失败: {e}")
                    
        except Exception as e:
            logger.error(f"启动服务失败: {e}")
        finally:
            self.stop()
    
    def _handle_client(self, client_socket: socket.socket):
        """处理客户端连接"""
        try:
            client_socket.settimeout(5.0)
            
            with client_socket:
                reader = client_socket.makefile('r', encoding='utf-8')
                writer = client_socket.makefile('w', encoding='utf-8')
                
                # 发送就绪响应
                writer.write("READY\n")
                writer.flush()
                
                while self.running:
                    line = reader.readline()
                    if not line:
                        break
                    
                    line = line.strip()
                    
                    if line == "INIT":
                        # 初始化新文件
                        if self.writer:
                            self.writer.close()
                        self.writer = MDF4Writer()
                        self.writer.create_new_file()
                        self.header_received = False
                        writer.write("READY\n")
                        writer.flush()
                        
                    elif line.startswith("HEADER:"):
                        # 接收CSV头（可选处理）
                        header = line[7:]
                        logger.info(f"接收CSV头: {header}")
                        self.header_received = True
                        
                    elif line.startswith("DATA:"):
                        # 接收数据
                        if self.writer and self.header_received:
                            data_str = line[5:]
                            data = self._parse_data(data_str)
                            if data:
                                self.writer.add_data(data)
                                
                    elif line == "CLOSE":
                        # 关闭文件
                        if self.writer:
                            self.writer.close()
                            self.writer = None
                        logger.info("客户端请求关闭")
                        break
                        
        except Exception as e:
            logger.error(f"处理客户端异常: {e}")
        finally:
            if self.writer:
                self.writer.close()
                self.writer = None
            logger.info("客户端连接已关闭")
    
    def _parse_data(self, data_str: str) -> Optional[VehicleData]:
        """解析CSV格式的数据"""
        try:
            parts = data_str.split(',')
            if len(parts) >= 15:
                return VehicleData(
                    timestamp=int(parts[0]),
                    can_channel=int(parts[1]),
                    can_id=int(parts[2]),
                    vehicle_speed=float(parts[3]),
                    engine_rpm=float(parts[4]),
                    engine_temp=float(parts[5]),
                    throttle_position=float(parts[6]),
                    brake_position=float(parts[7]),
                    steering_angle=float(parts[8]),
                    battery_voltage=float(parts[9]),
                    fuel_level=float(parts[10]),
                    odometer=float(parts[11]),
                    accel_x=float(parts[12]),
                    accel_y=float(parts[13]),
                    accel_z=float(parts[14])
                )
        except Exception as e:
            logger.error(f"解析数据失败: {e}, 数据: {data_str}")
        return None
    
    def stop(self):
        """停止服务"""
        self.running = False
        
        if self.writer:
            self.writer.close()
            self.writer = None
            
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
            self.server_socket = None
            
        logger.info("MDF4写入服务已停止")


def signal_handler(signum, frame):
    """信号处理"""
    logger.info(f"接收到信号 {signum}，正在关闭...")
    if service:
        service.stop()
    sys.exit(0)


# 全局服务实例
service: Optional[Mdf4WriterService] = None


def main():
    """主函数"""
    global service
    
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 创建并启动服务
    service = Mdf4WriterService(host='localhost', port=9999)
    
    try:
        service.start()
    except KeyboardInterrupt:
        logger.info("用户中断")
    finally:
        service.stop()


if __name__ == "__main__":
    main()
