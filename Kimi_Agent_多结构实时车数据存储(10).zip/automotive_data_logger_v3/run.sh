#!/bin/bash

# 汽车数据记录系统启动脚本 V3 (JavaFX)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "========================================"
echo "  汽车数据实时记录系统 V3 (JavaFX)"
echo "========================================"
echo ""

# 检查Java版本
if ! command -v java &> /dev/null; then
    echo "错误: 未找到Java"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "Java版本: $JAVA_VERSION"

# 检查Maven
if ! command -v mvn &> /dev/null; then
    echo "错误: 未找到Maven"
    exit 1
fi

# 编译
echo ""
echo "编译项目..."
cd "$SCRIPT_DIR/java"
mvn clean package -q

# 检查Python（仅MDF4格式需要）
echo ""
if command -v python3 &> /dev/null; then
    if python3 -c "import asammdf" 2>/dev/null; then
        echo "✓ Python asammdf已安装，MDF4格式可用"
    else
        echo "ℹ Python asammdf未安装，MDF4格式不可用"
        echo "  如需MDF4支持，请运行: pip3 install asammdf numpy"
    fi
else
    echo "ℹ Python未安装，MDF4格式不可用"
fi

# 运行
echo ""
echo "启动应用..."
echo ""

# 检测操作系统
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    mvn javafx:run
elif [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    mvn javafx:run
else
    # 其他系统直接运行
    java -jar target/automotive-data-logger-3.0.0.jar
fi
