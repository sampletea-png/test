package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * MDF4存储格式实现 - 直接从内存数据写入
 * 通过调用Python脚本将JSON数据转换为MDF4格式
 */
public class Mdf4Storage extends BaseStorage {
    
    private final Gson gson;
    private final List<VehicleData> memoryBuffer;
    
    // Python脚本路径
    private String pythonScriptPath = "python/mdf4_writer.py";
    private String pythonExecutable = "python3";
    
    // 临时JSON文件路径
    private Path tempJsonPath;
    
    public Mdf4Storage(StorageConfig config) {
        super(config);
        
        this.gson = new GsonBuilder()
            .setPrettyPrinting()
            .create();
        
        this.memoryBuffer = new ArrayList<>();
        
        // 检测Python可执行文件
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            pythonExecutable = "python";
        }
    }
    
    @Override
    public String getFormatName() {
        return "mdf4";
    }
    
    @Override
    public String getFileExtension() {
        return "mf4";
    }
    
    @Override
    public boolean supportsAppend() {
        return false; // MDF4追加较复杂
    }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        currentFilePath = filePath != null ? filePath : config.getOutputPath(getFileExtension());
        currentFilePath.getParent().toFile().mkdirs();
        
        // 创建临时JSON文件路径
        String tempFileName = currentFilePath.getFileName().toString().replace(".mf4", "_temp.json");
        tempJsonPath = currentFilePath.resolveSibling(tempFileName);
        
        // 清空内存缓冲区
        memoryBuffer.clear();
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        // 直接存入内存缓冲区
        memoryBuffer.add(data);
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        // 批量存入内存缓冲区
        memoryBuffer.addAll(dataList);
    }
    
    @Override
    protected void doFlush() throws IOException {
        // MDF4不需要实时刷新，只在关闭时写入
    }
    
    @Override
    protected void doClose() throws IOException {
        if (memoryBuffer.isEmpty()) {
            return;
        }
        
        try {
            // 将内存数据写入临时JSON文件
            writeJsonToFile();
            
            // 调用Python脚本转换为MDF4
            convertToMdf4();
            
        } finally {
            // 清理临时文件
            cleanupTempFile();
            
            // 清空内存缓冲区
            memoryBuffer.clear();
        }
    }
    
    /**
     * 将内存数据写入JSON文件
     */
    private void writeJsonToFile() throws IOException {
        try (Writer writer = Files.newBufferedWriter(tempJsonPath)) {
            gson.toJson(memoryBuffer, writer);
        }
    }
    
    /**
     * 调用Python脚本将JSON转换为MDF4
     */
    private void convertToMdf4() throws IOException {
        // 检查Python脚本
        Path scriptPath = findPythonScript();
        
        // 构建命令
        ProcessBuilder pb = new ProcessBuilder(
            pythonExecutable,
            scriptPath.toAbsolutePath().toString(),
            currentFilePath.toAbsolutePath().toString(),
            tempJsonPath.toAbsolutePath().toString()
        );
        
        pb.redirectErrorStream(true);
        pb.directory(currentFilePath.getParent().toFile());
        
        try {
            Process process = pb.start();
            
            // 读取输出
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                    System.out.println("[MDF4] " + line);
                }
            }
            
            // 等待完成
            boolean finished = process.waitFor(120, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                throw new IOException("MDF4转换超时");
            }
            
            int exitCode = process.exitValue();
            if (exitCode != 0) {
                throw new IOException("MDF4转换失败，退出码: " + exitCode + 
                    "\n输出: " + output.toString());
            }
            
            System.out.println("MDF4文件已生成: " + currentFilePath);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("MDF4转换被中断", e);
        }
    }
    
    /**
     * 查找Python脚本
     */
    private Path findPythonScript() throws IOException {
        // 尝试多个可能的位置
        Path[] possiblePaths = {
            Path.of(pythonScriptPath),
            Path.of("..", "python", "mdf4_writer.py"),
            Path.of("python", "mdf4_writer.py"),
            currentFilePath.getParent().resolve("..").resolve("python").resolve("mdf4_writer.py").normalize()
        };
        
        for (Path path : possiblePaths) {
            if (path.toFile().exists()) {
                return path;
            }
        }
        
        throw new IOException("MDF4写入脚本未找到: " + pythonScriptPath);
    }
    
    /**
     * 清理临时文件
     */
    private void cleanupTempFile() {
        if (tempJsonPath != null && tempJsonPath.toFile().exists()) {
            try {
                Files.delete(tempJsonPath);
            } catch (IOException e) {
                System.err.println("清理临时文件失败: " + e.getMessage());
            }
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null && currentFilePath.toFile().exists()) {
            return currentFilePath.toFile().length();
        }
        return 0;
    }
    
    /**
     * 设置Python可执行文件路径
     */
    public void setPythonExecutable(String pythonExecutable) {
        this.pythonExecutable = pythonExecutable;
    }
    
    /**
     * 设置Python脚本路径
     */
    public void setPythonScriptPath(String pythonScriptPath) {
        this.pythonScriptPath = pythonScriptPath;
    }
    
    /**
     * 获取内存缓冲区大小
     */
    public int getMemoryBufferSize() {
        return memoryBuffer.size();
    }
}
