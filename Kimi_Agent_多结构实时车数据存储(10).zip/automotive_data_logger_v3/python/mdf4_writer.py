#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4写入工具 - 直接从JSON数据写入

用法:
    python mdf4_writer.py <output_mf4> <json_data_file>

示例:
    python mdf4_writer.py data.mf4 data.json
"""

import sys
import json
from pathlib import Path

try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False
    print("ERROR: asammdf not installed")
    print("Run: pip install asammdf numpy")
    sys.exit(1)


def json_to_mdf4(json_path: str, mdf4_path: str):
    """将JSON数据文件转换为MDF4格式"""
    
    json_file = Path(json_path)
    mdf4_file = Path(mdf4_path)
    
    if not json_file.exists():
        print(f"ERROR: JSON file not found: {json_path}")
        sys.exit(1)
    
    # 读取JSON数据
    with open(json_file, 'r', encoding='utf-8') as f:
        records = json.load(f)
    
    if not records:
        print("ERROR: No data in JSON file")
        sys.exit(1)
    
    print(f"Converting {len(records)} records to MDF4...")
    
    # 提取各字段数据
    timestamps = []
    data_dict = {
        'vehicle_speed': [],
        'engine_rpm': [],
        'engine_temp': [],
        'throttle_position': [],
        'brake_position': [],
        'steering_angle': [],
        'battery_voltage': [],
        'fuel_level': [],
        'odometer': [],
        'accel_x': [],
        'accel_y': [],
        'accel_z': []
    }
    
    units = {
        'vehicle_speed': 'km/h',
        'engine_rpm': 'rpm',
        'engine_temp': '°C',
        'throttle_position': '%',
        'brake_position': '%',
        'steering_angle': '°',
        'battery_voltage': 'V',
        'fuel_level': '%',
        'odometer': 'km',
        'accel_x': 'm/s²',
        'accel_y': 'm/s²',
        'accel_z': 'm/s²'
    }
    
    for record in records:
        # 时间戳转换为秒
        timestamp_ms = record.get('timestamp', 0)
        timestamps.append(timestamp_ms / 1000.0)
        
        data_dict['vehicle_speed'].append(record.get('vehicleSpeed', 0))
        data_dict['engine_rpm'].append(record.get('engineRpm', 0))
        data_dict['engine_temp'].append(record.get('engineTemp', 0))
        data_dict['throttle_position'].append(record.get('throttlePosition', 0))
        data_dict['brake_position'].append(record.get('brakePosition', 0))
        data_dict['steering_angle'].append(record.get('steeringAngle', 0))
        data_dict['battery_voltage'].append(record.get('batteryVoltage', 0))
        data_dict['fuel_level'].append(record.get('fuelLevel', 0))
        data_dict['odometer'].append(record.get('odometer', 0))
        data_dict['accel_x'].append(record.get('accelX', 0))
        data_dict['accel_y'].append(record.get('accelY', 0))
        data_dict['accel_z'].append(record.get('accelZ', 0))
    
    # 创建MDF4文件
    mdf = MDF(version='4.10')
    
    # 创建信号列表
    signals = []
    timestamps_array = np.array(timestamps, dtype=np.float64)
    
    for name, values in data_dict.items():
        if values:
            signal = Signal(
                samples=np.array(values, dtype=np.float64),
                timestamps=timestamps_array,
                name=name,
                unit=units.get(name, '')
            )
            signals.append(signal)
    
    # 追加到MDF文件
    mdf.append(signals)
    
    # 保存文件
    mdf.save(str(mdf4_file), overwrite=True)
    mdf.close()
    
    file_size = mdf4_file.stat().st_size / (1024 * 1024)
    print(f"MDF4 saved: {mdf4_path}")
    print(f"  Size: {file_size:.2f} MB")
    print(f"  Signals: {len(signals)}")
    print(f"  Records: {len(records)}")


def main():
    if len(sys.argv) != 3:
        print("Usage: python mdf4_writer.py <output_mf4> <json_data_file>")
        print("Example: python mdf4_writer.py data.mf4 data.json")
        sys.exit(1)
    
    output_mdf4 = sys.argv[1]
    input_json = sys.argv[2]
    
    try:
        json_to_mdf4(input_json, output_mdf4)
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
