package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * CSV存储格式实现 - 支持GB级大文件直接内存读写
 * 
 * 特性：
 * 1. 写入：内存数据直接流式写入CSV，无中间文件
 * 2. 读取：支持迭代器分块读取，避免内存溢出
 * 3. 大文件：支持GB级文件的高效读写
 */
public class CsvStorage extends BaseStorage {
    
    private static final String[] HEADERS = {
        "timestamp", "can_channel", "can_id",
        "vehicle_speed", "engine_rpm", "engine_temp",
        "throttle_position", "brake_position", "steering_angle",
        "battery_voltage", "fuel_level", "odometer",
        "accel_x", "accel_y", "accel_z"
    };
    
    // 写入相关
    private BufferedWriter writer;
    private boolean headerWritten = false;
    
    // 读取相关
    private BufferedReader reader;
    private boolean readMode = false;
    
    // 大文件分块配置
    private static final int DEFAULT_CHUNK_SIZE = 10000;
    private int chunkSize = DEFAULT_CHUNK_SIZE;
    
    // 文件信息缓存
    private long cachedRecordCount = -1;
    private long[] cachedTimeRange = null;
    
    public CsvStorage(StorageConfig config) {
        super(config);
        
        // 从配置读取分块大小
        Object chunkSizeOption = config.getOption("csv.chunkSize");
        if (chunkSizeOption != null) {
            this.chunkSize = ((Number) chunkSizeOption).intValue();
        }
    }
    
    @Override
    public String getFormatName() {
        return "csv";
    }
    
    @Override
    public String getFileExtension() {
        return "csv";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    @Override
    public boolean supportsIterator() {
        return true;
    }
    
    // ==================== 写入操作 ====================
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        Files.createDirectories(filePath.getParent());
        
        boolean fileExists = Files.exists(filePath) && Files.size(filePath) > 0;
        headerWritten = fileExists && config.isAppendMode();
        
        OutputStream os = new FileOutputStream(filePath.toFile(), config.isAppendMode());
        
        if ("gzip".equals(config.getCompression())) {
            os = new GZIPOutputStream(os);
            currentFilePath = filePath.resolveSibling(filePath.getFileName() + ".gz");
        } else {
            currentFilePath = filePath;
        }
        
        writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        
        if (!headerWritten) {
            writeHeader();
        }
    }
    
    private void writeHeader() throws IOException {
        writer.write(String.join(",", HEADERS));
        writer.newLine();
        headerWritten = true;
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        writer.write(dataToCsvLine(data));
        writer.newLine();
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        for (VehicleData data : dataList) {
            doWrite(data);
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (writer != null) {
            writer.flush();
            writer.close();
            writer = null;
        }
    }
    
    // ==================== 读取操作（大文件优化）====================
    
    @Override
    protected void doOpenForRead(Path filePath) throws IOException {
        if (!Files.exists(filePath)) {
            throw new IOException("文件不存在: " + filePath);
        }
        
        currentFilePath = filePath;
        readMode = true;
        cachedRecordCount = -1;
        cachedTimeRange = null;
        
        InputStream is = new FileInputStream(filePath.toFile());
        
        // 检测是否为GZIP压缩
        if (filePath.toString().endsWith(".gz")) {
            is = new GZIPInputStream(is);
        }
        
        reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        
        // 跳过表头
        reader.readLine();
    }
    
    @Override
    public Iterator<VehicleData> iterator() throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        
        return new CsvIterator();
    }
    
    @Override
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        if (!readMode || reader == null) {
            throw new IOException("未在读取模式");
        }
        
        List<VehicleData> result = new ArrayList<>();
        String line;
        long currentLine = 0;
        
        // 注意：CSV不支持真正的随机访问，需要顺序读取
        // 这里假设reader已经定位到正确位置
        while (currentLine < offset) {
            reader.readLine();
            currentLine++;
        }
        
        while ((line = reader.readLine()) != null && result.size() < count) {
            VehicleData data = csvLineToData(line);
            if (data != null) {
                result.add(data);
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readAll() throws IOException {
        if (!readMode || reader == null) {
            throw new IOException("未在读取模式");
        }
        
        List<VehicleData> result = new ArrayList<>();
        String line;
        
        while ((line = reader.readLine()) != null) {
            VehicleData data = csvLineToData(line);
            if (data != null) {
                result.add(data);
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readRange(long startTime, long endTime) throws IOException {
        List<VehicleData> allData = readAll();
        List<VehicleData> result = new ArrayList<>();
        
        for (VehicleData data : allData) {
            if (data.getTimestamp() >= startTime && data.getTimestamp() <= endTime) {
                result.add(data);
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readLatest(int count) throws IOException {
        // 对于CSV，需要先读取所有数据
        List<VehicleData> allData = readAll();
        int start = Math.max(0, allData.size() - count);
        return allData.subList(start, allData.size());
    }
    
    @Override
    public long[] getTimeRange() throws IOException {
        if (cachedTimeRange != null) {
            return cachedTimeRange.clone();
        }
        
        List<VehicleData> allData = readAll();
        if (allData.isEmpty()) {
            return new long[]{0, 0};
        }
        
        long minTime = allData.get(0).getTimestamp();
        long maxTime = allData.get(allData.size() - 1).getTimestamp();
        
        cachedTimeRange = new long[]{minTime, maxTime};
        return cachedTimeRange.clone();
    }
    
    @Override
    public long getTotalRecordCount() throws IOException {
        if (cachedRecordCount >= 0) {
            return cachedRecordCount;
        }
        
        if (!readMode || reader == null) {
            throw new IOException("未在读取模式");
        }
        
        long count = 0;
        while (reader.readLine() != null) {
            count++;
        }
        
        cachedRecordCount = count;
        return count;
    }
    
    // ==================== 通用方法 ====================
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            try {
                return Files.size(currentFilePath);
            } catch (IOException e) {
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public boolean isValidFile(Path filePath) {
        if (!Files.exists(filePath)) {
            return false;
        }
        
        String name = filePath.toString().toLowerCase();
        return name.endsWith(".csv") || name.endsWith(".csv.gz");
    }
    
    // ==================== 辅助方法 ====================
    
    private String dataToCsvLine(VehicleData data) {
        return String.format("%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.4f,%.4f,%.4f",
            data.getTimestamp(),
            data.getCanChannel(),
            data.getCanId(),
            data.getVehicleSpeed(),
            data.getEngineRpm(),
            data.getEngineTemp(),
            data.getThrottlePosition(),
            data.getBrakePosition(),
            data.getSteeringAngle(),
            data.getBatteryVoltage(),
            data.getFuelLevel(),
            data.getOdometer(),
            data.getAccelX(),
            data.getAccelY(),
            data.getAccelZ()
        );
    }
    
    private VehicleData csvLineToData(String line) {
        try {
            String[] parts = line.split(",");
            if (parts.length < 15) {
                return null;
            }
            
            VehicleData data = new VehicleData();
            data.setTimestamp(Long.parseLong(parts[0]));
            data.setCanChannel(Integer.parseInt(parts[1]));
            data.setCanId(Integer.parseInt(parts[2]));
            data.setVehicleSpeed(Double.parseDouble(parts[3]));
            data.setEngineRpm(Double.parseDouble(parts[4]));
            data.setEngineTemp(Double.parseDouble(parts[5]));
            data.setThrottlePosition(Double.parseDouble(parts[6]));
            data.setBrakePosition(Double.parseDouble(parts[7]));
            data.setSteeringAngle(Double.parseDouble(parts[8]));
            data.setBatteryVoltage(Double.parseDouble(parts[9]));
            data.setFuelLevel(Double.parseDouble(parts[10]));
            data.setOdometer(Double.parseDouble(parts[11]));
            data.setAccelX(Double.parseDouble(parts[12]));
            data.setAccelY(Double.parseDouble(parts[13]));
            data.setAccelZ(Double.parseDouble(parts[14]));
            
            return data;
        } catch (Exception e) {
            System.err.println("解析CSV行失败: " + line + " - " + e.getMessage());
            return null;
        }
    }
    
    // ==================== 迭代器实现 ====================
    
    private class CsvIterator implements Iterator<VehicleData> {
        private VehicleData nextData = null;
        private boolean hasNext = true;
        
        public CsvIterator() {
            advance();
        }
        
        private void advance() {
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    VehicleData data = csvLineToData(line);
                    if (data != null) {
                        nextData = data;
                        return;
                    }
                }
                hasNext = false;
            } catch (IOException e) {
                hasNext = false;
            }
        }
        
        @Override
        public boolean hasNext() {
            return hasNext;
        }
        
        @Override
        public VehicleData next() {
            if (!hasNext) {
                throw new NoSuchElementException();
            }
            VehicleData result = nextData;
            advance();
            return result;
        }
    }
}
