package com.automotive.logger.storage;

import java.util.*;

/**
 * 存储工厂 - 管理和创建存储实例
 * 单例模式
 */
public class StorageFactory {
    
    private static StorageFactory instance;
    
    // 存储格式注册表
    private final Map<String, StorageProvider> storageRegistry = new HashMap<>();
    
    // 存储格式信息
    private final Map<String, FormatInfo> formatInfoMap = new HashMap<>();
    
    private StorageFactory() {
        // 注册内置存储格式
        registerBuiltInStorages();
    }
    
    public static synchronized StorageFactory getInstance() {
        if (instance == null) {
            instance = new StorageFactory();
        }
        return instance;
    }
    
    /**
     * 存储提供者接口
     */
    @FunctionalInterface
    public interface StorageProvider {
        StorageInterface create(StorageConfig config);
    }
    
    /**
     * 格式信息
     */
    public static class FormatInfo {
        private final String name;
        private final String extension;
        private final boolean supportsAppend;
        private final boolean supportsCompression;
        private final String description;
        
        public FormatInfo(String name, String extension, boolean supportsAppend, 
                         boolean supportsCompression, String description) {
            this.name = name;
            this.extension = extension;
            this.supportsAppend = supportsAppend;
            this.supportsCompression = supportsCompression;
            this.description = description;
        }
        
        public String getName() { return name; }
        public String getExtension() { return extension; }
        public boolean isSupportsAppend() { return supportsAppend; }
        public boolean isSupportsCompression() { return supportsCompression; }
        public String getDescription() { return description; }
    }
    
    /**
     * 注册内置存储格式
     */
    private void registerBuiltInStorages() {
        // CSV格式
        register("csv", CsvStorage::new, 
            new FormatInfo("csv", "csv", true, true, "CSV格式，通用易读"));
        
        // JSON格式
        register("json", JsonStorage::new,
            new FormatInfo("json", "json", true, true, "JSON格式，结构化数据"));
        
        // SQLite格式
        register("sqlite", SqliteStorage::new,
            new FormatInfo("sqlite", "db", true, false, "SQLite数据库，支持SQL查询"));
        
        // MDF4格式（通过Python转换）
        register("mdf4", Mdf4Storage::new,
            new FormatInfo("mdf4", "mf4", false, true, "ASAM MDF4格式，行业通用"));
    }
    
    /**
     * 注册存储格式
     */
    public void register(String formatName, StorageProvider provider, FormatInfo info) {
        String key = formatName.toLowerCase();
        storageRegistry.put(key, provider);
        formatInfoMap.put(key, info);
    }
    
    /**
     * 注销存储格式
     */
    public void unregister(String formatName) {
        String key = formatName.toLowerCase();
        storageRegistry.remove(key);
        formatInfoMap.remove(key);
    }
    
    /**
     * 创建存储实例
     */
    public StorageInterface create(String formatName, StorageConfig config) {
        String key = formatName.toLowerCase();
        StorageProvider provider = storageRegistry.get(key);
        
        if (provider == null) {
            throw new IllegalArgumentException("未知的存储格式: " + formatName + 
                "，可用格式: " + getAvailableFormats());
        }
        
        return provider.create(config);
    }
    
    /**
     * 创建存储实例（使用默认配置）
     */
    public StorageInterface create(String formatName) {
        return create(formatName, new StorageConfig());
    }
    
    /**
     * 获取可用格式列表
     */
    public List<String> getAvailableFormats() {
        return new ArrayList<>(storageRegistry.keySet());
    }
    
    /**
     * 获取格式信息
     */
    public FormatInfo getFormatInfo(String formatName) {
        return formatInfoMap.get(formatName.toLowerCase());
    }
    
    /**
     * 获取所有格式信息
     */
    public Map<String, FormatInfo> getAllFormatInfo() {
        return new HashMap<>(formatInfoMap);
    }
    
    /**
     * 检查格式是否可用
     */
    public boolean isFormatAvailable(String formatName) {
        return storageRegistry.containsKey(formatName.toLowerCase());
    }
    
    /**
     * 获取格式扩展名
     */
    public String getFormatExtension(String formatName) {
        FormatInfo info = formatInfoMap.get(formatName.toLowerCase());
        return info != null ? info.getExtension() : null;
    }
}
