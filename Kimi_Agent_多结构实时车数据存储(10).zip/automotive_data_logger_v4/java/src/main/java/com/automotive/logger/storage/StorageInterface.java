package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 存储接口 - 定义所有存储格式的通用接口
 * 支持大文件的流式读写，避免内存溢出
 */
public interface StorageInterface {
    
    /**
     * 获取格式名称
     */
    String getFormatName();
    
    /**
     * 获取文件扩展名
     */
    String getFileExtension();
    
    /**
     * 是否支持追加模式
     */
    boolean supportsAppend();
    
    /**
     * 是否支持读取
     */
    boolean supportsRead();
    
    /**
     * 是否支持迭代器读取（大文件优化）
     */
    default boolean supportsIterator() {
        return false;
    }
    
    // ==================== 写入操作 ====================
    
    /**
     * 打开/创建存储文件
     * 
     * @param filePath 文件路径，如果为null则自动生成
     * @return 是否成功
     */
    boolean open(Path filePath) throws IOException;
    
    /**
     * 写入单条数据（直接写入最终文件）
     * 
     * @param data 车辆数据
     * @return 是否成功
     */
    boolean write(VehicleData data) throws IOException;
    
    /**
     * 批量写入数据
     * 
     * @param dataList 数据列表
     * @return 是否成功
     */
    boolean writeBatch(List<VehicleData> dataList) throws IOException;
    
    /**
     * 刷新缓冲区到磁盘
     */
    void flush() throws IOException;
    
    /**
     * 关闭存储文件
     */
    void close() throws IOException;
    
    // ==================== 读取操作（大文件优化）====================
    
    /**
     * 打开现有文件进行读取
     * 
     * @param filePath 文件路径
     * @return 是否成功
     */
    boolean openForRead(Path filePath) throws IOException;
    
    /**
     * 获取迭代器进行流式读取
     * 适用于大文件，避免一次性加载全部数据到内存
     * 
     * @return 数据迭代器
     * @throws IOException 如果读取失败
     * @throws UnsupportedOperationException 如果不支持迭代器
     */
    default Iterator<VehicleData> iterator() throws IOException {
        throw new UnsupportedOperationException("该存储格式不支持迭代器读取");
    }
    
    /**
     * 分块读取数据
     * 适用于大文件的分页加载
     * 
     * @param offset 起始位置
     * @param count 读取数量
     * @return 数据列表
     * @throws IOException 如果读取失败
     */
    default List<VehicleData> readChunk(long offset, int count) throws IOException {
        throw new UnsupportedOperationException("该存储格式不支持分块读取");
    }
    
    /**
     * 读取所有数据
     * 注意：对于大文件可能导致内存溢出，建议使用iterator()或readChunk()
     * 
     * @return 数据列表
     */
    List<VehicleData> readAll() throws IOException;
    
    /**
     * 读取指定时间范围的数据
     * 
     * @param startTime 开始时间戳
     * @param endTime 结束时间戳
     * @return 数据列表
     */
    List<VehicleData> readRange(long startTime, long endTime) throws IOException;
    
    /**
     * 读取最新N条数据
     * 
     * @param count 数据条数
     * @return 数据列表
     */
    List<VehicleData> readLatest(int count) throws IOException;
    
    /**
     * 获取文件中的时间范围
     * 
     * @return [最小时间戳, 最大时间戳]
     */
    long[] getTimeRange() throws IOException;
    
    /**
     * 获取文件中的总记录数
     */
    long getTotalRecordCount() throws IOException;
    
    // ==================== 通用方法 ====================
    
    /**
     * 获取当前文件大小（字节）
     */
    long getFileSize();
    
    /**
     * 获取已写入记录数
     */
    long getRecordCount();
    
    /**
     * 获取当前文件路径
     */
    Path getCurrentFilePath();
    
    /**
     * 获取存储信息
     */
    StorageInfo getInfo();
    
    /**
     * 设置配置选项
     */
    void setOptions(Map<String, Object> options);
    
    /**
     * 检查文件是否有效
     */
    boolean isValidFile(Path filePath);
    
    /**
     * 存储信息类
     */
    class StorageInfo {
        private String formatName;
        private String filePath;
        private boolean isOpen;
        private boolean isReadMode;
        private long recordCount;
        private long fileSizeBytes;
        private double fileSizeMb;
        private long startTime;
        private long endTime;
        private long durationMs;
        private double writeRate;
        
        // Getters and Setters
        public String getFormatName() { return formatName; }
        public void setFormatName(String formatName) { this.formatName = formatName; }
        
        public String getFilePath() { return filePath; }
        public void setFilePath(String filePath) { this.filePath = filePath; }
        
        public boolean isOpen() { return isOpen; }
        public void setOpen(boolean open) { isOpen = open; }
        
        public boolean isReadMode() { return isReadMode; }
        public void setReadMode(boolean readMode) { isReadMode = readMode; }
        
        public long getRecordCount() { return recordCount; }
        public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
        
        public long getFileSizeBytes() { return fileSizeBytes; }
        public void setFileSizeBytes(long fileSizeBytes) { 
            this.fileSizeBytes = fileSizeBytes;
            this.fileSizeMb = fileSizeBytes / (1024.0 * 1024.0);
        }
        
        public double getFileSizeMb() { return fileSizeMb; }
        
        public long getStartTime() { return startTime; }
        public void setStartTime(long startTime) { this.startTime = startTime; }
        
        public long getEndTime() { return endTime; }
        public void setEndTime(long endTime) { this.endTime = endTime; }
        
        public long getDurationMs() { return durationMs; }
        public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
        
        public double getWriteRate() { return writeRate; }
        public void setWriteRate(double writeRate) { this.writeRate = writeRate; }
        
        @Override
        public String toString() {
            return String.format("StorageInfo[format=%s, records=%d, size=%.2fMB]",
                formatName, recordCount, fileSizeMb);
        }
    }
}
