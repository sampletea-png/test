package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * MDF4存储格式实现 - 使用asammdf直接存储二进制double数据
 * 
 * 特性：
 * 1. 写入：内存数据直接以二进制double数组格式写入MDF4
 * 2. 读取：支持分块读取，避免内存溢出
 * 3. 灵活信号：支持动态配置信号列表
 * 4. 二进制传输：使用struct二进制格式与Python进程通信，非JSON
 */
public class Mdf4Storage extends BaseStorage {
    
    // Python进程
    private Process pythonProcess;
    private DataOutputStream processOutput;
    private DataInputStream processInput;
    
    // Python脚本路径
    private String pythonScriptPath = "python/mdf4_writer_binary.py";
    private String pythonExecutable = "python3";
    
    // 读取模式
    private boolean readMode = false;
    
    // 信号定义（可动态配置）
    private List<SignalDef> signalDefs;
    
    // 大文件分块读取配置
    private static final int DEFAULT_CHUNK_SIZE = 10000;
    private int chunkSize = DEFAULT_CHUNK_SIZE;
    
    // 文件信息缓存
    private long cachedRecordCount = -1;
    private long[] cachedTimeRange = null;
    
    // asammdf自动安装标记
    private static boolean asammdfChecked = false;
    private static boolean asammdfAvailable = false;
    
    /**
     * 信号定义类
     */
    public static class SignalDef {
        public final String name;
        public final String unit;
        public final SignalType type;
        
        public SignalDef(String name, String unit, SignalType type) {
            this.name = name;
            this.unit = unit;
            this.type = type;
        }
    }
    
    public enum SignalType {
        DOUBLE(8),
        FLOAT(4),
        LONG(8),
        INT(4);
        
        public final int bytes;
        
        SignalType(int bytes) {
            this.bytes = bytes;
        }
    }
    
    public Mdf4Storage(StorageConfig config) {
        super(config);
        
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            pythonExecutable = "python";
        }
        
        // 初始化默认信号定义
        initDefaultSignals();
        
        // 从配置读取分块大小
        Object chunkSizeOption = config.getOption("mdf4.chunkSize");
        if (chunkSizeOption != null) {
            this.chunkSize = ((Number) chunkSizeOption).intValue();
        }
        
        // 从配置读取自定义信号
        @SuppressWarnings("unchecked")
        List<SignalDef> customSignals = (List<SignalDef>) config.getOption("mdf4.signals");
        if (customSignals != null) {
            this.signalDefs = customSignals;
        }
    }
    
    /**
     * 初始化默认信号定义
     */
    private void initDefaultSignals() {
        signalDefs = new ArrayList<>();
        signalDefs.add(new SignalDef("timestamp", "ms", SignalType.LONG));
        signalDefs.add(new SignalDef("vehicle_speed", "km/h", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("engine_rpm", "rpm", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("engine_temp", "degC", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("throttle_position", "%", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("brake_position", "%", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("steering_angle", "deg", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("battery_voltage", "V", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("fuel_level", "%", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("odometer", "km", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("accel_x", "m/s2", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("accel_y", "m/s2", SignalType.DOUBLE));
        signalDefs.add(new SignalDef("accel_z", "m/s2", SignalType.DOUBLE));
    }
    
    /**
     * 设置自定义信号定义
     */
    public void setSignalDefs(List<SignalDef> signalDefs) {
        this.signalDefs = new ArrayList<>(signalDefs);
    }
    
    /**
     * 获取当前信号定义
     */
    public List<SignalDef> getSignalDefs() {
        return new ArrayList<>(signalDefs);
    }
    
    @Override
    public String getFormatName() {
        return "mdf4";
    }
    
    @Override
    public String getFileExtension() {
        return "mf4";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    @Override
    public boolean supportsIterator() {
        return true;
    }
    
    // ==================== asammdf自动安装 ====================
    
    private synchronized boolean checkAndInstallAsammdf() {
        if (asammdfChecked) {
            return asammdfAvailable;
        }
        
        try {
            Process checkProcess = new ProcessBuilder(pythonExecutable, "-c", "import asammdf")
                .redirectErrorStream(true)
                .start();
            
            boolean installed = checkProcess.waitFor(5, TimeUnit.SECONDS) && checkProcess.exitValue() == 0;
            
            if (installed) {
                System.out.println("asammdf已安装");
                asammdfAvailable = true;
                asammdfChecked = true;
                return true;
            }
            
            System.out.println("asammdf未安装，正在自动下载安装...");
            System.out.println("这可能需要几分钟时间，请耐心等待...");
            
            Process installProcess = new ProcessBuilder(
                pythonExecutable, "-m", "pip", "install", "asammdf", "numpy", "--user"
            )
            .redirectErrorStream(true)
            .redirectOutput(ProcessBuilder.Redirect.INHERIT)
            .start();
            
            boolean success = installProcess.waitFor(300, TimeUnit.SECONDS);
            
            if (success && installProcess.exitValue() == 0) {
                System.out.println("asammdf安装成功");
                asammdfAvailable = true;
            } else {
                System.err.println("asammdf安装失败，请手动运行: pip install asammdf numpy");
                asammdfAvailable = false;
            }
            
        } catch (Exception e) {
            System.err.println("检查/安装asammdf失败: " + e.getMessage());
            asammdfAvailable = false;
        }
        
        asammdfChecked = true;
        return asammdfAvailable;
    }
    
    // ==================== 写入操作 ====================
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        if (!checkAndInstallAsammdf()) {
            throw new IOException("asammdf不可用，请手动安装: pip install asammdf numpy");
        }
        
        currentFilePath = filePath != null ? filePath : config.getOutputPath(getFileExtension());
        Files.createDirectories(currentFilePath.getParent());
        
        startPythonProcess(currentFilePath, "write", config.isAppendMode());
        
        // 发送信号定义到Python进程
        sendSignalDefinitions();
    }
    
    /**
     * 发送信号定义到Python进程
     */
    private void sendSignalDefinitions() throws IOException {
        // 发送信号数量
        processOutput.writeInt(signalDefs.size());
        
        // 发送每个信号的定义
        for (SignalDef sig : signalDefs) {
            writeString(sig.name);
            writeString(sig.unit);
            processOutput.writeInt(sig.type.ordinal());
        }
        
        processOutput.flush();
    }
    
    /**
     * 写入字符串（长度+UTF-8字节）
     */
    private void writeString(String str) throws IOException {
        byte[] bytes = str.getBytes("UTF-8");
        processOutput.writeInt(bytes.length);
        processOutput.write(bytes);
    }
    
    /**
     * 启动Python进程
     */
    private void startPythonProcess(Path filePath, String mode, boolean append) throws IOException {
        Path scriptPath = findPythonScript();
        
        List<String> command = new ArrayList<>();
        command.add(pythonExecutable);
        command.add(scriptPath.toAbsolutePath().toString());
        command.add(filePath.toAbsolutePath().toString());
        command.add("--mode");
        command.add(mode);
        
        if (append && mode.equals("write")) {
            command.add("--append");
        }
        
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        pb.directory(filePath.getParent().toFile());
        
        pythonProcess = pb.start();
        processOutput = new DataOutputStream(new BufferedOutputStream(
            pythonProcess.getOutputStream()));
        processInput = new DataInputStream(new BufferedInputStream(
            pythonProcess.getInputStream()));
        
        // 等待就绪信号
        int readyCode = processInput.readInt();
        if (readyCode != 1) {
            throw new IOException("Python进程启动失败，错误码: " + readyCode);
        }
        
        System.out.println("MDF4进程已启动: " + filePath);
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        // 发送命令码：1 = 写入单条数据
        processOutput.writeInt(1);
        
        // 按信号定义顺序发送数据
        for (SignalDef sig : signalDefs) {
            double value = getSignalValue(data, sig.name);
            writeValue(value, sig.type);
        }
        
        recordCount++;
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        // 发送命令码：2 = 批量写入
        processOutput.writeInt(2);
        processOutput.writeInt(dataList.size());
        
        for (VehicleData data : dataList) {
            for (SignalDef sig : signalDefs) {
                double value = getSignalValue(data, sig.name);
                writeValue(value, sig.type);
            }
        }
        
        recordCount += dataList.size();
    }
    
    /**
     * 根据信号名称获取值
     */
    private double getSignalValue(VehicleData data, String signalName) {
        switch (signalName) {
            case "timestamp": return data.getTimestamp();
            case "vehicle_speed": return data.getVehicleSpeed();
            case "engine_rpm": return data.getEngineRpm();
            case "engine_temp": return data.getEngineTemp();
            case "throttle_position": return data.getThrottlePosition();
            case "brake_position": return data.getBrakePosition();
            case "steering_angle": return data.getSteeringAngle();
            case "battery_voltage": return data.getBatteryVoltage();
            case "fuel_level": return data.getFuelLevel();
            case "odometer": return data.getOdometer();
            case "accel_x": return data.getAccelX();
            case "accel_y": return data.getAccelY();
            case "accel_z": return data.getAccelZ();
            default: return 0.0;
        }
    }
    
    /**
     * 写入指定类型的值
     */
    private void writeValue(double value, SignalType type) throws IOException {
        switch (type) {
            case DOUBLE:
                processOutput.writeDouble(value);
                break;
            case FLOAT:
                processOutput.writeFloat((float) value);
                break;
            case LONG:
                processOutput.writeLong((long) value);
                break;
            case INT:
                processOutput.writeInt((int) value);
                break;
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        // 发送命令码：3 = 刷新
        processOutput.writeInt(3);
        processOutput.flush();
        
        // 等待确认
        int response = processInput.readInt();
        if (response != 0) {
            throw new IOException("刷新失败，错误码: " + response);
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (processOutput != null) {
            // 发送命令码：4 = 关闭
            processOutput.writeInt(4);
            processOutput.flush();
            
            // 读取最终统计
            try {
                long totalRecords = processInput.readLong();
                double fileSizeMb = processInput.readDouble();
                System.out.println("MDF4文件已保存: " + currentFilePath);
                System.out.println("  大小: " + String.format("%.2f MB", fileSizeMb));
                System.out.println("  记录数: " + totalRecords);
            } catch (IOException e) {
                // ignore
            }
            
            processOutput.close();
            processOutput = null;
        }
        
        if (processInput != null) {
            processInput.close();
            processInput = null;
        }
        
        if (pythonProcess != null) {
            try {
                boolean finished = pythonProcess.waitFor(30, TimeUnit.SECONDS);
                if (!finished) {
                    pythonProcess.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                pythonProcess.destroyForcibly();
            }
            pythonProcess = null;
        }
    }
    
    // ==================== 读取操作 ====================
    
    @Override
    protected void doOpenForRead(Path filePath) throws IOException {
        if (!checkAndInstallAsammdf()) {
            throw new IOException("asammdf不可用，请手动安装: pip install asammdf numpy");
        }
        
        if (!Files.exists(filePath)) {
            throw new IOException("文件不存在: " + filePath);
        }
        
        readMode = true;
        cachedRecordCount = -1;
        cachedTimeRange = null;
        
        startPythonProcess(filePath, "read", false);
        
        // 接收信号定义
        receiveSignalDefinitions();
    }
    
    /**
     * 接收信号定义
     */
    private void receiveSignalDefinitions() throws IOException {
        int signalCount = processInput.readInt();
        signalDefs = new ArrayList<>();
        
        for (int i = 0; i < signalCount; i++) {
            String name = readString();
            String unit = readString();
            int typeOrdinal = processInput.readInt();
            SignalType type = SignalType.values()[typeOrdinal];
            signalDefs.add(new SignalDef(name, unit, type));
        }
    }
    
    /**
     * 读取字符串
     */
    private String readString() throws IOException {
        int length = processInput.readInt();
        byte[] bytes = new byte[length];
        processInput.readFully(bytes);
        return new String(bytes, "UTF-8");
    }
    
    @Override
    public Iterator<VehicleData> iterator() throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        return new Mdf4Iterator(chunkSize);
    }
    
    @Override
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        if (!readMode || processOutput == null) {
            throw new IOException("未在读取模式");
        }
        
        // 发送命令码：5 = 分块读取
        processOutput.writeInt(5);
        processOutput.writeLong(offset);
        processOutput.writeInt(count);
        processOutput.flush();
        
        // 读取响应
        int responseCode = processInput.readInt();
        if (responseCode != 0) {
            throw new IOException("读取失败，错误码: " + responseCode);
        }
        
        int actualCount = processInput.readInt();
        List<VehicleData> result = new ArrayList<>(actualCount);
        
        for (int i = 0; i < actualCount; i++) {
            VehicleData data = readVehicleData();
            result.add(data);
        }
        
        return result;
    }
    
    /**
     * 从二进制流读取VehicleData
     */
    private VehicleData readVehicleData() throws IOException {
        VehicleData data = new VehicleData();
        
        for (SignalDef sig : signalDefs) {
            double value = readValue(sig.type);
            setSignalValue(data, sig.name, value);
        }
        
        return data;
    }
    
    /**
     * 读取指定类型的值
     */
    private double readValue(SignalType type) throws IOException {
        switch (type) {
            case DOUBLE:
                return processInput.readDouble();
            case FLOAT:
                return processInput.readFloat();
            case LONG:
                return processInput.readLong();
            case INT:
                return processInput.readInt();
            default:
                return 0.0;
        }
    }
    
    /**
     * 设置信号值
     */
    private void setSignalValue(VehicleData data, String signalName, double value) {
        switch (signalName) {
            case "timestamp": data.setTimestamp((long) value); break;
            case "vehicle_speed": data.setVehicleSpeed(value); break;
            case "engine_rpm": data.setEngineRpm(value); break;
            case "engine_temp": data.setEngineTemp(value); break;
            case "throttle_position": data.setThrottlePosition(value); break;
            case "brake_position": data.setBrakePosition(value); break;
            case "steering_angle": data.setSteeringAngle(value); break;
            case "battery_voltage": data.setBatteryVoltage(value); break;
            case "fuel_level": data.setFuelLevel(value); break;
            case "odometer": data.setOdometer(value); break;
            case "accel_x": data.setAccelX(value); break;
            case "accel_y": data.setAccelY(value); break;
            case "accel_z": data.setAccelZ(value); break;
        }
    }
    
    @Override
    public List<VehicleData> readAll() throws IOException {
        List<VehicleData> result = new ArrayList<>();
        long offset = 0;
        
        while (true) {
            List<VehicleData> chunk = readChunk(offset, chunkSize);
            if (chunk.isEmpty()) break;
            result.addAll(chunk);
            offset += chunk.size();
            if (chunk.size() < chunkSize) break;
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readRange(long startTime, long endTime) throws IOException {
        if (!readMode || processOutput == null) {
            throw new IOException("未在读取模式");
        }
        
        // 发送命令码：6 = 时间范围读取
        processOutput.writeInt(6);
        processOutput.writeLong(startTime);
        processOutput.writeLong(endTime);
        processOutput.flush();
        
        int responseCode = processInput.readInt();
        if (responseCode != 0) {
            throw new IOException("读取失败，错误码: " + responseCode);
        }
        
        int count = processInput.readInt();
        List<VehicleData> result = new ArrayList<>(count);
        
        for (int i = 0; i < count; i++) {
            result.add(readVehicleData());
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readLatest(int count) throws IOException {
        if (!readMode || processOutput == null) {
            throw new IOException("未在读取模式");
        }
        
        // 发送命令码：7 = 读取最新N条
        processOutput.writeInt(7);
        processOutput.writeInt(count);
        processOutput.flush();
        
        int responseCode = processInput.readInt();
        if (responseCode != 0) {
            throw new IOException("读取失败，错误码: " + responseCode);
        }
        
        int actualCount = processInput.readInt();
        List<VehicleData> result = new ArrayList<>(actualCount);
        
        for (int i = 0; i < actualCount; i++) {
            result.add(readVehicleData());
        }
        
        return result;
    }
    
    @Override
    public long[] getTimeRange() throws IOException {
        if (cachedTimeRange != null) {
            return cachedTimeRange.clone();
        }
        
        if (!readMode || processOutput == null) {
            throw new IOException("未在读取模式");
        }
        
        // 发送命令码：8 = 获取时间范围
        processOutput.writeInt(8);
        processOutput.flush();
        
        long minTime = processInput.readLong();
        long maxTime = processInput.readLong();
        
        cachedTimeRange = new long[]{minTime, maxTime};
        return cachedTimeRange.clone();
    }
    
    @Override
    public long getTotalRecordCount() throws IOException {
        if (cachedRecordCount >= 0) {
            return cachedRecordCount;
        }
        
        if (!readMode || processOutput == null) {
            throw new IOException("未在读取模式");
        }
        
        // 发送命令码：9 = 获取记录数
        processOutput.writeInt(9);
        processOutput.flush();
        
        cachedRecordCount = processInput.readLong();
        return cachedRecordCount;
    }
    
    // ==================== 通用方法 ====================
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            try {
                return Files.size(currentFilePath);
            } catch (IOException e) {
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public boolean isValidFile(Path filePath) {
        if (!Files.exists(filePath)) {
            return false;
        }
        
        if (!filePath.toString().toLowerCase().endsWith(".mf4")) {
            return false;
        }
        
        try {
            return Files.size(filePath) > 64;
        } catch (IOException e) {
            return false;
        }
    }
    
    private Path findPythonScript() throws IOException {
        Path[] possiblePaths = {
            Path.of(pythonScriptPath),
            Path.of("..", "python", "mdf4_writer_binary.py"),
            Path.of("python", "mdf4_writer_binary.py"),
            currentFilePath != null ? currentFilePath.getParent().resolve("..").resolve("python").resolve("mdf4_writer_binary.py").normalize() : null
        };
        
        for (Path path : possiblePaths) {
            if (path != null && path.toFile().exists()) {
                return path;
            }
        }
        
        throw new IOException("MDF4二进制写入脚本未找到: " + pythonScriptPath);
    }
    
    // ==================== 迭代器实现 ====================
    
    private class Mdf4Iterator implements Iterator<VehicleData> {
        private final int chunkSize;
        private List<VehicleData> currentChunk = new ArrayList<>();
        private int currentIndex = 0;
        private long currentOffset = 0;
        private boolean hasMore = true;
        
        public Mdf4Iterator(int chunkSize) {
            this.chunkSize = chunkSize;
            loadNextChunk();
        }
        
        private void loadNextChunk() {
            try {
                currentChunk = readChunk(currentOffset, chunkSize);
                currentIndex = 0;
                currentOffset += currentChunk.size();
                hasMore = !currentChunk.isEmpty();
            } catch (IOException e) {
                hasMore = false;
                currentChunk.clear();
            }
        }
        
        @Override
        public boolean hasNext() {
            if (currentIndex < currentChunk.size()) {
                return true;
            }
            if (hasMore) {
                loadNextChunk();
                return !currentChunk.isEmpty();
            }
            return false;
        }
        
        @Override
        public VehicleData next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return currentChunk.get(currentIndex++);
        }
    }
}
