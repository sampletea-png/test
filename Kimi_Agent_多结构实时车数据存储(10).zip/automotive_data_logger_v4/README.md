# 汽车数据实时记录系统 V4

一个功能完整的汽车数据实时记录工具，支持GB级大文件的直接内存读写，使用asammdf直接存储二进制double数据。

## 核心特性

### 大文件支持
- **直接内存写入**：数据从内存直接以二进制double数组格式写入MDF4
- **流式读取**：支持迭代器分块读取，避免内存溢出
- **GB级支持**：支持GB级大文件的高效读写

### 二进制数据传输
- **非JSON格式**：使用struct二进制格式与Python进程通信，效率更高
- **直接double存储**：MDF4文件中直接存储double/float/long/int原始数据

### 灵活信号配置
- **动态信号定义**：支持运行时配置信号列表
- **多种数据类型**：支持DOUBLE、FLOAT、LONG、INT类型
- **自定义信号**：可根据需求添加/删除信号

### 自动依赖管理
- **asammdf自动安装**：当Python的asammdf库不存在时，自动下载安装

### 存储格式
| 格式 | 扩展名 | 写入方式 | 读取方式 | 大文件支持 |
|------|--------|----------|----------|------------|
| CSV | .csv | 流式直接写入 | 迭代器/分块读取 | ✓ |
| JSON | .json | 流式直接写入 (Lines格式) | 迭代器/分块读取 | ✓ |
| SQLite | .db | 批量插入 | 分页查询/迭代器 | ✓ |
| MDF4 | .mf4 | **二进制double数组** (asammdf) | 分块读取 | ✓ |

## 环境要求

### Java环境
- **JDK 21** (必需)
- Maven 3.6+ (可选，用于构建)

### Python环境（用于MDF4格式）
- Python 3.8+ (必需)
- asammdf (自动安装)
- numpy (自动安装)

> **注意**：asammdf和numpy会在首次使用MDF4格式时自动安装，无需手动操作。

## 快速开始

### 1. 确保JDK 21已安装
```bash
java -version
# 应显示: openjdk version "21" 或类似信息
```

### 2. 确保Python已安装
```bash
python --version
# 或
python3 --version
```

### 3. 运行应用
```bash
# Linux/macOS
./scripts/run.sh

# Windows
scripts\run.bat
```

首次使用MDF4格式时，系统会自动下载并安装asammdf和numpy，这可能需要几分钟时间。

## MDF4二进制数据传输

### 与JSON方式的对比

| 特性 | JSON方式 | 二进制方式 |
|------|----------|------------|
| 数据格式 | JSON字符串 | struct二进制 |
| 数据大小 | 大（文本格式） | 小（原始二进制） |
| 解析速度 | 慢（需JSON解析） | 快（直接内存拷贝） |
| MDF4存储 | JSON字符串 | 原始double数组 |
| 兼容性 | 通用 | 需要asammdf |

### 二进制协议

Java与Python之间使用大端序(big-endian)二进制格式通信：

```
命令码 (4 bytes int)
    1 = 写入单条
    2 = 批量写入
    3 = 刷新
    4 = 关闭
    5 = 分块读取
    6 = 时间范围读取
    7 = 读取最新N条
    8 = 获取时间范围
    9 = 获取记录数

数据格式:
    int:    4 bytes (big-endian)
    long:   8 bytes (big-endian)
    float:  4 bytes (big-endian IEEE 754)
    double: 8 bytes (big-endian IEEE 754)
    string: length(4 bytes) + UTF-8 bytes
```

## 灵活信号配置

### 默认信号定义
```java
// 预定义的汽车信号
List<SignalDef> signals = Arrays.asList(
    new SignalDef("timestamp", "ms", SignalType.LONG),
    new SignalDef("vehicle_speed", "km/h", SignalType.DOUBLE),
    new SignalDef("engine_rpm", "rpm", SignalType.DOUBLE),
    new SignalDef("engine_temp", "degC", SignalType.DOUBLE),
    new SignalDef("throttle_position", "%", SignalType.DOUBLE),
    new SignalDef("brake_position", "%", SignalType.DOUBLE),
    new SignalDef("steering_angle", "deg", SignalType.DOUBLE),
    new SignalDef("battery_voltage", "V", SignalType.DOUBLE),
    new SignalDef("fuel_level", "%", SignalType.DOUBLE),
    new SignalDef("odometer", "km", SignalType.DOUBLE),
    new SignalDef("accel_x", "m/s2", SignalType.DOUBLE),
    new SignalDef("accel_y", "m/s2", SignalType.DOUBLE),
    new SignalDef("accel_z", "m/s2", SignalType.DOUBLE)
);
```

### 自定义信号配置
```java
// 创建自定义信号列表
List<Mdf4Storage.SignalDef> customSignals = new ArrayList<>();
customSignals.add(new Mdf4Storage.SignalDef("timestamp", "ms", Mdf4Storage.SignalType.LONG));
customSignals.add(new Mdf4Storage.SignalDef("custom_signal1", "unit1", Mdf4Storage.SignalType.DOUBLE));
customSignals.add(new Mdf4Storage.SignalDef("custom_signal2", "unit2", Mdf4Storage.SignalType.FLOAT));

// 配置到存储
StorageConfig config = new StorageConfig();
config.setOption("mdf4.signals", customSignals);

Mdf4Storage storage = new Mdf4Storage(config);
storage.open(Path.of("output/custom.mf4"));
```

### 运行时修改信号
```java
// 获取当前信号定义
List<SignalDef> currentSignals = storage.getSignalDefs();

// 添加新信号
currentSignals.add(new SignalDef("new_signal", "new_unit", SignalType.DOUBLE));

// 更新信号定义
storage.setSignalDefs(currentSignals);
```

## 大文件读写示例

### 写入（直接内存到MDF4）
```java
// 创建存储实例
Mdf4Storage storage = new Mdf4Storage(config);
storage.open(Path.of("output/large_file.mf4"));

// 直接写入 - 无中间转储，二进制传输
while (hasMoreData()) {
    VehicleData data = getNextData();  // 从内存获取数据
    storage.write(data);               // 直接以double数组格式写入MDF4
}

storage.close();
```

### 批量写入（更高效）
```java
List<VehicleData> batch = new ArrayList<>();
while (batch.size() < 1000) {
    batch.add(getNextData());
}
storage.writeBatch(batch);  // 批量写入，减少进程通信开销
```

### 读取（迭代器模式 - 推荐用于大文件）
```java
// 打开文件
storage.openForRead(Path.of("output/large_file.mf4"));

// 使用迭代器流式读取 - 内存占用恒定
Iterator<VehicleData> iterator = storage.iterator();
while (iterator.hasNext()) {
    VehicleData data = iterator.next();  // 逐条读取
    process(data);
}
```

### 读取（分块模式）
```java
// 分块读取 - 控制内存使用
long offset = 0;
int chunkSize = 10000;  // 每次读取1万条

while (true) {
    List<VehicleData> chunk = storage.readChunk(offset, chunkSize);
    if (chunk.isEmpty()) break;
    
    process(chunk);
    offset += chunk.size();
}
```

## 项目结构

```
automotive_data_logger_v4/
├── java/
│   ├── pom.xml                          # Maven配置 (JDK 21 + JavaFX 21)
│   └── src/main/java/com/automotive/logger/
│       ├── VehicleDataLoggerApp.java    # 主应用入口
│       ├── model/
│       │   └── VehicleData.java         # 数据模型
│       ├── service/
│       │   ├── DataSimulatorService.java    # 数据模拟服务
│       │   └── DataLoggerService.java       # 数据记录服务
│       ├── storage/
│       │   ├── StorageInterface.java        # 存储接口
│       │   ├── StorageConfig.java           # 存储配置
│       │   ├── StorageFactory.java          # 存储工厂
│       │   ├── BaseStorage.java             # 存储基类
│       │   ├── CsvStorage.java              # CSV存储
│       │   ├── JsonStorage.java             # JSON存储
│       │   ├── SqliteStorage.java           # SQLite存储
│       │   └── Mdf4Storage.java             # MDF4存储（二进制传输）
│       ├── data/
│       │   ├── DataBuffer.java              # 数据缓冲区
│       │   └── DataHistoryManager.java      # 历史数据管理
│       └── frontend/
│           ├── FrontendInterface.java       # 前端接口
│           └── javafx/
│               └── JavaFXFrontend.java      # JavaFX实现
├── python/
│   ├── mdf4_writer_binary.py          # MDF4二进制流式读写脚本
│   └── requirements.txt               # Python依赖
├── scripts/
│   ├── run.sh / run.bat               # 启动脚本
│   └── compile.sh / compile.bat       # 编译脚本
└── README.md
```

## 手动编译

如果没有Maven，可以使用手动编译脚本：

```bash
# Linux/macOS
./scripts/compile.sh

# Windows
scripts\compile.bat
```

这将自动下载所有依赖（JavaFX 21、Gson、SQLite JDBC）并编译项目。

## 大文件配置

### 分块大小配置
```java
StorageConfig config = new StorageConfig();

// MDF4分块大小
config.setOption("mdf4.chunkSize", 10000);
```

### 大文件阈值
```java
// 超过100MB的文件使用大文件模式
DataHistoryManager historyManager = new DataHistoryManager(outputDir);
// 自动检测文件大小，大文件使用迭代器模式
```

## 存储接口方法

### 写入操作
- `open(Path)` - 打开/创建文件
- `write(VehicleData)` - 写入单条数据
- `writeBatch(List<VehicleData>)` - 批量写入
- `flush()` - 刷新缓冲区
- `close()` - 关闭文件

### 读取操作
- `openForRead(Path)` - 打开文件读取
- `iterator()` - 获取迭代器（流式读取）
- `readChunk(offset, count)` - 分块读取
- `readAll()` - 读取全部（小文件）
- `readRange(startTime, endTime)` - 读取时间范围
- `readLatest(count)` - 读取最新N条
- `getTimeRange()` - 获取时间范围
- `getTotalRecordCount()` - 获取总记录数

## asammdf自动安装

当首次使用MDF4格式时，系统会自动执行以下操作：

1. 检查Python是否已安装
2. 检查asammdf是否已安装
3. 如果未安装，自动运行 `pip install asammdf numpy --user`
4. 等待安装完成后继续执行

安装过程可能需要几分钟，请耐心等待。安装成功后，后续使用无需再次安装。

### 手动安装
如果自动安装失败，可以手动安装：
```bash
pip install asammdf numpy
```

## 性能对比

| 操作 | 小文件(<100MB) | 大文件(>1GB) |
|------|----------------|--------------|
| 写入 | 直接写入 | 流式写入 |
| 读取 | 全部加载 | 迭代器/分块 |
| 内存占用 | 与文件大小相关 | 恒定（分块大小） |

## 常见问题

### Q: JDK版本要求？
A: 必须使用JDK 21，JavaFX版本也是21。

### Q: asammdf自动安装失败？
A: 可以尝试手动安装：
```bash
pip install asammdf numpy
```

### Q: 如何处理GB级大文件？
A: 使用迭代器模式或分块读取：
```java
Iterator<VehicleData> it = storage.iterator();
while (it.hasNext()) {
    process(it.next());
}
```

### Q: 可以自定义信号吗？
A: 可以，使用 `setSignalDefs()` 方法：
```java
List<SignalDef> signals = new ArrayList<>();
signals.add(new SignalDef("my_signal", "unit", SignalType.DOUBLE));
storage.setSignalDefs(signals);
```

### Q: 可以追加写入吗？
A: 支持，打开时设置append模式：
```java
config.setAppendMode(true);
storage.open(filePath);
```

### Q: 如何优化写入性能？
A: 使用批量写入：
```java
storage.writeBatch(dataList);  // 批量写入
```

## License

MIT License
