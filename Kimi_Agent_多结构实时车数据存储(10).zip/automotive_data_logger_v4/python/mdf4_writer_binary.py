#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4二进制流式读写工具 - 直接存储double数组数据

特性：
1. 写入：内存数据直接以二进制double数组格式写入MDF4
2. 读取：支持分块读取，避免内存溢出
3. 灵活信号：支持动态配置信号列表
4. 二进制传输：使用struct二进制格式与Java进程通信

用法:
    python mdf4_writer_binary.py <output_mf4> [--mode write|read] [--append]

命令码 (4字节int):
    1  - WRITE_SINGLE    写入单条数据
    2  - WRITE_BATCH     批量写入数据
    3  - FLUSH           刷新缓冲区
    4  - CLOSE           关闭文件
    5  - READ_CHUNK      分块读取 (offset: long, count: int)
    6  - READ_RANGE      读取时间范围 (start: long, end: long)
    7  - READ_LATEST     读取最新N条 (count: int)
    8  - GET_RANGE       获取时间范围
    9  - GET_COUNT       获取总记录数
"""

import sys
import struct
import argparse
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import IntEnum

try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False


class Command(IntEnum):
    WRITE_SINGLE = 1
    WRITE_BATCH = 2
    FLUSH = 3
    CLOSE = 4
    READ_CHUNK = 5
    READ_RANGE = 6
    READ_LATEST = 7
    GET_RANGE = 8
    GET_COUNT = 9


class SignalType(IntEnum):
    DOUBLE = 0
    FLOAT = 1
    LONG = 2
    INT = 3


@dataclass
class SignalDef:
    name: str
    unit: str
    type: SignalType


class BinaryStream:
    """二进制流读写工具"""
    
    def __init__(self, input_stream=None, output_stream=None):
        self.input = input_stream
        self.output = output_stream
    
    def read_int(self) -> int:
        return struct.unpack('>i', self.input.read(4))[0]
    
    def read_long(self) -> int:
        return struct.unpack('>q', self.input.read(8))[0]
    
    def read_double(self) -> float:
        return struct.unpack('>d', self.input.read(8))[0]
    
    def read_float(self) -> float:
        return struct.unpack('>f', self.input.read(4))[0]
    
    def read_string(self) -> str:
        length = self.read_int()
        return self.input.read(length).decode('utf-8')
    
    def write_int(self, value: int):
        self.output.write(struct.pack('>i', value))
    
    def write_long(self, value: int):
        self.output.write(struct.pack('>q', value))
    
    def write_double(self, value: float):
        self.output.write(struct.pack('>d', value))
    
    def write_float(self, value: float):
        self.output.write(struct.pack('>f', value))
    
    def write_string(self, value: str):
        encoded = value.encode('utf-8')
        self.write_int(len(encoded))
        self.output.write(encoded)
    
    def flush(self):
        if self.output:
            self.output.flush()


class Mdf4BinaryWriter:
    """MDF4二进制写入器 - 直接存储double数组"""
    
    def __init__(self, output_path: str, append: bool = False):
        self.output_path = Path(output_path)
        self.append_mode = append
        self.mdf: Optional[MDF] = None
        self.signal_defs: List[SignalDef] = []
        self.buffer: Dict[str, List[float]] = {}
        self.timestamps: List[float] = []
        self.buffer_size = 1000
        self.total_records = 0
        
    def open(self):
        """打开MDF4文件并接收信号定义"""
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if self.append_mode and self.output_path.exists():
            self.mdf = MDF(str(self.output_path))
            self._load_existing_signals()
        else:
            self.mdf = MDF(version='4.10')
        
        # 发送就绪信号
        return True
    
    def _load_existing_signals(self):
        """加载现有文件的信号定义"""
        for channel in self.mdf.channels_db:
            if channel not in self.mdf.get_master_channels():
                self.signal_defs.append(SignalDef(channel, '', SignalType.DOUBLE))
                self.buffer[channel] = []
    
    def set_signal_definitions(self, signal_defs: List[SignalDef]):
        """设置信号定义"""
        self.signal_defs = signal_defs
        for sig in signal_defs:
            self.buffer[sig.name] = []
    
    def write_single(self, stream: BinaryStream):
        """写入单条数据"""
        timestamp = 0.0
        
        for sig in self.signal_defs:
            value = self._read_value(stream, sig.type)
            if sig.name == 'timestamp':
                timestamp = value / 1000.0  # 毫秒转秒
            else:
                self.buffer[sig.name].append(value)
        
        self.timestamps.append(timestamp)
        self.total_records += 1
        
        # 缓冲区满时刷新
        if len(self.timestamps) >= self.buffer_size:
            self.flush()
    
    def write_batch(self, stream: BinaryStream):
        """批量写入数据"""
        count = stream.read_int()
        
        for _ in range(count):
            timestamp = 0.0
            
            for sig in self.signal_defs:
                value = self._read_value(stream, sig.type)
                if sig.name == 'timestamp':
                    timestamp = value / 1000.0
                else:
                    self.buffer[sig.name].append(value)
            
            self.timestamps.append(timestamp)
        
        self.total_records += count
        
        if len(self.timestamps) >= self.buffer_size:
            self.flush()
    
    def _read_value(self, stream: BinaryStream, sig_type: SignalType) -> float:
        """根据类型读取值"""
        if sig_type == SignalType.DOUBLE:
            return stream.read_double()
        elif sig_type == SignalType.FLOAT:
            return stream.read_float()
        elif sig_type == SignalType.LONG:
            return float(stream.read_long())
        elif sig_type == SignalType.INT:
            return float(stream.read_int())
        return 0.0
    
    def flush(self):
        """刷新缓冲区到文件"""
        if not self.timestamps:
            return
        
        # 创建时间戳数组（秒）
        timestamps_array = np.array(self.timestamps, dtype=np.float64)
        
        # 创建信号列表
        signals = []
        for sig in self.signal_defs:
            if sig.name == 'timestamp':
                continue
            
            if sig.name in self.buffer and self.buffer[sig.name]:
                values = np.array(self.buffer[sig.name], dtype=np.float64)
                signal = Signal(
                    samples=values,
                    timestamps=timestamps_array,
                    name=sig.name,
                    unit=sig.unit
                )
                signals.append(signal)
        
        # 追加到MDF文件
        if signals:
            self.mdf.append(signals)
        
        # 清空缓冲区
        self.timestamps.clear()
        for key in self.buffer:
            self.buffer[key].clear()
    
    def close(self, stream: BinaryStream):
        """关闭文件"""
        self.flush()
        
        # 保存文件
        self.mdf.save(str(self.output_path), overwrite=True)
        self.mdf.close()
        
        # 发送统计信息
        file_size_mb = self.output_path.stat().st_size / (1024 * 1024)
        stream.write_long(self.total_records)
        stream.write_double(file_size_mb)
        stream.flush()


class Mdf4BinaryReader:
    """MDF4二进制读取器 - 支持分块读取"""
    
    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        self.mdf: Optional[MDF] = None
        self.signal_defs: List[SignalDef] = []
        self.timestamps: Optional[np.ndarray] = None
        self.signals: Dict[str, np.ndarray] = {}
        self.total_records = 0
        
    def open(self, stream: BinaryStream) -> bool:
        """打开MDF4文件并发送信号定义"""
        if not self.file_path.exists():
            stream.write_int(-1)  # 错误码
            return False
        
        self.mdf = MDF(str(self.file_path))
        
        # 加载主通道（时间戳）
        master_channels = self.mdf.get_master_channels()
        if master_channels:
            master = self.mdf.get(master_channels[0])
            self.timestamps = master.timestamps
            self.total_records = len(self.timestamps)
        
        # 加载信号定义
        for channel in self.mdf.channels_db:
            if channel not in master_channels:
                try:
                    sig = self.mdf.get(channel)
                    self.signals[channel] = sig.samples
                    unit = sig.unit if hasattr(sig, 'unit') else ''
                    self.signal_defs.append(SignalDef(channel, unit, SignalType.DOUBLE))
                except:
                    pass
        
        # 添加timestamp到信号定义开头
        self.signal_defs.insert(0, SignalDef('timestamp', 'ms', SignalType.LONG))
        
        # 发送就绪信号和信号定义
        stream.write_int(1)  # 成功
        self._send_signal_definitions(stream)
        return True
    
    def _send_signal_definitions(self, stream: BinaryStream):
        """发送信号定义"""
        stream.write_int(len(self.signal_defs))
        
        for sig in self.signal_defs:
            stream.write_string(sig.name)
            stream.write_string(sig.unit)
            stream.write_int(sig.type.value)
        
        stream.flush()
    
    def _write_value(self, stream: BinaryStream, value: float, sig_type: SignalType):
        """根据类型写入值"""
        if sig_type == SignalType.DOUBLE:
            stream.write_double(value)
        elif sig_type == SignalType.FLOAT:
            stream.write_float(value)
        elif sig_type == SignalType.LONG:
            stream.write_long(int(value))
        elif sig_type == SignalType.INT:
            stream.write_int(int(value))
    
    def read_chunk(self, stream: BinaryStream):
        """分块读取数据"""
        offset = stream.read_long()
        count = stream.read_int()
        
        end = min(offset + count, self.total_records)
        actual_count = int(end - offset)
        
        if actual_count <= 0:
            stream.write_int(0)  # 成功
            stream.write_int(0)  # 0条记录
            return
        
        stream.write_int(0)  # 成功
        stream.write_int(actual_count)
        
        for i in range(int(offset), int(end)):
            for sig in self.signal_defs:
                if sig.name == 'timestamp':
                    value = float(self.timestamps[i] * 1000)  # 秒转毫秒
                else:
                    value = float(self.signals.get(sig.name, [0] * self.total_records)[i])
                self._write_value(stream, value, sig.type)
        
        stream.flush()
    
    def read_range(self, stream: BinaryStream):
        """读取指定时间范围的数据"""
        start_time = stream.read_long() / 1000.0  # 毫秒转秒
        end_time = stream.read_long() / 1000.0
        
        indices = []
        for i, ts in enumerate(self.timestamps):
            if start_time <= ts <= end_time:
                indices.append(i)
        
        stream.write_int(0)  # 成功
        stream.write_int(len(indices))
        
        for i in indices:
            for sig in self.signal_defs:
                if sig.name == 'timestamp':
                    value = float(self.timestamps[i] * 1000)
                else:
                    value = float(self.signals.get(sig.name, [0] * self.total_records)[i])
                self._write_value(stream, value, sig.type)
        
        stream.flush()
    
    def read_latest(self, stream: BinaryStream):
        """读取最新N条数据"""
        count = stream.read_int()
        
        start = max(0, self.total_records - count)
        actual_count = self.total_records - start
        
        stream.write_int(0)  # 成功
        stream.write_int(actual_count)
        
        for i in range(start, self.total_records):
            for sig in self.signal_defs:
                if sig.name == 'timestamp':
                    value = float(self.timestamps[i] * 1000)
                else:
                    value = float(self.signals.get(sig.name, [0] * self.total_records)[i])
                self._write_value(stream, value, sig.type)
        
        stream.flush()
    
    def get_time_range(self, stream: BinaryStream):
        """获取时间范围"""
        if self.timestamps is None or len(self.timestamps) == 0:
            stream.write_long(0)
            stream.write_long(0)
        else:
            min_time = int(self.timestamps[0] * 1000)
            max_time = int(self.timestamps[-1] * 1000)
            stream.write_long(min_time)
            stream.write_long(max_time)
        
        stream.flush()
    
    def get_record_count(self, stream: BinaryStream):
        """获取总记录数"""
        stream.write_long(self.total_records)
        stream.flush()
    
    def close(self):
        """关闭文件"""
        if self.mdf:
            self.mdf.close()


def main():
    parser = argparse.ArgumentParser(description='MDF4 Binary Stream Tool')
    parser.add_argument('file_path', help='MDF4 file path')
    parser.add_argument('--mode', choices=['write', 'read'], default='write')
    parser.add_argument('--append', action='store_true')
    
    args = parser.parse_args()
    
    if not ASAMMDF_AVAILABLE:
        print("ERROR: asammdf not installed", file=sys.stderr)
        sys.exit(1)
    
    # 创建二进制流
    stream = BinaryStream(
        input_stream=sys.stdin.buffer,
        output_stream=sys.stdout.buffer
    )
    
    if args.mode == 'write':
        writer = Mdf4BinaryWriter(args.file_path, append=args.append)
        
        if not writer.open():
            sys.exit(1)
        
        # 发送就绪信号
        stream.write_int(1)
        stream.flush()
        
        # 接收信号定义
        signal_count = stream.read_int()
        signal_defs = []
        
        for _ in range(signal_count):
            name = stream.read_string()
            unit = stream.read_string()
            type_ordinal = stream.read_int()
            signal_defs.append(SignalDef(name, unit, SignalType(type_ordinal)))
        
        writer.set_signal_definitions(signal_defs)
        
        try:
            while True:
                cmd = stream.read_int()
                
                if cmd == Command.WRITE_SINGLE:
                    writer.write_single(stream)
                
                elif cmd == Command.WRITE_BATCH:
                    writer.write_batch(stream)
                
                elif cmd == Command.FLUSH:
                    writer.flush()
                    stream.write_int(0)  # 成功
                    stream.flush()
                
                elif cmd == Command.CLOSE:
                    writer.close(stream)
                    break
                
                else:
                    print(f"ERROR: Unknown command {cmd}", file=sys.stderr)
                    break
        
        except (EOFError, BrokenPipeError):
            writer.close(stream)
    
    else:  # read mode
        reader = Mdf4BinaryReader(args.file_path)
        
        if not reader.open(stream):
            sys.exit(1)
        
        try:
            while True:
                cmd = stream.read_int()
                
                if cmd == Command.READ_CHUNK:
                    reader.read_chunk(stream)
                
                elif cmd == Command.READ_RANGE:
                    reader.read_range(stream)
                
                elif cmd == Command.READ_LATEST:
                    reader.read_latest(stream)
                
                elif cmd == Command.GET_RANGE:
                    reader.get_time_range(stream)
                
                elif cmd == Command.GET_COUNT:
                    reader.get_record_count(stream)
                
                elif cmd == Command.CLOSE:
                    reader.close()
                    break
                
                else:
                    print(f"ERROR: Unknown command {cmd}", file=sys.stderr)
                    break
        
        except (EOFError, BrokenPipeError):
            reader.close()


if __name__ == "__main__":
    main()
