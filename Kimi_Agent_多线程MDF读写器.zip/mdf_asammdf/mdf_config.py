# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器 - 配置模块

本模块定义了 MDF 读写器所需的所有配置参数、枚举类型和常量。
配置通过 MDFConfig 类统一管理，支持灵活的参数定制。

设计原则:
    1. 每种操作模式有独立的配置参数组
    2. 参数默认值经过生产环境验证
    3. 配置验证确保参数组合的合法性
    4. 支持序列化和反序列化，便于持久化配置

线程安全:
    本模块的类均为不可变或线程安全类型，可在多线程环境中共享。

作者: AI Assistant
版本: 2.0.0 (基于 asammdf)
日期: 2026-04-22
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List

# 配置日志
logger = logging.getLogger(__name__)


# =============================================================================
# 操作模式枚举
# =============================================================================

class OperationMode(enum.Enum):
    """
    MDF 读写器操作模式枚举

    定义三种核心操作模式，分别适用于不同的数据写入场景:

    1. NORMAL (一般模式):
       - 数据直接写入 asammdf，不经过额外缓冲
       - 适用于数据量适中、可批量准备的场景
       - 写入延迟最低，内存占用最小
       - 每次 append 调用直接触发一次磁盘 I/O

    2. FRAGMENTED (分片模式):
       - 数据先写入内存缓冲区，达到分片阈值后统一刷盘
       - 适用于大数据量场景，通过批量 I/O 提升性能
       - 可配置 fragment_size 控制分片大小
       - 内存占用中等，写入吞吐量最高

    3. STREAMING (流式模式):
       - 数据先写入内存缓冲区，达到阈值或超时时自动刷盘
       - 适用于数据采集和实时监控场景
       - 支持后台刷盘线程，写入不阻塞业务逻辑
       - 内存占用可控，延迟可控
    """
    NORMAL = "normal"           # 一般模式：直接写入
    FRAGMENTED = "fragmented"   # 分片模式：分片缓冲写入
    STREAMING = "streaming"     # 流式模式：实时流式写入


# =============================================================================
# 数据连续性枚举
# =============================================================================

class DataContinuity(enum.Enum):
    """
    数据连续性枚举

    描述通道数据的采样特征，影响数据的组织方式:

    1. CONTINUOUS (连续数据):
       - 所有通道共享同一时间基
       - 采样间隔固定，无缺失
       - 使用 append_continuous 方法写入
       - 存储效率高，所有通道打包为单条记录

    2. INTERMITTENT (间歇数据):
       - 各通道有独立的时间基
       - 采样间隔不固定，可能缺失
       - 使用 append_intermittent 方法写入
       - 每条记录包含 (timestamp, channel_name, value)
    """
    CONTINUOUS = "continuous"       # 连续数据：共享时间基
    INTERMITTENT = "intermittent"   # 间歇数据：独立时间基


# =============================================================================
# 压缩类型枚举
# =============================================================================

class CompressionType(enum.Enum):
    """
    数据压缩类型枚举

    定义 MDF 文件支持的压缩算法。压缩可减少文件大小，
    但会增加 CPU 开销。根据数据特征和性能需求选择合适的算法。

    注意:
        压缩设置仅在创建新文件时生效，追加模式使用原有设置。
    """
    NONE = "no"         # 无压缩：CPU 开销最低，文件最大
    ZIP = "zip"         # ZIP 压缩：平衡压缩比和速度
    ZSTD = "zstd"       # ZStandard 压缩：高压缩比，适合大数据


# =============================================================================
# 配置类
# =============================================================================

@dataclass
class MDFConfig:
    """
    MDF 读写器配置类

    提供全面的参数配置，控制读写器在多线程环境下的行为。
    所有参数均有经过验证的默认值。

    属性说明:
        --- 基本配置 ---
        version: MDF 文件版本，支持 "3.00"-"4.20"
        operation_mode: 操作模式，决定数据缓冲和刷盘策略
        compression: 压缩算法，减少文件大小

        --- 分片模式配置 ---
        fragment_size: 分片大小（记录数），缓冲区达到此大小后刷盘
        fragment_timeout_ms: 分片超时（毫秒），超时后强制刷盘

        --- 流式模式配置 ---
        stream_buffer_size: 流式缓冲区大小（记录数）
        stream_flush_interval_ms: 自动刷盘间隔（毫秒）
        stream_enable_background_thread: 是否启用后台刷盘线程

        --- 线程安全配置 ---
        lock_timeout_seconds: 锁超时时间（秒），防止死锁
        max_concurrent_readers: 最大并发读取线程数

        --- 性能配置 ---
        use_display_names: 是否使用显示名称
        raise_on_multiple_samples: 多个样本时是否报错
        remove_source_folder: 是否移除源文件夹

        --- 扩展配置 ---
        custom_params: 自定义参数字典，用于未来扩展

    使用示例:
        # 一般模式配置
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        # 分片模式配置
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=10000,
        )

        # 流式模式配置
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=5000,
            stream_flush_interval_ms=1000,
            stream_enable_background_thread=True,
        )

    线程安全:
        本类实例创建后不可变（frozen dataclass），可在多线程间安全共享。
    """

    # --- 基本配置 ---
    version: str = "4.10"
    """MDF 文件版本字符串。支持 "3.00" 到 "4.20"。
    版本越高功能越丰富，但兼容性可能降低。"""

    operation_mode: OperationMode = OperationMode.NORMAL
    """操作模式：NORMAL / FRAGMENTED / STREAMING。
    决定数据缓冲和刷盘策略。"""

    compression: CompressionType = CompressionType.NONE
    """压缩算法：NONE / ZIP / ZSTD。
    压缩减少文件大小但增加 CPU 开销。"""

    # --- 分片模式配置 ---
    fragment_size: int = 10000
    """分片大小，单位为记录数。
    FRAGMENTED 模式下，缓冲区积累到此数量后统一刷盘。
    较大的值提升吞吐量但增加内存占用和延迟。
    范围: 100 - 1000000"""

    fragment_timeout_ms: float = 5000.0
    """分片超时时间，单位为毫秒。
    即使缓冲区未满，超过此时间也会强制刷盘。
    防止数据在缓冲区中滞留过久。
    范围: 100 - 60000"""

    # --- 流式模式配置 ---
    stream_buffer_size: int = 5000
    """流式缓冲区大小，单位为记录数。
    STREAMING 模式下，缓冲区达到此大小后触发刷盘。
    范围: 100 - 100000"""

    stream_flush_interval_ms: float = 1000.0
    """流式自动刷盘间隔，单位为毫秒。
    STREAMING 模式下，无论缓冲区是否满，超过此间隔自动刷盘。
    范围: 100 - 60000"""

    stream_enable_background_thread: bool = True
    """是否启用后台刷盘线程。
    True: 后台线程定时刷盘，写入调用不阻塞。
    False: 写入时检查并触发刷盘，可能阻塞。
    后台线程模式推荐用于实时数据采集场景。"""

    # --- 线程安全配置 ---
    lock_timeout_seconds: float = 30.0
    """锁超时时间，单位为秒。
    获取锁超过此时间将抛出 TimeoutError。
    防止因死锁导致线程永久阻塞。
    范围: 1 - 300"""

    max_concurrent_readers: int = 10
    """最大并发读取线程数。
    用于信号量控制，防止过多读取线程影响写入性能。
    范围: 1 - 100"""

    # --- asammdf 特定配置 ---
    use_display_names: bool = True
    """是否使用通道的显示名称。"""

    raise_on_multiple_samples: bool = False
    """当通道存在多个样本时是否抛出异常。"""

    remove_source_folder: bool = False
    """保存后是否移除源文件夹（仅对 MDF 4.x 有效）。"""

    # --- 扩展配置 ---
    custom_params: Dict[str, Any] = field(default_factory=dict)
    """自定义参数字典。用于特殊需求和未来扩展。
    键值对由用户定义，不经过验证。"""

    def __post_init__(self):
        """
        配置验证与归一化

        步骤:
            1. 验证版本号格式和范围
            2. 验证数值参数的边界
            3. 确保参数组合的逻辑一致性
            4. 发出警告提示不合理的配置
        """
        # 验证版本号
        valid_versions = ["3.00", "3.10", "3.20", "3.30",
                          "4.00", "4.10", "4.11", "4.20"]
        if self.version not in valid_versions:
            raise ValueError(
                f"不支持的 MDF 版本: {self.version}. "
                f"支持的版本: {valid_versions}"
            )

        # 验证分片大小
        if self.fragment_size < 100 or self.fragment_size > 1_000_000:
            raise ValueError(
                f"fragment_size 必须在 100-1000000 范围内，"
                f"当前值: {self.fragment_size}"
            )

        # 验证超时参数
        if self.fragment_timeout_ms < 100 or self.fragment_timeout_ms > 60000:
            raise ValueError(
                f"fragment_timeout_ms 必须在 100-60000 范围内"
            )

        if self.stream_buffer_size < 10 or self.stream_buffer_size > 100_000:
            raise ValueError(
                f"stream_buffer_size 必须在 10-100000 范围内"
            )

        if self.stream_flush_interval_ms < 100 or self.stream_flush_interval_ms > 60000:
            raise ValueError(
                f"stream_flush_interval_ms 必须在 100-60000 范围内"
            )

        if self.lock_timeout_seconds < 1 or self.lock_timeout_seconds > 300:
            raise ValueError(
                f"lock_timeout_seconds 必须在 1-300 范围内"
            )

        # 检查不合理的配置组合并发出警告
        if self.operation_mode == OperationMode.NORMAL:
            if self.fragment_size != 10000:
                logger.warning(
                    "NORMAL 模式下 fragment_size 参数无效，将被忽略"
                )
            if self.stream_buffer_size != 5000:
                logger.warning(
                    "NORMAL 模式下 stream_buffer_size 参数无效，将被忽略"
                )

    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典

        返回:
            包含所有配置项的字典，枚举值转换为字符串表示

        适用:
            配置持久化、日志记录、JSON 序列化
        """
        return {
            "version": self.version,
            "operation_mode": self.operation_mode.value,
            "compression": self.compression.value,
            "fragment_size": self.fragment_size,
            "fragment_timeout_ms": self.fragment_timeout_ms,
            "stream_buffer_size": self.stream_buffer_size,
            "stream_flush_interval_ms": self.stream_flush_interval_ms,
            "stream_enable_background_thread": self.stream_enable_background_thread,
            "lock_timeout_seconds": self.lock_timeout_seconds,
            "max_concurrent_readers": self.max_concurrent_readers,
            "use_display_names": self.use_display_names,
            "raise_on_multiple_samples": self.raise_on_multiple_samples,
            "remove_source_folder": self.remove_source_folder,
            "custom_params": dict(self.custom_params),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MDFConfig":
        """
        从字典创建配置

        参数:
            data: 包含配置项的字典

        步骤:
            1. 将字符串枚举值转换为枚举对象
            2. 过滤有效字段
            3. 创建 MDFConfig 实例

        返回:
            MDFConfig 实例

        适用:
            从配置文件或序列化数据恢复配置
        """
        # 转换枚举类型
        if "operation_mode" in data and isinstance(data["operation_mode"], str):
            data["operation_mode"] = OperationMode(data["operation_mode"])
        if "compression" in data and isinstance(data["compression"], str):
            data["compression"] = CompressionType(data["compression"])

        # 过滤有效字段
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}

        return cls(**filtered)


# =============================================================================
# 通道定义类
# =============================================================================

@dataclass
class ChannelDef:
    """
    通道定义类

    封装创建 MDF 通道所需的全部信息。每个通道定义包含
    名称、单位、数据类型、注释等元数据。

    属性:
        name: 通道名称（唯一标识符）
        unit: 物理单位（如 "V", "m/s", "°C"）
        data_type: NumPy 数据类型（如 "<f4", "<u4", "<i2"）
        comment: 通道注释
        display_name: 显示名称（可选）
        conversion: 转换公式字典（可选），如 {"a": 0.1, "b": -40}

    使用示例:
        ch_temp = ChannelDef(
            name="EngineTemp",
            unit="°C",
            data_type="<f4",
            comment="发动机温度",
        )

        ch_volt = ChannelDef(
            name="BatteryVoltage",
            unit="V",
            data_type="<f4",
            conversion={"a": 0.001, "b": 0},
        )
    """

    name: str
    """通道名称。必须在同一数据组中唯一。"""

    unit: str = ""
    """物理单位。如 "V", "m/s", "rpm", "°C"。"""

    data_type: str = "<f4"
    """NumPy 数据类型字符串。
    常用值: "<f4" (float32), "<f8" (float64), "<u4" (uint32), "<i4" (int32)
    "<" 表示小端序。"""

    comment: str = ""
    """通道注释。描述通道的用途和含义。"""

    display_name: str = ""
    """显示名称。如果为空，使用 name 作为显示名称。"""

    conversion: Optional[Dict[str, float]] = None
    """线性转换公式参数。格式为 {"a": 斜率, "b": 偏移}。
    物理值 = 原始值 * a + b。
    None 表示不进行转换。"""

    def __post_init__(self):
        """
        通道定义验证

        步骤:
            1. 验证名称非空
            2. 验证数据类型格式
            3. 设置默认显示名称
        """
        if not self.name or not self.name.strip():
            raise ValueError("通道名称不能为空")

        if self.display_name == "":
            self.display_name = self.name

        # 验证数据类型格式
        import numpy as np
        try:
            np.dtype(self.data_type)
        except TypeError:
            raise ValueError(f"无效的 NumPy 数据类型: {self.data_type}")


# =============================================================================
# 统计信息类
# =============================================================================

@dataclass
class WriterStats:
    """
    写入器统计信息类

    实时追踪写入器的运行状态，用于监控和诊断。
    所有计数器使用线程安全的原子操作。

    属性:
        total_records_written: 已写入的总记录数
        total_signals_written: 已写入的总信号数
        total_flush_count: 刷盘次数
        total_bytes_written: 估计写入字节数
        buffer_records_current: 当前缓冲区记录数
        buffer_records_peak: 缓冲区记录数峰值
        last_flush_timestamp: 上次刷盘时间戳（秒）
        error_count: 错误计数
        uptime_seconds: 运行时间（秒）
    """

    total_records_written: int = 0
    total_signals_written: int = 0
    total_flush_count: int = 0
    total_bytes_estimated: int = 0
    buffer_records_current: int = 0
    buffer_records_peak: int = 0
    last_flush_timestamp: float = 0.0
    error_count: int = 0
    uptime_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """将统计信息转换为字典"""
        return {
            "total_records_written": self.total_records_written,
            "total_signals_written": self.total_signals_written,
            "total_flush_count": self.total_flush_count,
            "total_bytes_estimated": self.total_bytes_estimated,
            "buffer_records_current": self.buffer_records_current,
            "buffer_records_peak": self.buffer_records_peak,
            "last_flush_timestamp": self.last_flush_timestamp,
            "error_count": self.error_count,
            "uptime_seconds": self.uptime_seconds,
        }


@dataclass
class ReaderStats:
    """
    读取器统计信息类

    实时追踪读取器的运行状态，用于监控和诊断。

    属性:
        total_reads: 总读取次数
        total_records_read: 已读取的总记录数
        cache_hit_count: 缓存命中次数
        cache_miss_count: 缓存未命中次数
        error_count: 错误计数
        uptime_seconds: 运行时间（秒）
    """

    total_reads: int = 0
    total_records_read: int = 0
    cache_hit_count: int = 0
    cache_miss_count: int = 0
    error_count: int = 0
    uptime_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """将统计信息转换为字典"""
        return {
            "total_reads": self.total_reads,
            "total_records_read": self.total_records_read,
            "cache_hit_count": self.cache_hit_count,
            "cache_miss_count": self.cache_miss_count,
            "error_count": self.error_count,
            "uptime_seconds": self.uptime_seconds,
        }
