# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程写入器模块 (基于 asammdf)

本模块实现了生产级的多线程 MDF 文件写入器，基于 asammdf 库构建。
支持三种操作模式（NORMAL/FRAGMENTED/STREAMING），
连续和间歇数据写入，以及持久化追加功能。

架构设计:
    1. 线程安全: 使用 threading.RLock 保护所有 asammdf.MDF 操作
    2. 三种模式:
       - NORMAL:   直接写入，无额外缓冲，延迟最低
       - FRAGMENTED: 分片缓冲区，达到阈值后批量刷盘
       - STREAMING:  流式缓冲区 + 可选后台刷盘线程
    3. 连续数据: 所有通道共享同一时间基，批量打包写入
    4. 间歇数据: 各通道独立时间基，单独追加
    5. 持久化:   关闭后重新打开可继续追加

线程模型:
    - 单写入线程模型: 所有写入操作通过同一把锁串行化
    - 后台刷盘线程(STREAMING模式): 独立线程定时刷盘
    - 线程安全统计: 统计信息通过锁保护

依赖:
    - asammdf >= 8.0
    - numpy
    - pandas (可选，用于 DataFrame 写入)

作者: AI Assistant
版本: 2.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import time
import struct
import logging
import threading
from typing import Optional, Dict, List, Any, Tuple, Union
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np

# asammdf 导入
try:
    from asammdf import MDF, Signal
    from asammdf.blocks.source_utils import Source
except ImportError as e:
    raise ImportError(
        "asammdf 库未安装。请运行: pip install asammdf"
    ) from e

# 导入配置模块
from mdf_config import (
    MDFConfig, ChannelDef, WriterStats,
    OperationMode, DataContinuity, CompressionType,
)

# 配置日志
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类
# =============================================================================

class MDFWriterError(Exception):
    """MDF 写入器基础异常"""
    pass


class MDFWriterStateError(MDFWriterError):
    """状态错误异常（如关闭后操作、未初始化等）"""
    pass


class MDFWriterModeError(MDFWriterError):
    """模式不匹配异常"""
    pass


class MDFWriterValidationError(MDFWriterError):
    """数据验证错误异常"""
    pass


class MDFWriterThreadError(MDFWriterError):
    """线程相关异常（如死锁超时）"""
    pass


# =============================================================================
# 内部数据结构
# =============================================================================

@dataclass
class _ContinuousBuffer:
    """
    连续数据缓冲区（内部使用）

    用于 FRAGMENTED 和 STREAMING 模式下缓存连续数据。
    所有通道共享同一时间基，数据按列存储。

    属性:
        timestamps: 时间戳数组（所有通道共享）
        samples:    通道名 -> 样本列表的字典
        channel_defs: 通道定义列表
        record_count: 当前记录数
    """
    timestamps: List[float] = field(default_factory=list)
    samples: Dict[str, List[Any]] = field(default_factory=dict)
    channel_defs: List[ChannelDef] = field(default_factory=list)
    record_count: int = 0

    def add_record(self, timestamp: float, values: Dict[str, Any]) -> None:
        """
        添加一条连续数据记录

        参数:
            timestamp: 时间戳
            values: 通道名 -> 值的字典
        """
        self.timestamps.append(timestamp)
        for name, val in values.items():
            if name not in self.samples:
                self.samples[name] = []
            self.samples[name].append(val)
        self.record_count += 1

    def clear(self) -> None:
        """清空缓冲区"""
        self.timestamps.clear()
        self.samples.clear()
        self.record_count = 0

    def is_empty(self) -> bool:
        """检查缓冲区是否为空"""
        return self.record_count == 0


@dataclass
class _IntermittentBuffer:
    """
    间歇数据缓冲区（内部使用）

    用于 FRAGMENTED 和 STREAMING 模式下缓存间歇数据。
    每条记录包含 (timestamp, channel_name, value)。

    属性:
        records: 记录列表，每条为 (timestamp, channel_name, value) 元组
    """
    records: List[Tuple[float, str, Any]] = field(default_factory=list)

    def add_record(self, timestamp: float, channel_name: str,
                    value: Any) -> None:
        """
        添加一条间歇数据记录

        参数:
            timestamp: 时间戳
            channel_name: 通道名称
            value: 通道值
        """
        self.records.append((timestamp, channel_name, value))

    def clear(self) -> None:
        """清空缓冲区"""
        self.records.clear()

    def is_empty(self) -> bool:
        """检查缓冲区是否为空"""
        return len(self.records) == 0

    def get_record_count(self) -> int:
        """获取记录数"""
        return len(self.records)


# =============================================================================
# 主写入器类
# =============================================================================

class MDFWriter:
    """
    线程安全的 ASAM MDF 文件写入器

    基于 asammdf.MDF 构建，提供多线程安全的 MDF 文件写入功能。
    支持三种操作模式、连续/间歇数据、持久化追加。

    线程安全保证:
        - 所有公共方法使用 self._lock 进行同步
        - asammdf.MDF 对象始终通过锁保护
        - 统计信息更新通过锁保护
        - 后台刷盘线程持有锁进行刷盘操作

    使用示例:
        # 一般模式 - 批量写入
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter("output.mf4", config)
        writer.define_channels([ChannelDef("Speed", "km/h")])
        writer.append_continuous({
            "Speed": [10.0, 20.0, 30.0]
        }, timestamps=[0.0, 0.1, 0.2])
        writer.close()

        # 流式模式 - 实时写入
        config = MDFConfig(operation_mode=OperationMode.STREAMING)
        writer = MDFWriter("output.mf4", config)
        writer.define_channels([...])
        for t, data in sensor_stream:
            writer.append_continuous(data, timestamps=[t])
        writer.close()

        # 上下文管理器
        with MDFWriter("output.mf4", config) as writer:
            writer.append_continuous(...)

    属性:
        filepath: 输出文件路径
        config: MDFConfig 配置对象
        is_open: 文件是否处于打开状态
        stats: WriterStats 统计信息
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 写入器

        参数:
            filepath: 输出 MDF 文件路径
            config: MDFConfig 配置对象，None 时使用默认配置

        步骤:
            1. 保存配置参数
            2. 初始化线程锁
            3. 初始化内部状态（缓冲区、统计信息等）
            4. 创建 asammdf.MDF 对象
            5. 如果是 STREAMING 模式，启动后台刷盘线程

        异常:
            MDFWriterModeError: 不支持的配置组合
            ImportError: asammdf 库未安装
        """
        # 步骤 1: 保存配置
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath

        # 步骤 2: 初始化线程锁
        # 使用 RLock 允许同一线程多次获取锁（防止死锁）
        self._lock: threading.RLock = threading.RLock()

        # 步骤 3: 初始化内部状态
        self._is_open: bool = False
        self._is_finalized: bool = False
        self._channel_defs: List[ChannelDef] = []
        self._channels_defined: bool = False

        # 模式相关状态
        self._continuity: DataContinuity = DataContinuity.CONTINUOUS
        self._cont_buffer: _ContinuousBuffer = _ContinuousBuffer()
        self._inter_buffer: _IntermittentBuffer = _IntermittentBuffer()

        # 刷盘控制
        self._last_flush_time: float = 0.0
        self._flush_requested: bool = False

        # 后台线程
        self._bg_thread: Optional[threading.Thread] = None
        self._bg_stop_event: threading.Event = threading.Event()

        # asammdf 对象
        self._mdf: Optional[MDF] = None

        # 统计信息
        self.stats: WriterStats = WriterStats()
        self._start_time: float = time.time()

        # 步骤 4: 创建 asammdf.MDF 对象
        self._create_mdf()

        # 步骤 5: STREAMING 模式下启动后台刷盘线程
        if self.config.operation_mode == OperationMode.STREAMING:
            if self.config.stream_enable_background_thread:
                self._start_background_thread()

        self._is_open = True
        logger.info(
            f"MDFWriter 初始化完成: filepath={filepath}, "
            f"mode={self.config.operation_mode.value}, "
            f"version={self.config.version}"
        )

    # ======================================================================
    # 属性访问
    # ======================================================================

    @property
    def is_open(self) -> bool:
        """文件是否处于打开状态"""
        return self._is_open

    # ======================================================================
    # MDF 对象管理
    # ======================================================================

    def _create_mdf(self) -> None:
        """
        创建或加载 asammdf.MDF 对象

        步骤:
            1. 检查文件是否已存在且为非空有效文件
            2. 如果存在且有效，打开已有文件以便追加数据组
            3. 如果不存在或为空/无效，创建新的 MDF 对象

        异常:
            MDFWriterError: 创建失败

        注意:
            当文件已存在且有效时，asammdf 的 MDF(filepath) 会加载已有文件，
            允许通过 append() 追加新数据组。保存时使用 overwrite=True
            覆盖为包含新数据的版本。
            
            文件有效性检查通过文件大小判断（MDF 最小文件大小为 64 字节的 ID 块）。
            空文件或大小小于 64 字节的文件将被视为无效，创建新 MDF。
        """
        try:
            file_exists = os.path.exists(self.filepath)
            file_valid = (file_exists and os.path.getsize(self.filepath) >= 64)

            if file_valid:
                # 文件已存在且有效，加载以便追加
                self._mdf = MDF(self.filepath)
                logger.debug(f"已加载现有 MDF 文件: {self.filepath}")
            else:
                # 文件不存在或无效，创建新的 MDF 对象
                self._mdf = MDF(version=self.config.version)
                logger.debug(f"asammdf.MDF 对象创建完成，版本: {self.config.version}")
        except Exception as e:
            raise MDFWriterError(f"创建/加载 MDF 对象失败: {e}") from e

    def _save_mdf(self) -> None:
        """
        保存 MDF 文件到磁盘

        步骤:
            1. 确保目标目录存在
            2. 将 CompressionType 枚举映射为 asammdf CompressionAlgorithm 枚举
            3. 调用 asammdf.MDF.save() 保存

        异常:
            MDFWriterError: 保存失败

        注意:
            asammdf 的 compression 参数期望 v4c.CompressionAlgorithm 枚举值，
            而非字符串。本方法负责类型转换。
        """
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.filepath)) or ".", exist_ok=True)

            # 步骤 2: 将 CompressionType 映射为 asammdf CompressionAlgorithm
            from asammdf.blocks.v4_constants import CompressionAlgorithm
            compression_map = {
                CompressionType.NONE: CompressionAlgorithm.NO_COMPRESSION,
                CompressionType.ZIP: CompressionAlgorithm.DEFLATE,
                CompressionType.ZSTD: CompressionAlgorithm.ZSTD,
            }
            compression = compression_map.get(
                self.config.compression, CompressionAlgorithm.NO_COMPRESSION
            )

            self._mdf.save(self.filepath, overwrite=True, compression=compression)
            logger.debug(f"MDF 文件已保存: {self.filepath}")
        except Exception as e:
            raise MDFWriterError(f"保存 MDF 文件失败: {e}") from e

    # ======================================================================
    # 后台刷盘线程 (STREAMING 模式)
    # ======================================================================

    def _start_background_thread(self) -> None:
        """
        启动后台刷盘线程

        步骤:
            1. 创建后台线程
            2. 设置为守护线程
            3. 启动线程

        后台线程行为:
            - 定期检查缓冲区状态
            - 超过刷盘间隔或缓冲区满时自动刷盘
            - 收到停止信号时退出
        """
        self._bg_stop_event.clear()
        self._bg_thread = threading.Thread(
            target=self._background_flush_loop,
            name="MDFWriter-BackgroundFlush",
            daemon=True,
        )
        self._bg_thread.start()
        logger.debug("后台刷盘线程已启动")

    def _background_flush_loop(self) -> None:
        """
        后台刷盘线程主循环

        步骤:
            1. 等待停止信号或超时
            2. 超时后检查缓冲区状态
            3. 如果需要刷盘，获取锁并执行刷盘
            4. 重复直到收到停止信号

        异常处理:
            捕获所有异常并记录日志，不终止线程
        """
        interval_s = self.config.stream_flush_interval_ms / 1000.0

        while not self._bg_stop_event.is_set():
            try:
                # 等待停止信号或超时
                stopped = self._bg_stop_event.wait(timeout=interval_s)
                if stopped:
                    break

                # 检查是否需要刷盘
                with self._lock:
                    if not self._is_open:
                        break

                    current_time = time.time()
                    time_since_flush = (current_time - self._last_flush_time) * 1000

                    need_flush = (
                        self._cont_buffer.record_count >= self.config.stream_buffer_size
                        or time_since_flush >= self.config.stream_flush_interval_ms
                    )

                    if need_flush and not self._cont_buffer.is_empty():
                        self._do_flush_continuous()

                    if not self._inter_buffer.is_empty():
                        self._do_flush_intermittent()

            except Exception as e:
                logger.error(f"后台刷盘线程异常: {e}", exc_info=True)
                self.stats.error_count += 1

        logger.debug("后台刷盘线程已退出")

    def _stop_background_thread(self) -> None:
        """
        停止后台刷盘线程

        步骤:
            1. 设置停止信号
            2. 等待线程退出（带超时）
        """
        if self._bg_thread and self._bg_thread.is_alive():
            self._bg_stop_event.set()
            self._bg_thread.join(timeout=5.0)
            if self._bg_thread.is_alive():
                logger.warning("后台刷盘线程未在超时内退出")
            self._bg_thread = None

    # ======================================================================
    # 通道定义
    # ======================================================================

    def define_channels(self, channels: List[ChannelDef],
                         continuity: DataContinuity = DataContinuity.CONTINUOUS) -> None:
        """
        定义通道布局

        参数:
            channels: 通道定义列表
            continuity: 数据连续性类型，默认 CONTINUOUS

        步骤:
            1. 验证文件处于打开状态
            2. 验证通道列表非空
            3. 验证通道名称唯一性
            4. 保存通道定义和连续性类型
            5. 初始化连续数据缓冲区的样本字典

        异常:
            MDFWriterStateError: 文件未打开
            MDFWriterValidationError: 通道定义无效

        适用:
            写入数据前必须先调用此方法定义通道布局。
            可以多次调用以定义新的数据组。
        """
        with self._lock:
            # 步骤 1: 验证状态
            if not self._is_open:
                raise MDFWriterStateError("文件未打开，无法定义通道")

            # 步骤 2: 验证通道列表
            if not channels:
                raise MDFWriterValidationError("通道列表不能为空")

            # 步骤 3: 验证通道名称唯一性
            names = [ch.name for ch in channels]
            if len(names) != len(set(names)):
                raise MDFWriterValidationError("通道名称必须唯一")

            # 步骤 4: 保存通道定义
            self._channel_defs = list(channels)
            self._channels_defined = True
            self._continuity = continuity

            # 步骤 5: 初始化缓冲区
            self._cont_buffer.channel_defs = self._channel_defs
            for ch in channels:
                if ch.name not in self._cont_buffer.samples:
                    self._cont_buffer.samples[ch.name] = []

            logger.info(
                f"通道定义完成: {len(channels)} 个通道, "
                f"连续性: {continuity.value}"
            )

    # ======================================================================
    # 连续数据写入
    # ======================================================================

    def append_continuous(self, values: Dict[str, List[Any]],
                           timestamps: List[float]) -> int:
        """
        追加连续数据样本（多通道共享时间基）

        参数:
            values: 通道名 -> 样本列表的字典
            timestamps: 时间戳列表（与样本列表等长）

        返回:
            写入的记录数

        步骤:
            1. 验证状态（文件打开、通道已定义）
            2. 验证数据（长度匹配、通道存在）
            3. 根据模式选择写入策略:
               - NORMAL: 直接写入 asammdf
               - FRAGMENTED/STREAMING: 写入缓冲区，必要时刷盘
            4. 更新统计信息

        异常:
            MDFWriterStateError: 文件未打开或通道未定义
            MDFWriterValidationError: 数据格式无效

        适用:
            连续采样场景，所有通道共享同一时间基。
            每次调用可写入一个或多个时间点的数据。

        示例:
            writer.append_continuous({
                "Speed": [10.0, 20.0, 30.0],
                "RPM": [1000, 2000, 3000],
            }, timestamps=[0.0, 0.1, 0.2])
        """
        with self._lock:
            # 步骤 1: 验证状态
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            if not self._channels_defined:
                raise MDFWriterStateError("通道未定义，请先调用 define_channels")

            # 步骤 2: 验证数据
            record_count = len(timestamps)
            if record_count == 0:
                return 0

            for name, samples in values.items():
                if len(samples) != record_count:
                    raise MDFWriterValidationError(
                        f"通道 {name} 的样本数 ({len(samples)}) "
                        f"与时间戳数 ({record_count}) 不匹配"
                    )

            # 步骤 3: 根据模式写入
            if self.config.operation_mode == OperationMode.NORMAL:
                self._write_direct_continuous(values, timestamps)
            else:
                self._write_buffered_continuous(values, timestamps)

            # 步骤 4: 更新统计
            self.stats.total_records_written += record_count
            self.stats.total_signals_written += len(values)

            return record_count

    def _write_direct_continuous(self, values: Dict[str, List[Any]],
                                  timestamps: List[float]) -> None:
        """
        直接写入连续数据（NORMAL 模式）

        参数:
            values: 通道名 -> 样本列表
            timestamps: 时间戳列表

        步骤:
            1. 为每个通道创建 asammdf.Signal 对象
            2. 调用 asammdf.MDF.append() 写入
        """
        signals = self._create_signals(values, timestamps)
        self._mdf.append(signals)
        self._last_flush_time = time.time()

    def _write_buffered_continuous(self, values: Dict[str, List[Any]],
                                    timestamps: List[float]) -> None:
        """
        缓冲写入连续数据（FRAGMENTED/STREAMING 模式）

        参数:
            values: 通道名 -> 样本列表
            timestamps: 时间戳列表

        步骤:
            1. 将数据追加到缓冲区
            2. 检查是否需要刷盘
            3. 如果需要，执行刷盘
        """
        # 步骤 1: 追加到缓冲区
        for i, ts in enumerate(timestamps):
            record_values = {name: vals[i] for name, vals in values.items()}
            self._cont_buffer.add_record(ts, record_values)

        # 更新当前缓冲区记录数
        self.stats.buffer_records_current = self._cont_buffer.record_count
        self.stats.buffer_records_peak = max(
            self.stats.buffer_records_peak,
            self.stats.buffer_records_current
        )

        # 步骤 2-3: 检查刷盘条件
        self._check_and_flush_continuous()

    def _check_and_flush_continuous(self) -> None:
        """
        检查并执行连续数据刷盘

        判断条件:
            - FRAGMENTED 模式: 缓冲区记录数 >= fragment_size
            - STREAMING 模式(无后台线程): 缓冲区记录数 >= stream_buffer_size
              或超过 flush_interval
        """
        if self._cont_buffer.is_empty():
            return

        need_flush = False

        if self.config.operation_mode == OperationMode.FRAGMENTED:
            if self._cont_buffer.record_count >= self.config.fragment_size:
                need_flush = True
        elif self.config.operation_mode == OperationMode.STREAMING:
            if not self.config.stream_enable_background_thread:
                if self._cont_buffer.record_count >= self.config.stream_buffer_size:
                    need_flush = True
                else:
                    elapsed_ms = (time.time() - self._last_flush_time) * 1000
                    if elapsed_ms >= self.config.stream_flush_interval_ms:
                        need_flush = True

        if need_flush:
            self._do_flush_continuous()

    def _do_flush_continuous(self) -> None:
        """
        执行连续数据刷盘（内部方法，调用者必须已持有锁）

        步骤:
            1. 将缓冲区数据转换为 asammdf.Signal 列表
            2. 调用 asammdf.MDF.append() 写入
            3. 清空缓冲区
            4. 更新统计信息
        """
        if self._cont_buffer.is_empty():
            return

        try:
            # 步骤 1: 转换为 Signal
            timestamps = self._cont_buffer.timestamps
            values = self._cont_buffer.samples
            signals = self._create_signals(values, timestamps)

            # 步骤 2: 写入
            self._mdf.append(signals)

            # 步骤 3: 清空缓冲区
            record_count = self._cont_buffer.record_count
            self._cont_buffer.clear()
            self.stats.buffer_records_current = 0

            # 步骤 4: 更新统计
            self.stats.total_flush_count += 1
            self.stats.last_flush_timestamp = time.time()
            self._last_flush_time = time.time()

            logger.debug(f"连续数据刷盘完成: {record_count} 条记录")

        except Exception as e:
            logger.error(f"连续数据刷盘失败: {e}", exc_info=True)
            self.stats.error_count += 1
            raise

    def _create_signals(self, values: Dict[str, List[Any]],
                         timestamps: List[float]) -> List[Signal]:
        """
        将数据字典转换为 asammdf.Signal 列表

        参数:
            values: 通道名 -> 样本列表
            timestamps: 时间戳列表

        步骤:
            1. 查找通道定义获取单位
            2. 将样本列表转为 numpy 数组
            3. 创建 Signal 对象

        返回:
            Signal 对象列表
        """
        signals = []
        ts_array = np.array(timestamps, dtype=np.float64)

        for name, samples in values.items():
            # 查找通道定义
            unit = ""
            for ch in self._channel_defs:
                if ch.name == name:
                    unit = ch.unit
                    break

            # 转换为 numpy 数组
            sample_array = np.array(samples)

            sig = Signal(
                samples=sample_array,
                timestamps=ts_array,
                name=name,
                unit=unit,
            )
            signals.append(sig)

        return signals

    # ======================================================================
    # 间歇数据写入
    # ======================================================================

    def append_intermittent(self, channel_name: str,
                             timestamp: float, value: Any) -> None:
        """
        追加间歇数据样本（单通道，独立时间基）

        参数:
            channel_name: 通道名称
            timestamp: 时间戳
            value: 通道值

        步骤:
            1. 验证状态
            2. 验证通道存在
            3. 根据模式选择写入策略:
               - NORMAL: 立即写入
               - FRAGMENTED/STREAMING: 写入缓冲区

        异常:
            MDFWriterStateError: 文件未打开或通道未定义
            MDFWriterValidationError: 通道不存在

        适用:
            间歇/事件触发采样，每次只写入一个通道的值。
            各通道有独立的时间基，不要求同步。

        示例:
            writer.append_intermittent("EventCode", 1.5, 1001)
            writer.append_intermittent("ErrorFlag", 2.3, True)
        """
        with self._lock:
            # 步骤 1: 验证状态
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            if not self._channels_defined:
                raise MDFWriterStateError("通道未定义")

            # 步骤 2: 验证通道
            channel_names = {ch.name for ch in self._channel_defs}
            if channel_name not in channel_names:
                raise MDFWriterValidationError(
                    f"通道 '{channel_name}' 未定义。"
                    f"已定义通道: {sorted(channel_names)}"
                )

            # 步骤 3: 根据模式写入
            if self.config.operation_mode == OperationMode.NORMAL:
                self._write_direct_intermittent(channel_name, timestamp, value)
            else:
                self._write_buffered_intermittent(channel_name, timestamp, value)

    def _write_direct_intermittent(self, channel_name: str,
                                    timestamp: float, value: Any) -> None:
        """
        直接写入间歇数据（NORMAL 模式）

        参数:
            channel_name: 通道名称
            timestamp: 时间戳
            value: 通道值

        步骤:
            1. 查找通道定义获取单位
            2. 将数据转换为 numpy 数组（确保类型正确）
            3. 创建 Signal 对象
            4. 写入 asammdf
        """
        unit = ""
        dtype = "<f4"
        for ch in self._channel_defs:
            if ch.name == channel_name:
                unit = ch.unit
                dtype = ch.data_type
                break

        # 步骤 2: 根据数据类型转换值
        try:
            sample_array = np.array([value], dtype=np.dtype(dtype))
        except (TypeError, ValueError):
            sample_array = np.array([value])

        sig = Signal(
            samples=sample_array,
            timestamps=np.array([timestamp], dtype=np.float64),
            name=channel_name,
            unit=unit,
        )
        self._mdf.append([sig])

    def _write_buffered_intermittent(self, channel_name: str,
                                      timestamp: float, value: Any) -> None:
        """
        缓冲写入间歇数据（FRAGMENTED/STREAMING 模式）

        参数:
            channel_name: 通道名称
            timestamp: 时间戳
            value: 通道值

        步骤:
            1. 追加到间歇缓冲区
            2. 检查是否需要刷盘
        """
        self._inter_buffer.add_record(timestamp, channel_name, value)

        # 检查刷盘条件
        self._check_and_flush_intermittent()

    def _check_and_flush_intermittent(self) -> None:
        """
        检查并执行间歇数据刷盘

        判断条件:
            - FRAGMENTED 模式: 累积一定数量后刷盘
            - STREAMING 模式: 后台线程处理
        """
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            if self._inter_buffer.get_record_count() >= self.config.fragment_size:
                self._do_flush_intermittent()

    def _do_flush_intermittent(self) -> None:
        """
        执行间歇数据刷盘（内部方法，调用者必须已持有锁）

        步骤:
            1. 按通道分组
            2. 为每组创建 Signal
            3. 写入 asammdf
            4. 清空缓冲区
        """
        if self._inter_buffer.is_empty():
            return

        try:
            # 步骤 1: 按通道分组
            channel_data: Dict[str, Tuple[List[float], List[Any]]] = {}
            for ts, name, val in self._inter_buffer.records:
                if name not in channel_data:
                    channel_data[name] = ([], [])
                channel_data[name][0].append(ts)
                channel_data[name][1].append(val)

            # 步骤 2-3: 为每组创建 Signal 并写入
            for name, (timestamps, samples) in channel_data.items():
                unit = ""
                for ch in self._channel_defs:
                    if ch.name == name:
                        unit = ch.unit
                        break

                sig = Signal(
                    samples=np.array(samples),
                    timestamps=np.array(timestamps, dtype=np.float64),
                    name=name,
                    unit=unit,
                )
                self._mdf.append([sig])

            # 步骤 4: 清空缓冲区
            self._inter_buffer.clear()
            self.stats.total_flush_count += 1
            self.stats.last_flush_timestamp = time.time()

        except Exception as e:
            logger.error(f"间歇数据刷盘失败: {e}", exc_info=True)
            self.stats.error_count += 1
            raise

    # ======================================================================
    # 手动刷盘
    # ======================================================================

    def flush(self) -> None:
        """
        手动刷盘所有缓冲区数据

        步骤:
            1. 获取锁
            2. 刷盘连续数据缓冲区
            3. 刷盘间歇数据缓冲区
            4. 保存 MDF 文件

        适用:
            - 确保数据持久化到磁盘
            - 切换操作模式前
            - 关闭前自动调用
        """
        with self._lock:
            if not self._is_open:
                return

            logger.debug("手动刷盘开始...")

            # 刷盘连续数据
            self._do_flush_continuous()

            # 刷盘间歇数据
            self._do_flush_intermittent()

            # 保存文件
            self._save_mdf()

            logger.debug("手动刷盘完成")

    # ======================================================================
    # 关闭与资源释放
    # ======================================================================

    def close(self) -> None:
        """
        关闭写入器并释放所有资源

        步骤:
            1. 获取锁
            2. 停止后台刷盘线程
            3. 刷盘剩余缓冲区数据
            4. 保存 MDF 文件
            5. 关闭 asammdf.MDF 对象
            6. 清理内部状态

        适用:
            完成所有写入操作后必须调用此方法。
            使用上下文管理器可自动调用。
        """
        with self._lock:
            if not self._is_open:
                return

            logger.info("关闭 MDFWriter...")

            try:
                # 步骤 2: 停止后台线程
                self._stop_background_thread()

                # 步骤 3: 刷盘剩余数据
                self._do_flush_continuous()
                self._do_flush_intermittent()

                # 步骤 4: 保存文件
                self._save_mdf()

                # 步骤 5: 关闭 asammdf
                if self._mdf:
                    self._mdf.close()
                    self._mdf = None

                # 步骤 6: 更新状态
                self._is_open = False
                self._is_finalized = True
                self.stats.uptime_seconds = time.time() - self._start_time

                logger.info(
                    f"MDFWriter 已关闭。统计: "
                    f"records={self.stats.total_records_written}, "
                    f"flushes={self.stats.total_flush_count}, "
                    f"errors={self.stats.error_count}"
                )

            except Exception as e:
                logger.error(f"关闭 MDFWriter 时出错: {e}", exc_info=True)
                self.stats.error_count += 1
                raise

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器出口

        确保即使发生异常也会关闭资源。
        """
        try:
            self.close()
        except Exception as e:
            logger.error(f"上下文退出时关闭失败: {e}")
        return False

    # ======================================================================
    # 信息查询
    # ======================================================================

    def get_info(self) -> Dict[str, Any]:
        """
        获取写入器状态信息

        返回:
            包含文件路径、模式、统计信息等的字典

        适用:
            监控和日志记录
        """
        with self._lock:
            info = {
                "filepath": self.filepath,
                "version": self.config.version,
                "operation_mode": self.config.operation_mode.value,
                "compression": self.config.compression.value,
                "continuity": self._continuity.value,
                "is_open": self._is_open,
                "channels_defined": self._channels_defined,
                "channel_count": len(self._channel_defs),
                "channel_names": [ch.name for ch in self._channel_defs],
                "stats": self.stats.to_dict(),
            }
            return info

    def get_channel_names(self) -> List[str]:
        """
        获取已定义的通道名称列表

        返回:
            通道名称列表
        """
        with self._lock:
            return [ch.name for ch in self._channel_defs]


# =============================================================================
# 追加模式写入器
# =============================================================================

class MDFAppendWriter(MDFWriter):
    """
    追加模式 MDF 写入器

    继承自 MDFWriter，支持打开已有 MDF 文件并在末尾追加数据。
    保留原有通道定义和数据，新数据以新的数据组形式追加。

    使用示例:
        # 第一次创建文件
        with MDFWriter("data.mf4", config) as w:
            w.define_channels([ChannelDef("Speed", "km/h")])
            w.append_continuous({"Speed": [10, 20]}, [0.0, 0.1])

        # 追加数据
        with MDFAppendWriter("data.mf4", config) as w:
            w.define_channels([ChannelDef("Speed", "km/h")])
            w.append_continuous({"Speed": [30, 40]}, [0.2, 0.3])

    线程安全:
        与 MDFWriter 相同，所有操作通过锁同步。
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化追加模式写入器

        参数:
            filepath: 已有 MDF 文件路径
            config: MDFConfig 配置对象

        步骤:
            1. 验证文件存在
            2. 调用父类初始化
            3. 加载已有文件
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"追加文件不存在: {filepath}")

        # 保存配置（不创建新 MDF）
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath
        self._lock: threading.RLock = threading.RLock()
        self._is_open: bool = False
        self._is_finalized: bool = False
        self._channel_defs: List[ChannelDef] = []
        self._channels_defined: bool = False
        self._continuity: DataContinuity = DataContinuity.CONTINUOUS
        self._cont_buffer: _ContinuousBuffer = _ContinuousBuffer()
        self._inter_buffer: _IntermittentBuffer = _IntermittentBuffer()
        self._last_flush_time: float = 0.0
        self._bg_thread: Optional[threading.Thread] = None
        self._bg_stop_event: threading.Event = threading.Event()
        self._mdf: Optional[MDF] = None
        self.stats: WriterStats = WriterStats()
        self._start_time: float = time.time()

        # 加载已有文件
        self._load_existing_mdf()

        # 启动后台线程
        if self.config.operation_mode == OperationMode.STREAMING:
            if self.config.stream_enable_background_thread:
                self._start_background_thread()

        self._is_open = True
        logger.info(f"MDFAppendWriter 初始化完成: {filepath}")

    def _create_mdf(self) -> None:
        """追加模式下不重写此方法，使用 _load_existing_mdf"""
        pass

    def _load_existing_mdf(self) -> None:
        """
        加载已有的 MDF 文件

        步骤:
            1. 使用 asammdf.MDF 打开文件
            2. 保留原有结构和数据
        """
        try:
            self._mdf = MDF(self.filepath)
            logger.debug(f"已加载 MDF 文件: {self.filepath}")
        except Exception as e:
            raise MDFWriterError(f"加载 MDF 文件失败: {e}") from e


__all__ = [
    "MDFWriter", "MDFAppendWriter",
    "MDFWriterError", "MDFWriterStateError",
    "MDFWriterModeError", "MDFWriterValidationError",
    "MDFWriterThreadError",
]
