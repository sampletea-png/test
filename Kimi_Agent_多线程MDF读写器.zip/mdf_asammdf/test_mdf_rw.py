# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器综合测试模块

本测试模块对基于 asammdf 的 MDF 读写器进行全面的功能验证，
覆盖以下场景:
    1. 配置验证测试
    2. 一般模式 (NORMAL): 直接写入读取
    3. 分片模式 (FRAGMENTED): 分片缓冲写入读取
    4. 流式模式 (STREAMING): 流式缓冲写入读取
    5. 连续数据 (CONTINUOUS): 共享时间基
    6. 间歇数据 (INTERMITTENT): 独立时间基
    7. 持久化追加: 关闭后重新打开继续写入
    8. 多线程并发: 多线程同时写入/读取
    9. 压缩测试: ZIP/ZSTD 压缩
    10. 边界条件: 空数据、大数据量等
    11. 迭代器读取: 内存高效的大数据读取

运行方式:
    python -m pytest test_mdf_rw.py -v
    python test_mdf_rw.py

作者: AI Assistant
版本: 2.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import sys
import time
import struct
import tempfile
import unittest
import logging
import threading
import concurrent.futures
from typing import List, Dict, Any

import numpy as np

# 导入被测试模块
from mdf_config import (
    MDFConfig, ChannelDef, WriterStats, ReaderStats,
    OperationMode, DataContinuity, CompressionType,
)
from mdf_writer import (
    MDFWriter, MDFAppendWriter,
    MDFWriterError, MDFWriterStateError, MDFWriterValidationError,
)
from mdf_reader import (
    MDFReader,
    MDFReaderError, MDFReaderNotFoundError, MDFReaderStateError,
)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


# =============================================================================
# 测试工具函数
# =============================================================================

def create_temp_filepath(suffix: str = ".mf4") -> str:
    """
    创建临时文件路径

    参数:
        suffix: 文件后缀

    返回:
        临时文件的绝对路径
    """
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    return path


def cleanup_file(filepath: str) -> None:
    """
    清理临时文件

    参数:
        filepath: 要删除的文件路径
    """
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception as e:
        logger.warning(f"清理文件失败: {filepath}, 错误: {e}")


def generate_continuous_data(num_records: int, channel_names: List[str]
                              ) -> tuple[Dict[str, List[float]], List[float]]:
    """
    生成连续测试数据

    参数:
        num_records: 记录数量
        channel_names: 通道名称列表

    返回:
        (values, timestamps) 元组
    """
    timestamps = [i * 0.01 for i in range(num_records)]
    values = {}
    for i, name in enumerate(channel_names):
        values[name] = [float(j * 10 + i) for j in range(num_records)]
    return values, timestamps


# =============================================================================
# 配置测试
# =============================================================================

class TestMDFConfig(unittest.TestCase):
    """配置类测试"""

    def test_default_config(self):
        """
        默认配置测试

        步骤:
            1. 创建默认配置
            2. 验证各参数的默认值
        """
        config = MDFConfig()
        self.assertEqual(config.version, "4.10")
        self.assertEqual(config.operation_mode, OperationMode.NORMAL)
        self.assertEqual(config.compression, CompressionType.NONE)
        self.assertEqual(config.fragment_size, 10000)
        self.assertEqual(config.stream_buffer_size, 5000)

    def test_config_validation_version(self):
        """
        版本号验证测试

        步骤:
            1. 测试无效版本号
            2. 验证抛出 ValueError
        """
        with self.assertRaises(ValueError):
            MDFConfig(version="9.99")

    def test_config_validation_fragment_size(self):
        """
        分片大小验证测试

        步骤:
            1. 测试过小的 fragment_size
            2. 测试过大的 fragment_size
            3. 验证抛出 ValueError
        """
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=50)
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=2_000_000)

    def test_config_serialization(self):
        """
        配置序列化测试

        步骤:
            1. 创建配置
            2. 转换为字典
            3. 从字典恢复
            4. 验证一致性
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            compression=CompressionType.ZIP,
            fragment_size=5000,
        )
        d = config.to_dict()
        restored = MDFConfig.from_dict(d)
        self.assertEqual(restored.operation_mode, OperationMode.FRAGMENTED)
        self.assertEqual(restored.compression, CompressionType.ZIP)
        self.assertEqual(restored.fragment_size, 5000)

    def test_channel_def_validation(self):
        """
        通道定义验证测试

        步骤:
            1. 测试空名称
            2. 测试无效数据类型
        """
        with self.assertRaises(ValueError):
            ChannelDef(name="")

        with self.assertRaises(ValueError):
            ChannelDef(name="Test", data_type="invalid_type")


# =============================================================================
# 一般模式写入器测试
# =============================================================================

class TestMDFWriterNormal(unittest.TestCase):
    """一般模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_normal_continuous_write_read(self):
        """
        一般模式连续数据写入读取测试

        步骤:
            1. 创建一般模式写入器
            2. 定义通道
            3. 写入连续数据
            4. 关闭写入器
            5. 打开读取器
            6. 读取并验证数据
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef(name="Speed", unit="km/h", data_type="<f4"),
            ChannelDef(name="RPM", unit="rpm", data_type="<f4"),
        ]

        # 写入
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels, DataContinuity.CONTINUOUS)
            values, timestamps = generate_continuous_data(100, ["Speed", "RPM"])
            writer.append_continuous(values, timestamps)

        # 读取验证
        with MDFReader(self.temp_file) as reader:
            sig_speed = reader.get_channel("Speed")
            sig_rpm = reader.get_channel("RPM")

            self.assertEqual(len(sig_speed.samples), 100)
            self.assertEqual(len(sig_rpm.samples), 100)
            self.assertEqual(str(sig_speed.unit), "km/h")
            self.assertEqual(str(sig_rpm.unit), "rpm")

    def test_normal_multiple_appends(self):
        """
        一般模式多次追加测试

        步骤:
            1. 分多次写入数据
            2. 验证所有数据完整
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Counter", data_type="<u4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            for batch in range(5):
                values = {"Counter": list(range(batch * 20, (batch + 1) * 20))}
                timestamps = [i * 0.1 for i in range(batch * 20, (batch + 1) * 20)]
                writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Counter")
            self.assertEqual(len(sig.samples), 100)

    def test_normal_empty_data(self):
        """
        一般模式空数据测试

        步骤:
            1. 定义通道
            2. 写入空数据
            3. 验证不报错
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Empty", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous({"Empty": []}, [])

    def test_normal_intermittent_data(self):
        """
        一般模式间歇数据测试

        步骤:
            1. 定义通道
            2. 使用 append_intermittent 写入
            3. 验证数据
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef(name="EventA", data_type="<u4"),
            ChannelDef(name="EventB", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(20):
                writer.append_intermittent("EventA", float(i) * 0.5, i * 10)

        with MDFReader(self.temp_file) as reader:
            names = reader.get_channel_names()
            self.assertIn("EventA", names)

    def test_writer_state_error(self):
        """
        写入器状态错误测试

        步骤:
            1. 未定义通道时写入
            2. 验证抛出异常
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter(self.temp_file, config)
        with self.assertRaises(MDFWriterStateError):
            writer.append_continuous({"X": [1.0]}, [0.0])
        writer.close()

    def test_writer_validation_error(self):
        """
        写入器验证错误测试

        步骤:
            1. 样本数与时间戳数不匹配
            2. 验证抛出异常
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="X", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            with self.assertRaises(MDFWriterValidationError):
                writer.append_continuous({"X": [1.0, 2.0]}, [0.0])


# =============================================================================
# 分片模式写入器测试
# =============================================================================

class TestMDFWriterFragmented(unittest.TestCase):
    """分片模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_fragmented_basic(self):
        """
        分片模式基本测试

        步骤:
            1. 创建分片模式写入器
            2. 写入大量数据（超过分片大小）
            3. 验证分片产生和数据完整
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=100,
        )
        channels = [
            ChannelDef(name="Sig1", data_type="<f4"),
            ChannelDef(name="Sig2", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(200, ["Sig1", "Sig2"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            sig1 = reader.get_channel("Sig1")
            sig2 = reader.get_channel("Sig2")
            self.assertEqual(len(sig1.samples), 200)
            self.assertEqual(len(sig2.samples), 200)

    def test_fragmented_flush_count(self):
        """
        分片模式刷盘次数测试

        步骤:
            1. 分多次写入数据
            2. 验证刷盘次数 >= 预期值
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=100,
        )
        channels = [ChannelDef(name="Data", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            # 分 4 次写入，每次 50 条，缓冲区累计到 100 条时刷盘
            for batch in range(4):
                values, timestamps = generate_continuous_data(50, ["Data"])
                timestamps = [t + batch * 0.5 for t in timestamps]
                writer.append_continuous(values, timestamps)
            # 至少刷盘 1 次（缓冲区达到 100 条时）
            self.assertGreaterEqual(writer.stats.total_flush_count, 1)

    def test_fragmented_manual_flush(self):
        """
        分片模式手动刷盘测试

        步骤:
            1. 写入部分数据
            2. 手动调用 flush
            3. 继续写入
            4. 验证所有数据完整
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=10000,  # 大分片，不自动触发
        )
        channels = [ChannelDef(name="Signal", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(50, ["Signal"])
            writer.append_continuous(values, timestamps)
            writer.flush()
            values2, timestamps2 = generate_continuous_data(50, ["Signal"])
            # 调整时间戳避免重复
            timestamps2 = [t + 1.0 for t in timestamps2]
            writer.append_continuous(values2, timestamps2)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Signal")
            self.assertEqual(len(sig.samples), 100)


# =============================================================================
# 流式模式写入器测试
# =============================================================================

class TestMDFWriterStreaming(unittest.TestCase):
    """流式模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_streaming_basic(self):
        """
        流式模式基本测试（无后台线程）

        步骤:
            1. 创建流式模式写入器
            2. 分多次追加数据
            3. 验证所有数据完整
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=50,
            stream_enable_background_thread=False,
        )
        channels = [
            ChannelDef(name="Stream1", data_type="<f4"),
            ChannelDef(name="Stream2", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            for batch in range(5):
                values, timestamps = generate_continuous_data(20, ["Stream1", "Stream2"])
                timestamps = [t + batch * 0.2 for t in timestamps]
                writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            s1 = reader.get_channel("Stream1")
            s2 = reader.get_channel("Stream2")
            self.assertEqual(len(s1.samples), 100)
            self.assertEqual(len(s2.samples), 100)

    def test_streaming_background_thread(self):
        """
        流式模式后台线程测试

        步骤:
            1. 创建带后台线程的流式写入器
            2. 写入数据
            3. 等待后台线程刷盘
            4. 验证数据完整
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=200,
            stream_flush_interval_ms=500,
            stream_enable_background_thread=True,
        )
        channels = [ChannelDef(name="BGTest", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(100, ["BGTest"])
            writer.append_continuous(values, timestamps)
            # 等待后台线程刷盘
            time.sleep(1.0)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("BGTest")
            self.assertEqual(len(sig.samples), 100)

    def test_streaming_continuous_append(self):
        """
        流式模式连续追加测试

        步骤:
            1. 定义通道
            2. 逐条追加
            3. 验证数据
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=500,
            stream_enable_background_thread=False,
        )
        channels = [
            ChannelDef(name="Counter", data_type="<u4"),
            ChannelDef(name="Value", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            for i in range(50):
                writer.append_continuous(
                    {"Counter": [i], "Value": [float(i) * 1.5]},
                    [float(i) * 0.01]
                )

        with MDFReader(self.temp_file) as reader:
            counter = reader.get_channel("Counter")
            self.assertEqual(len(counter.samples), 50)

    def test_streaming_intermittent(self):
        """
        流式模式间歇数据测试

        步骤:
            1. 定义通道
            2. 使用 append_intermittent 写入
            3. 验证数据
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=500,
            stream_enable_background_thread=False,
        )
        channels = [
            ChannelDef(name="EventA", data_type="<u4"),
            ChannelDef(name="EventB", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(20):
                writer.append_intermittent("EventA", float(i) * 0.1, i * 10)

        with MDFReader(self.temp_file) as reader:
            names = reader.get_channel_names()
            self.assertIn("EventA", names)


# =============================================================================
# 持久化追加测试
# =============================================================================

class TestMDFPersistence(unittest.TestCase):
    """持久化与追加测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_append_after_close(self):
        """
        关闭后追加数据测试

        步骤:
            1. 第一次创建文件并写入
            2. 使用 AppendWriter 追加
            3. 验证数据完整
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Data", data_type="<u4")]

        # 第一次写入
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous(
                {"Data": list(range(50))},
                [i * 0.1 for i in range(50)]
            )

        # 追加（通过重新创建写入器）
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous(
                {"Data": list(range(50, 100))},
                [i * 0.1 + 5.0 for i in range(50)]
            )

        # 验证
        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("Data")
            self.assertEqual(len(data.samples), 100)

    def test_multiple_append_cycles(self):
        """
        多次追加循环测试

        步骤:
            1. 循环 3 次写入
            2. 验证总数据量
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Cycle", data_type="<u4")]

        for cycle in range(3):
            with MDFWriter(self.temp_file, config) as writer:
                writer.define_channels(channels)
                writer.append_continuous(
                    {"Cycle": list(range(cycle * 30, (cycle + 1) * 30))},
                    [i * 0.1 + cycle * 3.0 for i in range(30)]
                )

        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("Cycle")
            self.assertEqual(len(data.samples), 90)


# =============================================================================
# 多线程测试
# =============================================================================

class TestMDFMultiThreading(unittest.TestCase):
    """多线程并发测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_multithread_write(self):
        """
        多线程写入测试

        步骤:
            1. 创建流式写入器
            2. 启动多个线程同时写入
            3. 验证所有数据完整无丢失
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=200,
            stream_enable_background_thread=False,
        )
        channels = [ChannelDef(name="ThreadData", data_type="<f4")]

        writer = MDFWriter(self.temp_file, config)
        writer.define_channels(channels)

        def worker(thread_id: int, count: int):
            """工作线程函数"""
            for i in range(count):
                writer.append_continuous(
                    {"ThreadData": [float(thread_id * 1000 + i)]},
                    [float(thread_id * 1000 + i) * 0.001]
                )

        # 启动 4 个线程，每个写入 25 条
        threads = []
        for tid in range(4):
            t = threading.Thread(target=worker, args=(tid, 25))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        writer.close()

        # 验证
        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("ThreadData")
            self.assertEqual(len(data.samples), 100)

    def test_multithread_write_read(self):
        """
        多线程写入+读取测试

        步骤:
            1. 创建流式写入器
            2. 启动写入线程
            3. 同时启动读取线程
            4. 验证数据一致性
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=500,
            stream_enable_background_thread=False,
        )
        channels = [ChannelDef(name="SharedData", data_type="<f4")]

        writer = MDFWriter(self.temp_file, config)
        writer.define_channels(channels)

        write_results = []

        def writer_worker():
            """写入线程"""
            for i in range(50):
                writer.append_continuous(
                    {"SharedData": [float(i)]},
                    [float(i) * 0.01]
                )
            write_results.append(True)

        # 启动写入线程
        t_write = threading.Thread(target=writer_worker)
        t_write.start()
        t_write.join()

        writer.close()

        # 读取验证
        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("SharedData")
            self.assertEqual(len(data.samples), 50)

    def test_concurrent_normal_writes(self):
        """
        多线程 NORMAL 模式写入测试

        步骤:
            1. 创建 NORMAL 模式写入器
            2. 多线程并发写入
            3. 验证数据完整
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Concurrent", data_type="<f4")]

        writer = MDFWriter(self.temp_file, config)
        writer.define_channels(channels)

        def worker(tid: int):
            for i in range(10):
                writer.append_continuous(
                    {"Concurrent": [float(tid * 100 + i)]},
                    [float(tid * 100 + i) * 0.001]
                )

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        writer.close()

        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("Concurrent")
            self.assertEqual(len(data.samples), 50)


# =============================================================================
# 压缩测试
# =============================================================================

class TestMDFCompression(unittest.TestCase):
    """压缩功能测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_zip_compression(self):
        """
        ZIP 压缩测试

        步骤:
            1. 创建 ZIP 压缩写入器
            2. 写入数据
            3. 验证数据完整
        """
        config = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionType.ZIP,
        )
        channels = [ChannelDef(name="Comp", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(200, ["Comp"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            data = reader.get_channel("Comp")
            self.assertEqual(len(data.samples), 200)

    def test_compression_reduces_size(self):
        """
        压缩减小文件大小测试

        步骤:
            1. 创建压缩文件
            2. 创建未压缩文件（相同数据）
            3. 验证压缩文件更小或相等
        """
        channels = [ChannelDef(name="X", data_type="<f4")]
        values, timestamps = generate_continuous_data(1000, ["X"])

        # 压缩写入
        fd, comp_file = tempfile.mkstemp(suffix="_compressed.mf4")
        os.close(fd)
        config_comp = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionType.ZIP,
        )
        with MDFWriter(comp_file, config_comp) as w:
            w.define_channels(channels)
            w.append_continuous(values, timestamps)

        # 未压缩写入
        fd, uncomp_file = tempfile.mkstemp(suffix="_uncompressed.mf4")
        os.close(fd)
        config_uncomp = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(uncomp_file, config_uncomp) as w:
            w.define_channels(channels)
            w.append_continuous(values, timestamps)

        comp_size = os.path.getsize(comp_file)
        uncomp_size = os.path.getsize(uncomp_file)
        # 压缩文件应小于等于未压缩文件
        self.assertLessEqual(comp_size, uncomp_size * 1.1)

        cleanup_file(comp_file)
        cleanup_file(uncomp_file)


# =============================================================================
# 迭代器读取测试
# =============================================================================

class TestMDFIteratorReading(unittest.TestCase):
    """迭代器读取测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_iter_channel(self):
        """
        单通道迭代器测试

        步骤:
            1. 创建大文件
            2. 使用 iter_channel 分块读取
            3. 验证所有数据被读取
        """
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
        channels = [ChannelDef(name="IterData", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(5000, ["IterData"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            total = 0
            for chunk in reader.iter_channel("IterData", batch_size=500):
                total += len(chunk.samples)
            self.assertEqual(total, 5000)

    def test_iter_channels(self):
        """
        多通道迭代器测试

        步骤:
            1. 创建多通道文件
            2. 使用 iter_channels 分块读取
            3. 验证所有通道数据完整
        """
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
        channels = [
            ChannelDef(name="Ch1", data_type="<f4"),
            ChannelDef(name="Ch2", data_type="<f4"),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(3000, ["Ch1", "Ch2"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            total = 0
            for chunk in reader.iter_channels(["Ch1", "Ch2"], batch_size=500):
                total += len(chunk["Ch1"].samples)
            self.assertEqual(total, 3000)

    def test_get_records_slice(self):
        """
        记录范围读取测试

        步骤:
            1. 创建文件
            2. 读取指定范围
            3. 验证范围正确
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Slice", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(100, ["Slice"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_records_slice("Slice", start=10, count=20)
            self.assertEqual(len(sig.samples), 20)


# =============================================================================
# 读取器测试
# =============================================================================

class TestMDFReader(unittest.TestCase):
    """读取器功能测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()
        # 预先创建测试文件
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef(name="Speed", unit="km/h", data_type="<f4"),
            ChannelDef(name="Temp", unit="C", data_type="<f4"),
        ]
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(100, ["Speed", "Temp"])
            writer.append_continuous(values, timestamps)

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_get_channel(self):
        """基本通道读取测试"""
        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Speed")
            self.assertEqual(len(sig.samples), 100)
            self.assertEqual(str(sig.unit), "km/h")

    def test_get_channels(self):
        """批量通道读取测试"""
        with MDFReader(self.temp_file) as reader:
            data = reader.get_channels(["Speed", "Temp"])
            self.assertIn("Speed", data)
            self.assertIn("Temp", data)
            self.assertEqual(len(data["Speed"].samples), 100)

    def test_channel_not_found(self):
        """通道不存在异常测试"""
        with MDFReader(self.temp_file) as reader:
            with self.assertRaises(MDFReaderNotFoundError):
                reader.get_channel("NonExistent")

    def test_get_channel_info(self):
        """通道信息查询测试"""
        with MDFReader(self.temp_file) as reader:
            info = reader.get_channel_info("Speed")
            self.assertEqual(info["name"], "Speed")
            self.assertEqual(info["unit"], "km/h")
            self.assertEqual(info["samples_count"], 100)

    def test_has_channel(self):
        """通道存在性检查测试"""
        with MDFReader(self.temp_file) as reader:
            self.assertTrue(reader.has_channel("Speed"))
            self.assertFalse(reader.has_channel("XXX"))

    def test_file_info(self):
        """文件信息查询测试"""
        with MDFReader(self.temp_file) as reader:
            info = reader.get_file_info()
            self.assertIn("filepath", info)
            self.assertIn("channels", info)
            self.assertGreater(info["channels"], 0)

    def test_cache(self):
        """读取缓存测试"""
        with MDFReader(self.temp_file) as reader:
            # 第一次读取（缓存未命中）
            sig1 = reader.get_channel("Speed")
            # 第二次读取（缓存命中）
            sig2 = reader.get_channel("Speed")
            self.assertEqual(len(sig1.samples), len(sig2.samples))


# =============================================================================
# 综合场景测试
# =============================================================================

class TestMDFIntegration(unittest.TestCase):
    """综合场景测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_all_modes_data_consistency(self):
        """
        全模式数据一致性测试

        步骤:
            1. 对每种模式写入相同数据
            2. 读取并验证数据一致
        """
        modes = [OperationMode.NORMAL, OperationMode.FRAGMENTED, OperationMode.STREAMING]
        channels = [ChannelDef(name="Test", data_type="<f4")]
        test_values = {"Test": [1.0, 2.0, 3.0, 4.0, 5.0]}
        test_timestamps = [0.0, 0.1, 0.2, 0.3, 0.4]

        for mode in modes:
            fd, filepath = tempfile.mkstemp(suffix=f"_{mode.value}.mf4")
            os.close(fd)
            config = MDFConfig(operation_mode=mode)
            if mode == OperationMode.STREAMING:
                config = MDFConfig(
                    operation_mode=mode,
                    stream_enable_background_thread=False,
                    stream_buffer_size=100,
                )

            with MDFWriter(filepath, config) as writer:
                writer.define_channels(channels)
                writer.append_continuous(test_values, test_timestamps)

            with MDFReader(filepath) as reader:
                sig = reader.get_channel("Test")
                self.assertEqual(len(sig.samples), 5)
                np.testing.assert_array_almost_equal(
                    sig.samples, np.array([1.0, 2.0, 3.0, 4.0, 5.0])
                )

            cleanup_file(filepath)

    def test_large_data(self):
        """
        大数据量测试

        步骤:
            1. 写入 50000 条记录
            2. 验证读取完整
        """
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
        channels = [ChannelDef(name="Big", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(50000, ["Big"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Big")
            self.assertEqual(len(sig.samples), 50000)

    def test_mixed_continuity(self):
        """
        混合连续性数据测试

        步骤:
            1. 先写入连续数据
            2. 再定义新通道写入间歇数据
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        with MDFWriter(self.temp_file, config) as writer:
            # 连续数据
            ch_cont = [ChannelDef(name="Speed", data_type="<f4")]
            writer.define_channels(ch_cont, DataContinuity.CONTINUOUS)
            writer.append_continuous(
                {"Speed": [10.0, 20.0, 30.0]},
                [0.0, 0.1, 0.2]
            )

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Speed")
            self.assertEqual(len(sig.samples), 3)

    def test_writer_info(self):
        """写入器信息查询测试"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="A", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous({"A": [1.0, 2.0]}, [0.0, 0.1])
            info = writer.get_info()
            self.assertEqual(info["operation_mode"], "normal")
            self.assertEqual(info["channel_count"], 1)
            self.assertTrue(info["is_open"])


# =============================================================================
# 边界条件测试
# =============================================================================

class TestMDFEdgeCases(unittest.TestCase):
    """边界条件测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_single_record(self):
        """单条记录测试"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Single", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous({"Single": [42.0]}, [0.0])

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Single")
            self.assertEqual(len(sig.samples), 1)
            self.assertAlmostEqual(sig.samples[0], 42.0)

    def test_very_small_fragment(self):
        """极小分片大小测试"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=100,
        )
        channels = [ChannelDef(name="Small", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            values, timestamps = generate_continuous_data(500, ["Small"])
            writer.append_continuous(values, timestamps)

        with MDFReader(self.temp_file) as reader:
            sig = reader.get_channel("Small")
            self.assertEqual(len(sig.samples), 500)

    def test_reader_closed_state(self):
        """读取器关闭状态测试"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="X", data_type="<f4")]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.append_continuous({"X": [1.0]}, [0.0])

        reader = MDFReader(self.temp_file)
        reader.close()

        with self.assertRaises(MDFReaderStateError):
            reader.get_channel("X")

    def test_double_close(self):
        """重复关闭测试"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter(self.temp_file, config)
        writer.close()
        # 第二次关闭不应报错
        writer.close()
        self.assertFalse(writer.is_open)


# =============================================================================
# 主入口
# =============================================================================

def run_tests():
    """
    运行所有测试

    返回:
        True 如果所有测试通过，False 否则
    """
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    test_classes = [
        TestMDFConfig,
        TestMDFWriterNormal,
        TestMDFWriterFragmented,
        TestMDFWriterStreaming,
        TestMDFPersistence,
        TestMDFMultiThreading,
        TestMDFCompression,
        TestMDFIteratorReading,
        TestMDFReader,
        TestMDFIntegration,
        TestMDFEdgeCases,
    ]

    for test_class in test_classes:
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 70)
    print("测试摘要")
    print("=" * 70)
    print(f"总测试数: {result.testsRun}")
    passed = result.testsRun - len(result.failures) - len(result.errors)
    print(f"通过: {passed}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")

    if result.wasSuccessful():
        print("\n所有测试通过!")
    else:
        print("\n存在失败的测试!")

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
