# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器包

基于 asammdf 库构建的生产级多线程 MDF 文件读写器。
支持三种操作模式（NORMAL/FRAGMENTED/STREAMING），
连续和间歇数据写入，以及持久化追加功能。

子模块:
    mdf_config   - 配置模块，包含枚举和 MDFConfig 类
    mdf_writer   - 线程安全写入器 (MDFWriter, MDFAppendWriter)
    mdf_reader   - 线程安全读取器 (MDFReader)

使用示例:
    from mdf_config import MDFConfig, OperationMode, ChannelDef
    from mdf_writer import MDFWriter
    from mdf_reader import MDFReader

    # 写入
    config = MDFConfig(operation_mode=OperationMode.STREAMING)
    with MDFWriter("output.mf4", config) as writer:
        writer.define_channels([ChannelDef("Speed", "km/h")])
        writer.append_continuous(
            {"Speed": [10.0, 20.0]},
            [0.0, 0.1]
        )

    # 读取
    with MDFReader("output.mf4") as reader:
        sig = reader.get_channel("Speed")
        print(sig.samples, sig.timestamps)

版本: 2.0.0
"""

from mdf_config import (
    MDFConfig, ChannelDef, WriterStats, ReaderStats,
    OperationMode, DataContinuity, CompressionType,
)

from mdf_writer import (
    MDFWriter, MDFAppendWriter,
    MDFWriterError, MDFWriterStateError,
    MDFWriterModeError, MDFWriterValidationError,
    MDFWriterThreadError,
)

from mdf_reader import (
    MDFReader,
    MDFReaderError, MDFReaderNotFoundError,
    MDFReaderStateError, MDFReaderFormatError,
)

__version__ = "2.0.0"
__all__ = [
    # 配置
    "MDFConfig", "ChannelDef", "WriterStats", "ReaderStats",
    "OperationMode", "DataContinuity", "CompressionType",
    # 写入器
    "MDFWriter", "MDFAppendWriter",
    "MDFWriterError", "MDFWriterStateError",
    "MDFWriterModeError", "MDFWriterValidationError",
    "MDFWriterThreadError",
    # 读取器
    "MDFReader",
    "MDFReaderError", "MDFReaderNotFoundError",
    "MDFReaderStateError", "MDFReaderFormatError",
    # 版本
    "__version__",
]
