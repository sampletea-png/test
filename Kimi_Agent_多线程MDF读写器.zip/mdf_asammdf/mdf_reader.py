# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读取器模块 (基于 asammdf)

本模块实现了线程安全的 MDF 文件读取器，基于 asammdf 库构建。
提供多种数据读取方式：按通道读取、批量读取、迭代器读取等。

架构设计:
    1. 线程安全: 使用 threading.RLock 保护所有 asammdf.MDF 操作
    2. 多组合并: 自动合并多个数据组中的同名通道数据
    3. 读取模式: 支持单值读取、批量读取、迭代器读取
    4. 数据转换: 支持原始值/物理值转换
    5. 通道查询: 支持按名称、索引查询通道信息
    6. 缓存优化: 支持通道数据缓存，减少重复 I/O

多组数据处理:
    asammdf 的 append 方法每次调用都会创建新的数据组 (DG)。
    当同一个通道名出现在多个数据组中时，本读取器会自动
    获取所有数据组中的数据并按时间戳排序合并，
    对外呈现统一的通道视图。

依赖:
    - asammdf >= 8.0
    - numpy

作者: AI Assistant
版本: 2.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import time
import logging
import threading
from typing import Optional, Dict, List, Any, Tuple, Union, Iterator
from dataclasses import dataclass

import numpy as np

# asammdf 导入
try:
    from asammdf import MDF, Signal
except ImportError as e:
    raise ImportError(
        "asammdf 库未安装。请运行: pip install asammdf"
    ) from e

# 导入配置模块
from mdf_config import MDFConfig, ReaderStats

# 配置日志
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类
# =============================================================================

class MDFReaderError(Exception):
    """MDF 读取器基础异常"""
    pass


class MDFReaderNotFoundError(MDFReaderError):
    """通道或数据未找到异常"""
    pass


class MDFReaderStateError(MDFReaderError):
    """状态错误异常"""
    pass


class MDFReaderFormatError(MDFReaderError):
    """文件格式错误异常"""
    pass


# =============================================================================
# 主读取器类
# =============================================================================

class MDFReader:
    """
    线程安全的 ASAM MDF 文件读取器

    基于 asammdf.MDF 构建，提供多线程安全的 MDF 文件读取功能。
    支持按通道读取、批量读取、迭代器读取等多种方式。

    多组数据合并:
        当同一个通道名存在于多个数据组中时（例如多次 append 的结果），
        本读取器会自动获取所有数据组中的数据，按时间戳排序合并，
        对外呈现统一的连续通道视图。用户无需关心底层数据组结构。

    线程安全保证:
        - 所有公共方法使用 self._lock 进行同步
        - asammdf.MDF 对象始终通过锁保护
        - 统计信息更新通过锁保护
        - 缓存操作通过锁保护

    使用示例:
        # 基本读取
        reader = MDFReader("input.mf4")
        data = reader.get_channel("Speed")
        print(data.samples, data.timestamps)

        # 批量读取
        data = reader.get_channels(["Speed", "RPM"])

        # 迭代器读取（内存高效）
        for chunk in reader.iter_channel("Speed", batch_size=1000):
            process(chunk)

        # 上下文管理器
        with MDFReader("input.mf4") as reader:
            data = reader.get_channel("Temperature")

    属性:
        filepath: MDF 文件路径
        is_open: 文件是否处于打开状态
        stats: ReaderStats 统计信息
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 读取器

        参数:
            filepath: MDF 文件路径
            config: MDFConfig 配置对象，None 时使用默认配置

        步骤:
            1. 保存配置参数
            2. 初始化线程锁
            3. 验证文件存在
            4. 打开 asammdf.MDF 对象
            5. 初始化统计信息和缓存

        异常:
            FileNotFoundError: 文件不存在
            MDFReaderFormatError: 文件格式无效
        """
        # 步骤 1: 保存配置
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath

        # 步骤 2: 初始化线程锁
        self._lock: threading.RLock = threading.RLock()

        # 步骤 3: 验证文件存在
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"MDF 文件不存在: {filepath}")

        # 步骤 4: 打开 asammdf.MDF
        try:
            self._mdf: MDF = MDF(filepath)
        except Exception as e:
            raise MDFReaderFormatError(f"无法打开 MDF 文件: {e}") from e

        # 步骤 5: 初始化状态
        self._is_open: bool = True
        self.stats: ReaderStats = ReaderStats()
        self._start_time: float = time.time()

        # 缓存
        self._cache: Dict[str, Signal] = {}
        self._cache_max_size: int = 20  # 最大缓存通道数

        logger.info(f"MDFReader 初始化完成: {filepath}")

    # ======================================================================
    # 属性访问
    # ======================================================================

    @property
    def is_open(self) -> bool:
        """文件是否处于打开状态"""
        return self._is_open

    # ======================================================================
    # 通道查询
    # ======================================================================

    def get_channel_names(self) -> List[str]:
        """
        获取所有通道名称列表

        返回:
            通道名称字符串列表（排除内部 time 通道）

        适用:
            探索文件内容，了解可用通道
        """
        with self._lock:
            self.stats.total_reads += 1
            names = [k for k in self._mdf.channels_db.keys() if k != 'time']
            return names

    def get_channel_info(self, name: str) -> Dict[str, Any]:
        """
        获取通道详细信息

        参数:
            name: 通道名称

        返回:
            通道信息字典，包含:
            - name: 通道名称
            - unit: 物理单位
            - comment: 注释
            - samples_count: 样本数量（跨所有数据组合计）
            - data_type: 数据类型
            - group_count: 所在数据组数量

        异常:
            MDFReaderNotFoundError: 通道不存在

        适用:
            了解通道的元数据信息
        """
        with self._lock:
            self.stats.total_reads += 1

            if name not in self._mdf.channels_db:
                raise MDFReaderNotFoundError(f"通道不存在: {name}")

            try:
                sig = self.get_channel(name)
                channel_entries = self._mdf.channels_db[name]
                return {
                    "name": str(sig.name),
                    "unit": str(sig.unit),
                    "comment": str(sig.comment),
                    "samples_count": len(sig.samples) if sig.samples is not None else 0,
                    "data_type": str(sig.samples.dtype) if sig.samples is not None else "unknown",
                    "group_count": len(channel_entries),
                }
            except Exception as e:
                raise MDFReaderError(f"获取通道信息失败: {e}") from e

    def has_channel(self, name: str) -> bool:
        """
        检查通道是否存在

        参数:
            name: 通道名称

        返回:
            True 如果通道存在（排除 time 通道），False 否则
        """
        with self._lock:
            return name in self._mdf.channels_db and name != 'time'

    # ======================================================================
    # 内部方法: 多组数据合并
    # ======================================================================

    def _get_channel_from_all_groups(self, name: str,
                                      raw: bool = False) -> Signal:
        """
        从所有数据组获取同名通道并合并

        参数:
            name: 通道名称
            raw: 是否返回原始值

        步骤:
            1. 从 channels_db 获取该通道在所有数据组中的位置
            2. 遍历每个数据组，获取信号数据
            3. 按时间戳排序合并所有信号
            4. 返回合并后的 Signal

        返回:
            合并后的 Signal 对象

        异常:
            MDFReaderNotFoundError: 通道不存在
            MDFReaderError: 读取失败
        """
        # 获取通道在所有组中的索引
        channel_entries = self._mdf.channels_db.get(name)
        if not channel_entries:
            raise MDFReaderNotFoundError(f"通道不存在: {name}")

        all_samples = []
        all_timestamps = []
        unit = ""
        comment = ""

        # 遍历每个 (group_index, channel_index) 获取数据
        for group_idx, channel_idx in channel_entries:
            try:
                sig = self._mdf.get(name, group=group_idx)
                if sig.samples is not None and len(sig.samples) > 0:
                    all_samples.append(sig.samples)
                    all_timestamps.append(sig.timestamps)
                    if not unit and sig.unit:
                        unit = str(sig.unit)
                    if not comment and sig.comment:
                        comment = str(sig.comment)
            except Exception as e:
                logger.warning(f"获取组 {group_idx} 的通道 {name} 失败: {e}")
                continue

        if not all_samples:
            raise MDFReaderError(f"通道 {name} 无有效数据")

        # 合并数据
        merged_samples = np.concatenate(all_samples)
        merged_timestamps = np.concatenate(all_timestamps)

        # 按时间戳排序
        sort_idx = np.argsort(merged_timestamps)
        merged_samples = merged_samples[sort_idx]
        merged_timestamps = merged_timestamps[sort_idx]

        return Signal(
            samples=merged_samples,
            timestamps=merged_timestamps,
            name=name,
            unit=unit,
            comment=comment,
        )

    # ======================================================================
    # 数据读取
    # ======================================================================

    def get_channel(self, name: str, raw: bool = False) -> Signal:
        """
        读取指定通道的完整数据

        参数:
            name: 通道名称
            raw: 是否返回原始值（不应用转换公式）

        返回:
            asammdf.Signal 对象，包含 samples 和 timestamps

        异常:
            MDFReaderNotFoundError: 通道不存在
            MDFReaderStateError: 读取器已关闭

        适用:
            按通道名称提取完整数据。如果通道存在于多个数据组中，
            会自动合并所有组的数据并按时间戳排序。
            结果会缓存以加速重复读取。

        示例:
            sig = reader.get_channel("Speed")
            print(sig.samples)      # 样本值数组
            print(sig.timestamps)   # 时间戳数组
            print(sig.unit)         # 单位
        """
        with self._lock:
            if not self._is_open:
                raise MDFReaderStateError("读取器已关闭")

            self.stats.total_reads += 1

            # 排除内部 time 通道
            if name == 'time':
                raise MDFReaderNotFoundError("'time' 是内部通道，不可直接读取")

            # 检查缓存
            cache_key = f"{name}:raw={raw}"
            if cache_key in self._cache:
                self.stats.cache_hit_count += 1
                return self._cache[cache_key]

            self.stats.cache_miss_count += 1

            # 读取数据（处理多组情况）
            try:
                channel_entries = self._mdf.channels_db.get(name)
                if not channel_entries:
                    raise MDFReaderNotFoundError(f"通道不存在: {name}")

                # 如果只在一个组中，直接获取
                if len(channel_entries) == 1:
                    group_idx = channel_entries[0][0]
                    sig = self._mdf.get(name, group=group_idx, raw=raw)
                else:
                    # 多个组中，合并数据
                    sig = self._get_channel_from_all_groups(name, raw=raw)

            except (MDFReaderNotFoundError, MDFReaderError):
                raise
            except Exception as e:
                raise MDFReaderError(f"读取通道失败: {e}") from e

            # 更新统计
            self.stats.total_records_read += len(sig.samples)

            # 缓存结果
            self._add_to_cache(cache_key, sig)

            return sig

    def get_channels(self, names: List[str],
                      raw: bool = False) -> Dict[str, Signal]:
        """
        批量读取多个通道的数据

        参数:
            names: 通道名称列表
            raw: 是否返回原始值

        返回:
            通道名 -> Signal 的字典

        异常:
            MDFReaderNotFoundError: 任一通道不存在

        适用:
            一次性读取多个相关通道的数据
        """
        with self._lock:
            result = {}
            for name in names:
                result[name] = self.get_channel(name, raw=raw)
            return result

    def get_records_slice(self, name: str,
                           start: int = 0,
                           count: Optional[int] = None,
                           raw: bool = False) -> Signal:
        """
        读取通道的指定范围记录

        参数:
            name: 通道名称
            start: 起始索引（从 0 开始）
            count: 读取数量，None 表示读取到末尾
            raw: 是否返回原始值

        返回:
            截取后的 Signal 对象

        适用:
            大数据量时只读取需要的部分，减少内存占用
        """
        with self._lock:
            sig = self.get_channel(name, raw=raw)

            total = len(sig.samples)
            if count is None:
                count = total - start
            end = min(start + count, total)

            # 创建新的 Signal（截取范围）
            return Signal(
                samples=sig.samples[start:end],
                timestamps=sig.timestamps[start:end],
                name=sig.name,
                unit=sig.unit,
                comment=sig.comment,
            )

    # ======================================================================
    # 迭代器读取（内存高效）
    # ======================================================================

    def iter_channel(self, name: str,
                      batch_size: int = 1000,
                      raw: bool = False) -> Iterator[Signal]:
        """
        迭代读取通道数据（内存高效）

        参数:
            name: 通道名称
            batch_size: 每次读取的样本数
            raw: 是否返回原始值

        步骤:
            1. 获取通道总样本数（跨所有组）
            2. 按 batch_size 分块
            3. 逐块 yield Signal

        适用:
            大文件处理，避免一次性加载所有数据到内存。
            适合流式处理和实时分析场景。

        示例:
            for chunk in reader.iter_channel("Speed", batch_size=500):
                process(chunk.samples)
        """
        with self._lock:
            if not self._is_open:
                raise MDFReaderStateError("读取器已关闭")

            try:
                sig = self.get_channel(name, raw=raw)
            except MDFReaderNotFoundError:
                raise
            except Exception as e:
                raise MDFReaderError(f"读取通道失败: {e}") from e

            total = len(sig.samples)
            start = 0

            while start < total:
                end = min(start + batch_size, total)
                chunk = Signal(
                    samples=sig.samples[start:end],
                    timestamps=sig.timestamps[start:end],
                    name=sig.name,
                    unit=sig.unit,
                )
                self.stats.total_records_read += (end - start)
                yield chunk
                start = end

    def iter_channels(self, names: List[str],
                       batch_size: int = 1000,
                       raw: bool = False) -> Iterator[Dict[str, Signal]]:
        """
        迭代读取多个通道的数据（内存高效）

        参数:
            names: 通道名称列表
            batch_size: 每次读取的样本数
            raw: 是否返回原始值

        步骤:
            1. 获取所有通道的总样本数（取最小值）
            2. 按 batch_size 分块
            3. 逐块 yield 通道名 -> Signal 的字典

        适用:
            多通道同步处理场景
        """
        with self._lock:
            # 预加载所有通道
            signals = {}
            min_count = float('inf')
            for name in names:
                try:
                    sig = self.get_channel(name, raw=raw)
                    signals[name] = sig
                    min_count = min(min_count, len(sig.samples))
                except MDFReaderNotFoundError:
                    raise
                except Exception as e:
                    raise MDFReaderError(f"读取通道失败: {e}") from e

            start = 0
            while start < min_count:
                end = min(start + batch_size, min_count)
                chunk = {}
                for name, sig in signals.items():
                    chunk[name] = Signal(
                        samples=sig.samples[start:end],
                        timestamps=sig.timestamps[start:end],
                        name=sig.name,
                        unit=sig.unit,
                    )
                self.stats.total_records_read += (end - start) * len(names)
                yield chunk
                start = end

    # ======================================================================
    # 缓存管理
    # ======================================================================

    def _add_to_cache(self, key: str, sig: Signal) -> None:
        """
        将信号添加到缓存

        参数:
            key: 缓存键
            sig: Signal 对象

        步骤:
            1. 如果缓存已满，移除最早的条目
            2. 添加新条目
        """
        # LRU 简单实现：如果满则清空
        if len(self._cache) >= self._cache_max_size:
            self._cache.clear()

        self._cache[key] = sig

    def clear_cache(self) -> None:
        """清空通道数据缓存"""
        with self._lock:
            self._cache.clear()
            logger.debug("读取缓存已清空")

    # ======================================================================
    # 文件信息
    # ======================================================================

    def get_file_info(self) -> Dict[str, Any]:
        """
        获取 MDF 文件的整体信息

        返回:
            文件信息字典，包含:
            - filepath: 文件路径
            - version: MDF 版本
            - groups: 数据组数量
            - channels: 通道数量
            - channel_names: 通道名称列表
            - file_size: 文件大小（字节）
        """
        with self._lock:
            channel_names = [k for k in self._mdf.channels_db.keys() if k != 'time']
            return {
                "filepath": self.filepath,
                "version": self._mdf.version,
                "groups": len(self._mdf.groups),
                "channels": len(channel_names),
                "channel_names": channel_names[:50],
                "file_size": os.path.getsize(self.filepath),
                "is_open": self._is_open,
                "stats": self.stats.to_dict(),
            }

    # ======================================================================
    # 关闭与资源释放
    # ======================================================================

    def close(self) -> None:
        """
        关闭读取器并释放资源

        步骤:
            1. 获取锁
            2. 清空缓存
            3. 关闭 asammdf.MDF 对象
            4. 更新状态

        适用:
            完成所有读取操作后调用。
            使用上下文管理器可自动调用。
        """
        with self._lock:
            if not self._is_open:
                return

            logger.info("关闭 MDFReader...")

            # 清空缓存
            self._cache.clear()

            # 关闭 asammdf
            try:
                self._mdf.close()
            except Exception as e:
                logger.warning(f"关闭 MDF 对象时出错: {e}")

            self._is_open = False
            self.stats.uptime_seconds = time.time() - self._start_time

            logger.info(
                f"MDFReader 已关闭。统计: "
                f"reads={self.stats.total_reads}, "
                f"records={self.stats.total_records_read}"
            )

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        try:
            self.close()
        except Exception as e:
            logger.error(f"上下文退出时关闭失败: {e}")
        return False


__all__ = [
    "MDFReader",
    "MDFReaderError", "MDFReaderNotFoundError",
    "MDFReaderStateError", "MDFReaderFormatError",
]
