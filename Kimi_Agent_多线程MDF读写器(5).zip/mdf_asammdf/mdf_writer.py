# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程写入器模块 (基于 asammdf 库)  v5.0.0

本模块实现了线程安全的 MDF 文件写入器，支持三种操作模式：
    1. NORMAL:     单文件直接写入，无分片逻辑
    2. FRAGMENTED: 分片模式，以体积阈值自动切分为多个独立 MDF 文件
    3. STREAMING:  流式模式，带内存缓冲区和可选后台刷盘线程

核心新增功能 (v5.0.0):
    Data Group / Channel Group / Channel 层级管理

    MDF 4.x 文件格式采用三级层级结构来组织数据：
        - Data Group (DG):  数据组，包含一个或多个通道组
        - Channel Group (CG): 通道组，包含一组相关通道
        - Channel (CN):     单个通道，存储实际数据

    本模块提供显式创建各个层级的方法，并返回每个层级的索引：
        create_data_group(name, comment) -> dg_index
        create_channel_group(dg_index, name, comment) -> cg_index
        create_channel(dg_index, cg_index, channel_def) -> cn_index

    用户可以通过返回的索引精确定位和查找数据：
        - dg_index: 在 mdf.groups 列表中的位置
        - cg_index: 在 data_group 下的 channel_group 索引 (asammdf 中固定为 0)
        - cn_index: 在 channel_group.channels 列表中的索引 ([0] 为 time 通道)

    写入数据时可通过 dg_index 指定目标 Data Group：
        append_continuous(values, timestamps, dg_index=0)
        append_to_data_group(dg_index, values, timestamps)

    实现策略 (基于 asammdf 限制):
        asammdf 的 append() 方法总是创建新 group，不支持向已有 group
        添加新 channel。因此 create_data_group 采用以下策略：
            1. 创建一个空的 dummy signal，调用 append() 创建空 group
            2. 空 group 包含 time 通道和一个名为 "_empty" 的 dummy 通道
            3. create_channel 时修改 dummy 通道的属性 (name, unit, comment)
            4. 更新 channels_db 索引映射
            5. 使用 extend() 方法向已有 group 追加数据

分片存储结构 (FRAGMENTED 模式):
    基础路径: /path/to/data.mf4
    分片文件夹: /path/to/data_fragments/
    分片文件:   /path/to/data_fragments/data_001.mf4
    索引文件:   /path/to/data_fragments/index.json

HD 块属性支持:
    通过 set_header() 方法修改 MDF 文件的 Header (HD) 块元数据。
    包括作者、部门、项目、主题、注释等。
    属性在每个分片中都会同步设置。

线程安全:
    所有公共方法均通过 threading.RLock 同步。
    后台刷盘线程在获取锁后检查 _is_open 状态。

版本: 5.0.0
日期: 2026-04-24
"""

# ---------------------------------------------------------------------------
# 标准库导入
# ---------------------------------------------------------------------------
from __future__ import annotations

import os
import time
import json
import logging
import threading
from typing import Optional, Dict, List, Any, Tuple, Union
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# 第三方库导入
# ---------------------------------------------------------------------------
import numpy as np

# 开始异常保护代码块
try:
    from asammdf import MDF, Signal
    from asammdf.blocks.v4_constants import CompressionAlgorithm
# 捕获并处理异常情况
except ImportError as e:
    raise ImportError(
        "asammdf 库未安装。请运行: pip install asammdf"
    ) from e

# ---------------------------------------------------------------------------
# 本地模块导入
# ---------------------------------------------------------------------------
from mdf_config import (
    MDFConfig, ChannelDef, WriterStats, HeaderConfig,
    OperationMode, DataContinuity, CompressionType,
)

# ---------------------------------------------------------------------------
# 模块级日志记录器
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类定义
# =============================================================================

class MDFWriterError(Exception):
    """MDF 写入器基础异常类。所有写入器异常均继承自此类。"""
    pass


class MDFWriterStateError(MDFWriterError):
    """状态错误异常。操作在不正确状态下执行时抛出。"""
    pass


class MDFWriterValidationError(MDFWriterError):
    """数据验证错误异常。传入数据不符合要求时抛出。"""
    pass


class MDFWriterModeError(MDFWriterError):
    """模式错误异常。操作在当前模式下不支持时抛出。"""
    pass


class MDFWriterThreadError(MDFWriterError):
    """线程错误异常。多线程操作出现问题时抛出。"""
    pass


class MDFWriterHierarchyError(MDFWriterError):
    """层级错误异常。DG/CG/CN 层级操作出错时抛出 (v5.0+)。"""
    pass


# =============================================================================
# 内部数据结构
# =============================================================================

@dataclass
class _ContinuousBuffer:
    """
    连续数据内部缓冲区

    用于 FRAGMENTED 和 STREAMING 模式下缓存连续数据。
    所有通道共享同一时间基。

    字段:
        timestamps:    时间戳列表（所有通道共享）
        samples:       通道名 -> 样本列表的字典
        record_count:  当前缓冲区中的记录数
        target_dg_idx: 数据应追加到的目标 Data Group 索引（v5.0+）

    线程安全:
        本类本身不加锁，调用方通过 RLock 保护。
    """
    timestamps: List[float] = field(default_factory=list)
    samples: Dict[str, List[Any]] = field(default_factory=dict)
    record_count: int = 0
    target_dg_idx: int = -1

    def __post_init__(self):
        """确保 samples 为字典类型。"""
        # 执行条件判断逻辑
        if isinstance(self.samples, list):
            self.samples = {}


    # -----------------------------------------------------------------
    # add_record 方法实现
    # -----------------------------------------------------------------
    def add_record(self, timestamp: float, values: Dict[str, Any]) -> None:
        """向缓冲区添加一条记录。"""
        self.timestamps.append(timestamp)
        # 开始循环遍历处理
        for name, val in values.items():
            # 执行条件判断逻辑
            if name not in self.samples:
                self.samples[name] = []
            self.samples[name].append(val)
        self.record_count += 1


    # -----------------------------------------------------------------
    # clear 方法实现
    # -----------------------------------------------------------------
    def clear(self) -> None:
        """清空缓冲区。刷盘后调用。"""
        self.timestamps.clear()
        self.samples.clear()
        self.record_count = 0
        self.target_dg_idx = -1


    # -----------------------------------------------------------------
    # is_empty 方法实现
    # -----------------------------------------------------------------
    def is_empty(self) -> bool:
        """检查缓冲区是否为空。"""
        # 返回函数执行结果
        return self.record_count == 0


@dataclass
class _IntermittentBuffer:
    """
    间歇数据内部缓冲区

    用于 FRAGMENTED 和 STREAMING 模式下缓存间歇数据。
    每条记录独立存储（时间戳, 通道名, 值）。

    字段:
        records:       记录列表
        target_dg_idx: 数据应追加到的目标 Data Group 索引（v5.0+）

    线程安全:
        本类本身不加锁，调用方通过 RLock 保护。
    """
    records: List[Tuple[float, str, Any]] = field(default_factory=list)
    target_dg_idx: int = -1


    # -----------------------------------------------------------------
    # add_record 方法实现
    # -----------------------------------------------------------------
    def add_record(self, timestamp: float, channel_name: str, value: Any) -> None:
        """向缓冲区添加一条间歇记录。"""
        self.records.append((timestamp, channel_name, value))


    # -----------------------------------------------------------------
    # clear 方法实现
    # -----------------------------------------------------------------
    def clear(self) -> None:
        """清空缓冲区。"""
        self.records.clear()
        self.target_dg_idx = -1


    # -----------------------------------------------------------------
    # is_empty 方法实现
    # -----------------------------------------------------------------
    def is_empty(self) -> bool:
        """检查缓冲区是否为空。"""
        # 返回函数执行结果
        return len(self.records) == 0


    # -----------------------------------------------------------------
    # get_record_count 方法实现
    # -----------------------------------------------------------------
    def get_record_count(self) -> int:
        """获取当前缓冲区中的记录数。"""
        # 返回函数执行结果
        return len(self.records)


# =============================================================================
# 分片索引管理
# =============================================================================

class FragmentIndex:
    """
    分片索引管理器

    管理分片索引文件（JSON 格式），记录所有分片文件的元数据信息。
    索引文件存储在分片子文件夹中。

    存储结构:
        基础路径: /path/to/data.mf4
        分片文件夹: /path/to/data_fragments/
        索引文件:   /path/to/data_fragments/index.json

    索引文件格式（JSON）:
        {
            "base_path": "/path/to/base.mf4",
            "schema": {"channels": [...]},
            "fragments": [
                {"index": 1, "path": "...", "size": 1024000,
                 "records": 1000, "start_time": 0.0, "end_time": 9.9}
            ],
            "created_at": "2026-04-24T10:00:00",
            "updated_at": "2026-04-24T10:05:00"
        }
    """

    def __init__(self, base_path: str, folder_suffix: str = "_fragments"):
        """
        初始化分片索引。

        参数:
            base_path:      基础文件路径
            folder_suffix:  分片文件夹后缀
        """
        self.base_path = base_path
        self.folder_suffix = folder_suffix
        self.fragment_folder = self._get_fragment_folder(base_path, folder_suffix)
        self.index_path = os.path.join(self.fragment_folder, "index.json")
        self.schema: Optional[Dict[str, Any]] = None
        self.fragments: List[Dict[str, Any]] = []
        self.created_at: str = ""
        self.updated_at: str = ""

    @staticmethod

    # -----------------------------------------------------------------
    # _get_fragment_folder 方法实现
    # -----------------------------------------------------------------
    def _get_fragment_folder(base_path: str, suffix: str = "_fragments") -> str:
        """根据基础路径获取分片文件夹路径。"""
        base, _ = os.path.splitext(base_path)
        # 返回函数执行结果
        return f"{base}{suffix}"

    @staticmethod

    # -----------------------------------------------------------------
    # _get_fragment_path 方法实现
    # -----------------------------------------------------------------
    def _get_fragment_path(base_path: str, index: int,
                            suffix: str = "_fragments") -> str:
        """根据基础路径和分片索引生成分片文件路径。

        命名: base_fragments/base_{index:03d}.ext
        """
        base, ext = os.path.splitext(base_path)
        folder = f"{base}{suffix}"
        # 返回函数执行结果
        return os.path.join(folder, f"{os.path.basename(base)}_{index:03d}{ext}")


    # -----------------------------------------------------------------
    # _ensure_folder_exists 方法实现
    # -----------------------------------------------------------------
    def _ensure_folder_exists(self) -> None:
        """确保分片文件夹存在，不存在则创建。"""
        # 执行条件判断逻辑
        if not os.path.exists(self.fragment_folder):
            os.makedirs(self.fragment_folder, exist_ok=True)
            # 记录操作成功的信息日志
            # 记录操作成功的信息日志
        # 记录信息级别日志
        logger.info(f"创建分片文件夹: {self.fragment_folder}")


    # -----------------------------------------------------------------
    # load 方法实现
    # -----------------------------------------------------------------
    def load(self) -> bool:
        """从磁盘加载索引文件。"""
        # 执行条件判断逻辑
        if not os.path.exists(self.index_path):
            # 返回函数执行结果
            return False
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            with open(self.index_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.schema = data.get("schema")
            self.fragments = data.get("fragments", [])
            self.created_at = data.get("created_at", "")
            self.updated_at = data.get("updated_at", "")
            # 返回函数执行结果
            return True
        # 捕获并处理异常情况
        except (json.JSONDecodeError, IOError) as e:
            # 记录警告信息日志
            # 记录警告信息日志
            # 记录警告级别日志
            logger.warning(f"加载索引文件失败: {e}")
            # 返回函数执行结果
            return False


    # -----------------------------------------------------------------
    # save 方法实现
    # -----------------------------------------------------------------
    def save(self) -> None:
        """保存索引到磁盘。"""
        self._ensure_folder_exists()
        data = {
            "base_path": self.base_path,
            "schema": self.schema,
            "fragments": self.fragments,
            "created_at": self.created_at,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            with open(self.index_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        # 捕获并处理异常情况
        except IOError as e:
            # 记录错误信息日志
            # 记录错误信息日志
            # 记录错误级别日志
            logger.error(f"保存索引文件失败: {e}")


    # -----------------------------------------------------------------
    # add_fragment 方法实现
    # -----------------------------------------------------------------
    def add_fragment(self, index: int, path: str, size: int,
                      records: int, start_time: float, end_time: float) -> None:
        """添加分片记录到索引。"""
        self._ensure_folder_exists()
        self.fragments.append({
            "index": index, "path": path, "size": size,
            "records": records, "start_time": start_time, "end_time": end_time,
        })
        self.save()


    # -----------------------------------------------------------------
    # get_latest_fragment_path 方法实现
    # -----------------------------------------------------------------
    def get_latest_fragment_path(self) -> Optional[str]:
        """获取最新分片的文件路径。"""
        # 返回函数执行结果
        return self.fragments[-1]["path"] if self.fragments else None


    # -----------------------------------------------------------------
    # get_latest_fragment_index 方法实现
    # -----------------------------------------------------------------
    def get_latest_fragment_index(self) -> int:
        """获取最新分片的索引号。"""
        # 返回函数执行结果
        return self.fragments[-1]["index"] if self.fragments else -1


    # -----------------------------------------------------------------
    # get_all_fragment_paths 方法实现
    # -----------------------------------------------------------------
    def get_all_fragment_paths(self) -> List[str]:
        """获取所有分片文件路径。"""
        # 返回函数执行结果
        return [f["path"] for f in self.fragments]


    # -----------------------------------------------------------------
    # set_schema 方法实现
    # -----------------------------------------------------------------
    def set_schema(self, channel_defs: List[ChannelDef]) -> None:
        """设置通道 Schema。"""
        self.schema = {
            "channels": [
                {"name": ch.name, "unit": ch.unit, "data_type": ch.data_type,
                 "comment": ch.comment, "display_name": ch.display_name,
                 "conversion": ch.conversion}
                for ch in channel_defs
            ]
        }


    # -----------------------------------------------------------------
    # total_records 方法实现
    # -----------------------------------------------------------------
    def total_records(self) -> int:
        """获取所有分片的总记录数。"""
        # 返回函数执行结果
        return sum(f["records"] for f in self.fragments)


    # -----------------------------------------------------------------
    # total_size 方法实现
    # -----------------------------------------------------------------
    def total_size(self) -> int:
        """获取所有分片的总大小（字节）。"""
        # 返回函数执行结果
        return sum(f["size"] for f in self.fragments)


# =============================================================================
# 主写入器类
# =============================================================================

class MDFWriter:
    """
    线程安全的 ASAM MDF 文件写入器

    核心功能：
        1. 三种操作模式（NORMAL/FRAGMENTED/STREAMING）
        2. 连续数据和间歇数据写入
        3. 分片模式下以体积阈值自动切分，分片存储在子文件夹中
        4. 支持修改 MDF HD 块属性（作者、部门、项目等）
        5. DG/CG/CN 层级管理（v5.0+）：显式创建各层级，返回索引

    DG/CG/CN 层级管理详解：
        ASAM MDF 4.x 采用三级层级结构组织数据：

        Data Group (DG):
            数据组，对应一个物理数据源或一个采样周期。
            在 asammdf 的 groups 列表中，每个元素对应一个 DG。
            通过 create_data_group() 创建，返回 dg_index。

        Channel Group (CG):
            通道组，位于 DG 之下，包含一组逻辑相关的通道。
            在 asammdf 中，每个 DG 只有一个 CG（mdf.groups[dg].channel_group）。
            通过 create_channel_group() 创建，返回 cg_index（固定为 0）。

        Channel (CN):
            通道，位于 CG 之下，存储实际的时间序列数据。
            mdf.groups[dg].channels 列表中 [0] 为 time 通道，
            [1+] 为数据通道。
            通过 create_channel() 创建，返回 cn_index。

        使用示例：
            with MDFWriter("output.mf4") as w:
                # 创建 Data Group
                dg = w.create_data_group(name="制动测试", comment="前轮制动")
                # 创建 Channel Group（在 DG 下）
                cg = w.create_channel_group(dg, name="温度组", comment="刹车盘温度")
                # 创建 Channels（在 CG 下）
                cn1 = w.create_channel(dg, cg, ChannelDef("前左温度", "C", "<f4"))
                cn2 = w.create_channel(dg, cg, ChannelDef("前右温度", "C", "<f4"))
                # 追加数据到指定 Data Group
                w.append_to_data_group(dg, {
                    "前左温度": [120.5, 125.0, 130.2],
                    "前右温度": [118.0, 122.3, 128.7]
                }, [0.0, 0.1, 0.2])

    分片模式（FRAGMENTED）：
        分片触发：estimated_size = 64KB + records * 12 bytes
        分片存储在子文件夹中：base_fragments/
        分片命名：base_fragments/base_001.mf4, base_002.mf4, ...
        索引文件：base_fragments/index.json

    HD 块属性设置：
        通过 set_header() 方法设置 Header 块元数据。
        属性在每个分片创建时自动同步。

    线程安全：
        所有公共方法均通过 threading.RLock 同步。

    版本: 5.0.0
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 写入器。

        参数:
            filepath: 输出文件的基础路径
            config:   MDFConfig 配置对象，默认使用 NORMAL 模式
        """
        # 保存配置和路径
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath

        # 线程同步机制
        self._lock: threading.RLock = threading.RLock()

        # 状态管理
        self._is_open: bool = False
        self._channel_defs: List[ChannelDef] = []
        self._channels_defined: bool = False
        self._continuity: DataContinuity = DataContinuity.CONTINUOUS

        # HD 块属性
        self._header_config: Optional[HeaderConfig] = None
        self._header_set: bool = False

        # DG/CG/CN 层级管理 (v5.0+)
        # 每个 DG 对应的 channel 定义映射: dg_index -> List[ChannelDef]
        self._group_channels: Dict[int, List[ChannelDef]] = {}
        # 每个 DG 对应的 dummy channel 标记: dg_index -> True/False
        # True 表示该 group 的 dummy channel 已被替换
        self._group_has_real_channels: Dict[int, bool] = {}

        # 数据缓冲区
        self._cont_buffer: _ContinuousBuffer = _ContinuousBuffer()
        self._inter_buffer: _IntermittentBuffer = _IntermittentBuffer()
        self._last_flush_time: float = 0.0

        # 后台线程（STREAMING 模式）
        self._bg_thread: Optional[threading.Thread] = None
        self._bg_stop_event: threading.Event = threading.Event()

        # asammdf 核心对象
        self._mdf: Optional[MDF] = None

        # 分片模式专用状态
        self._fragment_index: Optional[FragmentIndex] = None
        self._current_fragment_idx: int = 0
        self._current_fragment_path: str = ""
        self._current_fragment_records: int = 0

        # 统计信息
        self.stats: WriterStats = WriterStats()
        self._start_time: float = time.time()

        # 执行初始化
        # 执行内部初始化流程
        self._initialize()

        # 启动后台线程（如果启用）
        if (self.config.operation_mode == OperationMode.STREAMING
                and self.config.stream_enable_background_thread):
            self._start_background_thread()

        # 标记写入器为已打开状态
        self._is_open = True
        # 记录操作成功的信息日志
        # 记录信息级别日志
        logger.info(
            f"MDFWriter 初始化完成: path={filepath}, "
            f"mode={self.config.operation_mode.value}"
        )

    @property

    # -----------------------------------------------------------------
    # is_open 方法实现
    # -----------------------------------------------------------------
    def is_open(self) -> bool:
        """文件是否处于打开状态（只读属性）。"""
        # 返回函数执行结果
        return self._is_open

    # ======================================================================
    # 初始化方法
    # ======================================================================


    # -----------------------------------------------------------------
    # _initialize 方法实现
    # -----------------------------------------------------------------
    def _initialize(self) -> None:
        """初始化 MDF 对象和分片状态。"""
        # 执行条件判断逻辑
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            self._fragment_index = FragmentIndex(
                self.filepath,
                folder_suffix=self.config.fragment_folder_suffix,
            )
            # 执行条件判断逻辑
            if self._fragment_index.load():
                # 操作分片索引文件
                latest_path = self._fragment_index.get_latest_fragment_path()
                # 操作分片索引文件
                self._current_fragment_idx = self._fragment_index.get_latest_fragment_index()
                # 执行条件判断逻辑
                if latest_path and os.path.exists(latest_path):
                    self._current_fragment_path = latest_path
                    self._mdf = MDF(latest_path)
                    # 更新写入统计计数器
                    self.stats.fragment_count = len(self._fragment_index.fragments)
                    # 更新写入统计计数器
                    self.stats.fragment_index = self._current_fragment_idx
                    # 恢复层级状态
                    # 从现有 MDF 重建层级结构
                    self._rebuild_hierarchy_from_mdf()
                    # 记录操作成功的信息日志
                    # 记录操作成功的信息日志
                    # 记录信息级别日志
                    logger.info(f"加载已有分片 #{self._current_fragment_idx}")
                    return
            # 处理其他分支情况
            else:
                # 操作分片索引文件
                self._fragment_index.created_at = time.strftime("%Y-%m-%dT%H:%M:%S")
            # 操作分片索引文件
            self._fragment_index._ensure_folder_exists()
            # 创建新的分片文件
            self._create_new_fragment()
        # 处理其他分支情况
        else:
            # 创建新的 MDF 内存对象
            self._create_mdf(self.filepath)


    # -----------------------------------------------------------------
    # _rebuild_hierarchy_from_mdf 方法实现
    # -----------------------------------------------------------------
    def _rebuild_hierarchy_from_mdf(self) -> None:
        """从已加载的 MDF 对象重建层级状态（用于持久化追加）。"""
        # 执行条件判断逻辑
        if self._mdf is None:
            return
        # 开始循环遍历处理
        for dg_idx, group in enumerate(self._mdf.groups):
            real_channels = []
            # 开始循环遍历处理
            for cn_idx, ch in enumerate(group.channels):
                # 执行条件判断逻辑
                if cn_idx == 0:
                    continue  # skip time channel
                # 执行条件判断逻辑
                if ch.name.startswith("_"):
                    continue  # skip internal channels
                real_channels.append(ChannelDef(
                    name=ch.name, unit=ch.unit or "", data_type="<f4",
                ))
            # 执行条件判断逻辑
            if real_channels:
                self._group_channels[dg_idx] = real_channels
                self._group_has_real_channels[dg_idx] = True
            # 处理其他分支情况
            else:
                self._group_has_real_channels[dg_idx] = False


    # -----------------------------------------------------------------
    # _create_mdf 方法实现
    # -----------------------------------------------------------------
    def _create_mdf(self, path: str) -> None:
        """创建或加载 MDF 对象。"""
        # 执行条件判断逻辑
        if os.path.exists(path) and os.path.getsize(path) >= 64:
            self._mdf = MDF(path)
            # 从现有 MDF 重建层级结构
            self._rebuild_hierarchy_from_mdf()
        # 处理其他分支情况
        else:
            self._mdf = MDF(version=self.config.version)


    # -----------------------------------------------------------------
    # _create_new_fragment 方法实现
    # -----------------------------------------------------------------
    def _create_new_fragment(self) -> None:
        """创建新的分片文件。"""
        # 执行条件判断逻辑
        if self._mdf is not None:
            # 开始尝试执行核心操作
            # 开始异常保护代码块
            try:
                # 关闭当前 MDF 文件句柄
                self._mdf.close()
            # 捕获并处理异常情况
            except Exception:
                pass

        self._current_fragment_idx += 1
        self._current_fragment_path = FragmentIndex._get_fragment_path(
            self.filepath, self._current_fragment_idx,
            suffix=self.config.fragment_folder_suffix,
        )
        self._current_fragment_records = 0

        # 执行条件判断逻辑
        if self._fragment_index is not None:
            # 操作分片索引文件
            self._fragment_index._ensure_folder_exists()

        self._mdf = MDF(version=self.config.version)

        # 如果之前有层级定义，在新分片中重建（保留第一个 DG 的层级结构）
        # 执行条件判断逻辑
        if self._group_channels and 0 in self._group_channels:
            channels = self._group_channels[0]
            # 执行条件判断逻辑
            if channels:
                max_ch = max(16, len(channels) + 4)
                # 初始化空信号列表容器
                empty_sigs = []
                base_name = f"_dg0_frag{self._current_fragment_idx}"
                # 开始循环遍历处理
                for i in range(max_ch):
                    empty_sigs.append(Signal(
                        samples=np.array([], dtype=np.float64),
                        timestamps=np.array([], dtype=np.float64),
                        name=f"_empty_{base_name}_ch{i}",
                        unit="",
                    ))
                # 向 MDF 追加新信号数据
                new_dg = self._mdf.append(empty_sigs)
                # 设置 DG/CG 属性
                dg = self._mdf.groups[new_dg].data_group
                cg = self._mdf.groups[new_dg].channel_group
                # 复制旧属性
                # 执行条件判断逻辑
                if self._fragment_index and self._fragment_index.fragments:
                    # 操作分片索引文件
                    old_frag = self._fragment_index.fragments[-1]
                    # 从旧分片路径推断名称
                    pass
                # 重建 channels
                # 开始循环遍历处理
                for i, ch_def in enumerate(channels):
                    # 执行条件判断逻辑
                    if i + 1 < len(self._mdf.groups[new_dg].channels):
                        dummy_ch = self._mdf.groups[new_dg].channels[i + 1]
                        dummy_ch.name = ch_def.name
                        dummy_ch.unit = ch_def.unit
                        dummy_ch.comment = ch_def.comment
                        self._mdf.channels_db[ch_def.name] = ((new_dg, i + 1),)
                # 更新层级状态指向新 group
                old_channels = self._group_channels.pop(0, None)
                # 执行条件判断逻辑
                if old_channels is not None:
                    self._group_channels[new_dg] = old_channels
                old_has_real = self._group_has_real_channels.pop(0, False)
                # 执行条件判断逻辑
                if old_has_real:
                    self._group_has_real_channels[new_dg] = old_has_real

        # 执行条件判断逻辑
        if self._header_set and self._header_config is not None:
            self._apply_header_to_mdf(self._mdf, self._header_config)

        # 执行条件判断逻辑
        if self._channels_defined and self._channel_defs:
            self._apply_schema_to_new_fragment()

        # 更新写入统计计数器
        self.stats.fragment_count = self._current_fragment_idx
        # 更新写入统计计数器
        self.stats.fragment_index = self._current_fragment_idx

        # 执行条件判断逻辑
        if self._fragment_index is not None:
            # 操作分片索引文件
            self._fragment_index.add_fragment(
                index=self._current_fragment_idx,
                path=self._current_fragment_path,
                size=0, records=0, start_time=0.0, end_time=0.0,
            )

        # 记录操作成功的信息日志
        # 记录信息级别日志
        logger.info(f"创建新分片 #{self._current_fragment_idx}: {self._current_fragment_path}")


    # -----------------------------------------------------------------
    # _apply_schema_to_new_fragment 方法实现
    # -----------------------------------------------------------------
    def _apply_schema_to_new_fragment(self) -> None:
        """将通道 Schema 应用到新创建的分片。"""
        # 执行条件判断逻辑
        if not self._channel_defs:
            return
        # 初始化信号对象列表容器
        signals = []
        # 开始循环遍历处理
        for ch in self._channel_defs:
            sig = Signal(
                samples=np.array([], dtype=np.dtype(ch.data_type)),
                timestamps=np.array([], dtype=np.float64),
                name=ch.name, unit=ch.unit, comment=ch.comment,
            )
            signals.append(sig)
        # 执行条件判断逻辑
        if signals:
            # 向 MDF 追加新信号数据
            self._mdf.append(signals)


    # -----------------------------------------------------------------
    # _apply_header_to_mdf 方法实现
    # -----------------------------------------------------------------
    def _apply_header_to_mdf(self, mdf: MDF, header: HeaderConfig) -> None:
        """将 HD 块属性应用到 MDF 对象。"""
        # 执行条件判断逻辑
        if not header or header.is_empty():
            return
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            # 执行条件判断逻辑
            if header.comment:
                mdf.header.comment = header.comment
            # 执行条件判断逻辑
            if header.author:
                mdf.header.author = header.author
            # 执行条件判断逻辑
            if header.department:
                mdf.header.department = header.department
            # 执行条件判断逻辑
            if header.project:
                mdf.header.project = header.project
            # 执行条件判断逻辑
            if header.subject:
                mdf.header.subject = header.subject
        # 捕获异常并记录错误日志
        # 捕获并处理异常情况
        except Exception as e:
            # 记录警告信息日志
            # 记录警告信息日志
            # 记录警告级别日志
            logger.warning(f"设置 HD 块属性失败: {e}")


    # -----------------------------------------------------------------
    # _check_fragment_split 方法实现
    # -----------------------------------------------------------------
    def _check_fragment_split(self) -> None:
        """检查是否需要切分新分片。"""
        # 执行条件判断逻辑
        if self.config.operation_mode != OperationMode.FRAGMENTED:
            return
        estimated_size = 64 * 1024 + self._current_fragment_records * 12
        # 执行条件判断逻辑
        if estimated_size >= self.config.fragment_size:
            # 保存当前分片数据
            self._save_current_fragment()
            # 创建新的分片文件
            self._create_new_fragment()

    # ======================================================================
    # DG/CG/CN 层级管理 (v5.0+)
    # ======================================================================


    # -----------------------------------------------------------------
    # create_data_group 方法实现
    # -----------------------------------------------------------------
    def create_data_group(self, name: str = "", comment: str = "",
                           max_channels: int = 16) -> int:
        """
        创建 Data Group（数据组），返回 dg_index。

        ASAM MDF 4.x 中，Data Group 是数据组织的顶层单元。
        本方法通过 append 空的 dummy signals 创建新的空 group。
        预创建 max_channels 个 dummy channel 槽位，供后续 create_channel 替换。

        参数:
            name:         Data Group 名称
            comment:      Data Group 注释
            max_channels: 预创建的 dummy channel 数量（默认 16）

        返回:
            dg_index: 新创建的 Data Group 在 groups 列表中的索引

        示例:
            dg = writer.create_data_group(name="制动测试", comment="前轮制动数据")
            # DG #0 现在包含 time + 16 个 dummy channels
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")

            # 开始异常保护代码块
            try:
                # 预创建多个空的 dummy signals，触发 asammdf 创建新 group
                # 初始化空信号列表容器
                empty_sigs = []
                base_name = f"_dg{len(self._mdf.groups)}"
                # 开始循环遍历处理
                for i in range(max_channels):
                    empty_sig = Signal(
                        samples=np.array([], dtype=np.float64),
                        timestamps=np.array([], dtype=np.float64),
                        name=f"_empty_{base_name}_ch{i}",
                        unit="",
                    )
                    empty_sigs.append(empty_sig)

                # 向 MDF 追加新信号数据
                dg_idx = self._mdf.append(empty_sigs)

                # 设置 Data Group 属性
                dg = self._mdf.groups[dg_idx].data_group
                dg.comment = comment or name or ""

                # 初始化层级状态
                self._group_channels[dg_idx] = []
                self._group_has_real_channels[dg_idx] = False

                # 记录操作成功的信息日志
                # 记录信息级别日志
                logger.info(
                    f"创建 Data Group #{dg_idx}: name={name!r}, "
                    f"预创建 {max_channels} 个 channel 槽位"
                )
                # 返回新创建的 Data Group 索引
                # 返回函数执行结果
                return dg_idx

            # 捕获并处理异常情况
            except Exception as e:
                # 记录错误信息日志
                # 记录错误级别日志
                logger.error(f"创建 Data Group 失败: {e}", exc_info=True)
                raise MDFWriterHierarchyError(f"创建 Data Group 失败: {e}") from e


    # -----------------------------------------------------------------
    # create_channel_group 方法实现
    # -----------------------------------------------------------------
    def create_channel_group(self, dg_index: int, name: str = "", comment: str = "") -> int:
        """
        在指定 Data Group 下创建 Channel Group（通道组），返回 cg_index。

        ASAM MDF 4.x 中，Channel Group 位于 Data Group 之下，
        包含一组逻辑相关的通道（如温度传感器组、压力传感器组）。

        重要说明：
            asammdf 的实现中，每个 Data Group 只有一个 Channel Group。
            因此 cg_index 始终为 0。返回值固定为 0 是为了与未来可能的
            多 CG 支持保持 API 兼容性。

        参数:
            dg_index: 目标 Data Group 的索引
            name:     Channel Group 名称
            comment:  Channel Group 注释

        返回:
            cg_index: 在 asammdf 中固定为 0

        示例:
            cg = writer.create_channel_group(dg, name="温度组", comment="刹车盘温度")
            print(f"创建 Channel Group #{cg} in DG #{dg}")

        异常:
            MDFWriterStateError:     文件未打开
            MDFWriterHierarchyError: dg_index 无效
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")

            # 验证 dg_index
            # 执行条件判断逻辑
            if not (0 <= dg_index < len(self._mdf.groups)):
                raise MDFWriterHierarchyError(
                    f"dg_index {dg_index} 无效，当前有 {len(self._mdf.groups)} 个 Data Group"
                )

            # 开始异常保护代码块
            try:
                # 设置 Channel Group 属性
                cg = self._mdf.groups[dg_index].channel_group
                cg.comment = comment or name or ""

                # 记录操作成功的信息日志
                # 记录信息级别日志
                logger.info(
                    f"创建 Channel Group in DG #{dg_index}: "
                    f"name={name!r}, comment={comment!r}"
                )
                # asammdf 中每个 DG 只有一个 CG，cg_index 固定为 0
                # 返回 Channel Group 索引（asammdf 中固定为 0）
                # 返回函数执行结果
                return 0

            # 捕获并处理异常情况
            except Exception as e:
                # 记录错误信息日志
                # 记录错误级别日志
                logger.error(f"创建 Channel Group 失败: {e}", exc_info=True)
                raise MDFWriterHierarchyError(f"创建 Channel Group 失败: {e}") from e


    # -----------------------------------------------------------------
    # create_channel 方法实现
    # -----------------------------------------------------------------
    def create_channel(self, dg_index: int, cg_index: int,
                       channel_def: ChannelDef) -> int:
        """
        在指定 Channel Group 下创建 Channel（通道），返回 cn_index。

        实现策略（基于 asammdf 限制）：
            asammdf 的 append() 不支持在已有 group 中添加新 channel。
            因此本方法采用"替换 dummy channel"策略：
                1. 遍历 group.channels 查找可用的 dummy channel（名字以 _empty_ 开头）
                2. 修改 dummy channel 的属性（name, unit, comment）
                3. 更新 channels_db 索引映射

        参数:
            dg_index:     目标 Data Group 的索引
            cg_index:     目标 Channel Group 的索引（固定为 0）
            channel_def:  通道定义（ChannelDef 对象）

        返回:
            cn_index: Channel 在 group.channels 列表中的索引（[0] 为 time）

        示例:
            cn = writer.create_channel(dg, cg, ChannelDef("Speed", "km/h", "<f4"))

        异常:
            MDFWriterStateError:      文件未打开
            MDFWriterValidationError:  通道名重复
            MDFWriterHierarchyError:  dg_index 无效或 dummy channel 耗尽
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")

            # 执行条件判断逻辑
            if not (0 <= dg_index < len(self._mdf.groups)):
                raise MDFWriterHierarchyError(
                    f"dg_index {dg_index} 无效，当前有 {len(self._mdf.groups)} 个 Data Group"
                )

            group = self._mdf.groups[dg_index]
            existing_names = {c.name for c in group.channels if c.name and not c.name.startswith("_")}
            # 执行条件判断逻辑
            if channel_def.name in existing_names:
                raise MDFWriterValidationError(
                    f"通道名称 '{channel_def.name}' 在 DG #{dg_index} 中已存在"
                )

            # 开始异常保护代码块
            try:
                # 查找可用的 dummy channel
                dummy_ch = None
                dummy_idx = -1
                # 开始循环遍历处理
                for i in range(1, len(group.channels)):
                    ch = group.channels[i]
                    # 执行条件判断逻辑
                    if ch.name.startswith("_empty_"):
                        dummy_ch = ch
                        dummy_idx = i
                        break

                # 执行条件判断逻辑
                if dummy_ch is None:
                    raise MDFWriterHierarchyError(
                        f"DG #{dg_index} 没有可用的空 channel 槽位。"
                        f"请创建新的 Data Group 或增加 max_channels。"
                    )

                # 修改 dummy channel 属性
                dummy_ch.name = channel_def.name
                dummy_ch.unit = channel_def.unit
                dummy_ch.comment = channel_def.comment

                # 更新 channels_db（删除旧条目，添加新条目）
                old_names_to_remove = [k for k in self._mdf.channels_db if k.startswith("_empty_")]
                # 开始循环遍历处理
                for old_name in old_names_to_remove:
                    # 执行条件判断逻辑
                    if old_name in self._mdf.channels_db:
                        del self._mdf.channels_db[old_name]

                # 重新注册所有非 dummy channels
                # 开始循环遍历处理
                for i in range(1, len(group.channels)):
                    ch = group.channels[i]
                    # 执行条件判断逻辑
                    if not ch.name.startswith("_empty_"):
                        self._mdf.channels_db[ch.name] = ((dg_index, i),)

                # 更新层级状态
                # 执行条件判断逻辑
                if dg_index not in self._group_channels:
                    self._group_channels[dg_index] = []
                self._group_channels[dg_index].append(channel_def)
                self._group_has_real_channels[dg_index] = True

                # 记录操作成功的信息日志
                # 记录信息级别日志
                logger.info(
                    f"创建 Channel #{dummy_idx} in DG #{dg_index}: "
                    f"name={channel_def.name!r}, unit={channel_def.unit!r}"
                )
                # 返回新创建的 Channel 索引
                # 返回函数执行结果
                return dummy_idx

            # 捕获并处理异常情况
            except (MDFWriterValidationError, MDFWriterHierarchyError):
                raise
            # 捕获异常并记录错误日志
            # 捕获并处理异常情况
            except Exception as e:
                # 记录错误信息日志
                # 记录错误级别日志
                logger.error(f"创建 Channel 失败: {e}", exc_info=True)
                raise MDFWriterHierarchyError(f"创建 Channel 失败: {e}") from e


    # -----------------------------------------------------------------
    # append_to_data_group 方法实现
    # -----------------------------------------------------------------
    def append_to_data_group(self, dg_index: int,
                              values: Dict[str, List[Any]],
                              timestamps: List[float]) -> int:
        """
        向指定 Data Group 追加连续数据。

        使用 asammdf 的 extend() 方法向已有 group 追加数据。
        自动为 dummy channels 填充空数组。

        参数:
            dg_index:   目标 Data Group 的索引
            values:     通道名 -> 样本列表的字典
            timestamps: 时间戳列表（所有通道共享）

        返回:
            实际追加的记录数
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")

            # 执行条件判断逻辑
            if not (0 <= dg_index < len(self._mdf.groups)):
                raise MDFWriterHierarchyError(
                    f"dg_index {dg_index} 无效，当前有 {len(self._mdf.groups)} 个 Data Group"
                )

            record_count = len(timestamps)
            # 执行条件判断逻辑
            if record_count == 0:
                # 返回 Channel Group 索引（asammdf 中固定为 0）
                # 返回函数执行结果
                return 0

            # 验证样本数匹配
            # 开始循环遍历处理
            for name, samples in values.items():
                # 执行条件判断逻辑
                if len(samples) != record_count:
                    raise MDFWriterValidationError(
                        f"通道 '{name}' 样本数 ({len(samples)}) 与时间戳数 ({record_count}) 不匹配"
                    )

            # 构建 extend 所需的数据
            group = self._mdf.groups[dg_index]
            extend_signals = []
            provided_channels = set()

            # 开始循环遍历处理
            for ch in group.channels:
                # 执行条件判断逻辑
                if ch.name == 'time' or ch.name is None:
                    # time 通道提供 timestamps
                    extend_signals.append((np.array(timestamps, dtype=np.float64), None))
                # 执行额外条件判断
                elif ch.name in values:
                    # 数据通道提供 samples
                    extend_signals.append((np.array(values[ch.name]), None))
                    provided_channels.add(ch.name)
                # 执行额外条件判断
                elif ch.name.startswith("_empty_"):
                    # dummy channel 提供空数组
                    extend_signals.append((np.array([]), None))
                # 处理其他分支情况
                else:
                    # 未提供数据的 channel（非 dummy），提供空数组
                    extend_signals.append((np.array([]), None))

            # 检查是否有未匹配的数据通道
            # 开始循环遍历处理
            for name in values:
                # 执行条件判断逻辑
                if name not in provided_channels:
                    raise MDFWriterValidationError(
                        f"通道 '{name}' 在 DG #{dg_index} 中不存在"
                    )

            # 执行 extend
            # 开始异常保护代码块
            try:
                # 扩展现有通道的数据记录
                self._mdf.extend(dg_index, extend_signals)
            # 捕获并处理异常情况
            except Exception as e:
                # 记录错误信息日志
                # 记录错误级别日志
                logger.error(f"extend 失败: {e}", exc_info=True)
                raise MDFWriterHierarchyError(f"向 DG #{dg_index} 追加数据失败: {e}") from e

            # 更新统计
            # 更新写入统计计数器
            self.stats.total_records_written += record_count
            # 更新写入统计计数器
            self.stats.total_signals_written += len(values)

            # 分片模式：更新记录计数并检查切分
            # 执行条件判断逻辑
            if self.config.operation_mode == OperationMode.FRAGMENTED:
                self._current_fragment_records += record_count
                # 检查是否需要分片切分
                self._check_fragment_split()

            # 记录调试信息日志
            # 记录调试信息日志
        # 记录调试级别日志
        logger.debug(f"向 DG #{dg_index} 追加 {record_count} 条记录")
            # 返回成功追加的记录数
        # 返回函数执行结果
        return record_count


    # -----------------------------------------------------------------
    # get_hierarchy_info 方法实现
    # -----------------------------------------------------------------
    def get_hierarchy_info(self) -> Dict[str, Any]:
        """
        获取当前层级结构信息。

        返回:
            包含所有 DG、CG、CN 层级信息的字典（跳过 dummy channels）
        """
        with self._lock:
            info = {"data_groups": []}
            # 执行条件判断逻辑
            if self._mdf is None:
                # 返回函数执行结果
                return info

            # 开始循环遍历处理
            for dg_idx, group in enumerate(self._mdf.groups):
                dg_info = {
                    "dg_index": dg_idx,
                    "name": getattr(group.data_group, 'comment', ''),
                    "channel_groups": [],
                }
                cg = group.channel_group
                cg_info = {
                    "cg_index": 0,
                    "name": getattr(cg, 'comment', ''),
                    "channels": [],
                }
                # 开始循环遍历处理
                for cn_idx, ch in enumerate(group.channels):
                    # 执行条件判断逻辑
                    if cn_idx == 0:
                        continue  # skip time channel
                    # 执行条件判断逻辑
                    if ch.name and ch.name.startswith("_empty_"):
                        continue  # skip dummy channels
                    cg_info["channels"].append({
                        "cn_index": cn_idx,
                        "name": ch.name,
                        "unit": ch.unit,
                    })
                dg_info["channel_groups"].append(cg_info)
                info["data_groups"].append(dg_info)

            # 返回函数执行结果
            return info

    # ======================================================================
    # HD 块属性设置
    # ======================================================================


    # -----------------------------------------------------------------
    # set_header 方法实现
    # -----------------------------------------------------------------
    def set_header(self, header: HeaderConfig) -> None:
        """
        设置 MDF HD（Header）块属性。

        在 FRAGMENTED 模式下，当前分片立即应用，后续新建分片自动同步。

        参数:
            header: HeaderConfig 配置对象

        异常:
            MDFWriterStateError: 文件未打开
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")

            self._header_config = header
            self._header_set = True

            # 执行条件判断逻辑
            if self._mdf is not None:
                self._apply_header_to_mdf(self._mdf, header)

            # 记录操作成功的信息日志
            # 记录操作成功的信息日志
        # 记录信息级别日志
        logger.info(
                f"HD 块属性已设置: author={header.author}, "
                f"department={header.department}, project={header.project}"
            )

    # ======================================================================
    # 后台线程（STREAMING 模式）
    # ======================================================================


    # -----------------------------------------------------------------
    # _start_background_thread 方法实现
    # -----------------------------------------------------------------
    def _start_background_thread(self) -> None:
        """启动后台刷盘线程。"""
        self._bg_stop_event.clear()
        self._bg_thread = threading.Thread(
            target=self._background_flush_loop,
            name="MDFWriter-BGFlush",
            daemon=True,
        )
        self._bg_thread.start()


    # -----------------------------------------------------------------
    # _background_flush_loop 方法实现
    # -----------------------------------------------------------------
    def _background_flush_loop(self) -> None:
        """后台刷盘循环。"""
        interval_s = self.config.stream_flush_interval_ms / 1000.0
        while not self._bg_stop_event.is_set():
            stopped = self._bg_stop_event.wait(timeout=interval_s)
            # 执行条件判断逻辑
            if stopped:
                break
            with self._lock:
                # 执行条件判断逻辑
                if not self._is_open:
                    break
                # 执行所有数据刷盘操作
                self._do_flush_all()


    # -----------------------------------------------------------------
    # _stop_background_thread 方法实现
    # -----------------------------------------------------------------
    def _stop_background_thread(self) -> None:
        """停止后台刷盘线程。"""
        # 执行条件判断逻辑
        if self._bg_thread and self._bg_thread.is_alive():
            self._bg_stop_event.set()
            self._bg_thread.join(timeout=5.0)
            self._bg_thread = None

    # ======================================================================
    # 通道定义（传统方式，兼容 v4.x）
    # ======================================================================


    # -----------------------------------------------------------------
    # define_channels 方法实现
    # -----------------------------------------------------------------
    def define_channels(self, channels: List[ChannelDef],
                         continuity: DataContinuity = DataContinuity.CONTINUOUS) -> None:
        """
        定义通道布局（Schema）。兼容 v4.x 传统方式。

        在 v5.0+ 中，推荐使用 create_data_group / create_channel 的层级方式。
        此方法仍然可用，为向后兼容保留。

        参数:
            channels:   通道定义列表
            continuity: 数据连续性类型

        异常:
            MDFWriterStateError:     文件未打开
            MDFWriterValidationError: 通道列表为空或名称重复
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            # 执行条件判断逻辑
            if not channels:
                raise MDFWriterValidationError("通道列表不能为空")

            names = [ch.name for ch in channels]
            # 执行条件判断逻辑
            if len(names) != len(set(names)):
                raise MDFWriterValidationError("通道名称必须唯一")

            self._channel_defs = list(channels)
            self._channels_defined = True
            self._continuity = continuity

            # 初始化缓冲区
            self._cont_buffer = _ContinuousBuffer()
            # 开始循环遍历处理
            for ch in channels:
                # 执行条件判断逻辑
                if ch.name not in self._cont_buffer.samples:
                    self._cont_buffer.samples[ch.name] = []

            # 分片模式：保存 Schema 到索引
            # 执行条件判断逻辑
            if self._fragment_index is not None:
                # 操作分片索引文件
                self._fragment_index.set_schema(self._channel_defs)
                # 操作分片索引文件
                self._fragment_index.save()

            # 记录操作成功的信息日志
            # 记录操作成功的信息日志
        # 记录信息级别日志
        logger.info(f"通道定义完成: {len(channels)} 个通道")

    # ======================================================================
    # 连续数据写入（兼容 v4.x + 支持 dg_index）
    # ======================================================================


    # -----------------------------------------------------------------
    # append_continuous 方法实现
    # -----------------------------------------------------------------
    def append_continuous(self, values: Dict[str, List[Any]],
                           timestamps: List[float],
                           dg_index: Optional[int] = None) -> int:
        """
        追加连续数据。

        v5.0+ 新增 dg_index 参数，支持指定目标 Data Group。
        当 dg_index 为 None 时，使用传统行为（创建新 group 或缓冲）。

        参数:
            values:     通道名 -> 样本列表的字典
            timestamps: 时间戳列表
            dg_index:   目标 Data Group 索引（None 则使用默认行为）

        返回:
            实际写入（或缓冲）的记录数
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            # 执行条件判断逻辑
            if not self._channels_defined and dg_index is None:
                raise MDFWriterStateError("通道未定义，请先调用 define_channels()")

            record_count = len(timestamps)
            # 执行条件判断逻辑
            if record_count == 0:
                # 返回 Channel Group 索引（asammdf 中固定为 0）
                # 返回函数执行结果
                return 0

            # 开始循环遍历处理
            for name, samples in values.items():
                # 执行条件判断逻辑
                if len(samples) != record_count:
                    raise MDFWriterValidationError(
                        f"通道 '{name}' 样本数 ({len(samples)}) 与 "
                        f"时间戳数 ({record_count}) 不匹配"
                    )

            # 如果指定了 dg_index，直接追加到该 group
            # 执行条件判断逻辑
            if dg_index is not None:
                # 返回函数执行结果
                return self.append_to_data_group(dg_index, values, timestamps)

            # 否则使用传统行为
            # 执行条件判断逻辑
            if self.config.operation_mode == OperationMode.NORMAL:
                self._write_direct_continuous(values, timestamps)
            # 处理其他分支情况
            else:
                self._write_buffered_continuous(values, timestamps)

            # 更新写入统计计数器
            self.stats.total_records_written += record_count
            # 更新写入统计计数器
            self.stats.total_signals_written += len(values)
            # 返回成功追加的记录数
        # 返回函数执行结果
        return record_count


    # -----------------------------------------------------------------
    # _write_direct_continuous 方法实现
    # -----------------------------------------------------------------
    def _write_direct_continuous(self, values: Dict[str, List[Any]],
                                  timestamps: List[float]) -> None:
        """直接写入连续数据（NORMAL 模式）。"""
        # 根据样本构建信号对象
        signals = self._create_signals(values, timestamps)
        # 向 MDF 追加新信号数据
        self._mdf.append(signals)
        self._last_flush_time = time.time()


    # -----------------------------------------------------------------
    # _write_buffered_continuous 方法实现
    # -----------------------------------------------------------------
    def _write_buffered_continuous(self, values: Dict[str, List[Any]],
                                    timestamps: List[float]) -> None:
        """缓冲写入连续数据（FRAGMENTED/STREAMING 模式）。"""
        # 开始循环遍历处理
        for i, ts in enumerate(timestamps):
            record_values = {name: vals[i] for name, vals in values.items()}
            self._cont_buffer.add_record(ts, record_values)

        # 更新写入统计计数器
        self.stats.buffer_records_current = self._cont_buffer.record_count
        # 更新写入统计计数器
        self.stats.buffer_records_peak = max(
            self.stats.buffer_records_peak,
            self.stats.buffer_records_current
        )
        self._check_flush_continuous()
        if (self.config.operation_mode == OperationMode.FRAGMENTED
                and self._cont_buffer.is_empty()):
            # 检查是否需要分片切分
            self._check_fragment_split()


    # -----------------------------------------------------------------
    # _check_flush_continuous 方法实现
    # -----------------------------------------------------------------
    def _check_flush_continuous(self) -> None:
        """检查并执行连续数据刷盘。"""
        # 执行条件判断逻辑
        if self._cont_buffer.is_empty():
            return
        need_flush = False
        # 执行条件判断逻辑
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            # 执行条件判断逻辑
            if self._cont_buffer.record_count >= 1000:
                need_flush = True
        # 执行额外条件判断
        elif self.config.operation_mode == OperationMode.STREAMING:
            # 执行条件判断逻辑
            if not self.config.stream_enable_background_thread:
                # 执行条件判断逻辑
                if self._cont_buffer.record_count >= self.config.stream_buffer_size:
                    need_flush = True
                # 处理其他分支情况
                else:
                    elapsed = (time.time() - self._last_flush_time) * 1000
                    # 执行条件判断逻辑
                    if elapsed >= self.config.stream_flush_interval_ms:
                        need_flush = True
        # 执行条件判断逻辑
        if need_flush:
            # 刷盘连续数据缓冲区
            self._do_flush_continuous()


    # -----------------------------------------------------------------
    # _do_flush_continuous 方法实现
    # -----------------------------------------------------------------
    def _do_flush_continuous(self) -> None:
        """执行连续数据刷盘。"""
        # 执行条件判断逻辑
        if self._cont_buffer.is_empty():
            return
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            timestamps = self._cont_buffer.timestamps
            values = self._cont_buffer.samples
            # 根据样本构建信号对象
            signals = self._create_signals(values, timestamps)
            # 向 MDF 追加新信号数据
            self._mdf.append(signals)

            record_count = self._cont_buffer.record_count
            self._current_fragment_records += record_count

            self._cont_buffer.clear()
            # 更新写入统计计数器
            self.stats.buffer_records_current = 0
            # 更新写入统计计数器
            self.stats.total_flush_count += 1
            # 更新写入统计计数器
            self.stats.last_flush_timestamp = time.time()
            self._last_flush_time = time.time()

            # 记录调试信息日志
            # 记录调试级别日志
            logger.debug(f"连续数据刷盘: {record_count} 条记录")
        # 捕获并处理异常情况
        except Exception as e:
            # 记录错误信息日志
            # 记录错误级别日志
            logger.error(f"连续数据刷盘失败: {e}", exc_info=True)
            # 更新写入统计计数器
            self.stats.error_count += 1
            raise


    # -----------------------------------------------------------------
    # _save_current_fragment 方法实现
    # -----------------------------------------------------------------
    def _save_current_fragment(self) -> None:
        """保存当前分片文件并更新索引。"""
        # 执行条件判断逻辑
        if self._fragment_index is None:
            return
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            # 获取当前压缩配置参数
            compression = self._get_compression()
            # 保存 MDF 文件数据到磁盘
            self._mdf.save(
                self._current_fragment_path,
                overwrite=True,
                compression=compression
            )
            # 执行条件判断逻辑
            if self._fragment_index.fragments:
                # 操作分片索引文件
                last_frag = self._fragment_index.fragments[-1]
                last_frag["size"] = os.path.getsize(self._current_fragment_path)
                last_frag["records"] = self._current_fragment_records
                # 操作分片索引文件
                self._fragment_index.save()
            # 记录调试信息日志
            # 记录调试级别日志
            logger.debug(f"分片 #{self._current_fragment_idx} 已保存")
        # 捕获并处理异常情况
        except Exception as e:
            # 记录警告信息日志
            # 记录警告级别日志
            logger.warning(f"保存分片失败: {e}")

    # ======================================================================
    # 间歇数据写入
    # ======================================================================


    # -----------------------------------------------------------------
    # append_intermittent 方法实现
    # -----------------------------------------------------------------
    def append_intermittent(self, channel_name: str,
                             timestamp: float, value: Any,
                             dg_index: Optional[int] = None) -> None:
        """
        追加间歇数据。

        v5.0+ 新增 dg_index 参数。

        参数:
            channel_name: 通道名称
            timestamp:    时间戳
            value:        通道值
            dg_index:     目标 Data Group 索引（None 则使用默认行为）
        """
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            # 执行条件判断逻辑
            if not self._channels_defined and dg_index is None:
                raise MDFWriterStateError("通道未定义，请先调用 define_channels()")

            # 执行条件判断逻辑
            if dg_index is not None:
                # 直接追加到指定 DG
                channel_names = {ch.name for ch in self._group_channels.get(dg_index, [])}
                # 执行条件判断逻辑
                if channel_name not in channel_names:
                    raise MDFWriterValidationError(
                        f"通道 '{channel_name}' 在 DG #{dg_index} 中未定义"
                    )
                # 对于间歇数据到指定 DG，需要先构建 signals
                self._write_intermittent_to_group(dg_index, channel_name, timestamp, value)
                # 执行条件判断逻辑
                if self.config.operation_mode == OperationMode.FRAGMENTED:
                    self._current_fragment_records += 1
                    # 检查是否需要分片切分
                    self._check_fragment_split()
                return

            # 传统行为
            channel_names = {ch.name for ch in self._channel_defs}
            # 执行条件判断逻辑
            if channel_name not in channel_names:
                raise MDFWriterValidationError(
                    f"通道 '{channel_name}' 未定义"
                )

            # 执行条件判断逻辑
            if self.config.operation_mode == OperationMode.NORMAL:
                self._write_direct_intermittent(channel_name, timestamp, value)
            # 处理其他分支情况
            else:
                self._inter_buffer.add_record(timestamp, channel_name, value)
                # 执行条件判断逻辑
                if self.config.operation_mode == OperationMode.FRAGMENTED:
                    self._current_fragment_records += 1
                    # 检查是否需要分片切分
                    self._check_fragment_split()
                self._check_flush_intermittent()


    # -----------------------------------------------------------------
    # _write_intermittent_to_group 方法实现
    # -----------------------------------------------------------------
    def _write_intermittent_to_group(self, dg_index: int, channel_name: str,
                                      timestamp: float, value: Any) -> None:
        """向指定 Data Group 写入单条间歇数据。"""
        unit = ""
        dtype = "<f4"
        # 开始循环遍历处理
        for ch in self._group_channels.get(dg_index, []):
            # 执行条件判断逻辑
            if ch.name == channel_name:
                unit = ch.unit
                dtype = ch.data_type
                break

        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            sample_array = np.array([value], dtype=np.dtype(dtype))
        # 捕获并处理异常情况
        except (TypeError, ValueError):
            sample_array = np.array([value])

        sig = Signal(
            samples=sample_array,
            timestamps=np.array([timestamp], dtype=np.float64),
            name=channel_name,
            unit=unit,
        )
        # 向 MDF 追加新信号数据
        self._mdf.append([sig])


    # -----------------------------------------------------------------
    # _write_direct_intermittent 方法实现
    # -----------------------------------------------------------------
    def _write_direct_intermittent(self, channel_name: str,
                                    timestamp: float, value: Any) -> None:
        """直接写入间歇数据（NORMAL 模式）。"""
        unit = ""
        dtype = "<f4"
        # 开始循环遍历处理
        for ch in self._channel_defs:
            # 执行条件判断逻辑
            if ch.name == channel_name:
                unit = ch.unit
                dtype = ch.data_type
                break

        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            sample_array = np.array([value], dtype=np.dtype(dtype))
        # 捕获并处理异常情况
        except (TypeError, ValueError):
            sample_array = np.array([value])

        sig = Signal(
            samples=sample_array,
            timestamps=np.array([timestamp], dtype=np.float64),
            name=channel_name,
            unit=unit,
        )
        # 向 MDF 追加新信号数据
        self._mdf.append([sig])


    # -----------------------------------------------------------------
    # _check_flush_intermittent 方法实现
    # -----------------------------------------------------------------
    def _check_flush_intermittent(self) -> None:
        """检查间歇数据是否需要刷盘。"""
        # 执行条件判断逻辑
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            # 执行条件判断逻辑
            if self._inter_buffer.get_record_count() >= 1000:
                # 刷盘间歇数据缓冲区
                self._do_flush_intermittent()


    # -----------------------------------------------------------------
    # _do_flush_intermittent 方法实现
    # -----------------------------------------------------------------
    def _do_flush_intermittent(self) -> None:
        """执行间歇数据刷盘。"""
        # 执行条件判断逻辑
        if self._inter_buffer.is_empty():
            return
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            channel_data: Dict[str, Tuple[List[float], List[Any]]] = {}
            # 开始循环遍历处理
            for ts, name, val in self._inter_buffer.records:
                # 执行条件判断逻辑
                if name not in channel_data:
                    channel_data[name] = ([], [])
                channel_data[name][0].append(ts)
                channel_data[name][1].append(val)

            # 开始循环遍历处理
            for name, (tss, samples) in channel_data.items():
                unit = ""
                # 开始循环遍历处理
                for ch in self._channel_defs:
                    # 执行条件判断逻辑
                    if ch.name == name:
                        unit = ch.unit
                        break
                sig = Signal(
                    samples=np.array(samples),
                    timestamps=np.array(tss, dtype=np.float64),
                    name=name,
                    unit=unit,
                )
                # 向 MDF 追加新信号数据
                self._mdf.append([sig])

            self._inter_buffer.clear()
            # 更新写入统计计数器
            self.stats.total_flush_count += 1

            # 执行条件判断逻辑
            if self.config.operation_mode == OperationMode.FRAGMENTED:
                # 保存当前分片数据
                self._save_current_fragment()

            # 记录调试信息日志
            # 记录调试级别日志
            logger.debug("间歇数据刷盘完成")
        # 捕获并处理异常情况
        except Exception as e:
            # 记录错误信息日志
            # 记录错误级别日志
            logger.error(f"间歇数据刷盘失败: {e}", exc_info=True)
            # 更新写入统计计数器
            self.stats.error_count += 1
            raise

    # ======================================================================
    # 工具方法
    # ======================================================================


    # -----------------------------------------------------------------
    # _create_signals 方法实现
    # -----------------------------------------------------------------
    def _create_signals(self, values: Dict[str, List[Any]],
                         timestamps: List[float]) -> List[Signal]:
        """将数据字典转换为 asammdf.Signal 列表。"""
        # 初始化信号对象列表容器
        signals = []
        ts_array = np.array(timestamps, dtype=np.float64)
        # 开始循环遍历处理
        for name, samples in values.items():
            unit = ""
            # 开始循环遍历处理
            for ch in self._channel_defs:
                # 执行条件判断逻辑
                if ch.name == name:
                    unit = ch.unit
                    break
            # 如果没有在 _channel_defs 中找到，尝试在层级中查找
            # 执行条件判断逻辑
            if not unit:
                # 开始循环遍历处理
                for dg_channels in self._group_channels.values():
                    # 开始循环遍历处理
                    for ch in dg_channels:
                        # 执行条件判断逻辑
                        if ch.name == name:
                            unit = ch.unit
                            break
            sig = Signal(
                samples=np.array(samples),
                timestamps=ts_array,
                name=name,
                unit=unit,
            )
            signals.append(sig)
        # 返回函数执行结果
        return signals


    # -----------------------------------------------------------------
    # _get_compression 方法实现
    # -----------------------------------------------------------------
    def _get_compression(self) -> int:
        """获取 asammdf 压缩算法枚举值。"""
        compression_map = {
            CompressionType.NONE: CompressionAlgorithm.NO_COMPRESSION,
            CompressionType.ZIP: CompressionAlgorithm.DEFLATE,
            CompressionType.ZSTD: CompressionAlgorithm.ZSTD,
        }
        # 返回函数执行结果
        return compression_map.get(
            self.config.compression,
            CompressionAlgorithm.NO_COMPRESSION
        )

    # ======================================================================
    # 公共方法
    # ======================================================================


    # -----------------------------------------------------------------
    # flush 方法实现
    # -----------------------------------------------------------------
    def flush(self) -> None:
        """手动刷盘所有缓冲区数据。"""
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                return
            # 执行所有数据刷盘操作
            self._do_flush_all()


    # -----------------------------------------------------------------
    # _do_flush_all 方法实现
    # -----------------------------------------------------------------
    def _do_flush_all(self) -> None:
        """刷盘所有数据（连续 + 间歇）。"""
        # 刷盘连续数据缓冲区
        self._do_flush_continuous()
        # 刷盘间歇数据缓冲区
        self._do_flush_intermittent()


    # -----------------------------------------------------------------
    # get_fragment_paths 方法实现
    # -----------------------------------------------------------------
    def get_fragment_paths(self) -> List[str]:
        """获取所有存在的分片文件路径（分片模式）。"""
        with self._lock:
            # 执行条件判断逻辑
            if self._fragment_index is not None:
                # 返回函数执行结果
                return [
                    # 操作分片索引文件
                    p for p in self._fragment_index.get_all_fragment_paths()
                    if os.path.exists(p)
                ]
            # 返回函数执行结果
            return []


    # -----------------------------------------------------------------
    # get_info 方法实现
    # -----------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        """获取写入器状态信息。"""
        with self._lock:
            info = {
                "filepath": self.filepath,
                "version": self.config.version,
                "operation_mode": self.config.operation_mode.value,
                "compression": self.config.compression.value,
                "is_open": self._is_open,
                "channels_defined": self._channels_defined,
                "channel_count": len(self._channel_defs),
                "channel_names": [ch.name for ch in self._channel_defs],
                "header_set": self._header_set,
                "stats": self.stats.to_dict(),
                "hierarchy": self.get_hierarchy_info(),
            }
            # 执行条件判断逻辑
            if self._fragment_index is not None:
                # 操作分片索引文件
                info["fragment_count"] = len(self._fragment_index.fragments)
                # 操作分片索引文件
                info["fragment_paths"] = self._fragment_index.get_all_fragment_paths()
                # 操作分片索引文件
                info["fragment_folder"] = self._fragment_index.fragment_folder
                # 操作分片索引文件
                info["total_size"] = self._fragment_index.total_size()
                # 操作分片索引文件
                info["total_records"] = self._fragment_index.total_records()
            # 返回函数执行结果
            return info

    # ======================================================================
    # 关闭和资源释放
    # ======================================================================


    # -----------------------------------------------------------------
    # close 方法实现
    # -----------------------------------------------------------------
    def close(self) -> None:
        """关闭写入器并释放所有资源。"""
        with self._lock:
            # 执行条件判断逻辑
            if not self._is_open:
                return

            # 记录操作成功的信息日志
            # 记录信息级别日志
            logger.info("正在关闭 MDFWriter...")
            # 开始尝试执行核心操作
            # 开始异常保护代码块
            try:
                # 停止后台刷盘线程
                self._stop_background_thread()
                # 执行所有数据刷盘操作
                self._do_flush_all()

                # 执行条件判断逻辑
                if self._mdf is not None:
                    # 获取当前压缩配置参数
                    compression = self._get_compression()
                    # 执行条件判断逻辑
                    if self.config.operation_mode == OperationMode.FRAGMENTED:
                        # 开始异常保护代码块
                        try:
                            # 保存 MDF 文件数据到磁盘
                            self._mdf.save(
                                self._current_fragment_path,
                                overwrite=True,
                                compression=compression
                            )
                            # 执行条件判断逻辑
                            if self._fragment_index and self._fragment_index.fragments:
                                # 操作分片索引文件
                                last = self._fragment_index.fragments[-1]
                                last["size"] = os.path.getsize(self._current_fragment_path)
                                last["records"] = self._current_fragment_records
                                # 操作分片索引文件
                                self._fragment_index.save()
                        # 捕获并处理异常情况
                        except Exception as e:
                            # 记录警告信息日志
                            # 记录警告级别日志
                            logger.warning(f"保存最终分片失败: {e}")
                            # 关闭当前 MDF 文件句柄
                            self._mdf.close()
                    # 处理其他分支情况
                    else:
                        # 保存 MDF 文件数据到磁盘
                        self._mdf.save(self.filepath, overwrite=True, compression=compression)
                        # 关闭当前 MDF 文件句柄
                        self._mdf.close()
                    # 释放 MDF 对象引用
                    self._mdf = None

                # 标记写入器为已关闭状态
                self._is_open = False
                # 更新写入统计计数器
                self.stats.uptime_seconds = time.time() - self._start_time
                # 记录操作成功的信息日志
                # 记录信息级别日志
                logger.info("MDFWriter 已关闭")
            # 捕获并处理异常情况
            except Exception as e:
                # 记录错误信息日志
                # 记录错误级别日志
                logger.error(f"关闭 MDFWriter 失败: {e}", exc_info=True)
                # 更新写入统计计数器
                self.stats.error_count += 1
                raise

    def __enter__(self):
        """上下文管理器入口。"""
        # 返回函数执行结果
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口。确保自动关闭。"""
        # 开始尝试执行核心操作
        # 开始异常保护代码块
        try:
            self.close()
        # 捕获并处理异常情况
        except Exception:
            pass
        # 返回函数执行结果
        return False


# =============================================================================
# 追加写入器类
# =============================================================================

class MDFAppendWriter(MDFWriter):
    """追加写入器（用于在已有文件上追加数据）。继承自 MDFWriter。"""

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        # 执行条件判断逻辑
        if config is None:
            config = MDFConfig(operation_mode=OperationMode.NORMAL)
        super().__init__(filepath, config)


# =============================================================================
# 模块导出
# =============================================================================

__all__ = [
    "MDFWriter",
    "MDFAppendWriter",
    "FragmentIndex",
    "MDFWriterError",
    "MDFWriterStateError",
    "MDFWriterValidationError",
    "MDFWriterModeError",
    "MDFWriterThreadError",
    "MDFWriterHierarchyError",
]
