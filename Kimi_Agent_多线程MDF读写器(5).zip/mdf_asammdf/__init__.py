# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器包

基于 asammdf 库构建的生产级多线程 MDF 文件读写器。
支持三种操作模式（NORMAL / FRAGMENTED / STREAMING），
连续和间歇数据写入，分片子文件夹存储，HD 块属性修改，
以及持久化追加功能。

核心特性：
    1. 三种操作模式：
       - NORMAL:     单文件直接写入，简单高效
       - FRAGMENTED: 以体积阈值自动切分为多个独立文件
       - STREAMING:  带缓冲区和后台刷盘线程，适合实时采集

    2. 分片模式存储结构：
       分片文件存储在独立子文件夹中（base_fragments/）：
           data.mf4 -> data_fragments/data_001.mf4, data_002.mf4, ...
           索引文件:  data_fragments/index.json
       便于文件管理和归档。

    3. HD 块属性支持：
       通过 set_header() / get_header() 方法可读写 MDF 文件
       Header (HD) 块的元数据，包括作者、部门、项目、主题、注释。

    4. 数据类型支持：
       - 连续数据：多通道共享时间基，适合同步采样
       - 间歇数据：各通道独立时间基，适合事件触发

    5. 线程安全：
       - 所有公共方法通过 RLock 同步
       - 支持多线程并发写入

子模块:
    mdf_config   - 配置模块，包含枚举和 MDFConfig/HeaderConfig 类
    mdf_writer   - 线程安全写入器 (MDFWriter, MDFAppendWriter)
    mdf_reader   - 线程安全读取器 (MDFReader)

使用示例:
    from mdf_asammdf import (
        MDFConfig, ChannelDef, HeaderConfig, OperationMode,
        MDFWriter, MDFReader,
    )

    # 写入
    config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
    with MDFWriter("output.mf4", config) as writer:
        writer.set_header(HeaderConfig(
            author="张三", department="测试部", project="车型A"
        ))
        writer.define_channels([ChannelDef("Speed", "km/h")])
        writer.append_continuous(
            {"Speed": [10.0, 20.0, 30.0]},
            [0.0, 0.1, 0.2]
        )

    # 读取
    with MDFReader("output.mf4") as reader:
        header = reader.get_header()
        print(f"作者: {header.author}")
        sig = reader.get_channel("Speed")
        print(f"样本: {sig.samples}")

版本: 4.0.0
"""

# ---------------------------------------------------------------------------
# 配置模块导出
# ---------------------------------------------------------------------------
from mdf_config import (
    # 配置类
    MDFConfig,
    ChannelDef,
    HeaderConfig,
    # 统计类
    WriterStats,
    ReaderStats,
    # 枚举类型
    OperationMode,
    DataContinuity,
    CompressionType,
)

# ---------------------------------------------------------------------------
# 写入器模块导出
# ---------------------------------------------------------------------------
from mdf_writer import (
    # 主写入器类
    MDFWriter,
    MDFAppendWriter,
    # 分片索引管理
    FragmentIndex,
    # 异常类
    MDFWriterError,
    MDFWriterStateError,
    MDFWriterValidationError,
    MDFWriterModeError,
    MDFWriterThreadError,
    MDFWriterHierarchyError,
)

# ---------------------------------------------------------------------------
# 读取器模块导出
# ---------------------------------------------------------------------------
from mdf_reader import (
    # 主读取器类
    MDFReader,
    # 异常类
    MDFReaderError,
    MDFReaderNotFoundError,
    MDFReaderStateError,
    MDFReaderFormatError,
)

# ---------------------------------------------------------------------------
# 包元信息
# ---------------------------------------------------------------------------
__version__ = "4.0.0"
__author__ = "ASAM MDF Multi-threaded R/W"
__all__ = [
    # === 配置 ===
    "MDFConfig",
    "ChannelDef",
    "HeaderConfig",
    "WriterStats",
    "ReaderStats",
    "OperationMode",
    "DataContinuity",
    "CompressionType",
    # === 写入器 ===
    "MDFWriter",
    "MDFAppendWriter",
    "FragmentIndex",
    # === 读取器 ===
    "MDFReader",
    # === 写入器异常 ===
    "MDFWriterError",
    "MDFWriterStateError",
    "MDFWriterValidationError",
    "MDFWriterModeError",
    "MDFWriterThreadError",
    "MDFWriterHierarchyError",
    # === 读取器异常 ===
    "MDFReaderError",
    "MDFReaderNotFoundError",
    "MDFReaderStateError",
    "MDFReaderFormatError",
    # === 元信息 ===
    "__version__",
]
