# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读取器模块 (基于 asammdf 库)

本模块实现了线程安全的 MDF 文件读取器，支持：
    1. 单文件读取（NORMAL / STREAMING 模式产生的文件）
    2. 多分片文件自动发现与合并读取（FRAGMENTED 模式）

分片读取架构：
    分片文件存储在独立子文件夹中（base_fragments/）：
        基础路径: /path/to/data.mf4
        分片文件夹: /path/to/data_fragments/
        索引文件:   /path/to/data_fragments/index.json

    分片发现策略（按优先级）：
        1. 优先使用子文件夹中的索引文件 (base_fragments/index.json)
        2. 回退到子文件夹中的文件名模式匹配 (base_fragments/base_*.mf4)
        3. 兼容旧版本：检查基础目录下的索引文件 (.index)
        4. 单文件模式：打开基础路径对应的 MDF 文件

    数据合并策略：
        - 跨分片数据按时间戳排序合并
        - 单文件内多数据组也合并
        - 合并后对外呈现统一的时间序列视图

    HD 块属性读取：
        通过 get_header() 方法读取 MDF 文件的 Header 块元数据，
        包括 author、department、project、subject、comment。

线程安全：
    所有公共方法均通过 threading.RLock 同步。
    内部缓存也在锁保护下操作。

版本: 4.0.0
日期: 2026-04-23
"""

# ---------------------------------------------------------------------------
# 标准库导入
# ---------------------------------------------------------------------------
from __future__ import annotations

import os
import re
import json
import time
import glob
import logging
import threading
from typing import Optional, Dict, List, Any, Iterator

# ---------------------------------------------------------------------------
# 第三方库导入
# ---------------------------------------------------------------------------
import numpy as np

try:
    from asammdf import MDF, Signal
except ImportError as e:
    raise ImportError(
        "asammdf 库未安装。请运行: pip install asammdf"
    ) from e

# ---------------------------------------------------------------------------
# 本地模块导入
# ---------------------------------------------------------------------------
from mdf_config import MDFConfig, ReaderStats, HeaderConfig

# ---------------------------------------------------------------------------
# 模块级日志记录器
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类定义
# =============================================================================

class MDFReaderError(Exception):
    """
    MDF 读取器基础异常类

    所有读取器相关的异常均继承自此类，便于调用者统一捕获。
    """
    pass


class MDFReaderNotFoundError(MDFReaderError):
    """
    通道未找到异常

    当请求的通道在 MDF 文件中不存在时抛出。
    """
    pass


class MDFReaderStateError(MDFReaderError):
    """
    状态错误异常

    当操作在不正确的状态下执行时抛出，例如：
        - 读取器已关闭后尝试读取
        - 文件未正确初始化
    """
    pass


class MDFReaderFormatError(MDFReaderError):
    """
    格式错误异常

    当 MDF 文件格式不正确或损坏时抛出。
    """
    pass


# =============================================================================
# 主读取器类
# =============================================================================

class MDFReader:
    """
    线程安全的 ASAM MDF 文件读取器

    核心功能：
        1. 支持单文件读取
        2. 支持多分片文件自动发现和数据合并
        3. 支持 HD 块属性读取（作者、部门、项目等）
        4. 通道数据缓存（避免重复读取）
        5. 迭代器支持（大数据量分批读取）

    分片文件发现策略（按优先级）：
        1. 子文件夹索引 (base_fragments/index.json)：最可靠
        2. 子文件夹模式 (base_fragments/*.mf4)：自动发现
        3. 旧版本兼容 (base.index / base_*.mf4)：向后兼容
        4. 单文件 (base.mf4)：无分片时直接打开

    HD 块属性读取：
        通过 get_header() 方法读取 MDF 文件的 Header 块元数据。
        分片模式下返回第一个分片的 HD 属性。

    使用示例:
        # 读取分片文件（自动发现所有分片）
        reader = MDFReader("data.mf4")
        # 获取 HD 块属性
        header = reader.get_header()
        print(f"作者: {header.author}, 项目: {header.project}")
        # 读取通道数据
        sig = reader.get_channel("Speed")
        print(f"跨分片总样本数: {len(sig.samples)}")
        reader.close()
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 读取器

        步骤：
            1. 保存配置和路径
            2. 创建 RLock
            3. 初始化分片管理和缓存
            4. 调用 _initialize() 打开文件/分片
            5. 标记为打开状态

        参数:
            filepath: 基础文件路径（如 "data.mf4"）
                      分片模式下作为分片发现基础
            config:   MDFConfig 配置对象（可选）
        """
        # 保存配置（使用默认配置如果未提供）
        self.config: MDFConfig = config or MDFConfig()
        # 保存文件路径
        self.filepath: str = filepath
        # 创建可重入锁
        self._lock: threading.RLock = threading.RLock()
        # 打开状态标志
        self._is_open: bool = False
        # 读取器统计
        self.stats: ReaderStats = ReaderStats()
        # 初始化开始时间
        self._start_time: float = time.time()

        # ===================================================================
        # 分片管理
        # ===================================================================
        # 分片文件路径列表
        self._fragment_paths: List[str] = []
        # 打开的分片 MDF 对象列表
        self._mdfs: List[MDF] = []

        # ===================================================================
        # 单文件模式
        # ===================================================================
        # 单文件 MDF 对象
        self._single_mdf: Optional[MDF] = None

        # ===================================================================
        # 缓存
        # ===================================================================
        # 通道数据缓存（避免重复读取）
        self._cache: Dict[str, Signal] = {}
        # 缓存最大条目数
        self._cache_max_size: int = 20

        # ===================================================================
        # 执行初始化
        # ===================================================================
        self._initialize()
        # 标记为打开状态
        self._is_open = True
        logger.info(f"MDFReader 初始化完成: {filepath}")

    @property
    def is_open(self) -> bool:
        """
        读取器是否处于打开状态（只读属性）

        返回:
            True 如果读取器处于打开状态
        """
        return self._is_open

    # ======================================================================
    # 初始化方法
    # ======================================================================

    def _initialize(self) -> None:
        """
        初始化读取器

        按以下优先级确定读取模式：
            1. 检查子文件夹中的索引文件 (base_fragments/index.json)
            2. 检查子文件夹中的分片文件 (base_fragments/*.mf4)
            3. 兼容旧版本：检查基础目录下的索引 (base.index)
            4. 兼容旧版本：检查基础目录下的分片 (base_*.mf4)
            5. 单文件模式：打开基础路径对应的 MDF 文件

        异常:
            FileNotFoundError: 文件不存在
        """
        # 计算分片文件夹路径
        fragment_folder = self._get_fragment_folder()

        # 1. 检查子文件夹中的索引文件
        index_path = os.path.join(fragment_folder, "index.json")
        if os.path.exists(index_path):
            self._load_from_index(index_path)
            return

        # 2. 检查子文件夹中的分片文件
        if os.path.isdir(fragment_folder):
            folder_pattern = os.path.join(fragment_folder, "*.mf4")
            fragments = sorted(glob.glob(folder_pattern))
            if fragments:
                self._fragment_paths = fragments
                self._open_fragments()
                return

        # 3. 兼容旧版本：检查基础目录下的索引文件
        old_index_path = self._get_old_index_path()
        if os.path.exists(old_index_path):
            self._load_from_index(old_index_path)
            return

        # 4. 兼容旧版本：检查基础目录下的分片文件
        old_fragment_pattern = self._get_old_fragment_pattern()
        old_fragments = sorted(glob.glob(old_fragment_pattern))
        if old_fragments:
            self._fragment_paths = old_fragments
            self._open_fragments()
            return

        # 5. 单文件模式
        if os.path.exists(self.filepath) and os.path.getsize(self.filepath) >= 64:
            # 文件存在且有效（至少包含 MDF ID 块头）
            self._single_mdf = MDF(self.filepath)
        else:
            raise FileNotFoundError(
                f"MDF 文件不存在或无效: {self.filepath}"
            )

    def _get_fragment_folder(self) -> str:
        """
        获取分片文件夹路径

        规则：将扩展名替换为 _fragments
            data.mf4 -> data_fragments

        返回:
            分片文件夹路径
        """
        base, _ = os.path.splitext(self.filepath)
        return f"{base}{self.config.fragment_folder_suffix}"

    def _get_old_index_path(self) -> str:
        """
        获取旧版本索引文件路径（兼容 v3.x）

        规则：将扩展名替换为 .index
            data.mf4 -> data.index

        返回:
            旧版本索引文件路径
        """
        base, _ = os.path.splitext(self.filepath)
        return base + ".index"

    def _get_old_fragment_pattern(self) -> str:
        """
        获取旧版本分片文件匹配模式（兼容 v3.x）

        返回:
            glob 匹配模式字符串
        """
        base, ext = os.path.splitext(self.filepath)
        return f"{base}_*[0-9]{ext}"

    def _load_from_index(self, index_path: str) -> None:
        """
        从索引文件加载分片列表

        步骤：
            1. 读取并解析 JSON 索引文件
            2. 提取分片路径列表
            3. 打开所有分片文件

        参数:
            index_path: 索引文件路径
        """
        try:
            # 读取索引文件
            with open(index_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # 提取分片路径
            self._fragment_paths = [
                f["path"] for f in data.get("fragments", [])
                if os.path.exists(f["path"])
            ]
            # 打开所有分片
            self._open_fragments()
            logger.info(f"从索引加载了 {len(self._fragment_paths)} 个分片")
        except (json.JSONDecodeError, IOError) as e:
            # 索引文件加载失败时记录警告
            logger.warning(f"索引文件加载失败: {e}")
            # 回退到单文件模式
            if os.path.exists(self.filepath):
                self._single_mdf = MDF(self.filepath)

    def _open_fragments(self) -> None:
        """
        打开所有分片文件

        遍历分片路径列表，逐个打开有效的 MDF 文件。
        跳过不存在或损坏的文件。
        """
        for path in self._fragment_paths:
            if os.path.exists(path):
                try:
                    # 打开分片文件
                    mdf = MDF(path)
                    self._mdfs.append(mdf)
                except Exception as e:
                    # 打开失败时记录警告，跳过该分片
                    logger.warning(f"打开分片失败 {path}: {e}")
            else:
                logger.warning(f"分片文件不存在: {path}")

        # 更新统计
        self.stats.fragments_read = len(self._mdfs)
        logger.info(f"已打开 {len(self._mdfs)} 个分片")

    # ======================================================================
    # HD 块属性读取
    # ======================================================================

    def get_header(self) -> HeaderConfig:
        """
        获取 MDF HD（Header）块属性

        读取 MDF 文件的元数据信息，包括作者、部门、项目、主题和注释。

        分片模式下返回第一个分片的 HD 属性（所有分片的 HD 属性一致）。

        返回:
            HeaderConfig 对象，包含所有 HD 块属性

        异常:
            MDFReaderStateError: 读取器已关闭
        """
        with self._lock:
            # 状态检查
            if not self._is_open:
                raise MDFReaderStateError("读取器已关闭")

            # 获取 MDF 对象
            mdf = None
            if self._single_mdf:
                mdf = self._single_mdf
            elif self._mdfs:
                mdf = self._mdfs[0]

            if mdf is None:
                return HeaderConfig()

            try:
                return HeaderConfig(
                    author=getattr(mdf.header, 'author', '') or '',
                    department=getattr(mdf.header, 'department', '') or '',
                    project=getattr(mdf.header, 'project', '') or '',
                    subject=getattr(mdf.header, 'subject', '') or '',
                    comment=getattr(mdf.header, 'comment', '') or '',
                )
            except Exception as e:
                logger.warning(f"读取 HD 块属性失败: {e}")
                return HeaderConfig()

    # ======================================================================
    # 通道查询
    # ======================================================================

    def get_channel_names(self) -> List[str]:
        """
        获取所有通道名称列表

        单文件模式下直接从 channels_db 获取。
        分片模式下合并所有分片的通道名（去重）。

        返回:
            通道名称列表（按字母排序）
        """
        with self._lock:
            self.stats.total_reads += 1
            if self._single_mdf:
                # 单文件：从 channels_db 获取，排除 'time' 键
                return [
                    k for k in self._single_mdf.channels_db.keys()
                    if k != 'time'
                ]
            elif self._mdfs:
                # 分片模式：合并所有分片的通道名
                names = set()
                for mdf in self._mdfs:
                    names.update(
                        k for k in mdf.channels_db.keys() if k != 'time'
                    )
                return sorted(names)
            return []

    def has_channel(self, name: str) -> bool:
        """
        检查通道是否存在

        参数:
            name: 通道名称

        返回:
            True 如果通道存在
        """
        with self._lock:
            return name in self.get_channel_names()

    # ======================================================================
    # 数据读取（核心：多组合并）
    # ======================================================================

    def get_channel(self, name: str, raw: bool = False) -> Signal:
        """
        读取指定通道的完整数据（跨所有分片合并）

        这是读取器的核心方法。它会：
            1. 检查缓存（避免重复读取）
            2. 从单文件或所有分片读取数据
            3. 合并并按时间戳排序
            4. 更新缓存

        参数:
            name: 通道名称
            raw:  是否返回原始值（不应用转换）

        返回:
            Signal 对象，samples 和 timestamps 已跨分片合并排序

        异常:
            MDFReaderStateError:     读取器已关闭
            MDFReaderNotFoundError:  通道不存在或无数据
        """
        with self._lock:
            # 状态检查
            if not self._is_open:
                raise MDFReaderStateError("读取器已关闭")

            # 缓存检查
            cache_key = f"{name}:raw={raw}"
            if cache_key in self._cache:
                self.stats.cache_hit_count += 1
                return self._cache[cache_key]
            self.stats.cache_miss_count += 1

            # 根据模式读取数据
            if self._single_mdf:
                sig = self._get_from_single(name, raw)
            elif self._mdfs:
                sig = self._get_from_fragments(name, raw)
            else:
                raise MDFReaderNotFoundError("无可用数据源")

            # 更新统计
            self.stats.total_records_read += len(sig.samples)
            # 添加到缓存
            self._add_to_cache(cache_key, sig)
            return sig

    def _get_from_single(self, name: str, raw: bool) -> Signal:
        """
        从单文件读取通道数据

        处理单文件内可能存在多个数据组的情况（如追加写入）。

        参数:
            name: 通道名称
            raw:  是否返回原始值

        返回:
            Signal 对象

        异常:
            MDFReaderNotFoundError: 通道不存在
        """
        # 检查通道是否存在
        if name not in self._single_mdf.channels_db:
            raise MDFReaderNotFoundError(f"通道不存在: {name}")

        # 获取通道在所有数据组中的条目
        entries = self._single_mdf.channels_db[name]
        if len(entries) == 1:
            # 只有一个数据组，直接读取
            return self._single_mdf.get(name, group=entries[0][0], raw=raw)
        else:
            # 多个数据组，需要合并
            return self._merge_groups(self._single_mdf, name, entries, raw)

    def _get_from_fragments(self, name: str, raw: bool) -> Signal:
        """
        从多个分片读取并合并通道数据

        核心合并逻辑：
            1. 遍历每个分片
            2. 如果分片包含目标通道，读取数据
            3. 收集所有样本和时间戳
            4. 按时间戳排序合并

        参数:
            name: 通道名称
            raw:  是否返回原始值

        返回:
            合并后的 Signal 对象

        异常:
            MDFReaderNotFoundError: 通道在所有分片中无数据
        """
        # 收集所有分片的样本和时间戳
        all_samples = []
        all_timestamps = []
        unit = ""
        comment = ""

        for mdf in self._mdfs:
            # 检查当前分片是否包含目标通道
            if name not in mdf.channels_db:
                continue
            try:
                # 获取通道在所有数据组中的条目
                entries = mdf.channels_db[name]
                for group_idx, _ in entries:
                    # 读取该数据组的通道数据
                    sig = mdf.get(name, group=group_idx, raw=raw)
                    if sig.samples is not None and len(sig.samples) > 0:
                        all_samples.append(sig.samples)
                        all_timestamps.append(sig.timestamps)
                        # 保存单位和注释（从第一个有效分片获取）
                        if not unit and sig.unit:
                            unit = str(sig.unit)
                        if not comment and sig.comment:
                            comment = str(sig.comment)
            except Exception as e:
                # 单个分片读取失败时记录警告，继续处理其他分片
                logger.warning(f"分片读取通道 '{name}' 失败: {e}")

        # 检查是否有有效数据
        if not all_samples:
            raise MDFReaderNotFoundError(
                f"通道 '{name}' 在所有分片中无有效数据"
            )

        # 合并所有分片的样本和时间戳
        merged_samples = np.concatenate(all_samples)
        merged_timestamps = np.concatenate(all_timestamps)

        # 按时间戳排序（确保时序正确）
        sort_idx = np.argsort(merged_timestamps)
        merged_samples = merged_samples[sort_idx]
        merged_timestamps = merged_timestamps[sort_idx]

        return Signal(
            samples=merged_samples,
            timestamps=merged_timestamps,
            name=name,
            unit=unit,
            comment=comment,
        )

    def _merge_groups(self, mdf: MDF, name: str,
                       entries: List, raw: bool) -> Signal:
        """
        合并单文件内多数据组的通道数据

        当同一个通道存在于多个数据组中时（如追加写入），
        需要合并所有数据组的数据。

        参数:
            mdf:     MDF 对象
            name:    通道名称
            entries: 通道在数据组中的条目列表
            raw:     是否返回原始值

        返回:
            合并后的 Signal 对象
        """
        all_samples = []
        all_timestamps = []
        unit = ""

        for group_idx, _ in entries:
            # 读取该数据组的通道数据
            sig = mdf.get(name, group=group_idx, raw=raw)
            if sig.samples is not None and len(sig.samples) > 0:
                all_samples.append(sig.samples)
                all_timestamps.append(sig.timestamps)
                if not unit and sig.unit:
                    unit = str(sig.unit)

        # 合并并按时间戳排序
        merged_samples = np.concatenate(all_samples)
        merged_timestamps = np.concatenate(all_timestamps)
        sort_idx = np.argsort(merged_timestamps)

        return Signal(
            samples=merged_samples[sort_idx],
            timestamps=merged_timestamps[sort_idx],
            name=name,
            unit=unit,
        )

    # ======================================================================
    # 批量读取
    # ======================================================================

    def get_channels(self, names: List[str], raw: bool = False) -> Dict[str, Signal]:
        """
        批量读取多个通道

        参数:
            names: 通道名称列表
            raw:   是否返回原始值

        返回:
            通道名 -> Signal 的字典
        """
        with self._lock:
            return {
                name: self.get_channel(name, raw=raw)
                for name in names
            }

    def get_records_slice(self, name: str, start: int = 0,
                           count: Optional[int] = None, raw: bool = False) -> Signal:
        """
        读取通道指定范围的记录

        参数:
            name:  通道名称
            start: 起始索引
            count: 读取数量（None 表示到末尾）
            raw:   是否返回原始值

        返回:
            指定范围的 Signal 对象
        """
        with self._lock:
            # 获取完整通道数据
            sig = self.get_channel(name, raw=raw)
            total = len(sig.samples)
            # 计算结束位置
            if count is None:
                count = total - start
            end = min(start + count, total)
            return Signal(
                samples=sig.samples[start:end],
                timestamps=sig.timestamps[start:end],
                name=sig.name,
                unit=sig.unit,
                comment=sig.comment,
            )

    # ======================================================================
    # 迭代器
    # ======================================================================

    def iter_channel(self, name: str, batch_size: int = 1000,
                      raw: bool = False) -> Iterator[Signal]:
        """
        迭代读取通道数据

        适用于大数据量场景，避免一次性加载全部数据到内存。

        参数:
            name:       通道名称
            batch_size: 每批返回的记录数
            raw:        是否返回原始值

        返回:
            Signal 对象的迭代器
        """
        with self._lock:
            sig = self.get_channel(name, raw=raw)
            total = len(sig.samples)
            pos = 0
            while pos < total:
                # 计算当前批次结束位置
                end = min(pos + batch_size, total)
                # 生成当前批次的 Signal
                yield Signal(
                    samples=sig.samples[pos:end],
                    timestamps=sig.timestamps[pos:end],
                    name=sig.name,
                    unit=sig.unit,
                )
                # 更新统计
                self.stats.total_records_read += (end - pos)
                pos = end

    # ======================================================================
    # 缓存管理
    # ======================================================================

    def _add_to_cache(self, key: str, sig: Signal) -> None:
        """
        将 Signal 添加到缓存

        如果缓存已满，清空后重新添加。
        简单策略：缓存满时全部清空（而非 LRU）。

        参数:
            key: 缓存键
            sig: Signal 对象
        """
        if len(self._cache) >= self._cache_max_size:
            self._cache.clear()
        self._cache[key] = sig

    def clear_cache(self) -> None:
        """
        清空通道数据缓存

        在内存紧张或数据可能变化时调用。
        """
        with self._lock:
            self._cache.clear()

    # ======================================================================
    # 文件信息
    # ======================================================================

    def get_file_info(self) -> Dict[str, Any]:
        """
        获取文件信息

        返回包含文件元数据的字典，用于监控和调试。

        返回:
            包含 filepath, mode, version, channels 等信息的字典
        """
        with self._lock:
            info = {
                "filepath": self.filepath,
                "is_open": self._is_open,
                "stats": self.stats.to_dict(),
            }
            if self._single_mdf:
                # 单文件模式信息
                info["mode"] = "single"
                info["version"] = self._single_mdf.version
                info["channels"] = len([
                    k for k in self._single_mdf.channels_db if k != 'time'
                ])
            elif self._mdfs:
                # 分片模式信息
                info["mode"] = "fragmented"
                info["fragment_count"] = len(self._mdfs)
                info["fragment_paths"] = self._fragment_paths
                # 合并所有分片的通道名
                all_channels = set()
                for mdf in self._mdfs:
                    all_channels.update(
                        k for k in mdf.channels_db if k != 'time'
                    )
                info["channels"] = len(all_channels)
                info["channel_names"] = sorted(all_channels)[:50]
            return info

    def get_fragment_paths(self) -> List[str]:
        """
        获取分片文件路径列表

        返回:
            分片路径列表（按索引顺序）
        """
        with self._lock:
            return list(self._fragment_paths)

    # ======================================================================
    # 关闭和资源释放
    # ======================================================================

    def close(self) -> None:
        """
        关闭读取器并释放所有资源

        步骤：
            1. 清空缓存
            2. 关闭单文件 MDF 对象
            3. 关闭所有分片 MDF 对象
            4. 更新统计信息

        注意：此方法可安全多次调用（幂等）。
              所有异常被捕获并忽略，确保资源释放。
        """
        with self._lock:
            # 幂等性检查
            if not self._is_open:
                return

            # 清空缓存
            self._cache.clear()

            # 关闭单文件 MDF
            if self._single_mdf:
                try:
                    self._single_mdf.close()
                except Exception:
                    pass

            # 关闭所有分片 MDF
            for mdf in self._mdfs:
                try:
                    mdf.close()
                except Exception:
                    pass

            # 标记为关闭状态
            self._is_open = False
            # 计算运行时间
            self.stats.uptime_seconds = time.time() - self._start_time
            logger.info("MDFReader 已关闭")

    def __enter__(self):
        """
        上下文管理器入口

        支持 with 语句使用。
        """
        return self

    def __exit__(self, *args):
        """
        上下文管理器出口

        确保退出 with 块时自动关闭读取器。
        """
        self.close()
        return False


# =============================================================================
# 模块导出
# =============================================================================

__all__ = [
    "MDFReader",
    "MDFReaderError",
    "MDFReaderNotFoundError",
    "MDFReaderStateError",
    "MDFReaderFormatError",
]
