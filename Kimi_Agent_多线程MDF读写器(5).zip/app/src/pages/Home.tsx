import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { CheckCircle2, Layers, Zap, Shield, Database, FolderTree, Activity, Code2, FileJson, TestTube2, GitBranch } from 'lucide-react'
import '../App.css'

const features = [
  {
    icon: <Layers className="h-8 w-8 text-emerald-400" />,
    title: '三种操作模式',
    description: 'NORMAL 单文件高效写入、FRAGMENTED 体积阈值自动分片、STREAMING 带后台刷盘线程的实时采集模式，覆盖全场景需求。'
  },
  {
    icon: <FolderTree className="h-8 w-8 text-blue-400" />,
    title: '子文件夹分片存储',
    description: '分片文件集中存储在 base_fragments/ 子文件夹中，搭配 JSON 索引文件，便于查看、管理和归档。'
  },
  {
    icon: <Database className="h-8 w-8 text-violet-400" />,
    title: 'HD 块属性读写',
    description: '支持修改 MDF Header (HD) 块的元数据，包括作者、部门、项目、主题和注释，每个分片保持一致的 HD 属性。'
  },
  {
    icon: <GitBranch className="h-8 w-8 text-amber-400" />,
    title: 'DG/CG/CN 层级管理',
    description: '提供 create_data_group()、create_channel_group()、create_channel() 方法，返回各层级索引，实现精细化的通道层级结构。'
  },
  {
    icon: <Shield className="h-8 w-8 text-rose-400" />,
    title: '线程安全 (RLock)',
    description: '所有公共方法通过 threading.RLock 同步，支持多线程并发写入，内置完善的异常层次结构。'
  },
  {
    icon: <Zap className="h-8 w-8 text-cyan-400" />,
    title: '持久化追加',
    description: '关闭后再次打开可继续追加数据，分片模式下自动加载最新分片并重建层级状态，数据不丢失。'
  }
]

const writerAPI = [
  { method: 'MDFWriter(path, config)', desc: '创建写入器实例，支持上下文管理器' },
  { method: 'define_channels(channels)', desc: '定义通道列表（名称、单位、数据类型）' },
  { method: 'create_data_group(name, comment)', desc: '创建 Data Group，返回 dg_index' },
  { method: 'create_channel_group(dg, name, comment)', desc: '在 DG 下创建 Channel Group，返回 cg_index（固定为 0）' },
  { method: 'create_channel(dg, cg, ch_def)', desc: '在 CG 下创建 Channel，返回 cn_index（dummy channel 替换策略）' },
  { method: 'append_continuous(values, ts)', desc: '追加连续数据（多通道共享时间基）' },
  { method: 'append_intermittent(ch, ts, val)', desc: '追加单条间歇数据（各通道独立时间基）' },
  { method: 'append_to_data_group(dg, values, ts)', desc: '向指定 Data Group 追加数据' },
  { method: 'set_header(HeaderConfig)', desc: '设置 HD 块属性（作者/部门/项目/主题/注释）' },
  { method: 'get_hierarchy_info()', desc: '获取当前 DG/CG/CN 层级结构信息' },
  { method: 'get_fragment_paths()', desc: '获取所有分片文件路径列表' },
  { method: 'get_file_info()', desc: '获取当前文件元信息（模式、通道数、记录数等）' }
]

const readerAPI = [
  { method: 'MDFReader(path)', desc: '创建读取器实例，支持上下文管理器' },
  { method: 'get_channel(name)', desc: '按名称获取单个通道数据（Signal 对象）' },
  { method: 'get_channels(names)', desc: '批量获取多个通道数据' },
  { method: 'has_channel(name)', desc: '检查通道是否存在' },
  { method: 'get_header()', desc: '读取 HD 块属性（HeaderConfig）' },
  { method: 'get_file_info()', desc: '获取文件元信息' },
  { method: 'iter_channel(name, batch)', desc: '创建通道迭代器，支持分批读取' },
  { method: 'iter_fragmented(name, batch)', desc: '跨分片通道迭代器，自动合并数据' }
]

const configAPI = [
  { method: 'MDFConfig', desc: '配置类：operation_mode, fragment_size, compression, fragment_folder_suffix 等' },
  { method: 'ChannelDef', desc: '通道定义：name, unit, data_type, comment, display_name' },
  { method: 'HeaderConfig', desc: 'HD 属性：author, department, project, subject, comment' },
  { method: 'OperationMode', desc: '枚举：NORMAL / FRAGMENTED / STREAMING' },
  { method: 'DataContinuity', desc: '枚举：CONTINUOUS / INTERMITTENT / MIXED' },
  { method: 'CompressionType', desc: '枚举：NONE / ZIP / TRANSPOSITION' }
]

const codeExamples = [
  {
    title: '一般模式写入与读取',
    lang: 'python',
    code: `from mdf_asammdf import MDFConfig, ChannelDef, MDFWriter, MDFReader

config = MDFConfig(operation_mode='NORMAL')
with MDFWriter('output.mf4', config) as w:
    w.define_channels([ChannelDef('Speed', 'km/h', '<f4')])
    w.append_continuous(
        {'Speed': [10.0, 20.0, 30.0]},
        [0.0, 0.1, 0.2]
    )

with MDFReader('output.mf4') as r:
    sig = r.get_channel('Speed')
    print(sig.samples)   # [10.0, 20.0, 30.0]
    print(sig.timestamps)  # [0.0, 0.1, 0.2]`
  },
  {
    title: '分片模式 + HD 属性',
    lang: 'python',
    code: `from mdf_asammdf import (
    MDFConfig, ChannelDef, HeaderConfig,
    OperationMode, MDFWriter, MDFReader
)

config = MDFConfig(
    operation_mode=OperationMode.FRAGMENTED,
    fragment_size=1024 * 1024,  # 1MB
)
with MDFWriter('data.mf4', config) as w:
    w.set_header(HeaderConfig(
        author='张三',
        department='测试部',
        project='车型A',
    ))
    w.define_channels([ChannelDef('Temp', 'C', '<f4')])
    for i in range(100):
        w.append_continuous(
            {'Temp': [float(i)]},
            [i * 0.01]
        )

# 分片存储在 data_fragments/ 目录下
with MDFReader('data.mf4') as r:
    print(r.get_header().author)  # '张三'
    sig = r.get_channel('Temp')
    print(len(sig.samples))  # 100`
  },
  {
    title: '层级管理（DG/CG/CN）',
    lang: 'python',
    code: `from mdf_asammdf import MDFWriter, ChannelDef

with MDFWriter('hierarchy.mf4') as w:
    dg1 = w.create_data_group('制动测试')
    cg1 = w.create_channel_group(dg1, '前轮')
    cn1 = w.create_channel(dg1, cg1, ChannelDef('Pressure', 'bar', '<f4'))
    cn2 = w.create_channel(dg1, cg1, ChannelDef('Temp', 'C', '<f4'))

    w.append_to_data_group(dg1, {
        'Pressure': [1.0, 2.0, 3.0],
        'Temp': [25.0, 30.0, 35.0]
    }, [0.0, 0.1, 0.2])

    info = w.get_hierarchy_info()
    print(info['data_groups'][0]['name'])  # '制动测试'`
  },
  {
    title: '多线程并发写入',
    lang: 'python',
    code: `import threading
from mdf_asammdf import MDFConfig, ChannelDef, MDFWriter, OperationMode

config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
writer = MDFWriter('multi.mf4', config)
writer.define_channels([ChannelDef('ThreadData', '<f4')])

def worker(tid, count):
    for i in range(count):
        writer.append_continuous(
            {'ThreadData': [float(tid * 100 + i)]},
            [i * 0.001]
        )

threads = [
    threading.Thread(target=worker, args=(t, 50))
    for t in range(4)
]
for t in threads:
    t.start()
for t in threads:
    t.join()

writer.close()`
  }
]

const testResults = [
  { category: '配置验证', count: 11, tests: 'test_default, test_serialization, test_header_config...' },
  { category: '一般模式', count: 5, tests: 'test_basic_write_read, test_multiple_channels...' },
  { category: '分片模式', count: 6, tests: 'test_fragment_auto_split, test_persistence_append...' },
  { category: '流式模式', count: 3, tests: 'test_basic, test_continuous_append, test_flush_before_close' },
  { category: '间歇数据', count: 4, tests: 'test_normal_intermittent, test_fragmented_intermittent...' },
  { category: '多线程', count: 2, tests: 'test_concurrent_write_fragmented, test_concurrent_write_streaming' },
  { category: '数据完整性', count: 4, tests: 'test_exact_values_normal, test_exact_values_fragmented...' },
  { category: '层级管理', count: 10, tests: 'test_create_data_group, test_create_channel, test_multiple_data_groups...' },
  { category: 'HD 块', count: 6, tests: 'test_header_set_and_get_normal, test_header_each_fragment_has_same_hd...' },
  { category: '边界与异常', count: 9, tests: 'test_large_data, test_write_after_close, test_duplicate_channel_names...' },
  { category: '读取器', count: 6, tests: 'test_get_channel, test_iter_fragmented, test_records_slice...' },
  { category: '追加与压缩', count: 4, tests: 'test_append_writer_basic, test_zip_compression...' }
]

export default function Home() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-slate-950/90 backdrop-blur-md border-b border-slate-800' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-6 w-6 text-emerald-400" />
            <span className="font-bold text-lg tracking-tight">MDF-RW</span>
            <Badge variant="outline" className="text-emerald-400 border-emerald-400/30 text-xs">v4.0.0</Badge>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm text-slate-400">
            <a href="#features" className="hover:text-slate-100 transition-colors">特性</a>
            <a href="#architecture" className="hover:text-slate-100 transition-colors">架构</a>
            <a href="#api" className="hover:text-slate-100 transition-colors">API</a>
            <a href="#examples" className="hover:text-slate-100 transition-colors">示例</a>
            <a href="#tests" className="hover:text-slate-100 transition-colors">测试</a>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-900/20 via-slate-950 to-slate-950" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-emerald-500/10 blur-[120px] rounded-full" />
        <div className="relative max-w-5xl mx-auto text-center">
          <Badge className="mb-6 bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20">
            <Activity className="h-3 w-3 mr-1" />
            生产级 · 多线程安全 · 基于 asammdf
          </Badge>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 bg-gradient-to-b from-white to-slate-400 bg-clip-text text-transparent">
            ASAM MDF 多线程读写器
          </h1>
          <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto mb-10 leading-relaxed">
            基于 asammdf 库构建的高性能 MDF 4.x 文件读写器。支持三种操作模式、分片子文件夹存储、
            HD 块属性读写、DG/CG/CN 三级层级管理，以及多线程并发写入。
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold px-8" asChild>
              <a href="#examples">查看示例</a>
            </Button>
            <Button size="lg" variant="outline" className="border-slate-700 hover:bg-slate-800 px-8" asChild>
              <a href="#api">API 文档</a>
            </Button>
          </div>
          <div className="mt-12 flex flex-wrap justify-center gap-8 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>75 个测试全部通过</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>注释比例 ≥ 1:1</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>RLock 线程安全</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>Schema 模式分片</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">核心特性</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">覆盖从简单记录到大规模实时采集的全场景 MDF 文件处理需求</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <Card key={i} className="bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-colors group">
                <CardHeader>
                  <div className="mb-4 p-3 bg-slate-800/50 rounded-lg w-fit group-hover:bg-slate-800 transition-colors">
                    {f.icon}
                  </div>
                  <CardTitle className="text-lg">{f.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-400 leading-relaxed">
                    {f.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Separator className="bg-slate-800 max-w-7xl mx-auto" />

      {/* Architecture */}
      <section id="architecture" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">MDF 层级架构</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">支持完整的 DG → CG → CN 三级层级结构，每个层级可独立创建和管理</p>
          </div>

          <div className="relative bg-slate-900/50 border border-slate-800 rounded-xl p-8 md:p-12">
            {/* Tree visualization */}
            <div className="flex flex-col items-center gap-6">
              {/* Root */}
              <div className="w-48 h-14 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 flex items-center justify-center text-sm font-bold shadow-lg shadow-emerald-900/20">
                MDF 文件 (ID / HD)
              </div>
              <div className="w-px h-6 bg-slate-600" />

              {/* Data Group level */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                {[
                  { name: 'DG #0: 制动测试', channels: ['Pressure', 'Temp'] },
                  { name: 'DG #1: 动力系统', channels: ['RPM', 'Torque', 'Power'] },
                  { name: 'DG #2: 环境温度', channels: ['AmbientT', 'Humidity'] }
                ].map((dg, i) => (
                  <div key={i} className="flex flex-col items-center gap-3">
                    <div className="w-full h-12 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center justify-center text-xs font-bold shadow-lg shadow-blue-900/20">
                      {dg.name}
                    </div>
                    <div className="w-px h-4 bg-slate-600" />
                    <div className="w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50">
                      <div className="text-[10px] text-slate-500 mb-2 text-center uppercase tracking-wider">CG #0</div>
                      <div className="flex flex-wrap gap-2 justify-center">
                        {dg.channels.map((cn, j) => (
                          <Badge key={j} variant="secondary" className="bg-slate-700 text-slate-300 text-xs">
                            {cn}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-10 text-center text-sm text-slate-500">
              每个 DG 包含一个 CG，每个 CG 包含多个 CN（Channel）。通过层级方法可以按需创建和管理。
            </div>
          </div>

          <div className="mt-10 grid md:grid-cols-2 gap-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FolderTree className="h-4 w-4 text-blue-400" />
                  分片存储结构
                </CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-xs text-slate-400 bg-slate-950 rounded-lg p-4 overflow-x-auto leading-relaxed">
{`data.mf4                    # 基础文件（索引入口）
data_fragments/             # 子文件夹
  ├── index.json            # JSON 索引：分片列表、大小、记录数
  ├── data_001.mf4          # 分片 1（完整 Schema）
  ├── data_002.mf4          # 分片 2（完整 Schema）
  └── data_003.mf4          # 分片 3（完整 Schema）`}
                </pre>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FileJson className="h-4 w-4 text-amber-400" />
                  索引文件格式
                </CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-xs text-slate-400 bg-slate-950 rounded-lg p-4 overflow-x-auto leading-relaxed">
{`{
  "base_path": "data.mf4",
  "created_at": "2024-01-15T10:30:00",
  "fragments": [
    {"index": 1, "path": "data_001.mf4",
     "size": 1048576, "records": 10000},
    {"index": 2, "path": "data_002.mf4",
     "size": 1048576, "records": 10000}
  ]
}`}
                </pre>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Separator className="bg-slate-800 max-w-7xl mx-auto" />

      {/* API Docs */}
      <section id="api" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">API 文档</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">完整的公共 API 参考，涵盖写入器、读取器和配置模块</p>
          </div>

          <Tabs defaultValue="writer" className="w-full">
            <TabsList className="bg-slate-900 border border-slate-800 mb-8 mx-auto flex w-fit">
              <TabsTrigger value="writer" className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-100">写入器 (MDFWriter)</TabsTrigger>
              <TabsTrigger value="reader" className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-100">读取器 (MDFReader)</TabsTrigger>
              <TabsTrigger value="config" className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-100">配置 (Config)</TabsTrigger>
            </TabsList>

            <TabsContent value="writer">
              <div className="grid gap-3">
                {writerAPI.map((api, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors">
                    <Code2 className="h-5 w-5 text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <code className="text-sm font-mono text-emerald-300">{api.method}</code>
                      <p className="text-sm text-slate-400 mt-1">{api.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="reader">
              <div className="grid gap-3">
                {readerAPI.map((api, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors">
                    <Code2 className="h-5 w-5 text-blue-400 mt-0.5 shrink-0" />
                    <div>
                      <code className="text-sm font-mono text-blue-300">{api.method}</code>
                      <p className="text-sm text-slate-400 mt-1">{api.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="config">
              <div className="grid gap-3">
                {configAPI.map((api, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors">
                    <Code2 className="h-5 w-5 text-violet-400 mt-0.5 shrink-0" />
                    <div>
                      <code className="text-sm font-mono text-violet-300">{api.method}</code>
                      <p className="text-sm text-slate-400 mt-1">{api.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Separator className="bg-slate-800 max-w-7xl mx-auto" />

      {/* Examples */}
      <section id="examples" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">代码示例</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">从简单写入到复杂层级管理和多线程并发，覆盖典型使用场景</p>
          </div>

          <Tabs defaultValue="0" className="w-full">
            <TabsList className="bg-slate-900 border border-slate-800 mb-6 flex flex-wrap h-auto gap-2 p-2 w-fit mx-auto">
              {codeExamples.map((ex, i) => (
                <TabsTrigger key={i} value={String(i)} className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-100 text-xs px-3 py-1.5">
                  {ex.title}
                </TabsTrigger>
              ))}
            </TabsList>
            {codeExamples.map((ex, i) => (
              <TabsContent key={i} value={String(i)}>
                <Card className="bg-slate-950 border-slate-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-300">{ex.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[420px] w-full rounded-md">
                      <pre className="text-xs md:text-sm font-mono text-slate-300 leading-relaxed p-4">
                        <code>{ex.code}</code>
                      </pre>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      <Separator className="bg-slate-800 max-w-7xl mx-auto" />

      {/* Test Results */}
      <section id="tests" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">测试报告</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">经过多轮迭代优化，75 个测试用例全部通过，覆盖功能、性能、边界和异常场景</p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {testResults.map((tr, i) => (
              <Card key={i} className="bg-slate-900/50 border-slate-800 hover:border-emerald-500/30 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium">{tr.category}</CardTitle>
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">{tr.count} 个</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-500">{tr.tests}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 p-6 rounded-xl bg-gradient-to-r from-emerald-900/20 to-slate-900 border border-emerald-500/20 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <TestTube2 className="h-6 w-6 text-emerald-400" />
              <span className="text-2xl font-bold text-emerald-400">75 / 75</span>
            </div>
            <p className="text-sm text-slate-400">全部测试通过 · 0 失败 · 0 错误 · 执行时间 &lt; 2 秒</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5 text-emerald-400" />
            <span className="font-semibold">ASAM MDF 多线程读写器</span>
          </div>
          <div className="text-sm text-slate-500">
            基于 asammdf 构建 · Python 3.x · 生产级质量 · 注释比例 ≥ 1:1
          </div>
        </div>
      </footer>
    </div>
  )
}
