# -*- coding: utf-8 -*-
"""
ASAM MDF 文件读写器配置模块

本模块定义了 MDF 4.x 文件格式所需的所有常量、枚举类型和配置类。
包含块类型标识、数据类型、通道类型、标志位等核心常量，
以及用于控制读写器行为的配置参数类。

注释与代码比例严格遵循 >= 1:1 的要求，每个公共接口均包含
完整的文档字符串，说明入参、返回值、方法步骤及适用范围。

作者: AI Assistant
版本: 1.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


# =============================================================================
# 块类型标识符 (Block Type Identifiers)
# =============================================================================
# 每个 MDF 块以 4 字节 ASCII 字符串开头，用于标识块类型。
# 格式为 "##XX"，其中 XX 为块类型缩写。

BLOCK_ID_ID = b"##ID"  # Identification Block: 文件标识块，64字节固定大小
BLOCK_ID_HD = b"##HD"  # Header Block: 文件头块，包含全局信息
BLOCK_ID_MD = b"##MD"  # Metadata Block: XML 元数据容器
BLOCK_ID_TX = b"##TX"  # Text Block: 纯文本字符串容器
BLOCK_ID_FH = b"##FH"  # File History Block: 文件修改历史
BLOCK_ID_CH = b"##CH"  # Channel Hierarchy Block: 通道层次结构
BLOCK_ID_AT = b"##AT"  # Attachment Block: 二进制数据附件
BLOCK_ID_EV = b"##EV"  # Event Block: 事件描述（触发器、标记等）
BLOCK_ID_DG = b"##DG"  # Data Group Block: 数据组描述
BLOCK_ID_CG = b"##CG"  # Channel Group Block: 通道组描述
BLOCK_ID_SI = b"##SI"  # Source Information Block: 源信息
BLOCK_ID_CN = b"##CN"  # Channel Block: 通道描述
BLOCK_ID_CC = b"##CC"  # Channel Conversion Block: 通道转换公式
BLOCK_ID_CA = b"##CA"  # Channel Array Block: 通道数组
BLOCK_ID_DT = b"##DT"  # Data Block: 数据记录容器
BLOCK_ID_SR = b"##SR"  # Sample Reduction Block: 降采样描述
BLOCK_ID_RD = b"##RD"  # Reduction Data Block: 降采样数据
BLOCK_ID_SD = b"##SD"  # Signal Data Block: 变长信号数据
BLOCK_ID_DL = b"##DL"  # Data List Block: 数据块有序列表（用于分片）
BLOCK_ID_DZ = b"##DZ"  # Data Zipped Block: 压缩数据容器
BLOCK_ID_HL = b"##HL"  # Header List Block: 链表头信息

# 所有已知块类型的集合，用于快速验证
ALL_BLOCK_IDS = {
    BLOCK_ID_ID, BLOCK_ID_HD, BLOCK_ID_MD, BLOCK_ID_TX, BLOCK_ID_FH,
    BLOCK_ID_CH, BLOCK_ID_AT, BLOCK_ID_EV, BLOCK_ID_DG, BLOCK_ID_CG,
    BLOCK_ID_SI, BLOCK_ID_CN, BLOCK_ID_CC, BLOCK_ID_CA, BLOCK_ID_DT,
    BLOCK_ID_SR, BLOCK_ID_RD, BLOCK_ID_SD, BLOCK_ID_DL, BLOCK_ID_DZ,
    BLOCK_ID_HL,
}


# =============================================================================
# MDF 版本常量
# =============================================================================
# 支持的 MDF 4.x 版本号

VERSION_4_00 = "4.00"  # MDF 4.00 基础版本
VERSION_4_10 = "4.10"  # MDF 4.10 引入压缩、VLSD、总线日志
VERSION_4_11 = "4.11"  # MDF 4.11 增量更新
VERSION_4_20 = "4.20"  # MDF 4.20 列式存储、复杂数、事件信号
VERSION_4_30 = "4.30"  # MDF 4.30 引入 ZStandard 和 LZ4 压缩

# 默认版本
DEFAULT_VERSION = VERSION_4_10

# 支持的版本集合
SUPPORTED_VERSIONS = {VERSION_4_00, VERSION_4_10, VERSION_4_11, VERSION_4_20, VERSION_4_30}


# =============================================================================
# 数据类型枚举 (Channel Data Types)
# =============================================================================
# 定义通道可以存储的数据类型，对应 CN 块中的 data_type 字段。
# 数值类型分为 Intel（小端）和 Motorola（大端）两种字节序。

class ChannelDataType(enum.IntEnum):
    """
    通道数据类型枚举
    
    对应 MDF 4.x CN 块中 data_type 字段的取值。
    区分字节序（Intel little-endian vs Motorola big-endian）
    和数值类型（无符号整数、有符号整数、浮点数）。
    """
    # 无符号整数类型 (Unsigned Integer)
    UINT_LE = 0   # UNSIGNED_INTEL: 无符号整数，小端序
    UINT_BE = 1   # UNSIGNED_MOTOROLA: 无符号整数，大端序

    # 有符号整数类型 (Signed Integer)
    SINT_LE = 2   # SIGNED_INTEL: 有符号整数，小端序
    SINT_BE = 3   # SIGNED_MOTOROLA: 有符号整数，大端序

    # IEEE 754 浮点类型 (Floating Point)
    FLOAT_LE = 4  # REAL_INTEL: IEEE 754 浮点数，小端序
    FLOAT_BE = 5  # REAL_MOTOROLA: IEEE 754 浮点数，大端序

    # 字符串类型 (String)
    STRING_UTF8 = 6       # STRING_UTF_8: UTF-8 编码字符串
    STRING_LATIN1 = 7     # STRING_LATIN_1: Latin-1 (ISO-8859-1) 编码字符串
    STRING_UTF16_LE = 8   # STRING_UTF_16_LE: UTF-16 小端序字符串
    STRING_UTF16_BE = 9   # STRING_UTF_16_BE: UTF-16 大端序字符串

    # 字节数组类型 (Byte Array)
    BYTEARRAY = 10  # BYTEARRAY: 原始字节数组

    # 复合类型 (Composite)
    CANOPEN_TIME = 11   # CANOPEN_TIME: CANopen 时间格式
    CANOPEN_DATE = 12   # CANOPEN_DATE: CANopen 日期格式

    # 特殊类型 (Special, 4.20+)
    COMPLEX_LE = 13     # COMPLEX_INTEL: 复数，小端序（4.20+）
    COMPLEX_BE = 14     # COMPLEX_MOTOROLA: 复数，大端序（4.20+）


def get_numpy_dtype(data_type: ChannelDataType, bit_count: int) -> str:
    """
    将 MDF 通道数据类型转换为 NumPy 数据类型描述字符串

    参数:
        data_type: 通道数据类型枚举值
        bit_count: 位宽（如 8, 16, 32, 64）

    返回:
        NumPy 兼容的数据类型格式字符串，如 '<u4', '>f8' 等

    适用:
        在读取数据时将原始字节解析为正确的数值类型

    步骤:
        1. 根据 data_type 确定字节序和数值类型类别
        2. 根据 bit_count 确定字节大小
        3. 组合成 NumPy dtype 字符串
    """
    # 确定字节序字符
    if data_type in (ChannelDataType.UINT_LE, ChannelDataType.SINT_LE,
                     ChannelDataType.FLOAT_LE, ChannelDataType.COMPLEX_LE):
        endian = "<"  # 小端序 (Intel)
    elif data_type in (ChannelDataType.UINT_BE, ChannelDataType.SINT_BE,
                       ChannelDataType.FLOAT_BE, ChannelDataType.COMPLEX_BE):
        endian = ">"  # 大端序 (Motorola)
    else:
        endian = "|"  # 不适用（字符串/字节数组）

    # 确定类型字符和字节数
    if data_type in (ChannelDataType.UINT_LE, ChannelDataType.UINT_BE):
        type_char = "u"  # 无符号整数
    elif data_type in (ChannelDataType.SINT_LE, ChannelDataType.SINT_BE):
        type_char = "i"  # 有符号整数
    elif data_type in (ChannelDataType.FLOAT_LE, ChannelDataType.FLOAT_BE):
        type_char = "f"  # 浮点数
    elif data_type in (ChannelDataType.COMPLEX_LE, ChannelDataType.COMPLEX_BE):
        type_char = "c"  # 复数
    elif data_type in (ChannelDataType.STRING_UTF8, ChannelDataType.STRING_LATIN1,
                       ChannelDataType.STRING_UTF16_LE, ChannelDataType.STRING_UTF16_BE,
                       ChannelDataType.BYTEARRAY):
        # 字符串和字节数组使用固定长度字节数组
        byte_count = max(bit_count // 8, 1)
        return f"|S{byte_count}"
    else:
        type_char = "u"  # 默认无符号整数

    # 计算字节数
    byte_count = bit_count // 8
    if byte_count == 1:
        size_char = "1"
    elif byte_count == 2:
        size_char = "2"
    elif byte_count == 4:
        size_char = "4"
    elif byte_count == 8:
        size_char = "8"
    else:
        # 非标准位宽，使用最接近的字节数
        size_char = str(max(byte_count, 1))

    return f"{endian}{type_char}{size_char}"


# =============================================================================
# 通道类型枚举 (Channel Types)
# =============================================================================

class ChannelType(enum.IntEnum):
    """
    通道类型枚举
    
    定义通道在数据记录中的角色：
    - 固定长度数据通道 (Fixed Length Data Channel)
    - 变长数据通道 (Variable Length Data Channel, VLSD)
    - 主通道/同步通道 (Master/Synchronization Channel)
    - 虚拟通道 (Virtual Channel，不占用记录空间)
    - 最大长度数据通道 (Maximum Length Data Channel)
    - 同步通道 (Synchronization Channel)
    """
    FIXED_LENGTH = 0       # 固定长度数据通道：最常见的数据通道类型
    VARIABLE_LENGTH = 1    # 变长数据通道 (VLSD)：数据长度不固定
    MASTER = 2             # 主通道：提供时间/距离等同步基准
    VIRTUAL = 3            # 虚拟通道：不存储在记录中，值由公式计算
    MAX_LENGTH = 4         # 最大长度数据通道：用于 VLSD CG 模式
    VIRTUAL_MASTER = 5     # 虚拟主通道：时间基准由公式生成


# =============================================================================
# 同步类型枚举 (Synchronization Types)
# =============================================================================

class SyncType(enum.IntEnum):
    """
    同步类型枚举
    
    定义通道使用的同步域（时间、角度、距离等）。
    主通道（ChannelType.MASTER）通过 sync_type 指示其同步域。
    """
    TIME = 0      # 时间同步：最常见，以秒或纳秒为单位
    ANGLE = 1     # 角度同步：以转数或弧度为单位
    DISTANCE = 2  # 距离同步：以米或其他长度单位为单位
    INDEX = 3     # 索引同步：以记录索引为同步基准


# =============================================================================
# 压缩算法枚举 (Compression Algorithms)
# =============================================================================

class CompressionAlgorithm(enum.IntEnum):
    """
    数据压缩算法枚举
    
    MDF 4.10+ 支持对 DT/SD/RD 块进行压缩存储（DZ 块）。
    MDF 4.30+ 新增 ZStandard 和 LZ4 算法。
    """
    NONE = 0               # 无压缩
    DEFLATE = 1            # DEFLATE (zlib/gzip)，4.10+，高压缩比
    TRANSPOSED_DEFLATE = 2 # 转置 + DEFLATE，4.10+，对列式数据更优
    ZSTD = 3               # ZStandard，4.30+，平衡压缩比和速度
    TRANSPOSED_ZSTD = 4    # 转置 + ZStandard，4.30+
    LZ4 = 5                # LZ4，4.30+，极速压缩/解压
    TRANSPOSED_LZ4 = 6     # 转置 + LZ4，4.30+


# =============================================================================
# 操作模式枚举 (Operation Modes)
# =============================================================================

class OperationMode(enum.Enum):
    """
    MDF 读写器操作模式枚举
    
    定义三种核心操作模式：
    
    1. NORMAL (一般模式): 标准 MDF 文件读写，数据以完整 DT 块存储。
       适用于数据量适中、可一次性加载到内存的场景。
       
    2. FRAGMENTED (分片模式): 数据被分割为多个小块，通过 DL 块管理。
       适用于大数据量场景，支持随机访问和增量加载。
       
    3. STREAMING (流式模式): 数据以流式方式实时写入，支持追加。
       适用于数据采集和实时监控场景，内存占用低。
    """
    NORMAL = "normal"           # 一般模式：标准读写
    FRAGMENTED = "fragmented"   # 分片模式：数据分片存储
    STREAMING = "streaming"     # 流式模式：实时流式写入


# =============================================================================
# 数据连续性枚举 (Data Continuity)
# =============================================================================

class DataContinuity(enum.Enum):
    """
    数据连续性枚举
    
    描述数据记录的连续性特征：
    
    1. CONTINUOUS (连续数据): 采样间隔固定且连续，无缺失。
       例如：以固定 100Hz 采样的传感器数据。
       
    2. INTERMITTENT (间歇数据): 采样间隔不固定，可能有缺失或突发。
       例如：事件触发记录、CAN 总线报文（非周期性）。
    """
    CONTINUOUS = "continuous"     # 连续数据：固定采样率
    INTERMITTENT = "intermittent"  # 间歇数据：非固定采样率


# =============================================================================
# 标志位常量 (Flag Constants)
# =============================================================================

# CG (Channel Group) 标志位
FLAG_CG_NONE = 0x0000           # 无特殊标志
FLAG_CG_VLSD = 0x0001           # Variable Length Signal Data CG
FLAG_CG_BUS_EVENT = 0x0002      # Bus Event CG（CAN/LIN/FlexRay 总线事件）
FLAG_CG_PLAIN_BUS_EVENT = 0x0004 # Plain Bus Event CG
FLAG_CG_REMOTE_MASTER = 0x0008  # Remote Master CG

# CN (Channel) 标志位
FLAG_CN_NONE = 0x0000           # 无特殊标志
FLAG_CN_ALL_KNOWN = 0x0001      # All values are valid (invalidation disabled)
FLAG_CN_INVALIDATION = 0x0002   # Invalidation bit enabled
FLAG_CN_PRECISION = 0x0004      # Precision is valid
FLAG_CN_RANGE = 0x0008          # Physical range is valid
FLAG_CN_LIMIT = 0x0010          # Physical limit is valid
FLAG_CN_EXTLIMIT = 0x0020       # Extended physical limit is valid
FLAG_CN_DISPLAY = 0x0040        # Display name present
FLAG_CN_BUS_EVENT = 0x0080      # Bus event channel
FLAG_CN_MONOTONOUS = 0x0100     # Monotonous channel (4.20+)
FLAG_CN_DEFAULT_X = 0x0200      # Default X axis (4.20+)

# DG (Data Group) 标志位
FLAG_DG_NONE = 0x0000           # 无特殊标志
FLAG_DG_UNSORTED = 0x0001       # Unsorted data group（多 CG，需要 record ID）
FLAG_DG_INVALIDATION = 0x0002   # Invalidation enabled for this DG

# DL (Data List) 标志位
FLAG_DL_NONE = 0x0000           # 无特殊标志
FLAG_DL_EQUAL_LEN = 0x0001      # 所有数据块长度相等

# DZ (Data Zipped) 标志位
FLAG_DZ_DEFLATE = 0x0000        # DEFLATE 压缩 (zlib)
FLAG_DZ_TRANSPOSED_DEFLATE = 0x0001  # 转置 + DEFLATE
FLAG_DZ_ZSTD = 0x0002           # ZStandard 压缩 (4.30+)
FLAG_DZ_TRANSPOSED_ZSTD = 0x0003     # 转置 + ZStandard
FLAG_DZ_LZ4 = 0x0004            # LZ4 压缩 (4.30+)
FLAG_DZ_TRANSPOSED_LZ4 = 0x0005      # 转置 + LZ4

# ID (Identification) 标志位
FLAG_ID_UNFINALIZED_STANDARD = 0x0001  # 需要更新 CG/CA cycle count
FLAG_ID_UNFINALIZED_SR = 0x0002        # 需要更新 SR cycle count
FLAG_ID_UNFINALIZED_DT = 0x0004        # 需要更新最后 DT 块长度
FLAG_ID_UNFINALIZED_RD = 0x0008        # 需要更新最后 RD 块长度
FLAG_ID_UNFINALIZED_DL = 0x0010        # 需要更新 DL 链表
FLAG_ID_UNFINALIZED_VLSD_CG = 0x0020   # 需要更新 VLSD CG 字节数
FLAG_ID_UNFINALIZED_VLSD_CN = 0x0040   # 需要更新 VLSD CN 偏移值


# =============================================================================
# 固定大小常量 (Fixed Size Constants)
# =============================================================================

ID_BLOCK_SIZE = 64       # ID 块固定大小：64 字节
HD_BLOCK_SIZE = 104      # HD 块基础大小（不含 links）
COMMON_BLOCK_HEADER_SIZE = 24  # 通用块头大小：id(4) + reserved(4) + length(8) + links_nr(8)
LINK_SIZE = 8            # 每个 link 的大小：8 字节（64 位地址）

# 记录 ID 大小选项
RECORD_ID_SIZE_NONE = 0   # 无 record ID（sorted DG）
RECORD_ID_SIZE_1 = 1      # 1 字节 record ID
RECORD_ID_SIZE_2 = 2      # 2 字节 record ID
RECORD_ID_SIZE_4 = 4      # 4 字节 record ID
RECORD_ID_SIZE_8 = 8      # 8 字节 record ID


# =============================================================================
# 配置类 (Configuration Class)
# =============================================================================

@dataclass
class MDFConfig:
    """
    MDF 读写器配置类

    提供灵活的参数配置，控制读写器的行为模式。
    所有参数均有合理的默认值，用户可按需调整。

    属性:
        version: MDF 文件版本，影响可用特性
        operation_mode: 操作模式（NORMAL/FRAGMENTED/STREAMING）
        compression: 压缩算法（NONE/DEFLATE/ZSTD/LZ4 等）
        fragment_size: 分片大小（字节），仅 FRAGMENTED 模式有效
        stream_buffer_size: 流式缓冲区大小（字节），仅 STREAMING 模式有效
        use_record_id: 是否使用 record ID（unsorted 模式）
        record_id_size: record ID 字节数（1/2/4/8）
        enable_invalidation: 是否启用无效值标记
        write_index: 是否写入索引以加速读取
        alignment: 数据对齐字节数（默认 8 字节对齐）
        max_file_size: 最大文件大小限制（字节），0 表示无限制
        cache_size: 读取缓存大小（字节）
        endian: 默认字节序（"little" 或 "big"）
        metadata_encoding: 元数据 XML 编码格式
        custom_params: 自定义参数字典，用于扩展配置

    适用:
        创建 MDFReader 或 MDFWriter 实例时传入，控制其行为

    示例:
        # 创建一般模式配置
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        # 创建分片模式配置，使用 DEFLATE 压缩
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            compression=CompressionAlgorithm.DEFLATE,
            fragment_size=1024*1024  # 1MB 分片
        )

        # 创建流式模式配置
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=64*1024  # 64KB 缓冲区
        )
    """

    # --- 基本文件属性 ---
    version: str = DEFAULT_VERSION
    """MDF 文件版本，决定可用特性集"""

    operation_mode: OperationMode = OperationMode.NORMAL
    """操作模式：NORMAL, FRAGMENTED, 或 STREAMING"""

    # --- 压缩设置 ---
    compression: CompressionAlgorithm = CompressionAlgorithm.NONE
    """数据压缩算法，4.10+ 支持 DEFLATE，4.30+ 支持 ZStandard/LZ4"""

    # --- 分片模式设置 ---
    fragment_size: int = 8 * 1024 * 1024  # 8 MB
    """分片大小（字节），FRAGMENTED 模式下每个数据块的最大大小"""

    # --- 流式模式设置 ---
    stream_buffer_size: int = 1024 * 1024  # 1 MB
    """流式缓冲区大小（字节），STREAMING 模式下的内存缓冲上限"""

    # --- 数据布局设置 ---
    use_record_id: bool = False
    """是否使用 record ID。True 表示 unsorted 模式（多 CG），False 表示 sorted"""

    record_id_size: int = RECORD_ID_SIZE_NONE
    """record ID 字节数：0（无）, 1, 2, 4, 8。0 表示 sorted 模式"""

    enable_invalidation: bool = False
    """是否启用无效值标记位。启用后每个记录尾部添加无效值字节"""

    # --- 性能优化设置 ---
    write_index: bool = True
    """是否写入索引。True 可加速后续读取，但增加写入开销"""

    alignment: int = 8
    """数据对齐字节数，默认 8 字节对齐，确保 64 位系统最优访问"""

    max_file_size: int = 0
    """最大文件大小限制（字节），0 表示无限制"""

    cache_size: int = 64 * 1024 * 1024  # 64 MB
    """读取缓存大小（字节），用于缓存频繁访问的数据块"""

    endian: str = "little"
    """默认字节序：'little' (Intel) 或 'big' (Motorola)"""

    metadata_encoding: str = "utf-8"
    """元数据 XML 字符串编码格式"""

    # --- 扩展配置 ---
    custom_params: Dict[str, Any] = field(default_factory=dict)
    """自定义参数字典，用于未来扩展和特殊需求"""

    def __post_init__(self):
        """
        配置验证与默认值设置

        步骤:
            1. 验证 version 是否在支持列表中
            2. 验证 record_id_size 合法性
            3. 验证 alignment 为 2 的幂
            4. 验证 compression 与 version 兼容性
            5. 根据 use_record_id 自动设置 record_id_size
        """
        # 验证版本号
        if self.version not in SUPPORTED_VERSIONS:
            raise ValueError(
                f"不支持的 MDF 版本: {self.version}. "
                f"支持的版本: {SUPPORTED_VERSIONS}"
            )

        # 验证 record_id_size
        if self.record_id_size not in (0, 1, 2, 4, 8):
            raise ValueError(
                f"不合法的 record_id_size: {self.record_id_size}. "
                f"必须为 0, 1, 2, 4, 8 之一"
            )

        # 验证 alignment 为 2 的幂
        if self.alignment <= 0 or (self.alignment & (self.alignment - 1)) != 0:
            raise ValueError(
                f"alignment 必须为 2 的幂，当前值: {self.alignment}"
            )

        # 验证压缩算法与版本兼容性
        if self.compression != CompressionAlgorithm.NONE:
            if self.version == VERSION_4_00:
                raise ValueError(
                    "MDF 4.00 不支持压缩，请使用 4.10 或更高版本"
                )
            if self.compression in (
                CompressionAlgorithm.ZSTD, CompressionAlgorithm.TRANSPOSED_ZSTD,
                CompressionAlgorithm.LZ4, CompressionAlgorithm.TRANSPOSED_LZ4
            ) and self.version < VERSION_4_30:
                raise ValueError(
                    "ZStandard 和 LZ4 压缩需要 MDF 4.30 或更高版本"
                )

        # 根据 use_record_id 自动同步 record_id_size
        if self.use_record_id and self.record_id_size == RECORD_ID_SIZE_NONE:
            self.record_id_size = RECORD_ID_SIZE_1  # 默认使用 1 字节 record ID
        if not self.use_record_id and self.record_id_size != RECORD_ID_SIZE_NONE:
            self.record_id_size = RECORD_ID_SIZE_NONE

    def is_sorted_mode(self) -> bool:
        """
        判断是否处于 sorted 模式

        返回:
            True 如果 record_id_size == 0（sorted 模式）
            False 如果 record_id_size > 0（unsorted 模式）

        适用:
            写入数据前判断是否需要添加 record ID
        """
        return self.record_id_size == RECORD_ID_SIZE_NONE

    def is_unsorted_mode(self) -> bool:
        """
        判断是否处于 unsorted 模式

        返回:
            True 如果 record_id_size > 0（unsorted 模式）
            False 如果 record_id_size == 0（sorted 模式）
        """
        return self.record_id_size > RECORD_ID_SIZE_NONE

    def get_endian_char(self) -> str:
        """
        获取 struct 模块使用的字节序字符

        返回:
            '<' 表示小端序 (Intel)
            '>' 表示大端序 (Motorola)

        适用:
            使用 struct.pack/struct.unpack 时指定字节序
        """
        return "<" if self.endian == "little" else ">"

    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典

        返回:
            包含所有配置项的字典，便于序列化和日志记录
        """
        return {
            "version": self.version,
            "operation_mode": self.operation_mode.value,
            "compression": self.compression.name,
            "fragment_size": self.fragment_size,
            "stream_buffer_size": self.stream_buffer_size,
            "use_record_id": self.use_record_id,
            "record_id_size": self.record_id_size,
            "enable_invalidation": self.enable_invalidation,
            "write_index": self.write_index,
            "alignment": self.alignment,
            "max_file_size": self.max_file_size,
            "cache_size": self.cache_size,
            "endian": self.endian,
            "metadata_encoding": self.metadata_encoding,
            "custom_params": dict(self.custom_params),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MDFConfig":
        """
        从字典创建配置

        参数:
            data: 包含配置项的字典

        返回:
            MDFConfig 实例

        适用:
            从配置文件或序列化数据恢复配置
        """
        # 转换枚举类型
        if "operation_mode" in data and isinstance(data["operation_mode"], str):
            data["operation_mode"] = OperationMode(data["operation_mode"])
        if "compression" in data and isinstance(data["compression"], str):
            data["compression"] = CompressionAlgorithm[data["compression"]]

        # 过滤出本类支持的字段
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}

        return cls(**filtered)
