# -*- coding: utf-8 -*-
"""
ASAM MDF 4.x 文件写入器模块

本模块实现了 MDF 文件的写入功能，支持三种操作模式：
    1. 一般模式 (NORMAL): 标准 MDF 文件写入，数据以完整 DT 块存储
    2. 分片模式 (FRAGMENTED): 数据分割为多个块，通过 DL 块管理
    3. 流式模式 (STREAMING): 实时流式写入，支持追加和持久化

特性:
    - 支持间歇 (INTERMITTENT) 和连续 (CONTINUOUS) 数据
    - 关闭后可重新打开继续追加数据
    - 支持 DEFLATE 压缩（4.10+）
    - 支持 sorted 和 unsorted 数据布局
    - 支持通道转换公式 (CC 块)
    - 完善的文件历史追踪 (FH 块)

线程安全:
    本模块的写入操作非线程安全。如需多线程使用，请在外部加锁。

作者: AI Assistant
版本: 1.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import struct
import io
import zlib
import time
import logging
from typing import Optional, Dict, List, Any, Tuple, BinaryIO, Union
from dataclasses import dataclass, field
from datetime import datetime, timezone

from mdf_config import (
    # 块类型
    BLOCK_ID_ID, BLOCK_ID_HD, BLOCK_ID_DG, BLOCK_ID_CG, BLOCK_ID_CN,
    BLOCK_ID_DT, BLOCK_ID_DL, BLOCK_ID_DZ, BLOCK_ID_HL,
    BLOCK_ID_TX, BLOCK_ID_MD, BLOCK_ID_FH, BLOCK_ID_CC,
    # 常量
    ID_BLOCK_SIZE, COMMON_BLOCK_HEADER_SIZE, LINK_SIZE,
    RECORD_ID_SIZE_NONE, RECORD_ID_SIZE_1, RECORD_ID_SIZE_2,
    RECORD_ID_SIZE_4, RECORD_ID_SIZE_8,
    FLAG_CG_NONE, FLAG_DG_NONE, FLAG_CN_NONE, FLAG_DL_NONE,
    FLAG_DZ_DEFLATE, FLAG_ID_UNFINALIZED_DT,
    # 枚举
    ChannelDataType, ChannelType, SyncType,
    CompressionAlgorithm, OperationMode, DataContinuity,
    MDFConfig, get_numpy_dtype,
    SUPPORTED_VERSIONS, DEFAULT_VERSION,
)
from mdf_blocks import (
    IDBlock, HDBlock, DGBlock, CGBlock, CNBlock,
    DTBlock, DLBlock, HLBlock, DZBlock,
    TXBlock, MDBlock, FHBlock, CCBlock,
    ChannelInfo, calculate_record_layout,
)

# 配置日志
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类
# =============================================================================

class MDFWriterError(Exception):
    """MDF 写入器基础异常"""
    pass


class MDFWriterModeError(MDFWriterError):
    """模式错误异常"""
    pass


class MDFWriterStateError(MDFWriterError):
    """状态错误异常（如关闭后操作）"""
    pass


class MDFWriterValidationError(MDFWriterError):
    """数据验证错误异常"""
    pass


# =============================================================================
# 内部数据结构
# =============================================================================

@dataclass
class _DGState:
    """
    数据组写入状态（内部使用）

    追踪单个 DG 的写入状态，包括：
    - 当前 CG 的元数据
    - 已写入的记录数
    - 数据块的地址列表（分片模式下）
    - 缓冲区数据（流式模式下）
    """
    dg_addr: int = 0                # DG 块文件地址
    cg_addr: int = 0                # CG 块文件地址
    cn_addrs: List[int] = field(default_factory=list)  # CN 块地址列表
    record_size: int = 0            # 每条记录的字节数
    cycles_written: int = 0         # 已写入的记录数
    data_block_addrs: List[int] = field(default_factory=list)  # 数据块地址列表
    buffer: bytearray = field(default_factory=bytearray)  # 流式缓冲区
    last_dt_addr: int = 0           # 最后一个 DT 块地址（追加用）


# =============================================================================
# MDF 写入器主类
# =============================================================================

class MDFWriter:
    """
    ASAM MDF 4.x 文件写入器

    提供三种操作模式的 MDF 文件写入功能：

    1. 一般模式 (NORMAL):
       - 数据以完整 DT 块形式一次性写入
       - 适用于数据量适中、可全部加载到内存的场景
       - 写入流程：定义通道 -> 准备数据 -> 写入文件

    2. 分片模式 (FRAGMENTED):
       - 数据被分割为多个小块（可配置 fragment_size）
       - 通过 DL 块链接管理数据碎片
       - 支持压缩（可选 CompressionAlgorithm）
       - 适用于大数据量场景

    3. 流式模式 (STREAMING):
       - 数据以流式方式实时追加写入
       - 内存中维护写入缓冲区
       - 支持关闭后重新打开继续追加
       - 适用于数据采集、实时监控场景

    使用示例:
        # 一般模式
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter("output.mf4", config)
        writer.define_channels([ChannelInfo(name="Speed", unit="km/h")])
        writer.write_records(data_bytes)
        writer.close()

        # 流式模式，支持追加
        config = MDFConfig(operation_mode=OperationMode.STREAMING)
        writer = MDFWriter("output.mf4", config)
        writer.define_channels([...])
        for chunk in data_generator:
            writer.append_records(chunk)
        writer.close()

        # 重新打开追加
        writer2 = MDFWriter("output.mf4", config, append=True)
        writer2.append_records(new_data)
        writer2.close()

    属性:
        filepath: 输出文件路径
        config: MDFConfig 配置对象
        mode: 操作模式
        is_open: 文件是否处于打开状态
        is_append: 是否为追加模式
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None,
                 append: bool = False):
        """
        初始化 MDF 写入器

        参数:
            filepath: 输出 MDF 文件路径
            config: MDFConfig 配置对象，None 时使用默认配置
            append: 是否为追加模式。True 表示打开已有文件并追加数据

        步骤:
            1. 保存配置参数
            2. 确定操作模式
            3. 如果是追加模式，读取现有文件结构
            4. 否则创建新文件
            5. 初始化内部状态

        异常:
            MDFWriterModeError: 不支持的配置组合
            MDFWriterStateError: 文件已打开或其他状态错误
        """
        # 保存配置（使用默认配置 if None）
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath
        self.mode: OperationMode = self.config.operation_mode
        self.is_append: bool = append

        # 文件句柄
        self._file: Optional[BinaryIO] = None

        # 内部状态
        self._is_open: bool = False
        self._channels_defined: bool = False
        self._channels: List[ChannelInfo] = []
        self._dg_states: List[_DGState] = []
        self._current_dg_idx: int = -1
        self._header: Optional[HDBlock] = None
        self._id_block: Optional[IDBlock] = None
        self._file_history: List[FHBlock] = []

        # 记录布局缓存
        self._record_size: int = 0
        self._byte_offsets: List[int] = []

        # 流式模式专用状态
        self._stream_buffer: bytearray = bytearray()
        self._stream_records_buffered: int = 0

        # 统计信息
        self._total_records_written: int = 0
        self._total_bytes_written: int = 0

        # 打开或创建文件
        if append:
            self._open_for_append()
        else:
            self._create_new_file()

    # ======================================================================
    # 属性访问
    # ======================================================================

    @property
    def is_open(self) -> bool:
        """文件是否处于打开状态"""
        return self._is_open

    @property
    def total_records(self) -> int:
        """已写入的总记录数"""
        return self._total_records_written

    @property
    def total_bytes(self) -> int:
        """已写入的总字节数"""
        return self._total_bytes_written

    # ======================================================================
    # 文件创建 / 打开
    # ======================================================================

    def _create_new_file(self) -> None:
        """
        创建新 MDF 文件

        步骤:
            1. 以二进制写模式打开文件
            2. 写入 ID 块（64 字节，固定位置）
            3. 预留 HD 块空间（写入占位数据）
            4. 初始化文件状态

        异常:
            IOError: 文件无法创建
        """
        logger.info(f"创建新 MDF 文件: {self.filepath}, 模式: {self.mode.value}")

        # 步骤 1: 打开文件
        self._file = open(self.filepath, "wb+")

        # 步骤 2: 创建并写入 ID 块
        version_num = int(self.config.version.replace(".", ""))
        self._id_block = IDBlock(version=version_num)
        self._file.write(self._id_block.to_bytes())

        # 步骤 3: 创建 HD 块并写入
        self._header = HDBlock(start_time_ns=self._get_timestamp_ns())
        self._file.write(self._header.to_bytes())

        # 步骤 4: 写入文件历史块
        fh_block = self._create_file_history()
        fh_addr = self._file.tell()
        self._file.write(fh_block.to_bytes())
        self._header.fh_first = fh_addr
        self._file_history.append(fh_block)

        # 回写更新后的 HD 块
        self._file.seek(ID_BLOCK_SIZE)
        self._file.write(self._header.to_bytes())

        # 恢复文件指针到文件末尾（回写 HD 会将指针移到 HD 块末尾，
        # 但文件内容可能已延伸到更后面，必须恢复末尾位置）
        self._file.seek(0, 2)

        self._is_open = True
        self._total_bytes_written = self._file.tell()

        logger.debug(f"文件创建完成，当前大小: {self._total_bytes_written} 字节")

    def _open_for_append(self) -> None:
        """
        打开已有文件以追加数据

        步骤:
            1. 检查文件是否存在
            2. 读取并验证 ID 块
            3. 读取 HD 块
            4. 遍历现有 DG/CG/CN 结构
            5. 定位到文件末尾准备追加

        异常:
            FileNotFoundError: 文件不存在
            MDFWriterValidationError: 文件格式不兼容
        """
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"追加模式指定的文件不存在: {self.filepath}")

        logger.info(f"打开文件以追加: {self.filepath}")

        # 步骤 1: 以读写模式打开
        self._file = open(self.filepath, "rb+")

        # 步骤 2: 读取并验证 ID 块
        self._id_block = IDBlock.from_stream(self._file)
        file_version = self._id_block.get_version_string()
        logger.debug(f"文件版本: {file_version}")

        # 验证版本兼容性
        if file_version != self.config.version:
            logger.warning(f"文件版本 ({file_version}) 与配置版本 ({self.config.version}) 不匹配")

        # 步骤 3: 读取 HD 块
        self._header = HDBlock.from_stream(self._file, ID_BLOCK_SIZE)

        # 步骤 4: 遍历现有 DG 结构（简化：读取最后一个 DG 的状态）
        self._scan_existing_structure()

        # 步骤 5: seek 到文件末尾
        self._file.seek(0, 2)  # seek to end
        self._is_open = True

        logger.info(f"文件已打开，当前大小: {self._file.tell()} 字节")

    def _scan_existing_structure(self) -> None:
        """
        扫描现有文件结构（追加模式下）

        步骤:
            1. 遍历 DG 链表，找到最后一个 DG
            2. 读取该 DG 的 CG 和 CN 信息
            3. 重建通道定义和记录布局
            4. 保存 DG 状态以便后续追加

        注意:
            当前为简化实现，完整实现需递归遍历所有块
        """
        # 简化实现：定位到文件末尾，后续写入将创建新的 DG
        # 完整实现应解析现有结构以在现有 DG 中追加
        pass

    # ======================================================================
    # 文件历史
    # ======================================================================

    def _create_file_history(self, program_name: str = "MDFWriter") -> FHBlock:
        """
        创建文件历史块

        参数:
            program_name: 程序/工具名称

        步骤:
            1. 创建 TX 块存储程序名称
            2. 创建 FH 块并设置时间戳和链接

        返回:
            FHBlock 实例
        """
        # 创建程序名称 TX 块
        tx_program = TXBlock(text=program_name)
        tx_addr = self._get_current_position()
        self._file.write(tx_program.to_bytes())

        # 创建 FH 块
        fh = FHBlock(
            time_ns=self._get_timestamp_ns(),
            tx_program=tx_addr,
        )
        return fh

    # ======================================================================
    # 通道定义
    # ======================================================================

    def define_channels(self, channels: List[ChannelInfo]) -> None:
        """
        定义通道布局

        参数:
            channels: 通道信息列表，定义每个通道的名称、类型、位宽等

        步骤:
            1. 验证文件处于打开状态
            2. 验证通道列表非空
            3. 计算记录布局（字节偏移和记录大小）
            4. 创建 DG -> CG -> CN 块结构
            5. 写入元数据块到文件

        异常:
            MDFWriterStateError: 文件未打开
            MDFWriterValidationError: 通道定义无效

        适用:
            写入数据前必须先调用此方法定义通道布局
        """
        # 步骤 1: 验证状态
        if not self._is_open:
            raise MDFWriterStateError("文件未打开，无法定义通道")

        if self._channels_defined:
            logger.warning("通道已定义，重新定义将创建新的数据组")

        # 步骤 2: 验证通道列表
        if not channels:
            raise MDFWriterValidationError("通道列表不能为空")

        self._channels = channels

        # 步骤 3: 计算记录布局
        inval_bytes = 1 if self.config.enable_invalidation else 0
        self._record_size, self._byte_offsets = calculate_record_layout(
            channels,
            alignment=self.config.alignment,
            record_id_size=self.config.record_id_size,
            inval_bytes_nr=inval_bytes,
        )

        logger.debug(f"记录大小: {self._record_size} 字节, "
                     f"通道数: {len(channels)}")

        # 步骤 4-5: 创建并写入 DG/CG/CN 结构
        self._write_channel_structure()

        self._channels_defined = True

    def _write_channel_structure(self) -> None:
        """
        写入通道结构块（DG -> CG -> CN 层次）

        步骤:
            1. 创建 DG 块
            2. 创建 CG 块（设置 record_size 和 flags）
            3. 为每个通道创建 CN 块、TX 块（名称）、可选 CC 块
            4. 链接所有块
            5. 写入文件并更新 HD -> DG 链表
        """
        file_pos = self._get_current_position

        # 步骤 1: 创建 DG 块
        dg = DGBlock(
            flags=FLAG_DG_NONE,
            record_id_size=self.config.record_id_size,
        )
        dg_addr = file_pos()

        # 预留 DG 块空间（稍后回填）
        dg_placeholder = dg.to_bytes()
        self._file.write(dg_placeholder)

        # 步骤 2: 创建 CG 块
        inval_bytes = 1 if self.config.enable_invalidation else 0
        cg = CGBlock(
            flags=FLAG_CG_NONE,
            samples_byte_nr=self._record_size - inval_bytes,
            inval_bytes_nr=inval_bytes,
        )
        cg_addr = file_pos()
        cg_placeholder = cg.to_bytes()
        self._file.write(cg_placeholder)

        # 更新 DG -> CG 链接
        dg.cg_first = cg_addr

        # 步骤 3: 为每个通道创建 CN 块
        cn_addrs = []
        prev_cn_addr = 0

        for i, ch in enumerate(self._channels):
            # 创建通道名称 TX 块
            tx_name = TXBlock(text=ch.name)
            tx_name_addr = file_pos()
            self._file.write(tx_name.to_bytes())

            # 创建单位 TX 块（如果有）
            tx_unit_addr = 0
            if ch.unit:
                tx_unit = TXBlock(text=ch.unit)
                tx_unit_addr = file_pos()
                self._file.write(tx_unit.to_bytes())

            # 创建转换 CC 块（如果有转换参数）
            cc_addr = 0
            if ch.conversion_a != 1.0 or ch.conversion_b != 0.0:
                cc = CCBlock(
                    type=1,  # 线性转换
                    parameters=[ch.conversion_a, ch.conversion_b],
                    md_unit=tx_unit_addr,
                )
                cc_addr = file_pos()
                self._file.write(cc.to_bytes())

            # 创建 CN 块
            byte_offset = self._byte_offsets[i]
            cn = CNBlock(
                cn_next=0,  # 暂时设为 0，最后一个保持 0
                cc_conversion=cc_addr,
                tx_name=tx_name_addr,
                channel_type=ch.channel_type,
                sync_type=ch.sync_type,
                data_type=ch.data_type,
                byte_offset=byte_offset,
                bit_count=ch.bit_count,
                bit_offset=ch.bit_offset,
            )
            cn_addr = file_pos()
            cn_placeholder = cn.to_bytes()
            self._file.write(cn_placeholder)

            cn_addrs.append(cn_addr)

            # 链接前一个 CN -> 当前 CN
            if prev_cn_addr != 0:
                # 回写前一个 CN 的 next 指针
                self._update_link_at(prev_cn_addr, 0, cn_addr)

            prev_cn_addr = cn_addr

        # 更新 CG -> 第一个 CN 链接
        if cn_addrs:
            cg.cn_first = cn_addrs[0]

        # 步骤 5: 回写更新后的 CG 块
        self._file.seek(cg_addr)
        self._file.write(cg.to_bytes())

        # 回写更新后的 DG 块
        self._file.seek(dg_addr)
        self._file.write(dg.to_bytes())

        # 更新 HD -> DG 链表
        self._update_dg_linked_list(dg_addr)

        # 恢复文件位置到末尾
        self._file.seek(0, 2)

        # 保存 DG 状态
        dg_state = _DGState(
            dg_addr=dg_addr,
            cg_addr=cg_addr,
            cn_addrs=cn_addrs,
            record_size=self._record_size,
        )
        self._dg_states.append(dg_state)
        self._current_dg_idx = len(self._dg_states) - 1

        logger.debug(f"通道结构写入完成: DG@0x{dg_addr:X}, CG@0x{cg_addr:X}, "
                     f"{len(cn_addrs)} 个 CN")

    def _update_dg_linked_list(self, new_dg_addr: int) -> None:
        """
        更新 HD -> DG 链表

        参数:
            new_dg_addr: 新 DG 块的地址

        步骤:
            1. 如果 HD.dg_first 为 0，设置为新 DG 地址
            2. 否则遍历 DG 链表，找到最后一个 DG，更新其 dg_next
        """
        if self._header.dg_first == 0:
            # 第一个 DG
            self._header.dg_first = new_dg_addr
            self._file.seek(ID_BLOCK_SIZE)
            self._file.write(self._header.to_bytes())
        else:
            # 遍历到链表尾部
            current_addr = self._header.dg_first
            while current_addr != 0:
                self._file.seek(current_addr)
                header_raw = self._file.read(COMMON_BLOCK_HEADER_SIZE)
                block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

                # 读取第一个 link（dg_next）
                if links_nr > 0:
                    next_raw = self._file.read(LINK_SIZE)
                    next_addr = struct.unpack("<Q", next_raw)[0]
                    if next_addr == 0:
                        # 找到尾部，更新 next
                        self._update_link_at(current_addr, 0, new_dg_addr)
                        break
                    current_addr = next_addr
                else:
                    break

    def _update_link_at(self, block_addr: int, link_index: int, new_value: int) -> None:
        """
        更新指定块中指定链接的值

        参数:
            block_addr: 块地址
            link_index: 链接索引（从 0 开始）
            new_value: 新的链接值

        注意:
            方法会自动保存和恢复文件指针位置，
            确保调用后文件指针位置不变。
        """
        # 保存当前文件位置
        current_pos = self._file.tell()
        link_offset = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * link_index
        self._file.seek(block_addr + link_offset)
        self._file.write(struct.pack("<Q", new_value))
        # 恢复文件位置
        self._file.seek(current_pos)

    # ======================================================================
    # 数据写入（一般模式）
    # ======================================================================

    def write_records(self, records: bytes) -> int:
        """
        一般模式下写入数据记录

        参数:
            records: 原始记录字节数据，每条记录长度必须等于 record_size

        返回:
            写入的记录数

        步骤:
            1. 验证状态（文件打开、通道已定义）
            2. 验证数据大小
            3. 根据模式选择存储方式：
               - NORMAL: 直接写入 DT 块
               - FRAGMENTED: 分片写入多个 DT 块 + DL 块
               - STREAMING: 缓冲写入
            4. 更新 CG 块的 cycles_nr

        异常:
            MDFWriterStateError: 文件未打开或通道未定义
            MDFWriterValidationError: 数据大小不合法

        适用:
            一般模式和分片模式下的批量数据写入
        """
        # 步骤 1: 验证状态
        if not self._is_open:
            raise MDFWriterStateError("文件未打开")
        if not self._channels_defined:
            raise MDFWriterStateError("通道未定义，请先调用 define_channels")

        # 步骤 2: 验证数据大小
        if len(records) == 0:
            return 0

        if len(records) % self._record_size != 0:
            raise MDFWriterValidationError(
                f"数据大小 ({len(records)}) 不是记录大小 ({self._record_size}) 的整数倍"
            )

        num_records = len(records) // self._record_size

        # 步骤 3: 根据模式写入
        if self.mode == OperationMode.NORMAL:
            self._write_normal(records)
        elif self.mode == OperationMode.FRAGMENTED:
            self._write_fragmented(records)
        elif self.mode == OperationMode.STREAMING:
            self._write_streaming(records)
        else:
            raise MDFWriterModeError(f"未知操作模式: {self.mode}")

        # 步骤 4: 更新统计
        self._total_records_written += num_records
        self._total_bytes_written += len(records)

        # 更新 CG 的 cycles_nr
        self._update_cycles(num_records)

        logger.debug(f"写入 {num_records} 条记录, 模式: {self.mode.value}")

        return num_records

    def _write_normal(self, records: bytes) -> None:
        """
        一般模式写入：直接写入单个 DT 块

        参数:
            records: 记录字节数据

        步骤:
            1. 应用压缩（如果启用）
            2. 写入 DT 块到文件
            3. 更新 DG -> data_addr 链接
        """
        dg_state = self._dg_states[self._current_dg_idx]

        # 步骤 1: 压缩（如果启用）
        if self.config.compression != CompressionAlgorithm.NONE:
            dz = DZBlock.compress(records, zip_type=FLAG_DZ_DEFLATE)
            data_addr = self._get_current_position()
            self._file.write(dz.to_bytes())
            # 更新 DG 指向 DZ 块
            self._update_link_at(dg_state.dg_addr, 2, data_addr)
        else:
            # 步骤 2: 直接写入 DT 块
            dt = DTBlock(data=records)
            data_addr = self._get_current_position()
            self._file.write(dt.to_bytes())
            # 步骤 3: 更新 DG -> data_addr
            self._update_link_at(dg_state.dg_addr, 2, data_addr)

        dg_state.data_block_addrs.append(data_addr)

    def _write_fragmented(self, records: bytes) -> None:
        """
        分片模式写入：将数据分割为多个块

        参数:
            records: 记录字节数据

        步骤:
            1. 计算分片大小（确保为 record_size 的整数倍）
            2. 循环分割数据为多个 fragment
            3. 为每个 fragment 写入 DT 块（或压缩后的 DZ 块）
            4. 收集数据块地址
            5. 如果只有一个分片，直接链接到 DG
            6. 如果多个分片，创建 DL 块管理
            7. 如果启用压缩，创建 HL 块
        """
        dg_state = self._dg_states[self._current_dg_idx]

        # 步骤 1: 计算分片大小
        fragment_size = self.config.fragment_size
        # 确保分片大小是 record_size 的整数倍
        records_per_fragment = max(fragment_size // self._record_size, 1)
        actual_fragment_size = records_per_fragment * self._record_size

        # 步骤 2-3: 分割并写入
        dt_addrs = []
        for i in range(0, len(records), actual_fragment_size):
            chunk = records[i:i + actual_fragment_size]

            if self.config.compression != CompressionAlgorithm.NONE:
                dz = DZBlock.compress(chunk, zip_type=FLAG_DZ_DEFLATE)
                addr = self._get_current_position()
                self._file.write(dz.to_bytes())
            else:
                dt = DTBlock(data=chunk)
                addr = self._get_current_position()
                self._file.write(dt.to_bytes())

            dt_addrs.append(addr)

        # 步骤 5-7: 管理数据块链接
        if len(dt_addrs) == 1:
            # 单个分片，直接链接
            self._update_link_at(dg_state.dg_addr, 2, dt_addrs[0])
            dg_state.data_block_addrs.extend(dt_addrs)
        else:
            # 多个分片，创建 DL 块
            dl_addr = self._create_dl_chain(dt_addrs)
            self._update_link_at(dg_state.dg_addr, 2, dl_addr)
            dg_state.data_block_addrs.append(dl_addr)

    def _create_dl_chain(self, dt_addrs: List[int]) -> int:
        """
        创建 DL 块链表

        参数:
            dt_addrs: 数据块地址列表

        步骤:
            1. 如果地址数量少，创建单个 DL 块
            2. 如果数量多，创建多个 DL 块形成链表
            3. 返回第一个 DL 块地址

        返回:
            第一个 DL 块的文件地址
        """
        # 简化：创建单个 DL 块
        dl = DLBlock(
            dl_next=0,
            data_addrs=dt_addrs,
            flags=FLAG_DL_NONE,
            equal_len=0,
        )
        dl_addr = self._get_current_position()
        self._file.write(dl.to_bytes())
        return dl_addr

    def _write_streaming(self, records: bytes) -> None:
        """
        流式模式写入：缓冲并批量刷盘

        参数:
            records: 记录字节数据

        步骤:
            1. 将数据追加到内存缓冲区
            2. 如果缓冲区超过阈值，刷盘
            3. 更新 DG 数据链接
        """
        self._stream_buffer.extend(records)
        self._stream_records_buffered += len(records) // self._record_size

        # 检查是否需要刷盘
        if len(self._stream_buffer) >= self.config.stream_buffer_size:
            self._flush_stream_buffer()

    def _flush_stream_buffer(self) -> None:
        """
        刷写流式缓冲区到文件

        步骤:
            1. 如果缓冲区为空，直接返回
            2. 根据配置选择写入方式（DT 或 DZ）
            3. 写入新的数据块
            4. 如果已有数据块，创建或更新 DL 块来链接所有数据块
            5. 更新 DG 的 data_addr 指向 DL 块（或第一个 DT 块）
            6. 清空缓冲区

        注意:
            流式模式下多次刷盘会产生多个 DT 块。
            为避免数据丢失，使用 DL 块管理所有 DT 块的链接。
            第一次刷盘时 DG.data_addr 直接指向 DT 块。
            第二次及以后刷盘时，创建 DL 块包含所有 DT 块地址，
            DG.data_addr 指向 DL 块。
        """
        if len(self._stream_buffer) == 0:
            return

        dg_state = self._dg_states[self._current_dg_idx]

        # 步骤 2-3: 写入新的数据块
        if self.config.compression != CompressionAlgorithm.NONE:
            dz = DZBlock.compress(bytes(self._stream_buffer), zip_type=FLAG_DZ_DEFLATE)
            new_block_addr = self._get_current_position()
            self._file.write(dz.to_bytes())
        else:
            dt = DTBlock(data=bytes(self._stream_buffer))
            new_block_addr = self._get_current_position()
            self._file.write(dt.to_bytes())

        # 步骤 4: 管理数据块链接
        if not dg_state.data_block_addrs:
            # 第一次刷盘：DG.data_addr 直接指向 DT 块
            self._update_link_at(dg_state.dg_addr, 2, new_block_addr)
            dg_state.data_block_addrs.append(new_block_addr)
            dg_state.last_dt_addr = new_block_addr
        else:
            # 第二次及以后刷盘：使用 DL 块管理所有 DT 块
            # 方案：创建新的 DL 块，包含所有历史 DT 块地址 + 新 DT 块地址
            all_addrs = dg_state.data_block_addrs + [new_block_addr]
            dl = DLBlock(
                dl_next=0,
                data_addrs=all_addrs,
                flags=FLAG_DL_NONE,
            )
            dl_addr = self._get_current_position()
            self._file.write(dl.to_bytes())

            # 更新 DG.data_addr 指向 DL 块
            self._update_link_at(dg_state.dg_addr, 2, dl_addr)
            dg_state.data_block_addrs.append(new_block_addr)
            dg_state.last_dt_addr = new_block_addr

        # 步骤 6: 清空缓冲区
        buffer_size = len(self._stream_buffer)
        self._stream_buffer = bytearray()
        self._stream_records_buffered = 0

        logger.debug(f"流式缓冲区刷盘: {buffer_size} 字节")

    # ======================================================================
    # 数据追加（流式模式专用）
    # ======================================================================

    def append_records(self, records: Union[bytes, bytearray]) -> int:
        """
        追加数据记录（主要用于流式模式）

        参数:
            records: 记录字节数据，可为 bytes 或 bytearray

        返回:
            追加的记录数

        步骤:
            1. 验证状态
            2. 如果是流式模式，使用缓冲写入
            3. 否则委托给 write_records

        适用:
            流式模式下循环调用，实现低延迟数据追加
        """
        if not self._is_open:
            raise MDFWriterStateError("文件未打开")

        if isinstance(records, bytearray):
            records = bytes(records)

        if self.mode == OperationMode.STREAMING:
            return self.write_records(records)
        else:
            return self.write_records(records)

    def append_continuous(self, samples: Dict[str, Any]) -> None:
        """
        追加连续数据样本（单条记录）

        参数:
            samples: 通道名 -> 值的字典

        步骤:
            1. 验证状态
            2. 按通道定义的顺序打包数值
            3. 写入单条记录

        适用:
            连续采样场景，每次调用写入一个时间点的所有通道值
        """
        if not self._is_open or not self._channels_defined:
            raise MDFWriterStateError("文件未打开或通道未定义")

        # 打包单条记录
        record = self._pack_record(samples)
        self.append_records(record)

    def append_intermittent(self, channel_name: str, timestamp: float,
                            value: Any) -> None:
        """
        追加间歇数据样本

        参数:
            channel_name: 通道名称
            timestamp: 时间戳
            value: 通道值

        步骤:
            1. 验证通道存在
            2. 打包为单通道记录（包含时间戳和值）
            3. 写入记录

        适用:
            间歇/事件触发采样，每次只写入一个通道的值
        """
        if not self._is_open or not self._channels_defined:
            raise MDFWriterStateError("文件未打开或通道未定义")

        # 查找通道索引
        ch_idx = None
        for i, ch in enumerate(self._channels):
            if ch.name == channel_name:
                ch_idx = i
                break

        if ch_idx is None:
            raise MDFWriterValidationError(f"通道不存在: {channel_name}")

        # 打包单通道记录
        record = self._pack_single_channel_record(ch_idx, timestamp, value)
        self.append_records(record)

    def _pack_record(self, samples: Dict[str, Any]) -> bytes:
        """
        将样本字典打包为记录字节

        参数:
            samples: 通道名 -> 值的字典

        步骤:
            1. 创建指定大小的字节缓冲区
            2. 遍历通道定义，按顺序写入值
            3. 返回打包后的字节

        返回:
            单条记录的字节表示
        """
        record = bytearray(self._record_size)

        for i, ch in enumerate(self._channels):
            if ch.name not in samples:
                continue

            val = samples[ch.name]
            offset = self._byte_offsets[i]

            # 根据数据类型打包
            dtype = get_numpy_dtype(ch.data_type, ch.bit_count)
            try:
                packed = struct.pack(f"<{self._get_struct_format(ch)}", val)
                record[offset:offset + len(packed)] = packed
            except struct.error as e:
                logger.warning(f"打包通道 {ch.name} 失败: {e}")

        return bytes(record)

    def _pack_single_channel_record(self, ch_idx: int, timestamp: float,
                                     value: Any) -> bytes:
        """
        打包单通道记录（用于间歇数据）

        参数:
            ch_idx: 通道索引
            timestamp: 时间戳
            value: 通道值

        返回:
            单条记录字节
        """
        record = bytearray(self._record_size)
        ch = self._channels[ch_idx]
        offset = self._byte_offsets[ch_idx]

        try:
            packed = struct.pack(f"<{self._get_struct_format(ch)}", value)
            record[offset:offset + len(packed)] = packed
        except struct.error as e:
            logger.warning(f"打包通道 {ch.name} 失败: {e}")

        return bytes(record)

    def _get_struct_format(self, ch: ChannelInfo) -> str:
        """
        获取 struct 格式字符

        参数:
            ch: 通道信息

        返回:
            struct 格式字符串（不含字节序前缀）
        """
        if ch.data_type in (ChannelDataType.UINT_LE, ChannelDataType.UINT_BE):
            type_char = "u"
        elif ch.data_type in (ChannelDataType.SINT_LE, ChannelDataType.SINT_BE):
            type_char = "i"
        elif ch.data_type in (ChannelDataType.FLOAT_LE, ChannelDataType.FLOAT_BE):
            type_char = "f"
        else:
            type_char = "u"

        byte_count = ch.bit_count // 8
        if byte_count == 1:
            size_char = "B" if type_char == "u" else "b"
        elif byte_count == 2:
            size_char = "H" if type_char == "u" else "h"
        elif byte_count == 4:
            if type_char == "f":
                size_char = "f"
            else:
                size_char = "I" if type_char == "u" else "i"
        elif byte_count == 8:
            if type_char == "f":
                size_char = "d"
            else:
                size_char = "Q" if type_char == "u" else "q"
        else:
            size_char = f"{byte_count}s"

        return size_char

    # ======================================================================
    # 更新操作
    # ======================================================================

    def _update_cycles(self, num_records: int) -> None:
        """
        更新 CG 块的采样周期数 (cycles_nr)

        参数:
            num_records: 新增记录数

        步骤:
            1. 保存当前文件位置
            2. seek 到 CG 块的 cycles_nr 字段
            3. 读取当前值，增加 num_records
            4. 写回新值
            5. 恢复文件位置到原位置

        注意:
            本方法会修改文件指针位置，但会在返回前恢复原位置，
            确保调用者的文件指针不受干扰。
        """
        # 步骤 1: 保存当前文件位置
        saved_pos = self._file.tell()

        dg_state = self._dg_states[self._current_dg_idx]
        cg_addr = dg_state.cg_addr

        # 步骤 2-4: 读取并更新 cycles_nr
        # cycles_nr 在 CG Data Section 的偏移 4-7
        cycles_offset = COMMON_BLOCK_HEADER_SIZE + 6 * LINK_SIZE + 4
        self._file.seek(cg_addr + cycles_offset)
        current_cycles = struct.unpack("<I", self._file.read(4))[0]
        new_cycles = current_cycles + num_records

        self._file.seek(cg_addr + cycles_offset)
        self._file.write(struct.pack("<I", new_cycles))

        dg_state.cycles_written = new_cycles

        # 步骤 5: 恢复文件位置
        self._file.seek(saved_pos)

    # ======================================================================
    # 关闭与资源释放
    # ======================================================================

    def close(self, finalize: bool = True) -> None:
        """
        关闭写入器并释放资源

        参数:
            finalize: 是否最终化文件（更新所有元数据）

        步骤:
            1. 如果是流式模式，刷盘剩余缓冲区
            2. 如果 finalize，更新文件元数据
            3. 关闭文件句柄
            4. 重置内部状态

        适用:
            完成所有写入操作后必须调用此方法
        """
        if not self._is_open:
            return

        logger.info("关闭 MDF 写入器...")

        # 步骤 1: 刷盘流式缓冲区
        if self.mode == OperationMode.STREAMING:
            self._flush_stream_buffer()

        # 步骤 2: 最终化文件
        if finalize:
            self._finalize_file()

        # 步骤 3: 关闭文件
        if self._file:
            self._file.close()
            self._file = None

        self._is_open = False
        logger.info(f"文件已关闭。总记录数: {self._total_records_written}, "
                     f"总字节数: {self._total_bytes_written}")

    def _finalize_file(self) -> None:
        """
        最终化文件

        步骤:
            1. 清除未最终化标志
            2. 更新 ID 块的 standard_flags 为 0
            3. 确保所有元数据一致性
        """
        try:
            # 更新 ID 块标志为已最终化
            self._id_block.standard_flags = 0
            self._file.seek(0)
            self._file.write(self._id_block.to_bytes())
        except Exception as e:
            logger.warning(f"最终化文件时出错: {e}")

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口，确保资源释放"""
        self.close()
        return False

    # ======================================================================
    # 工具方法
    # ======================================================================

    def _get_current_position(self) -> int:
        """
        获取当前文件写入位置

        返回:
            当前文件偏移量（字节）
        """
        return self._file.tell()

    @staticmethod
    def _get_timestamp_ns() -> int:
        """
        获取当前 UTC 时间戳（纳秒）

        返回:
            自 Unix 纪元以来的纳秒数

        适用:
            填充 HD 块和 FH 块的时间戳字段
        """
        return int(time.time_ns())

    def get_info(self) -> Dict[str, Any]:
        """
        获取写入器状态信息

        返回:
            包含文件路径、模式、记录数、字节数等信息的字典

        适用:
            监控和日志记录
        """
        return {
            "filepath": self.filepath,
            "version": self.config.version,
            "mode": self.mode.value,
            "is_open": self._is_open,
            "is_append": self.is_append,
            "channels_defined": self._channels_defined,
            "channel_count": len(self._channels),
            "record_size": self._record_size,
            "total_records": self._total_records_written,
            "total_bytes": self._total_bytes_written,
            "data_groups": len(self._dg_states),
            "compression": self.config.compression.name,
        }


__all__ = ["MDFWriter", "MDFWriterError", "MDFWriterModeError",
           "MDFWriterStateError", "MDFWriterValidationError"]
