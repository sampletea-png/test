# -*- coding: utf-8 -*-
"""
ASAM MDF 4.x 读写器综合测试模块

本测试模块对 MDF 读写器进行全面的功能验证，覆盖以下场景：
    1. 一般模式 (NORMAL): 标准 DT 块读写
    2. 分片模式 (FRAGMENTED): DL 块管理的分片数据读写
    3. 流式模式 (STREAMING): 实时流式写入和追加
    4. 连续数据 (CONTINUOUS): 固定采样率数据
    5. 间歇数据 (INTERMITTENT): 非固定采样数据
    6. 持久化与追加: 关闭后重新打开继续写入
    7. 压缩: DEFLATE 压缩/解压
    8. 通道转换: CC 块线性转换
    9. 多通道: 复杂记录布局
    10. 边界条件: 空文件、大数据量等

测试策略:
    - 每个测试用例独立运行，使用临时文件
    - 写入后立即读取验证数据完整性
    - 验证元数据（通道名、单位、转换参数）
    - 验证文件结构（DG/CG/CN 链表）

运行方式:
    python -m pytest test_mdf_rw.py -v
    python test_mdf_rw.py  # 直接运行使用 unittest

作者: AI Assistant
版本: 1.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import sys
import struct
import tempfile
import unittest
import logging
import time
import random
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

# 导入被测试模块
from mdf_config import (
    MDFConfig,
    OperationMode,
    CompressionAlgorithm,
    DataContinuity,
    ChannelDataType,
    ChannelType,
    SyncType,
    SUPPORTED_VERSIONS,
    get_numpy_dtype,
)
from mdf_blocks import (
    IDBlock, HDBlock, DGBlock, CGBlock, CNBlock,
    DTBlock, DLBlock, HLBlock, DZBlock,
    TXBlock, MDBlock, FHBlock, CCBlock,
    ChannelInfo, calculate_record_layout,
)
from mdf_writer import MDFWriter, MDFWriterError, MDFWriterStateError
from mdf_reader import (MDFReader, MDFReaderError, MDFReaderNotFoundError,
                         MDFReaderStateError, MDFReaderFormatError)

# 配置日志
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)


# =============================================================================
# 测试工具函数
# =============================================================================

def create_temp_filepath(suffix: str = ".mf4") -> str:
    """
    创建临时文件路径

    参数:
        suffix: 文件后缀

    返回:
        临时文件的绝对路径
    """
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    return path


def cleanup_file(filepath: str) -> None:
    """
    清理临时文件

    参数:
        filepath: 要删除的文件路径
    """
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception as e:
        logger.warning(f"清理文件失败: {filepath}, 错误: {e}")


def generate_test_data(num_records: int, channels: List[ChannelInfo],
                        record_size: int, offsets: List[int]) -> bytes:
    """
    生成测试数据

    参数:
        num_records: 记录数量
        channels: 通道定义列表
        record_size: 每条记录的字节大小
        offsets: 各通道字节偏移列表

    步骤:
        1. 创建记录缓冲区
        2. 为每条记录生成数据
        3. 按通道偏移写入值
        4. 返回所有记录字节

    返回:
        打包后的记录字节数据
    """
    records = bytearray(num_records * record_size)

    for rec_idx in range(num_records):
        base = rec_idx * record_size
        for ch_idx, ch in enumerate(channels):
            offset = offsets[ch_idx]
            abs_offset = base + offset

            # 生成测试值
            val = rec_idx * 10 + ch_idx  # 简单递增模式

            # 根据数据类型打包
            if ch.data_type in (ChannelDataType.UINT_LE, ChannelDataType.UINT_BE):
                fmt = "<I"
            elif ch.data_type in (ChannelDataType.SINT_LE, ChannelDataType.SINT_BE):
                fmt = "<i"
            elif ch.data_type in (ChannelDataType.FLOAT_LE, ChannelDataType.FLOAT_BE):
                fmt = "<f"
                val = float(val)
            else:
                fmt = "<I"

            byte_size = ch.bit_count // 8
            packed = struct.pack(fmt, val)[:byte_size]
            records[abs_offset:abs_offset + len(packed)] = packed

    return bytes(records)


# =============================================================================
# 基础块测试
# =============================================================================

class TestMDFBlocks(unittest.TestCase):
    """MDF 核心块数据结构测试"""

    def setUp(self):
        """测试前准备"""
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        """测试后清理"""
        cleanup_file(self.temp_file)

    def test_id_block_serialization(self):
        """
        测试 ID 块序列化与反序列化

        步骤:
            1. 创建 IDBlock
            2. 序列化为字节
            3. 写入临时文件
            4. 从文件反序列化
            5. 验证字段一致性
        """
        id_block = IDBlock(version=410)
        data = id_block.to_bytes()

        # 验证大小
        self.assertEqual(len(data), 64)

        # 写入并读取
        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            id_read = IDBlock.from_stream(f)

        self.assertEqual(id_read.file_id.strip(), "MDF")
        self.assertEqual(id_read.version, 410)
        self.assertEqual(id_read.get_version_string(), "4.10")

    def test_hd_block_serialization(self):
        """
        测试 HD 块序列化与反序列化

        步骤:
            1. 创建 HDBlock
            2. 序列化为字节
            3. 写入临时文件
            4. 从文件反序列化
            5. 验证链接和数据字段
        """
        hd = HDBlock(
            dg_first=0x100,
            fh_first=0x200,
            start_time_ns=1234567890,
            tz_offset_min=480,
        )
        data = hd.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            hd_read = HDBlock.from_stream(f, 0)

        self.assertEqual(hd_read.dg_first, 0x100)
        self.assertEqual(hd_read.fh_first, 0x200)
        self.assertEqual(hd_read.start_time_ns, 1234567890)
        self.assertEqual(hd_read.tz_offset_min, 480)

    def test_dg_block_serialization(self):
        """
        测试 DG 块序列化与反序列化

        步骤:
            1. 创建 DGBlock
            2. 序列化并反序列化
            3. 验证字段
        """
        dg = DGBlock(
            dg_next=0x300,
            cg_first=0x400,
            data_addr=0x500,
            record_id_size=1,
        )
        data = dg.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            dg_read = DGBlock.from_stream(f, 0)

        self.assertEqual(dg_read.dg_next, 0x300)
        self.assertEqual(dg_read.cg_first, 0x400)
        self.assertEqual(dg_read.data_addr, 0x500)
        self.assertEqual(dg_read.record_id_size, 1)

    def test_cg_block_serialization(self):
        """
        测试 CG 块序列化与反序列化

        步骤:
            1. 创建 CGBlock
            2. 序列化并反序列化
            3. 验证所有字段
        """
        cg = CGBlock(
            cg_next=0,
            cn_first=0x600,
            record_id=1,
            cycles_nr=1000,
            samples_byte_nr=16,
            inval_bytes_nr=0,
        )
        data = cg.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            cg_read = CGBlock.from_stream(f, 0)

        self.assertEqual(cg_read.cn_first, 0x600)
        self.assertEqual(cg_read.cycles_nr, 1000)
        self.assertEqual(cg_read.samples_byte_nr, 16)

    def test_cn_block_serialization(self):
        """
        测试 CN 块序列化与反序列化

        步骤:
            1. 创建 CNBlock
            2. 序列化并反序列化
            3. 验证所有字段
        """
        cn = CNBlock(
            cn_next=0,
            tx_name=0x700,
            channel_type=ChannelType.FIXED_LENGTH,
            sync_type=SyncType.TIME,
            data_type=ChannelDataType.FLOAT_LE,
            byte_offset=4,
            bit_count=32,
            bit_offset=0,
        )
        data = cn.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            cn_read = CNBlock.from_stream(f, 0)

        self.assertEqual(cn_read.tx_name, 0x700)
        self.assertEqual(cn_read.channel_type, ChannelType.FIXED_LENGTH)
        self.assertEqual(cn_read.data_type, ChannelDataType.FLOAT_LE)
        self.assertEqual(cn_read.byte_offset, 4)
        self.assertEqual(cn_read.bit_count, 32)

    def test_dt_block_serialization(self):
        """
        测试 DT 块序列化与反序列化

        步骤:
            1. 创建 DTBlock
            2. 序列化并反序列化
            3. 验证数据完整性
        """
        test_data = b"Hello, MDF World! " * 100
        dt = DTBlock(data=test_data)
        data = dt.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            dt_read = DTBlock.from_stream(f, 0)

        self.assertEqual(dt_read.data, test_data)

    def test_dl_block_serialization(self):
        """
        测试 DL 块序列化与反序列化

        步骤:
            1. 创建 DLBlock
            2. 序列化并反序列化
            3. 验证数据块地址列表
        """
        dl = DLBlock(
            dl_next=0,
            data_addrs=[0x1000, 0x2000, 0x3000],
            flags=0,
        )
        data = dl.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            dl_read = DLBlock.from_stream(f, 0)

        self.assertEqual(dl_read.data_addrs, [0x1000, 0x2000, 0x3000])
        self.assertEqual(dl_read.dl_next, 0)

    def test_dz_block_compression(self):
        """
        测试 DZ 块压缩与解压

        步骤:
            1. 创建原始数据
            2. 压缩为 DZ 块
            3. 序列化并反序列化
            4. 解压并验证数据完整性
        """
        original = b"Test data for compression " * 1000
        dz = DZBlock.compress(original, zip_type=0)

        data = dz.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            dz_read = DZBlock.from_stream(f, 0)

        decompressed = dz_read.decompress()
        self.assertEqual(decompressed, original)

    def test_tx_block_serialization(self):
        """
        测试 TX 块序列化与反序列化

        步骤:
            1. 创建 TXBlock
            2. 序列化并反序列化
            3. 验证文本内容
        """
        tx = TXBlock(text="Test Channel Name")
        data = tx.to_bytes()

        with open(self.temp_file, "wb") as f:
            f.write(data)

        with open(self.temp_file, "rb") as f:
            tx_read = TXBlock.from_stream(f, 0)

        self.assertEqual(tx_read.text, "Test Channel Name")

    def test_cc_block_linear_conversion(self):
        """
        测试 CC 块线性转换

        步骤:
            1. 创建线性转换 CC 块（y = 2x + 10）
            2. 应用转换
            3. 验证转换结果
        """
        cc = CCBlock(type=1, parameters=[2.0, 10.0])

        # 测试转换
        self.assertEqual(cc.apply(0), 10.0)
        self.assertEqual(cc.apply(5), 20.0)
        self.assertEqual(cc.apply(10), 30.0)


# =============================================================================
# 一般模式写入器测试
# =============================================================================

class TestMDFWriterNormal(unittest.TestCase):
    """一般模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_normal_mode_basic_write_read(self):
        """
        一般模式基本写入读取测试

        步骤:
            1. 创建一般模式写入器
            2. 定义 3 个通道
            3. 生成 100 条记录并写入
            4. 关闭写入器
            5. 打开读取器
            6. 加载结构
            7. 读取各通道数据
            8. 验证数据正确性
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        # 定义通道
        channels = [
            ChannelInfo(name="Speed", data_type=ChannelDataType.FLOAT_LE,
                        bit_count=32, unit="km/h"),
            ChannelInfo(name="RPM", data_type=ChannelDataType.UINT_LE,
                        bit_count=32, unit="rpm"),
            ChannelInfo(name="Temp", data_type=ChannelDataType.FLOAT_LE,
                        bit_count=32, unit="°C", conversion_a=0.1, conversion_b=-40),
        ]

        # 写入
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment,
                record_id_size=config.record_id_size)
            data = generate_test_data(100, channels, record_size, offsets)
            writer.write_records(data)

        # 读取
        with MDFReader(self.temp_file) as reader:
            reader.load_structure()

            # 验证通道名
            names = reader.get_channel_names()
            self.assertIn("Speed", names)
            self.assertIn("RPM", names)
            self.assertIn("Temp", names)

            # 读取数据
            speed_data = reader.read_channel("Speed")
            self.assertEqual(len(speed_data), 100)

            rpm_data = reader.read_channel("RPM")
            self.assertEqual(len(rpm_data), 100)

    def test_normal_mode_with_conversion(self):
        """
        一般模式通道转换测试

        步骤:
            1. 创建带转换的通道
            2. 写入数据
            3. 读取并验证转换结果
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        channels = [
            ChannelInfo(name="Voltage", data_type=ChannelDataType.FLOAT_LE,
                        bit_count=32, unit="V", conversion_a=0.001, conversion_b=0),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)
            data = generate_test_data(10, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()

            # 不应用转换（原始值）
            raw = reader.read_channel("Voltage", apply_conversion=False)
            # 应用转换
            converted = reader.read_channel("Voltage", apply_conversion=True)

            # 验证转换: converted = raw * 0.001 + 0
            for i in range(10):
                expected = raw[i] * 0.001
                self.assertAlmostEqual(converted[i], expected, places=5)

    def test_normal_mode_multiple_dg(self):
        """
        多数据组写入测试

        步骤:
            1. 写入第一组通道和记录
            2. 重新定义通道（创建新 DG）
            3. 写入新记录
            4. 验证两组数据独立
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        with MDFWriter(self.temp_file, config) as writer:
            # 第一组
            ch1 = [ChannelInfo(name="A1", data_type=ChannelDataType.FLOAT_LE, bit_count=32)]
            writer.define_channels(ch1)
            rs1, off1 = calculate_record_layout(ch1, alignment=config.alignment)
            data1 = generate_test_data(50, ch1, rs1, off1)
            writer.write_records(data1)

            # 第二组（不同通道）
            ch2 = [ChannelInfo(name="B1", data_type=ChannelDataType.UINT_LE, bit_count=32)]
            writer.define_channels(ch2)
            rs2, off2 = calculate_record_layout(ch2, alignment=config.alignment)
            data2 = generate_test_data(30, ch2, rs2, off2)
            writer.write_records(data2)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            self.assertEqual(reader.data_group_count, 2)


# =============================================================================
# 分片模式写入器测试
# =============================================================================

class TestMDFWriterFragmented(unittest.TestCase):
    """分片模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_fragmented_mode_basic(self):
        """
        分片模式基本测试

        步骤:
            1. 创建分片模式写入器（小分片大小）
            2. 写入大量数据（超过分片大小）
            3. 验证分片产生
            4. 读取并验证数据完整性
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256,  # 小分片以触发分片
        )

        channels = [
            ChannelInfo(name="Signal1", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
            ChannelInfo(name="Signal2", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)
            # 写入 1000 条记录（应触发多个分片）
            data = generate_test_data(1000, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            sig1 = reader.read_channel("Signal1")
            sig2 = reader.read_channel("Signal2")
            self.assertEqual(len(sig1), 1000)
            self.assertEqual(len(sig2), 1000)

    def test_fragmented_mode_with_compression(self):
        """
        分片模式压缩测试

        步骤:
            1. 创建带压缩的分片模式写入器
            2. 写入数据
            3. 验证压缩数据可正确解压读取
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=512,
            compression=CompressionAlgorithm.DEFLATE,
        )

        channels = [
            ChannelInfo(name="Data", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)
            data = generate_test_data(500, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            data = reader.read_channel("Data")
            self.assertEqual(len(data), 500)


# =============================================================================
# 流式模式写入器测试
# =============================================================================

class TestMDFWriterStreaming(unittest.TestCase):
    """流式模式写入器测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_streaming_mode_basic(self):
        """
        流式模式基本测试

        步骤:
            1. 创建流式模式写入器（小缓冲区）
            2. 分多次追加数据
            3. 验证所有数据写入
            4. 读取验证完整性
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=512,
        )

        channels = [
            ChannelInfo(name="Stream1", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
            ChannelInfo(name="Stream2", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)

            # 分 5 次追加数据
            for batch in range(5):
                data = generate_test_data(100, channels, record_size, offsets)
                writer.append_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            s1 = reader.read_channel("Stream1")
            s2 = reader.read_channel("Stream2")
            self.assertEqual(len(s1), 500)
            self.assertEqual(len(s2), 500)

    def test_streaming_continuous_append(self):
        """
        流式模式连续数据追加测试

        步骤:
            1. 定义通道
            2. 使用 append_continuous 逐条写入
            3. 验证数据完整性
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=256,
        )

        channels = [
            ChannelInfo(name="Counter", data_type=ChannelDataType.UINT_LE, bit_count=32),
            ChannelInfo(name="Value", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)

            # 逐条追加
            for i in range(50):
                samples = {
                    "Counter": i,
                    "Value": float(i) * 1.5,
                }
                writer.append_continuous(samples)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            counter = reader.read_channel("Counter")
            value = reader.read_channel("Value")
            self.assertEqual(len(counter), 50)
            self.assertEqual(counter[0], 0)
            self.assertEqual(counter[49], 49)

    def test_streaming_intermittent_append(self):
        """
        流式模式间歇数据追加测试

        步骤:
            1. 定义多个通道
            2. 使用 append_intermittent 分别写入各通道
            3. 验证数据
        """
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=256,
        )

        channels = [
            ChannelInfo(name="EventA", data_type=ChannelDataType.UINT_LE, bit_count=32),
            ChannelInfo(name="EventB", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)

            # 间歇写入（模拟事件触发）
            for i in range(20):
                writer.append_intermittent("EventA", float(i) * 0.1, i * 10)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            names = reader.get_channel_names()
            self.assertIn("EventA", names)


# =============================================================================
# 持久化追加测试
# =============================================================================

class TestMDFPersistence(unittest.TestCase):
    """持久化与追加测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_append_after_close(self):
        """
        关闭后追加数据测试

        步骤:
            1. 第一次打开，写入数据，关闭
            2. 第二次以追加模式打开
            3. 追加新数据
            4. 验证所有数据（旧+新）
        """
        config = MDFConfig(operation_mode=OperationMode.STREAMING)

        channels = [
            ChannelInfo(name="Data", data_type=ChannelDataType.UINT_LE, bit_count=32),
        ]

        # 第一次写入
        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)
            data = generate_test_data(50, channels, record_size, offsets)
            writer.write_records(data)

        # 追加模式写入（创建新 DG）
        with MDFWriter(self.temp_file, config, append=True) as writer:
            writer.define_channels(channels)
            data = generate_test_data(50, channels, record_size, offsets)
            writer.write_records(data)

        # 读取验证
        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            self.assertEqual(reader.data_group_count, 2)

    def test_multiple_append_cycles(self):
        """
        多次追加循环测试

        步骤:
            1. 循环 5 次：打开 -> 追加 -> 关闭
            2. 验证总数据量
        """
        config = MDFConfig(operation_mode=OperationMode.STREAMING)

        channels = [
            ChannelInfo(name="Cycle", data_type=ChannelDataType.UINT_LE, bit_count=32),
        ]

        for cycle in range(5):
            append = (cycle > 0)
            with MDFWriter(self.temp_file, config, append=append) as writer:
                writer.define_channels(channels)
                record_size, offsets = calculate_record_layout(
                    channels, alignment=config.alignment)
                data = generate_test_data(20, channels, record_size, offsets)
                writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            # 5 个 DG，每个 20 条记录
            self.assertEqual(reader.data_group_count, 5)


# =============================================================================
# 压缩测试
# =============================================================================

class TestMDFCompression(unittest.TestCase):
    """压缩功能测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_deflate_compression(self):
        """
        DEFLATE 压缩测试

        步骤:
            1. 创建带 DEFLATE 压缩的写入器
            2. 写入数据
            3. 读取并验证数据完整性
        """
        config = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionAlgorithm.DEFLATE,
        )

        channels = [
            ChannelInfo(name="Comp", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(
                channels, alignment=config.alignment)
            data = generate_test_data(200, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            data = reader.read_channel("Comp")
            self.assertEqual(len(data), 200)

    def test_compression_reduces_size(self):
        """
        压缩减小文件大小测试

        步骤:
            1. 创建压缩文件
            2. 创建未压缩文件（相同数据）
            3. 验证压缩文件更小
        """
        compressed_file = self.temp_file + ".compressed"
        uncompressed_file = self.temp_file + ".uncompressed"

        channels = [
            ChannelInfo(name="X", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        # 压缩写入
        config_comp = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionAlgorithm.DEFLATE,
        )
        with MDFWriter(compressed_file, config_comp) as w:
            w.define_channels(channels)
            rs, off = calculate_record_layout(channels)
            data = generate_test_data(1000, channels, rs, off)
            w.write_records(data)

        # 未压缩写入
        config_uncomp = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(uncompressed_file, config_uncomp) as w:
            w.define_channels(channels)
            rs, off = calculate_record_layout(channels)
            data = generate_test_data(1000, channels, rs, off)
            w.write_records(data)

        # 验证压缩文件更小
        comp_size = os.path.getsize(compressed_file)
        uncomp_size = os.path.getsize(uncompressed_file)
        self.assertLess(comp_size, uncomp_size,
                        f"压缩文件应更小: comp={comp_size}, uncomp={uncomp_size}")

        cleanup_file(compressed_file)
        cleanup_file(uncompressed_file)


# =============================================================================
# 边界条件和错误处理测试
# =============================================================================

class TestMDFEdgeCases(unittest.TestCase):
    """边界条件测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_empty_data_write(self):
        """
        空数据写入测试

        步骤:
            1. 定义通道
            2. 写入空数据
            3. 验证不报错
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        channels = [
            ChannelInfo(name="Empty", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            writer.write_records(b"")

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            names = reader.get_channel_names()
            self.assertIn("Empty", names)

    def test_single_record(self):
        """
        单条记录写入测试

        步骤:
            1. 定义通道
            2. 写入单条记录
            3. 验证读取
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        channels = [
            ChannelInfo(name="Single", data_type=ChannelDataType.UINT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(channels)
            data = generate_test_data(1, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            data = reader.read_channel("Single")
            self.assertEqual(len(data), 1)

    def test_large_data_write(self):
        """
        大数据量写入测试

        步骤:
            1. 定义通道
            2. 写入 10000 条记录
            3. 验证读取完整性
        """
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)

        channels = [
            ChannelInfo(name="Large", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(channels)
            data = generate_test_data(10000, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            data = reader.read_channel("Large")
            self.assertEqual(len(data), 10000)

    def test_reader_channel_not_found(self):
        """
        读取不存在的通道测试

        步骤:
            1. 创建文件
            2. 尝试读取不存在的通道
            3. 验证抛出异常
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels([
                ChannelInfo(name="A", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
            ])
            rs, off = calculate_record_layout(writer._channels)
            data = generate_test_data(10, writer._channels, rs, off)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            with self.assertRaises(MDFReaderNotFoundError):
                reader.read_channel("NonExistent")

    def test_structure_not_loaded(self):
        """
        结构未加载时读取测试

        步骤:
            1. 打开文件
            2. 不调用 load_structure
            3. 尝试读取通道
            4. 验证抛出异常
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels([
                ChannelInfo(name="A", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
            ])
            rs, off = calculate_record_layout(writer._channels)
            data = generate_test_data(10, writer._channels, rs, off)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            with self.assertRaises(MDFReaderStateError):
                reader.read_channel("A")


# =============================================================================
# 综合场景测试
# =============================================================================

class TestMDFIntegration(unittest.TestCase):
    """综合场景测试"""

    def setUp(self):
        self.temp_file = create_temp_filepath()

    def tearDown(self):
        cleanup_file(self.temp_file)

    def test_full_workflow_all_modes(self):
        """
        全模式工作流测试

        步骤:
            1. 对每种模式分别创建文件
            2. 写入多通道数据
            3. 读取并验证
            4. 比较三种模式的结果一致性
        """
        modes = [OperationMode.NORMAL, OperationMode.FRAGMENTED, OperationMode.STREAMING]
        results = {}

        for mode in modes:
            filepath = self.temp_file + f"_{mode.value}"
            config = MDFConfig(operation_mode=mode)

            channels = [
                ChannelInfo(name="Speed", data_type=ChannelDataType.FLOAT_LE,
                            bit_count=32, unit="km/h"),
                ChannelInfo(name="Torque", data_type=ChannelDataType.FLOAT_LE,
                            bit_count=32, unit="Nm"),
                ChannelInfo(name="Status", data_type=ChannelDataType.UINT_LE,
                            bit_count=16),
            ]

            # 写入
            with MDFWriter(filepath, config) as writer:
                writer.define_channels(channels)
                record_size, offsets = calculate_record_layout(
                    channels, alignment=config.alignment)
                data = generate_test_data(200, channels, record_size, offsets)
                writer.write_records(data)

            # 读取
            with MDFReader(filepath) as reader:
                reader.load_structure()
                speed = reader.read_channel("Speed")
                torque = reader.read_channel("Torque")
                status = reader.read_channel("Status")
                results[mode.value] = (speed, torque, status)

            cleanup_file(filepath)

        # 验证三种模式数据一致
        normal_speed = results[OperationMode.NORMAL.value][0]
        frag_speed = results[OperationMode.FRAGMENTED.value][0]
        stream_speed = results[OperationMode.STREAMING.value][0]

        self.assertEqual(len(normal_speed), len(frag_speed))
        self.assertEqual(len(normal_speed), len(stream_speed))

    def test_iterators(self):
        """
        迭代器接口测试

        步骤:
            1. 创建大文件
            2. 使用迭代器分块读取
            3. 验证所有数据被读取
        """
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)

        channels = [
            ChannelInfo(name="Iter", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(channels)
            data = generate_test_data(5000, channels, record_size, offsets)
            writer.write_records(data)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()

            total = 0
            for batch in reader.iter_channel("Iter", batch_size=500):
                total += len(batch)

            self.assertEqual(total, 5000)

    def test_file_info(self):
        """
        文件信息查询测试

        步骤:
            1. 创建文件
            2. 查询 writer info
            3. 查询 reader info
            4. 验证信息正确
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        channels = [
            ChannelInfo(name="Info1", data_type=ChannelDataType.FLOAT_LE, bit_count=32),
            ChannelInfo(name="Info2", data_type=ChannelDataType.UINT_LE, bit_count=32),
        ]

        with MDFWriter(self.temp_file, config) as writer:
            writer.define_channels(channels)
            record_size, offsets = calculate_record_layout(channels)
            data = generate_test_data(100, channels, record_size, offsets)
            writer.write_records(data)

            info = writer.get_info()
            self.assertEqual(info["version"], "4.10")
            self.assertEqual(info["channel_count"], 2)
            self.assertEqual(info["total_records"], 100)

        with MDFReader(self.temp_file) as reader:
            reader.load_structure()
            info = reader.get_file_info()
            self.assertEqual(info["version"], "4.10")
            self.assertEqual(info["channels"], 2)


# =============================================================================
# 配置测试
# =============================================================================

class TestMDFConfig(unittest.TestCase):
    """配置类测试"""

    def test_default_config(self):
        """
        默认配置测试

        步骤:
            1. 创建默认配置
            2. 验证默认值
        """
        config = MDFConfig()
        self.assertEqual(config.version, "4.10")
        self.assertEqual(config.operation_mode, OperationMode.NORMAL)
        self.assertEqual(config.compression, CompressionAlgorithm.NONE)
        self.assertFalse(config.use_record_id)

    def test_config_validation(self):
        """
        配置验证测试

        步骤:
            1. 测试无效版本
            2. 测试无效 record_id_size
            3. 测试压缩与版本不兼容
        """
        with self.assertRaises(ValueError):
            MDFConfig(version="9.99")

        with self.assertRaises(ValueError):
            MDFConfig(record_id_size=3)

    def test_config_serialization(self):
        """
        配置序列化测试

        步骤:
            1. 创建配置
            2. 转换为字典
            3. 从字典恢复
            4. 验证一致性
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            compression=CompressionAlgorithm.DEFLATE,
            fragment_size=1024,
        )

        d = config.to_dict()
        self.assertEqual(d["operation_mode"], "fragmented")
        self.assertEqual(d["fragment_size"], 1024)

        restored = MDFConfig.from_dict(d)
        self.assertEqual(restored.operation_mode, OperationMode.FRAGMENTED)
        self.assertEqual(restored.fragment_size, 1024)


# =============================================================================
# 主入口
# =============================================================================

def run_tests():
    """
    运行所有测试

    步骤:
        1. 创建测试套件
        2. 加载所有测试类
        3. 运行测试
        4. 输出结果摘要
    """
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # 加载测试类
    test_classes = [
        TestMDFBlocks,
        TestMDFWriterNormal,
        TestMDFWriterFragmented,
        TestMDFWriterStreaming,
        TestMDFPersistence,
        TestMDFCompression,
        TestMDFEdgeCases,
        TestMDFIntegration,
        TestMDFConfig,
    ]

    for test_class in test_classes:
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)

    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # 输出摘要
    print("\n" + "=" * 70)
    print("测试摘要")
    print("=" * 70)
    print(f"总测试数: {result.testsRun}")
    print(f"通过: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")

    if result.wasSuccessful():
        print("\n所有测试通过!")
    else:
        print("\n存在失败的测试!")

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
