# -*- coding: utf-8 -*-
"""
ASAM MDF 4.x 文件读取器模块

本模块实现了 MDF 文件的读取功能，支持三种操作模式的数据读取：
    1. 一般模式 (NORMAL): 读取完整 DT 块
    2. 分片模式 (FRAGMENTED): 通过 DL/HL 块遍历分片数据
    3. 流式模式 (STREAMING): 支持增量读取和流式处理

特性:
    - 支持间歇 (INTERMITTENT) 和连续 (CONTINUOUS) 数据读取
    - 支持 DEFLATE 压缩数据的透明解压
    - 支持 sorted 和 unsorted 数据布局
    - 支持按通道名称快速访问
    - 支持记录范围选择和随机访问
    - 内存高效的迭代器接口

线程安全:
    本模块的读取操作非线程安全。如需多线程使用，请在外部加锁。

作者: AI Assistant
版本: 1.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import os
import struct
import io
import zlib
import logging
from typing import Optional, Dict, List, Any, Tuple, BinaryIO, Union, Iterator, Callable
from dataclasses import dataclass, field
from datetime import datetime

from mdf_config import (
    # 块类型
    BLOCK_ID_ID, BLOCK_ID_HD, BLOCK_ID_DG, BLOCK_ID_CG, BLOCK_ID_CN,
    BLOCK_ID_DT, BLOCK_ID_DL, BLOCK_ID_DZ, BLOCK_ID_HL,
    BLOCK_ID_TX, BLOCK_ID_MD, BLOCK_ID_FH, BLOCK_ID_CC,
    # 常量
    ID_BLOCK_SIZE, COMMON_BLOCK_HEADER_SIZE, LINK_SIZE,
    RECORD_ID_SIZE_NONE, RECORD_ID_SIZE_1, RECORD_ID_SIZE_2,
    RECORD_ID_SIZE_4, RECORD_ID_SIZE_8,
    FLAG_CG_NONE, FLAG_DG_NONE, FLAG_CN_NONE, FLAG_DL_NONE,
    FLAG_DZ_DEFLATE, FLAG_DZ_TRANSPOSED_DEFLATE,
    FLAG_CG_VLSD,
    # 枚举
    ChannelDataType, ChannelType, SyncType,
    CompressionAlgorithm, OperationMode, DataContinuity,
    MDFConfig, get_numpy_dtype,
)
from mdf_blocks import (
    IDBlock, HDBlock, DGBlock, CGBlock, CNBlock,
    DTBlock, DLBlock, HLBlock, DZBlock,
    TXBlock, MDBlock, FHBlock, CCBlock,
    ChannelInfo, calculate_record_layout,
)

# 配置日志
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类
# =============================================================================

class MDFReaderError(Exception):
    """MDF 读取器基础异常"""
    pass


class MDFReaderFormatError(MDFReaderError):
    """文件格式错误异常"""
    pass


class MDFReaderNotFoundError(MDFReaderError):
    """通道或数据未找到异常"""
    pass


class MDFReaderStateError(MDFReaderError):
    """状态错误异常"""
    pass


# =============================================================================
# 内部数据结构
# =============================================================================

@dataclass
class _ChannelMetadata:
    """
    通道元数据（内部使用）

    存储从 CN 块解析出的通道完整元数据，
    用于数据解析和转换。
    """
    name: str = ""                      # 通道名称
    data_type: int = 0                  # 数据类型
    bit_count: int = 0                  # 位宽
    byte_offset: int = 0                # 字节偏移
    bit_offset: int = 0                 # 位偏移
    record_size: int = 0                # 记录大小
    channel_type: int = 0               # 通道类型
    sync_type: int = 0                  # 同步类型
    unit: str = ""                      # 单位
    comment: str = ""                   # 注释
    conversion_a: float = 1.0           # 转换系数 a
    conversion_b: float = 0.0           # 转换偏移 b
    has_conversion: bool = False        # 是否有转换公式


@dataclass
class _DGMetadata:
    """
    数据组元数据（内部使用）

    存储单个 DG 的完整结构信息，包括所有通道和记录布局。
    """
    dg_addr: int = 0                    # DG 块地址
    cg_addr: int = 0                    # CG 块地址
    data_addr: int = 0                  # 数据块地址
    record_size: int = 0                # 记录大小
    cycles_nr: int = 0                  # 记录总数
    record_id_size: int = 0             # record ID 字节数
    flags: int = 0                      # DG 标志
    channels: List[_ChannelMetadata] = field(default_factory=list)  # 通道列表


# =============================================================================
# MDF 读取器主类
# =============================================================================

class MDFReader:
    """
    ASAM MDF 4.x 文件读取器

    提供 MDF 文件的完整读取功能，支持三种操作模式的数据：

    1. 一般模式数据: 读取完整 DT 块
    2. 分片模式数据: 通过 DL/HL 块透明读取分片数据
    3. 流式模式数据: 支持增量读取

    核心功能:
        - 文件结构解析（ID -> HD -> DG -> CG -> CN -> DT/DL/HL/DZ）
        - 通道数据提取（按名称或索引）
        - 压缩数据透明解压
        - 原始值到物理值的转换（应用 CC 块）
        - 记录范围选择和迭代器接口

    使用示例:
        # 基本读取
        reader = MDFReader("input.mf4")
        reader.load_structure()

        # 获取通道列表
        channels = reader.get_channel_names()

        # 读取通道数据
        data = reader.read_channel("Speed")

        # 读取多条记录
        records = reader.read_records(0, 100)  # 读取前 100 条

        # 迭代器接口
        for record in reader.iter_records():
            process(record)

        reader.close()

        # 上下文管理器
        with MDFReader("input.mf4") as reader:
            data = reader.read_channel("Temperature")

    属性:
        filepath: MDF 文件路径
        is_open: 文件是否处于打开状态
        structure_loaded: 结构是否已加载
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 读取器

        参数:
            filepath: MDF 文件路径
            config: MDFConfig 配置对象，None 时使用默认配置

        步骤:
            1. 保存配置参数
            2. 以二进制读模式打开文件
            3. 读取并验证 ID 块
            4. 初始化内部状态

        异常:
            FileNotFoundError: 文件不存在
            MDFReaderFormatError: 文件格式无效
        """
        self.config: MDFConfig = config or MDFConfig()
        self.filepath: str = filepath

        # 文件句柄
        self._file: Optional[BinaryIO] = None

        # 内部状态
        self._is_open: bool = False
        self._structure_loaded: bool = False
        self._id_block: Optional[IDBlock] = None
        self._header: Optional[HDBlock] = None
        self._dg_metadata: List[_DGMetadata] = []
        self._channel_map: Dict[str, Tuple[int, int]] = {}  # name -> (dg_idx, ch_idx)

        # 缓存
        self._data_cache: Dict[int, bytes] = {}
        self._cache_size: int = 0
        self._max_cache_size: int = self.config.cache_size

        # 打开文件
        self._open_file()

    # ======================================================================
    # 属性访问
    # ======================================================================

    @property
    def is_open(self) -> bool:
        """文件是否处于打开状态"""
        return self._is_open

    @property
    def structure_loaded(self) -> bool:
        """结构是否已加载"""
        return self._structure_loaded

    @property
    def version(self) -> str:
        """MDF 文件版本字符串"""
        if self._id_block:
            return self._id_block.get_version_string()
        return ""

    @property
    def data_group_count(self) -> int:
        """数据组数量"""
        return len(self._dg_metadata)

    @property
    def channel_count(self) -> int:
        """总通道数量"""
        return sum(len(dg.channels) for dg in self._dg_metadata)

    # ======================================================================
    # 文件打开
    # ======================================================================

    def _open_file(self) -> None:
        """
        打开 MDF 文件

        步骤:
            1. 验证文件存在
            2. 以二进制读模式打开
            3. 读取并验证 ID 块

        异常:
            FileNotFoundError: 文件不存在
            MDFReaderFormatError: 不是有效的 MDF 文件
        """
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"MDF 文件不存在: {self.filepath}")

        # 步骤 2: 打开文件
        self._file = open(self.filepath, "rb")

        # 步骤 3: 读取 ID 块
        try:
            self._id_block = IDBlock.from_stream(self._file)
        except Exception as e:
            raise MDFReaderFormatError(f"无效的 MDF 文件: {e}")

        # 验证文件标识（去除填充空格）
        if self._id_block.file_id.strip() != "MDF":
            raise MDFReaderFormatError(f"无效的文件标识: {self._id_block.file_id}")

        self._is_open = True
        logger.info(f"MDF 文件已打开: {self.filepath}, 版本: {self.version}")

    # ======================================================================
    # 结构加载
    # ======================================================================

    def load_structure(self) -> None:
        """
        加载完整文件结构

        步骤:
            1. 验证文件已打开
            2. 读取 HD 块
            3. 遍历 DG 链表，读取每个 DG
            4. 遍历 CG 链表，读取每个 CG
            5. 遍历 CN 链表，读取每个 CN 及其关联块（TX, CC, SI）
            6. 构建通道映射表
            7. 标记结构已加载

        异常:
            MDFReaderStateError: 文件未打开
            MDFReaderFormatError: 文件结构损坏

        适用:
            读取数据前必须先调用此方法加载文件结构
        """
        if not self._is_open:
            raise MDFReaderStateError("文件未打开")

        logger.info("加载文件结构...")

        # 步骤 2: 读取 HD 块
        self._header = HDBlock.from_stream(self._file, ID_BLOCK_SIZE)

        # 步骤 3: 遍历 DG 链表
        dg_addr = self._header.dg_first
        while dg_addr != 0:
            try:
                dg_meta = self._load_dg(dg_addr)
                self._dg_metadata.append(dg_meta)

                # 读取下一个 DG
                self._file.seek(dg_addr)
                header_raw = self._file.read(COMMON_BLOCK_HEADER_SIZE)
                block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)
                if links_nr > 0:
                    next_raw = self._file.read(LINK_SIZE)
                    dg_addr = struct.unpack("<Q", next_raw)[0]
                else:
                    dg_addr = 0
            except Exception as e:
                logger.error(f"加载 DG @0x{dg_addr:X} 失败: {e}")
                break

        # 步骤 6: 构建通道映射
        self._build_channel_map()

        self._structure_loaded = True
        logger.info(f"结构加载完成: {len(self._dg_metadata)} 个 DG, "
                     f"{self.channel_count} 个通道")

    def _load_dg(self, dg_addr: int) -> _DGMetadata:
        """
        加载单个数据组

        参数:
            dg_addr: DG 块地址

        步骤:
            1. 读取 DG 块
            2. 读取关联的 CG 块
            3. 读取所有 CN 块
            4. 构建 _DGMetadata

        返回:
            _DGMetadata 实例
        """
        # 步骤 1: 读取 DG
        dg = DGBlock.from_stream(self._file, dg_addr)

        # 步骤 2: 读取 CG
        cg = CGBlock.from_stream(self._file, dg.cg_first)

        # 步骤 3: 读取所有 CN
        channels = []
        cn_addr = cg.cn_first
        while cn_addr != 0:
            try:
                ch_meta = self._load_channel(cn_addr, cg.samples_byte_nr)
                channels.append(ch_meta)

                # 下一个 CN
                self._file.seek(cn_addr)
                header_raw = self._file.read(COMMON_BLOCK_HEADER_SIZE)
                block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)
                if links_nr > 0:
                    next_raw = self._file.read(LINK_SIZE)
                    cn_addr = struct.unpack("<Q", next_raw)[0]
                else:
                    cn_addr = 0
            except Exception as e:
                logger.error(f"加载 CN @0x{cn_addr:X} 失败: {e}")
                break

        return _DGMetadata(
            dg_addr=dg_addr,
            cg_addr=dg.cg_first,
            data_addr=dg.data_addr,
            record_size=cg.samples_byte_nr + cg.inval_bytes_nr,
            cycles_nr=cg.cycles_nr,
            record_id_size=dg.record_id_size,
            flags=dg.flags,
            channels=channels,
        )

    def _load_channel(self, cn_addr: int, record_size: int) -> _ChannelMetadata:
        """
        加载单个通道

        参数:
            cn_addr: CN 块地址
            record_size: 记录大小

        步骤:
            1. 读取 CN 块
            2. 读取通道名称 TX 块
            3. 读取转换 CC 块（如果有）
            4. 构建 _ChannelMetadata

        返回:
            _ChannelMetadata 实例
        """
        # 步骤 1: 读取 CN
        cn = CNBlock.from_stream(self._file, cn_addr)

        # 步骤 2: 读取通道名称
        name = ""
        if cn.tx_name != 0:
            try:
                tx = TXBlock.from_stream(self._file, cn.tx_name)
                name = tx.text
            except Exception as e:
                logger.warning(f"读取通道名称 TX @0x{cn.tx_name:X} 失败: {e}")

        # 读取单位
        unit = ""
        if cn.md_unit != 0:
            try:
                tx_unit = TXBlock.from_stream(self._file, cn.md_unit)
                unit = tx_unit.text
            except Exception:
                pass

        # 步骤 3: 读取转换
        conversion_a, conversion_b = 1.0, 0.0
        has_conversion = False
        if cn.cc_conversion != 0:
            try:
                cc = CCBlock.from_stream(self._file, cn.cc_conversion)
                if cc.type == 1 and len(cc.parameters) >= 2:
                    conversion_a = cc.parameters[0]
                    conversion_b = cc.parameters[1]
                    has_conversion = True
            except Exception as e:
                logger.warning(f"读取转换 CC @0x{cn.cc_conversion:X} 失败: {e}")

        return _ChannelMetadata(
            name=name,
            data_type=cn.data_type,
            bit_count=cn.bit_count,
            byte_offset=cn.byte_offset,
            bit_offset=cn.bit_offset,
            record_size=record_size,
            channel_type=cn.channel_type,
            sync_type=cn.sync_type,
            unit=unit,
            comment="",
            conversion_a=conversion_a,
            conversion_b=conversion_b,
            has_conversion=has_conversion,
        )

    def _build_channel_map(self) -> None:
        """
        构建通道名称到 (dg_idx, ch_idx) 的映射表

        步骤:
            1. 遍历所有 DG
            2. 遍历每个 DG 的所有通道
            3. 将通道名映射到 (dg_idx, ch_idx)
        """
        self._channel_map = {}
        for dg_idx, dg in enumerate(self._dg_metadata):
            for ch_idx, ch in enumerate(dg.channels):
                if ch.name:
                    self._channel_map[ch.name] = (dg_idx, ch_idx)

    # ======================================================================
    # 数据读取
    # ======================================================================

    def read_channel(self, channel_name: str, start: int = 0,
                      count: Optional[int] = None,
                      apply_conversion: bool = True) -> List[Any]:
        """
        读取指定通道的数据

        参数:
            channel_name: 通道名称
            start: 起始记录索引（从 0 开始）
            count: 读取记录数，None 表示读取所有
            apply_conversion: 是否应用转换公式

        返回:
            通道值列表

        步骤:
            1. 查找通道位置 (dg_idx, ch_idx)
            2. 获取通道元数据
            3. 读取原始数据字节
            4. 解析原始值为数值
            5. 如果需要，应用转换公式

        异常:
            MDFReaderNotFoundError: 通道不存在
            MDFReaderStateError: 结构未加载

        适用:
            按通道名称提取数据，是最常用的读取接口
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载，请先调用 load_structure()")

        # 步骤 1: 查找通道
        if channel_name not in self._channel_map:
            raise MDFReaderNotFoundError(f"通道不存在: {channel_name}")

        dg_idx, ch_idx = self._channel_map[channel_name]
        dg = self._dg_metadata[dg_idx]
        ch = dg.channels[ch_idx]

        # 步骤 2-3: 读取原始数据
        raw_data = self._read_raw_data(dg_idx, start, count)

        # 步骤 4: 解析原始值
        values = self._parse_channel_data(raw_data, ch, dg)

        # 步骤 5: 应用转换
        if apply_conversion and ch.has_conversion:
            values = [ch.conversion_a * v + ch.conversion_b for v in values]

        return values

    def read_records(self, start: int = 0, count: Optional[int] = None) -> bytes:
        """
        读取原始记录字节

        参数:
            start: 起始记录索引
            count: 读取记录数

        返回:
            原始记录字节数据

        适用:
            需要原始字节进行自定义解析的场景
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载")

        if self._dg_metadata:
            return self._read_raw_data(0, start, count)
        return b""

    def _read_raw_data(self, dg_idx: int, start: int = 0,
                        count: Optional[int] = None) -> bytes:
        """
        读取指定数据组的原始数据字节

        参数:
            dg_idx: 数据组索引
            start: 起始记录索引
            count: 记录数

        步骤:
            1. 获取 DG 元数据
            2. 计算字节范围
            3. 判断数据存储类型（DT/DL/HL/DZ）
            4. 读取并解压数据
            5. 截取请求的范围

        返回:
            请求范围内的原始数据字节
        """
        dg = self._dg_metadata[dg_idx]

        # 确定读取范围
        total_records = dg.cycles_nr
        if count is None:
            count = total_records - start
        count = min(count, total_records - start)

        if count <= 0:
            return b""

        start_byte = start * dg.record_size
        read_bytes = count * dg.record_size

        # 判断数据存储类型并读取
        data = self._read_data_at_address(dg.data_addr)

        return data[start_byte:start_byte + read_bytes]

    def _read_data_at_address(self, addr: int) -> bytes:
        """
        从指定地址读取数据（自动识别块类型）

        参数:
            addr: 数据块地址

        步骤:
            1. 读取块头 4 字节，识别块类型
            2. 根据类型调用对应解析器
            3. 如果是压缩块，解压后返回
            4. 如果是 DL 块，递归读取所有数据
            5. 如果是 HL 块，读取关联的 DL 链

        返回:
            解压/合并后的原始数据字节
        """
        if addr == 0:
            return b""

        # 检查缓存
        if addr in self._data_cache:
            return self._data_cache[addr]

        # 步骤 1: 识别块类型
        self._file.seek(addr)
        block_id = self._file.read(4)

        # 步骤 2-5: 根据类型处理
        if block_id == BLOCK_ID_DT:
            dt = DTBlock.from_stream(self._file, addr)
            result = dt.data
        elif block_id == BLOCK_ID_DZ:
            dz = DZBlock.from_stream(self._file, addr)
            result = dz.decompress()
        elif block_id == BLOCK_ID_DL:
            result = self._read_dl_data(addr)
        elif block_id == BLOCK_ID_HL:
            result = self._read_hl_data(addr)
        else:
            logger.warning(f"未知数据块类型: {block_id} @0x{addr:X}")
            result = b""

        # 缓存结果
        self._cache_data(addr, result)

        return result

    def _read_dl_data(self, dl_addr: int) -> bytes:
        """
        读取 DL 块管理的所有数据

        参数:
            dl_addr: DL 块地址

        步骤:
            1. 读取 DL 块
            2. 遍历所有数据块地址
            3. 递归读取每个数据块
            4. 合并所有数据

        返回:
            合并后的完整数据字节
        """
        parts = []
        current_dl = dl_addr

        while current_dl != 0:
            dl = DLBlock.from_stream(self._file, current_dl)

            for dt_addr in dl.data_addrs:
                if dt_addr != 0:
                    parts.append(self._read_data_at_address(dt_addr))

            current_dl = dl.dl_next

        return b"".join(parts)

    def _read_hl_data(self, hl_addr: int) -> bytes:
        """
        读取 HL 块管理的压缩数据

        参数:
            hl_addr: HL 块地址

        步骤:
            1. 读取 HL 块
            2. 读取关联的 DL 链
            3. 合并所有数据

        返回:
            解压合并后的完整数据字节
        """
        hl = HLBlock.from_stream(self._file, hl_addr)
        if hl.dl_first != 0:
            return self._read_dl_data(hl.dl_first)
        return b""

    def _parse_channel_data(self, raw_data: bytes,
                            ch: _ChannelMetadata,
                            dg: _DGMetadata) -> List[Any]:
        """
        从原始数据中解析指定通道的值

        参数:
            raw_data: 原始记录字节数据
            ch: 通道元数据
            dg: 数据组元数据

        步骤:
            1. 确定每个记录中该通道的字节范围
            2. 按记录步长提取字节
            3. 根据数据类型解析为数值

        返回:
            通道值列表
        """
        values = []
        record_size = dg.record_size

        if record_size == 0:
            return values

        # 计算字节大小
        byte_size = ch.bit_count // 8
        if byte_size == 0:
            byte_size = 1

        for i in range(0, len(raw_data), record_size):
            if i + ch.byte_offset + byte_size > len(raw_data):
                break

            chunk = raw_data[i + ch.byte_offset:i + ch.byte_offset + byte_size]

            try:
                value = self._unpack_value(chunk, ch.data_type, ch.bit_count)
                values.append(value)
            except Exception as e:
                logger.warning(f"解析通道 {ch.name} 数据失败: {e}")
                values.append(0)

        return values

    def _unpack_value(self, data: bytes, data_type: int, bit_count: int) -> Union[int, float]:
        """
        将字节数据解包为数值

        参数:
            data: 字节数据
            data_type: 数据类型
            bit_count: 位宽

        返回:
            解析后的数值（int 或 float）
        """
        byte_count = bit_count // 8
        if byte_count == 0:
            byte_count = 1

        if data_type in (ChannelDataType.UINT_LE, ChannelDataType.UINT_BE):
            if byte_count == 1:
                return struct.unpack("B", data[:1])[0]
            elif byte_count == 2:
                return struct.unpack("<H", data[:2])[0]
            elif byte_count == 4:
                return struct.unpack("<I", data[:4])[0]
            elif byte_count == 8:
                return struct.unpack("<Q", data[:8])[0]
        elif data_type in (ChannelDataType.SINT_LE, ChannelDataType.SINT_BE):
            if byte_count == 1:
                return struct.unpack("b", data[:1])[0]
            elif byte_count == 2:
                return struct.unpack("<h", data[:2])[0]
            elif byte_count == 4:
                return struct.unpack("<i", data[:4])[0]
            elif byte_count == 8:
                return struct.unpack("<q", data[:8])[0]
        elif data_type in (ChannelDataType.FLOAT_LE, ChannelDataType.FLOAT_BE):
            if byte_count == 4:
                return struct.unpack("<f", data[:4])[0]
            elif byte_count == 8:
                return struct.unpack("<d", data[:8])[0]

        # 默认返回整数值
        if len(data) <= 8:
            return int.from_bytes(data, "little")
        return 0

    # ======================================================================
    # 迭代器接口
    # ======================================================================

    def iter_records(self, batch_size: int = 1000) -> Iterator[bytes]:
        """
        迭代读取记录（内存高效）

        参数:
            batch_size: 每次读取的记录数

        步骤:
            1. 计算总记录数
            2. 按 batch_size 分块读取
            3. 逐块 yield

        适用:
            大文件处理，避免一次性加载所有数据到内存
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载")

        if not self._dg_metadata:
            return

        dg = self._dg_metadata[0]
        total = dg.cycles_nr
        start = 0

        while start < total:
            count = min(batch_size, total - start)
            data = self._read_raw_data(0, start, count)
            yield data
            start += count

    def iter_channel(self, channel_name: str, batch_size: int = 1000,
                      apply_conversion: bool = True) -> Iterator[List[Any]]:
        """
        迭代读取通道数据（内存高效）

        参数:
            channel_name: 通道名称
            batch_size: 每次读取的记录数
            apply_conversion: 是否应用转换

        步骤:
            1. 查找通道
            2. 按 batch_size 分块读取
            3. 逐块解析并 yield

        适用:
            大文件通道数据处理
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载")

        if channel_name not in self._channel_map:
            raise MDFReaderNotFoundError(f"通道不存在: {channel_name}")

        dg_idx, ch_idx = self._channel_map[channel_name]
        dg = self._dg_metadata[dg_idx]
        ch = dg.channels[ch_idx]
        total = dg.cycles_nr
        start = 0

        while start < total:
            count = min(batch_size, total - start)
            raw_data = self._read_raw_data(dg_idx, start, count)
            values = self._parse_channel_data(raw_data, ch, dg)
            if apply_conversion and ch.has_conversion:
                values = [ch.conversion_a * v + ch.conversion_b for v in values]
            yield values
            start += count

    # ======================================================================
    # 缓存管理
    # ======================================================================

    def _cache_data(self, addr: int, data: bytes) -> None:
        """
        缓存读取的数据

        参数:
            addr: 数据块地址（作为缓存键）
            data: 数据字节

        步骤:
            1. 检查缓存大小是否超过限制
            2. 如果超过，清空部分缓存
            3. 存储新数据
        """
        data_size = len(data)

        # 如果数据太大，不缓存
        if data_size > self._max_cache_size // 4:
            return

        # 检查空间
        while self._cache_size + data_size > self._max_cache_size and self._data_cache:
            # 移除最早的缓存项
            oldest = next(iter(self._data_cache))
            self._cache_size -= len(self._data_cache[oldest])
            del self._data_cache[oldest]

        self._data_cache[addr] = data
        self._cache_size += data_size

    def clear_cache(self) -> None:
        """清空数据缓存"""
        self._data_cache.clear()
        self._cache_size = 0

    # ======================================================================
    # 信息查询
    # ======================================================================

    def get_channel_names(self) -> List[str]:
        """
        获取所有通道名称

        返回:
            通道名称列表

        适用:
            探索文件内容，了解可用通道
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载")
        return list(self._channel_map.keys())

    def get_channel_info(self, channel_name: str) -> Dict[str, Any]:
        """
        获取通道详细信息

        参数:
            channel_name: 通道名称

        返回:
            通道信息字典，包含名称、类型、单位、转换参数等

        适用:
            了解通道的元数据信息
        """
        if not self._structure_loaded:
            raise MDFReaderStateError("结构未加载")

        if channel_name not in self._channel_map:
            raise MDFReaderNotFoundError(f"通道不存在: {channel_name}")

        dg_idx, ch_idx = self._channel_map[channel_name]
        ch = self._dg_metadata[dg_idx].channels[ch_idx]

        return {
            "name": ch.name,
            "data_type": ch.data_type,
            "bit_count": ch.bit_count,
            "byte_offset": ch.byte_offset,
            "unit": ch.unit,
            "channel_type": ch.channel_type,
            "sync_type": ch.sync_type,
            "conversion_a": ch.conversion_a,
            "conversion_b": ch.conversion_b,
            "has_conversion": ch.has_conversion,
        }

    def get_file_info(self) -> Dict[str, Any]:
        """
        获取文件信息

        返回:
            文件信息字典，包含版本、DG 数量、通道数等
        """
        info = {
            "filepath": self.filepath,
            "version": self.version,
            "data_groups": self.data_group_count,
            "channels": self.channel_count,
            "is_open": self._is_open,
            "structure_loaded": self._structure_loaded,
        }

        if self._structure_loaded:
            for i, dg in enumerate(self._dg_metadata):
                info[f"dg_{i}_records"] = dg.cycles_nr
                info[f"dg_{i}_record_size"] = dg.record_size
                info[f"dg_{i}_channels"] = [ch.name for ch in dg.channels]

        return info

    # ======================================================================
    # 关闭与资源释放
    # ======================================================================

    def close(self) -> None:
        """
        关闭读取器并释放资源

        步骤:
            1. 清空缓存
            2. 关闭文件句柄
            3. 重置状态
        """
        if not self._is_open:
            return

        logger.info("关闭 MDF 读取器...")

        # 清空缓存
        self.clear_cache()

        # 关闭文件
        if self._file:
            self._file.close()
            self._file = None

        self._is_open = False
        logger.info("读取器已关闭")

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False


__all__ = ["MDFReader", "MDFReaderError", "MDFReaderFormatError",
           "MDFReaderNotFoundError", "MDFReaderStateError"]
