# -*- coding: utf-8 -*-
"""
ASAM MDF 4.x 核心块数据结构模块

本模块实现了 MDF 文件格式中所有核心二进制块的内存表示，
包括序列化（打包为字节）和反序列化（从字节解析）功能。

每个块类均遵循 MDF 4.x 规范的三段式结构：
    1. Header Section: 块类型标识、块长度、链接数量
    2. Link Section: 指向其他块的 64 位绝对地址
    3. Data Section: 块的具体数据内容

所有块均支持：
    - 从内存数据结构打包为二进制字节（to_bytes）
    - 从文件流解析为内存数据结构（from_stream）
    - 地址偏移计算和链接解析

作者: AI Assistant
版本: 1.0.0
日期: 2026-04-22
"""

from __future__ import annotations

import struct
import io
import zlib
import logging
from typing import Optional, Dict, List, Any, Tuple, BinaryIO, Union
from dataclasses import dataclass, field

# 导入配置模块的常量和类型
from mdf_config import (
    # 块类型标识
    BLOCK_ID_ID, BLOCK_ID_HD, BLOCK_ID_MD, BLOCK_ID_TX, BLOCK_ID_FH,
    BLOCK_ID_DG, BLOCK_ID_CG, BLOCK_ID_SI, BLOCK_ID_CN, BLOCK_ID_CC,
    BLOCK_ID_CA, BLOCK_ID_DT, BLOCK_ID_SR, BLOCK_ID_RD, BLOCK_ID_SD,
    BLOCK_ID_DL, BLOCK_ID_DZ, BLOCK_ID_HL, BLOCK_ID_AT, BLOCK_ID_EV, BLOCK_ID_CH,
    # 大小常量
    ID_BLOCK_SIZE, COMMON_BLOCK_HEADER_SIZE, LINK_SIZE,
    RECORD_ID_SIZE_NONE, RECORD_ID_SIZE_1, RECORD_ID_SIZE_2,
    RECORD_ID_SIZE_4, RECORD_ID_SIZE_8,
    # 标志位
    FLAG_CG_NONE, FLAG_DG_NONE, FLAG_CN_NONE, FLAG_DL_NONE,
    FLAG_DZ_DEFLATE, FLAG_DZ_TRANSPOSED_DEFLATE,
    FLAG_ID_UNFINALIZED_DT,
    # 枚举类型
    ChannelDataType, ChannelType, SyncType, CompressionAlgorithm,
    OperationMode, DataContinuity,
    # 辅助函数
    get_numpy_dtype,
)

# 配置日志记录
logger = logging.getLogger(__name__)


# =============================================================================
# 基础块类 (Base Block Class)
# =============================================================================

class MDFBlock:
    """
    MDF 块基类

    所有具体块类型的抽象基类，定义了块的通用接口：
    - 二进制序列化（to_bytes）
    - 从流反序列化（from_stream）
    - 块大小计算

    子类必须实现：
        _pack_data(): 将 Data Section 打包为字节
        _unpack_data(): 从字节解析 Data Section
        _get_links(): 获取 Link Section 的所有链接地址列表
        _set_links(): 设置 Link Section 的所有链接地址

    属性:
        block_type: 4 字节块类型标识（如 b'##HD'）
        block_len: 块总长度（字节），包含 Header + Links + Data
        links_nr: Link Section 中链接的数量
        links: Link Section 的链接地址列表（64 位绝对地址）
        address: 块在文件中的绝对地址（反序列化后填充）
    """

    # 子类必须覆盖的块类型标识
    BLOCK_TYPE: bytes = b"####"

    def __init__(self):
        """
        初始化块基类

        步骤:
            1. 设置块类型标识（从子类 BLOCK_TYPE 获取）
            2. 初始化块长度为通用头大小（仅 Header，无 Links 和 Data）
            3. 初始化链接列表为空
            4. 初始化文件地址为 0（未写入文件）
        """
        self.block_type: bytes = self.BLOCK_TYPE
        self.block_len: int = COMMON_BLOCK_HEADER_SIZE
        self.links_nr: int = 0
        self.links: List[int] = []
        self.address: int = 0  # 块在文件中的绝对地址

    # ------------------------------------------------------------------
    # 序列化接口
    # ------------------------------------------------------------------

    def to_bytes(self) -> bytes:
        """
        将块序列化为二进制字节

        步骤:
            1. 调用 _get_links() 获取当前链接列表
            2. 调用 _pack_data() 打包 Data Section
            3. 计算总块长度：Header(24) + Links(8*n) + Data
            4. 按 MDF 规范顺序打包：Header -> Links -> Data
            5. 返回完整字节串

        返回:
            完整的块二进制表示，可直接写入文件

        适用:
            写入 MDF 文件前将内存块对象转为字节
        """
        # 步骤 1-2: 获取链接和数据
        self.links = self._get_links()
        data_bytes = self._pack_data()

        # 步骤 3: 计算总长度
        self.links_nr = len(self.links)
        self.block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * self.links_nr + len(data_bytes)

        # 步骤 4: 打包 Header
        header = struct.pack("<4sIQQ", self.block_type, 0, self.block_len, self.links_nr)

        # 打包 Links
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in self.links)

        # 步骤 5: 组合并返回
        return header + links_bytes + data_bytes

    # ------------------------------------------------------------------
    # 反序列化接口
    # ------------------------------------------------------------------

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int = 0) -> MDFBlock:
        """
        从二进制流解析块

        参数:
            stream: 二进制文件流，必须支持 seek 和 read
            address: 块在文件中的绝对地址（用于计算相对偏移）

        步骤:
            1. seek 到指定地址
            2. 读取并解析 Header Section（24 字节）
            3. 读取并解析 Link Section
            4. 读取 Data Section 的原始字节
            5. 创建实例并填充数据
            6. 调用 _unpack_data() 解析 Data Section

        返回:
            解析后的块实例

        适用:
            读取 MDF 文件时从文件流重建块对象
        """
        # 步骤 1: 定位
        stream.seek(address)

        # 步骤 2: 读取 Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        if len(header_raw) < COMMON_BLOCK_HEADER_SIZE:
            raise ValueError(f"读取 Header 失败：期望 {COMMON_BLOCK_HEADER_SIZE} 字节，"
                             f"实际获得 {len(header_raw)} 字节，地址: 0x{address:X}")

        block_type, reserved, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        # 验证块类型
        if block_type != cls.BLOCK_TYPE:
            raise ValueError(f"块类型不匹配: 期望 {cls.BLOCK_TYPE}, 实际 {block_type}, "
                             f"地址: 0x{address:X}")

        # 步骤 3: 读取 Links
        links_raw = stream.read(LINK_SIZE * links_nr)
        links = list(struct.unpack(f"<{links_nr}Q", links_raw))

        # 步骤 4: 读取 Data Section
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_bytes = stream.read(data_size)

        # 步骤 5: 创建实例
        instance = cls.__new__(cls)
        MDFBlock.__init__(instance)
        instance.block_type = block_type
        instance.block_len = block_len
        instance.links_nr = links_nr
        instance.links = links
        instance.address = address

        # 步骤 6: 解析 Data Section
        instance._unpack_data(data_bytes)

        return instance

    # ------------------------------------------------------------------
    # 子类必须实现的抽象方法
    # ------------------------------------------------------------------

    def _pack_data(self) -> bytes:
        """
        打包 Data Section 为字节

        返回:
            Data Section 的二进制表示

        子类必须覆盖此方法以实现具体的序列化逻辑
        """
        return b""

    def _unpack_data(self, data: bytes) -> None:
        """
        从字节解析 Data Section

        参数:
            data: Data Section 的原始字节

        子类必须覆盖此方法以实现具体的反序列化逻辑
        """
        pass

    def _get_links(self) -> List[int]:
        """
        获取 Link Section 的所有链接地址

        返回:
            64 位绝对地址列表

        子类必须覆盖此方法以提供正确的链接列表
        """
        return []

    def _set_links(self, links: List[int]) -> None:
        """
        设置 Link Section 的所有链接地址

        参数:
            links: 64 位绝对地址列表

        子类必须覆盖此方法以正确接收链接列表
        """
        self.links = links

    # ------------------------------------------------------------------
    # 通用工具方法
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        """返回块的字符串表示，便于调试"""
        return (f"<{self.__class__.__name__}(type={self.block_type!r}, "
                f"len={self.block_len}, links={self.links_nr}, "
                f"addr=0x{self.address:X})>")

    def align_size(self, size: int, alignment: int = 8) -> int:
        """
        将大小对齐到指定字节边界

        参数:
            size: 原始大小
            alignment: 对齐字节数，默认为 8

        返回:
            对齐后的大小

        适用:
            计算块总长度时确保符合 MDF 对齐要求
        """
        remainder = size % alignment
        if remainder:
            return size + (alignment - remainder)
        return size


# =============================================================================
# ID Block (Identification Block)
# =============================================================================

@dataclass
class IDBlock:
    """
    MDF 文件标识块 (##ID)

    ID 块是每个 MDF 文件的第一个块，位于文件偏移 0 处，
    固定 64 字节大小。它标识文件为 MDF 格式并指定版本信息。

    格式 (64 字节):
        字节 0-7:   文件标识 "MDF     " (8 字节 ASCII)
        字节 8-8:   格式标识 (0x00 = MDF, 0x01 = MFB, 0x02 = MFE)
        字节 9-9:   应用程序版本 (默认 0x00)
        字节 10-11: 默认字节序 (0 = Intel little-endian, 1 = Motorola big-endian)
        字节 12-15: 浮点格式 (0 = IEEE 754)
        字节 16-19: MDF 版本号 (如 400, 410, 420)
        字节 20-23: 预留
        字节 24-31: 标准标志位（用于标识未完成的文件）
        字节 32-63: 预留

    属性:
        file_id: 文件标识字符串，固定为 "MDF     "
        format_id: 格式标识，0 = MDF
        app_version: 应用程序版本号
        endianness: 默认字节序，0 = little-endian, 1 = big-endian
        float_format: 浮点格式，0 = IEEE 754
        version: MDF 版本号整数（如 400, 410）
        standard_flags: 标准标志位（未完成标志等）

    适用:
        文件打开时首先读取此块以验证文件格式和版本
    """

    file_id: str = "MDF     "       # 8 字节文件标识
    format_id: int = 0              # 0 = MDF
    app_version: int = 0            # 应用程序版本
    endianness: int = 0             # 0 = Intel (little-endian)
    float_format: int = 0           # 0 = IEEE 754
    version: int = 410              # MDF 版本号（如 410 表示 4.10）
    standard_flags: int = 0         # 标准未完成标志位

    # 类常量
    FIXED_SIZE: int = ID_BLOCK_SIZE  # 64 字节固定大小

    @classmethod
    def from_stream(cls, stream: BinaryIO) -> IDBlock:
        """
        从文件流读取 ID 块

        参数:
            stream: 二进制文件流

        步骤:
            1. seek 到文件开头（偏移 0）
            2. 读取 64 字节
            3. 按格式解析各字段

        返回:
            IDBlock 实例

        适用:
            打开 MDF 文件时首先调用此方法验证文件格式
        """
        stream.seek(0)
        raw = stream.read(cls.FIXED_SIZE)
        if len(raw) < cls.FIXED_SIZE:
            raise ValueError(f"ID 块读取失败：文件太小（{len(raw)} < {cls.FIXED_SIZE}）")

        # 解析字段
        file_id = raw[0:8].decode("ascii", errors="ignore").rstrip("\x00")
        format_id = raw[8]
        app_version = raw[9]
        endianness = struct.unpack("<H", raw[10:12])[0]
        float_format = struct.unpack("<I", raw[12:16])[0]
        version = struct.unpack("<I", raw[16:20])[0]
        standard_flags = struct.unpack("<Q", raw[24:32])[0]

        return cls(
            file_id=file_id,
            format_id=format_id,
            app_version=app_version,
            endianness=endianness,
            float_format=float_format,
            version=version,
            standard_flags=standard_flags,
        )

    def to_bytes(self) -> bytes:
        """
        将 ID 块打包为 64 字节

        步骤:
            1. 将 file_id 编码为 8 字节 ASCII
            2. 按 MDF 规范顺序打包各字段
            3. 填充预留字节为 0

        返回:
            64 字节二进制数据
        """
        # 编码 file_id 为 8 字节
        file_id_bytes = self.file_id.encode("ascii", errors="ignore")
        file_id_bytes = file_id_bytes.ljust(8, b"\x00")[:8]

        # 打包数据
        data = bytearray(self.FIXED_SIZE)
        data[0:8] = file_id_bytes
        data[8] = self.format_id
        data[9] = self.app_version
        data[10:12] = struct.pack("<H", self.endianness)
        data[12:16] = struct.pack("<I", self.float_format)
        data[16:20] = struct.pack("<I", self.version)
        # 字节 20-23 预留（已为 0）
        data[24:32] = struct.pack("<Q", self.standard_flags)
        # 字节 32-63 预留（已为 0）

        return bytes(data)

    def get_version_string(self) -> str:
        """
        获取版本号字符串表示

        返回:
            如 "4.10", "4.20" 等
        """
        major = self.version // 100
        minor = self.version % 100
        return f"{major}.{minor:02d}"

    def set_version_from_string(self, version_str: str) -> None:
        """
        从字符串设置版本号

        参数:
            version_str: 版本号字符串，如 "4.10", "4.2"
        """
        parts = version_str.split(".")
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0
        self.version = major * 100 + minor


# =============================================================================
# Header Block (HD Block)
# =============================================================================

@dataclass
class HDBlock:
    """
    MDF 文件头块 (##HD)

    HD 块是 MDF 文件的根块，位于 ID 块之后（偏移 64）。
    它包含文件的全局描述信息，并链接到所有顶级结构块。

    Link Section（可变长度，8 字节 * links_nr）:
        link[0]: hd_dg_first: 第一个 DG 块地址
        link[1]: hd_fh_first: 第一个 FH 块地址
        link[2]: hd_ch_first: 第一个 CH 块地址（可选）
        link[3]: hd_at_first: 第一个 AT 块地址（可选）
        link[4]: hd_ev_first: 第一个 EV 块地址（可选）
        link[5]: hd_md_comment: 注释 MD 块地址（可选）

    Data Section:
        字节 0-7:   开始时间（纳秒级 UTC 时间戳）
        字节 8-9:   时区偏移（分钟）
        字节 10-11: 夏令时偏移（分钟）
        字节 12-13: 时间标志（0 = 本地时间, 1 = UTC 时间）
        字节 14-15: 标志位

    属性:
        dg_first: 第一个 DG 块地址
        fh_first: 第一个 FH 块地址
        ch_first: 第一个 CH 块地址
        at_first: 第一个 AT 块地址
        ev_first: 第一个 EV 块地址
        md_comment: 注释 MD 块地址
        start_time_ns: 开始时间（纳秒 UTC 时间戳）
        tz_offset_min: 时区偏移（分钟）
        dst_offset_min: 夏令时偏移（分钟）
        time_flags: 时间标志
        flags: HD 标志位

    适用:
        文件全局信息访问，DG 链表遍历起点
    """

    # Links
    dg_first: int = 0       # 第一个 Data Group 地址
    fh_first: int = 0       # 第一个 File History 地址
    ch_first: int = 0       # 第一个 Channel Hierarchy 地址
    at_first: int = 0       # 第一个 Attachment 地址
    ev_first: int = 0       # 第一个 Event 地址
    md_comment: int = 0     # 注释 Metadata 地址

    # Data
    start_time_ns: int = 0          # 开始时间（纳秒 UTC）
    tz_offset_min: int = 0          # 时区偏移（分钟）
    dst_offset_min: int = 0         # 夏令时偏移（分钟）
    time_flags: int = 0             # 时间标志（0=本地, 1=UTC）
    flags: int = 0                  # HD 标志位

    def __post_init__(self):
        """初始化链接列表"""
        self.links = [
            self.dg_first, self.fh_first, self.ch_first,
            self.at_first, self.ev_first, self.md_comment,
        ]

    def to_bytes(self) -> bytes:
        """
        将 HD 块打包为二进制字节

        步骤:
            1. 更新 links 列表
            2. 打包 Data Section
            3. 计算总长度
            4. 组合 Header + Links + Data

        返回:
            完整的 HD 块字节
        """
        # 更新 links
        self.links = [
            self.dg_first, self.fh_first, self.ch_first,
            self.at_first, self.ev_first, self.md_comment,
        ]
        links_nr = len(self.links)
        data = struct.pack("<QhhhH",
                           self.start_time_ns,
                           self.tz_offset_min,
                           self.dst_offset_min,
                           self.time_flags,
                           self.flags)
        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)

        # Header
        header = struct.pack("<4sIQQ", BLOCK_ID_HD, 0, block_len, links_nr)
        # Links
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in self.links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int = 64) -> HDBlock:
        """
        从流解析 HD 块

        参数:
            stream: 二进制文件流
            address: HD 块地址，默认为 64（紧跟 ID 块）

        步骤:
            1. seek 到指定地址
            2. 读取并解析 Header
            3. 读取 Links
            4. 读取并解析 Data Section

        返回:
            HDBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        # Links
        links_raw = stream.read(LINK_SIZE * links_nr)
        links = list(struct.unpack(f"<{links_nr}Q", links_raw))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        # 解析 Data
        start_time_ns, tz_offset_min, dst_offset_min, time_flags, flags = \
            struct.unpack("<QhhhH", data_raw[:16])

        return cls(
            dg_first=links[0] if links_nr > 0 else 0,
            fh_first=links[1] if links_nr > 1 else 0,
            ch_first=links[2] if links_nr > 2 else 0,
            at_first=links[3] if links_nr > 3 else 0,
            ev_first=links[4] if links_nr > 4 else 0,
            md_comment=links[5] if links_nr > 5 else 0,
            start_time_ns=start_time_ns,
            tz_offset_min=tz_offset_min,
            dst_offset_min=dst_offset_min,
            time_flags=time_flags,
            flags=flags,
        )


# =============================================================================
# Data Group Block (DG Block)
# =============================================================================

@dataclass
class DGBlock:
    """
    数据组块 (##DG)

    DG 块描述一个数据块，可以引用一个或多个通道组（CG）。
    每个 DG 块包含实际测量数据（通过 DT/DL/HL 块链接）和
    描述数据布局的通道组（CG）链表。

    Link Section:
        link[0]: dg_dg_next: 下一个 DG 块地址（0 表示最后一个）
        link[1]: dg_cg_first: 第一个 CG 块地址
        link[2]: dg_data: 数据块地址（DT/DL/HL）
        link[3]: dg_md_comment: 注释 MD 块地址（可选）

    Data Section:
        字节 0-1: 标志位
        字节 2-2: record_id_size: record ID 字节数 (0/1/2/4/8)
        字节 3-7: 预留

    属性:
        dg_next: 下一个 DG 块地址
        cg_first: 第一个 CG 块地址
        data_addr: 数据块地址（DT/DL/HL）
        md_comment: 注释 MD 块地址
        flags: DG 标志位
        record_id_size: record ID 字节数

    适用:
        数据组链表遍历，获取数据块地址
    """

    # Links
    dg_next: int = 0        # 下一个 DG 地址
    cg_first: int = 0       # 第一个 CG 地址
    data_addr: int = 0      # 数据块地址 (DT/DL/HL)
    md_comment: int = 0     # 注释地址

    # Data
    flags: int = FLAG_DG_NONE    # DG 标志位
    record_id_size: int = RECORD_ID_SIZE_NONE  # record ID 字节数

    def to_bytes(self) -> bytes:
        """
        将 DG 块打包为二进制字节

        步骤:
            1. 组合链接列表
            2. 打包 Data Section（flags + record_id_size + 预留）
            3. 计算总长度并组合

        返回:
            完整的 DG 块字节
        """
        links = [self.dg_next, self.cg_first, self.data_addr, self.md_comment]
        links_nr = len(links)

        # Data: flags(2) + record_id_size(1) + reserved(5)
        data = struct.pack("<HBB5s", self.flags, self.record_id_size, 0, b"\x00" * 5)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_DG, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> DGBlock:
        """
        从流解析 DG 块

        参数:
            stream: 二进制文件流
            address: DG 块在文件中的地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header（验证块类型为 ##DG）
            3. 读取 4 个链接
            4. 读取 Data Section 并解析 flags 和 record_id_size

        返回:
            DGBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_DG:
            raise ValueError(f"期望 DG 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * links_nr)
        links = list(struct.unpack(f"<{links_nr}Q", links_raw))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        # 解析
        flags, record_id_size = struct.unpack("<HB", data_raw[:3]) if len(data_raw) >= 3 else (0, 0)

        return cls(
            dg_next=links[0] if links_nr > 0 else 0,
            cg_first=links[1] if links_nr > 1 else 0,
            data_addr=links[2] if links_nr > 2 else 0,
            md_comment=links[3] if links_nr > 3 else 0,
            flags=flags,
            record_id_size=record_id_size,
        )


# =============================================================================
# Channel Group Block (CG Block)
# =============================================================================

@dataclass
class CGBlock:
    """
    通道组块 (##CG)

    CG 块描述一组总是联合测量的通道的记录布局。
    它定义了记录的字节大小、record ID、采样周期数等信息。

    Link Section:
        link[0]: cg_cg_next: 下一个 CG 块地址
        link[1]: cg_cn_first: 第一个 CN 块地址
        link[2]: cg_tx_acq_name: 采集名称 TX 块地址
        link[3]: cg_si_acq_source: 源信息 SI 块地址
        link[4]: cg_sr_first: 第一个 SR 块地址（可选）
        link[5]: cg_md_comment: 注释 MD 块地址（可选）

    Data Section:
        字节 0-3:   record_id: 记录标识号
        字节 4-7:   cycles_nr: 采样周期数（记录数）
        字节 8-11:  flags: CG 标志位
        字节 12-15: path_separator: 路径分隔符字符（如 0x5C='\\'）
        字节 16-19: samples_byte_nr: 每个记录的数据字节数
        字节 20-23: inval_bytes_nr: 每个记录的无效值字节数
        字节 24-31: (4.20+) cg_data_bytes: VLSD CG 数据字节数
        字节 32-39: (4.20+) cg_inval_bytes: VLSD CG 无效值字节数

    属性:
        cg_next: 下一个 CG 地址
        cn_first: 第一个 CN 地址
        tx_acq_name: 采集名称 TX 块地址
        si_acq_source: 源信息 SI 块地址
        sr_first: 第一个 SR 地址
        md_comment: 注释地址
        record_id: 记录标识号
        cycles_nr: 采样周期数
        flags: CG 标志位
        path_separator: 路径分隔符
        samples_byte_nr: 每个记录的数据字节数
        inval_bytes_nr: 无效值字节数

    适用:
        描述记录布局，计算数据块大小，遍历通道链表
    """

    # Links
    cg_next: int = 0            # 下一个 CG 地址
    cn_first: int = 0           # 第一个 CN 地址
    tx_acq_name: int = 0        # 采集名称 TX 地址
    si_acq_source: int = 0      # 源信息 SI 地址
    sr_first: int = 0           # 第一个 SR 地址
    md_comment: int = 0         # 注释地址

    # Data
    record_id: int = 0          # 记录标识号
    cycles_nr: int = 0          # 采样周期数
    flags: int = FLAG_CG_NONE   # CG 标志位
    path_separator: int = 0x5C  # 路径分隔符（默认反斜杠）
    samples_byte_nr: int = 0    # 每个记录的数据字节数
    inval_bytes_nr: int = 0     # 无效值字节数

    def to_bytes(self) -> bytes:
        """
        将 CG 块打包为二进制字节

        步骤:
            1. 组合 6 个链接
            2. 打包 Data Section
            3. 计算总长度并组合

        返回:
            完整的 CG 块字节
        """
        links = [
            self.cg_next, self.cn_first, self.tx_acq_name,
            self.si_acq_source, self.sr_first, self.md_comment,
        ]
        links_nr = len(links)

        # Data Section: 24 bytes (record_id + cycles_nr + flags + path_separator + reserved + samples_byte_nr + inval_bytes_nr)
        data = struct.pack("<IIIHHII",
                           self.record_id,
                           self.cycles_nr,
                           self.flags,
                           self.path_separator,
                           0,  # reserved
                           self.samples_byte_nr,
                           self.inval_bytes_nr)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_CG, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> CGBlock:
        """
        从流解析 CG 块

        参数:
            stream: 二进制文件流
            address: CG 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 6 个链接
            4. 读取并解析 Data Section

        返回:
            CGBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_CG:
            raise ValueError(f"期望 CG 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * min(links_nr, 6))
        links = list(struct.unpack(f"<{min(links_nr, 6)}Q", links_raw))
        # 跳过多余链接
        if links_nr > 6:
            stream.read(LINK_SIZE * (links_nr - 6))
            links.extend([0] * (links_nr - 6))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        # 解析 Data（至少 24 字节）
        record_id = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 0
        cycles_nr = struct.unpack("<I", data_raw[4:8])[0] if len(data_raw) >= 8 else 0
        flags = struct.unpack("<I", data_raw[8:12])[0] if len(data_raw) >= 12 else 0
        path_separator = struct.unpack("<H", data_raw[12:14])[0] if len(data_raw) >= 14 else 0x5C
        samples_byte_nr = struct.unpack("<I", data_raw[16:20])[0] if len(data_raw) >= 20 else 0
        inval_bytes_nr = struct.unpack("<I", data_raw[20:24])[0] if len(data_raw) >= 24 else 0

        return cls(
            cg_next=links[0] if links_nr > 0 else 0,
            cn_first=links[1] if links_nr > 1 else 0,
            tx_acq_name=links[2] if links_nr > 2 else 0,
            si_acq_source=links[3] if links_nr > 3 else 0,
            sr_first=links[4] if links_nr > 4 else 0,
            md_comment=links[5] if links_nr > 5 else 0,
            record_id=record_id,
            cycles_nr=cycles_nr,
            flags=flags,
            path_separator=path_separator,
            samples_byte_nr=samples_byte_nr,
            inval_bytes_nr=inval_bytes_nr,
        )


# =============================================================================
# Channel Block (CN Block)
# =============================================================================

@dataclass
class CNBlock:
    """
    通道块 (##CN)

    CN 块描述一个通道（即一个信号），包含信号名称、数据类型、
    在记录中的位置（字节偏移、位偏移）、转换公式引用等信息。

    Link Section:
        link[0]: cn_cn_next: 下一个 CN 块地址
        link[1]: cn_cc_conversion: 转换公式 CC 块地址
        link[2]: cn_tx_name: 通道名称 TX 块地址
        link[3]: cn_si_source: 源信息 SI 块地址
        link[4]: cn_md_comment: 注释 MD 块地址 (4.10+)
        link[5]: cn_md_unit: 单位 MD 块地址 (4.20+)

    Data Section:
        字节 0-3:   channel_type: 通道类型 (0=FL, 1=VLSD, 2=Master, 3=Virtual, ...)
        字节 4-7:   sync_type: 同步类型 (0=Time, 1=Angle, 2=Distance, 3=Index)
        字节 8-11:  data_type: 数据类型 (ChannelDataType 枚举)
        字节 12-15: flags: 通道标志位
        字节 16-19: byte_offset: 在记录中的字节偏移
        字节 20-23: bit_offset: 在字节中的位偏移
        字节 24-27: bit_count: 位宽
        字节 28-31: inval_bit_pos: 无效值位位置
        字节 32-39: precision: 精度
        字节 40-47: val_range_min: 原始值范围最小值
        字节 48-55: val_range_max: 原始值范围最大值
        字节 56-63: limit_min: 物理限值最小值
        字节 64-71: limit_max: 物理限值最大值

    属性:
        cn_next: 下一个 CN 地址
        cc_conversion: 转换公式 CC 地址
        tx_name: 通道名称 TX 地址
        si_source: 源信息 SI 地址
        md_comment: 注释地址
        md_unit: 单位地址
        channel_type: 通道类型
        sync_type: 同步类型
        data_type: 数据类型
        flags: 通道标志位
        byte_offset: 字节偏移
        bit_offset: 位偏移
        bit_count: 位宽
        inval_bit_pos: 无效值位位置

    适用:
        描述单个信号的数据存储格式和位置
    """

    # Links
    cn_next: int = 0            # 下一个 CN 地址
    cc_conversion: int = 0      # 转换公式 CC 地址
    tx_name: int = 0            # 通道名称 TX 地址
    si_source: int = 0          # 源信息 SI 地址
    md_comment: int = 0         # 注释地址
    md_unit: int = 0            # 单位地址

    # Data
    channel_type: int = ChannelType.FIXED_LENGTH  # 通道类型
    sync_type: int = SyncType.TIME                 # 同步类型
    data_type: int = ChannelDataType.UINT_LE        # 数据类型
    flags: int = FLAG_CN_NONE                      # 标志位
    byte_offset: int = 0           # 字节偏移
    bit_offset: int = 0            # 位偏移
    bit_count: int = 0             # 位宽
    inval_bit_pos: int = 0xFFFFFFFF  # 无效值位位置（默认无效）
    precision: int = 0             # 精度
    val_range_min: float = 0.0     # 原始值范围最小值
    val_range_max: float = 0.0     # 原始值范围最大值
    limit_min: float = 0.0         # 限值最小值
    limit_max: float = 0.0         # 限值最大值

    def to_bytes(self) -> bytes:
        """
        将 CN 块打包为二进制字节

        步骤:
            1. 组合 6 个链接
            2. 打包 Data Section（固定 72 字节）
            3. 计算总长度并组合

        返回:
            完整的 CN 块字节
        """
        links = [
            self.cn_next, self.cc_conversion, self.tx_name,
            self.si_source, self.md_comment, self.md_unit,
        ]
        links_nr = len(links)

        # Data Section: 72 字节
        # Layout: channel_type(4) + sync_type(4) + data_type(4) + reserved(2) + flags(2) +
        #         byte_offset(4) + bit_offset(4) + bit_count(4) + inval_bit_pos(4) +
        #         precision(8) + val_range_min(8) + val_range_max(8) + limit_min(8) + limit_max(8)
        data = struct.pack("<IIIHHIIIIQdddd",
                           self.channel_type,
                           self.sync_type,
                           self.data_type,
                           0,  # reserved (2 bytes)
                           self.flags,
                           self.byte_offset,
                           self.bit_offset,
                           self.bit_count,
                           self.inval_bit_pos,
                           self.precision,
                           self.val_range_min,
                           self.val_range_max,
                           self.limit_min,
                           self.limit_max)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_CN, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> CNBlock:
        """
        从流解析 CN 块

        参数:
            stream: 二进制文件流
            address: CN 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 6 个链接
            4. 读取并解析 Data Section

        返回:
            CNBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_CN:
            raise ValueError(f"期望 CN 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * min(links_nr, 6))
        links = list(struct.unpack(f"<{min(links_nr, 6)}Q", links_raw))
        if links_nr > 6:
            stream.read(LINK_SIZE * (links_nr - 6))
            links.extend([0] * (links_nr - 6))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        # 解析 Data（偏移量必须与 to_bytes 中的 pack 格式一致）
        # Layout: channel_type(4) + sync_type(4) + data_type(4) + reserved(2) + flags(2) +
        #         byte_offset(4) + bit_offset(4) + bit_count(4) + inval_bit_pos(4) + ...
        channel_type = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 0
        sync_type = struct.unpack("<I", data_raw[4:8])[0] if len(data_raw) >= 8 else 0
        data_type = struct.unpack("<I", data_raw[8:12])[0] if len(data_raw) >= 12 else 0
        flags = struct.unpack("<H", data_raw[14:16])[0] if len(data_raw) >= 16 else 0
        byte_offset = struct.unpack("<I", data_raw[16:20])[0] if len(data_raw) >= 20 else 0
        bit_offset = struct.unpack("<I", data_raw[20:24])[0] if len(data_raw) >= 24 else 0
        bit_count = struct.unpack("<I", data_raw[24:28])[0] if len(data_raw) >= 28 else 0
        inval_bit_pos = struct.unpack("<I", data_raw[28:32])[0] if len(data_raw) >= 32 else 0xFFFFFFFF

        return cls(
            cn_next=links[0] if links_nr > 0 else 0,
            cc_conversion=links[1] if links_nr > 1 else 0,
            tx_name=links[2] if links_nr > 2 else 0,
            si_source=links[3] if links_nr > 3 else 0,
            md_comment=links[4] if links_nr > 4 else 0,
            md_unit=links[5] if links_nr > 5 else 0,
            channel_type=channel_type,
            sync_type=sync_type,
            data_type=data_type,
            flags=flags,
            byte_offset=byte_offset,
            bit_offset=bit_offset,
            bit_count=bit_count,
            inval_bit_pos=inval_bit_pos,
        )


# =============================================================================
# Data Block (DT Block)
# =============================================================================

@dataclass
class DTBlock:
    """
    数据块 (##DT)

    DT 块是实际存储数据记录的容器。记录按通道组（CG）定义的布局
    紧密排列，无间隙。

    DT 块没有 Link Section（links_nr = 0），只有 Header 和 Data。
    Data Section 包含所有原始记录字节。

    属性:
        data: 原始记录字节数据

    适用:
        存储实际测量数据。对于大数据量，应使用 DL + DT 分片
        或 HL + DL + DZ 压缩方式
    """

    data: bytes = b""  # 原始记录字节

    def to_bytes(self) -> bytes:
        """
        将 DT 块打包为二进制字节

        步骤:
            1. 计算总长度 = Header(24) + Data(len(data))
            2. 打包 Header（links_nr = 0）
            3. 拼接 data

        返回:
            完整的 DT 块字节
        """
        block_len = COMMON_BLOCK_HEADER_SIZE + len(self.data)
        header = struct.pack("<4sIQQ", BLOCK_ID_DT, 0, block_len, 0)
        return header + self.data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> DTBlock:
        """
        从流解析 DT 块

        参数:
            stream: 二进制文件流
            address: DT 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header（验证块类型，读取块长度）
            3. 读取 Data Section（block_len - 24 字节）

        返回:
            DTBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_DT:
            raise ValueError(f"期望 DT 块，实际为 {block_type}")

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data = stream.read(data_size)

        instance = cls(data=data)
        return instance


# =============================================================================
# Data List Block (DL Block)
# =============================================================================

@dataclass
class DLBlock:
    """
    数据列表块 (##DL)

    DL 块用于管理分散在多个数据块中的数据，实现数据分片。
    当单个 DT 块过大时，可将其拆分为多个小 DT 块，通过 DL 块链接。

    Link Section:
        link[0]: dl_dl_next: 下一个 DL 块地址（0 表示链尾）
        link[1..n]: dl_data[i]: 第 i 个数据块地址

    Data Section:
        字节 0-3: flags: DL 标志位
        字节 4-7: 预留
        字节 8-11: data_block_nr: 链接的数据块数量
        字节 12-19: equal_len: 如果 FLAG_DL_EQUAL_LEN，表示每个块等长

    属性:
        dl_next: 下一个 DL 块地址
        data_addrs: 数据块地址列表
        flags: DL 标志位
        data_block_nr: 数据块数量
        equal_len: 等长模式下每个块的长度

    适用:
        FRAGMENTED 模式下管理分片数据块链表
    """

    dl_next: int = 0            # 下一个 DL 地址
    data_addrs: List[int] = field(default_factory=list)  # 数据块地址列表
    flags: int = FLAG_DL_NONE   # DL 标志位
    equal_len: int = 0          # 等长模式下每个块的长度

    def to_bytes(self) -> bytes:
        """
        将 DL 块打包为二进制字节

        步骤:
            1. 组合链接：dl_next + 所有 data_addrs
            2. 打包 Data Section
            3. 计算总长度并组合

        返回:
            完整的 DL 块字节
        """
        links = [self.dl_next] + self.data_addrs
        links_nr = len(links)
        data_block_nr = len(self.data_addrs)

        # Data Section: flags(4) + reserved(4) + data_block_nr(4) + equal_len(8)
        data = struct.pack("<IIIQ", self.flags, 0, data_block_nr, self.equal_len)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_DL, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> DLBlock:
        """
        从流解析 DL 块

        参数:
            stream: 二进制文件流
            address: DL 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取所有链接（第一个为 dl_next，其余为 data_addrs）
            4. 读取并解析 Data Section

        返回:
            DLBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_DL:
            raise ValueError(f"期望 DL 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * links_nr)
        links = list(struct.unpack(f"<{links_nr}Q", links_raw)) if links_nr > 0 else []

        dl_next = links[0] if links_nr > 0 else 0
        data_addrs = links[1:] if links_nr > 1 else []

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        flags = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 0
        data_block_nr = struct.unpack("<I", data_raw[8:12])[0] if len(data_raw) >= 12 else 0
        equal_len = struct.unpack("<Q", data_raw[12:20])[0] if len(data_raw) >= 20 else 0

        return cls(
            dl_next=dl_next,
            data_addrs=data_addrs,
            flags=flags,
            equal_len=equal_len,
        )


# =============================================================================
# Header List Block (HL Block)
# =============================================================================

@dataclass
class HLBlock:
    """
    列表头块 (##HL)

    HL 块作为 DL 链表的头部，用于描述压缩数据的分片列表。
    当数据使用压缩存储（DZ 块）时，HL 块指向第一个 DL 块，
    并记录压缩算法类型。

    Link Section:
        link[0]: hl_dl_first: 第一个 DL 块地址

    Data Section:
        字节 0-3: flags: HL 标志位
        字节 4-7: zip_type: 压缩类型
        字节 8-9: 预留
        字节 10-11: dl_nr: DL 块总数
        字节 12-19: dl_equal_len: 每个 DL 管理的等长数据大小

    属性:
        dl_first: 第一个 DL 块地址
        flags: HL 标志位
        zip_type: 压缩算法类型 (CompressionAlgorithm)
        dl_nr: DL 块数量
        dl_equal_len: 等长数据大小

    适用:
        FRAGMENTED 模式下压缩数据的管理头
    """

    dl_first: int = 0           # 第一个 DL 地址
    flags: int = 0              # HL 标志位
    zip_type: int = FLAG_DZ_DEFLATE  # 压缩类型
    dl_nr: int = 0              # DL 块数量
    dl_equal_len: int = 0       # 等长数据大小

    def to_bytes(self) -> bytes:
        """
        将 HL 块打包为二进制字节

        步骤:
            1. 组合 1 个链接（dl_first）
            2. 打包 Data Section（16 字节）
            3. 计算总长度并组合

        返回:
            完整的 HL 块字节
        """
        links = [self.dl_first]
        links_nr = len(links)

        # Data Section: flags(4) + zip_type(4) + reserved(2) + dl_nr(2) + dl_equal_len(8)
        data = struct.pack("<IIHHQ", self.flags, self.zip_type, 0, self.dl_nr, self.dl_equal_len)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_HL, 0, block_len, links_nr)
        links_bytes = struct.pack("<Q", self.dl_first)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> HLBlock:
        """
        从流解析 HL 块

        参数:
            stream: 二进制文件流
            address: HL 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 1 个链接（dl_first）
            4. 读取并解析 Data Section

        返回:
            HLBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_HL:
            raise ValueError(f"期望 HL 块，实际为 {block_type}")

        # Links
        dl_first = 0
        if links_nr > 0:
            dl_first = struct.unpack("<Q", stream.read(LINK_SIZE))[0]

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        flags = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 0
        zip_type = struct.unpack("<I", data_raw[4:8])[0] if len(data_raw) >= 8 else 0
        dl_nr = struct.unpack("<H", data_raw[10:12])[0] if len(data_raw) >= 12 else 0
        dl_equal_len = struct.unpack("<Q", data_raw[12:20])[0] if len(data_raw) >= 20 else 0

        return cls(
            dl_first=dl_first,
            flags=flags,
            zip_type=zip_type,
            dl_nr=dl_nr,
            dl_equal_len=dl_equal_len,
        )


# =============================================================================
# Data Zipped Block (DZ Block)
# =============================================================================

@dataclass
class DZBlock:
    """
    压缩数据块 (##DZ)

    DZ 块用于存储压缩后的 DT/SD/RD 数据。它包含压缩算法类型、
    原始数据大小、压缩后大小等信息。

    Link Section: 无（links_nr = 0）

    Data Section:
        字节 0-3:   zip_type: 压缩算法类型
        字节 4-7:   预留
        字节 8-11:  param: 压缩参数（转置模式下的列数）
        字节 12-19: original_size: 原始（解压后）数据大小
        字节 20-27: zip_size: 压缩数据大小
        字节 28..:  zip_data: 压缩后的数据字节

    属性:
        zip_type: 压缩算法类型
        param: 压缩参数
        original_size: 原始数据大小
        zip_size: 压缩数据大小
        zip_data: 压缩后的数据字节

    适用:
        压缩模式下的数据存储，解压时恢复原始 DT 块
    """

    zip_type: int = FLAG_DZ_DEFLATE  # 压缩类型
    param: int = 0                   # 压缩参数
    original_size: int = 0           # 原始数据大小
    zip_data: bytes = b""            # 压缩数据

    def __post_init__(self):
        """初始化 zip_size 为实际压缩数据长度"""
        self.zip_size: int = len(self.zip_data)

    def to_bytes(self) -> bytes:
        """
        将 DZ 块打包为二进制字节

        步骤:
            1. 计算压缩数据大小
            2. 打包 Data Section（元数据 + 压缩数据）
            3. 计算总长度并组合

        返回:
            完整的 DZ 块字节
        """
        self.zip_size = len(self.zip_data)

        # Data Section: zip_type(4) + reserved(4) + param(4) + original_size(8) + zip_size(8) + zip_data
        meta = struct.pack("<IIIQQ", self.zip_type, 0, self.param, self.original_size, self.zip_size)
        data = meta + self.zip_data

        block_len = COMMON_BLOCK_HEADER_SIZE + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_DZ, 0, block_len, 0)

        return header + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> DZBlock:
        """
        从流解析 DZ 块

        参数:
            stream: 二进制文件流
            address: DZ 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 Data Section 并解析元数据和压缩数据

        返回:
            DZBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_DZ:
            raise ValueError(f"期望 DZ 块，实际为 {block_type}")

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE
        data_raw = stream.read(data_size)

        zip_type = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 0
        param = struct.unpack("<I", data_raw[8:12])[0] if len(data_raw) >= 12 else 0
        original_size = struct.unpack("<Q", data_raw[12:20])[0] if len(data_raw) >= 20 else 0
        zip_size = struct.unpack("<Q", data_raw[20:28])[0] if len(data_raw) >= 28 else 0
        zip_data = data_raw[28:28 + zip_size] if len(data_raw) >= 28 else b""

        return cls(
            zip_type=zip_type,
            param=param,
            original_size=original_size,
            zip_data=zip_data,
        )

    def decompress(self) -> bytes:
        """
        解压压缩数据

        步骤:
            1. 根据 zip_type 选择解压算法
            2. 调用对应算法解压 zip_data
            3. 验证解压后大小与 original_size 一致

        返回:
            解压后的原始数据字节

        适用:
            读取压缩数据时恢复原始 DT 块内容
        """
        if self.zip_type in (FLAG_DZ_DEFLATE, FLAG_DZ_TRANSPOSED_DEFLATE):
            # 使用 zlib 解压 DEFLATE
            data = zlib.decompress(self.zip_data)
        else:
            # 其他压缩算法暂未实现
            raise NotImplementedError(f"压缩类型 {self.zip_type} 尚未实现")

        # 验证大小
        if len(data) != self.original_size:
            logger.warning(f"解压后大小不匹配: 期望 {self.original_size}, 实际 {len(data)}")

        return data

    @classmethod
    def compress(cls, data: bytes, zip_type: int = FLAG_DZ_DEFLATE, param: int = 0) -> DZBlock:
        """
        创建压缩数据块

        参数:
            data: 原始数据字节
            zip_type: 压缩算法类型
            param: 压缩参数

        步骤:
            1. 根据 zip_type 选择压缩算法
            2. 压缩数据
            3. 创建 DZBlock 实例

        返回:
            包含压缩数据的 DZBlock 实例

        适用:
            写入时压缩原始 DT 块数据
        """
        original_size = len(data)

        if zip_type in (FLAG_DZ_DEFLATE, FLAG_DZ_TRANSPOSED_DEFLATE):
            zip_data = zlib.compress(data)
        else:
            raise NotImplementedError(f"压缩类型 {zip_type} 尚未实现")

        return cls(
            zip_type=zip_type,
            param=param,
            original_size=original_size,
            zip_data=zip_data,
        )


# =============================================================================
# Text Block (TX Block)
# =============================================================================

@dataclass
class TXBlock:
    """
    文本块 (##TX)

    TX 块用于存储可变长度的纯文本字符串，以 null 结尾。
    常用于存储通道名称、单位、注释等。

    Link Section: 无
    Data Section: 以 null 结尾的 UTF-8 编码字符串

    属性:
        text: 文本字符串内容

    适用:
        存储通道名称、单位、注释等文本信息
    """

    text: str = ""  # 文本内容

    def to_bytes(self) -> bytes:
        """
        将 TX 块打包为二进制字节

        步骤:
            1. 将文本编码为 UTF-8 并添加 null 结尾
            2. 计算总长度并打包 Header

        返回:
            完整的 TX 块字节
        """
        text_bytes = self.text.encode("utf-8") + b"\x00"
        block_len = COMMON_BLOCK_HEADER_SIZE + len(text_bytes)
        header = struct.pack("<4sIQQ", BLOCK_ID_TX, 0, block_len, 0)
        return header + text_bytes

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> TXBlock:
        """
        从流解析 TX 块

        参数:
            stream: 二进制文件流
            address: TX 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header 获取块长度
            3. 读取文本字节并解码

        返回:
            TXBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_TX:
            raise ValueError(f"期望 TX 块，实际为 {block_type}")

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE
        text_bytes = stream.read(data_size)

        # 去除 null 结尾并解码
        text = text_bytes.rstrip(b"\x00").decode("utf-8", errors="ignore")

        return cls(text=text)


# =============================================================================
# Metadata Block (MD Block)
# =============================================================================

@dataclass
class MDBlock:
    """
    元数据块 (##MD)

    MD 块用于存储 XML 格式的元数据字符串，以 null 结尾。
    XML 内容遵循 ASAM MDF 元数据模式定义。

    Link Section: 无
    Data Section: 以 null 结尾的 XML 字符串（UTF-8 编码）

    属性:
        xml_data: XML 元数据字符串

    适用:
        存储通道注释、文件注释、自定义属性等结构化元数据
    """

    xml_data: str = ""  # XML 元数据内容

    def to_bytes(self) -> bytes:
        """
        将 MD 块打包为二进制字节

        步骤:
            1. 将 XML 编码为 UTF-8 并添加 null 结尾
            2. 计算总长度并打包 Header

        返回:
            完整的 MD 块字节
        """
        xml_bytes = self.xml_data.encode("utf-8") + b"\x00"
        block_len = COMMON_BLOCK_HEADER_SIZE + len(xml_bytes)
        header = struct.pack("<4sIQQ", BLOCK_ID_MD, 0, block_len, 0)
        return header + xml_bytes

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> MDBlock:
        """
        从流解析 MD 块

        参数:
            stream: 二进制文件流
            address: MD 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header 获取块长度
            3. 读取 XML 字节并解码

        返回:
            MDBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_MD:
            raise ValueError(f"期望 MD 块，实际为 {block_type}")

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE
        xml_bytes = stream.read(data_size)

        xml_data = xml_bytes.rstrip(b"\x00").decode("utf-8", errors="ignore")

        return cls(xml_data=xml_data)


# =============================================================================
# File History Block (FH Block)
# =============================================================================

@dataclass
class FHBlock:
    """
    文件历史块 (##FH)

    FH 块记录文件的修改历史，包含时间戳和工具信息。
    多个 FH 块通过 next 链接形成链表。

    Link Section:
        link[0]: fh_fh_next: 下一个 FH 块地址
        link[1]: fh_tx_program: 程序/工具名称 TX 块地址
        link[2]: fh_md_comment: 注释 MD 块地址（可选）

    Data Section:
        字节 0-7: time_ns: 修改时间（纳秒 UTC 时间戳）
        字节 8-9: tz_offset_min: 时区偏移（分钟）
        字节 10-11: dst_offset_min: 夏令时偏移（分钟）
        字节 12-13: time_flags: 时间标志

    属性:
        fh_next: 下一个 FH 地址
        tx_program: 程序名称 TX 地址
        md_comment: 注释地址
        time_ns: 修改时间（纳秒 UTC）
        tz_offset_min: 时区偏移
        dst_offset_min: 夏令时偏移
        time_flags: 时间标志

    适用:
        追踪文件修改历史，记录创建/修改工具和版本
    """

    fh_next: int = 0        # 下一个 FH 地址
    tx_program: int = 0     # 程序名称 TX 地址
    md_comment: int = 0     # 注释地址

    time_ns: int = 0        # 修改时间（纳秒 UTC）
    tz_offset_min: int = 0  # 时区偏移
    dst_offset_min: int = 0 # 夏令时偏移
    time_flags: int = 0     # 时间标志

    def to_bytes(self) -> bytes:
        """
        将 FH 块打包为二进制字节

        步骤:
            1. 组合 3 个链接
            2. 打包 Data Section
            3. 计算总长度并组合

        返回:
            完整的 FH 块字节
        """
        links = [self.fh_next, self.tx_program, self.md_comment]
        links_nr = len(links)

        data = struct.pack("<QhhhH", self.time_ns, self.tz_offset_min,
                           self.dst_offset_min, self.time_flags, 0)

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_FH, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> FHBlock:
        """
        从流解析 FH 块

        参数:
            stream: 二进制文件流
            address: FH 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 3 个链接
            4. 读取并解析 Data Section

        返回:
            FHBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_FH:
            raise ValueError(f"期望 FH 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * min(links_nr, 3))
        links = list(struct.unpack(f"<{min(links_nr, 3)}Q", links_raw))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        time_ns = struct.unpack("<Q", data_raw[0:8])[0] if len(data_raw) >= 8 else 0
        tz_offset_min = struct.unpack("<h", data_raw[8:10])[0] if len(data_raw) >= 10 else 0
        dst_offset_min = struct.unpack("<h", data_raw[10:12])[0] if len(data_raw) >= 12 else 0
        time_flags = struct.unpack("<H", data_raw[12:14])[0] if len(data_raw) >= 14 else 0

        return cls(
            fh_next=links[0] if links_nr > 0 else 0,
            tx_program=links[1] if links_nr > 1 else 0,
            md_comment=links[2] if links_nr > 2 else 0,
            time_ns=time_ns,
            tz_offset_min=tz_offset_min,
            dst_offset_min=dst_offset_min,
            time_flags=time_flags,
        )


# =============================================================================
# 通道转换块 (CC Block)
# =============================================================================

@dataclass
class CCBlock:
    """
    通道转换块 (##CC)

    CC 块定义通道的转换公式，用于将原始值（raw value）转换为物理值（physical value）。
    支持线性转换（y = a*x + b）、多项式转换、查表转换、公式转换等多种类型。

    Link Section（可变长度，取决于转换类型和参数数量）:
        link[0]: cc_tx_name: 转换名称 TX 块地址
        link[1]: cc_md_unit: 单位 MD 块地址
        link[2]: cc_md_comment: 注释 MD 块地址
        link[3]: cc_cc_inverse: 逆转换 CC 块地址

    Data Section:
        字节 0-3:   type: 转换类型 (1=线性, 2=多项式, 3=指数, ...)
        字节 4-7:   flags: 标志位
        字节 8-15:  val_param_nr: 数值参数数量
        字节 16-23: ref_param_nr: 引用参数数量
        字节 24..:  参数数组（double 类型）

    属性:
        tx_name: 转换名称地址
        md_unit: 单位地址
        md_comment: 注释地址
        cc_inverse: 逆转换地址
        type: 转换类型
        flags: 标志位
        parameters: 转换参数列表（浮点数）

    适用:
        原始值到物理值的转换，如 ADC 码值到电压的转换
    """

    # Links
    tx_name: int = 0        # 转换名称 TX 地址
    md_unit: int = 0        # 单位 MD 地址
    md_comment: int = 0     # 注释 MD 地址
    cc_inverse: int = 0     # 逆转换 CC 地址

    # Data
    type: int = 1           # 转换类型（1=线性 y=ax+b）
    flags: int = 0          # 标志位
    parameters: List[float] = field(default_factory=list)  # 转换参数

    def to_bytes(self) -> bytes:
        """
        将 CC 块打包为二进制字节

        步骤:
            1. 组合 4 个链接
            2. 打包 Data Section（类型、标志、参数数量、参数值）
            3. 计算总长度并组合

        返回:
            完整的 CC 块字节
        """
        links = [self.tx_name, self.md_unit, self.md_comment, self.cc_inverse]
        links_nr = len(links)

        val_param_nr = len(self.parameters)
        ref_param_nr = 0

        # Data: type(4) + flags(4) + val_param_nr(8) + ref_param_nr(8) + params(8*len)
        params_bytes = struct.pack(f"<{len(self.parameters)}d", *self.parameters)
        data = struct.pack("<IIQQ", self.type, self.flags, val_param_nr, ref_param_nr) + params_bytes

        block_len = COMMON_BLOCK_HEADER_SIZE + LINK_SIZE * links_nr + len(data)
        header = struct.pack("<4sIQQ", BLOCK_ID_CC, 0, block_len, links_nr)
        links_bytes = b"".join(struct.pack("<Q", addr) for addr in links)

        return header + links_bytes + data

    @classmethod
    def from_stream(cls, stream: BinaryIO, address: int) -> CCBlock:
        """
        从流解析 CC 块

        参数:
            stream: 二进制文件流
            address: CC 块地址

        步骤:
            1. seek 到指定地址
            2. 读取 Header
            3. 读取 4 个链接
            4. 读取并解析 Data Section

        返回:
            CCBlock 实例
        """
        stream.seek(address)

        # Header
        header_raw = stream.read(COMMON_BLOCK_HEADER_SIZE)
        block_type, _, block_len, links_nr = struct.unpack("<4sIQQ", header_raw)

        if block_type != BLOCK_ID_CC:
            raise ValueError(f"期望 CC 块，实际为 {block_type}")

        # Links
        links_raw = stream.read(LINK_SIZE * min(links_nr, 4))
        links = list(struct.unpack(f"<{min(links_nr, 4)}Q", links_raw))

        # Data
        data_size = block_len - COMMON_BLOCK_HEADER_SIZE - LINK_SIZE * links_nr
        data_raw = stream.read(data_size)

        type_ = struct.unpack("<I", data_raw[0:4])[0] if len(data_raw) >= 4 else 1
        flags = struct.unpack("<I", data_raw[4:8])[0] if len(data_raw) >= 8 else 0
        val_param_nr = struct.unpack("<Q", data_raw[8:16])[0] if len(data_raw) >= 16 else 0

        # 读取参数
        params = []
        for i in range(val_param_nr):
            offset = 24 + i * 8
            if offset + 8 <= len(data_raw):
                params.append(struct.unpack("<d", data_raw[offset:offset + 8])[0])

        return cls(
            tx_name=links[0] if links_nr > 0 else 0,
            md_unit=links[1] if links_nr > 1 else 0,
            md_comment=links[2] if links_nr > 2 else 0,
            cc_inverse=links[3] if links_nr > 3 else 0,
            type=type_,
            flags=flags,
            parameters=params,
        )

    def apply(self, raw_value: float) -> float:
        """
        应用转换公式

        参数:
            raw_value: 原始值

        返回:
            转换后的物理值

        适用:
            将通道的原始值转换为有物理意义的值
        """
        if self.type == 1 and len(self.parameters) >= 2:
            # 线性转换: y = a*x + b
            a, b = self.parameters[0], self.parameters[1]
            return a * raw_value + b
        return raw_value


# =============================================================================
# 便捷数据结构
# =============================================================================

@dataclass
class ChannelInfo:
    """
    通道信息数据结构

    封装创建通道所需的全部信息，简化用户接口。
    包含通道名称、数据类型、单位、注释等元数据，
    以及用于数据转换的线性转换参数（a, b）。

    属性:
        name: 通道名称（唯一标识）
        data_type: 数据类型枚举值
        bit_count: 位宽（如 8, 16, 32, 64）
        unit: 物理单位（如 "V", "m/s", "°C"）
        comment: 通道注释
        channel_type: 通道类型（默认 FIXED_LENGTH）
        sync_type: 同步类型（默认 TIME）
        conversion_a: 线性转换系数 a（y = a*x + b）
        conversion_b: 线性转换偏移 b
        byte_offset: 在记录中的字节偏移（自动计算时可不填）
        bit_offset: 在字节中的位偏移（默认 0）

    适用:
        创建 MDF 文件时定义通道布局
    """

    name: str                           # 通道名称
    data_type: int = ChannelDataType.FLOAT_LE  # 数据类型
    bit_count: int = 32                 # 位宽
    unit: str = ""                      # 物理单位
    comment: str = ""                   # 注释
    channel_type: int = ChannelType.FIXED_LENGTH  # 通道类型
    sync_type: int = SyncType.TIME       # 同步类型
    conversion_a: float = 1.0           # 转换系数 a
    conversion_b: float = 0.0           # 转换偏移 b
    byte_offset: Optional[int] = None   # 字节偏移（None 表示自动计算）
    bit_offset: int = 0                 # 位偏移


def calculate_record_layout(channels: List[ChannelInfo], alignment: int = 8,
                           record_id_size: int = RECORD_ID_SIZE_NONE,
                           inval_bytes_nr: int = 0) -> Tuple[int, List[int]]:
    """
    计算记录布局

    给定通道列表，计算每个通道在记录中的字节偏移和位偏移，
    以及记录的总字节大小。

    参数:
        channels: 通道信息列表
        alignment: 字节对齐数
        record_id_size: record ID 字节数
        inval_bytes_nr: 无效值字节数

    步骤:
        1. 初始化偏移量为 record_id_size
        2. 遍历每个通道：
           a. 如果 byte_offset 已指定，使用指定值
           b. 否则，按当前偏移量自动分配
           c. 更新偏移量（考虑位宽和字节大小）
        3. 对齐到 alignment 边界
        4. 添加无效值字节数

    返回:
        (record_size, byte_offsets): 记录总大小和各通道字节偏移列表

    适用:
        写入前计算记录布局，确保数据正确排列
    """
    byte_offsets = []
    current_offset = record_id_size  # 从 record ID 后开始

    for ch in channels:
        if ch.byte_offset is not None:
            # 使用指定的偏移
            byte_offsets.append(ch.byte_offset)
            current_offset = max(current_offset, ch.byte_offset + ch.bit_count // 8)
        else:
            # 自动分配偏移
            byte_size = ch.bit_count // 8
            byte_offsets.append(current_offset)
            current_offset += byte_size

    # 对齐
    record_size = ((current_offset + alignment - 1) // alignment) * alignment

    # 添加无效值字节
    record_size += inval_bytes_nr

    return record_size, byte_offsets


__all__ = [
    "MDFBlock",
    "IDBlock", "HDBlock", "DGBlock", "CGBlock", "CNBlock",
    "DTBlock", "DLBlock", "HLBlock", "DZBlock",
    "TXBlock", "MDBlock", "FHBlock", "CCBlock",
    "ChannelInfo", "calculate_record_layout",
]
