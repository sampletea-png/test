"""
Command Handler

Handles MDF4 file operations based on received commands.
"""

import logging
import base64
import io
import numpy as np
from asammdf import MDF


class CommandHandler:
    """Command handler for MDF4 operations"""

    def __init__(self):
        self.open_files = {}  # file_id -> {'mdf': MDF, 'mode': 'r'|'w', 'path': str}
        self.file_counter = 0
        self.logger = logging.getLogger(__name__)
        self.lock = threading.Lock()

    def handle(self, command):
        """Handle command"""
        cmd_type = command.get('type')
        params = command.get('params', {})

        self.logger.debug(f"Handling command: {cmd_type}")

        handlers = {
            'OPEN_READ': self._handle_open_read,
            'OPEN_WRITE': self._handle_open_write,
            'GET_SIGNALS': self._handle_get_signals,
            'GET_SIGNAL_INFO': self._handle_get_signal_info,
            'READ_SIGNAL': self._handle_read_signal,
            'READ_SIGNALS_BATCH': self._handle_read_signals_batch,
            'READ_SIGNAL_CHUNK': self._handle_read_signal_chunk,
            'APPEND_SIGNAL_CHUNK': self._handle_append_signal_chunk,
            'SET_COMPRESSION': self._handle_set_compression,
            'SAVE': self._handle_save,
            'CLOSE': self._handle_close,
            'GET_INFO': self._handle_get_info,
            'CONVERT_TO_CSV': self._handle_convert_to_csv,
            'CUT': self._handle_cut,
            'CONCATENATE': self._handle_concatenate,
            'DECODE_WITH_DBC': self._handle_decode_with_dbc,
            'PING': self._handle_ping,
        }

        handler = handlers.get(cmd_type)
        if handler:
            try:
                return handler(params)
            except Exception as e:
                self.logger.error(f"Error handling {cmd_type}: {e}")
                return {'status': 'ERROR', 'message': str(e)}
        else:
            return {'status': 'ERROR', 'message': f'Unknown command: {cmd_type}'}

    def _handle_open_read(self, params):
        """Open file for reading"""
        file_path = params['file_path']
        mdf = MDF(file_path)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'r',
                'path': file_path
            }

        self.logger.info(f"Opened file for reading: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'file_id': file_id,
            'version': mdf.version
        }

    def _handle_open_write(self, params):
        """Open file for writing"""
        file_path = params['file_path']
        version = params.get('version', '4.10')

        # Create new MDF file
        mdf = MDF(version=version)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'w',
                'path': file_path
            }

        self.logger.info(f"Created file for writing: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'file_id': file_id,
            'version': version
        }

    def _handle_get_signals(self, params):
        """Get all signal names"""
        file_id = params['file_id']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal_names = []

        for group in mdf.groups:
            for channel in group.channels:
                signal_names.append(channel.name)

        return {
            'status': 'OK',
            'signal_names': signal_names
        }

    def _handle_get_signal_info(self, params):
        """Get signal information"""
        file_id = params['file_id']
        signal_name = params['signal_name']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        return {
            'status': 'OK',
            'sample_count': len(signal.samples) if signal.samples is not None else 0,
            'unit': signal.unit,
            'comment': signal.comment
        }

    def _handle_read_signal(self, params):
        """Read signal data"""
        file_id = params['file_id']
        signal_name = params['signal_name']
        start_time = params.get('start_time')
        end_time = params.get('end_time')

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        # Time range filtering
        timestamps = signal.timestamps
        samples = signal.samples

        if start_time is not None or end_time is not None:
            mask = np.ones(len(timestamps), dtype=bool)
            if start_time is not None:
                mask &= timestamps >= start_time
            if end_time is not None:
                mask &= timestamps <= end_time
            timestamps = timestamps[mask]
            samples = samples[mask]

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'data_type': str(samples.dtype) if samples is not None else 'unknown',
            'timestamps': self._encode_array(timestamps),
            'samples': self._encode_array(samples)
        }

    def _handle_read_signals_batch(self, params):
        """Read multiple signals (batch)"""
        file_id = params['file_id']
        signal_names = params['signal_names']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signals_data = {}

        for signal_name in signal_names:
            signal = mdf.get(signal_name)
            signals_data[signal_name] = {
                'name': signal.name,
                'unit': signal.unit,
                'description': signal.comment,
                'data_type': str(signal.samples.dtype) if signal.samples is not None else 'unknown',
                'timestamps': self._encode_array(signal.timestamps),
                'samples': self._encode_array(signal.samples)
            }

        return {
            'status': 'OK',
            'signals': signals_data
        }

    def _handle_read_signal_chunk(self, params):
        """Read signal data in chunks"""
        file_id = params['file_id']
        signal_name = params['signal_name']
        offset = params.get('offset', 0)
        limit = params.get('limit', 10000)

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        timestamps = signal.timestamps
        samples = signal.samples

        # Apply chunk range
        start = int(offset)
        end = min(start + int(limit), len(timestamps))

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'data_type': str(samples.dtype) if samples is not None else 'unknown',
            'timestamps': self._encode_array(timestamps[start:end]),
            'samples': self._encode_array(samples[start:end]),
            'offset': offset,
            'count': end - start
        }

    def _handle_append_signal_chunk(self, params):
        """Append signal data chunk"""
        file_id = params['file_id']
        name = params['name']
        timestamps_b64 = params['timestamps']
        samples_b64 = params['samples']
        config = params.get('config', {})
        is_last = params.get('is_last', False)

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Decode arrays
        timestamps = self._decode_array(timestamps_b64)
        samples = self._decode_array(samples_b64)

        # Append to MDF (this is simplified - actual implementation would need to handle chunks properly)
        # For now, we just store the data in memory and save when is_last is True

        if is_last:
            # Create signal and append to MDF
            # Note: This is a simplified version - actual implementation would be more complex
            pass

        return {
            'status': 'OK',
            'appended': len(samples)
        }

    def _handle_set_compression(self, params):
        """Set compression level"""
        file_id = params['file_id']
        level = params['level']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        # Set compression (implementation depends on asammdf version)
        # mdf = file_info['mdf']
        # mdf.configure(compression=level)

        return {'status': 'OK'}

    def _handle_save(self, params):
        """Save file"""
        file_id = params['file_id']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        file_path = file_info['path']

        mdf.save(file_path, overwrite=True)

        self.logger.info(f"Saved file: {file_path}")

        return {'status': 'OK'}

    def _handle_close(self, params):
        """Close file"""
        file_id = params['file_id']
        file_info = self.open_files.pop(file_id, None)

        if file_info:
            mdf = file_info['mdf']
            mdf.close()
            self.logger.info(f"Closed file: {file_info['path']}")

        return {'status': 'OK'}

    def _handle_get_info(self, params):
        """Get file information"""
        file_id = params['file_id']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Calculate total channels
        channel_count = sum(len(group.channels) for group in mdf.groups)

        return {
            'status': 'OK',
            'version': mdf.version,
            'channel_group_count': len(mdf.groups),
            'channel_count': channel_count,
            'record_count': mdf.header.start_time,
            'start_time': str(mdf.header.start_time) if mdf.header.start_time else None,
            'duration': mdf.header.duration if hasattr(mdf.header, 'duration') else 0.0
        }

    def _handle_convert_to_csv(self, params):
        """Convert MDF4 to CSV"""
        mdf_path = params['mdf_path']
        csv_path = params['csv_path']
        delimiter = params.get('delimiter', ',')
        include_time = params.get('include_time', True)
        time_format = params.get('time_format', 'SECONDS')

        mdf = MDF(mdf_path)
        mdf.export(fmt='csv', filename=csv_path)
        mdf.close()

        self.logger.info(f"Converted {mdf_path} to CSV: {csv_path}")

        return {'status': 'OK'}

    def _handle_cut(self, params):
        """Cut file by time range"""
        input_path = params['input_path']
        output_path = params['output_path']
        start_time = params.get('start_time')
        end_time = params.get('end_time')

        mdf = MDF(input_path)
        cut_mdf = mdf.cut(start=start_time, stop=end_time)
        cut_mdf.save(output_path, overwrite=True)
        mdf.close()
        cut_mdf.close()

        self.logger.info(f"Cut {input_path} to {output_path}")

        return {'status': 'OK'}

    def _handle_concatenate(self, params):
        """Concatenate multiple MDF4 files"""
        mdf_paths = params['mdf_paths']
        output_path = params['output_path']

        mdfs = [MDF(path) for path in mdf_paths]
        concatenated = MDF.concatenate(mdfs)
        concatenated.save(output_path, overwrite=True)

        for mdf in mdfs:
            mdf.close()
        concatenated.close()

        self.logger.info(f"Concatenated {len(mdf_paths)} files to {output_path}")

        return {'status': 'OK'}

    def _handle_decode_with_dbc(self, params):
        """Decode with DBC file"""
        mdf_path = params['mdf_path']
        dbc_path = params['dbc_path']
        output_path = params['output_path']

        mdf = MDF(mdf_path)
        decoded = mdf.extract_bus_logging(database_files={'CAN': dbc_path})
        decoded.save(output_path, overwrite=True)
        mdf.close()
        decoded.close()

        self.logger.info(f"Decoded {mdf_path} with DBC to {output_path}")

        return {'status': 'OK'}

    def _handle_ping(self, params):
        """Ping handler"""
        return {'status': 'OK', 'message': 'pong'}

    def _encode_array(self, arr):
        """Encode numpy array to base64 string"""
        if arr is None or len(arr) == 0:
            return ''

        buffer = io.BytesIO()
        np.save(buffer, arr, allow_pickle=False)
        return base64.b64encode(buffer.getvalue()).decode('utf-8')

    def _decode_array(self, b64_str):
        """Decode base64 string to numpy array"""
        if not b64_str:
            return np.array([])

        buffer = io.BytesIO(base64.b64decode(b64_str))
        return np.load(buffer, allow_pickle=False)
