package com.example.mdf4.pool;

import com.example.mdf4.exception.MDF4Exception;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * MDF4连接池
 * <p>
 * 基于Apache Commons Pool2实现的连接池，用于管理MDF4连接对象。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4ConnectionPool {
    private static final Logger logger = LoggerFactory.getLogger(MDF4ConnectionPool.class);

    private final GenericObjectPool<MDF4Connection> pool;
    private final MDF4ConnectionFactory factory;

    public MDF4ConnectionPool(MDF4ConnectionFactory factory, PoolConfig config) {
        this.factory = factory;

        GenericObjectPoolConfig<MDF4Connection> poolConfig = new GenericObjectPoolConfig<>();
        poolConfig.setMaxTotal(config.getMaxConnections());
        poolConfig.setMaxIdle(config.getMaxIdle());
        poolConfig.setMinIdle(config.getMinIdle());
        poolConfig.setMaxWaitMillis(config.getMaxWaitMillis());
        poolConfig.setTestOnBorrow(true);
        poolConfig.setTestOnReturn(true);
        poolConfig.setTestWhileIdle(true);
        poolConfig.setTimeBetweenEvictionRunsMillis(30000); // 30秒检查一次
        poolConfig.setMinEvictableIdleTimeMillis(config.getIdleTimeoutMillis());

        this.pool = new GenericObjectPool<>(factory, poolConfig);

        logger.info("MDF4ConnectionPool created with config: {}", config);
    }

    /**
     * 获取连接（阻塞）
     *
     * @return MDF4连接
     * @throws MDF4Exception 如果获取失败
     */
    public MDF4Connection borrowConnection() throws MDF4Exception {
        try {
            MDF4Connection conn = pool.borrowObject();
            conn.setInUse(true);
            logger.debug("Connection borrowed: {}", conn.getConnectionId());
            return conn;
        } catch (Exception e) {
            throw new MDF4Exception("Failed to borrow connection", e);
        }
    }

    /**
     * 获取连接（带超时）
     *
     * @param timeout 超时时间
     * @param unit    时间单位
     * @return MDF4连接
     * @throws MDF4Exception 如果获取失败或超时
     */
    public MDF4Connection borrowConnection(long timeout, TimeUnit unit) throws MDF4Exception {
        try {
            MDF4Connection conn = pool.borrowObject(unit.toMillis(timeout));
            conn.setInUse(true);
            logger.debug("Connection borrowed: {}", conn.getConnectionId());
            return conn;
        } catch (Exception e) {
            throw new MDF4Exception("Failed to borrow connection within timeout", e);
        }
    }

    /**
     * 归还连接
     *
     * @param connection 连接对象
     */
    public void returnConnection(MDF4Connection connection) {
        if (connection != null) {
            connection.setInUse(false);
            pool.returnObject(connection);
            logger.debug("Connection returned: {}", connection.getConnectionId());
        }
    }

    /**
     * 关闭连接池
     */
    public void shutdown() {
        logger.info("Shutting down MDF4ConnectionPool...");
        pool.close();
        logger.info("MDF4ConnectionPool shut down");
    }

    /**
     * 获取活跃连接数
     *
     * @return 活跃连接数
     */
    public int getActiveCount() {
        return pool.getNumActive();
    }

    /**
     * 获取空闲连接数
     *
     * @return 空闲连接数
     */
    public int getIdleCount() {
        return pool.getNumIdle();
    }

    /**
     * 获取总连接数
     *
     * @return 总连接数
     */
    public int getTotalCount() {
        return pool.getNumActive() + pool.getNumIdle();
    }
}
