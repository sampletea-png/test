package com.example.mdf4.protocol;

import java.util.List;
import java.util.Map;

/**
 * MDF4响应协议
 * <p>
 * 用于封装Python服务返回的响应。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Response {
    private String status;
    private String message;
    private String fileId;
    private Map<String, Object> data;

    public MDF4Response() {
    }

    // Getters and Setters

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    // Helper methods

    @SuppressWarnings("unchecked")
    public String getString(String key) {
        if (data == null) return null;
        Object value = data.get(key);
        return value != null ? value.toString() : null;
    }

    public int getInt(String key, int defaultValue) {
        if (data == null) return defaultValue;
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return defaultValue;
    }

    public long getLong(String key, long defaultValue) {
        if (data == null) return defaultValue;
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        return defaultValue;
    }

    public double getDouble(String key, double defaultValue) {
        if (data == null) return defaultValue;
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return defaultValue;
    }

    @SuppressWarnings("unchecked")
    public List<String> getSignalNames() {
        if (data == null) return null;
        Object value = data.get("signal_names");
        if (value instanceof List) {
            return (List<String>) value;
        }
        return null;
    }
}
