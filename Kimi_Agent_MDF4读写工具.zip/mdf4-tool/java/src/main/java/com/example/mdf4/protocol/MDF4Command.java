package com.example.mdf4.protocol;

import java.util.Map;

/**
 * MDF4命令协议
 * <p>
 * 用于封装发送给Python服务的命令。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Command {
    private String type;
    private Map<String, Object> params;

    public MDF4Command() {
    }

    public MDF4Command(String type, Map<String, Object> params) {
        this.type = type;
        this.params = params;
    }

    // Getters and Setters

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }
}
