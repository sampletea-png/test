package com.example.mdf4.pool;

import com.example.mdf4.protocol.MDF4Command;
import com.example.mdf4.protocol.MDF4Response;
import com.example.mdf4.util.GsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;

/**
 * MDF4连接对象
 * <p>
 * 包装Socket连接，提供线程安全的命令执行能力。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Connection implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(MDF4Connection.class);

    private final String connectionId;
    private final Socket socket;
    private final PrintWriter out;
    private final BufferedReader in;
    private final long createTime;
    private volatile long lastUseTime;
    private volatile boolean valid = true;
    private volatile boolean inUse = false;

    // 线程本地存储的打开文件映射 (fileId -> filePath)
    private final ConcurrentHashMap<String, String> openFiles = new ConcurrentHashMap<>();

    public MDF4Connection(String connectionId, Socket socket) throws IOException {
        this.connectionId = connectionId;
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.createTime = System.currentTimeMillis();
        this.lastUseTime = createTime;
    }

    /**
     * 执行命令（线程安全）
     *
     * @param command 命令对象
     * @return 响应对象
     * @throws IOException 如果执行失败
     */
    public synchronized MDF4Response execute(MDF4Command command) throws IOException {
        if (!valid) {
            throw new IOException("Connection is invalid");
        }

        try {
            // 发送命令
            String json = GsonUtils.toJson(command);
            byte[] data = json.getBytes(StandardCharsets.UTF_8);

            // 发送长度 + 数据
            synchronized (this) {
                socket.getOutputStream().write(intToBytes(data.length));
                socket.getOutputStream().write(data);
                socket.getOutputStream().flush();

                // 读取响应长度
                byte[] lengthBytes = readNBytes(4);
                int responseLength = bytesToInt(lengthBytes);

                // 读取响应数据
                byte[] responseBytes = readNBytes(responseLength);

                String responseJson = new String(responseBytes, StandardCharsets.UTF_8);
                lastUseTime = System.currentTimeMillis();

                return GsonUtils.fromJson(responseJson, MDF4Response.class);
            }
        } catch (Exception e) {
            valid = false;
            throw new IOException("Command execution failed", e);
        }
    }

    /**
     * 注册打开的文件
     *
     * @param fileId   文件ID
     * @param filePath 文件路径
     */
    public void registerOpenFile(String fileId, String filePath) {
        openFiles.put(fileId, filePath);
    }

    /**
     * 注销打开的文件
     *
     * @param fileId 文件ID
     */
    public void unregisterOpenFile(String fileId) {
        openFiles.remove(fileId);
    }

    /**
     * 关闭所有打开的文件
     */
    public void closeAllFiles() {
        for (String fileId : openFiles.keySet()) {
            try {
                MDF4Command command = new MDF4Command();
                command.setType("CLOSE");
                command.setParams(java.util.Collections.singletonMap("file_id", fileId));
                execute(command);
            } catch (Exception e) {
                // 忽略关闭错误
                logger.warn("Error closing file {}: {}", fileId, e.getMessage());
            }
        }
        openFiles.clear();
    }

    @Override
    public void close() {
        closeAllFiles();
        valid = false;
        try {
            socket.close();
            logger.debug("Connection {} closed", connectionId);
        } catch (IOException e) {
            // 忽略
        }
    }

    // Getters

    public boolean isValid() {
        return valid && socket.isConnected() && !socket.isClosed();
    }

    public boolean isInUse() {
        return inUse;
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }

    public long getIdleTime() {
        return System.currentTimeMillis() - lastUseTime;
    }

    public String getConnectionId() {
        return connectionId;
    }

    public long getCreateTime() {
        return createTime;
    }

    // Helper methods

    private byte[] intToBytes(int value) {
        return new byte[]{
                (byte) (value >>> 24),
                (byte) (value >>> 16),
                (byte) (value >>> 8),
                (byte) value
        };
    }

    private int bytesToInt(byte[] bytes) {
        return ((bytes[0] & 0xFF) << 24) |
                ((bytes[1] & 0xFF) << 16) |
                ((bytes[2] & 0xFF) << 8) |
                (bytes[3] & 0xFF);
    }

    private byte[] readNBytes(int n) throws IOException {
        byte[] data = new byte[n];
        int totalRead = 0;
        while (totalRead < n) {
            int read = socket.getInputStream().read(data, totalRead, n - totalRead);
            if (read == -1) {
                throw new IOException("Connection closed while reading");
            }
            totalRead += read;
        }
        return data;
    }
}
