package com.example.mdf4;

import com.example.mdf4.exception.MDF4Exception;
import com.example.mdf4.model.MDF4Info;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.MDF4Connection;
import com.example.mdf4.protocol.MDF4Command;
import com.example.mdf4.protocol.MDF4Response;
import com.example.mdf4.util.GsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MDF4读取器 - 线程安全
 * <p>
 * 用于从MDF4文件中读取信号数据。支持：
 * - 单信号读取
 * - 批量信号读取
 * - 流式分块读取（大数据量）
 * - 时间范围过滤
 * </p>
 *
 * <p><b>使用示例：</b></p>
 * <pre>
 * try (MDF4Reader reader = MDF4ServiceManager.getInstance().createReader()) {
 *     String fileId = reader.open("/data/measurement.mf4");
 *     SignalData data = reader.readSignal(fileId, "EngineSpeed");
 *     reader.close(fileId);
 * }
 * </pre>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Reader implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(MDF4Reader.class);

    private final MDF4ServiceManager manager;
    private final List<String> openedFiles = new CopyOnWriteArrayList<>();
    private final Map<String, ReentrantReadWriteLock.ReadLock> heldLocks = new HashMap<>();

    public MDF4Reader(MDF4ServiceManager manager) {
        this.manager = manager;
    }

    /**
     * 打开文件用于读取
     * <p>
     * 此方法会获取文件的读锁，允许多个线程同时读取同一文件。
     * </p>
     *
     * @param filePath MDF4文件路径
     * @return 文件ID，用于后续操作
     * @throws MDF4Exception 如果打开失败
     */
    public String open(String filePath) throws MDF4Exception {
        // 获取读锁
        ReentrantReadWriteLock.ReadLock lock = manager.acquireReadLock(filePath);

        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            MDF4Command command = new MDF4Command("OPEN_READ",
                    Collections.singletonMap("file_path", filePath)
            );

            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to open file: " + response.getMessage());
            }

            String fileId = response.getFileId();
            conn.registerOpenFile(fileId, filePath);
            openedFiles.add(filePath);
            heldLocks.put(filePath, lock);

            logger.debug("Opened file for reading: {} (fileId={})", filePath, fileId);
            return fileId;

        } catch (Exception e) {
            manager.releaseLock(filePath);
            throw new MDF4Exception("Failed to open file: " + filePath, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 获取所有信号名称
     *
     * @param fileId 文件ID
     * @return 信号名称列表
     * @throws MDF4Exception 如果获取失败
     */
    public List<String> getSignalNames(String fileId) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            MDF4Command command = new MDF4Command("GET_SIGNALS",
                    Collections.singletonMap("file_id", fileId)
            );

            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to get signal names: " + response.getMessage());
            }

            return response.getSignalNames();

        } catch (Exception e) {
            throw new MDF4Exception("Failed to get signal names", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 读取单个信号数据
     *
     * @param fileId     文件ID
     * @param signalName 信号名称
     * @return 信号数据
     * @throws MDF4Exception 如果读取失败
     */
    public SignalData readSignal(String fileId, String signalName) throws MDF4Exception {
        return readSignal(fileId, signalName, null, null);
    }

    /**
     * 读取信号数据（带时间范围）
     *
     * @param fileId     文件ID
     * @param signalName 信号名称
     * @param startTime  开始时间（秒），null表示从头开始
     * @param endTime    结束时间（秒），null表示到末尾
     * @return 信号数据
     * @throws MDF4Exception 如果读取失败
     */
    public SignalData readSignal(String fileId, String signalName,
                                  Double startTime, Double endTime) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("file_id", fileId);
            params.put("signal_name", signalName);
            if (startTime != null) params.put("start_time", startTime);
            if (endTime != null) params.put("end_time", endTime);

            MDF4Command command = new MDF4Command("READ_SIGNAL", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to read signal: " + response.getMessage());
            }

            return decodeSignalData(response);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to read signal: " + signalName, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 批量读取信号（更高效）
     *
     * @param fileId      文件ID
     * @param signalNames 信号名称列表
     * @return 信号名称到数据的映射
     * @throws MDF4Exception 如果读取失败
     */
    public Map<String, SignalData> readSignals(String fileId, List<String> signalNames)
            throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("file_id", fileId);
            params.put("signal_names", signalNames);

            MDF4Command command = new MDF4Command("READ_SIGNALS_BATCH", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to read signals: " + response.getMessage());
            }

            return decodeBatchSignalData(response);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to read signals batch", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 流式读取信号（大数据量）
     * <p>
     * 此方法会分块读取信号数据，通过回调函数处理每个数据块，
     * 适用于处理大数据量信号，避免内存溢出。
     * </p>
     *
     * @param fileId     文件ID
     * @param signalName 信号名称
     * @param consumer   数据块消费者
     * @throws MDF4Exception 如果读取失败
     */
    public void readSignalStream(String fileId, String signalName,
                                  SignalDataConsumer consumer) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            // 先获取信号总信息
            MDF4Command infoCmd = new MDF4Command("GET_SIGNAL_INFO",
                    Map.of("file_id", fileId, "signal_name", signalName)
            );
            MDF4Response infoResponse = conn.execute(infoCmd);

            if (!"OK".equals(infoResponse.getStatus())) {
                throw new MDF4Exception("Failed to get signal info: " + infoResponse.getMessage());
            }

            long totalSamples = infoResponse.getSampleCount();
            int chunkSize = 10000;

            for (long offset = 0; offset < totalSamples; offset += chunkSize) {
                Map<String, Object> params = new HashMap<>();
                params.put("file_id", fileId);
                params.put("signal_name", signalName);
                params.put("offset", offset);
                params.put("limit", chunkSize);

                MDF4Command readCmd = new MDF4Command("READ_SIGNAL_CHUNK", params);
                MDF4Response response = conn.execute(readCmd);

                if (!"OK".equals(response.getStatus())) {
                    throw new MDF4Exception("Failed to read signal chunk: " + response.getMessage());
                }

                SignalData chunk = decodeSignalData(response);

                // 回调处理数据块
                boolean continueReading = consumer.consume(chunk, offset, totalSamples);
                if (!continueReading) {
                    logger.debug("Signal stream reading stopped by consumer at offset {}", offset);
                    break;
                }
            }

        } catch (Exception e) {
            throw new MDF4Exception("Failed to stream signal: " + signalName, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 获取文件信息
     *
     * @param fileId 文件ID
     * @return 文件信息
     * @throws MDF4Exception 如果获取失败
     */
    public MDF4Info getInfo(String fileId) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            MDF4Command command = new MDF4Command("GET_INFO",
                    Collections.singletonMap("file_id", fileId)
            );

            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to get file info: " + response.getMessage());
            }

            return decodeFileInfo(response);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to get file info", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 关闭文件
     *
     * @param fileId 文件ID
     */
    public void close(String fileId) {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            MDF4Command command = new MDF4Command("CLOSE",
                    Collections.singletonMap("file_id", fileId)
            );

            conn.execute(command);
            conn.unregisterOpenFile(fileId);

            // 找到并释放对应的文件锁
            String filePathToRelease = null;
            for (String path : openedFiles) {
                if (heldLocks.containsKey(path)) {
                    filePathToRelease = path;
                    break;
                }
            }

            if (filePathToRelease != null) {
                heldLocks.remove(filePathToRelease);
                manager.releaseLock(filePathToRelease);
                openedFiles.remove(filePathToRelease);
            }

            logger.debug("Closed file: {}", fileId);

        } catch (Exception e) {
            logger.warn("Error closing file: {}", fileId, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    @Override
    public void close() {
        // 关闭所有打开的文件
        for (String filePath : new ArrayList<>(openedFiles)) {
            manager.releaseLock(filePath);
        }
        openedFiles.clear();
        heldLocks.clear();
    }

    /**
     * 解码信号数据
     */
    private SignalData decodeSignalData(MDF4Response response) {
        SignalData data = new SignalData();
        data.setName(response.getString("name"));
        data.setUnit(response.getString("unit"));
        data.setDescription(response.getString("description"));
        data.setDataType(response.getString("data_type"));

        // 解码时间戳数组
        String timestampsBase64 = response.getString("timestamps");
        if (timestampsBase64 != null) {
            data.setTimestamps(decodeBase64Array(timestampsBase64));
        }

        // 解码采样值数组
        String samplesBase64 = response.getString("samples");
        if (samplesBase64 != null) {
            data.setSamples(decodeBase64Array(samplesBase64));
        }

        return data;
    }

    /**
     * 解码批量信号数据
     */
    private Map<String, SignalData> decodeBatchSignalData(MDF4Response response) {
        Map<String, SignalData> result = new HashMap<>();

        @SuppressWarnings("unchecked")
        Map<String, Map<String, Object>> signalsData =
                (Map<String, Map<String, Object>>) response.getData().get("signals");

        if (signalsData != null) {
            for (Map.Entry<String, Map<String, Object>> entry : signalsData.entrySet()) {
                MDF4Response signalResponse = new MDF4Response();
                signalResponse.setStatus("OK");
                signalResponse.setData(entry.getValue());
                result.put(entry.getKey(), decodeSignalData(signalResponse));
            }
        }

        return result;
    }

    /**
     * 解码文件信息
     */
    private MDF4Info decodeFileInfo(MDF4Response response) {
        MDF4Info info = new MDF4Info();
        info.setVersion(response.getString("version"));
        info.setChannelGroupCount(response.getInt("channel_group_count", 0));
        info.setChannelCount(response.getInt("channel_count", 0));
        info.setRecordCount(response.getLong("record_count", 0L));
        info.setStartTime(response.getString("start_time"));
        info.setDuration(response.getDouble("duration", 0.0));
        return info;
    }

    /**
     * 解码Base64编码的数组
     */
    private double[] decodeBase64Array(String base64) {
        try {
            byte[] bytes = Base64.getDecoder().decode(base64);
            ByteBuffer buffer = ByteBuffer.wrap(bytes);
            int length = bytes.length / 8; // double是8字节
            double[] result = new double[length];
            for (int i = 0; i < length; i++) {
                result[i] = buffer.getDouble(i * 8);
            }
            return result;
        } catch (Exception e) {
            logger.error("Failed to decode base64 array", e);
            return new double[0];
        }
    }
}
