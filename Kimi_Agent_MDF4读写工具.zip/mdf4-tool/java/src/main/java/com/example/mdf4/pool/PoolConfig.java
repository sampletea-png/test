package com.example.mdf4.pool;

/**
 * 连接池配置
 * <p>
 * 用于配置MDF4连接池的参数。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class PoolConfig {

    // 默认配置值
    private static final int DEFAULT_MAX_CONNECTIONS = Runtime.getRuntime().availableProcessors() * 2;
    private static final int DEFAULT_MAX_IDLE = DEFAULT_MAX_CONNECTIONS;
    private static final int DEFAULT_MIN_IDLE = 2;
    private static final long DEFAULT_MAX_WAIT_MILLIS = 30000;
    private static final long DEFAULT_IDLE_TIMEOUT_MILLIS = 60000;
    private static final long DEFAULT_MAX_LIFETIME_MILLIS = 300000;

    private int maxConnections = DEFAULT_MAX_CONNECTIONS;
    private int maxIdle = DEFAULT_MAX_IDLE;
    private int minIdle = DEFAULT_MIN_IDLE;
    private long maxWaitMillis = DEFAULT_MAX_WAIT_MILLIS;
    private long idleTimeoutMillis = DEFAULT_IDLE_TIMEOUT_MILLIS;
    private long maxLifetimeMillis = DEFAULT_MAX_LIFETIME_MILLIS;

    public PoolConfig() {
    }

    // Getters and Setters

    public int getMaxConnections() {
        return maxConnections;
    }

    public void setMaxConnections(int maxConnections) {
        this.maxConnections = maxConnections;
    }

    public int getMaxIdle() {
        return maxIdle;
    }

    public void setMaxIdle(int maxIdle) {
        this.maxIdle = maxIdle;
    }

    public int getMinIdle() {
        return minIdle;
    }

    public void setMinIdle(int minIdle) {
        this.minIdle = minIdle;
    }

    public long getMaxWaitMillis() {
        return maxWaitMillis;
    }

    public void setMaxWaitMillis(long maxWaitMillis) {
        this.maxWaitMillis = maxWaitMillis;
    }

    public long getIdleTimeoutMillis() {
        return idleTimeoutMillis;
    }

    public void setIdleTimeoutMillis(long idleTimeoutMillis) {
        this.idleTimeoutMillis = idleTimeoutMillis;
    }

    public long getMaxLifetimeMillis() {
        return maxLifetimeMillis;
    }

    public void setMaxLifetimeMillis(long maxLifetimeMillis) {
        this.maxLifetimeMillis = maxLifetimeMillis;
    }

    @Override
    public String toString() {
        return "PoolConfig{" +
                "maxConnections=" + maxConnections +
                ", maxIdle=" + maxIdle +
                ", minIdle=" + minIdle +
                ", maxWaitMillis=" + maxWaitMillis +
                ", idleTimeoutMillis=" + idleTimeoutMillis +
                ", maxLifetimeMillis=" + maxLifetimeMillis +
                '}';
    }
}
