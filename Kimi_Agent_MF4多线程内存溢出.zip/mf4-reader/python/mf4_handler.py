"""
MF4文件处理模块 - 处理MF4文件的具体操作（支持大文件流式读取）
"""
import os
import threading
import uuid
import gc
import sys
from typing import Dict, List, Optional, Any, Iterator, Tuple
from dataclasses import dataclass
from enum import Enum
import numpy as np

from asammdf import MDF
from asammdf.blocks.mdf_v4 import MDF4

import logging

logger = logging.getLogger('mf4_server')


class WriteMode(Enum):
    """写入模式枚举"""
    APPEND = "append"      # 追加到现有通道
    OVERWRITE = "overwrite"  # 覆盖现有通道
    CREATE_NEW = "create_new"  # 创建新通道（如果存在则报错）


@dataclass
class FileHandle:
    """文件句柄封装类"""
    file_id: str
    file_path: str
    mdf: MDF
    mode: str  # 'r', 'w', 'rw'
    ref_count: int = 0  # 引用计数
    lock: threading.RLock = None
    
    def __post_init__(self):
        if self.lock is None:
            self.lock = threading.RLock()


class MemoryMonitor:
    """内存监控器 - 防止内存溢出"""
    
    # 默认最大内存使用限制 (512MB)
    DEFAULT_MAX_MEMORY_MB = 512
    
    def __init__(self, max_memory_mb: int = None):
        self.max_memory_bytes = (max_memory_mb or self.DEFAULT_MAX_MEMORY_MB) * 1024 * 1024
        
    def check_memory_usage(self) -> Tuple[bool, int]:
        """
        检查当前内存使用情况
        
        Returns:
            (是否安全, 当前使用字节数)
        """
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            used_bytes = memory_info.rss
            
            is_safe = used_bytes < self.max_memory_bytes
            if not is_safe:
                logger.warning(f"Memory usage ({used_bytes / 1024 / 1024:.1f}MB) exceeds limit "
                             f"({self.max_memory_bytes / 1024 / 1024:.1f}MB)")
            
            return is_safe, used_bytes
        except ImportError:
            # 如果没有psutil，假设安全
            return True, 0
    
    def force_gc(self):
        """强制垃圾回收"""
        gc.collect()
        logger.debug("Forced garbage collection")


class DataChunker:
    """数据分块器 - 将大数据分割成小块"""
    
    # 默认每块最大样本数 (10万样本)
    DEFAULT_SAMPLES_PER_CHUNK = 100000
    
    # 默认每块最大数据量 (10MB)
    DEFAULT_BYTES_PER_CHUNK = 10 * 1024 * 1024
    
    def __init__(self, samples_per_chunk: int = None, bytes_per_chunk: int = None):
        self.samples_per_chunk = samples_per_chunk or self.DEFAULT_SAMPLES_PER_CHUNK
        self.bytes_per_chunk = bytes_per_chunk or self.DEFAULT_BYTES_PER_CHUNK
    
    def estimate_chunk_size(self, sample_count: int, dtype_size: int = 8) -> int:
        """
        估算合适的分块大小
        
        Args:
            sample_count: 总样本数
            dtype_size: 每个样本的字节数
            
        Returns:
            每块样本数
        """
        # 基于样本数限制
        samples_limit = self.samples_per_chunk
        
        # 基于内存限制
        bytes_per_sample = dtype_size * 2  # timestamps + values
        memory_limit = self.bytes_per_chunk // bytes_per_sample
        
        return min(samples_limit, memory_limit, sample_count)
    
    def create_chunks(self, data: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
        """
        将数据分块
        
        Args:
            data: 包含timestamps和values的数据字典
            
        Yields:
            数据块字典
        """
        timestamps = data.get('timestamps', [])
        values = data.get('values', [])
        
        if not timestamps:
            yield data
            return
        
        total_samples = len(timestamps)
        chunk_size = self.estimate_chunk_size(total_samples)
        
        name = data.get('name', '')
        unit = data.get('unit', '')
        
        for i in range(0, total_samples, chunk_size):
            end_idx = min(i + chunk_size, total_samples)
            
            chunk = {
                'timestamps': timestamps[i:end_idx],
                'values': values[i:end_idx],
                'name': name,
                'unit': unit,
                'sampleCount': end_idx - i,
                'chunkIndex': i // chunk_size,
                'totalChunks': (total_samples + chunk_size - 1) // chunk_size,
                'startOffset': i
            }
            
            yield chunk
    
    def create_iterator(self, file_id: str, group_index: int, channel_index: int,
                        handle: FileHandle, start: float = None, end: float = None,
                        samples: int = None) -> Iterator[Dict[str, Any]]:
        """
        创建数据迭代器 - 惰性加载数据
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_index: 通道索引
            handle: 文件句柄
            start: 开始时间
            end: 结束时间
            samples: 采样点数限制
            
        Yields:
            数据块
        """
        try:
            signal = handle.mdf.get(
                group=group_index,
                index=channel_index,
                samples_only=False
            )
            
            timestamps = signal.timestamps
            values = signal.samples
            
            # 应用时间过滤
            if start is not None or end is not None:
                mask = np.ones(len(timestamps), dtype=bool)
                if start is not None:
                    mask &= timestamps >= start
                if end is not None:
                    mask &= timestamps <= end
                timestamps = timestamps[mask]
                values = values[mask]
                del mask  # 立即释放
            
            # 应用采样限制
            if samples is not None and len(timestamps) > samples:
                timestamps = timestamps[:samples]
                values = values[:samples]
            
            total_samples = len(timestamps)
            chunk_size = self.estimate_chunk_size(total_samples)
            
            name = signal.name
            unit = signal.unit if hasattr(signal, 'unit') else ''
            total_chunks = (total_samples + chunk_size - 1) // chunk_size
            
            # 分块yield数据
            for i in range(0, total_samples, chunk_size):
                end_idx = min(i + chunk_size, total_samples)
                
                chunk = {
                    'timestamps': timestamps[i:end_idx].tolist(),
                    'values': values[i:end_idx].tolist() if not isinstance(values[i:end_idx], np.ndarray) 
                             else values[i:end_idx].tolist(),
                    'name': name,
                    'unit': unit,
                    'sampleCount': end_idx - i,
                    'chunkIndex': i // chunk_size,
                    'totalChunks': total_chunks,
                    'startOffset': i,
                    'fileId': file_id,
                    'groupIndex': group_index,
                    'channelIndex': channel_index
                }
                
                yield chunk
                
                # 每yield一块后强制垃圾回收
                if i // chunk_size % 10 == 0:
                    gc.collect()
                    
        except Exception as e:
            logger.error(f"Error creating iterator for {file_id}: {e}")
            raise


class Mf4FileManager:
    """MF4文件管理器 - 管理所有打开的文件句柄（支持大文件）"""
    
    # 默认单次读取最大样本数 (100万)
    DEFAULT_MAX_SAMPLES_PER_READ = 1000000
    
    # 默认单次读取最大数据量 (100MB)
    DEFAULT_MAX_BYTES_PER_READ = 100 * 1024 * 1024
    
    def __init__(self, max_memory_mb: int = None):
        # 文件句柄映射: file_id -> FileHandle
        self._files: Dict[str, FileHandle] = {}
        # 路径到file_id的映射: file_path -> set(file_id)
        self._path_to_ids: Dict[str, set] = {}
        # 全局锁
        self._global_lock = threading.RLock()
        
        # 内存监控
        self._memory_monitor = MemoryMonitor(max_memory_mb)
        
        # 数据分块器
        self._chunker = DataChunker()
        
        # 迭代器存储（用于流式读取）
        self._iterators: Dict[str, Iterator] = {}
        self._iterator_lock = threading.RLock()
    
    def open_file(self, file_path: str, mode: str = 'r', create_if_not_exists: bool = False) -> str:
        """
        打开MF4文件
        
        Args:
            file_path: 文件路径
            mode: 打开模式 ('r', 'w', 'rw')
            create_if_not_exists: 文件不存在时是否创建
            
        Returns:
            file_id: 文件唯一标识
        """
        with self._global_lock:
            # 检查内存使用
            is_safe, memory_used = self._memory_monitor.check_memory_usage()
            if not is_safe:
                self._memory_monitor.force_gc()
                logger.warning(f"Memory pressure detected ({memory_used / 1024 / 1024:.1f}MB), "
                             "forced garbage collection")
            
            # 检查文件是否存在
            file_exists = os.path.exists(file_path)
            
            if not file_exists and mode == 'r' and not create_if_not_exists:
                raise FileNotFoundError(f"File not found: {file_path}")
            
            # 如果文件已打开，增加引用计数
            if file_path in self._path_to_ids:
                for file_id in self._path_to_ids[file_path]:
                    handle = self._files.get(file_id)
                    if handle and handle.mode == mode:
                        with handle.lock:
                            handle.ref_count += 1
                        logger.info(f"Reused file handle: {file_id}, ref_count: {handle.ref_count}")
                        return file_id
            
            # 创建新的文件句柄
            file_id = str(uuid.uuid4())
            
            try:
                if mode == 'w' or (mode == 'rw' and not file_exists and create_if_not_exists):
                    # 创建新文件
                    mdf = MDF(version='4.11')
                else:
                    # 打开现有文件 - 使用内存映射模式
                    mdf = MDF(file_path)
                
                handle = FileHandle(
                    file_id=file_id,
                    file_path=file_path,
                    mdf=mdf,
                    mode=mode
                )
                handle.ref_count = 1
                
                self._files[file_id] = handle
                
                if file_path not in self._path_to_ids:
                    self._path_to_ids[file_path] = set()
                self._path_to_ids[file_path].add(file_id)
                
                logger.info(f"Opened file: {file_path}, mode: {mode}, file_id: {file_id}")
                return file_id
                
            except Exception as e:
                logger.error(f"Failed to open file {file_path}: {e}")
                raise
    
    def close_file(self, file_id: str) -> bool:
        """
        关闭文件
        
        Args:
            file_id: 文件唯一标识
            
        Returns:
            是否成功关闭
        """
        with self._global_lock:
            handle = self._files.get(file_id)
            if not handle:
                logger.warning(f"File not found for closing: {file_id}")
                return False
            
            with handle.lock:
                handle.ref_count -= 1
                
                if handle.ref_count <= 0:
                    try:
                        handle.mdf.close()
                        logger.info(f"Closed file: {handle.file_path}, file_id: {file_id}")
                    except Exception as e:
                        logger.error(f"Error closing file {file_id}: {e}")
                    finally:
                        del self._files[file_id]
                        self._path_to_ids[handle.file_path].discard(file_id)
                        if not self._path_to_ids[handle.file_path]:
                            del self._path_to_ids[handle.file_path]
                        
                        # 清理相关迭代器
                        with self._iterator_lock:
                            iterator_keys = [k for k in self._iterators.keys() if k.startswith(file_id)]
                            for key in iterator_keys:
                                del self._iterators[key]
                        
                        # 强制垃圾回收
                        gc.collect()
                else:
                    logger.info(f"Decreased ref_count for {file_id}: {handle.ref_count}")
            
            return True
    
    def get_file_info(self, file_id: str) -> Dict[str, Any]:
        """获取文件信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            info = {
                'filePath': handle.file_path,
                'mode': handle.mode,
                'version': handle.mdf.version_str if hasattr(handle.mdf, 'version_str') else 'unknown',
                'channelCount': len(handle.mdf.channels_db) if hasattr(handle.mdf, 'channels_db') else 0,
            }
            
            # 获取通道组信息
            groups = []
            if hasattr(handle.mdf, 'groups'):
                for i, group in enumerate(handle.mdf.groups):
                    group_info = {
                        'index': i,
                        'channelCount': len(group.channels) if hasattr(group, 'channels') else 0
                    }
                    groups.append(group_info)
            
            info['groups'] = groups
            return info
    
    def get_channels(self, file_id: str, group_index: int = None) -> List[Dict[str, Any]]:
        """获取通道列表（基础信息）"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            channels = []
            
            if hasattr(handle.mdf, 'groups'):
                groups_to_process = [handle.mdf.groups[group_index]] if group_index is not None else handle.mdf.groups
                
                for g_idx, group in enumerate(groups_to_process):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            ch_info = {
                                'name': channel.name if hasattr(channel, 'name') else f'Channel_{c_idx}',
                                'groupIndex': g_idx if group_index is None else group_index,
                                'channelIndex': c_idx,
                            }
                            
                            # 添加更多通道信息
                            if hasattr(channel, 'unit'):
                                ch_info['unit'] = channel.unit
                            if hasattr(channel, 'comment'):
                                ch_info['comment'] = str(channel.comment) if channel.comment else ''
                            
                            channels.append(ch_info)
            
            return channels
    
    def get_channel_info(self, file_id: str, group_index: int, channel_index: int) -> Dict[str, Any]:
        """
        获取指定通道的详细信息
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_index: 通道索引
            
        Returns:
            通道详细信息字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            if not hasattr(handle.mdf, 'groups'):
                raise ValueError("File has no channel groups")
            
            if group_index >= len(handle.mdf.groups):
                raise ValueError(f"Group index {group_index} out of range")
            
            group = handle.mdf.groups[group_index]
            
            if not hasattr(group, 'channels'):
                raise ValueError("Group has no channels")
            
            if channel_index >= len(group.channels):
                raise ValueError(f"Channel index {channel_index} out of range")
            
            channel = group.channels[channel_index]
            
            # 获取通道详细信息
            info = {
                'name': channel.name if hasattr(channel, 'name') else f'Channel_{channel_index}',
                'groupIndex': group_index,
                'channelIndex': channel_index,
            }
            
            # 基本信息
            if hasattr(channel, 'unit'):
                info['unit'] = channel.unit
            if hasattr(channel, 'comment'):
                info['comment'] = str(channel.comment) if channel.comment else ''
            
            # 数据类型信息
            if hasattr(channel, 'dtype'):
                info['dataType'] = str(channel.dtype)
            
            # 采样信息
            if hasattr(channel, 'samples'):
                info['sampleCount'] = len(channel.samples) if hasattr(channel.samples, '__len__') else 0
            
            # 时间信息
            if hasattr(channel, 'timestamp'):
                ts = channel.timestamp
                if hasattr(ts, '__len__') and len(ts) > 0:
                    info['startTime'] = float(ts[0]) if hasattr(ts[0], 'item') else ts[0]
                    info['endTime'] = float(ts[-1]) if hasattr(ts[-1], 'item') else ts[-1]
            
            # 其他元数据
            if hasattr(channel, 'conversion'):
                conv = channel.conversion
                if conv is not None:
                    info['conversion'] = {
                        'type': type(conv).__name__ if hasattr(conv, '__class__') else 'unknown'
                    }
            
            if hasattr(channel, 'source'):
                src = channel.source
                if src is not None:
                    info['source'] = str(src)
            
            # 信号信息（如果可用）
            try:
                signal = handle.mdf.get(group=group_index, index=channel_index, samples_only=False)
                if signal is not None:
                    info['signalName'] = signal.name
                    if hasattr(signal, 'unit'):
                        info['signalUnit'] = signal.unit
                    if hasattr(signal, 'comment'):
                        info['signalComment'] = str(signal.comment) if signal.comment else ''
                    if hasattr(signal.samples, '__len__'):
                        info['signalSampleCount'] = len(signal.samples)
                    if hasattr(signal, 'timestamps') and hasattr(signal.timestamps, '__len__'):
                        if len(signal.timestamps) > 0:
                            info['signalStartTime'] = float(signal.timestamps[0])
                            info['signalEndTime'] = float(signal.timestamps[-1])
            except Exception as e:
                logger.warning(f"Could not get signal info for channel {channel_index}: {e}")
            
            return info
    
    def find_channel(self, file_id: str, channel_name: str) -> List[Dict[str, Any]]:
        """
        根据名称查找通道
        
        Args:
            file_id: 文件ID
            channel_name: 通道名称（支持部分匹配）
            
        Returns:
            匹配的通道列表
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            results = []
            
            if hasattr(handle.mdf, 'groups'):
                for g_idx, group in enumerate(handle.mdf.groups):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            name = channel.name if hasattr(channel, 'name') else ''
                            
                            # 支持部分匹配
                            if channel_name.lower() in name.lower():
                                ch_info = {
                                    'name': name,
                                    'groupIndex': g_idx,
                                    'channelIndex': c_idx,
                                }
                                
                                if hasattr(channel, 'unit'):
                                    ch_info['unit'] = channel.unit
                                if hasattr(channel, 'comment'):
                                    ch_info['comment'] = str(channel.comment) if channel.comment else ''
                                
                                results.append(ch_info)
            
            return results
    
    def read_data(self, file_id: str, group_index: int, channel_index: int = None,
                  start: float = None, end: float = None, 
                  samples: int = None, chunk_size: int = None,
                  use_iterator: bool = False) -> Dict[str, Any]:
        """
        读取数据（支持大文件分块读取）
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_index: 通道索引，None表示读取整个组
            start: 开始时间
            end: 结束时间
            samples: 采样点数限制（默认最大100万）
            chunk_size: 分段大小（字节）
            use_iterator: 是否使用迭代器模式（用于超大文件）
            
        Returns:
            包含数据和元信息的字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        # 限制单次读取的最大样本数
        if samples is None or samples > self.DEFAULT_MAX_SAMPLES_PER_READ:
            samples = self.DEFAULT_MAX_SAMPLES_PER_READ
        
        # 检查内存使用
        is_safe, _ = self._memory_monitor.check_memory_usage()
        if not is_safe:
            self._memory_monitor.force_gc()
        
        with handle.lock:
            try:
                if use_iterator:
                    # 创建迭代器，用于流式读取
                    iterator_id = f"{file_id}_{group_index}_{channel_index}_{uuid.uuid4().hex[:8]}"
                    iterator = self._chunker.create_iterator(
                        file_id, group_index, channel_index, handle, start, end, samples
                    )
                    
                    with self._iterator_lock:
                        self._iterators[iterator_id] = iterator
                    
                    # 返回第一个块和迭代器ID
                    try:
                        first_chunk = next(iterator)
                        first_chunk['iteratorId'] = iterator_id
                        first_chunk['hasMore'] = True
                        return first_chunk
                    except StopIteration:
                        return {
                            'iteratorId': iterator_id,
                            'hasMore': False,
                            'sampleCount': 0
                        }
                
                # 使用asammdf的get方法读取数据
                if channel_index is not None:
                    # 读取单个通道
                    signal = handle.mdf.get(
                        group=group_index,
                        index=channel_index,
                        samples_only=False
                    )
                    
                    # 应用时间和采样限制
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                        del mask  # 立即释放
                    
                    if samples is not None and len(timestamps) > samples:
                        timestamps = timestamps[:samples]
                        values = values[:samples]
                    
                    # 检查数据大小，如果太大则分块返回
                    total_samples = len(timestamps)
                    estimated_bytes = total_samples * 16  # 假设每个样本16字节（timestamp + value）
                    
                    if estimated_bytes > self.DEFAULT_MAX_BYTES_PER_READ:
                        # 数据太大，使用分块模式
                        logger.info(f"Data size ({estimated_bytes / 1024 / 1024:.1f}MB) exceeds limit, "
                                  "using chunked mode")
                        
                        chunk_samples = self.DEFAULT_MAX_BYTES_PER_READ // 16
                        chunks = []
                        total_chunks = (total_samples + chunk_samples - 1) // chunk_samples
                        
                        # 只返回第一块
                        end_idx = min(chunk_samples, total_samples)
                        first_chunk = {
                            'timestamps': timestamps[:end_idx].tolist(),
                            'values': values[:end_idx].tolist() if not isinstance(values, np.ndarray) 
                                     else values[:end_idx].tolist(),
                            'name': signal.name,
                            'unit': signal.unit if hasattr(signal, 'unit') else '',
                            'sampleCount': end_idx,
                            'chunkIndex': 0,
                            'totalChunks': total_chunks,
                            'hasMore': total_chunks > 1,
                            'startOffset': 0,
                            'totalSamples': total_samples
                        }
                        
                        # 清理内存
                        del timestamps
                        del values
                        gc.collect()
                        
                        return first_chunk
                    
                    result = {
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps),
                        'hasMore': False
                    }
                    
                    # 清理内存
                    del timestamps
                    del values
                    gc.collect()
                    
                    return result
                else:
                    # 读取整个通道组
                    group_data = []
                    total_samples = 0
                    
                    if group_index < len(handle.mdf.groups):
                        group = handle.mdf.groups[group_index]
                        if hasattr(group, 'channels'):
                            # 限制同时读取的通道数
                            max_channels_per_read = 10
                            channels_to_read = min(len(group.channels), max_channels_per_read)
                            
                            for idx in range(channels_to_read):
                                signal = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                
                                timestamps = signal.timestamps
                                values = signal.samples
                                
                                if start is not None or end is not None:
                                    mask = np.ones(len(timestamps), dtype=bool)
                                    if start is not None:
                                        mask &= timestamps >= start
                                    if end is not None:
                                        mask &= timestamps <= end
                                    timestamps = timestamps[mask]
                                    values = values[mask]
                                    del mask
                                
                                if samples is not None and len(timestamps) > samples:
                                    timestamps = timestamps[:samples]
                                    values = values[:samples]
                                
                                channel_samples = len(timestamps)
                                total_samples += channel_samples
                                
                                group_data.append({
                                    'timestamps': timestamps.tolist(),
                                    'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                                    'name': signal.name,
                                    'unit': signal.unit if hasattr(signal, 'unit') else '',
                                    'sampleCount': channel_samples
                                })
                                
                                # 定期清理内存
                                if idx % 5 == 0:
                                    gc.collect()
                    
                    result = {
                        'groupIndex': group_index,
                        'channels': group_data,
                        'channelCount': len(group_data),
                        'totalSamples': total_samples,
                        'hasMore': False
                    }
                    
                    gc.collect()
                    return result
                    
            except Exception as e:
                logger.error(f"Error reading data from file {file_id}: {e}")
                raise
    
    def read_next_chunk(self, iterator_id: str) -> Optional[Dict[str, Any]]:
        """
        读取迭代器的下一个数据块
        
        Args:
            iterator_id: 迭代器ID
            
        Returns:
            数据块，如果没有更多数据则返回None
        """
        with self._iterator_lock:
            iterator = self._iterators.get(iterator_id)
            if iterator is None:
                raise ValueError(f"Iterator not found: {iterator_id}")
            
            try:
                chunk = next(iterator)
                chunk['iteratorId'] = iterator_id
                chunk['hasMore'] = True
                return chunk
            except StopIteration:
                # 迭代器结束，清理
                del self._iterators[iterator_id]
                gc.collect()
                return {
                    'iteratorId': iterator_id,
                    'hasMore': False,
                    'sampleCount': 0
                }
    
    def close_iterator(self, iterator_id: str):
        """关闭迭代器"""
        with self._iterator_lock:
            if iterator_id in self._iterators:
                del self._iterators[iterator_id]
                gc.collect()
    
    def read_batch(self, file_id: str, group_index: int, channel_indices: List[int],
                   start: float = None, end: float = None, max_samples: int = None) -> Dict[str, Any]:
        """
        批量读取多个通道数据（带内存限制）
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_indices: 通道索引列表
            start: 开始时间
            end: 结束时间
            max_samples: 每个通道最大采样数
            
        Returns:
            包含多个通道数据的字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        # 限制参数
        if max_samples is None or max_samples > self.DEFAULT_MAX_SAMPLES_PER_READ:
            max_samples = self.DEFAULT_MAX_SAMPLES_PER_READ
        
        # 限制同时读取的通道数
        max_channels = 10
        if len(channel_indices) > max_channels:
            logger.warning(f"Too many channels ({len(channel_indices)}), limiting to {max_channels}")
            channel_indices = channel_indices[:max_channels]
        
        with handle.lock:
            results = []
            total_samples = 0
            
            for ch_idx in channel_indices:
                try:
                    # 检查内存使用
                    is_safe, _ = self._memory_monitor.check_memory_usage()
                    if not is_safe:
                        self._memory_monitor.force_gc()
                        logger.warning("Memory pressure detected during batch read, forced GC")
                    
                    signal = handle.mdf.get(group=group_index, index=ch_idx, samples_only=False)
                    
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                        del mask
                    
                    if len(timestamps) > max_samples:
                        timestamps = timestamps[:max_samples]
                        values = values[:max_samples]
                    
                    total_samples += len(timestamps)
                    
                    results.append({
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'channelIndex': ch_idx,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps)
                    })
                    
                    # 定期清理
                    if len(results) % 5 == 0:
                        gc.collect()
                        
                except Exception as e:
                    logger.error(f"Error reading channel {ch_idx}: {e}")
                    results.append({
                        'error': str(e),
                        'channelIndex': ch_idx
                    })
            
            result = {
                'groupIndex': group_index,
                'channels': results,
                'channelCount': len(results),
                'totalSamples': total_samples
            }
            
            gc.collect()
            return result
    
    def _channel_exists(self, handle: FileHandle, group_index: int, channel_name: str) -> Tuple[bool, int]:
        """
        检查通道是否已存在
        
        Args:
            handle: 文件句柄
            group_index: 通道组索引
            channel_name: 通道名称
            
        Returns:
            (是否存在, 通道索引)
        """
        if not hasattr(handle.mdf, 'groups'):
            return False, -1
        
        if group_index >= len(handle.mdf.groups):
            return False, -1
        
        group = handle.mdf.groups[group_index]
        if not hasattr(group, 'channels'):
            return False, -1
        
        for idx, channel in enumerate(group.channels):
            name = channel.name if hasattr(channel, 'name') else ''
            if name == channel_name:
                return True, idx
        
        return False, -1
    
    def write_data(self, file_id: str, group_index: int, channel_data: List[Dict[str, Any]],
                   batch_size: int = 10000, write_mode: str = "append") -> Dict[str, Any]:
        """
        写入数据（支持分批写入大文件和覆盖/追加模式）
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引（None则创建新组）
            channel_data: 通道数据列表
            batch_size: 每批写入的最大样本数
            write_mode: 写入模式 - "append"(追加), "overwrite"(覆盖), "create_new"(新建)
            
        Returns:
            写入结果字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if handle.mode == 'r':
            raise PermissionError("File opened in read-only mode")
        
        # 解析写入模式
        mode = WriteMode(write_mode) if write_mode else WriteMode.APPEND
        
        result = {
            'success': False,
            'channelsWritten': 0,
            'channelsAppended': 0,
            'channelsOverwritten': 0,
            'channelsCreated': 0,
            'details': []
        }
        
        with handle.lock:
            try:
                for ch in channel_data:
                    channel_name = ch['name']
                    exists, existing_idx = self._channel_exists(handle, group_index, channel_name)
                    
                    channel_result = {
                        'name': channel_name,
                        'action': 'unknown'
                    }
                    
                    if exists:
                        if mode == WriteMode.CREATE_NEW:
                            # 通道已存在，报错
                            raise ValueError(f"Channel '{channel_name}' already exists in group {group_index}")
                        
                        elif mode == WriteMode.OVERWRITE:
                            # 覆盖模式：需要重新创建整个文件或通道组
                            # asammdf不直接支持覆盖单个通道，这里我们先读取原数据，然后合并
                            logger.info(f"Overwriting channel '{channel_name}' in group {group_index}")
                            
                            # 读取原有其他通道的数据
                            existing_signals = []
                            group = handle.mdf.groups[group_index]
                            for idx in range(len(group.channels)):
                                if idx != existing_idx:
                                    try:
                                        sig = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                        existing_signals.append(sig)
                                    except Exception as e:
                                        logger.warning(f"Could not read existing channel {idx}: {e}")
                            
                            # 创建新信号
                            from asammdf import Signal
                            new_signal = Signal(
                                samples=np.array(ch['values']),
                                timestamps=np.array(ch['timestamps']),
                                name=channel_name,
                                unit=ch.get('unit', ''),
                                comment=ch.get('comment', '')
                            )
                            existing_signals.append(new_signal)
                            
                            # 保存当前文件状态
                            temp_path = handle.file_path + ".tmp"
                            handle.mdf.save(temp_path, overwrite=True)
                            handle.mdf.close()
                            
                            # 重新创建文件
                            new_mdf = MDF(version='4.11')
                            new_mdf.append(existing_signals, comment=f"Overwritten channel {channel_name}")
                            new_mdf.save(handle.file_path, overwrite=True)
                            new_mdf.close()
                            
                            # 重新打开
                            handle.mdf = MDF(handle.file_path)
                            
                            result['channelsOverwritten'] += 1
                            channel_result['action'] = 'overwritten'
                            
                        else:  # APPEND
                            # 追加模式：将新数据追加到现有通道
                            logger.info(f"Appending to channel '{channel_name}' in group {group_index}")
                            
                            # 读取现有数据
                            existing_signal = handle.mdf.get(group=group_index, index=existing_idx, samples_only=False)
                            existing_timestamps = existing_signal.timestamps
                            existing_values = existing_signal.samples
                            
                            # 合并数据
                            new_timestamps = np.array(ch['timestamps'])
                            new_values = np.array(ch['values'])
                            
                            # 按时间戳排序合并
                            combined_timestamps = np.concatenate([existing_timestamps, new_timestamps])
                            combined_values = np.concatenate([existing_values, new_values])
                            
                            # 排序
                            sort_indices = np.argsort(combined_timestamps)
                            combined_timestamps = combined_timestamps[sort_indices]
                            combined_values = combined_values[sort_indices]
                            
                            # 创建合并后的信号
                            from asammdf import Signal
                            combined_signal = Signal(
                                samples=combined_values,
                                timestamps=combined_timestamps,
                                name=channel_name,
                                unit=ch.get('unit', existing_signal.unit if hasattr(existing_signal, 'unit') else ''),
                                comment=ch.get('comment', '')
                            )
                            
                            # 需要重新创建整个组
                            existing_signals = []
                            group = handle.mdf.groups[group_index]
                            for idx in range(len(group.channels)):
                                if idx != existing_idx:
                                    try:
                                        sig = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                        existing_signals.append(sig)
                                    except Exception as e:
                                        logger.warning(f"Could not read existing channel {idx}: {e}")
                            
                            existing_signals.append(combined_signal)
                            
                            # 保存并重新打开
                            temp_path = handle.file_path + ".tmp"
                            handle.mdf.save(temp_path, overwrite=True)
                            handle.mdf.close()
                            
                            new_mdf = MDF(version='4.11')
                            new_mdf.append(existing_signals, comment=f"Appended to channel {channel_name}")
                            new_mdf.save(handle.file_path, overwrite=True)
                            new_mdf.close()
                            
                            handle.mdf = MDF(handle.file_path)
                            
                            result['channelsAppended'] += 1
                            channel_result['action'] = 'appended'
                            channel_result['oldSamples'] = len(existing_timestamps)
                            channel_result['newSamples'] = len(combined_timestamps)
                    
                    else:
                        # 通道不存在，创建新通道
                        from asammdf import Signal
                        
                        timestamps = np.array(ch['timestamps'])
                        values = np.array(ch['values'])
                        
                        # 如果数据太大，分批处理
                        total_samples = len(timestamps)
                        if total_samples > batch_size:
                            logger.info(f"Large write ({total_samples} samples), processing in batches")
                            
                            for i in range(0, total_samples, batch_size):
                                end_idx = min(i + batch_size, total_samples)
                                
                                batch_signal = Signal(
                                    samples=values[i:end_idx],
                                    timestamps=timestamps[i:end_idx],
                                    name=channel_name,
                                    unit=ch.get('unit', ''),
                                    comment=ch.get('comment', '')
                                )
                                
                                handle.mdf.append([batch_signal], comment=f"Batch {i//batch_size}")
                                
                                del batch_signal
                                if i // batch_size % 10 == 0:
                                    gc.collect()
                        else:
                            signal = Signal(
                                samples=values,
                                timestamps=timestamps,
                                name=channel_name,
                                unit=ch.get('unit', ''),
                                comment=ch.get('comment', '')
                            )
                            handle.mdf.append([signal], comment=ch.get('comment', 'Written by mf4_server'))
                            del signal
                        
                        result['channelsCreated'] += 1
                        channel_result['action'] = 'created'
                    
                    result['details'].append(channel_result)
                    result['channelsWritten'] += 1
                
                result['success'] = True
                gc.collect()
                
                logger.info(f"Written {result['channelsWritten']} channels to file {file_id}: "
                          f"{result['channelsCreated']} created, "
                          f"{result['channelsAppended']} appended, "
                          f"{result['channelsOverwritten']} overwritten")
                
                return result
                
            except Exception as e:
                logger.error(f"Error writing data to file {file_id}: {e}")
                result['error'] = str(e)
                raise
    
    def save_file(self, file_id: str, file_path: str = None, overwrite: bool = False) -> str:
        """
        保存文件
        
        Args:
            file_id: 文件ID
            file_path: 保存路径，None则保存到原路径
            overwrite: 是否覆盖现有文件
            
        Returns:
            保存的文件路径
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        target_path = file_path or handle.file_path
        
        if os.path.exists(target_path) and not overwrite:
            raise FileExistsError(f"File already exists: {target_path}")
        
        with handle.lock:
            try:
                handle.mdf.save(target_path, overwrite=overwrite)
                logger.info(f"Saved file: {target_path}")
                
                # 更新文件路径映射
                if target_path != handle.file_path:
                    old_path = handle.file_path
                    self._path_to_ids[old_path].discard(file_id)
                    if not self._path_to_ids[old_path]:
                        del self._path_to_ids[old_path]
                    
                    handle.file_path = target_path
                    if target_path not in self._path_to_ids:
                        self._path_to_ids[target_path] = set()
                    self._path_to_ids[target_path].add(file_id)
                
                # 清理
                gc.collect()
                
                return target_path
                
            except Exception as e:
                logger.error(f"Error saving file {file_id}: {e}")
                raise
    
    def close_all(self):
        """关闭所有文件"""
        with self._global_lock:
            file_ids = list(self._files.keys())
            for file_id in file_ids:
                try:
                    handle = self._files.get(file_id)
                    if handle:
                        handle.mdf.close()
                        logger.info(f"Closed file during shutdown: {handle.file_path}")
                except Exception as e:
                    logger.error(f"Error closing file {file_id}: {e}")
            
            self._files.clear()
            self._path_to_ids.clear()
            self._iterators.clear()
            
            # 强制垃圾回收
            gc.collect()
            logger.info("All files closed and memory cleaned up")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取内存使用统计"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            return {
                'rss': memory_info.rss,
                'rssMB': memory_info.rss / 1024 / 1024,
                'vms': memory_info.vms,
                'vmsMB': memory_info.vms / 1024 / 1024,
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
        except ImportError:
            return {
                'error': 'psutil not available',
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
    
    def _get_handle(self, file_id: str) -> Optional[FileHandle]:
        """获取文件句柄"""
        return self._files.get(file_id)
