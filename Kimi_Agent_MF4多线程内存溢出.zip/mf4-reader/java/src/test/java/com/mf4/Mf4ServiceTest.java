package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.ChannelData;
import com.mf4.model.ChannelInfo;
import com.mf4.model.FileInfo;
import org.junit.jupiter.api.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MF4服务测试类
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class Mf4ServiceTest {
    
    private static final Logger LOGGER = Logger.getLogger(Mf4ServiceTest.class.getName());
    
    private static Mf4ServiceImpl service;
    private static Path tempDir;
    
    @BeforeAll
    static void setUp() throws Exception {
        // 创建临时目录
        tempDir = Files.createTempDirectory("mf4_test");
        
        // 启动服务
        String pythonScriptPath = "../python/mf4_server.py";
        service = new Mf4ServiceImpl(pythonScriptPath, tempDir.toString());
        service.start();
        
        LOGGER.info("Test service started on port: " + service.getPort());
    }
    
    @AfterAll
    static void tearDown() {
        if (service != null) {
            service.close();
        }
        
        // 清理临时目录
        if (tempDir != null) {
            try {
                deleteDirectory(tempDir.toFile());
            } catch (Exception e) {
                LOGGER.warning("Failed to clean up temp directory: " + e.getMessage());
            }
        }
    }
    
    @Test
    @Order(1)
    void testServiceRunning() {
        assertTrue(service.isRunning(), "Service should be running");
    }
    
    @Test
    @Order(2)
    void testCreateAndOpenFile() throws Mf4Exception {
        String filePath = tempDir.resolve("test.mf4").toString();
        
        // 创建文件
        Mf4File file = service.createFile(filePath);
        assertNotNull(file);
        assertNotNull(file.getFileId());
        
        // 关闭文件
        file.close();
        assertTrue(file.isClosed());
        
        // 重新打开文件
        Mf4File openedFile = service.openFile(filePath);
        assertNotNull(openedFile);
        assertFalse(openedFile.isClosed());
        
        openedFile.close();
    }
    
    @Test
    @Order(3)
    void testFileInfo() throws Mf4Exception {
        String filePath = tempDir.resolve("info_test.mf4").toString();
        
        Mf4File file = service.createFile(filePath);
        FileInfo info = file.getInfo();
        
        assertNotNull(info);
        assertEquals(filePath, info.getFilePath());
        
        file.close();
    }
    
    @Test
    @Order(4)
    void testMultiThreading() throws Exception {
        String filePath = tempDir.resolve("thread_test.mf4").toString();
        
        // 创建文件
        Mf4File mainFile = service.createFile(filePath);
        mainFile.close();
        
        int threadCount = 5;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        List<Future<Boolean>> futures = new ArrayList<>();
        
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            Future<Boolean> future = executor.submit(() -> {
                try {
                    // 每个线程打开同一个文件
                    Mf4File file = service.openFile(filePath);
                    LOGGER.info("Thread " + threadId + " opened file: " + file.getFileId());
                    
                    // 获取文件信息
                    FileInfo info = file.getInfo();
                    assertNotNull(info);
                    
                    // 模拟一些操作
                    Thread.sleep(100);
                    
                    file.close();
                    LOGGER.info("Thread " + threadId + " closed file");
                    
                    return true;
                } catch (Exception e) {
                    LOGGER.severe("Thread " + threadId + " error: " + e.getMessage());
                    return false;
                }
            });
            futures.add(future);
        }
        
        // 等待所有线程完成
        for (Future<Boolean> future : futures) {
            assertTrue(future.get(30, TimeUnit.SECONDS), "Thread should complete successfully");
        }
        
        executor.shutdown();
    }
    
    @Test
    @Order(5)
    void testConcurrentDifferentFiles() throws Exception {
        int fileCount = 3;
        List<String> filePaths = new ArrayList<>();
        
        for (int i = 0; i < fileCount; i++) {
            filePaths.add(tempDir.resolve("concurrent_" + i + ".mf4").toString());
        }
        
        // 创建所有文件
        for (String path : filePaths) {
            Mf4File file = service.createFile(path);
            file.close();
        }
        
        // 并发打开不同的文件
        ExecutorService executor = Executors.newFixedThreadPool(fileCount);
        List<Future<Boolean>> futures = new ArrayList<>();
        
        for (int i = 0; i < fileCount; i++) {
            final int index = i;
            final String path = filePaths.get(i);
            
            Future<Boolean> future = executor.submit(() -> {
                try {
                    Mf4File file = service.openFile(path);
                    FileInfo info = file.getInfo();
                    
                    assertEquals(path, info.getFilePath());
                    
                    Thread.sleep(200);
                    file.close();
                    return true;
                } catch (Exception e) {
                    LOGGER.severe("Error with file " + index + ": " + e.getMessage());
                    return false;
                }
            });
            futures.add(future);
        }
        
        for (Future<Boolean> future : futures) {
            assertTrue(future.get(30, TimeUnit.SECONDS));
        }
        
        executor.shutdown();
    }
    
    @Test
    @Order(6)
    void testOverwriteFile() throws Mf4Exception {
        String filePath = tempDir.resolve("overwrite_test.mf4").toString();
        
        // 创建第一个文件
        Mf4File file1 = service.createFile(filePath);
        file1.close();
        
        // 尝试不覆盖创建，应该失败
        assertThrows(Mf4Exception.class, () -> {
            service.createFile(filePath, false);
        });
        
        // 覆盖创建应该成功
        Mf4File file2 = service.createFile(filePath, true);
        assertNotNull(file2);
        file2.close();
    }
    
    @Test
    @Order(7)
    void testCreateIfNotExists() throws Mf4Exception {
        String existingFile = tempDir.resolve("existing.mf4").toString();
        String newFile = tempDir.resolve("new_file.mf4").toString();
        
        // 创建已存在的文件
        Mf4File file1 = service.createFile(existingFile);
        file1.close();
        
        // 打开已存在的文件（不创建）
        Mf4File file2 = service.openFile(existingFile, false);
        assertNotNull(file2);
        file2.close();
        
        // 打开不存在的文件（创建）
        Mf4File file3 = service.openFile(newFile, true);
        assertNotNull(file3);
        file3.close();
    }
    
    @Test
    @Order(8)
    void testPing() {
        // 通过创建客户端来测试ping
        assertTrue(service.isRunning());
    }
    
    private static void deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file);
                }
            }
        }
        directory.delete();
    }
}
