package com.mf4.examples;

import com.mf4.*;
import com.mf4.model.*;

import java.util.List;
import java.util.logging.Logger;

/**
 * 大文件处理示例
 * 
 * 演示如何安全地处理GB级MF4文件，避免内存溢出
 */
public class LargeFileExample {
    
    private static final Logger LOGGER = Logger.getLogger(LargeFileExample.class.getName());
    
    public static void main(String[] args) {
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4Service service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            LOGGER.info("Service started on port: " + ((Mf4ServiceImpl) service).getPort());
            
            // 检查内存状态
            MemoryStats stats = service.getMemoryStats();
            LOGGER.info("Initial memory: " + stats);
            
            // 示例1: 流式读取超大文件
            streamReadExample(service, "/path/to/large_file.mf4");
            
            // 示例2: 限制采样数读取
            limitedReadExample(service, "/path/to/medium_file.mf4");
            
            // 示例3: 按时间范围读取
            timeRangeReadExample(service, "/path/to/large_file.mf4");
            
            // 示例4: 分批写入大文件
            batchWriteExample(service, "/path/to/output.mf4");
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 示例1: 流式读取超大文件
     * 适用于GB级文件，内存占用稳定
     */
    static void streamReadExample(Mf4Service service, String filePath) {
        LOGGER.info("=== Stream Read Example ===");
        
        try {
            Mf4File file = service.openFile(filePath);
            
            // 获取文件信息
            FileInfo info = file.getInfo();
            LOGGER.info("File: " + info.getFilePath() + 
                       ", Channels: " + info.getChannelCount());
            
            // 创建流式迭代器
            ChannelDataIterator iterator = file.readChannelStream(0, 0);
            
            int totalProcessedSamples = 0;
            int chunkCount = 0;
            
            // 分块处理数据
            while (iterator.hasNext()) {
                ChannelData chunk = iterator.next();
                chunkCount++;
                
                List<Double> timestamps = chunk.getTimestamps();
                List<Object> values = chunk.getValues();
                
                totalProcessedSamples += chunk.getSampleCount();
                
                // 打印进度
                if (chunkCount % 10 == 0) {
                    double progress = iterator.getProgress() * 100;
                    LOGGER.info(String.format("Progress: %.1f%%, Processed: %d samples", 
                             progress, totalProcessedSamples));
                }
                
                // 在这里处理数据...
                // 例如：计算平均值、写入数据库等
                
                // 模拟处理时间
                // Thread.sleep(10);
            }
            
            LOGGER.info("Stream read complete. Total chunks: " + chunkCount + 
                       ", Total samples: " + totalProcessedSamples);
            
            // 关闭迭代器
            iterator.close();
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Stream read error: " + e.getMessage());
        }
    }
    
    /**
     * 示例2: 限制采样数读取
     * 适用于只需要部分数据的场景
     */
    static void limitedReadExample(Mf4Service service, String filePath) {
        LOGGER.info("=== Limited Read Example ===");
        
        try {
            Mf4File file = service.openFile(filePath);
            
            // 只读取前10万个样本
            ChannelData data = file.readChannel(0, 0, 100000);
            
            LOGGER.info("Read " + data.getSampleCount() + " samples");
            LOGGER.info("First timestamp: " + data.getTimestamps().get(0));
            LOGGER.info("Last timestamp: " + data.getTimestamps().get(data.getSampleCount() - 1));
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Limited read error: " + e.getMessage());
        }
    }
    
    /**
     * 示例3: 按时间范围读取
     * 适用于只需要特定时间段数据的场景
     */
    static void timeRangeReadExample(Mf4Service service, String filePath) {
        LOGGER.info("=== Time Range Read Example ===");
        
        try {
            Mf4File file = service.openFile(filePath);
            
            // 读取0-100秒的数据
            double startTime = 0.0;
            double endTime = 100.0;
            
            ChannelData data = file.readChannel(0, 0, startTime, endTime);
            
            LOGGER.info("Time range: " + startTime + " - " + endTime);
            LOGGER.info("Samples in range: " + data.getSampleCount());
            
            if (data.getSampleCount() > 0) {
                LOGGER.info("First timestamp in range: " + data.getTimestamps().get(0));
                LOGGER.info("Last timestamp in range: " + 
                           data.getTimestamps().get(data.getSampleCount() - 1));
            }
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Time range read error: " + e.getMessage());
        }
    }
    
    /**
     * 示例4: 分批写入大文件
     * 适用于生成大文件时避免内存溢出
     */
    static void batchWriteExample(Mf4Service service, String filePath) {
        LOGGER.info("=== Batch Write Example ===");
        
        try {
            // 创建新文件
            Mf4File file = service.createFile(filePath, true);
            
            // 模拟生成大量数据
            int totalBatches = 100;
            int samplesPerBatch = 10000;
            
            for (int batch = 0; batch < totalBatches; batch++) {
                // 生成一批数据
                ChannelData data = generateBatchData(batch, samplesPerBatch);
                
                // 写入数据（自动分批处理）
                file.writeChannel(0, data);
                
                if (batch % 10 == 0) {
                    LOGGER.info("Written batch " + batch + "/" + totalBatches);
                    
                    // 检查内存状态
                    MemoryStats stats = service.getMemoryStats();
                    LOGGER.info("Memory: " + String.format("%.2f", stats.getRssMB()) + " MB");
                }
            }
            
            // 保存文件
            file.save();
            LOGGER.info("File saved: " + filePath);
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Batch write error: " + e.getMessage());
        }
    }
    
    /**
     * 生成模拟数据批次
     */
    static ChannelData generateBatchData(int batchIndex, int sampleCount) {
        ChannelData data = new ChannelData();
        data.setName("Channel_" + batchIndex);
        data.setUnit("V");
        
        java.util.List<Double> timestamps = new java.util.ArrayList<>(sampleCount);
        java.util.List<Double> values = new java.util.ArrayList<>(sampleCount);
        
        double startTime = batchIndex * sampleCount * 0.001;  // 1ms间隔
        
        for (int i = 0; i < sampleCount; i++) {
            timestamps.add(startTime + i * 0.001);
            values.add(Math.sin((startTime + i * 0.001) * 2 * Math.PI));  // 正弦波
        }
        
        data.setTimestamps(timestamps);
        data.setValues(new java.util.ArrayList<>(values));
        
        return data;
    }
}
