package com.mf4.model;

/**
 * 通道详细信息类
 */
public class ChannelDetailInfo {
    
    private String name;
    private int groupIndex;
    private int channelIndex;
    private String unit;
    private String comment;
    private String dataType;
    private Integer sampleCount;
    private Double startTime;
    private Double endTime;
    private String conversion;
    private String source;
    private String signalName;
    private String signalUnit;
    private String signalComment;
    private Integer signalSampleCount;
    private Double signalStartTime;
    private Double signalEndTime;
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getGroupIndex() {
        return groupIndex;
    }
    
    public void setGroupIndex(int groupIndex) {
        this.groupIndex = groupIndex;
    }
    
    public int getChannelIndex() {
        return channelIndex;
    }
    
    public void setChannelIndex(int channelIndex) {
        this.channelIndex = channelIndex;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public String getDataType() {
        return dataType;
    }
    
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    public Integer getSampleCount() {
        return sampleCount;
    }
    
    public void setSampleCount(Integer sampleCount) {
        this.sampleCount = sampleCount;
    }
    
    public Double getStartTime() {
        return startTime;
    }
    
    public void setStartTime(Double startTime) {
        this.startTime = startTime;
    }
    
    public Double getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Double endTime) {
        this.endTime = endTime;
    }
    
    public String getConversion() {
        return conversion;
    }
    
    public void setConversion(String conversion) {
        this.conversion = conversion;
    }
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
    public String getSignalName() {
        return signalName;
    }
    
    public void setSignalName(String signalName) {
        this.signalName = signalName;
    }
    
    public String getSignalUnit() {
        return signalUnit;
    }
    
    public void setSignalUnit(String signalUnit) {
        this.signalUnit = signalUnit;
    }
    
    public String getSignalComment() {
        return signalComment;
    }
    
    public void setSignalComment(String signalComment) {
        this.signalComment = signalComment;
    }
    
    public Integer getSignalSampleCount() {
        return signalSampleCount;
    }
    
    public void setSignalSampleCount(Integer signalSampleCount) {
        this.signalSampleCount = signalSampleCount;
    }
    
    public Double getSignalStartTime() {
        return signalStartTime;
    }
    
    public void setSignalStartTime(Double signalStartTime) {
        this.signalStartTime = signalStartTime;
    }
    
    public Double getSignalEndTime() {
        return signalEndTime;
    }
    
    public void setSignalEndTime(Double signalEndTime) {
        this.signalEndTime = signalEndTime;
    }
    
    @Override
    public String toString() {
        return "ChannelDetailInfo{" +
                "name='" + name + '\'' +
                ", groupIndex=" + groupIndex +
                ", channelIndex=" + channelIndex +
                ", unit='" + unit + '\'' +
                ", comment='" + comment + '\'' +
                ", sampleCount=" + sampleCount +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
