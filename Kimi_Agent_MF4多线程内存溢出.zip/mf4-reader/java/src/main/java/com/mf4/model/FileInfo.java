package com.mf4.model;

import java.util.List;
import java.util.Map;

/**
 * MF4文件信息
 */
public class FileInfo {
    
    private String filePath;
    private String mode;
    private String version;
    private int channelCount;
    private List<Map<String, Object>> groups;
    
    public String getFilePath() {
        return filePath;
    }
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    public String getMode() {
        return mode;
    }
    
    public void setMode(String mode) {
        this.mode = mode;
    }
    
    public String getVersion() {
        return version;
    }
    
    public void setVersion(String version) {
        this.version = version;
    }
    
    public int getChannelCount() {
        return channelCount;
    }
    
    public void setChannelCount(int channelCount) {
        this.channelCount = channelCount;
    }
    
    public List<Map<String, Object>> getGroups() {
        return groups;
    }
    
    public void setGroups(List<Map<String, Object>> groups) {
        this.groups = groups;
    }
    
    @Override
    public String toString() {
        return "FileInfo{" +
                "filePath='" + filePath + '\'' +
                ", mode='" + mode + '\'' +
                ", version='" + version + '\'' +
                ", channelCount=" + channelCount +
                ", groupCount=" + (groups != null ? groups.size() : 0) +
                '}';
    }
}
