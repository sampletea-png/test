package com.mf4;

import com.google.gson.Gson;
import com.mf4.model.Request;
import com.mf4.model.Response;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Socket客户端 - 负责与Python服务器的通信
 */
public class SocketClient {
    
    // 协议常量
    private static final byte[] MAGIC_NUMBER = new byte[]{'M', 'F', '4', 'P'};
    private static final int VERSION = 1;
    private static final int HEADER_SIZE = 12;
    private static final int BUFFER_SIZE = 8192;
    private static final int DEFAULT_TIMEOUT = 300000; // 5分钟
    
    private final String host;
    private final int port;
    private final Gson gson;
    private final ReentrantLock lock;
    private final AtomicBoolean connected;
    
    private Socket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.gson = new Gson();
        this.lock = new ReentrantLock();
        this.connected = new AtomicBoolean(false);
    }
    
    /**
     * 连接到服务器
     */
    public void connect() throws IOException {
        lock.lock();
        try {
            if (connected.get()) {
                return;
            }
            
            socket = new Socket(host, port);
            socket.setSoTimeout(DEFAULT_TIMEOUT);
            socket.setKeepAlive(true);
            socket.setTcpNoDelay(true);
            
            outputStream = new BufferedOutputStream(socket.getOutputStream());
            inputStream = new BufferedInputStream(socket.getInputStream());
            
            connected.set(true);
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 断开连接
     */
    public void disconnect() {
        lock.lock();
        try {
            connected.set(false);
            
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    // ignore
                }
                outputStream = null;
            }
            
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    // ignore
                }
                inputStream = null;
            }
            
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // ignore
                }
                socket = null;
            }
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return connected.get() && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    /**
     * 发送请求并接收响应
     */
    public Response sendRequest(Request request) throws IOException {
        lock.lock();
        try {
            if (!isConnected()) {
                throw new IOException("Not connected to server");
            }
            
            // 序列化请求
            String jsonRequest = gson.toJson(request);
            byte[] requestData = jsonRequest.getBytes(StandardCharsets.UTF_8);
            
            // 构建协议头: 魔数(4) + 版本(1) + 保留(3) + 数据长度(4)
            ByteBuffer header = ByteBuffer.allocate(HEADER_SIZE);
            header.put(MAGIC_NUMBER);
            header.put((byte) VERSION);
            header.put(new byte[3]); // 保留字节
            header.putInt(requestData.length);
            
            // 发送数据
            outputStream.write(header.array());
            outputStream.write(requestData);
            outputStream.flush();
            
            // 接收响应
            String jsonResponse = receiveMessage();
            
            // 反序列化响应
            return gson.fromJson(jsonResponse, Response.class);
            
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 接收完整的消息
     */
    private String receiveMessage() throws IOException {
        // 读取协议头
        byte[] header = new byte[HEADER_SIZE];
        int headerRead = 0;
        
        while (headerRead < HEADER_SIZE) {
            int read = inputStream.read(header, headerRead, HEADER_SIZE - headerRead);
            if (read == -1) {
                throw new IOException("Connection closed while reading header");
            }
            headerRead += read;
        }
        
        // 验证魔数
        for (int i = 0; i < 4; i++) {
            if (header[i] != MAGIC_NUMBER[i]) {
                throw new IOException("Invalid magic number in response");
            }
        }
        
        // 获取数据长度
        int dataLength = ByteBuffer.wrap(header, 8, 4).getInt();
        
        if (dataLength < 0 || dataLength > 100 * 1024 * 1024) { // 最大100MB
            throw new IOException("Invalid data length: " + dataLength);
        }
        
        // 读取数据体
        ByteArrayOutputStream baos = new ByteArrayOutputStream(dataLength);
        byte[] buffer = new byte[Math.min(BUFFER_SIZE, dataLength)];
        int totalRead = 0;
        
        while (totalRead < dataLength) {
            int toRead = Math.min(buffer.length, dataLength - totalRead);
            int read = inputStream.read(buffer, 0, toRead);
            if (read == -1) {
                throw new IOException("Connection closed while reading body");
            }
            baos.write(buffer, 0, read);
            totalRead += read;
        }
        
        return baos.toString(StandardCharsets.UTF_8.name());
    }
    
    /**
     * 发送Ping请求检查连接
     */
    public boolean ping() {
        try {
            Response response = sendRequest(Request.ping());
            return response.isSuccess();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 发送关闭服务器请求
     */
    public void shutdownServer() {
        try {
            sendRequest(Request.shutdown());
        } catch (Exception e) {
            // ignore
        } finally {
            disconnect();
        }
    }
}
