package com.mf4;

import com.google.gson.Gson;
import com.mf4.exception.Mf4Exception;
import com.mf4.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * MF4文件实现类（支持大文件流式读取）
 */
public class Mf4FileImpl implements Mf4File {
    
    private static final Logger LOGGER = Logger.getLogger(Mf4FileImpl.class.getName());
    private static final Gson GSON = new Gson();
    
    // 默认单次读取最大样本数
    private static final int DEFAULT_MAX_SAMPLES = 1000000; // 100万
    
    // 默认批量读取最大通道数
    private static final int DEFAULT_MAX_CHANNELS = 10;
    
    private final String fileId;
    private final String filePath;
    private final SocketClient client;
    private final ReentrantReadWriteLock lock;
    private final AtomicBoolean closed;
    
    public Mf4FileImpl(String fileId, String filePath, SocketClient client) {
        this.fileId = fileId;
        this.filePath = filePath;
        this.client = client;
        this.lock = new ReentrantReadWriteLock();
        this.closed = new AtomicBoolean(false);
    }
    
    @Override
    public String getFileId() {
        return fileId;
    }
    
    @Override
    public String getFilePath() {
        return filePath;
    }
    
    @Override
    public FileInfo getInfo() throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.getInfo(fileId);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to get file info: " + response.getErrorMessage(), 
                        response.getRequestId());
            }
            
            return GSON.fromJson(GSON.toJson(response.getData()), FileInfo.class);
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error getting file info", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelInfo> getChannels() throws Mf4Exception {
        return getChannels(null);
    }
    
    @Override
    public List<ChannelInfo> getChannels(Integer groupIndex) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.getChannels(fileId, groupIndex);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to get channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelInfo> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    ChannelInfo info = new ChannelInfo();
                    info.setName((String) ch.get("name"));
                    info.setGroupIndex(((Number) ch.get("groupIndex")).intValue());
                    info.setChannelIndex(((Number) ch.get("channelIndex")).intValue());
                    info.setUnit((String) ch.get("unit"));
                    info.setComment((String) ch.get("comment"));
                    result.add(info);
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error getting channels", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public ChannelDetailInfo getChannelInfo(int groupIndex, int channelIndex) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.getChannelInfo(fileId, groupIndex, channelIndex);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to get channel info: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            return GSON.fromJson(GSON.toJson(response.getData()), ChannelDetailInfo.class);
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error getting channel info", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelInfo> findChannel(String channelName) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.findChannel(fileId, channelName);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to find channel: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelInfo> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    ChannelInfo info = new ChannelInfo();
                    info.setName((String) ch.get("name"));
                    info.setGroupIndex(((Number) ch.get("groupIndex")).intValue());
                    info.setChannelIndex(((Number) ch.get("channelIndex")).intValue());
                    info.setUnit((String) ch.get("unit"));
                    info.setComment((String) ch.get("comment"));
                    result.add(info);
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error finding channel", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex) throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, null, null, DEFAULT_MAX_SAMPLES);
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex, double startTime, double endTime) 
            throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, startTime, endTime, DEFAULT_MAX_SAMPLES);
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex, int maxSamples) throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, null, null, maxSamples);
    }
    
    private ChannelData readChannel(int groupIndex, int channelIndex, 
                                    Double startTime, Double endTime, Integer maxSamples) 
            throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readData(fileId, groupIndex, channelIndex, 
                    startTime, endTime, maxSamples, null, false);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read channel: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            return parseChannelData(response.getData());
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading channel", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public ChannelDataIterator readChannelStream(int groupIndex, int channelIndex) throws Mf4Exception {
        return readChannelStream(groupIndex, channelIndex, null, null);
    }
    
    @Override
    public ChannelDataIterator readChannelStream(int groupIndex, int channelIndex, 
                                                  double startTime, double endTime) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readData(fileId, groupIndex, channelIndex, 
                    startTime, endTime, null, null, true);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to start stream: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            Map<String, Object> data = response.getData();
            String iteratorId = (String) data.get("iteratorId");
            boolean hasMore = data.get("hasMore") != null ? (Boolean) data.get("hasMore") : false;
            int chunkIndex = data.get("chunkIndex") != null ? ((Number) data.get("chunkIndex")).intValue() : 0;
            int totalChunks = data.get("totalChunks") != null ? ((Number) data.get("totalChunks")).intValue() : 1;
            int totalSamples = data.get("totalSamples") != null ? ((Number) data.get("totalSamples")).intValue() : 0;
            
            return new ChannelDataIterator(client, iteratorId, fileId, groupIndex, channelIndex,
                    hasMore, chunkIndex, totalChunks, totalSamples);
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error starting stream", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelData> readChannels(int groupIndex, int[] channelIndices) throws Mf4Exception {
        return readChannels(groupIndex, channelIndices, null, null, DEFAULT_MAX_SAMPLES);
    }
    
    @Override
    public List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                          double startTime, double endTime) throws Mf4Exception {
        return readChannels(groupIndex, channelIndices, startTime, endTime, DEFAULT_MAX_SAMPLES);
    }
    
    @Override
    public List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                          double startTime, double endTime, int maxSamples) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            // 限制通道数
            if (channelIndices.length > DEFAULT_MAX_CHANNELS) {
                LOGGER.warning("Too many channels (" + channelIndices.length + "), limiting to " + DEFAULT_MAX_CHANNELS);
                int[] limited = new int[DEFAULT_MAX_CHANNELS];
                System.arraycopy(channelIndices, 0, limited, 0, DEFAULT_MAX_CHANNELS);
                channelIndices = limited;
            }
            
            Request request = Request.readBatch(fileId, groupIndex, channelIndices, 
                    startTime, endTime, maxSamples);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelData> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    if (ch.containsKey("error")) {
                        LOGGER.warning("Error reading channel: " + ch.get("error"));
                        continue;
                    }
                    result.add(parseChannelData(ch));
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading channels", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelData> readGroup(int groupIndex) throws Mf4Exception {
        return readGroup(groupIndex, DEFAULT_MAX_CHANNELS);
    }
    
    @Override
    public List<ChannelData> readGroup(int groupIndex, int maxChannels) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readData(fileId, groupIndex, null, null, null, 
                    null, null, false);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read group: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelData> result = new ArrayList<>();
            
            if (channelList != null) {
                int count = 0;
                for (Map<String, Object> ch : channelList) {
                    if (count >= maxChannels) {
                        LOGGER.warning("Reached max channels limit (" + maxChannels + "), truncating");
                        break;
                    }
                    result.add(parseChannelData(ch));
                    count++;
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading group", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void writeChannel(int groupIndex, ChannelData data) throws Mf4Exception {
        writeChannel(groupIndex, data, WriteMode.APPEND);
    }
    
    @Override
    public void writeChannel(int groupIndex, ChannelData data, WriteMode writeMode) throws Mf4Exception {
        List<ChannelData> list = new ArrayList<>();
        list.add(data);
        writeChannels(groupIndex, list, 10000, writeMode);
    }
    
    @Override
    public void writeChannels(int groupIndex, List<ChannelData> dataList) throws Mf4Exception {
        writeChannels(groupIndex, dataList, 10000, WriteMode.APPEND);
    }
    
    @Override
    public void writeChannels(int groupIndex, List<ChannelData> dataList, WriteMode writeMode) throws Mf4Exception {
        writeChannels(groupIndex, dataList, 10000, writeMode);
    }
    
    @Override
    public void writeChannels(int groupIndex, List<ChannelData> dataList, int batchSize, WriteMode writeMode) throws Mf4Exception {
        checkClosed();
        
        lock.writeLock().lock();
        try {
            // 构建写入数据
            List<Map<String, Object>> channelData = new ArrayList<>();
            for (ChannelData data : dataList) {
                Map<String, Object> ch = new HashMap<>();
                ch.put("name", data.getName());
                ch.put("unit", data.getUnit());
                ch.put("timestamps", data.getTimestamps());
                ch.put("values", data.getValues());
                channelData.add(ch);
            }
            
            Request.WriteMode requestMode;
            switch (writeMode) {
                case OVERWRITE:
                    requestMode = Request.WriteMode.OVERWRITE;
                    break;
                case CREATE_NEW:
                    requestMode = Request.WriteMode.CREATE_NEW;
                    break;
                case APPEND:
                default:
                    requestMode = Request.WriteMode.APPEND;
                    break;
            }
            
            Request request = Request.writeData(fileId, groupIndex, channelData, batchSize, requestMode);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to write channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            // 记录写入结果
            Map<String, Object> result = response.getData();
            Integer written = (Integer) result.get("channelsWritten");
            Integer created = (Integer) result.get("channelsCreated");
            Integer appended = (Integer) result.get("channelsAppended");
            Integer overwritten = (Integer) result.get("channelsOverwritten");
            
            LOGGER.info("Write result: " + written + " channels written (" + 
                       created + " created, " + appended + " appended, " + overwritten + " overwritten)");
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error writing channels", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void save() throws Mf4Exception {
        save(null, false);
    }
    
    @Override
    public void save(String filePath, boolean overwrite) throws Mf4Exception {
        checkClosed();
        
        lock.writeLock().lock();
        try {
            Request request = Request.saveFile(fileId, filePath, overwrite);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to save file: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error saving file", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void close() {
        if (closed.getAndSet(true)) {
            return;
        }
        
        try {
            Request request = Request.closeFile(fileId);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                LOGGER.warning("Error closing file: " + response.getErrorMessage());
            }
            
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing file", e);
        }
    }
    
    @Override
    public boolean isClosed() {
        return closed.get();
    }
    
    private void checkClosed() throws Mf4Exception {
        if (closed.get()) {
            throw new Mf4Exception("File is closed");
        }
    }
    
    private Response sendRequest(Request request) throws IOException {
        return client.sendRequest(request);
    }
    
    @SuppressWarnings("unchecked")
    private ChannelData parseChannelData(Map<String, Object> data) {
        ChannelData result = new ChannelData();
        result.setName((String) data.get("name"));
        result.setUnit((String) data.get("unit"));
        
        List<Number> timestamps = (List<Number>) data.get("timestamps");
        if (timestamps != null) {
            List<Double> tsList = new ArrayList<>(timestamps.size());
            for (Number n : timestamps) {
                tsList.add(n.doubleValue());
            }
            result.setTimestamps(tsList);
        }
        
        result.setValues((List<Object>) data.get("values"));
        result.setSampleCount(((Number) data.get("sampleCount")).intValue());
        
        return result;
    }
}
