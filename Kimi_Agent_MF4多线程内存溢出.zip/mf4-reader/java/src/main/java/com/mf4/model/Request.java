package com.mf4.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 请求类 - 用于Java与Python之间的通信
 */
public class Request {
    
    /**
     * 请求类型枚举
     */
    public enum RequestType {
        OPEN_FILE("open_file"),
        CREATE_FILE("create_file"),
        CLOSE_FILE("close_file"),
        READ_DATA("read_data"),
        READ_NEXT_CHUNK("read_next_chunk"),  // 读取下一个数据块（流式）
        CLOSE_ITERATOR("close_iterator"),     // 关闭迭代器
        READ_BATCH("read_batch"),
        WRITE_DATA("write_data"),
        GET_INFO("get_info"),
        GET_CHANNELS("get_channels"),
        GET_CHANNEL_INFO("get_channel_info"),  // 获取单个通道详细信息
        FIND_CHANNEL("find_channel"),          // 按名称查找通道
        SAVE_FILE("save_file"),
        GET_MEMORY_STATS("get_memory_stats"), // 获取内存统计
        PING("ping"),
        SHUTDOWN("shutdown");
        
        private final String value;
        
        RequestType(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    /**
     * 写入模式枚举
     */
    public enum WriteMode {
        APPEND("append"),       // 追加到现有通道
        OVERWRITE("overwrite"), // 覆盖现有通道
        CREATE_NEW("create_new"); // 创建新通道（如果存在则报错）
        
        private final String value;
        
        WriteMode(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    private String requestType;
    private String requestId;
    private String fileId;
    private Map<String, Object> data;
    
    public Request() {
        this.requestId = UUID.randomUUID().toString();
        this.data = new HashMap<>();
    }
    
    public Request(RequestType requestType) {
        this();
        this.requestType = requestType.getValue();
    }
    
    public Request(RequestType requestType, String fileId) {
        this(requestType);
        this.fileId = fileId;
    }
    
    public String getRequestType() {
        return requestType;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getFileId() {
        return fileId;
    }
    
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    
    public Map<String, Object> getData() {
        return data;
    }
    
    public void setData(Map<String, Object> data) {
        this.data = data;
    }
    
    public void addData(String key, Object value) {
        if (this.data == null) {
            this.data = new HashMap<>();
        }
        this.data.put(key, value);
    }
    
    /**
     * 创建打开文件请求
     */
    public static Request openFile(String filePath, boolean createIfNotExists) {
        Request request = new Request(RequestType.OPEN_FILE);
        request.addData("filePath", filePath);
        request.addData("createIfNotExists", createIfNotExists);
        return request;
    }
    
    /**
     * 创建文件请求
     */
    public static Request createFile(String filePath, boolean overwrite) {
        Request request = new Request(RequestType.CREATE_FILE);
        request.addData("filePath", filePath);
        request.addData("overwrite", overwrite);
        return request;
    }
    
    /**
     * 创建关闭文件请求
     */
    public static Request closeFile(String fileId) {
        Request request = new Request(RequestType.CLOSE_FILE, fileId);
        return request;
    }
    
    /**
     * 创建读取数据请求
     */
    public static Request readData(String fileId, int groupIndex, Integer channelIndex,
                                   Double start, Double end, Integer samples, Integer chunkSize) {
        return readData(fileId, groupIndex, channelIndex, start, end, samples, chunkSize, false);
    }
    
    /**
     * 创建读取数据请求（支持流式）
     */
    public static Request readData(String fileId, int groupIndex, Integer channelIndex,
                                   Double start, Double end, Integer samples, Integer chunkSize,
                                   boolean useIterator) {
        Request request = new Request(RequestType.READ_DATA, fileId);
        request.addData("groupIndex", groupIndex);
        if (channelIndex != null) {
            request.addData("channelIndex", channelIndex);
        }
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        if (samples != null) {
            request.addData("samples", samples);
        }
        if (chunkSize != null) {
            request.addData("chunkSize", chunkSize);
        }
        request.addData("useIterator", useIterator);
        return request;
    }
    
    /**
     * 创建读取下一个数据块请求
     */
    public static Request readNextChunk(String iteratorId) {
        Request request = new Request(RequestType.READ_NEXT_CHUNK);
        request.addData("iteratorId", iteratorId);
        return request;
    }
    
    /**
     * 创建关闭迭代器请求
     */
    public static Request closeIterator(String iteratorId) {
        Request request = new Request(RequestType.CLOSE_ITERATOR);
        request.addData("iteratorId", iteratorId);
        return request;
    }
    
    /**
     * 创建批量读取请求
     */
    public static Request readBatch(String fileId, int groupIndex, int[] channelIndices,
                                    Double start, Double end) {
        return readBatch(fileId, groupIndex, channelIndices, start, end, null);
    }
    
    /**
     * 创建批量读取请求（带最大采样数限制）
     */
    public static Request readBatch(String fileId, int groupIndex, int[] channelIndices,
                                    Double start, Double end, Integer maxSamples) {
        Request request = new Request(RequestType.READ_BATCH, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelIndices", channelIndices);
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        if (maxSamples != null) {
            request.addData("maxSamples", maxSamples);
        }
        return request;
    }
    
    /**
     * 创建写入数据请求（默认追加模式）
     */
    public static Request writeData(String fileId, int groupIndex, java.util.List<Map<String, Object>> channelData) {
        return writeData(fileId, groupIndex, channelData, 10000, WriteMode.APPEND);
    }
    
    /**
     * 创建写入数据请求（指定写入模式）
     */
    public static Request writeData(String fileId, int groupIndex, java.util.List<Map<String, Object>> channelData,
                                    int batchSize, WriteMode writeMode) {
        Request request = new Request(RequestType.WRITE_DATA, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelData", channelData);
        request.addData("batchSize", batchSize);
        request.addData("writeMode", writeMode.getValue());
        return request;
    }
    
    /**
     * 创建获取文件信息请求
     */
    public static Request getInfo(String fileId) {
        return new Request(RequestType.GET_INFO, fileId);
    }
    
    /**
     * 创建获取通道列表请求
     */
    public static Request getChannels(String fileId, Integer groupIndex) {
        Request request = new Request(RequestType.GET_CHANNELS, fileId);
        if (groupIndex != null) {
            request.addData("groupIndex", groupIndex);
        }
        return request;
    }
    
    /**
     * 创建获取单个通道详细信息请求
     */
    public static Request getChannelInfo(String fileId, int groupIndex, int channelIndex) {
        Request request = new Request(RequestType.GET_CHANNEL_INFO, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelIndex", channelIndex);
        return request;
    }
    
    /**
     * 创建按名称查找通道请求
     */
    public static Request findChannel(String fileId, String channelName) {
        Request request = new Request(RequestType.FIND_CHANNEL, fileId);
        request.addData("channelName", channelName);
        return request;
    }
    
    /**
     * 创建保存文件请求
     */
    public static Request saveFile(String fileId, String filePath, boolean overwrite) {
        Request request = new Request(RequestType.SAVE_FILE, fileId);
        if (filePath != null) {
            request.addData("filePath", filePath);
        }
        request.addData("overwrite", overwrite);
        return request;
    }
    
    /**
     * 创建获取内存统计请求
     */
    public static Request getMemoryStats() {
        return new Request(RequestType.GET_MEMORY_STATS);
    }
    
    /**
     * 创建Ping请求
     */
    public static Request ping() {
        return new Request(RequestType.PING);
    }
    
    /**
     * 创建关闭服务器请求
     */
    public static Request shutdown() {
        return new Request(RequestType.SHUTDOWN);
    }
}
