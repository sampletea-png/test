package com.mf4;

/**
 * Python服务端内存统计信息
 */
public class MemoryStats {
    
    private long rss;           // 实际使用内存（字节）
    private double rssMB;       // 实际使用内存（MB）
    private long vms;           // 虚拟内存（字节）
    private double vmsMB;       // 虚拟内存（MB）
    private int openFiles;      // 打开的文件数
    private int activeIterators; // 活动迭代器数
    private String error;       // 错误信息（如果无法获取）
    
    public long getRss() {
        return rss;
    }
    
    public void setRss(long rss) {
        this.rss = rss;
    }
    
    public double getRssMB() {
        return rssMB;
    }
    
    public void setRssMB(double rssMB) {
        this.rssMB = rssMB;
    }
    
    public long getVms() {
        return vms;
    }
    
    public void setVms(long vms) {
        this.vms = vms;
    }
    
    public double getVmsMB() {
        return vmsMB;
    }
    
    public void setVmsMB(double vmsMB) {
        this.vmsMB = vmsMB;
    }
    
    public int getOpenFiles() {
        return openFiles;
    }
    
    public void setOpenFiles(int openFiles) {
        this.openFiles = openFiles;
    }
    
    public int getActiveIterators() {
        return activeIterators;
    }
    
    public void setActiveIterators(int activeIterators) {
        this.activeIterators = activeIterators;
    }
    
    public String getError() {
        return error;
    }
    
    public void setError(String error) {
        this.error = error;
    }
    
    /**
     * 检查是否可以获取内存统计
     */
    public boolean isAvailable() {
        return error == null || error.isEmpty();
    }
    
    @Override
    public String toString() {
        if (!isAvailable()) {
            return "MemoryStats{error='" + error + "'}";
        }
        return "MemoryStats{" +
                "rssMB=" + String.format("%.2f", rssMB) +
                ", vmsMB=" + String.format("%.2f", vmsMB) +
                ", openFiles=" + openFiles +
                ", activeIterators=" + activeIterators +
                '}';
    }
}
