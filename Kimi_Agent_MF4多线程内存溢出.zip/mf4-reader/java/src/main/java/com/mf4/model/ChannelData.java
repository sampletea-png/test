package com.mf4.model;

import java.util.List;

/**
 * 通道数据
 */
public class ChannelData {
    
    private String name;
    private String unit;
    private List<Double> timestamps;
    private List<Object> values;
    private int sampleCount;
    
    public ChannelData() {
    }
    
    public ChannelData(String name, List<Double> timestamps, List<Object> values) {
        this.name = name;
        this.timestamps = timestamps;
        this.values = values;
        this.sampleCount = timestamps != null ? timestamps.size() : 0;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public List<Double> getTimestamps() {
        return timestamps;
    }
    
    public void setTimestamps(List<Double> timestamps) {
        this.timestamps = timestamps;
        this.sampleCount = timestamps != null ? timestamps.size() : 0;
    }
    
    public List<Object> getValues() {
        return values;
    }
    
    public void setValues(List<Object> values) {
        this.values = values;
    }
    
    public int getSampleCount() {
        return sampleCount;
    }
    
    public void setSampleCount(int sampleCount) {
        this.sampleCount = sampleCount;
    }
    
    /**
     * 获取双精度数值数组（如果值是数值类型）
     */
    public double[] getValuesAsDouble() {
        if (values == null) {
            return new double[0];
        }
        
        double[] result = new double[values.size()];
        for (int i = 0; i < values.size(); i++) {
            Object val = values.get(i);
            if (val instanceof Number) {
                result[i] = ((Number) val).doubleValue();
            } else {
                result[i] = 0.0;
            }
        }
        return result;
    }
    
    @Override
    public String toString() {
        return "ChannelData{" +
                "name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", sampleCount=" + sampleCount +
                '}';
    }
}
