package com.mf4;

import com.mf4.exception.Mf4Exception;

import java.io.Closeable;

/**
 * MF4服务接口 - 管理Python进程和文件操作
 */
public interface Mf4Service extends Closeable {
    
    /**
     * 启动服务
     */
    void start() throws Mf4Exception;
    
    /**
     * 检查服务是否已启动
     */
    boolean isRunning();
    
    /**
     * 打开文件（只读模式）
     */
    Mf4File openFile(String filePath) throws Mf4Exception;
    
    /**
     * 打开文件
     */
    Mf4File openFile(String filePath, boolean createIfNotExists) throws Mf4Exception;
    
    /**
     * 创建新文件
     */
    Mf4File createFile(String filePath) throws Mf4Exception;
    
    /**
     * 创建新文件（可指定是否覆盖）
     */
    Mf4File createFile(String filePath, boolean overwrite) throws Mf4Exception;
    
    /**
     * 获取Python服务端内存统计信息
     */
    MemoryStats getMemoryStats() throws Mf4Exception;
    
    /**
     * 关闭服务
     */
    @Override
    void close();
}
