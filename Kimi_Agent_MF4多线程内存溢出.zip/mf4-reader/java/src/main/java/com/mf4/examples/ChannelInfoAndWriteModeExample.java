package com.mf4.examples;

import com.mf4.*;
import com.mf4.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * 通道信息获取和写入模式示例
 * 
 * 演示如何：
 * 1. 获取通道的详细信息（包括comment等）
 * 2. 使用不同的写入模式（追加、覆盖、新建）
 */
public class ChannelInfoAndWriteModeExample {
    
    private static final Logger LOGGER = Logger.getLogger(ChannelInfoAndWriteModeExample.class.getName());
    
    public static void main(String[] args) {
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4Service service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            LOGGER.info("Service started");
            
            // 示例1: 获取通道详细信息
            getChannelInfoExample(service);
            
            // 示例2: 按名称查找通道
            findChannelExample(service);
            
            // 示例3: 使用不同写入模式
            writeModeExample(service);
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 示例1: 获取通道详细信息
     */
    static void getChannelInfoExample(Mf4Service service) {
        LOGGER.info("=== Get Channel Info Example ===");
        
        try {
            // 打开文件
            Mf4File file = service.openFile("/path/to/file.mf4");
            
            // 获取通道列表
            List<ChannelInfo> channels = file.getChannels(0);
            
            if (channels.isEmpty()) {
                LOGGER.info("No channels found");
                file.close();
                return;
            }
            
            // 获取第一个通道的详细信息
            ChannelInfo basicInfo = channels.get(0);
            LOGGER.info("Basic info - Name: " + basicInfo.getName() + 
                       ", Unit: " + basicInfo.getUnit());
            
            // 获取详细信息
            ChannelDetailInfo detailInfo = file.getChannelInfo(
                basicInfo.getGroupIndex(), 
                basicInfo.getChannelIndex()
            );
            
            LOGGER.info("Detailed info:");
            LOGGER.info("  Name: " + detailInfo.getName());
            LOGGER.info("  Unit: " + detailInfo.getUnit());
            LOGGER.info("  Comment: " + detailInfo.getComment());
            LOGGER.info("  Data Type: " + detailInfo.getDataType());
            LOGGER.info("  Sample Count: " + detailInfo.getSampleCount());
            LOGGER.info("  Start Time: " + detailInfo.getStartTime());
            LOGGER.info("  End Time: " + detailInfo.getEndTime());
            LOGGER.info("  Conversion: " + detailInfo.getConversion());
            LOGGER.info("  Source: " + detailInfo.getSource());
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Get channel info error: " + e.getMessage());
        }
    }
    
    /**
     * 示例2: 按名称查找通道
     */
    static void findChannelExample(Mf4Service service) {
        LOGGER.info("=== Find Channel Example ===");
        
        try {
            Mf4File file = service.openFile("/path/to/file.mf4");
            
            // 按名称查找通道（支持部分匹配）
            String searchName = "Voltage";  // 查找包含"Voltage"的通道
            List<ChannelInfo> foundChannels = file.findChannel(searchName);
            
            LOGGER.info("Found " + foundChannels.size() + " channels matching '" + searchName + "':");
            for (ChannelInfo ch : foundChannels) {
                LOGGER.info("  - " + ch.getName() + " (Group " + ch.getGroupIndex() + 
                           ", Channel " + ch.getChannelIndex() + ")");
            }
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Find channel error: " + e.getMessage());
        }
    }
    
    /**
     * 示例3: 使用不同写入模式
     */
    static void writeModeExample(Mf4Service service) {
        LOGGER.info("=== Write Mode Example ===");
        
        try {
            // 创建新文件
            Mf4File file = service.createFile("/path/to/write_test.mf4", true);
            
            // 创建测试数据
            ChannelData data1 = createTestData("Channel_A", 1000);
            ChannelData data2 = createTestData("Channel_B", 1000);
            
            // 模式1: CREATE_NEW - 创建新通道（如果存在则报错）
            LOGGER.info("Mode 1: CREATE_NEW");
            try {
                file.writeChannel(0, data1, Mf4File.WriteMode.CREATE_NEW);
                LOGGER.info("Channel_A created successfully");
            } catch (Exception e) {
                LOGGER.warning("CREATE_NEW failed: " + e.getMessage());
            }
            
            // 再次尝试创建同名通道，应该报错
            try {
                file.writeChannel(0, data1, Mf4File.WriteMode.CREATE_NEW);
                LOGGER.warning("Should have failed but didn't!");
            } catch (Exception e) {
                LOGGER.info("Expected error: " + e.getMessage());
            }
            
            // 模式2: APPEND - 追加到现有通道
            LOGGER.info("Mode 2: APPEND");
            ChannelData appendData = createTestData("Channel_A", 500);  // 更多数据
            file.writeChannel(0, appendData, Mf4File.WriteMode.APPEND);
            LOGGER.info("Data appended to Channel_A");
            
            // 验证追加结果
            ChannelDetailInfo info = file.getChannelInfo(0, 0);
            LOGGER.info("Channel_A now has " + info.getSampleCount() + " samples");
            
            // 模式3: OVERWRITE - 覆盖现有通道
            LOGGER.info("Mode 3: OVERWRITE");
            ChannelData newData = createTestData("Channel_A", 200);  // 完全不同的数据
            file.writeChannel(0, newData, Mf4File.WriteMode.OVERWRITE);
            LOGGER.info("Channel_A overwritten with new data");
            
            // 验证覆盖结果
            info = file.getChannelInfo(0, 0);
            LOGGER.info("Channel_A now has " + info.getSampleCount() + " samples after overwrite");
            
            // 批量写入多个通道
            LOGGER.info("Batch write with different modes:");
            List<ChannelData> batchData = new ArrayList<>();
            batchData.add(createTestData("Channel_C", 1000));
            batchData.add(createTestData("Channel_D", 1000));
            
            file.writeChannels(0, batchData, Mf4File.WriteMode.CREATE_NEW);
            LOGGER.info("Batch write completed");
            
            // 保存文件
            file.save();
            LOGGER.info("File saved");
            
            file.close();
            
        } catch (Exception e) {
            LOGGER.severe("Write mode error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 创建测试数据
     */
    static ChannelData createTestData(String name, int sampleCount) {
        ChannelData data = new ChannelData();
        data.setName(name);
        data.setUnit("V");
        
        List<Double> timestamps = new ArrayList<>(sampleCount);
        List<Double> values = new ArrayList<>(sampleCount);
        
        for (int i = 0; i < sampleCount; i++) {
            timestamps.add(i * 0.001);  // 1ms间隔
            values.add(Math.sin(i * 0.01) * 10);  // 正弦波
        }
        
        data.setTimestamps(timestamps);
        data.setValues(new ArrayList<>(values));
        
        return data;
    }
}
