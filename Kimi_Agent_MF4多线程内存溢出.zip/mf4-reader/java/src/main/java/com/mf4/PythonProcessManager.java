package com.mf4;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Python进程管理器 - 负责启动、监控和关闭Python服务
 */
public class PythonProcessManager {
    
    private static final Logger LOGGER = Logger.getLogger(PythonProcessManager.class.getName());
    
    private static final int STARTUP_TIMEOUT_SECONDS = 30;
    private static final int PORT_READ_TIMEOUT_MS = 10000;
    private static final int SHUTDOWN_TIMEOUT_SECONDS = 10;
    
    private final String pythonExecutable;
    private final String pythonScriptPath;
    private final String logDir;
    private final int preferredPort;
    
    private Process pythonProcess;
    private int actualPort = -1;
    private final AtomicBoolean running;
    private Thread shutdownHook;
    private Thread monitorThread;
    
    public PythonProcessManager(String pythonExecutable, String pythonScriptPath, 
                                 String logDir, int preferredPort) {
        this.pythonExecutable = pythonExecutable;
        this.pythonScriptPath = pythonScriptPath;
        this.logDir = logDir;
        this.preferredPort = preferredPort;
        this.running = new AtomicBoolean(false);
    }
    
    /**
     * 从资源路径创建管理器
     */
    public static PythonProcessManager fromResource(String resourcePath, String logDir, int preferredPort) {
        // 尝试从classpath加载
        String pythonPath = resolvePythonPath(resourcePath);
        String pythonExe = findPythonExecutable();
        
        return new PythonProcessManager(pythonExe, pythonPath, logDir, preferredPort);
    }
    
    /**
     * 解析Python脚本路径
     */
    private static String resolvePythonPath(String resourcePath) {
        // 首先检查是否是绝对路径
        File file = new File(resourcePath);
        if (file.exists()) {
            return file.getAbsolutePath();
        }
        
        // 检查classpath
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        java.net.URL resourceUrl = classLoader.getResource(resourcePath);
        if (resourceUrl != null) {
            return new File(resourceUrl.getFile()).getAbsolutePath();
        }
        
        // 检查工作目录
        Path workingDir = Paths.get(System.getProperty("user.dir"), resourcePath);
        if (workingDir.toFile().exists()) {
            return workingDir.toAbsolutePath().toString();
        }
        
        throw new RuntimeException("Cannot find Python script: " + resourcePath);
    }
    
    /**
     * 查找Python可执行文件
     */
    private static String findPythonExecutable() {
        String[] candidates = {"python3", "python", "py"};
        
        for (String candidate : candidates) {
            try {
                Process process = new ProcessBuilder(candidate, "--version")
                        .redirectErrorStream(true)
                        .start();
                
                boolean finished = process.waitFor(5, TimeUnit.SECONDS);
                if (finished && process.exitValue() == 0) {
                    return candidate;
                }
            } catch (Exception e) {
                // try next
            }
        }
        
        // 默认返回python3
        return "python3";
    }
    
    /**
     * 启动Python服务
     */
    public synchronized int start() throws IOException {
        if (running.get()) {
            LOGGER.info("Python service already running on port " + actualPort);
            return actualPort;
        }
        
        LOGGER.info("Starting Python service...");
        LOGGER.info("Python executable: " + pythonExecutable);
        LOGGER.info("Python script: " + pythonScriptPath);
        
        long parentPid = ProcessHandle.current().pid();
        
        ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                pythonScriptPath,
                "--port", String.valueOf(preferredPort),
                "--parent-pid", String.valueOf(parentPid)
        );
        
        if (logDir != null) {
            pb.command().add("--log-dir");
            pb.command().add(logDir);
        }
        
        pb.redirectErrorStream(true);
        
        // 设置环境变量
        pb.environment().put("PYTHONUNBUFFERED", "1");
        
        pythonProcess = pb.start();
        running.set(true);
        
        // 注册关闭钩子
        registerShutdownHook();
        
        // 启动监控线程
        startMonitorThread();
        
        // 读取端口号
        actualPort = readPortFromOutput();
        
        if (actualPort <= 0) {
            stop();
            throw new IOException("Failed to get port from Python service");
        }
        
        LOGGER.info("Python service started on port " + actualPort);
        
        // 等待服务就绪
        if (!waitForServiceReady()) {
            stop();
            throw new IOException("Python service failed to start");
        }
        
        return actualPort;
    }
    
    /**
     * 从Python输出中读取端口号
     */
    private int readPortFromOutput() throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(pythonProcess.getInputStream()));
        
        long startTime = System.currentTimeMillis();
        
        try {
            while (System.currentTimeMillis() - startTime < PORT_READ_TIMEOUT_MS) {
                if (reader.ready()) {
                    String line = reader.readLine();
                    if (line != null) {
                        LOGGER.fine("Python output: " + line);
                        
                        if (line.startsWith("PORT:")) {
                            try {
                                return Integer.parseInt(line.substring(5).trim());
                            } catch (NumberFormatException e) {
                                LOGGER.warning("Invalid port format: " + line);
                            }
                        }
                    }
                } else {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                
                // 检查进程是否还在运行
                if (!pythonProcess.isAlive()) {
                    throw new IOException("Python process exited unexpectedly");
                }
            }
        } finally {
            // 启动日志转发线程
            startLogForwarder(reader);
        }
        
        return -1;
    }
    
    /**
     * 启动日志转发线程
     */
    private void startLogForwarder(BufferedReader reader) {
        Thread logThread = new Thread(() -> {
            try {
                String line;
                while (running.get() && (line = reader.readLine()) != null) {
                    LOGGER.fine("[Python] " + line);
                }
            } catch (IOException e) {
                if (running.get()) {
                    LOGGER.log(Level.WARNING, "Error reading Python output", e);
                }
            }
        }, "PythonLogForwarder");
        logThread.setDaemon(true);
        logThread.start();
    }
    
    /**
     * 等待服务就绪
     */
    private boolean waitForServiceReady() {
        long startTime = System.currentTimeMillis();
        
        while (System.currentTimeMillis() - startTime < STARTUP_TIMEOUT_SECONDS * 1000L) {
            try {
                SocketClient client = new SocketClient("127.0.0.1", actualPort);
                client.connect();
                
                if (client.ping()) {
                    client.disconnect();
                    return true;
                }
                
                client.disconnect();
            } catch (Exception e) {
                // 服务还未就绪，继续等待
            }
            
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        
        return false;
    }
    
    /**
     * 注册JVM关闭钩子
     */
    private void registerShutdownHook() {
        shutdownHook = new Thread(this::stop, "PythonProcessShutdownHook");
        Runtime.getRuntime().addShutdownHook(shutdownHook);
    }
    
    /**
     * 启动监控线程
     */
    private void startMonitorThread() {
        monitorThread = new Thread(() -> {
            while (running.get()) {
                try {
                    if (pythonProcess != null && !pythonProcess.isAlive()) {
                        LOGGER.warning("Python process exited unexpectedly");
                        running.set(false);
                        break;
                    }
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "PythonProcessMonitor");
        monitorThread.setDaemon(true);
        monitorThread.start();
    }
    
    /**
     * 停止Python服务
     */
    public synchronized void stop() {
        if (!running.getAndSet(false)) {
            return;
        }
        
        LOGGER.info("Stopping Python service...");
        
        // 移除关闭钩子
        if (shutdownHook != null) {
            try {
                Runtime.getRuntime().removeShutdownHook(shutdownHook);
            } catch (IllegalStateException e) {
                // JVM已经在关闭中
            }
        }
        
        // 尝试优雅关闭
        if (pythonProcess != null && pythonProcess.isAlive()) {
            // 先尝试发送关闭请求
            try {
                SocketClient client = new SocketClient("127.0.0.1", actualPort);
                client.connect();
                client.shutdownServer();
            } catch (Exception e) {
                LOGGER.fine("Could not send shutdown request: " + e.getMessage());
            }
            
            // 等待进程结束
            boolean terminated = false;
            try {
                terminated = pythonProcess.waitFor(SHUTDOWN_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            // 强制终止
            if (!terminated) {
                LOGGER.warning("Python process did not terminate gracefully, forcing...");
                pythonProcess.destroyForcibly();
            }
        }
        
        pythonProcess = null;
        actualPort = -1;
        
        LOGGER.info("Python service stopped");
    }
    
    /**
     * 检查服务是否运行中
     */
    public boolean isRunning() {
        return running.get() && pythonProcess != null && pythonProcess.isAlive();
    }
    
    /**
     * 获取实际端口号
     */
    public int getPort() {
        return actualPort;
    }
}
