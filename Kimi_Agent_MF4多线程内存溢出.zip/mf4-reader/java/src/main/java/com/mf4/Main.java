package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.ChannelData;
import com.mf4.model.FileInfo;

import java.util.List;
import java.util.logging.Logger;

/**
 * 主入口类
 */
public class Main {
    
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    
    public static void main(String[] args) {
        // 示例用法
        String pythonScriptPath = "python/mf4_server.py";  // 相对于工作目录的路径
        
        try (Mf4ServiceImpl service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            LOGGER.info("Service started on port: " + service.getPort());
            
            // 示例: 打开一个MF4文件
            // Mf4File file = service.openFile("/path/to/your/file.mf4");
            // 
            // // 获取文件信息
            // FileInfo info = file.getInfo();
            // LOGGER.info("File info: " + info);
            // 
            // // 读取通道数据
            // ChannelData data = file.readChannel(0, 0);
            // LOGGER.info("Channel samples: " + data.getSampleCount());
            // 
            // // 关闭文件
            // file.close();
            
        } catch (Mf4Exception e) {
            LOGGER.severe("MF4 error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            LOGGER.severe("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
