package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.ChannelData;
import com.mf4.model.ChannelDetailInfo;
import com.mf4.model.ChannelInfo;
import com.mf4.model.FileInfo;

import java.io.Closeable;
import java.util.List;

/**
 * MF4文件操作接口
 */
public interface Mf4File extends Closeable {
    
    /**
     * 获取文件ID
     */
    String getFileId();
    
    /**
     * 获取文件路径
     */
    String getFilePath();
    
    /**
     * 获取文件信息
     */
    FileInfo getInfo() throws Mf4Exception;
    
    /**
     * 获取通道列表
     */
    List<ChannelInfo> getChannels() throws Mf4Exception;
    
    /**
     * 获取指定组的通道列表
     */
    List<ChannelInfo> getChannels(int groupIndex) throws Mf4Exception;
    
    /**
     * 获取单个通道的详细信息
     */
    ChannelDetailInfo getChannelInfo(int groupIndex, int channelIndex) throws Mf4Exception;
    
    /**
     * 根据名称查找通道（支持部分匹配）
     */
    List<ChannelInfo> findChannel(String channelName) throws Mf4Exception;
    
    /**
     * 读取单个通道数据
     */
    ChannelData readChannel(int groupIndex, int channelIndex) throws Mf4Exception;
    
    /**
     * 读取单个通道数据（带时间范围）
     */
    ChannelData readChannel(int groupIndex, int channelIndex, double startTime, double endTime) throws Mf4Exception;
    
    /**
     * 读取单个通道数据（限制采样数）
     */
    ChannelData readChannel(int groupIndex, int channelIndex, int maxSamples) throws Mf4Exception;
    
    /**
     * 创建流式读取迭代器（用于超大文件）
     */
    ChannelDataIterator readChannelStream(int groupIndex, int channelIndex) throws Mf4Exception;
    
    /**
     * 创建流式读取迭代器（带时间范围）
     */
    ChannelDataIterator readChannelStream(int groupIndex, int channelIndex, 
                                          double startTime, double endTime) throws Mf4Exception;
    
    /**
     * 批量读取多个通道数据
     */
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices) throws Mf4Exception;
    
    /**
     * 批量读取多个通道数据（带时间范围）
     */
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                   double startTime, double endTime) throws Mf4Exception;
    
    /**
     * 批量读取多个通道数据（带最大采样数限制）
     */
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                   double startTime, double endTime, int maxSamples) throws Mf4Exception;
    
    /**
     * 读取整个通道组的数据
     */
    List<ChannelData> readGroup(int groupIndex) throws Mf4Exception;
    
    /**
     * 读取整个通道组的数据（带最大通道数限制）
     */
    List<ChannelData> readGroup(int groupIndex, int maxChannels) throws Mf4Exception;
    
    /**
     * 写入通道数据（默认追加模式）
     */
    void writeChannel(int groupIndex, ChannelData data) throws Mf4Exception;
    
    /**
     * 写入通道数据（指定写入模式）
     */
    void writeChannel(int groupIndex, ChannelData data, WriteMode writeMode) throws Mf4Exception;
    
    /**
     * 批量写入通道数据（默认追加模式）
     */
    void writeChannels(int groupIndex, List<ChannelData> dataList) throws Mf4Exception;
    
    /**
     * 批量写入通道数据（指定写入模式）
     */
    void writeChannels(int groupIndex, List<ChannelData> dataList, WriteMode writeMode) throws Mf4Exception;
    
    /**
     * 批量写入通道数据（带批处理大小和写入模式）
     */
    void writeChannels(int groupIndex, List<ChannelData> dataList, int batchSize, WriteMode writeMode) throws Mf4Exception;
    
    /**
     * 保存文件到原路径
     */
    void save() throws Mf4Exception;
    
    /**
     * 保存文件到指定路径
     */
    void save(String filePath, boolean overwrite) throws Mf4Exception;
    
    /**
     * 关闭文件
     */
    @Override
    void close();
    
    /**
     * 检查文件是否已关闭
     */
    boolean isClosed();
    
    /**
     * 写入模式枚举
     */
    enum WriteMode {
        APPEND,      // 追加到现有通道
        OVERWRITE,   // 覆盖现有通道
        CREATE_NEW   // 创建新通道（如果存在则报错）
    }
}
