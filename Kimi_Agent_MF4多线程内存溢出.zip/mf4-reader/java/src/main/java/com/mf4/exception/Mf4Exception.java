package com.mf4.exception;

/**
 * MF4操作相关异常
 */
public class Mf4Exception extends Exception {
    
    private final String requestId;
    
    public Mf4Exception(String message) {
        super(message);
        this.requestId = null;
    }
    
    public Mf4Exception(String message, Throwable cause) {
        super(message, cause);
        this.requestId = null;
    }
    
    public Mf4Exception(String message, String requestId) {
        super(message);
        this.requestId = requestId;
    }
    
    public Mf4Exception(String message, Throwable cause, String requestId) {
        super(message, cause);
        this.requestId = requestId;
    }
    
    public String getRequestId() {
        return requestId;
    }
}
