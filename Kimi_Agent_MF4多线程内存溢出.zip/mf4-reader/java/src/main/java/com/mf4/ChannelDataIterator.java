package com.mf4;

import com.mf4.model.ChannelData;
import com.mf4.model.Request;
import com.mf4.model.Response;

import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 通道数据迭代器 - 支持大文件的流式读取
 */
public class ChannelDataIterator implements Iterator<ChannelData>, AutoCloseable {
    
    private static final Logger LOGGER = Logger.getLogger(ChannelDataIterator.class.getName());
    
    private final SocketClient client;
    private final String iteratorId;
    private final String fileId;
    private final int groupIndex;
    private final int channelIndex;
    
    private boolean hasMore;
    private boolean closed;
    private int currentChunkIndex;
    private int totalChunks;
    private int totalSamples;
    
    public ChannelDataIterator(SocketClient client, String iteratorId, String fileId,
                               int groupIndex, int channelIndex, boolean hasMore,
                               int currentChunkIndex, int totalChunks, int totalSamples) {
        this.client = client;
        this.iteratorId = iteratorId;
        this.fileId = fileId;
        this.groupIndex = groupIndex;
        this.channelIndex = channelIndex;
        this.hasMore = hasMore;
        this.currentChunkIndex = currentChunkIndex;
        this.totalChunks = totalChunks;
        this.totalSamples = totalSamples;
        this.closed = false;
    }
    
    @Override
    public boolean hasNext() {
        return hasMore && !closed;
    }
    
    @Override
    public ChannelData next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more data available");
        }
        
        try {
            // 如果当前是第一块，直接返回（已经在构造函数中）
            if (currentChunkIndex == 0) {
                currentChunkIndex++;
                // 需要重新读取第一块，这里简化处理
            }
            
            // 读取下一块
            Request request = Request.readNextChunk(iteratorId);
            Response response = client.sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new RuntimeException("Failed to read next chunk: " + response.getErrorMessage());
            }
            
            // 解析响应
            ChannelData data = parseChannelData(response.getData());
            
            // 更新状态
            hasMore = response.getData().get("hasMore") != null ? 
                     (Boolean) response.getData().get("hasMore") : false;
            currentChunkIndex = response.getData().get("chunkIndex") != null ?
                               ((Number) response.getData().get("chunkIndex")).intValue() : currentChunkIndex;
            
            return data;
            
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error reading next chunk", e);
            throw new RuntimeException("IO error reading next chunk", e);
        }
    }
    
    /**
     * 读取所有剩余数据（慎用，可能导致内存溢出）
     */
    public java.util.List<ChannelData> readAllRemaining() {
        java.util.List<ChannelData> allData = new java.util.ArrayList<>();
        
        while (hasNext()) {
            allData.add(next());
        }
        
        return allData;
    }
    
    @Override
    public void close() {
        if (closed) {
            return;
        }
        
        closed = true;
        
        try {
            Request request = Request.closeIterator(iteratorId);
            client.sendRequest(request);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Error closing iterator", e);
        }
    }
    
    public String getIteratorId() {
        return iteratorId;
    }
    
    public int getCurrentChunkIndex() {
        return currentChunkIndex;
    }
    
    public int getTotalChunks() {
        return totalChunks;
    }
    
    public int getTotalSamples() {
        return totalSamples;
    }
    
    public double getProgress() {
        if (totalChunks <= 0) {
            return 1.0;
        }
        return (double) currentChunkIndex / totalChunks;
    }
    
    @SuppressWarnings("unchecked")
    private ChannelData parseChannelData(java.util.Map<String, Object> data) {
        ChannelData result = new ChannelData();
        result.setName((String) data.get("name"));
        result.setUnit((String) data.get("unit"));
        
        java.util.List<Number> timestamps = (java.util.List<Number>) data.get("timestamps");
        if (timestamps != null) {
            java.util.List<Double> tsList = new java.util.ArrayList<>(timestamps.size());
            for (Number n : timestamps) {
                tsList.add(n.doubleValue());
            }
            result.setTimestamps(tsList);
        }
        
        result.setValues((java.util.List<Object>) data.get("values"));
        result.setSampleCount(((Number) data.get("sampleCount")).intValue());
        
        return result;
    }
}
