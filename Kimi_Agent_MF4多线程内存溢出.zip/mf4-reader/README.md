# MF4 File Reader - Java + Python 混合实现

一个支持多线程读写的MF4（ASAM MDF4）文件处理库，Java端提供接口，Python端处理具体的文件操作，通过Socket进行通信。

## 特性

- ✅ **多线程支持**：多个线程可以同时处理不同的MF4文件，也可以安全地处理同一文件
- ✅ **单一Python进程**：整个生命周期只有一个Python进程，支持Java端的多线程请求
- ✅ **自动生命周期管理**：Java端关闭时Python端自动关闭，Java异常退出时Python也会终止
- ✅ **大文件支持**：支持GB级MF4文件的分段读取，防止内存溢出
- ✅ **流式读取**：超大文件支持迭代器模式，分块读取数据
- ✅ **内存监控**：实时监控Python端内存使用，自动垃圾回收
- ✅ **灵活的文件操作**：支持创建、打开、读写、保存MF4文件
- ✅ **通道详细信息**：支持获取通道的comment、dataType、conversion等详细信息
- ✅ **通道搜索**：支持按名称查找通道（支持部分匹配）
- ✅ **写入模式选择**：支持追加(APPEND)、覆盖(OVERWRITE)、新建(CREATE_NEW)三种写入模式
- ✅ **完善的日志系统**：Python端独立日志，便于调试
- ✅ **自定义通信协议**：通过Request/Response类进行结构化通信

## 项目结构

```
mf4-reader/
├── README.md                      # 项目文档
├── python/                        # Python端代码
│   ├── requirements.txt           # Python依赖
│   ├── logger_config.py           # 日志配置
│   ├── protocol.py                # 通信协议
│   ├── mf4_handler.py             # MF4文件处理核心（支持大文件）
│   └── mf4_server.py              # Socket服务器主程序
└── java/                          # Java端代码
    ├── src/
    │   ├── main/java/com/mf4/
    │   │   ├── Mf4Service.java          # 服务接口
    │   │   ├── Mf4ServiceImpl.java      # 服务实现
    │   │   ├── Mf4File.java             # 文件操作接口
    │   │   ├── Mf4FileImpl.java         # 文件操作实现
    │   │   ├── ChannelDataIterator.java # 流式数据迭代器
    │   │   ├── MemoryStats.java         # 内存统计
    │   │   ├── SocketClient.java        # Socket客户端
    │   │   ├── PythonProcessManager.java # Python进程管理
    │   │   ├── Main.java                # 入口类
    │   │   ├── examples/
    │   │   │   ├── LargeFileExample.java           # 大文件处理示例
    │   │   │   └── ChannelInfoAndWriteModeExample.java # 通道信息和写入模式示例
    │   │   ├── model/
    │   │   │   ├── Request.java         # 请求类
    │   │   │   ├── Response.java        # 响应类
    │   │   │   ├── FileInfo.java        # 文件信息
    │   │   │   ├── ChannelInfo.java     # 通道信息
    │   │   │   ├── ChannelDetailInfo.java # 通道详细信息
    │   │   │   └── ChannelData.java     # 通道数据
    │   │   └── exception/
    │   │       └── Mf4Exception.java
    │   └── test/java/com/mf4/
    │       └── Mf4ServiceTest.java      # 测试类
    └── pom.xml                    # Maven配置
```

## 快速开始

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
```

### 2. 构建Java项目

```bash
cd java
mvn clean package
```

### 3. 使用示例

```java
import com.mf4.*;
import com.mf4.model.*;

public class Example {
    public static void main(String[] args) {
        // 创建服务实例
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4Service service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            
            // 创建新文件
            Mf4File file = service.createFile("/path/to/output.mf4");
            
            // 或打开现有文件
            // Mf4File file = service.openFile("/path/to/input.mf4");
            
            // 获取文件信息
            FileInfo info = file.getInfo();
            System.out.println("Version: " + info.getVersion());
            System.out.println("Channels: " + info.getChannelCount());
            
            // 获取通道列表
            List<ChannelInfo> channels = file.getChannels();
            for (ChannelInfo ch : channels) {
                System.out.println("Channel: " + ch.getName());
            }
            
            // 读取通道数据（自动限制最大100万样本）
            ChannelData data = file.readChannel(0, 0);
            System.out.println("Samples: " + data.getSampleCount());
            
            // 批量读取多个通道
            List<ChannelData> batchData = file.readChannels(0, new int[]{0, 1, 2});
            
            // 保存文件
            file.save();
            
            // 关闭文件
            file.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

## 通道信息和写入模式

### 获取通道详细信息

```java
Mf4File file = service.openFile("/path/to/file.mf4");

// 获取通道列表
List<ChannelInfo> channels = file.getChannels();

// 获取第一个通道的详细信息
ChannelDetailInfo detail = file.getChannelInfo(0, 0);
System.out.println("Name: " + detail.getName());
System.out.println("Comment: " + detail.getComment());
System.out.println("Data Type: " + detail.getDataType());
System.out.println("Sample Count: " + detail.getSampleCount());
System.out.println("Start Time: " + detail.getStartTime());
System.out.println("End Time: " + detail.getEndTime());
```

### 按名称查找通道

```java
// 查找包含"Voltage"的所有通道
List<ChannelInfo> found = file.findChannel("Voltage");
for (ChannelInfo ch : found) {
    System.out.println("Found: " + ch.getName());
}
```

### 使用不同写入模式

```java
// 创建新通道（如果存在则报错）
file.writeChannel(0, data, Mf4File.WriteMode.CREATE_NEW);

// 追加到现有通道
file.writeChannel(0, data, Mf4File.WriteMode.APPEND);

// 覆盖现有通道
file.writeChannel(0, data, Mf4File.WriteMode.OVERWRITE);

// 批量写入指定模式
List<ChannelData> batchData = Arrays.asList(data1, data2);
file.writeChannels(0, batchData, Mf4File.WriteMode.APPEND);
```

## 大文件处理指南

### 问题：内存溢出风险

当处理GB级MF4文件时，如果一次性读取所有数据，Python端会出现内存溢出。例如：
- 一个1GB的MF4文件可能包含数亿个采样点
- 每个采样点占用16字节（timestamp + value）
- 一次性加载会占用数GB内存

### 解决方案

#### 1. 使用流式读取（推荐）

```java
// 对于超大文件，使用流式读取
Mf4File file = service.openFile("/path/to/large_file.mf4");

// 创建流式迭代器
ChannelDataIterator iterator = file.readChannelStream(0, 0);

// 分块处理数据
while (iterator.hasNext()) {
    ChannelData chunk = iterator.next();
    System.out.println("Processing chunk " + iterator.getCurrentChunkIndex() + 
                       "/" + iterator.getTotalChunks());
    
    // 处理当前块的数据
    List<Double> timestamps = chunk.getTimestamps();
    List<Object> values = chunk.getValues();
    
    // 你的业务逻辑...
}

// 关闭迭代器
iterator.close();
```

#### 2. 限制采样数

```java
// 只读取前10万个样本
ChannelData data = file.readChannel(0, 0, 100000);
```

#### 3. 按时间范围读取

```java
// 只读取指定时间范围内的数据
ChannelData data = file.readChannel(0, 0, 0.0, 100.0);
```

#### 4. 限制批量读取的通道数

```java
// 批量读取时限制最大通道数
List<ChannelData> data = file.readGroup(0, 5);  // 最多读取5个通道
```

#### 5. 分批写入大文件

```java
// 写入大量数据时，自动分批处理
List<ChannelData> largeDataList = ...;  // 大量数据
file.writeChannels(0, largeDataList, 10000);  // 每批1万样本
```

### 内存监控

```java
// 获取Python服务端内存统计
MemoryStats stats = service.getMemoryStats();
System.out.println("Python RSS: " + stats.getRssMB() + " MB");
System.out.println("Open files: " + stats.getOpenFiles());
```

## 多线程使用示例

```java
// 服务实例是线程安全的，可以被多个线程共享
Mf4Service service = new Mf4ServiceImpl(pythonScriptPath);
service.start();

// 多个线程可以同时处理不同的文件
ExecutorService executor = Executors.newFixedThreadPool(5);

for (int i = 0; i < 5; i++) {
    final int index = i;
    executor.submit(() -> {
        // 每个线程打开自己的文件
        Mf4File file = service.openFile("/path/to/file" + index + ".mf4");
        
        // 使用流式读取处理大文件
        ChannelDataIterator iterator = file.readChannelStream(0, 0);
        while (iterator.hasNext()) {
            ChannelData chunk = iterator.next();
            // 处理数据...
        }
        iterator.close();
        
        file.close();
    });
}
```

## 内存保护机制

Python端实现了多层内存保护：

1. **单次读取限制**：默认最大100万样本/次
2. **数据分块**：超过100MB的数据自动分块返回
3. **内存监控**：实时监控内存使用，超过80%触发GC
4. **迭代器模式**：超大文件使用惰性加载
5. **强制GC**：每次读取后触发垃圾回收

## API文档

### Mf4Service 接口

| 方法 | 说明 |
|------|------|
| `start()` | 启动Python服务 |
| `isRunning()` | 检查服务是否运行中 |
| `openFile(path)` | 打开文件（只读） |
| `openFile(path, createIfNotExists)` | 打开文件，可指定不存在时创建 |
| `createFile(path)` | 创建新文件 |
| `createFile(path, overwrite)` | 创建文件，可指定是否覆盖 |
| `getMemoryStats()` | 获取Python端内存统计 |
| `close()` | 关闭服务 |

### Mf4File 接口

| 方法 | 说明 |
|------|------|
| `getInfo()` | 获取文件信息 |
| `getChannels()` | 获取所有通道列表 |
| `getChannels(groupIndex)` | 获取指定组的通道列表 |
| `getChannelInfo(group, channel)` | 获取通道详细信息（comment等） |
| `findChannel(name)` | 按名称查找通道（支持部分匹配） |
| `readChannel(group, channel)` | 读取单个通道数据（最大100万样本） |
| `readChannel(group, channel, start, end)` | 按时间范围读取 |
| `readChannel(group, channel, maxSamples)` | 限制采样数读取 |
| `readChannelStream(group, channel)` | 创建流式读取迭代器 |
| `readChannels(group, indices)` | 批量读取多个通道（最多10个） |
| `readGroup(groupIndex)` | 读取整个通道组（最多10个通道） |
| `writeChannel(group, data)` | 写入通道数据（默认追加） |
| `writeChannel(group, data, mode)` | 写入通道数据（指定模式） |
| `writeChannels(group, dataList, mode)` | 批量写入（指定模式） |
| `writeChannels(group, dataList, batchSize, mode)` | 批量写入（分批+模式） |
| `save()` | 保存到原路径 |
| `save(path, overwrite)` | 保存到指定路径 |
| `close()` | 关闭文件 |

#### 写入模式（WriteMode）

| 模式 | 说明 |
|------|------|
| `APPEND` | 追加到现有通道（默认） |
| `OVERWRITE` | 覆盖现有通道 |
| `CREATE_NEW` | 创建新通道（如果存在则报错） |

```java
// 追加模式（默认）
file.writeChannel(0, data, Mf4File.WriteMode.APPEND);

// 覆盖模式
file.writeChannel(0, data, Mf4File.WriteMode.OVERWRITE);

// 新建模式（通道已存在会报错）
file.writeChannel(0, data, Mf4File.WriteMode.CREATE_NEW);
```

### ChannelDataIterator 接口

| 方法 | 说明 |
|------|------|
| `hasNext()` | 是否有更多数据 |
| `next()` | 读取下一块数据 |
| `readAllRemaining()` | 读取所有剩余数据（慎用） |
| `getProgress()` | 获取读取进度（0.0-1.0） |
| `close()` | 关闭迭代器 |

## 通信协议

Java与Python之间使用自定义二进制协议进行通信：

```
协议头 (12字节):
  - 魔数 (4字节): "MF4P"
  - 版本 (1字节): 1
  - 保留 (3字节): 0
  - 数据长度 (4字节): 大端序

数据体:
  - JSON格式的Request/Response
```

### Request 格式

```json
{
  "requestType": "read_data",
  "requestId": "uuid",
  "fileId": "file-uuid",
  "data": {
    "groupIndex": 0,
    "channelIndex": 0,
    "samples": 100000,
    "useIterator": true
  }
}
```

### Response 格式（流式）

```json
{
  "requestId": "uuid",
  "status": "success",
  "data": {
    "timestamps": [...],
    "values": [...],
    "sampleCount": 10000,
    "iteratorId": "iter-uuid",
    "chunkIndex": 0,
    "totalChunks": 100,
    "hasMore": true
  }
}
```

## 日志配置

Python端日志默认保存在 `python/logs/` 目录下：
- 日志文件按天轮转: `mf4_server_YYYYMMDD.log`
- 单文件最大50MB，保留10个备份
- 包含时间戳、日志级别、线程名、文件名和行号

## 注意事项

1. **Python依赖**: 需要安装 `asammdf>=7.0.0` 和 `numpy>=1.20.0`
2. **Java版本**: 需要Java 11或更高版本
3. **大文件处理**: 读取大文件时建议使用流式读取或时间范围限制
4. **线程安全**: 单个Mf4File实例的读操作是线程安全的，写操作会加锁
5. **资源释放**: 确保调用 `close()` 方法释放资源，或使用 try-with-resources
6. **迭代器关闭**: 使用完ChannelDataIterator后务必调用 `close()`

## 性能优化建议

1. **优先使用流式读取**：对于超过100MB的文件
2. **限制采样数**：如果不需要全部数据
3. **批量读取通道**：减少通信开销
4. **及时关闭资源**：文件和迭代器用完后立即关闭
5. **监控内存使用**：定期调用 `getMemoryStats()`

## 许可证

MIT License
