#!/bin/bash

# Complete build script for Linux with mdflib integration

set -e

echo "=========================================="
echo "MDF4 Java Wrapper - Build Script"
echo "=========================================="

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed. Please install Java JDK first."
    exit 1
fi

echo "Java found: $(java -version 2>&1 | head -n 1)"

# Check if CMake is installed
if ! command -v cmake &> /dev/null; then
    echo "Error: CMake is not installed. Please install CMake first."
    exit 1
fi

echo "CMake found: $(cmake --version | head -n 1)"

# Check if mdflib is available
if [ ! -d "../mdflib" ]; then
    echo "Error: mdflib library not found."
    echo "Please clone mdflib first:"
    echo "  git clone https://github.com/ihedvall/mdflib.git"
    exit 1
fi

echo "mdflib found at: $(pwd)/../mdflib"

# Create build directory
echo "Creating build directory..."
mkdir -p build
cd build

# Configure CMake with mdflib
echo "Configuring CMake..."
cmake -DCMAKE_BUILD_TYPE=Release \
      -DMDF_BUILD_SHARED_LIB=ON \
      -DMDF_BUILD_SHARED_LIB_EXAMPLE=OFF \
      -DMDF_BUILD_TOOL=OFF \
      -DMDF_BUILD_TEST=OFF \
      -DMDF_BUILD_PYTHON=OFF \
      -DMDF_BUILD_DOC=OFF \
      ../..

# Build the project
echo "Building the project..."
make -j$(nproc)

echo "=========================================="
echo "Build completed successfully!"
echo "=========================================="
echo "Executable location: build/bin/mdf4_main"
echo "JNI library location: build/lib/libmdf4_jni.so"
