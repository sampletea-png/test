#!/bin/bash

# Test runner script for MDF4 Java Wrapper

echo "=========================================="
echo "MDF4 Java Wrapper - Test Runner"
echo "=========================================="

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed. Please install Maven first."
    exit 1
fi

echo "Maven found: $(mvn --version | head -n 1)"

# Create test directory
mkdir -p test
cd test

# Copy test files
cp ../src/test/java/com/example/mdf4/*.java .

# Compile test files
echo "Compiling test files..."
javac -cp "..:../build/bin" Mdf4WrapperTest.java Mdf4IntegrationTest.java Mdf4PerformanceTest.java

if [ $? -ne 0 ]; then
    echo "Compilation failed. Please make sure the native library is built first."
    exit 1
fi

echo "Compilation successful!"

# Run tests
echo "Running tests..."
java -cp "..:../build/bin:." com.example.mdf4.Mdf4WrapperTest
java -cp "..:../build/bin:." com.example.mdf4.Mdf4IntegrationTest
java -cp "..:../build/bin:." com.example.mdf4.Mdf4PerformanceTest

echo "=========================================="
echo "All tests completed!"
echo "=========================================="
