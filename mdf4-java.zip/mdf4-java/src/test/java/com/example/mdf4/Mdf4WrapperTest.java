package com.example.mdf4;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test cases for Mdf4Wrapper class
 */
public class Mdf4WrapperTest {

    private Mdf4Wrapper wrapper;
    private static final String TEST_FILE_PATH = "test_file.mf4";

    @BeforeEach
    public void setUp() {
        wrapper = new Mdf4Wrapper();
    }

    @AfterEach
    public void tearDown() {
        if (wrapper != null) {
            try {
                wrapper.closeFile();
            } catch (Exception e) {
                // Ignore close errors during testing
            }
        }
    }

    @Test
    public void testOpenFile() {
        // Test with non-existent file
        assertThrows(Exception.class, () -> {
            wrapper.openFile("non_existent_file.mf4");
        });

        // Test with valid file (if available)
        // This test would need a real MDF4 file to pass
        // For now, it's a placeholder for when we have test files
    }

    @Test
    public void testCloseFile() {
        // Test closing a file that was never opened
        assertDoesNotThrow(() -> {
            wrapper.closeFile();
        });
    }

    @Test
    public void testGetChannelCount() {
        // Test getting channel count before opening file
        assertEquals(0, wrapper.getChannelCount());

        // Test after opening file (if available)
        // wrapper.openFile(TEST_FILE_PATH);
        // assertEquals(expectedChannelCount, wrapper.getChannelCount());
    }

    @Test
    public void testGetChannelName() {
        // Test getting channel name with invalid index
        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(999);
        });
    }

    @Test
    public void testGetChannelUnit() {
        // Test getting channel unit with invalid index
        assertThrows(Exception.class, () -> {
            wrapper.getChannelUnit(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelUnit(999);
        });
    }

    @Test
    public void testGetChannelDescription() {
        // Test getting channel description with invalid index
        assertThrows(Exception.class, () -> {
            wrapper.getChannelDescription(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelDescription(999);
        });
    }

    @Test
    public void testReadChannelData() {
        // Test reading channel data with invalid parameters
        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(-1, 0, 10);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, -1, 10);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, 0, -1);
        });

        // Test reading channel data with valid parameters (if file is open)
        // double[] data = wrapper.readChannelData(0, 0, 10);
        // assertNotNull(data);
        // assertEquals(10, data.length);
    }

    @Test
    public void testMultipleOperations() {
        // Test sequence of operations
        assertDoesNotThrow(() -> {
            wrapper.openFile(TEST_FILE_PATH);
            int count = wrapper.getChannelCount();
            wrapper.closeFile();
        });
    }

    @Test
    public void testFileNotOpenException() {
        // Test that operations fail when file is not open
        assertThrows(Exception.class, () -> {
            wrapper.getChannelCount();
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(0);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, 0, 10);
        });
    }

    @Test
    public void testNullFilePath() {
        // Test with null file path
        assertThrows(Exception.class, () -> {
            wrapper.openFile(null);
        });
    }

    @Test
    public void testEmptyFilePath() {
        // Test with empty file path
        assertThrows(Exception.class, () -> {
            wrapper.openFile("");
        });
    }

    @Test
    public void testValidFileOperations() {
        // This test would be enabled when we have a valid MDF4 file
        // Currently it's skipped
        // @Disabled("Requires a valid MDF4 test file")
        // public void testValidFileOperations() {
        //     wrapper.openFile(TEST_FILE_PATH);
        //     assertTrue(wrapper.getChannelCount() > 0);
        //     assertNotNull(wrapper.getChannelName(0));
        //     assertNotNull(wrapper.getChannelUnit(0));
        //     assertNotNull(wrapper.getChannelDescription(0));
        //     assertNotNull(wrapper.readChannelData(0, 0, 10));
        //     wrapper.closeFile();
        // }
    }
}
