package com.example.mdf4;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for MDF4 Java Wrapper
 */
public class Mdf4IntegrationTest {

    private Mdf4Wrapper wrapper;

    @BeforeEach
    public void setUp() {
        wrapper = new Mdf4Wrapper();
    }

    @AfterEach
    public void tearDown() {
        if (wrapper != null) {
            try {
                wrapper.closeFile();
            } catch (Exception e) {
                // Ignore during testing
            }
        }
    }

    @Test
    public void testLibraryLoading() {
        // Test that JNI library is loaded successfully
        assertNotNull(wrapper);
        // The library loading happens in the static block
    }

    @Test
    public void testNativePointerInitialization() {
        // Test that native file pointer is initialized to 0
        assertNotNull(wrapper);
        // After construction, the native pointer should be 0
        // We can verify this by trying to open a file
        assertThrows(Exception.class, () -> {
            wrapper.getChannelCount();
        });
    }

    @Test
    public void testErrorHandling() {
        // Test various error scenarios
        Exception exception = assertThrows(Exception.class, () -> {
            wrapper.openFile("non_existent_file.mf4");
        });
        assertTrue(exception.getMessage().contains("Error") || exception.getMessage().contains("failed"));

        assertThrows(Exception.class, () -> {
            wrapper.getChannelCount();
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(0);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, 0, 10);
        });
    }

    @Test
    public void testSequentialOperations() {
        // Test that operations can be performed sequentially
        assertDoesNotThrow(wrapper::closeFile);

        assertDoesNotThrow(() -> {
            wrapper.openFile("test.mf4");
            wrapper.closeFile();
        });

        assertDoesNotThrow(() -> {
            wrapper.openFile("test.mf4");
            int count = wrapper.getChannelCount();
            wrapper.closeFile();
        });
    }

    @Test
    public void testFileOpenCloseCycle() {
        // Test opening and closing files multiple times
        assertThrows(Exception.class, () -> {
            wrapper.openFile("test.mf4");
            wrapper.closeFile();
            wrapper.openFile("test.mf4");
            wrapper.closeFile();
        });
    }

    @Test
    public void testInvalidIndices() {
        // Test with various invalid indices
        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(9999);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelUnit(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelUnit(9999);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelDescription(-1);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelDescription(9999);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(-1, 0, 10);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, -1, 10);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, 0, -1);
        });
    }

    @Test
    public void testEdgeCases() {
        // Test edge cases
        assertThrows(Exception.class, () -> {
            wrapper.openFile("");
        });

        assertThrows(Exception.class, () -> {
            wrapper.openFile(null);
        });

        assertThrows(Exception.class, () -> {
            wrapper.getChannelName(0);
        });

        assertThrows(Exception.class, () -> {
            wrapper.readChannelData(0, 0, 0);
        });
    }
}
