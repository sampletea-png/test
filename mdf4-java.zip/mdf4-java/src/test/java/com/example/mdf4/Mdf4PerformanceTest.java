package com.example.mdf4;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Performance tests for MDF4 Java Wrapper
 */
public class Mdf4PerformanceTest {

    @Test
    public void testLibraryLoadTime() {
        long startTime = System.currentTimeMillis();
        Mdf4Wrapper wrapper = new Mdf4Wrapper();
        long loadTime = System.currentTimeMillis() - startTime;

        // Library loading should be reasonably fast (< 1000ms)
        assertTrue(loadTime < 1000, "Library loading took too long: " + loadTime + "ms");

        wrapper.closeFile();
    }

    @Test
    public void testMultipleChannelOperations() {
        Mdf4Wrapper wrapper = new Mdf4Wrapper();

        try {
            wrapper.openFile("test.mf4");

            int channelCount = wrapper.getChannelCount();
            long startTime = System.currentTimeMillis();

            for (int i = 0; i < channelCount; i++) {
                wrapper.getChannelName(i);
                wrapper.getChannelUnit(i);
                wrapper.getChannelDescription(i);
            }

            long operationTime = System.currentTimeMillis() - startTime;

            System.out.println("Channel operations time for " + channelCount + " channels: " + operationTime + "ms");
            assertTrue(operationTime < 1000, "Channel operations took too long: " + operationTime + "ms");

            wrapper.closeFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testDataReadingPerformance() {
        Mdf4Wrapper wrapper = new Mdf4Wrapper();

        try {
            wrapper.openFile("test.mf4");

            if (wrapper.getChannelCount() > 0) {
                int channelIndex = 0;
                long startTime = System.currentTimeMillis();

                double[] data = wrapper.readChannelData(channelIndex, 0, 100);

                long readTime = System.currentTimeMillis() - startTime;

                System.out.println("Data read time for 100 samples: " + readTime + "ms");
                assertNotNull(data);
                assertEquals(100, data.length);

                wrapper.closeFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testMemoryLeakDetection() {
        int iterations = 100;
        Runtime runtime = Runtime.getRuntime();

        // Run garbage collection before test
        System.gc();
        Thread.sleep(100);

        long memoryBefore = runtime.totalMemory() - runtime.freeMemory();

        for (int i = 0; i < iterations; i++) {
            Mdf4Wrapper wrapper = new Mdf4Wrapper();
            try {
                wrapper.openFile("test.mf4");
                wrapper.closeFile();
            } catch (Exception e) {
                // Ignore errors during memory test
            }
        }

        // Run garbage collection after test
        System.gc();
        Thread.sleep(100);

        long memoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = memoryAfter - memoryBefore;

        System.out.println("Memory used for " + iterations + " iterations: " + memoryUsed + " bytes");
        // Allow some memory usage for object allocation
        assertTrue(memoryUsed < 10 * 1024 * 1024, "Memory usage too high: " + memoryUsed + " bytes");
    }

    @Test
    public void testStressTest() {
        int iterations = 10;
        Mdf4Wrapper wrapper = new Mdf4Wrapper();

        try {
            for (int i = 0; i < iterations; i++) {
                wrapper.openFile("test.mf4");
                wrapper.closeFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
