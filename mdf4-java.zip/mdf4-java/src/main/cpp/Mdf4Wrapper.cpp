#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cstring>
#include <iostream>

class Mdf4File {
private:
    std::string filePath;
    bool isOpen;
    int channelCount;

public:
    Mdf4File() : isOpen(false), channelCount(0) {}

    bool open(const std::string& path) {
        filePath = path;
        isOpen = true;

        // Check if file exists
        std::ifstream file(path);
        if (!file.good()) {
            return false;
        }

        // For now, we'll just read the file header to determine channel count
        // In a real implementation, we would parse the MDF4 format properly
        file.seekg(0, std::ios::end);
        long fileSize = file.tellg();
        file.seekg(0, std::ios::beg);

        // Simple heuristic: assume 100 channels for demonstration
        // In production, we would parse the MDF4 structure
        channelCount = 100;

        return true;
    }

    void close() {
        isOpen = false;
        filePath.clear();
        channelCount = 0;
    }

    int getChannelCount() const {
        return channelCount;
    }

    std::string getChannelName(int index) const {
        if (index < 0 || index >= channelCount) {
            return "Invalid channel index";
        }
        return "Channel_" + std::to_string(index);
    }

    std::vector<double> readChannelData(int index, int start, int length) const {
        std::vector<double> data;

        if (!isOpen || index < 0 || index >= channelCount) {
            return data;
        }

        // For demonstration, return random data
        for (int i = 0; i < length; i++) {
            data.push_back(static_cast<double>(index * 1000 + i));
        }

        return data;
    }

    std::string getChannelUnit(int index) const {
        if (index < 0 || index >= channelCount) {
            return "";
        }
        return "unit_" + std::to_string(index);
    }

    std::string getChannelDescription(int index) const {
        if (index < 0 || index >= channelCount) {
            return "";
        }
        return "Description for channel " + std::to_string(index);
    }
};

extern "C" {

JNIEXPORT void JNICALL Java_com_example_mdf4_Mdf4Wrapper_openFile(JNIEnv* env, jobject obj, jstring filePath) {
    Mdf4File* file = new Mdf4File();

    const char* path = env->GetStringUTFChars(filePath, nullptr);
    if (path != nullptr) {
        bool success = file->open(std::string(path));
        env->ReleaseStringUTFChars(filePath, path);

        if (success) {
            // Store the file object in the JNI object
            jclass clazz = env->GetObjectClass(obj);
            jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");
            env->SetLongField(obj, fileIdField, reinterpret_cast<jlong>(file));
        } else {
            delete file;
        }
    }
}

JNIEXPORT void JNICALL Java_com_example_mdf4_Mdf4Wrapper_closeFile(JNIEnv* env, jobject obj) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr != 0) {
        Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
        delete file;
        env->SetLongField(obj, fileIdField, 0);
    }
}

JNIEXPORT jint JNICALL Java_com_example_mdf4_Mdf4Wrapper_getChannelCount(JNIEnv* env, jobject obj) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr == 0) {
        return 0;
    }

    Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
    return file->getChannelCount();
}

JNIEXPORT jstring JNICALL Java_com_example_mdf4_Mdf4Wrapper_getChannelName(JNIEnv* env, jobject obj, jint index) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr == 0) {
        return env->NewStringUTF("File not open");
    }

    Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
    std::string name = file->getChannelName(index);
    return env->NewStringUTF(name.c_str());
}

JNIEXPORT jdoubleArray JNICALL Java_com_example_mdf4_Mdf4Wrapper_readChannelData(JNIEnv* env, jobject obj, jint index, jint start, jint length) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr == 0) {
        return nullptr;
    }

    Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
    std::vector<double> data = file->readChannelData(index, start, length);

    jdoubleArray result = env->NewDoubleArray(data.size());
    if (result != nullptr) {
        env->SetDoubleArrayRegion(result, 0, data.size(), data.data());
    }

    return result;
}

JNIEXPORT jstring JNICALL Java_com_example_mdf4_Mdf4Wrapper_getChannelUnit(JNIEnv* env, jobject obj, jint index) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr == 0) {
        return env->NewStringUTF("");
    }

    Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
    std::string unit = file->getChannelUnit(index);
    return env->NewStringUTF(unit.c_str());
}

JNIEXPORT jstring JNICALL Java_com_example_mdf4_Mdf4Wrapper_getChannelDescription(JNIEnv* env, jobject obj, jint index) {
    jclass clazz = env->GetObjectClass(obj);
    jfieldID fileIdField = env->GetFieldID(clazz, "nativeFilePtr", "J");

    jlong filePtr = env->GetLongField(obj, fileIdField);
    if (filePtr == 0) {
        return env->NewStringUTF("");
    }

    Mdf4File* file = reinterpret_cast<Mdf4File*>(filePtr);
    std::string description = file->getChannelDescription(index);
    return env->NewStringUTF(description.c_str());
}

}
