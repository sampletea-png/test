package com.example.mdf4;

public class Mdf4Wrapper {
    static {
        try {
            System.loadLibrary("mdf4_jni");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Failed to load mdf4_jni library");
            e.printStackTrace();
        }
    }

    public native void openFile(String filePath);
    public native void closeFile();
    public native int getChannelCount();
    public native String getChannelName(int index);
    public native double[] readChannelData(int index, int start, int length);
    public native String getChannelUnit(int index);
    public native String getChannelDescription(int index);

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java com.example.mdf4.Mdf4Wrapper <mf4_file_path>");
            return;
        }

        Mdf4Wrapper wrapper = new Mdf4Wrapper();
        try {
            System.out.println("Opening file: " + args[0]);
            wrapper.openFile(args[0]);

            int channelCount = wrapper.getChannelCount();
            System.out.println("Total channels: " + channelCount);

            for (int i = 0; i < channelCount; i++) {
                String channelName = wrapper.getChannelName(i);
                String channelUnit = wrapper.getChannelUnit(i);
                String channelDesc = wrapper.getChannelDescription(i);

                System.out.printf("Channel %d: %s\n", i, channelName);
                System.out.printf("  Unit: %s\n", channelUnit);
                System.out.printf("  Description: %s\n", channelDesc);
            }

            wrapper.closeFile();
            System.out.println("File processing completed successfully.");
        } catch (Exception e) {
            System.err.println("Error processing file: " + e.getMessage());
            e.printStackTrace();
            wrapper.closeFile();
        }
    }
}
