@echo off
REM Test runner script for Windows

echo ==========================================
echo MDF4 Java Wrapper - Test Runner
echo ==========================================

REM Check if Java is installed
where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: Java is not installed. Please install Java JDK first.
    exit /b 1
)

echo Java found:
java -version 2>&1 | findstr /C:"version"

REM Create test directory
if not exist test mkdir test
cd test

REM Copy test files
copy ..\src\test\java\com\example\mdf4\*.java .

REM Compile test files
echo Compiling test files...
javac -cp "..;..\build\bin" Mdf4WrapperTest.java Mdf4IntegrationTest.java Mdf4PerformanceTest.java

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed. Please make sure the native library is built first.
    exit /b 1
)

echo Compilation successful!

REM Run tests
echo Running tests...
java -cp "..;..\build\bin;." com.example.mdf4.Mdf4WrapperTest
java -cp "..;..\build\bin;." com.example.mdf4.Mdf4IntegrationTest
java -cp "..;..\build\bin;." com.example.mdf4.Mdf4PerformanceTest

echo ==========================================
echo All tests completed!
echo ==========================================
