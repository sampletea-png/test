@echo off
REM Build script for Windows

REM Check if Java is installed
where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: Java is not installed. Please install Java JDK first.
    exit /b 1
)

REM Check if CMake is installed
where cmake >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: CMake is not installed. Please install CMake first.
    exit /b 1
)

REM Create build directory
if not exist build mkdir build
cd build

REM Run CMake configuration
cmake ..

REM Build the project
cmake --build . --config Release

echo Build completed successfully!
echo The executable is located in: build\bin\

REM Copy library to bin directory
copy lib\mdf4_jni.dll bin\
