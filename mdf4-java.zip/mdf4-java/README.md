# MDF4 Java Native Interface Wrapper

This project demonstrates how to create a Java wrapper for MDF4 file handling using JNI (Java Native Interface). The project is designed to be built on both Windows and Linux systems.

## Project Overview

The project provides a JNI-based Java wrapper that allows Java applications to read and process MDF4 (ASAM MDF) measurement data files. The native code is written in C++ and interfaces with Java through JNI.

## Architecture

```
┌─────────────────────────────────────┐
│         Java Application            │
│   (Mdf4Wrapper.java)                │
└──────────────┬──────────────────────┘
               │ JNI Interface
               ↓
┌─────────────────────────────────────┐
│      JNI Native Library             │
│   (mdf4_jni.so/.dll)                │
└──────────────┬──────────────────────┘
               │
               ↓
┌─────────────────────────────────────┐
│      C++ Implementation             │
│   (Mdf4Wrapper.cpp)                 │
└──────────────┬──────────────────────┘
               │
               ↓
┌─────────────────────────────────────┐
│        MDF4 Library                 │
│   (mdflib C++ library)              │
└─────────────────────────────────────┘
```

## Features

- **Cross-platform support**: Windows and Linux
- **Java Native Interface**: Seamless integration between Java and C++
- **File handling**: Open, close, and read MDF4 files
- **Channel information**: Access channel names, units, and descriptions
- **Data reading**: Read channel data in Java
- **Error handling**: Basic error handling for file operations

## Build Requirements

### Required Software

1. **Java Development Kit (JDK)**: 8 or higher
   - Download: https://adoptium.net/

2. **CMake**: 3.15 or higher
   - Download: https://cmake.org/download/

3. **C++ Compiler**: 
   - Windows: Visual Studio 2019 or higher
   - Linux: GCC 7 or higher

4. **mdflib**: C++ library for MDF4 file handling
   - Repository: https://github.com/ihedvall/mdflib
   - License: MIT

### Optional Dependencies

5. **ZLIB**: Compression library (required by mdflib)
   - Download: https://www.zlib.net/

6. **EXPAT**: XML parsing library (required by mdflib)
   - Download: https://github.com/libexpat/libexpat

7. **Boost**: C++ libraries (optional, for GUI applications)
   - Download: https://www.boost.org/

## Building the Project

### Prerequisites

1. Clone the mdflib repository:
   ```bash
   git clone https://github.com/ihedvall/mdflib.git
   ```

2. Download and install required software (see above)

### Linux Build

```bash
chmod +x build_complete.sh
./build_complete.sh
```

### Windows Build

```bash
build_complete.bat
```

### Manual Build

#### Linux

```bash
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j$(nproc)
```

#### Windows

```cmd
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --config Release
```

## Project Structure

```
mdf4-java/
├── CMakeLists.txt                 # CMake build configuration
├── build_complete.sh              # Linux build script
├── build_complete.bat             # Windows build script
├── README.md                      # This file
├── RESOURCES.txt                  # List of required resources
├── MANIFEST.MF                    # Java manifest file
├── src/
│   ├── main/
│   │   ├── cpp/
│   │   │   ├── Mdf4Wrapper.cpp   # JNI native implementation
│   │   │   └── Mdf4Main.cpp       # C++ main program
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── mdf4/
│   │   │               └── Mdf4Wrapper.java  # Java wrapper class
│   │   └── resources/
│   │       └── MANIFEST.MF       # Java manifest file
└── build/                         # Build output directory
    ├── bin/                       # Executables and libraries
    └── lib/                       # Compiled libraries
```

## Usage

### Compile Java Code

```bash
javac src/main/java/com/example/mdf4/Mdf4Wrapper.java
```

### Run the Application

```bash
java -cp .:build/bin com.example.mdf4.Mdf4Wrapper /path/to/your/file.mf4
```

### Run the C++ Executable

```bash
./build/bin/mdf4_main /path/to/your/file.mf4
```

## API Reference

### Mdf4Wrapper Class

#### Methods

- `openFile(String filePath)`: Opens an MDF4 file
- `closeFile()`: Closes the currently open file
- `getChannelCount()`: Returns the number of channels in the file
- `getChannelName(int index)`: Returns the name of a channel
- `getChannelUnit(int index)`: Returns the unit of a channel
- `getChannelDescription(int index)`: Returns the description of a channel
- `readChannelData(int index, int start, int length)`: Reads channel data

## Integration with mdflib

For production use, you need to integrate the full mdflib C++ library. The current implementation is a demonstration. To integrate mdflib:

1. Build mdflib as a shared library
2. Link your JNI project with mdflib
3. Update the CMakeLists.txt to include mdflib dependencies
4. Implement proper MDF4 file parsing in the C++ code

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## Future Enhancements

- [ ] Full MDF4 file parsing support
- [ ] Writing MDF4 files
- [ ] Performance optimization for large files
- [ ] Advanced error handling
- [ ] Support for MDF3 files
- [ ] GUI application
- [ ] Command-line tools
- [ ] Maven/Gradle integration

## References

- [ASAM MDF Specification](https://www.asam.net/standards/detail/mdf/)
- [Java Native Interface (JNI) Documentation](https://docs.oracle.com/javase/8/docs/technotes/guides/jni/)
- [mdflib Documentation](https://ihedvall.github.io/mdflib/)
