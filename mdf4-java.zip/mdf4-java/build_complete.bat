@echo off
REM Complete build script for Windows with mdflib integration

echo ==========================================
echo MDF4 Java Wrapper - Build Script
echo ==========================================

REM Check if Java is installed
where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: Java is not installed. Please install Java JDK first.
    exit /b 1
)

echo Java found:
java -version 2>&1 | findstr /C:"version"

REM Check if CMake is installed
where cmake >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: CMake is not installed. Please install CMake first.
    exit /b 1
)

echo CMake found:
cmake --version | findstr /C:"cmake"

REM Check if mdflib is available
if not exist "..\mdflib" (
    echo Error: mdflib library not found.
    echo Please clone mdflib first:
    echo   git clone https://github.com/ihedvall/mdflib.git
    exit /b 1
)

echo mdflib found at: %cd%\..\mdflib

REM Create build directory
echo Creating build directory...
if not exist build mkdir build
cd build

REM Configure CMake with mdflib
echo Configuring CMake...
cmake -DCMAKE_BUILD_TYPE=Release ^
      -DMDF_BUILD_SHARED_LIB=ON ^
      -DMDF_BUILD_SHARED_LIB_EXAMPLE=OFF ^
      -DMDF_BUILD_TOOL=OFF ^
      -DMDF_BUILD_TEST=OFF ^
      -DMDF_BUILD_PYTHON=OFF ^
      -DMDF_BUILD_DOC=OFF ^
      ..\..

REM Build the project
echo Building the project...
cmake --build . --config Release

echo ==========================================
echo Build completed successfully!
echo ==========================================
echo Executable location: build\bin\mdf4_main.exe
echo JNI library location: build\lib\mdf4_jni.dll
