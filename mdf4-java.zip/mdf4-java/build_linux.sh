#!/bin/bash

# Build script for Linux

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed. Please install Java JDK first."
    exit 1
fi

# Check if CMake is installed
if ! command -v cmake &> /dev/null; then
    echo "Error: CMake is not installed. Please install CMake first."
    exit 1
fi

# Create build directory
mkdir -p build
cd build

# Run CMake configuration
cmake ..

# Build the project
make -j$(nproc)

echo "Build completed successfully!"
echo "The executable is located in: build/bin/"

# Copy library to bin directory
cp lib/libmdf4_jni.so bin/
