package com.mdf4.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * 信号信息类
 * 描述MDF4文件中信号的基本信息
 */
public class SignalInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String name;
    private String unit;
    private String comment;
    private DataType dataType;
    private Double minValue;
    private Double maxValue;
    
    public SignalInfo() {
        this.dataType = DataType.FLOAT64;
    }
    
    public SignalInfo(String name) {
        this();
        this.name = name;
    }
    
    public SignalInfo(String name, String unit) {
        this(name);
        this.unit = unit;
    }
    
    public SignalInfo(String name, String unit, String comment) {
        this(name, unit);
        this.comment = comment;
    }
    
    // Getters and Setters
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public DataType getDataType() {
        return dataType;
    }
    
    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }
    
    public Double getMinValue() {
        return minValue;
    }
    
    public void setMinValue(Double minValue) {
        this.minValue = minValue;
    }
    
    public Double getMaxValue() {
        return maxValue;
    }
    
    public void setMaxValue(Double maxValue) {
        this.maxValue = maxValue;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SignalInfo that = (SignalInfo) o;
        return Objects.equals(name, that.name);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
    
    @Override
    public String toString() {
        return "SignalInfo{" +
                "name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", comment='" + comment + '\'' +
                ", dataType=" + dataType +
                '}';
    }
}
