package com.mdf4.example;

import com.mdf4.MDF4Factory;
import com.mdf4.model.*;
import com.mdf4.utils.ThreadPoolManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 多线程示例 - 展示并发读写操作
 */
public class MultiThreadExample {
    
    private static final Logger LOGGER = Logger.getLogger(MultiThreadExample.class.getName());
    
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java -cp mdf4-reader-writer.jar com.mdf4.example.MultiThreadExample <python-script-path>");
            System.exit(1);
        }
        
        String pythonScriptPath = args[0];
        
        // 设置日志级别
        Logger.getLogger("").setLevel(Level.INFO);
        
        LOGGER.info("=== MDF4 Multi-Thread Example ===");
        
        try (MDF4Factory factory = MDF4Factory.builder()
                .pythonScriptPath(pythonScriptPath)
                .build()) {
            
            // 创建线程池
            ThreadPoolManager threadPool = new ThreadPoolManager(4);
            
            // ========== 并发写入多个文件 ==========
            LOGGER.info("\n--- Concurrent Write Operations ---");
            
            List<Callable<String>> writeTasks = new ArrayList<>();
            
            for (int i = 0; i < 4; i++) {
                final int fileIndex = i;
                writeTasks.add(() -> {
                    String fileName = "thread_test_" + fileIndex + ".mf4";
                    var writer = factory.getWriter();
                    
                    // 创建信号数据
                    List<SignalData> signals = createTestSignals(fileIndex);
                    writer.write(fileName, signals, CompressionType.ZIP, true);
                    
                    LOGGER.info("Thread " + fileIndex + " wrote " + fileName);
                    return fileName;
                });
            }
            
            // 执行并发写入
            List<Future<String>> writeFutures = new ArrayList<>();
            for (Callable<String> task : writeTasks) {
                writeFutures.add(threadPool.submit(task));
            }
            
            // 等待所有写入完成
            List<String> fileNames = new ArrayList<>();
            for (Future<String> future : writeFutures) {
                try {
                    fileNames.add(future.get());
                } catch (Exception e) {
                    LOGGER.severe("Write task failed: " + e.getMessage());
                }
            }
            
            LOGGER.info("All " + fileNames.size() + " files written successfully");
            
            // ========== 并发读取多个文件 ==========
            LOGGER.info("\n--- Concurrent Read Operations ---");
            
            List<Callable<FileInfo>> readTasks = new ArrayList<>();
            
            for (String fileName : fileNames) {
                readTasks.add(() -> {
                    var reader = factory.getReader();
                    FileInfo info = reader.readInfo(fileName);
                    LOGGER.info("Read info from " + fileName + ": " + 
                               info.getTotalSignalCount() + " signals");
                    return info;
                });
            }
            
            // 执行并发读取
            List<Future<FileInfo>> readFutures = new ArrayList<>();
            for (Callable<FileInfo> task : readTasks) {
                readFutures.add(threadPool.submit(task));
            }
            
            // 等待所有读取完成
            int totalSignals = 0;
            for (Future<FileInfo> future : readFutures) {
                try {
                    FileInfo info = future.get();
                    totalSignals += info.getTotalSignalCount();
                } catch (Exception e) {
                    LOGGER.severe("Read task failed: " + e.getMessage());
                }
            }
            
            LOGGER.info("Total signals across all files: " + totalSignals);
            
            // ========== 并行处理大信号 ==========
            LOGGER.info("\n--- Parallel Signal Processing ---");
            
            // 创建一个大信号文件
            String largeFile = "large_signal.mf4";
            LOGGER.info("Creating large signal file...");
            
            var writer = factory.getWriter();
            SignalData largeSignal = createLargeSignal("LargeSignal", 1000000);  // 100万样本
            writer.write(largeFile, Arrays.asList(largeSignal), CompressionType.ZIP, true);
            
            LOGGER.info("Large signal file created");
            
            // 分块读取和处理
            var reader = factory.getReader();
            SignalData readSignal = reader.readSignal(largeFile, "LargeSignal");
            
            // 并行处理信号数据
            int numChunks = 4;
            int chunkSize = readSignal.getLength() / numChunks;
            List<Callable<ProcessingResult>> processTasks = new ArrayList<>();
            
            for (int i = 0; i < numChunks; i++) {
                final int chunkIndex = i;
                final int startIdx = i * chunkSize;
                final int endIdx = (i == numChunks - 1) ? readSignal.getLength() : (i + 1) * chunkSize;
                
                processTasks.add(() -> {
                    double[] values = readSignal.getValues();
                    double sum = 0;
                    double max = Double.NEGATIVE_INFINITY;
                    double min = Double.POSITIVE_INFINITY;
                    
                    for (int j = startIdx; j < endIdx; j++) {
                        double v = values[j];
                        sum += v;
                        if (v > max) max = v;
                        if (v < min) min = v;
                    }
                    
                    double avg = sum / (endIdx - startIdx);
                    
                    LOGGER.info(String.format("Chunk %d: processed %d samples, avg=%.4f, min=%.4f, max=%.4f",
                            chunkIndex, endIdx - startIdx, avg, min, max));
                    
                    return new ProcessingResult(avg, min, max);
                });
            }
            
            // 执行并行处理
            List<Future<ProcessingResult>> processFutures = new ArrayList<>();
            for (Callable<ProcessingResult> task : processTasks) {
                processFutures.add(threadPool.submit(task));
            }
            
            // 收集结果
            double globalSum = 0;
            double globalMin = Double.POSITIVE_INFINITY;
            double globalMax = Double.NEGATIVE_INFINITY;
            
            for (Future<ProcessingResult> future : processFutures) {
                try {
                    ProcessingResult result = future.get();
                    globalSum += result.average;
                    if (result.min < globalMin) globalMin = result.min;
                    if (result.max > globalMax) globalMax = result.max;
                } catch (Exception e) {
                    LOGGER.severe("Processing task failed: " + e.getMessage());
                }
            }
            
            LOGGER.info(String.format("Global stats: min=%.4f, max=%.4f", globalMin, globalMax));
            
            // 关闭线程池
            threadPool.shutdown();
            
            LOGGER.info("\n=== Multi-Thread Example Completed Successfully ===");
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     * 创建测试信号
     */
    private static List<SignalData> createTestSignals(int index) {
        List<SignalData> signals = new ArrayList<>();
        
        // 信号1
        double[] timestamps1 = new double[1000];
        double[] values1 = new double[1000];
        double freq1 = 10 + index * 2;  // 不同频率
        
        for (int i = 0; i < 1000; i++) {
            timestamps1[i] = i * 0.001;
            values1[i] = Math.sin(2 * Math.PI * freq1 * timestamps1[i]);
        }
        
        SignalData signal1 = SignalData.create("Signal_" + index + "_A", "V", timestamps1, values1);
        signals.add(signal1);
        
        // 信号2
        double[] timestamps2 = new double[1000];
        double[] values2 = new double[1000];
        double freq2 = 5 + index;
        
        for (int i = 0; i < 1000; i++) {
            timestamps2[i] = i * 0.001;
            values2[i] = Math.cos(2 * Math.PI * freq2 * timestamps2[i]);
        }
        
        SignalData signal2 = SignalData.create("Signal_" + index + "_B", "V", timestamps2, values2);
        signals.add(signal2);
        
        return signals;
    }
    
    /**
     * 创建大信号
     */
    private static SignalData createLargeSignal(String name, int sampleCount) {
        double[] timestamps = new double[sampleCount];
        double[] values = new double[sampleCount];
        
        for (int i = 0; i < sampleCount; i++) {
            timestamps[i] = i * 0.0001;  // 0.1ms采样间隔
            values[i] = Math.sin(2 * Math.PI * 100 * timestamps[i]) +  // 100Hz
                       0.5 * Math.sin(2 * Math.PI * 200 * timestamps[i]) +  // 200Hz
                       0.25 * Math.sin(2 * Math.PI * 500 * timestamps[i]);  // 500Hz
        }
        
        return SignalData.create(name, "V", timestamps, values);
    }
    
    /**
     * 处理结果
     */
    private static class ProcessingResult {
        final double average;
        final double min;
        final double max;
        
        ProcessingResult(double average, double min, double max) {
            this.average = average;
            this.min = min;
            this.max = max;
        }
    }
}
