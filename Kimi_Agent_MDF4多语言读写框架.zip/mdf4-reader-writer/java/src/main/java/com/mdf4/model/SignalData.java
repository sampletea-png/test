package com.mdf4.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

/**
 * 信号数据类
 * 包含信号的时间戳和数值数据
 */
public class SignalData implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private SignalInfo info;
    private double[] timestamps;
    private double[] values;
    
    public SignalData() {
    }
    
    public SignalData(SignalInfo info) {
        this.info = info;
        this.timestamps = new double[0];
        this.values = new double[0];
    }
    
    public SignalData(SignalInfo info, double[] timestamps, double[] values) {
        this.info = info;
        this.timestamps = timestamps;
        this.values = values;
    }
    
    /**
     * 创建信号数据（便捷方法）
     */
    public static SignalData create(String name, double[] timestamps, double[] values) {
        SignalInfo info = new SignalInfo(name);
        return new SignalData(info, timestamps, values);
    }
    
    /**
     * 创建信号数据（带单位）
     */
    public static SignalData create(String name, String unit, double[] timestamps, double[] values) {
        SignalInfo info = new SignalInfo(name, unit);
        return new SignalData(info, timestamps, values);
    }
    
    /**
     * 获取数据长度
     */
    public int getLength() {
        return timestamps != null ? timestamps.length : 0;
    }
    
    /**
     * 检查数据是否为空
     */
    public boolean isEmpty() {
        return getLength() == 0;
    }
    
    /**
     * 获取时间范围
     */
    public double getStartTime() {
        return timestamps != null && timestamps.length > 0 ? timestamps[0] : 0;
    }
    
    public double getEndTime() {
        return timestamps != null && timestamps.length > 0 ? timestamps[timestamps.length - 1] : 0;
    }
    
    // Getters and Setters
    public SignalInfo getInfo() {
        return info;
    }
    
    public void setInfo(SignalInfo info) {
        this.info = info;
    }
    
    public double[] getTimestamps() {
        return timestamps;
    }
    
    public void setTimestamps(double[] timestamps) {
        this.timestamps = timestamps;
    }
    
    public double[] getValues() {
        return values;
    }
    
    public void setValues(double[] values) {
        this.values = values;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SignalData that = (SignalData) o;
        return Objects.equals(info, that.info) &&
                Arrays.equals(timestamps, that.timestamps) &&
                Arrays.equals(values, that.values);
    }
    
    @Override
    public int hashCode() {
        int result = Objects.hash(info);
        result = 31 * result + Arrays.hashCode(timestamps);
        result = 31 * result + Arrays.hashCode(values);
        return result;
    }
    
    @Override
    public String toString() {
        return "SignalData{" +
                "info=" + info +
                ", length=" + getLength() +
                ", timeRange=[" + getStartTime() + ", " + getEndTime() + "]" +
                '}';
    }
}
