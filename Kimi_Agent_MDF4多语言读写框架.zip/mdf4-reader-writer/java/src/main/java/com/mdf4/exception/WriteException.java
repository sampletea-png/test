package com.mdf4.exception;

/**
 * 写入异常
 */
public class WriteException extends MDF4Exception {
    private static final long serialVersionUID = 1L;
    
    public WriteException(String message) {
        super(message, 5001);
    }
    
    public WriteException(String message, Throwable cause) {
        super(message, cause, 5001);
    }
    
    public WriteException(String message, int errorCode) {
        super(message, errorCode);
    }
}
