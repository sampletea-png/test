package com.mdf4.exception;

/**
 * 读取异常
 */
public class ReadException extends MDF4Exception {
    private static final long serialVersionUID = 1L;
    
    public ReadException(String message) {
        super(message, 6001);
    }
    
    public ReadException(String message, Throwable cause) {
        super(message, cause, 6001);
    }
    
    public ReadException(String message, int errorCode) {
        super(message, errorCode);
    }
}
