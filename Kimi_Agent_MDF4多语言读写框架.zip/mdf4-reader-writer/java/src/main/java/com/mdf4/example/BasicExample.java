package com.mdf4.example;

import com.mdf4.MDF4Factory;
import com.mdf4.model.*;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 基础示例 - 展示MDF4读写基本用法
 */
public class BasicExample {
    
    private static final Logger LOGGER = Logger.getLogger(BasicExample.class.getName());
    
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java -cp mdf4-reader-writer.jar com.mdf4.example.BasicExample <python-script-path>");
            System.exit(1);
        }
        
        String pythonScriptPath = args[0];
        String outputFile = "example_output.mf4";
        
        // 设置日志级别
        Logger.getLogger("").setLevel(Level.INFO);
        
        LOGGER.info("=== MDF4 Basic Example ===");
        
        // 使用try-with-resources确保资源释放
        try (MDF4Factory factory = MDF4Factory.builder()
                .pythonScriptPath(pythonScriptPath)
                .build()) {
            
            LOGGER.info("Connected to Python service");
            
            // ========== 写入示例 ==========
            LOGGER.info("\n--- Writing Signals ---");
            
            // 创建第一个信号: 正弦波
            double[] timestamps1 = new double[1000];
            double[] values1 = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps1[i] = i * 0.001;  // 1ms采样间隔
                values1[i] = Math.sin(2 * Math.PI * 10 * timestamps1[i]);  // 10Hz正弦波
            }
            SignalData sineWave = SignalData.create("SineWave", "V", timestamps1, values1);
            sineWave.getInfo().setComment("10Hz sine wave signal");
            
            // 创建第二个信号: 方波
            double[] timestamps2 = new double[1000];
            double[] values2 = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps2[i] = i * 0.001;
                values2[i] = Math.signum(Math.sin(2 * Math.PI * 5 * timestamps2[i]));  // 5Hz方波
            }
            SignalData squareWave = SignalData.create("SquareWave", "V", timestamps2, values2);
            squareWave.getInfo().setComment("5Hz square wave signal");
            
            // 创建第三个信号: 三角波
            double[] timestamps3 = new double[1000];
            double[] values3 = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps3[i] = i * 0.001;
                double t = timestamps3[i] * 2;  // 2Hz三角波
                values3[i] = 2 * Math.abs(2 * (t - Math.floor(t + 0.5))) - 1;
            }
            SignalData triangleWave = SignalData.create("TriangleWave", "V", timestamps3, values3);
            triangleWave.getInfo().setComment("2Hz triangle wave signal");
            
            // 获取写入器并写入文件
            var writer = factory.getWriter();
            List<SignalData> signals = Arrays.asList(sineWave, squareWave, triangleWave);
            
            LOGGER.info("Writing " + signals.size() + " signals to " + outputFile);
            writer.write(outputFile, signals, CompressionType.ZIP, true);
            LOGGER.info("Write completed successfully!");
            
            // ========== 读取示例 ==========
            LOGGER.info("\n--- Reading File Info ---");
            
            var reader = factory.getReader();
            FileInfo fileInfo = reader.readInfo(outputFile);
            
            LOGGER.info("File Version: " + fileInfo.getVersion());
            LOGGER.info("Program: " + fileInfo.getProgram());
            LOGGER.info("Creation Time: " + fileInfo.getCreationTime());
            LOGGER.info("Total Signals: " + fileInfo.getTotalSignalCount());
            LOGGER.info("Signal Names: " + String.join(", ", fileInfo.getAllSignalNames()));
            
            // ========== 读取所有信号 ==========
            LOGGER.info("\n--- Reading All Signals ---");
            
            List<SignalData> readSignals = reader.read(outputFile);
            for (SignalData signal : readSignals) {
                SignalInfo info = signal.getInfo();
                LOGGER.info(String.format("Signal: %s, Unit: %s, Length: %d, TimeRange: [%.3f, %.3f]",
                        info.getName(),
                        info.getUnit(),
                        signal.getLength(),
                        signal.getStartTime(),
                        signal.getEndTime()));
            }
            
            // ========== 读取特定信号 ==========
            LOGGER.info("\n--- Reading Specific Signal ---");
            
            SignalData sineSignal = reader.readSignal(outputFile, "SineWave");
            LOGGER.info("Read signal: " + sineSignal.getInfo().getName());
            LOGGER.info("First 5 values:");
            for (int i = 0; i < Math.min(5, sineSignal.getLength()); i++) {
                LOGGER.info(String.format("  t=%.3f: %.4f", 
                        sineSignal.getTimestamps()[i], 
                        sineSignal.getValues()[i]));
            }
            
            // ========== 时间范围读取 ==========
            LOGGER.info("\n--- Reading with Time Range (0.1s - 0.2s) ---");
            
            List<SignalData> rangedSignals = reader.read(outputFile, 0.1, 0.2);
            for (SignalData signal : rangedSignals) {
                LOGGER.info(String.format("Signal: %s, Samples in range: %d",
                        signal.getInfo().getName(), signal.getLength()));
            }
            
            // ========== 追加信号示例 ==========
            LOGGER.info("\n--- Appending New Signal ---");
            
            double[] timestamps4 = new double[500];
            double[] values4 = new double[500];
            for (int i = 0; i < 500; i++) {
                timestamps4[i] = i * 0.002;
                values4[i] = Math.cos(2 * Math.PI * 3 * timestamps4[i]);  // 3Hz余弦波
            }
            SignalData cosineWave = SignalData.create("CosineWave", "V", timestamps4, values4);
            cosineWave.getInfo().setComment("3Hz cosine wave signal");
            
            writer.appendSignal(outputFile, cosineWave);
            LOGGER.info("Appended CosineWave signal");
            
            // 验证追加结果
            FileInfo updatedInfo = reader.readInfo(outputFile);
            LOGGER.info("Updated signal count: " + updatedInfo.getTotalSignalCount());
            
            LOGGER.info("\n=== Example Completed Successfully ===");
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
