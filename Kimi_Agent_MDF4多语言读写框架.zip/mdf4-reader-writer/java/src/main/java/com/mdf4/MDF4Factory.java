package com.mdf4;

import com.mdf4.client.SocketClient;
import com.mdf4.exception.ConnectionException;
import com.mdf4.manager.PythonProcessManager;
import com.mdf4.reader.MDF4Reader;
import com.mdf4.writer.MDF4Writer;

import java.util.logging.Logger;

/**
 * MDF4工厂类
 * 用于创建和管理MDF4Reader和MDF4Writer实例
 */
public class MDF4Factory implements AutoCloseable {
    
    private static final Logger LOGGER = Logger.getLogger(MDF4Factory.class.getName());
    
    private final PythonProcessManager processManager;
    private SocketClient client;
    private MDF4Reader reader;
    private MDF4Writer writer;
    private final boolean manageProcess;
    
    /**
     * 创建工厂（自动启动Python服务）
     * 
     * @param pythonScriptPath Python脚本路径
     * @throws ConnectionException 启动失败
     */
    public MDF4Factory(String pythonScriptPath) throws ConnectionException {
        this.manageProcess = true;
        this.processManager = new PythonProcessManager(pythonScriptPath);
        
        // 启动Python服务
        int port = processManager.start();
        
        // 创建客户端连接
        this.client = new SocketClient(processManager.getHost(), port);
        this.client.connect();
        
        LOGGER.info("MDF4Factory initialized, connected to Python service on port " + port);
    }
    
    /**
     * 创建工厂（连接到现有服务）
     * 
     * @param host 主机地址
     * @param port 端口号
     * @throws ConnectionException 连接失败
     */
    public MDF4Factory(String host, int port) throws ConnectionException {
        this.manageProcess = false;
        this.processManager = null;
        
        // 创建客户端连接
        this.client = new SocketClient(host, port);
        this.client.connect();
        
        LOGGER.info("MDF4Factory initialized, connected to existing service at " + host + ":" + port);
    }
    
    /**
     * 创建工厂（使用现有客户端）
     * 
     * @param client Socket客户端
     */
    public MDF4Factory(SocketClient client) {
        this.manageProcess = false;
        this.processManager = null;
        this.client = client;
        
        LOGGER.info("MDF4Factory initialized with existing client");
    }
    
    /**
     * 获取MDF4读取器
     * 
     * @return MDF4Reader实例
     */
    public synchronized MDF4Reader getReader() {
        if (reader == null) {
            reader = new MDF4Reader(client);
        }
        return reader;
    }
    
    /**
     * 获取MDF4写入器
     * 
     * @return MDF4Writer实例
     */
    public synchronized MDF4Writer getWriter() {
        if (writer == null) {
            writer = new MDF4Writer(client);
        }
        return writer;
    }
    
    /**
     * 检查连接状态
     * 
     * @return 是否已连接
     */
    public boolean isConnected() {
        return client != null && client.isConnected();
    }
    
    /**
     * 获取客户端
     * 
     * @return Socket客户端
     */
    public SocketClient getClient() {
        return client;
    }
    
    /**
     * 关闭工厂，释放资源
     */
    @Override
    public void close() {
        LOGGER.info("Closing MDF4Factory...");
        
        // 关闭读取器和写入器（它们会关闭文件）
        if (reader != null) {
            reader.closeAllFiles();
            reader = null;
        }
        
        if (writer != null) {
            writer.closeAllFiles();
            writer = null;
        }
        
        // 断开客户端连接
        if (client != null) {
            client.disconnect();
            client = null;
        }
        
        // 停止Python进程（如果是我们启动的）
        if (manageProcess && processManager != null) {
            processManager.stop();
        }
        
        LOGGER.info("MDF4Factory closed");
    }
    
    /**
     * 创建Builder
     */
    public static Builder builder() {
        return new Builder();
    }
    
    /**
     * 构建器
     */
    public static class Builder {
        private String pythonScriptPath;
        private String host = "127.0.0.1";
        private int port = -1;
        private SocketClient client;
        
        public Builder pythonScriptPath(String pythonScriptPath) {
            this.pythonScriptPath = pythonScriptPath;
            return this;
        }
        
        public Builder host(String host) {
            this.host = host;
            return this;
        }
        
        public Builder port(int port) {
            this.port = port;
            return this;
        }
        
        public Builder client(SocketClient client) {
            this.client = client;
            return this;
        }
        
        public MDF4Factory build() throws ConnectionException {
            if (client != null) {
                return new MDF4Factory(client);
            } else if (port > 0) {
                return new MDF4Factory(host, port);
            } else if (pythonScriptPath != null) {
                return new MDF4Factory(pythonScriptPath);
            } else {
                throw new IllegalArgumentException("Must specify either pythonScriptPath, host:port, or client");
            }
        }
    }
}
