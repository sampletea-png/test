package com.mdf4.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 通道组类
 * 表示MDF4文件中的一个通道组
 */
public class ChannelGroup implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String name;
    private String comment;
    private List<SignalInfo> signals;
    
    public ChannelGroup() {
        this.signals = new ArrayList<>();
    }
    
    public ChannelGroup(String name) {
        this();
        this.name = name;
    }
    
    public ChannelGroup(String name, String comment) {
        this(name);
        this.comment = comment;
    }
    
    /**
     * 添加信号
     */
    public void addSignal(SignalInfo signal) {
        signals.add(signal);
    }
    
    /**
     * 获取信号数量
     */
    public int getSignalCount() {
        return signals.size();
    }
    
    // Getters and Setters
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public List<SignalInfo> getSignals() {
        return signals;
    }
    
    public void setSignals(List<SignalInfo> signals) {
        this.signals = signals;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChannelGroup that = (ChannelGroup) o;
        return Objects.equals(name, that.name);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
    
    @Override
    public String toString() {
        return "ChannelGroup{" +
                "name='" + name + '\'' +
                ", comment='" + comment + '\'' +
                ", signalCount=" + getSignalCount() +
                '}';
    }
}
