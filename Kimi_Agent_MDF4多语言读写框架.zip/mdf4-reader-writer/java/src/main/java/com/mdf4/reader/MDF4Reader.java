package com.mdf4.reader;

import com.mdf4.client.SocketClient;
import com.mdf4.exception.ReadException;
import com.mdf4.model.*;

import java.util.*;

/**
 * MDF4读取器
 * 提供MDF4文件的读取功能
 */
public class MDF4Reader {
    
    private final SocketClient client;
    
    public MDF4Reader(SocketClient client) {
        this.client = client;
    }
    
    /**
     * 读取MDF4文件中的所有信号
     * 
     * @param filePath 文件路径
     * @return 信号数据列表
     * @throws ReadException 读取失败
     */
    public List<SignalData> read(String filePath) throws ReadException {
        return read(filePath, null, null, null);
    }
    
    /**
     * 读取指定信号
     * 
     * @param filePath 文件路径
     * @param signalNames 信号名称列表
     * @return 信号数据列表
     * @throws ReadException 读取失败
     */
    public List<SignalData> read(String filePath, List<String> signalNames) throws ReadException {
        return read(filePath, signalNames, null, null);
    }
    
    /**
     * 读取指定时间范围的信号
     * 
     * @param filePath 文件路径
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 信号数据列表
     * @throws ReadException 读取失败
     */
    public List<SignalData> read(String filePath, Double startTime, Double endTime) throws ReadException {
        return read(filePath, null, startTime, endTime);
    }
    
    /**
     * 读取指定信号和时间范围的数据
     * 
     * @param filePath 文件路径
     * @param signalNames 信号名称列表（null表示所有信号）
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 信号数据列表
     * @throws ReadException 读取失败
     */
    public List<SignalData> read(String filePath, List<String> signalNames, 
                                Double startTime, Double endTime) throws ReadException {
        
        if (filePath == null || filePath.isEmpty()) {
            throw new ReadException("File path cannot be empty");
        }
        
        try {
            // 构建请求payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            
            if (signalNames != null && !signalNames.isEmpty()) {
                payload.put("signalNames", signalNames);
            }
            
            if (startTime != null) {
                payload.put("startTime", startTime);
            }
            
            if (endTime != null) {
                payload.put("endTime", endTime);
            }
            
            // 发送请求
            Message message = new Message(MessageType.READ, payload);
            Response response = client.sendMessage(message);
            
            if (!response.isSuccess()) {
                throw new ReadException(response.getMessage(), response.getErrorCode());
            }
            
            // 解析响应数据
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> signalDataList = (List<Map<String, Object>>) response.getData();
            
            if (signalDataList == null) {
                return new ArrayList<>();
            }
            
            List<SignalData> result = new ArrayList<>();
            for (Map<String, Object> signalMap : signalDataList) {
                result.add(convertMapToSignal(signalMap));
            }
            
            return result;
            
        } catch (Exception e) {
            if (e instanceof ReadException) {
                throw (ReadException) e;
            }
            throw new ReadException("Failed to read MDF4 file", e);
        }
    }
    
    /**
     * 读取单个信号
     * 
     * @param filePath 文件路径
     * @param signalName 信号名称
     * @return 信号数据
     * @throws ReadException 读取失败
     */
    public SignalData readSignal(String filePath, String signalName) throws ReadException {
        List<SignalData> signals = read(filePath, Collections.singletonList(signalName));
        if (signals.isEmpty()) {
            throw new ReadException("Signal not found: " + signalName);
        }
        return signals.get(0);
    }
    
    /**
     * 读取MDF4文件信息
     * 
     * @param filePath 文件路径
     * @return 文件信息
     * @throws ReadException 读取失败
     */
    public FileInfo readInfo(String filePath) throws ReadException {
        
        if (filePath == null || filePath.isEmpty()) {
            throw new ReadException("File path cannot be empty");
        }
        
        try {
            // 构建请求payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            
            // 发送请求
            Message message = new Message(MessageType.READ_INFO, payload);
            Response response = client.sendMessage(message);
            
            if (!response.isSuccess()) {
                throw new ReadException(response.getMessage(), response.getErrorCode());
            }
            
            // 解析响应数据
            @SuppressWarnings("unchecked")
            Map<String, Object> fileInfoMap = (Map<String, Object>) response.getData();
            
            if (fileInfoMap == null) {
                throw new ReadException("Failed to read file info: empty response");
            }
            
            return convertMapToFileInfo(fileInfoMap);
            
        } catch (Exception e) {
            if (e instanceof ReadException) {
                throw (ReadException) e;
            }
            throw new ReadException("Failed to read MDF4 file info", e);
        }
    }
    
    /**
     * 获取所有信号名称
     * 
     * @param filePath 文件路径
     * @return 信号名称列表
     * @throws ReadException 读取失败
     */
    public List<String> getSignalNames(String filePath) throws ReadException {
        FileInfo fileInfo = readInfo(filePath);
        return fileInfo.getAllSignalNames();
    }
    
    /**
     * 关闭文件
     * 
     * @param filePath 文件路径
     */
    public void closeFile(String filePath) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            
            Message message = new Message(MessageType.CLOSE_FILE, payload);
            client.sendMessage(message);
        } catch (Exception e) {
            // 忽略关闭错误
        }
    }
    
    /**
     * 关闭所有文件
     */
    public void closeAllFiles() {
        try {
            Message message = new Message(MessageType.CLOSE_FILE, new HashMap<>());
            client.sendMessage(message);
        } catch (Exception e) {
            // 忽略关闭错误
        }
    }
    
    /**
     * 将Map转换为SignalData
     */
    @SuppressWarnings("unchecked")
    private SignalData convertMapToSignal(Map<String, Object> map) {
        SignalData signal = new SignalData();
        
        // 解析信号信息
        Map<String, Object> infoMap = (Map<String, Object>) map.get("info");
        if (infoMap != null) {
            SignalInfo info = new SignalInfo();
            info.setName((String) infoMap.get("name"));
            info.setUnit((String) infoMap.get("unit"));
            info.setComment((String) infoMap.get("comment"));
            
            String dataTypeStr = (String) infoMap.get("dataType");
            if (dataTypeStr != null) {
                info.setDataType(DataType.fromValue(dataTypeStr));
            }
            
            info.setMinValue((Double) infoMap.get("minValue"));
            info.setMaxValue((Double) infoMap.get("maxValue"));
            
            signal.setInfo(info);
        }
        
        // 解析时间戳和值
        String timestampsBase64 = (String) map.get("timestamps");
        String valuesBase64 = (String) map.get("values");
        Number lengthNum = (Number) map.get("length");
        int length = lengthNum != null ? lengthNum.intValue() : 0;
        
        if (length > 0 && timestampsBase64 != null && !timestampsBase64.isEmpty()) {
            signal.setTimestamps(decodeDoubleArray(timestampsBase64, length));
        } else {
            signal.setTimestamps(new double[0]);
        }
        
        if (length > 0 && valuesBase64 != null && !valuesBase64.isEmpty()) {
            signal.setValues(decodeDoubleArray(valuesBase64, length));
        } else {
            signal.setValues(new double[0]);
        }
        
        return signal;
    }
    
    /**
     * 将Map转换为FileInfo
     */
    @SuppressWarnings("unchecked")
    private FileInfo convertMapToFileInfo(Map<String, Object> map) {
        FileInfo fileInfo = new FileInfo();
        
        fileInfo.setVersion((String) map.get("version"));
        fileInfo.setProgram((String) map.get("program"));
        fileInfo.setComment((String) map.get("comment"));
        fileInfo.setCreationTime((String) map.get("creationTime"));
        
        // 解析通道组
        List<Map<String, Object>> channelGroupsList = (List<Map<String, Object>>) map.get("channelGroups");
        if (channelGroupsList != null) {
            List<ChannelGroup> channelGroups = new ArrayList<>();
            for (Map<String, Object> cgMap : channelGroupsList) {
                ChannelGroup cg = new ChannelGroup();
                cg.setName((String) cgMap.get("name"));
                cg.setComment((String) cgMap.get("comment"));
                
                // 解析信号
                List<Map<String, Object>> signalsList = (List<Map<String, Object>>) cgMap.get("signals");
                if (signalsList != null) {
                    for (Map<String, Object> sigMap : signalsList) {
                        SignalInfo signal = new SignalInfo();
                        signal.setName((String) sigMap.get("name"));
                        signal.setUnit((String) sigMap.get("unit"));
                        signal.setComment((String) sigMap.get("comment"));
                        
                        String dataTypeStr = (String) sigMap.get("dataType");
                        if (dataTypeStr != null) {
                            signal.setDataType(DataType.fromValue(dataTypeStr));
                        }
                        
                        signal.setMinValue((Double) sigMap.get("minValue"));
                        signal.setMaxValue((Double) sigMap.get("maxValue"));
                        
                        cg.addSignal(signal);
                    }
                }
                
                channelGroups.add(cg);
            }
            fileInfo.setChannelGroups(channelGroups);
        }
        
        return fileInfo;
    }
    
    /**
     * 将Base64字符串解码为double数组
     */
    private double[] decodeDoubleArray(String base64, int length) {
        if (base64 == null || base64.isEmpty()) {
            return new double[0];
        }
        
        byte[] bytes = Base64.getDecoder().decode(base64);
        double[] result = new double[length];
        
        for (int i = 0; i < length && i * 8 + 7 < bytes.length; i++) {
            long bits = ((long) (bytes[i * 8] & 0xFF) << 56) |
                       ((long) (bytes[i * 8 + 1] & 0xFF) << 48) |
                       ((long) (bytes[i * 8 + 2] & 0xFF) << 40) |
                       ((long) (bytes[i * 8 + 3] & 0xFF) << 32) |
                       ((long) (bytes[i * 8 + 4] & 0xFF) << 24) |
                       ((long) (bytes[i * 8 + 5] & 0xFF) << 16) |
                       ((long) (bytes[i * 8 + 6] & 0xFF) << 8) |
                       ((long) (bytes[i * 8 + 7] & 0xFF));
            result[i] = Double.longBitsToDouble(bits);
        }
        
        return result;
    }
}
