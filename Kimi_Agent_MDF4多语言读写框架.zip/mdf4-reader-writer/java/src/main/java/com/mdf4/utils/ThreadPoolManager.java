package com.mdf4.utils;

import java.util.concurrent.*;
import java.util.logging.Logger;

/**
 * 线程池管理器
 * 提供多线程读写支持
 */
public class ThreadPoolManager {
    
    private static final Logger LOGGER = Logger.getLogger(ThreadPoolManager.class.getName());
    
    // 默认线程池大小
    private static final int DEFAULT_POOL_SIZE = Runtime.getRuntime().availableProcessors();
    // 最大线程池大小
    private static final int MAX_POOL_SIZE = 32;
    
    private final ExecutorService executorService;
    private final int poolSize;
    
    public ThreadPoolManager() {
        this(DEFAULT_POOL_SIZE);
    }
    
    public ThreadPoolManager(int poolSize) {
        this.poolSize = Math.min(poolSize, MAX_POOL_SIZE);
        this.executorService = Executors.newFixedThreadPool(
                this.poolSize,
                new ThreadFactory() {
                    private int count = 0;
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread thread = new Thread(r, "MDF4-Worker-" + (++count));
                        thread.setDaemon(true);
                        return thread;
                    }
                }
        );
        LOGGER.info("ThreadPoolManager created with " + this.poolSize + " threads");
    }
    
    /**
     * 提交任务
     * 
     * @param task 任务
     * @return Future对象
     */
    public <T> Future<T> submit(Callable<T> task) {
        return executorService.submit(task);
    }
    
    /**
     * 提交Runnable任务
     * 
     * @param task 任务
     * @return Future对象
     */
    public Future<?> submit(Runnable task) {
        return executorService.submit(task);
    }
    
    /**
     * 执行批量任务并等待完成
     * 
     * @param tasks 任务列表
     * @param timeout 超时时间（毫秒）
     * @return 是否全部成功
     */
    public <T> boolean executeBatch(java.util.List<Callable<T>> tasks, long timeout) {
        try {
            java.util.List<Future<T>> futures = executorService.invokeAll(tasks, timeout, TimeUnit.MILLISECONDS);
            for (Future<T> future : futures) {
                if (future.isCancelled() || !future.isDone()) {
                    return false;
                }
            }
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }
    
    /**
     * 关闭线程池
     */
    public void shutdown() {
        LOGGER.info("Shutting down ThreadPoolManager...");
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
        LOGGER.info("ThreadPoolManager shut down");
    }
    
    /**
     * 立即关闭线程池
     */
    public void shutdownNow() {
        executorService.shutdownNow();
    }
    
    /**
     * 获取线程池大小
     */
    public int getPoolSize() {
        return poolSize;
    }
    
    /**
     * 检查是否已关闭
     */
    public boolean isShutdown() {
        return executorService.isShutdown();
    }
}
