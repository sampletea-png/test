package com.mdf4.model;

/**
 * 信号数据类型枚举
 */
public enum DataType {
    INT8("INT8"),
    UINT8("UINT8"),
    INT16("INT16"),
    UINT16("UINT16"),
    INT32("INT32"),
    UINT32("UINT32"),
    INT64("INT64"),
    UINT64("UINT64"),
    FLOAT32("FLOAT32"),
    FLOAT64("FLOAT64");
    
    private final String value;
    
    DataType(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
    
    public static DataType fromValue(String value) {
        for (DataType type : values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown data type: " + value);
    }
}
