package com.mdf4.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 通信消息类
 */
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private MessageType type;
    private Map<String, Object> payload;
    private String requestId;
    
    public Message() {
        this.requestId = UUID.randomUUID().toString();
        this.payload = new HashMap<>();
    }
    
    public Message(MessageType type) {
        this();
        this.type = type;
    }
    
    public Message(MessageType type, Map<String, Object> payload) {
        this(type);
        this.payload = payload;
    }
    
    /**
     * 转换为Map（用于JSON序列化）
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("type", type != null ? type.getValue() : null);
        map.put("payload", payload);
        map.put("requestId", requestId);
        return map;
    }
    
    /**
     * 从Map创建
     */
    @SuppressWarnings("unchecked")
    public static Message fromMap(Map<String, Object> map) {
        Message message = new Message();
        String typeValue = (String) map.get("type");
        if (typeValue != null) {
            message.type = MessageType.fromValue(typeValue);
        }
        message.payload = (Map<String, Object>) map.get("payload");
        message.requestId = (String) map.get("requestId");
        return message;
    }
    
    // Getters and Setters
    public MessageType getType() {
        return type;
    }
    
    public void setType(MessageType type) {
        this.type = type;
    }
    
    public Map<String, Object> getPayload() {
        return payload;
    }
    
    public void setPayload(Map<String, Object> payload) {
        this.payload = payload;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
}
