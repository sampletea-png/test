package com.mdf4;

import com.mdf4.model.*;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

/**
 * 主类 - 示例用法
 */
public class Main {
    
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java -jar mdf4-reader-writer.jar <python-script-path>");
            System.exit(1);
        }
        
        String pythonScriptPath = args[0];
        
        // 使用try-with-resources自动关闭资源
        try (MDF4Factory factory = MDF4Factory.builder()
                .pythonScriptPath(pythonScriptPath)
                .build()) {
            
            // 获取写入器
            var writer = factory.getWriter();
            
            // 创建示例信号数据
            String filePath = "test.mf4";
            
            // 信号1: 正弦波
            double[] timestamps1 = new double[1000];
            double[] values1 = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps1[i] = i * 0.01;
                values1[i] = Math.sin(timestamps1[i]);
            }
            SignalData signal1 = SignalData.create("SineWave", "V", timestamps1, values1);
            signal1.getInfo().setComment("Sine wave signal");
            
            // 信号2: 余弦波
            double[] timestamps2 = new double[1000];
            double[] values2 = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps2[i] = i * 0.01;
                values2[i] = Math.cos(timestamps2[i]);
            }
            SignalData signal2 = SignalData.create("CosineWave", "V", timestamps2, values2);
            signal2.getInfo().setComment("Cosine wave signal");
            
            // 写入文件
            LOGGER.info("Writing signals to " + filePath);
            writer.write(filePath, Arrays.asList(signal1, signal2), CompressionType.ZIP, true);
            LOGGER.info("Write completed successfully");
            
            // 获取读取器
            var reader = factory.getReader();
            
            // 读取文件信息
            LOGGER.info("Reading file info...");
            FileInfo fileInfo = reader.readInfo(filePath);
            LOGGER.info("File info: " + fileInfo);
            
            // 读取所有信号
            LOGGER.info("Reading all signals...");
            List<SignalData> signals = reader.read(filePath);
            for (SignalData signal : signals) {
                LOGGER.info("Signal: " + signal.getInfo().getName() + 
                           ", Length: " + signal.getLength());
            }
            
            // 读取特定信号
            LOGGER.info("Reading specific signal...");
            SignalData sineWave = reader.readSignal(filePath, "SineWave");
            LOGGER.info("SineWave: " + sineWave);
            
            LOGGER.info("All operations completed successfully!");
            
        } catch (Exception e) {
            LOGGER.severe("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
