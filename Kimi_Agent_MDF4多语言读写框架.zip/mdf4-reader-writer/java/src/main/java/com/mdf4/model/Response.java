package com.mdf4.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 响应类
 */
public class Response implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private boolean success;
    private String message;
    private Object data;
    private int errorCode;
    
    public Response() {
    }
    
    public Response(boolean success) {
        this.success = success;
    }
    
    public Response(boolean success, String message) {
        this(success);
        this.message = message;
    }
    
    /**
     * 转换为Map（用于JSON序列化）
     */
    public Map<String, Object> toMap() {
        @SuppressWarnings("unchecked")
        Map<String, Object> map = new java.util.HashMap<>();
        map.put("success", success);
        map.put("message", message);
        map.put("data", data);
        map.put("errorCode", errorCode);
        return map;
    }
    
    /**
     * 从Map创建
     */
    @SuppressWarnings("unchecked")
    public static Response fromMap(Map<String, Object> map) {
        Response response = new Response();
        response.success = Boolean.TRUE.equals(map.get("success"));
        response.message = (String) map.get("message");
        response.data = map.get("data");
        Number errorCodeNum = (Number) map.get("errorCode");
        response.errorCode = errorCodeNum != null ? errorCodeNum.intValue() : 0;
        return response;
    }
    
    /**
     * 获取数据作为SignalData列表
     */
    @SuppressWarnings("unchecked")
    public List<SignalData> getDataAsSignalDataList() {
        if (data instanceof List) {
            return (List<SignalData>) data;
        }
        return null;
    }
    
    /**
     * 获取数据作为FileInfo
     */
    public FileInfo getDataAsFileInfo() {
        if (data instanceof FileInfo) {
            return (FileInfo) data;
        }
        return null;
    }
    
    /**
     * 获取数据作为Map
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getDataAsMap() {
        if (data instanceof Map) {
            return (Map<String, Object>) data;
        }
        return null;
    }
    
    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public Object getData() {
        return data;
    }
    
    public void setData(Object data) {
        this.data = data;
    }
    
    public int getErrorCode() {
        return errorCode;
    }
    
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
    
    @Override
    public String toString() {
        return "Response{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", errorCode=" + errorCode +
                '}';
    }
}
