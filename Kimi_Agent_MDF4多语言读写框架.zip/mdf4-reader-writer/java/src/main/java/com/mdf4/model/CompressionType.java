package com.mdf4.model;

/**
 * 压缩类型枚举
 */
public enum CompressionType {
    NONE("NONE"),
    ZIP("ZIP"),
    TRANSPOSITION("TRANSPOSITION");
    
    private final String value;
    
    CompressionType(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
    
    public static CompressionType fromValue(String value) {
        for (CompressionType type : values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown compression type: " + value);
    }
}
