package com.mdf4.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mdf4.exception.ConnectionException;
import com.mdf4.model.*;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Socket客户端
 * 负责与Python服务端的通信
 */
public class SocketClient {
    
    // 消息头长度: 4字节（消息长度）
    private static final int HEADER_SIZE = 4;
    // 缓冲区大小: 64KB
    private static final int BUFFER_SIZE = 65536;
    // 最大消息大小: 1GB
    private static final int MAX_MESSAGE_SIZE = 1024 * 1024 * 1024;
    
    private final String host;
    private final int port;
    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    private final Gson gson;
    private final AtomicBoolean connected;
    private final ReentrantLock lock;
    
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.gson = new GsonBuilder()
                .serializeNulls()
                .create();
        this.connected = new AtomicBoolean(false);
        this.lock = new ReentrantLock();
    }
    
    /**
     * 连接到服务器
     */
    public void connect() throws ConnectionException {
        lock.lock();
        try {
            if (connected.get()) {
                return;
            }
            
            try {
                socket = new Socket(host, port);
                socket.setTcpNoDelay(true);
                socket.setKeepAlive(true);
                socket.setSoTimeout(30000); // 30秒超时
                
                inputStream = new DataInputStream(
                        new BufferedInputStream(socket.getInputStream(), BUFFER_SIZE));
                outputStream = new DataOutputStream(
                        new BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE));
                
                connected.set(true);
            } catch (IOException e) {
                throw new ConnectionException("Failed to connect to server: " + host + ":" + port, e);
            }
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 断开连接
     */
    public void disconnect() {
        lock.lock();
        try {
            connected.set(false);
            
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    // Ignore
                }
                inputStream = null;
            }
            
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    // Ignore
                }
                outputStream = null;
            }
            
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // Ignore
                }
                socket = null;
            }
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 发送消息并接收响应
     */
    public Response sendMessage(Message message) throws ConnectionException {
        lock.lock();
        try {
            if (!connected.get()) {
                throw new ConnectionException("Not connected to server");
            }
            
            // 序列化消息
            String messageJson = gson.toJson(message.toMap());
            byte[] messageData = messageJson.getBytes(StandardCharsets.UTF_8);
            
            if (messageData.length > MAX_MESSAGE_SIZE) {
                throw new ConnectionException("Message too large: " + messageData.length);
            }
            
            // 发送消息（长度前缀 + 数据）
            try {
                outputStream.writeInt(messageData.length);
                outputStream.write(messageData);
                outputStream.flush();
            } catch (IOException e) {
                connected.set(false);
                throw new ConnectionException("Failed to send message", e);
            }
            
            // 接收响应
            return receiveResponse();
            
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 接收响应
     */
    private Response receiveResponse() throws ConnectionException {
        try {
            // 读取消息长度
            int messageLength = inputStream.readInt();
            
            if (messageLength > MAX_MESSAGE_SIZE || messageLength < 0) {
                throw new ConnectionException("Invalid message length: " + messageLength);
            }
            
            // 读取消息体
            byte[] messageData = new byte[messageLength];
            int totalRead = 0;
            while (totalRead < messageLength) {
                int read = inputStream.read(messageData, totalRead, messageLength - totalRead);
                if (read < 0) {
                    throw new ConnectionException("Connection closed while reading response");
                }
                totalRead += read;
            }
            
            // 解析JSON响应
            String responseJson = new String(messageData, StandardCharsets.UTF_8);
            @SuppressWarnings("unchecked")
            java.util.Map<String, Object> responseMap = gson.fromJson(responseJson, java.util.Map.class);
            
            return Response.fromMap(responseMap);
            
        } catch (IOException e) {
            connected.set(false);
            throw new ConnectionException("Failed to receive response", e);
        }
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return connected.get() && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    /**
     * 获取主机地址
     */
    public String getHost() {
        return host;
    }
    
    /**
     * 获取端口
     */
    public int getPort() {
        return port;
    }
}
