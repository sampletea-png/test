package com.mdf4.exception;

/**
 * 连接异常
 */
public class ConnectionException extends MDF4Exception {
    private static final long serialVersionUID = 1L;
    
    public ConnectionException(String message) {
        super(message, 4001);
    }
    
    public ConnectionException(String message, Throwable cause) {
        super(message, cause, 4001);
    }
}
