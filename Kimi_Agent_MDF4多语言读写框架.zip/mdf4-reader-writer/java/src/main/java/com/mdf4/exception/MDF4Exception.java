package com.mdf4.exception;

/**
 * MDF4操作异常基类
 */
public class MDF4Exception extends Exception {
    private static final long serialVersionUID = 1L;
    
    private int errorCode;
    
    public MDF4Exception(String message) {
        super(message);
        this.errorCode = -1;
    }
    
    public MDF4Exception(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = -1;
    }
    
    public MDF4Exception(String message, int errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public MDF4Exception(String message, Throwable cause, int errorCode) {
        super(message, cause);
        this.errorCode = errorCode;
    }
    
    public int getErrorCode() {
        return errorCode;
    }
}
