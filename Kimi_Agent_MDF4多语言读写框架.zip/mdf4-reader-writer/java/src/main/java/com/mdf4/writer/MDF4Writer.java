package com.mdf4.writer;

import com.mdf4.client.SocketClient;
import com.mdf4.exception.WriteException;
import com.mdf4.model.*;

import java.util.*;

/**
 * MDF4写入器
 * 提供MDF4文件的写入功能
 */
public class MDF4Writer {
    
    private final SocketClient client;
    
    public MDF4Writer(SocketClient client) {
        this.client = client;
    }
    
    /**
     * 写入信号数据到MDF4文件
     * 
     * @param filePath 文件路径
     * @param signals 信号数据列表
     * @throws WriteException 写入失败
     */
    public void write(String filePath, List<SignalData> signals) throws WriteException {
        write(filePath, signals, CompressionType.ZIP, false);
    }
    
    /**
     * 写入信号数据到MDF4文件
     * 
     * @param filePath 文件路径
     * @param signals 信号数据列表
     * @param compression 压缩类型
     * @throws WriteException 写入失败
     */
    public void write(String filePath, List<SignalData> signals, 
                     CompressionType compression) throws WriteException {
        write(filePath, signals, compression, false);
    }
    
    /**
     * 写入信号数据到MDF4文件
     * 
     * @param filePath 文件路径
     * @param signals 信号数据列表
     * @param compression 压缩类型
     * @param overwrite 是否覆盖现有文件
     * @throws WriteException 写入失败
     */
    public void write(String filePath, List<SignalData> signals, 
                     CompressionType compression, boolean overwrite) throws WriteException {
        
        if (filePath == null || filePath.isEmpty()) {
            throw new WriteException("File path cannot be empty");
        }
        
        if (signals == null || signals.isEmpty()) {
            throw new WriteException("Signals cannot be empty");
        }
        
        try {
            // 构建请求payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            payload.put("compression", compression.getValue());
            payload.put("overwrite", overwrite);
            
            // 转换信号数据
            List<Map<String, Object>> signalList = new ArrayList<>();
            for (SignalData signal : signals) {
                signalList.add(convertSignalToMap(signal));
            }
            payload.put("signals", signalList);
            
            // 发送请求
            Message message = new Message(MessageType.WRITE, payload);
            Response response = client.sendMessage(message);
            
            if (!response.isSuccess()) {
                throw new WriteException(response.getMessage(), response.getErrorCode());
            }
            
        } catch (Exception e) {
            if (e instanceof WriteException) {
                throw (WriteException) e;
            }
            throw new WriteException("Failed to write MDF4 file", e);
        }
    }
    
    /**
     * 写入单个信号
     * 
     * @param filePath 文件路径
     * @param signal 信号数据
     * @throws WriteException 写入失败
     */
    public void writeSignal(String filePath, SignalData signal) throws WriteException {
        write(filePath, Collections.singletonList(signal));
    }
    
    /**
     * 追加信号到现有MDF4文件
     * 
     * @param filePath 文件路径
     * @param signals 信号数据列表
     * @throws WriteException 追加失败
     */
    public void append(String filePath, List<SignalData> signals) throws WriteException {
        
        if (filePath == null || filePath.isEmpty()) {
            throw new WriteException("File path cannot be empty");
        }
        
        if (signals == null || signals.isEmpty()) {
            throw new WriteException("Signals cannot be empty");
        }
        
        try {
            // 构建请求payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            
            // 转换信号数据
            List<Map<String, Object>> signalList = new ArrayList<>();
            for (SignalData signal : signals) {
                signalList.add(convertSignalToMap(signal));
            }
            payload.put("signals", signalList);
            
            // 发送请求
            Message message = new Message(MessageType.APPEND, payload);
            Response response = client.sendMessage(message);
            
            if (!response.isSuccess()) {
                throw new WriteException(response.getMessage(), response.getErrorCode());
            }
            
        } catch (Exception e) {
            if (e instanceof WriteException) {
                throw (WriteException) e;
            }
            throw new WriteException("Failed to append to MDF4 file", e);
        }
    }
    
    /**
     * 追加单个信号
     * 
     * @param filePath 文件路径
     * @param signal 信号数据
     * @throws WriteException 追加失败
     */
    public void appendSignal(String filePath, SignalData signal) throws WriteException {
        append(filePath, Collections.singletonList(signal));
    }
    
    /**
     * 关闭文件
     * 
     * @param filePath 文件路径
     */
    public void closeFile(String filePath) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("filePath", filePath);
            
            Message message = new Message(MessageType.CLOSE_FILE, payload);
            client.sendMessage(message);
        } catch (Exception e) {
            // 忽略关闭错误
        }
    }
    
    /**
     * 关闭所有文件
     */
    public void closeAllFiles() {
        try {
            Message message = new Message(MessageType.CLOSE_FILE, new HashMap<>());
            client.sendMessage(message);
        } catch (Exception e) {
            // 忽略关闭错误
        }
    }
    
    /**
     * 将SignalData转换为Map
     */
    private Map<String, Object> convertSignalToMap(SignalData signal) {
        Map<String, Object> map = new HashMap<>();
        
        // 信号信息
        Map<String, Object> infoMap = new HashMap<>();
        SignalInfo info = signal.getInfo();
        infoMap.put("name", info.getName());
        infoMap.put("unit", info.getUnit());
        infoMap.put("comment", info.getComment());
        infoMap.put("dataType", info.getDataType().getValue());
        infoMap.put("minValue", info.getMinValue());
        infoMap.put("maxValue", info.getMaxValue());
        
        map.put("info", infoMap);
        
        // 时间戳和值（转换为Base64编码的二进制数据）
        double[] timestamps = signal.getTimestamps();
        double[] values = signal.getValues();
        
        map.put("timestamps", encodeDoubleArray(timestamps));
        map.put("values", encodeDoubleArray(values));
        map.put("timestampType", "float64");
        map.put("valueType", "float64");
        map.put("length", timestamps != null ? timestamps.length : 0);
        
        return map;
    }
    
    /**
     * 将double数组编码为Base64字符串
     */
    private String encodeDoubleArray(double[] array) {
        if (array == null || array.length == 0) {
            return "";
        }
        
        // 将double数组转换为字节数组
        byte[] bytes = new byte[array.length * 8];
        for (int i = 0; i < array.length; i++) {
            long bits = Double.doubleToLongBits(array[i]);
            bytes[i * 8] = (byte) (bits >> 56);
            bytes[i * 8 + 1] = (byte) (bits >> 48);
            bytes[i * 8 + 2] = (byte) (bits >> 40);
            bytes[i * 8 + 3] = (byte) (bits >> 32);
            bytes[i * 8 + 4] = (byte) (bits >> 24);
            bytes[i * 8 + 5] = (byte) (bits >> 16);
            bytes[i * 8 + 6] = (byte) (bits >> 8);
            bytes[i * 8 + 7] = (byte) bits;
        }
        
        return Base64.getEncoder().encodeToString(bytes);
    }
}
