package com.mdf4.model;

/**
 * 消息类型枚举
 */
public enum MessageType {
    WRITE("WRITE"),
    READ("READ"),
    READ_INFO("READ_INFO"),
    APPEND("APPEND"),
    CLOSE_FILE("CLOSE_FILE"),
    PING("PING"),
    SHUTDOWN("SHUTDOWN");
    
    private final String value;
    
    MessageType(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
    
    public static MessageType fromValue(String value) {
        for (MessageType type : values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown message type: " + value);
    }
}
