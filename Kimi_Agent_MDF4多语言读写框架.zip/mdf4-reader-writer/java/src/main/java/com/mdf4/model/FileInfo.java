package com.mdf4.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * MDF4文件信息类
 * 包含MDF4文件的元数据信息
 */
public class FileInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String version;
    private String program;
    private String comment;
    private String creationTime;
    private List<ChannelGroup> channelGroups;
    
    public FileInfo() {
        this.channelGroups = new ArrayList<>();
    }
    
    /**
     * 获取所有信号数量
     */
    public int getTotalSignalCount() {
        return channelGroups.stream()
                .mapToInt(ChannelGroup::getSignalCount)
                .sum();
    }
    
    /**
     * 获取所有信号名称
     */
    public List<String> getAllSignalNames() {
        List<String> names = new ArrayList<>();
        for (ChannelGroup group : channelGroups) {
            for (SignalInfo signal : group.getSignals()) {
                names.add(signal.getName());
            }
        }
        return names;
    }
    
    /**
     * 根据名称查找信号
     */
    public SignalInfo findSignal(String name) {
        for (ChannelGroup group : channelGroups) {
            for (SignalInfo signal : group.getSignals()) {
                if (signal.getName().equals(name)) {
                    return signal;
                }
            }
        }
        return null;
    }
    
    // Getters and Setters
    public String getVersion() {
        return version;
    }
    
    public void setVersion(String version) {
        this.version = version;
    }
    
    public String getProgram() {
        return program;
    }
    
    public void setProgram(String program) {
        this.program = program;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public String getCreationTime() {
        return creationTime;
    }
    
    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }
    
    public List<ChannelGroup> getChannelGroups() {
        return channelGroups;
    }
    
    public void setChannelGroups(List<ChannelGroup> channelGroups) {
        this.channelGroups = channelGroups;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FileInfo fileInfo = (FileInfo) o;
        return Objects.equals(version, fileInfo.version) &&
                Objects.equals(program, fileInfo.program);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(version, program);
    }
    
    @Override
    public String toString() {
        return "FileInfo{" +
                "version='" + version + '\'' +
                ", program='" + program + '\'' +
                ", comment='" + comment + '\'' +
                ", creationTime='" + creationTime + '\'' +
                ", channelGroupCount=" + channelGroups.size() +
                ", totalSignalCount=" + getTotalSignalCount() +
                '}';
    }
}
