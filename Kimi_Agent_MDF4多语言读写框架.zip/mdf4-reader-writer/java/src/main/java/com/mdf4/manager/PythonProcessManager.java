package com.mdf4.manager;

import com.mdf4.exception.ConnectionException;

import java.io.*nimport java.net.Socket;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Python进程管理器
 * 负责启动、管理和关闭Python服务端进程
 */
public class PythonProcessManager {
    
    private static final Logger LOGGER = Logger.getLogger(PythonProcessManager.class.getName());
    
    // 默认Python可执行文件
    private static final String DEFAULT_PYTHON = "python3";
    // 启动超时（秒）
    private static final int STARTUP_TIMEOUT = 30;
    // 连接重试次数
    private static final int CONNECT_RETRIES = 5;
    // 连接重试间隔（毫秒）
    private static final int CONNECT_RETRY_INTERVAL = 500;
    
    private final String pythonExecutable;
    private final String scriptPath;
    private final String host;
    private Process process;
    private int port;
    private final AtomicBoolean running;
    private Thread outputReaderThread;
    private Thread errorReaderThread;
    
    public PythonProcessManager(String scriptPath) {
        this(DEFAULT_PYTHON, scriptPath, "127.0.0.1");
    }
    
    public PythonProcessManager(String pythonExecutable, String scriptPath, String host) {
        this.pythonExecutable = pythonExecutable;
        this.scriptPath = scriptPath;
        this.host = host;
        this.running = new AtomicBoolean(false);
    }
    
    /**
     * 启动Python服务
     * 
     * @return 服务端口号
     * @throws ConnectionException 启动失败
     */
    public int start() throws ConnectionException {
        if (running.get()) {
            LOGGER.warning("Python service already running on port " + port);
            return port;
        }
        
        try {
            // 构建启动命令
            ProcessBuilder pb = new ProcessBuilder(
                    pythonExecutable,
                    scriptPath,
                    "--host", host,
                    "--port", "0"  // 0表示自动分配端口
            );
            
            // 设置工作目录
            File scriptDir = new File(scriptPath).getParentFile();
            if (scriptDir != null) {
                pb.directory(scriptDir);
            }
            
            // 继承环境变量
            pb.inheritIO();
            pb.redirectErrorStream(false);
            
            LOGGER.info("Starting Python service: " + String.join(" ", pb.command()));
            
            // 启动进程
            process = pb.start();
            running.set(true);
            
            // 读取输出获取端口号
            port = readPortFromOutput();
            
            if (port <= 0) {
                stop();
                throw new ConnectionException("Failed to get port from Python service");
            }
            
            LOGGER.info("Python service started on port " + port);
            
            // 启动输出读取线程
            startOutputReaders();
            
            // 等待服务就绪
            waitForServiceReady();
            
            return port;
            
        } catch (IOException e) {
            running.set(false);
            throw new ConnectionException("Failed to start Python service", e);
        }
    }
    
    /**
     * 停止Python服务
     */
    public void stop() {
        if (!running.get()) {
            return;
        }
        
        LOGGER.info("Stopping Python service...");
        running.set(false);
        
        // 尝试优雅关闭
        if (process != null) {
            // 发送关闭信号
            process.descendants().forEach(ProcessHandle::destroy);
            process.destroy();
            
            // 等待进程结束
            try {
                if (!process.waitFor(5, TimeUnit.SECONDS)) {
                    LOGGER.warning("Python service did not terminate gracefully, forcing...");
                    process.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            }
        }
        
        // 停止读取线程
        if (outputReaderThread != null) {
            outputReaderThread.interrupt();
        }
        if (errorReaderThread != null) {
            errorReaderThread.interrupt();
        }
        
        process = null;
        LOGGER.info("Python service stopped");
    }
    
    /**
     * 检查服务是否运行
     */
    public boolean isRunning() {
        return running.get() && process != null && process.isAlive();
    }
    
    /**
     * 获取端口号
     */
    public int getPort() {
        return port;
    }
    
    /**
     * 获取主机地址
     */
    public String getHost() {
        return host;
    }
    
    /**
     * 从Python输出中读取端口号
     */
    private int readPortFromOutput() throws ConnectionException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            
            String line;
            long startTime = System.currentTimeMillis();
            long timeout = STARTUP_TIMEOUT * 1000;
            
            while ((line = reader.readLine()) != null) {
                LOGGER.fine("Python output: " + line);
                
                // 检查是否包含端口号
                if (line.startsWith("PORT:")) {
                    try {
                        return Integer.parseInt(line.substring(5).trim());
                    } catch (NumberFormatException e) {
                        throw new ConnectionException("Invalid port format: " + line);
                    }
                }
                
                // 检查超时
                if (System.currentTimeMillis() - startTime > timeout) {
                    throw new ConnectionException("Timeout waiting for Python service to start");
                }
            }
            
            throw new ConnectionException("Python service terminated unexpectedly");
            
        } catch (IOException e) {
            throw new ConnectionException("Failed to read Python output", e);
        }
    }
    
    /**
     * 启动输出读取线程
     */
    private void startOutputReaders() {
        // 标准输出读取线程
        outputReaderThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while (running.get() && (line = reader.readLine()) != null) {
                    if (!line.startsWith("PORT:")) {
                        LOGGER.fine("[Python] " + line);
                    }
                }
            } catch (IOException e) {
                if (running.get()) {
                    LOGGER.log(Level.WARNING, "Error reading Python output", e);
                }
            }
        });
        outputReaderThread.setDaemon(true);
        outputReaderThread.start();
        
        // 错误输出读取线程
        errorReaderThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()))) {
                String line;
                while (running.get() && (line = reader.readLine()) != null) {
                    LOGGER.warning("[Python Error] " + line);
                }
            } catch (IOException e) {
                if (running.get()) {
                    LOGGER.log(Level.WARNING, "Error reading Python error output", e);
                }
            }
        });
        errorReaderThread.setDaemon(true);
        errorReaderThread.start();
    }
    
    /**
     * 等待服务就绪
     */
    private void waitForServiceReady() throws ConnectionException {
        for (int i = 0; i < CONNECT_RETRIES; i++) {
            try {
                Thread.sleep(CONNECT_RETRY_INTERVAL);
                
                // 尝试连接
                try (Socket testSocket = new Socket(host, port)) {
                    LOGGER.info("Python service is ready");
                    return;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new ConnectionException("Interrupted while waiting for service", e);
            } catch (IOException e) {
                // 连接失败，继续重试
                LOGGER.fine("Connection attempt " + (i + 1) + " failed, retrying...");
            }
        }
        
        stop();
        throw new ConnectionException("Python service failed to become ready after " + 
                CONNECT_RETRIES + " attempts");
    }
}
