package com.mdf4;

import com.mdf4.model.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MDF4读写测试类
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MDF4ReaderWriterTest {
    
    @TempDir
    static Path tempDir;
    
    private static MDF4Factory factory;
    private static String testFilePath;
    
    @BeforeAll
    static void setUp() throws Exception {
        // 假设Python脚本在相对路径中
        String pythonScriptPath = "../python/main.py";
        factory = MDF4Factory.builder()
                .pythonScriptPath(pythonScriptPath)
                .build();
        testFilePath = tempDir.resolve("test.mf4").toString();
    }
    
    @AfterAll
    static void tearDown() {
        if (factory != null) {
            factory.close();
        }
    }
    
    @Test
    @Order(1)
    @DisplayName("Test write signals to MDF4 file")
    void testWrite() throws Exception {
        var writer = factory.getWriter();
        
        // 创建测试信号
        double[] timestamps = new double[100];
        double[] values = new double[100];
        for (int i = 0; i < 100; i++) {
            timestamps[i] = i * 0.01;
            values[i] = Math.sin(timestamps[i]);
        }
        
        SignalData signal = SignalData.create("TestSignal", "V", timestamps, values);
        
        // 写入文件
        assertDoesNotThrow(() -> {
            writer.write(testFilePath, Arrays.asList(signal), CompressionType.ZIP, true);
        });
    }
    
    @Test
    @Order(2)
    @DisplayName("Test read file info")
    void testReadInfo() throws Exception {
        var reader = factory.getReader();
        
        FileInfo fileInfo = reader.readInfo(testFilePath);
        
        assertNotNull(fileInfo);
        assertFalse(fileInfo.getAllSignalNames().isEmpty());
        assertTrue(fileInfo.getAllSignalNames().contains("TestSignal"));
    }
    
    @Test
    @Order(3)
    @DisplayName("Test read all signals")
    void testReadAllSignals() throws Exception {
        var reader = factory.getReader();
        
        List<SignalData> signals = reader.read(testFilePath);
        
        assertNotNull(signals);
        assertFalse(signals.isEmpty());
        
        SignalData signal = signals.get(0);
        assertEquals("TestSignal", signal.getInfo().getName());
        assertEquals(100, signal.getLength());
    }
    
    @Test
    @Order(4)
    @DisplayName("Test read specific signal")
    void testReadSpecificSignal() throws Exception {
        var reader = factory.getReader();
        
        SignalData signal = reader.readSignal(testFilePath, "TestSignal");
        
        assertNotNull(signal);
        assertEquals("TestSignal", signal.getInfo().getName());
        assertEquals("V", signal.getInfo().getUnit());
    }
    
    @Test
    @Order(5)
    @DisplayName("Test read with time range")
    void testReadWithTimeRange() throws Exception {
        var reader = factory.getReader();
        
        List<SignalData> signals = reader.read(testFilePath, 0.0, 0.5);
        
        assertNotNull(signals);
        assertFalse(signals.isEmpty());
    }
    
    @Test
    @Order(6)
    @DisplayName("Test append signal")
    void testAppend() throws Exception {
        var writer = factory.getWriter();
        
        double[] timestamps = new double[50];
        double[] values = new double[50];
        for (int i = 0; i < 50; i++) {
            timestamps[i] = i * 0.01;
            values[i] = Math.cos(timestamps[i]);
        }
        
        SignalData signal = SignalData.create("CosineSignal", "V", timestamps, values);
        
        assertDoesNotThrow(() -> {
            writer.append(testFilePath, Arrays.asList(signal));
        });
    }
    
    @Test
    @Order(7)
    @DisplayName("Test connection status")
    void testConnectionStatus() {
        assertTrue(factory.isConnected());
    }
}
