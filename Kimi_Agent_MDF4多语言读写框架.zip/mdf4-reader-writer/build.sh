#!/bin/bash

# MDF4 Reader Writer 构建脚本

set -e

echo "================================"
echo "MDF4 Reader Writer Build Script"
echo "================================"

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 检查Python环境
echo ""
echo "Checking Python environment..."
if ! command -v python3 &> /dev/null; then
    echo "Error: python3 is not installed"
    exit 1
fi

# 安装Python依赖
echo ""
echo "Installing Python dependencies..."
cd python
pip3 install -r requirements.txt --quiet
cd ..

# 检查Java环境
echo ""
echo "Checking Java environment..."
if ! command -v java &> /dev/null; then
    echo "Error: java is not installed"
    exit 1
fi

if ! command -v mvn &> /dev/null; then
    echo "Error: maven is not installed"
    exit 1
fi

# 构建Java项目
echo ""
echo "Building Java project..."
cd java
mvn clean package -DskipTests -q

# 检查构建结果
if [ -f "target/mdf4-reader-writer-1.0.0.jar" ]; then
    echo ""
    echo "================================"
    echo "Build successful!"
    echo "================================"
    echo ""
    echo "JAR file: target/mdf4-reader-writer-1.0.0.jar"
    echo ""
    echo "Usage:"
    echo "  java -jar target/mdf4-reader-writer-1.0.0.jar <python-script-path>"
    echo ""
    echo "Example:"
    echo "  java -jar target/mdf4-reader-writer-1.0.0.jar ../python/main.py"
else
    echo "Error: Build failed"
    exit 1
fi
