# MDF4 Reader Writer

一个支持多线程的MDF4文件读写项目，采用Java+Python混合架构实现。

## 项目架构

```
mdf4-reader-writer/
├── java/                    # Java端代码
│   ├── src/
│   │   ├── main/java/com/mdf4/
│   │   │   ├── model/       # 数据模型
│   │   │   ├── client/      # Socket客户端
│   │   │   ├── manager/     # Python进程管理
│   │   │   ├── writer/      # Writer接口
│   │   │   ├── reader/      # Reader接口
│   │   │   ├── exception/   # 异常类
│   │   │   └── utils/       # 工具类
│   │   └── test/            # 测试代码
│   └── pom.xml              # Maven配置
├── python/                  # Python端代码
│   ├── mdf4_service/
│   │   ├── server.py        # Socket服务器
│   │   ├── handler.py       # 请求处理器
│   │   ├── mdf4_reader.py   # MDF4读取实现
│   │   ├── mdf4_writer.py   # MDF4写入实现
│   │   ├── models.py        # 数据模型
│   │   └── utils.py         # 工具函数
│   ├── requirements.txt     # Python依赖
│   └── main.py              # 入口点
└── README.md                # 本文档
```

## 特性

- **多线程支持**: 读写操作支持多线程并发处理
- **大文件支持**: 针对GB级大文件优化，支持分块读写
- **混合架构**: Java端负责业务逻辑，Python端负责MDF4文件操作
- **Socket通信**: Java通过Socket调用Python服务
- **自定义数据类**: 支持复杂的信号数据类型传输
- **生命周期管理**: Java端控制Python进程的启动和关闭

## 快速开始

### 环境要求

- Java 11+ (或 Java 8+)
- Python 3.8+
- Maven 3.6+

### Python端安装

```bash
cd python
pip install -r requirements.txt
```

### Java端构建

```bash
cd java
mvn clean package
```

### 使用示例

```java
import com.mdf4.*;
import com.mdf4.model.*;

// 方式1: 自动启动Python服务
try (MDF4Factory factory = MDF4Factory.builder()
        .pythonScriptPath("/path/to/python/main.py")
        .build()) {
    
    // 获取写入器
    var writer = factory.getWriter();
    
    // 创建信号数据
    double[] timestamps = new double[1000];
    double[] values = new double[1000];
    for (int i = 0; i < 1000; i++) {
        timestamps[i] = i * 0.01;
        values[i] = Math.sin(timestamps[i]);
    }
    SignalData signal = SignalData.create("SineWave", "V", timestamps, values);
    
    // 写入文件
    writer.write("output.mf4", Arrays.asList(signal), CompressionType.ZIP, true);
    
    // 获取读取器
    var reader = factory.getReader();
    
    // 读取文件信息
    FileInfo info = reader.readInfo("output.mf4");
    System.out.println("Version: " + info.getVersion());
    System.out.println("Signals: " + info.getTotalSignalCount());
    
    // 读取信号数据
    List<SignalData> signals = reader.read("output.mf4");
    for (SignalData sig : signals) {
        System.out.println(sig.getInfo().getName() + ": " + sig.getLength() + " samples");
    }
}

// 方式2: 连接到现有服务
try (MDF4Factory factory = MDF4Factory.builder()
        .host("127.0.0.1")
        .port(12345)
        .build()) {
    // ... 使用 factory
}
```

## API文档

### MDF4Factory

工厂类，用于创建和管理MDF4Reader和MDF4Writer实例。

| 方法 | 说明 |
|------|------|
| `getReader()` | 获取MDF4读取器 |
| `getWriter()` | 获取MDF4写入器 |
| `isConnected()` | 检查连接状态 |
| `close()` | 关闭工厂，释放资源 |

### MDF4Writer

MDF4文件写入器。

| 方法 | 说明 |
|------|------|
| `write(filePath, signals)` | 写入信号数据 |
| `write(filePath, signals, compression)` | 写入并指定压缩类型 |
| `write(filePath, signals, compression, overwrite)` | 写入并指定是否覆盖 |
| `append(filePath, signals)` | 追加信号到现有文件 |
| `closeFile(filePath)` | 关闭指定文件 |
| `closeAllFiles()` | 关闭所有文件 |

### MDF4Reader

MDF4文件读取器。

| 方法 | 说明 |
|------|------|
| `read(filePath)` | 读取所有信号 |
| `read(filePath, signalNames)` | 读取指定信号 |
| `read(filePath, startTime, endTime)` | 读取指定时间范围 |
| `readSignal(filePath, signalName)` | 读取单个信号 |
| `readInfo(filePath)` | 读取文件信息 |
| `getSignalNames(filePath)` | 获取所有信号名称 |
| `closeFile(filePath)` | 关闭指定文件 |
| `closeAllFiles()` | 关闭所有文件 |

### 数据模型

#### SignalData

```java
public class SignalData {
    private SignalInfo info;      // 信号信息
    private double[] timestamps;  // 时间戳数组
    private double[] values;      // 值数组
}
```

#### SignalInfo

```java
public class SignalInfo {
    private String name;          // 信号名称
    private String unit;          // 单位
    private String comment;       // 注释
    private DataType dataType;    // 数据类型
    private Double minValue;      // 最小值
    private Double maxValue;      // 最大值
}
```

#### FileInfo

```java
public class FileInfo {
    private String version;                   // MDF版本
    private String program;                   // 创建程序
    private String comment;                   // 文件注释
    private String creationTime;              // 创建时间
    private List<ChannelGroup> channelGroups; // 通道组列表
}
```

## 多线程支持

项目内置多线程支持，可通过`ThreadPoolManager`进行并发操作：

```java
ThreadPoolManager threadPool = new ThreadPoolManager(4);

// 并发读取多个文件
List<Callable<List<SignalData>>> tasks = Arrays.asList(
    () -> reader.read("file1.mf4"),
    () -> reader.read("file2.mf4"),
    () -> reader.read("file3.mf4")
);

boolean success = threadPool.executeBatch(tasks, 30000);
```

## 大文件优化

针对GB级大文件，项目自动采用以下优化策略：

1. **分块读写**: 数据按块处理，避免内存溢出
2. **流式处理**: 支持流式读取大文件
3. **内存映射**: 利用操作系统内存映射优化IO
4. **压缩优化**: 支持多种压缩算法

## 通信协议

Java与Python之间使用Socket通信，消息格式如下：

### 请求消息

```json
{
    "type": "WRITE|READ|READ_INFO|APPEND|CLOSE_FILE|PING|SHUTDOWN",
    "payload": { ... },
    "requestId": "uuid"
}
```

### 响应消息

```json
{
    "success": true|false,
    "message": "...",
    "data": { ... },
    "errorCode": 0
}
```

## 错误码

| 错误码 | 说明 |
|--------|------|
| 1001 | 文件已存在 |
| 1002 | 写入错误 |
| 1003 | 文件不存在 |
| 1004 | 追加错误 |
| 1005 | 关闭文件错误 |
| 2001 | 文件不存在 |
| 2002 | 读取错误 |
| 2003 | 文件不存在 |
| 2004 | 读取信息错误 |
| 2005 | 关闭文件错误 |
| 3001 | 未知消息类型 |
| 3002 | 内部错误 |
| 4001 | 连接错误 |
| 5001 | 写入异常 |
| 6001 | 读取异常 |

## 许可证

MIT License
