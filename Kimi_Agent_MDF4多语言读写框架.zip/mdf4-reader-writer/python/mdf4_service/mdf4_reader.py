"""
MDF4读取器实现
支持大文件分块读取和多线程
"""

import os
import threading
import logging
from typing import Dict, List, Optional, Iterator, Tuple
import numpy as np
from asammdf import MDF

from .models import (
    SignalData, SignalInfo, ReadRequest, FileInfo, 
    ChannelGroup, Response, DataType
)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MDF4Reader:
    """MDF4读取器 - 支持大文件和多线程"""
    
    # 大文件阈值: 100MB
    LARGE_FILE_THRESHOLD = 100 * 1024 * 1024
    # 分块读取大小: 每次读取10万条记录
    CHUNK_SIZE = 100000
    
    def __init__(self):
        self._lock = threading.RLock()
        self._open_files: Dict[str, MDF] = {}
        self._file_locks: Dict[str, threading.RLock] = {}
        self._file_info_cache: Dict[str, FileInfo] = {}
    
    def read(self, request: ReadRequest) -> Response:
        """
        读取MDF4文件中的信号数据
        
        Args:
            request: 读取请求
            
        Returns:
            Response: 包含SignalData列表
        """
        try:
            file_path = request.file_path
            
            if not os.path.exists(file_path):
                return Response(
                    success=False,
                    message=f"File not found: {file_path}",
                    error_code=2001
                )
            
            # 获取文件大小
            file_size = os.path.getsize(file_path)
            
            with self._lock:
                # 获取或创建文件锁
                if file_path not in self._file_locks:
                    self._file_locks[file_path] = threading.RLock()
                
                with self._file_locks[file_path]:
                    # 打开或复用MDF文件
                    if file_path not in self._open_files:
                        self._open_files[file_path] = MDF(file_path)
                    mdf = self._open_files[file_path]
                    
                    # 确定要读取的信号
                    signal_names = request.signal_names
                    if signal_names is None:
                        # 读取所有信号
                        signal_names = [ch.name for ch in mdf.channels_db]
                    
                    signals: List[SignalData] = []
                    
                    # 根据文件大小选择读取策略
                    if file_size > self.LARGE_FILE_THRESHOLD:
                        signals = self._read_large_file(
                            mdf, signal_names, request.start_time, request.end_time
                        )
                    else:
                        signals = self._read_normal_file(
                            mdf, signal_names, request.start_time, request.end_time
                        )
                    
                    logger.info(f"Successfully read {len(signals)} signals from {file_path}")
                    
                    return Response(
                        success=True,
                        message=f"Read {len(signals)} signals",
                        data=signals
                    )
                    
        except Exception as e:
            logger.error(f"Error reading MDF4 file: {str(e)}", exc_info=True)
            return Response(
                success=False,
                message=f"Error reading file: {str(e)}",
                error_code=2002
            )
    
    def read_info(self, file_path: str) -> Response:
        """
        读取MDF4文件信息（不读取实际数据）
        
        Args:
            file_path: 文件路径
            
        Returns:
            Response: 包含FileInfo
        """
        try:
            if not os.path.exists(file_path):
                return Response(
                    success=False,
                    message=f"File not found: {file_path}",
                    error_code=2003
                )
            
            # 检查缓存
            if file_path in self._file_info_cache:
                return Response(
                    success=True,
                    message="File info from cache",
                    data=self._file_info_cache[file_path]
                )
            
            with self._lock:
                if file_path not in self._file_locks:
                    self._file_locks[file_path] = threading.RLock()
                
                with self._file_locks[file_path]:
                    mdf = MDF(file_path)
                    
                    # 提取文件信息
                    file_info = FileInfo(
                        version=mdf.version,
                        program=getattr(mdf, 'program', ''),
                        comment=getattr(mdf, 'comment', ''),
                        creation_time=str(getattr(mdf, 'creation_time', ''))
                    )
                    
                    # 提取通道组信息
                    channel_groups = []
                    for i, group in enumerate(mdf.groups):
                        cg_info = ChannelGroup(
                            name=f"Group_{i}",
                            comment=getattr(group.channel_group, 'comment', ''),
                            signals=[]
                        )
                        
                        # 提取通道信息
                        for j, channel in enumerate(group.channels):
                            sig_info = SignalInfo(
                                name=getattr(channel, 'name', f'Channel_{j}'),
                                unit=getattr(channel, 'unit', ''),
                                comment=getattr(channel, 'comment', ''),
                                data_type=self._infer_data_type(channel)
                            )
                            cg_info.signals.append(sig_info)
                        
                        channel_groups.append(cg_info)
                    
                    file_info.channel_groups = channel_groups
                    
                    # 缓存文件信息
                    self._file_info_cache[file_path] = file_info
                    
                    mdf.close()
                    
                    return Response(
                        success=True,
                        message="File info retrieved",
                        data=file_info
                    )
                    
        except Exception as e:
            logger.error(f"Error reading file info: {str(e)}", exc_info=True)
            return Response(
                success=False,
                message=f"Error reading file info: {str(e)}",
                error_code=2004
            )
    
    def read_chunked(self, file_path: str, signal_name: str, 
                     chunk_size: int = CHUNK_SIZE) -> Iterator[SignalData]:
        """
        分块读取信号数据 - 适合大文件流式处理
        
        Args:
            file_path: 文件路径
            signal_name: 信号名称
            chunk_size: 块大小
            
        Yields:
            SignalData: 信号数据块
        """
        try:
            with self._lock:
                if file_path not in self._file_locks:
                    self._file_locks[file_path] = threading.RLock()
                
                with self._file_locks[file_path]:
                    if file_path not in self._open_files:
                        self._open_files[file_path] = MDF(file_path)
                    mdf = self._open_files[file_path]
                    
                    # 获取信号
                    signal = mdf.get(signal_name)
                    total_length = len(signal.timestamps)
                    
                    # 分块yield
                    for start_idx in range(0, total_length, chunk_size):
                        end_idx = min(start_idx + chunk_size, total_length)
                        
                        chunk = SignalData(
                            info=SignalInfo(
                                name=signal_name,
                                unit=signal.unit,
                                comment=signal.comment
                            ),
                            timestamps=signal.timestamps[start_idx:end_idx],
                            values=signal.samples[start_idx:end_idx]
                        )
                        yield chunk
                        
        except Exception as e:
            logger.error(f"Error reading chunked data: {str(e)}", exc_info=True)
            raise
    
    def close_file(self, file_path: str) -> Response:
        """
        关闭打开的文件
        
        Args:
            file_path: 文件路径
            
        Returns:
            Response: 关闭结果
        """
        with self._lock:
            if file_path in self._open_files:
                try:
                    self._open_files[file_path].close()
                    del self._open_files[file_path]
                    if file_path in self._file_locks:
                        del self._file_locks[file_path]
                    if file_path in self._file_info_cache:
                        del self._file_info_cache[file_path]
                    return Response(success=True, message=f"Closed {file_path}")
                except Exception as e:
                    return Response(
                        success=False,
                        message=f"Error closing file: {str(e)}",
                        error_code=2005
                    )
            return Response(success=True, message="File not open")
    
    def _read_normal_file(self, mdf: MDF, signal_names: List[str],
                         start_time: Optional[float], 
                         end_time: Optional[float]) -> List[SignalData]:
        """
        普通文件读取 - 适合小文件
        
        Args:
            mdf: MDF对象
            signal_names: 信号名称列表
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            List[SignalData]: 信号数据列表
        """
        signals = []
        
        for name in signal_names:
            try:
                # 获取信号数据
                signal = mdf.get(name)
                
                # 时间范围过滤
                timestamps = signal.timestamps
                samples = signal.samples
                
                if start_time is not None or end_time is not None:
                    mask = np.ones(len(timestamps), dtype=bool)
                    if start_time is not None:
                        mask &= timestamps >= start_time
                    if end_time is not None:
                        mask &= timestamps <= end_time
                    
                    timestamps = timestamps[mask]
                    samples = samples[mask]
                
                signal_data = SignalData(
                    info=SignalInfo(
                        name=name,
                        unit=signal.unit,
                        comment=signal.comment
                    ),
                    timestamps=timestamps,
                    values=samples
                )
                signals.append(signal_data)
                
            except Exception as e:
                logger.warning(f"Failed to read signal '{name}': {e}")
                continue
        
        return signals
    
    def _read_large_file(self, mdf: MDF, signal_names: List[str],
                        start_time: Optional[float], 
                        end_time: Optional[float]) -> List[SignalData]:
        """
        大文件读取 - 使用分块策略减少内存占用
        
        Args:
            mdf: MDF对象
            signal_names: 信号名称列表
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            List[SignalData]: 信号数据列表
        """
        signals = []
        
        for name in signal_names:
            try:
                # 先获取信号信息
                signal = mdf.get(name)
                total_length = len(signal.timestamps)
                
                if total_length <= self.CHUNK_SIZE:
                    # 小信号直接读取
                    signal_data = SignalData(
                        info=SignalInfo(
                            name=name,
                            unit=signal.unit,
                            comment=signal.comment
                        ),
                        timestamps=signal.timestamps,
                        values=signal.samples
                    )
                    signals.append(signal_data)
                else:
                    # 大信号分块读取并合并
                    logger.info(f"Reading large signal '{name}' in chunks "
                              f"(total: {total_length})")
                    
                    all_timestamps = []
                    all_values = []
                    
                    # 使用裁剪功能分块读取
                    for start_idx in range(0, total_length, self.CHUNK_SIZE):
                        end_idx = min(start_idx + self.CHUNK_SIZE, total_length)
                        
                        # 获取时间范围
                        chunk_start_time = signal.timestamps[start_idx]
                        chunk_end_time = signal.timestamps[end_idx - 1]
                        
                        # 检查时间范围
                        if start_time is not None and chunk_end_time < start_time:
                            continue
                        if end_time is not None and chunk_start_time > end_time:
                            break
                        
                        # 读取块
                        chunk_signal = mdf.get(name)
                        chunk_timestamps = chunk_signal.timestamps[start_idx:end_idx]
                        chunk_values = chunk_signal.samples[start_idx:end_idx]
                        
                        # 时间过滤
                        if start_time is not None or end_time is not None:
                            mask = np.ones(len(chunk_timestamps), dtype=bool)
                            if start_time is not None:
                                mask &= chunk_timestamps >= start_time
                            if end_time is not None:
                                mask &= chunk_timestamps <= end_time
                            
                            chunk_timestamps = chunk_timestamps[mask]
                            chunk_values = chunk_values[mask]
                        
                        all_timestamps.append(chunk_timestamps)
                        all_values.append(chunk_values)
                    
                    # 合并所有块
                    if all_timestamps:
                        merged_timestamps = np.concatenate(all_timestamps)
                        merged_values = np.concatenate(all_values)
                        
                        signal_data = SignalData(
                            info=SignalInfo(
                                name=name,
                                unit=signal.unit,
                                comment=signal.comment
                            ),
                            timestamps=merged_timestamps,
                            values=merged_values
                        )
                        signals.append(signal_data)
                
            except Exception as e:
                logger.warning(f"Failed to read signal '{name}': {e}")
                continue
        
        return signals
    
    def _infer_data_type(self, channel) -> DataType:
        """
        推断通道数据类型
        
        Args:
            channel: 通道对象
            
        Returns:
            DataType: 数据类型枚举
        """
        try:
            dtype = getattr(channel, 'data_type', None)
            if dtype is None:
                return DataType.FLOAT64
            
            dtype_map = {
                0: DataType.INT8,
                1: DataType.UINT8,
                2: DataType.INT16,
                3: DataType.UINT16,
                4: DataType.INT32,
                5: DataType.UINT32,
                6: DataType.INT64,
                7: DataType.UINT64,
                8: DataType.FLOAT32,
                9: DataType.FLOAT64,
            }
            
            return dtype_map.get(dtype, DataType.FLOAT64)
        except:
            return DataType.FLOAT64
    
    def close_all(self):
        """关闭所有打开的文件"""
        with self._lock:
            for file_path, mdf in list(self._open_files.items()):
                try:
                    mdf.close()
                    logger.info(f"Closed {file_path}")
                except Exception as e:
                    logger.error(f"Error closing {file_path}: {e}")
            self._open_files.clear()
            self._file_locks.clear()
            self._file_info_cache.clear()
