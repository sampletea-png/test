"""
请求处理器
处理来自Java端的各种请求
"""

import json
import logging
import traceback
from typing import Dict, Any

from .models import Message, MessageType, WriteRequest, ReadRequest, Response
from .mdf4_writer import MDF4Writer
from .mdf4_reader import MDF4Reader

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RequestHandler:
    """请求处理器 - 处理所有MDF4相关请求"""
    
    def __init__(self):
        self.writer = MDF4Writer()
        self.reader = MDF4Reader()
    
    def handle(self, message: Message) -> Response:
        """
        处理消息
        
        Args:
            message: 请求消息
            
        Returns:
            Response: 响应
        """
        try:
            logger.info(f"Handling message type: {message.msg_type.value}")
            
            handlers = {
                MessageType.WRITE: self._handle_write,
                MessageType.READ: self._handle_read,
                MessageType.READ_INFO: self._handle_read_info,
                MessageType.APPEND: self._handle_append,
                MessageType.CLOSE_FILE: self._handle_close_file,
                MessageType.PING: self._handle_ping,
                MessageType.SHUTDOWN: self._handle_shutdown,
            }
            
            handler = handlers.get(message.msg_type)
            if handler:
                return handler(message.payload)
            else:
                return Response(
                    success=False,
                    message=f"Unknown message type: {message.msg_type.value}",
                    error_code=3001
                )
                
        except Exception as e:
            logger.error(f"Error handling message: {str(e)}", exc_info=True)
            return Response(
                success=False,
                message=f"Internal error: {str(e)}",
                error_code=3002
            )
    
    def _handle_write(self, payload: Dict[str, Any]) -> Response:
        """处理写入请求"""
        try:
            request = WriteRequest.from_dict(payload)
            return self.writer.write(request)
        except Exception as e:
            logger.error(f"Error in write handler: {str(e)}")
            return Response(
                success=False,
                message=f"Write error: {str(e)}",
                error_code=3101
            )
    
    def _handle_read(self, payload: Dict[str, Any]) -> Response:
        """处理读取请求"""
        try:
            request = ReadRequest.from_dict(payload)
            return self.reader.read(request)
        except Exception as e:
            logger.error(f"Error in read handler: {str(e)}")
            return Response(
                success=False,
                message=f"Read error: {str(e)}",
                error_code=3201
            )
    
    def _handle_read_info(self, payload: Dict[str, Any]) -> Response:
        """处理读取文件信息请求"""
        try:
            file_path = payload.get("filePath")
            if not file_path:
                return Response(
                    success=False,
                    message="filePath is required",
                    error_code=3301
                )
            return self.reader.read_info(file_path)
        except Exception as e:
            logger.error(f"Error in read_info handler: {str(e)}")
            return Response(
                success=False,
                message=f"Read info error: {str(e)}",
                error_code=3302
            )
    
    def _handle_append(self, payload: Dict[str, Any]) -> Response:
        """处理追加请求"""
        try:
            file_path = payload.get("filePath")
            signals_data = payload.get("signals", [])
            
            if not file_path:
                return Response(
                    success=False,
                    message="filePath is required",
                    error_code=3401
                )
            
            from .models import SignalData
            signals = [SignalData.from_dict(s) for s in signals_data]
            
            return self.writer.append(file_path, signals)
        except Exception as e:
            logger.error(f"Error in append handler: {str(e)}")
            return Response(
                success=False,
                message=f"Append error: {str(e)}",
                error_code=3402
            )
    
    def _handle_close_file(self, payload: Dict[str, Any]) -> Response:
        """处理关闭文件请求"""
        try:
            file_path = payload.get("filePath")
            if not file_path:
                # 关闭所有文件
                self.writer.close_all()
                self.reader.close_all()
                return Response(success=True, message="All files closed")
            
            # 关闭指定文件
            writer_response = self.writer.close_file(file_path)
            reader_response = self.reader.close_file(file_path)
            
            if writer_response.success or reader_response.success:
                return Response(success=True, message=f"Closed {file_path}")
            else:
                return Response(
                    success=False,
                    message="File not found or already closed",
                    error_code=3501
                )
        except Exception as e:
            logger.error(f"Error in close_file handler: {str(e)}")
            return Response(
                success=False,
                message=f"Close file error: {str(e)}",
                error_code=3502
            )
    
    def _handle_ping(self, payload: Dict[str, Any]) -> Response:
        """处理心跳请求"""
        return Response(
            success=True,
            message="PONG",
            data={"status": "running"}
        )
    
    def _handle_shutdown(self, payload: Dict[str, Any]) -> Response:
        """处理关闭服务请求"""
        logger.info("Shutdown requested")
        
        # 关闭所有资源
        self.writer.close_all()
        self.reader.close_all()
        
        return Response(
            success=True,
            message="Server shutting down"
        )
    
    def cleanup(self):
        """清理资源"""
        logger.info("Cleaning up handler resources")
        self.writer.close_all()
        self.reader.close_all()
