"""
数据模型定义
定义与Java端通信的数据结构
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union
from enum import Enum
import json
import numpy as np


class DataType(Enum):
    """信号数据类型"""
    INT8 = "INT8"
    UINT8 = "UINT8"
    INT16 = "INT16"
    UINT16 = "UINT16"
    INT32 = "INT32"
    UINT32 = "UINT32"
    INT64 = "INT64"
    UINT64 = "UINT64"
    FLOAT32 = "FLOAT32"
    FLOAT64 = "FLOAT64"


class CompressionType(Enum):
    """压缩类型"""
    NONE = "NONE"
    ZIP = "ZIP"
    TRANSPOSITION = "TRANSPOSITION"


@dataclass
class SignalInfo:
    """信号信息"""
    name: str
    unit: str = ""
    comment: str = ""
    data_type: DataType = DataType.FLOAT64
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "unit": self.unit,
            "comment": self.comment,
            "dataType": self.data_type.value,
            "minValue": self.min_value,
            "maxValue": self.max_value
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SignalInfo':
        return cls(
            name=data["name"],
            unit=data.get("unit", ""),
            comment=data.get("comment", ""),
            data_type=DataType(data.get("dataType", "FLOAT64")),
            min_value=data.get("minValue"),
            max_value=data.get("maxValue")
        )


@dataclass
class SignalData:
    """信号数据"""
    info: SignalInfo
    timestamps: np.ndarray = field(default_factory=lambda: np.array([]))
    values: np.ndarray = field(default_factory=lambda: np.array([]))
    
    def __post_init__(self):
        if not isinstance(self.timestamps, np.ndarray):
            self.timestamps = np.array(self.timestamps)
        if not isinstance(self.values, np.ndarray):
            self.values = np.array(self.values)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典，大数据使用二进制传输优化"""
        return {
            "info": self.info.to_dict(),
            "timestamps": self.timestamps.tobytes() if len(self.timestamps) > 0 else b"",
            "values": self.values.tobytes() if len(self.values) > 0 else b"",
            "timestampType": str(self.timestamps.dtype) if len(self.timestamps) > 0 else "float64",
            "valueType": str(self.values.dtype) if len(self.values) > 0 else "float64",
            "length": len(self.timestamps)
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SignalData':
        """从字典创建，处理二进制数据"""
        info = SignalInfo.from_dict(data["info"])
        length = data.get("length", 0)
        
        if length > 0:
            timestamp_type = data.get("timestampType", "float64")
            value_type = data.get("valueType", "float64")
            
            timestamps = np.frombuffer(data["timestamps"], dtype=timestamp_type)
            values = np.frombuffer(data["values"], dtype=value_type)
        else:
            timestamps = np.array([])
            values = np.array([])
        
        return cls(info=info, timestamps=timestamps, values=values)


@dataclass
class ChannelGroup:
    """通道组信息"""
    name: str
    comment: str = ""
    signals: List[SignalInfo] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "comment": self.comment,
            "signals": [s.to_dict() for s in self.signals]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChannelGroup':
        return cls(
            name=data["name"],
            comment=data.get("comment", ""),
            signals=[SignalInfo.from_dict(s) for s in data.get("signals", [])]
        )


@dataclass
class FileInfo:
    """MDF文件信息"""
    version: str = ""
    program: str = ""
    comment: str = ""
    creation_time: str = ""
    channel_groups: List[ChannelGroup] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "program": self.program,
            "comment": self.comment,
            "creationTime": self.creation_time,
            "channelGroups": [cg.to_dict() for cg in self.channel_groups]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FileInfo':
        return cls(
            version=data.get("version", ""),
            program=data.get("program", ""),
            comment=data.get("comment", ""),
            creation_time=data.get("creationTime", ""),
            channel_groups=[ChannelGroup.from_dict(cg) for cg in data.get("channelGroups", [])]
        )


@dataclass
class WriteRequest:
    """写入请求"""
    file_path: str
    signals: List[SignalData]
    compression: CompressionType = CompressionType.ZIP
    overwrite: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "filePath": self.file_path,
            "signals": [s.to_dict() for s in self.signals],
            "compression": self.compression.value,
            "overwrite": self.overwrite
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WriteRequest':
        return cls(
            file_path=data["filePath"],
            signals=[SignalData.from_dict(s) for s in data.get("signals", [])],
            compression=CompressionType(data.get("compression", "ZIP")),
            overwrite=data.get("overwrite", False)
        )


@dataclass
class ReadRequest:
    """读取请求"""
    file_path: str
    signal_names: Optional[List[str]] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "filePath": self.file_path,
            "signalNames": self.signal_names,
            "startTime": self.start_time,
            "endTime": self.end_time
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ReadRequest':
        return cls(
            file_path=data["filePath"],
            signal_names=data.get("signalNames"),
            start_time=data.get("startTime"),
            end_time=data.get("endTime")
        )


@dataclass
class Response:
    """通用响应"""
    success: bool
    message: str = ""
    data: Any = None
    error_code: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            "success": self.success,
            "message": self.message,
            "errorCode": self.error_code
        }
        if self.data is not None:
            if isinstance(self.data, list):
                result["data"] = [d.to_dict() if hasattr(d, 'to_dict') else d for d in self.data]
            elif hasattr(self.data, 'to_dict'):
                result["data"] = self.data.to_dict()
            else:
                result["data"] = self.data
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Response':
        return cls(
            success=data["success"],
            message=data.get("message", ""),
            data=data.get("data"),
            error_code=data.get("errorCode", 0)
        )


class MessageType(Enum):
    """消息类型"""
    WRITE = "WRITE"
    READ = "READ"
    READ_INFO = "READ_INFO"
    APPEND = "APPEND"
    CLOSE_FILE = "CLOSE_FILE"
    PING = "PING"
    SHUTDOWN = "SHUTDOWN"


@dataclass
class Message:
    """通信消息"""
    msg_type: MessageType
    payload: Dict[str, Any]
    request_id: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.msg_type.value,
            "payload": self.payload,
            "requestId": self.request_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        return cls(
            msg_type=MessageType(data["type"]),
            payload=data.get("payload", {}),
            request_id=data.get("requestId", "")
        )
