"""
Socket服务器
处理与Java端的通信
"""

import socket
import threading
import json
import logging
import struct
import signal
import sys
from typing import Optional, Tuple
from io import BytesIO

from .models import Message, Response
from .handler import RequestHandler

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SocketServer:
    """Socket服务器 - 处理Java端的连接和请求"""
    
    # 消息头长度: 4字节（消息长度）
    HEADER_SIZE = 4
    # 默认缓冲区大小: 64KB
    BUFFER_SIZE = 65536
    # 最大消息大小: 1GB
    MAX_MESSAGE_SIZE = 1024 * 1024 * 1024
    
    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        """
        初始化服务器
        
        Args:
            host: 绑定地址，默认本地
            port: 绑定端口，0表示自动分配
        """
        self.host = host
        self.port = port
        self.server_socket: Optional[socket.socket] = None
        self.handler = RequestHandler()
        self.running = False
        self.clients: list[socket.socket] = []
        self.lock = threading.Lock()
        
        # 设置信号处理
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def start(self) -> int:
        """
        启动服务器
        
        Returns:
            int: 实际绑定的端口号
        """
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            
            # 获取实际绑定的端口
            self.port = self.server_socket.getsockname()[1]
            self.running = True
            
            logger.info(f"Server started on {self.host}:{self.port}")
            
            # 打印端口号（Java端通过标准输出获取）
            print(f"PORT:{self.port}", flush=True)
            
            # 启动接受连接的线程
            accept_thread = threading.Thread(target=self._accept_connections)
            accept_thread.daemon = True
            accept_thread.start()
            
            return self.port
            
        except Exception as e:
            logger.error(f"Failed to start server: {e}")
            raise
    
    def stop(self):
        """停止服务器"""
        logger.info("Stopping server...")
        self.running = False
        
        # 关闭所有客户端连接
        with self.lock:
            for client in self.clients:
                try:
                    client.close()
                except:
                    pass
            self.clients.clear()
        
        # 关闭服务器socket
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        
        # 清理处理器资源
        self.handler.cleanup()
        
        logger.info("Server stopped")
    
    def _accept_connections(self):
        """接受客户端连接"""
        while self.running:
            try:
                self.server_socket.settimeout(1.0)
                client_socket, address = self.server_socket.accept()
                logger.info(f"Client connected from {address}")
                
                with self.lock:
                    self.clients.append(client_socket)
                
                # 为每个客户端启动处理线程
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_socket, address)
                )
                client_thread.daemon = True
                client_thread.start()
                
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"Error accepting connection: {e}")
    
    def _handle_client(self, client_socket: socket.socket, address: Tuple[str, int]):
        """
        处理客户端连接
        
        Args:
            client_socket: 客户端socket
            address: 客户端地址
        """
        try:
            client_socket.settimeout(30.0)  # 30秒超时
            
            while self.running:
                # 接收消息
                message = self._receive_message(client_socket)
                if message is None:
                    break
                
                # 处理消息
                response = self.handler.handle(message)
                
                # 发送响应
                if not self._send_response(client_socket, response):
                    break
                
                # 检查是否是关闭请求
                if message.msg_type.value == "SHUTDOWN":
                    logger.info("Shutdown message received, stopping server")
                    self.running = False
                    break
                    
        except Exception as e:
            logger.error(f"Error handling client {address}: {e}")
        finally:
            logger.info(f"Client {address} disconnected")
            with self.lock:
                if client_socket in self.clients:
                    self.clients.remove(client_socket)
            try:
                client_socket.close()
            except:
                pass
    
    def _receive_message(self, client_socket: socket.socket) -> Optional[Message]:
        """
        接收完整消息
        
        Args:
            client_socket: 客户端socket
            
        Returns:
            Optional[Message]: 解析后的消息，None表示连接关闭
        """
        try:
            # 接收消息头（4字节长度）
            header = self._receive_all(client_socket, self.HEADER_SIZE)
            if header is None:
                return None
            
            # 解析消息长度
            message_length = struct.unpack('!I', header)[0]
            
            if message_length > self.MAX_MESSAGE_SIZE:
                logger.error(f"Message too large: {message_length}")
                return None
            
            # 接收消息体
            message_data = self._receive_all(client_socket, message_length)
            if message_data is None:
                return None
            
            # 解析JSON消息
            message_json = message_data.decode('utf-8')
            message_dict = json.loads(message_json)
            
            return Message.from_dict(message_dict)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            return None
        except Exception as e:
            logger.error(f"Error receiving message: {e}")
            return None
    
    def _receive_all(self, client_socket: socket.socket, 
                    size: int) -> Optional[bytes]:
        """
        接收指定大小的数据
        
        Args:
            client_socket: 客户端socket
            size: 要接收的字节数
            
        Returns:
            Optional[bytes]: 接收到的数据，None表示连接关闭
        """
        data = bytearray()
        while len(data) < size:
            try:
                chunk = client_socket.recv(min(size - len(data), self.BUFFER_SIZE))
                if not chunk:
                    return None
                data.extend(chunk)
            except socket.timeout:
                logger.warning("Socket timeout while receiving")
                return None
            except Exception as e:
                logger.error(f"Error receiving data: {e}")
                return None
        return bytes(data)
    
    def _send_response(self, client_socket: socket.socket, 
                      response: Response) -> bool:
        """
        发送响应
        
        Args:
            client_socket: 客户端socket
            response: 响应对象
            
        Returns:
            bool: 是否发送成功
        """
        try:
            # 序列化响应
            response_dict = response.to_dict()
            response_json = json.dumps(response_dict, ensure_ascii=False)
            response_data = response_json.encode('utf-8')
            
            # 构建消息（长度前缀 + 数据）
            message = struct.pack('!I', len(response_data)) + response_data
            
            # 发送消息
            client_socket.sendall(message)
            return True
            
        except Exception as e:
            logger.error(f"Error sending response: {e}")
            return False
    
    def _signal_handler(self, signum, frame):
        """信号处理器"""
        logger.info(f"Received signal {signum}")
        self.stop()
        sys.exit(0)


def main():
    """主入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='MDF4 Service Server')
    parser.add_argument('--port', type=int, default=0, 
                       help='Port to listen on (0 for auto)')
    parser.add_argument('--host', type=str, default='127.0.0.1',
                       help='Host to bind to')
    
    args = parser.parse_args()
    
    server = SocketServer(host=args.host, port=args.port)
    
    try:
        port = server.start()
        logger.info(f"Server running on port {port}")
        
        # 保持主线程运行
        while server.running:
            import time
            time.sleep(1)
            
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        server.stop()


if __name__ == "__main__":
    main()
