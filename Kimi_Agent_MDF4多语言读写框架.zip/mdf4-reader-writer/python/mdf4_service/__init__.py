"""
MDF4 Service Package
提供MDF4文件的读写服务，通过Socket与Java端通信
"""

__version__ = "1.0.0"
__author__ = "MDF4 Reader-Writer Project"
