"""
MDF4写入器实现
支持大文件分块写入和多线程
"""

import os
import threading
import logging
from typing import Dict, List, Optional, BinaryIO
from pathlib import Path
import numpy as np
from asammdf import MDF, Signal
from asammdf.blocks.mdf_v4 import MDF4

from .models import SignalData, WriteRequest, CompressionType, Response

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MDF4Writer:
    """MDF4写入器 - 支持大文件和多线程"""
    
    # 大文件阈值: 100MB
    LARGE_FILE_THRESHOLD = 100 * 1024 * 1024
    # 分块大小: 每次处理10万条记录
    CHUNK_SIZE = 100000
    
    def __init__(self):
        self._lock = threading.RLock()
        self._open_files: Dict[str, MDF4] = {}
        self._file_locks: Dict[str, threading.RLock] = {}
    
    def write(self, request: WriteRequest) -> Response:
        """
        写入MDF4文件
        
        Args:
            request: 写入请求
            
        Returns:
            Response: 写入结果
        """
        try:
            with self._lock:
                file_path = request.file_path
                
                # 检查文件是否存在
                if os.path.exists(file_path) and not request.overwrite:
                    return Response(
                        success=False,
                        message=f"File already exists: {file_path}",
                        error_code=1001
                    )
                
                # 确保目录存在
                Path(file_path).parent.mkdir(parents=True, exist_ok=True)
                
                # 创建新的MDF4文件
                mdf = MDF(version="4.10")
                
                # 转换压缩类型
                compression = self._get_compression_type(request.compression)
                
                # 计算总数据大小
                total_size = sum(
                    len(s.timestamps) * (s.timestamps.itemsize + s.values.itemsize)
                    for s in request.signals
                )
                
                logger.info(f"Writing {len(request.signals)} signals to {file_path}, "
                          f"total size: {total_size / 1024 / 1024:.2f} MB")
                
                # 根据文件大小选择写入策略
                if total_size > self.LARGE_FILE_THRESHOLD:
                    self._write_large_file(mdf, request.signals, compression)
                else:
                    self._write_normal_file(mdf, request.signals, compression)
                
                # 保存文件
                mdf.save(file_path, compression=compression, overwrite=True)
                mdf.close()
                
                logger.info(f"Successfully wrote to {file_path}")
                
                return Response(
                    success=True,
                    message=f"Successfully wrote {len(request.signals)} signals",
                    data={"filePath": file_path, "signalCount": len(request.signals)}
                )
                
        except Exception as e:
            logger.error(f"Error writing MDF4 file: {str(e)}", exc_info=True)
            return Response(
                success=False,
                message=f"Error writing file: {str(e)}",
                error_code=1002
            )
    
    def append(self, file_path: str, signals: List[SignalData]) -> Response:
        """
        向现有MDF4文件追加数据
        
        Args:
            file_path: 文件路径
            signals: 要追加的信号数据
            
        Returns:
            Response: 追加结果
        """
        try:
            with self._lock:
                if not os.path.exists(file_path):
                    return Response(
                        success=False,
                        message=f"File not found: {file_path}",
                        error_code=1003
                    )
                
                # 获取或创建文件锁
                if file_path not in self._file_locks:
                    self._file_locks[file_path] = threading.RLock()
                
                with self._file_locks[file_path]:
                    # 打开现有文件
                    mdf = MDF(file_path)
                    
                    # 追加信号
                    for signal_data in signals:
                        signal = self._convert_to_signal(signal_data)
                        mdf.append(signal)
                    
                    # 保存（使用临时文件然后替换，确保数据安全）
                    temp_path = file_path + ".tmp"
                    mdf.save(temp_path, overwrite=True)
                    mdf.close()
                    
                    # 原子替换
                    os.replace(temp_path, file_path)
                
                return Response(
                    success=True,
                    message=f"Successfully appended {len(signals)} signals",
                    data={"filePath": file_path}
                )
                
        except Exception as e:
            logger.error(f"Error appending to MDF4 file: {str(e)}", exc_info=True)
            return Response(
                success=False,
                message=f"Error appending to file: {str(e)}",
                error_code=1004
            )
    
    def close_file(self, file_path: str) -> Response:
        """
        关闭打开的文件
        
        Args:
            file_path: 文件路径
            
        Returns:
            Response: 关闭结果
        """
        with self._lock:
            if file_path in self._open_files:
                try:
                    self._open_files[file_path].close()
                    del self._open_files[file_path]
                    if file_path in self._file_locks:
                        del self._file_locks[file_path]
                    return Response(success=True, message=f"Closed {file_path}")
                except Exception as e:
                    return Response(
                        success=False,
                        message=f"Error closing file: {str(e)}",
                        error_code=1005
                    )
            return Response(success=True, message="File not open")
    
    def _write_normal_file(self, mdf: MDF, signals: List[SignalData], 
                          compression: int) -> None:
        """
        普通文件写入 - 适合小文件
        
        Args:
            mdf: MDF对象
            signals: 信号数据列表
            compression: 压缩类型
        """
        for signal_data in signals:
            signal = self._convert_to_signal(signal_data)
            mdf.append(signal)
    
    def _write_large_file(self, mdf: MDF, signals: List[SignalData], 
                         compression: int) -> None:
        """
        大文件分块写入 - 适合大文件，减少内存占用
        
        Args:
            mdf: MDF对象
            signals: 信号数据列表
            compression: 压缩类型
        """
        for signal_data in signals:
            total_length = len(signal_data.timestamps)
            
            if total_length <= self.CHUNK_SIZE:
                # 小信号直接写入
                signal = self._convert_to_signal(signal_data)
                mdf.append(signal)
            else:
                # 大信号分块写入
                logger.info(f"Writing large signal '{signal_data.info.name}' "
                          f"in chunks (total: {total_length})")
                
                # 先写入第一块创建通道
                first_chunk = SignalData(
                    info=signal_data.info,
                    timestamps=signal_data.timestamps[:self.CHUNK_SIZE],
                    values=signal_data.values[:self.CHUNK_SIZE]
                )
                signal = self._convert_to_signal(first_chunk)
                mdf.append(signal)
                
                # 追加剩余块
                for start_idx in range(self.CHUNK_SIZE, total_length, self.CHUNK_SIZE):
                    end_idx = min(start_idx + self.CHUNK_SIZE, total_length)
                    chunk = SignalData(
                        info=signal_data.info,
                        timestamps=signal_data.timestamps[start_idx:end_idx],
                        values=signal_data.values[start_idx:end_idx]
                    )
                    signal = self._convert_to_signal(chunk)
                    mdf.append(signal)
    
    def _convert_to_signal(self, signal_data: SignalData) -> Signal:
        """
        将SignalData转换为asammdf的Signal对象
        
        Args:
            signal_data: 信号数据
            
        Returns:
            Signal: asammdf Signal对象
        """
        return Signal(
            samples=signal_data.values,
            timestamps=signal_data.timestamps,
            name=signal_data.info.name,
            unit=signal_data.info.unit,
            comment=signal_data.info.comment,
        )
    
    def _get_compression_type(self, compression: CompressionType) -> int:
        """
        转换压缩类型
        
        Args:
            compression: 压缩类型枚举
            
        Returns:
            int: asammdf压缩类型代码
        """
        compression_map = {
            CompressionType.NONE: 0,
            CompressionType.ZIP: 1,
            CompressionType.TRANSPOSITION: 2
        }
        return compression_map.get(compression, 1)
    
    def close_all(self):
        """关闭所有打开的文件"""
        with self._lock:
            for file_path, mdf in list(self._open_files.items()):
                try:
                    mdf.close()
                    logger.info(f"Closed {file_path}")
                except Exception as e:
                    logger.error(f"Error closing {file_path}: {e}")
            self._open_files.clear()
            self._file_locks.clear()
