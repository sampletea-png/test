"""
工具函数
"""

import numpy as np
from typing import Any, Dict, List


def numpy_to_list(arr: np.ndarray) -> List[Any]:
    """
    将numpy数组转换为Python列表
    
    Args:
        arr: numpy数组
        
    Returns:
        List[Any]: Python列表
    """
    if arr is None or len(arr) == 0:
        return []
    return arr.tolist()


def list_to_numpy(data: List[Any], dtype=None) -> np.ndarray:
    """
    将Python列表转换为numpy数组
    
    Args:
        data: Python列表
        dtype: 数据类型
        
    Returns:
        np.ndarray: numpy数组
    """
    if not data:
        return np.array([])
    return np.array(data, dtype=dtype)


def estimate_memory_usage(signals_count: int, samples_per_signal: int, 
                         bytes_per_sample: int = 8) -> Dict[str, float]:
    """
    估算内存使用量
    
    Args:
        signals_count: 信号数量
        samples_per_signal: 每个信号的样本数
        bytes_per_sample: 每个样本的字节数
        
    Returns:
        Dict[str, float]: 内存使用估算（MB）
    """
    # 时间戳 + 值 = 2 * samples * bytes
    total_bytes = signals_count * samples_per_signal * bytes_per_sample * 2
    
    return {
        "total_mb": total_bytes / (1024 * 1024),
        "per_signal_mb": (samples_per_signal * bytes_per_sample * 2) / (1024 * 1024),
        "recommended_chunk_size": min(100000, samples_per_signal // 10)
    }


def validate_signal_data(timestamps: np.ndarray, values: np.ndarray) -> Dict[str, Any]:
    """
    验证信号数据
    
    Args:
        timestamps: 时间戳数组
        values: 值数组
        
    Returns:
        Dict[str, Any]: 验证结果
    """
    result = {
        "valid": True,
        "errors": [],
        "warnings": []
    }
    
    # 检查长度
    if len(timestamps) != len(values):
        result["valid"] = False
        result["errors"].append(f"Length mismatch: timestamps={len(timestamps)}, values={len(values)}")
    
    # 检查空数据
    if len(timestamps) == 0:
        result["warnings"].append("Empty data")
    
    # 检查时间戳排序
    if len(timestamps) > 1:
        if not np.all(np.diff(timestamps) >= 0):
            result["warnings"].append("Timestamps are not monotonically increasing")
    
    # 检查NaN值
    nan_count = np.isnan(values).sum()
    if nan_count > 0:
        result["warnings"].append(f"Found {nan_count} NaN values")
    
    # 检查Inf值
    inf_count = np.isinf(values).sum()
    if inf_count > 0:
        result["warnings"].append(f"Found {inf_count} Inf values")
    
    return result


def optimize_data_type(values: np.ndarray) -> str:
    """
    优化数据类型以节省空间
    
    Args:
        values: 值数组
        
    Returns:
        str: 推荐的数据类型
    """
    if values.dtype.kind == 'f':  # 浮点数
        return 'float32'  # 默认使用float32
    elif values.dtype.kind in 'iu':  # 整数
        info = np.iinfo(values.dtype)
        if info.max <= 255 and info.min >= 0:
            return 'uint8'
        elif info.max <= 32767 and info.min >= -32768:
            return 'int16'
        elif info.max <= 2147483647 and info.min >= -2147483648:
            return 'int32'
        else:
            return 'int64'
    else:
        return str(values.dtype)
