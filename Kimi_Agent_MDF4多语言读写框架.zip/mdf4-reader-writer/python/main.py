#!/usr/bin/env python3
"""
MDF4 Service 入口点
由Java端启动，提供MDF4文件读写服务
"""

import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mdf4_service.server import main

if __name__ == "__main__":
    main()
