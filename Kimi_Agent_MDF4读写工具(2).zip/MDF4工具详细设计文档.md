# Java MDF4文件读写工具详细设计文档

## 1. 概述

### 1.1 设计目标

设计一个可在Java项目中方便使用的GB级MDF4文件读写公共工具，通过引入Python的asammdf库实现MDF4文件的高效处理。

### 1.2 核心需求

| 需求项 | 说明 |
|--------|------|
| 文件大小支持 | 支持GB级别的MDF4文件读写 |
| 语言支持 | Java为主，引入Python/C辅助处理 |
| 易用性 | 公共工具类，可在项目任何位置方便调用 |
| 通信方式 | 使用Socket进行进程间通信 |
| 生命周期 | Java项目关闭时，该功能自动关闭 |

### 1.3 技术选型

| 组件 | 技术 | 说明 |
|------|------|------|
| MDF4处理引擎 | Python asammdf | 业界标准的MDF4处理库 |
| 进程管理 | Java ProcessBuilder | 启动和管理Python子进程 |
| 进程通信 | TCP Socket (localhost) | 跨平台、稳定可靠 |
| 数据序列化 | JSON + Base64 | 易于调试且兼容性好 |
| 生命周期管理 | ShutdownHook + 心跳机制 | 确保子进程正确终止 |

---

## 2. 整体架构

### 2.1 架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                        Java Application                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              MDF4Service (公共工具类)                    │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │    │
│  │  │ MDF4Reader  │  │ MDF4Writer  │  │ MDF4Converter   │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│                              │ Socket (TCP)                     │
│                              ▼                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              ProcessBuilder                             │    │
│  │         (启动Python子进程)                               │    │
│  └─────────────────────────────────────────────────────────┘    │
└──────────────────────────────┬──────────────────────────────────┘
                               │
                               │ StdIO/Process
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Python MDF4 Service                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Socket Server (TCP)                         │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │    │
│  │  │  Command    │  │   Handler   │  │   Response      │  │    │
│  │  │  Parser     │  │   Router    │  │   Builder       │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│                              ▼                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              asammdf Library                             │    │
│  │         (MDF4文件实际处理)                                │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 进程关系

```
Java主进程 (Parent)
    │
    ├── 启动 ──► Python子进程 (Child)
    │              │
    │              ├── Socket Server (监听端口)
    │              │
    │              └── MDF4处理引擎
    │
    ├── 通信 ──► Socket Client
    │              │
    │              └── 发送/接收数据
    │
    └── 终止 ──► ShutdownHook
                   │
                   └── 销毁子进程
```

---

## 3. 模块详细设计

### 3.1 Java端 - 公共工具类

#### 3.1.1 核心类结构

```java
// ==================== 核心服务类 ====================

/**
 * MDF4服务入口类 - 单例模式
 * 负责管理Python子进程生命周期和Socket连接
 */
public class MDF4Service {
    private static MDF4Service INSTANCE;
    private Process pythonProcess;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private int port;
    private boolean initialized = false;
    
    // 单例获取
    public static synchronized MDF4Service getInstance() { ... }
    
    // 初始化服务（自动启动Python进程）
    public synchronized void initialize() { ... }
    
    // 关闭服务
    public synchronized void shutdown() { ... }
    
    // 获取读写器
    public MDF4Reader createReader() { ... }
    public MDF4Writer createWriter() { ... }
    
    // 执行命令（内部使用）
    private MDF4Response executeCommand(MDF4Command command) { ... }
}

/**
 * MDF4文件读取器
 */
public class MDF4Reader implements AutoCloseable {
    private MDF4Service service;
    private String filePath;
    
    // 打开文件
    public void open(String filePath) { ... }
    
    // 获取所有信号名称
    public List<String> getSignalNames() { ... }
    
    // 读取信号数据
    public SignalData readSignal(String signalName) { ... }
    
    // 批量读取信号
    public Map<String, SignalData> readSignals(List<String> signalNames) { ... }
    
    // 按时间范围读取
    public SignalData readSignal(String signalName, double startTime, double endTime) { ... }
    
    // 获取文件信息
    public MDF4Info getInfo() { ... }
    
    // 转换为DataFrame格式
    public Map<String, Object> toDataFrame(List<String> signalNames) { ... }
    
    @Override
    public void close() { ... }
}

/**
 * MDF4文件写入器
 */
public class MDF4Writer implements AutoCloseable {
    private MDF4Service service;
    private String filePath;
    private String version;
    
    // 创建新文件
    public void create(String filePath, String version) { ... }
    
    // 追加信号数据
    public void appendSignal(String name, double[] timestamps, 
                            Object[] samples, SignalConfig config) { ... }
    
    // 批量追加
    public void appendSignals(List<Signal> signals) { ... }
    
    // 保存文件
    public void save() { ... }
    
    // 设置压缩
    public void setCompression(int level) { ... }
    
    @Override
    public void close() { ... }
}

/**
 * MDF4文件转换器
 */
public class MDF4Converter {
    private MDF4Service service;
    
    // MDF4转CSV
    public void toCSV(String mdfPath, String csvPath, CSVConfig config) { ... }
    
    // MDF4转MAT
    public void toMAT(String mdfPath, String matPath) { ... }
    
    // 合并多个MDF4文件
    public void concatenate(List<String> mdfPaths, String outputPath) { ... }
    
    // 裁剪时间范围
    public void cut(String inputPath, String outputPath, 
                    Double start, Double end) { ... }
    
    // DBC解码
    public void decodeWithDBC(String mdfPath, String dbcPath, 
                              String outputPath) { ... }
}
```

#### 3.1.2 数据模型

```java
/**
 * 信号数据
 */
public class SignalData {
    private String name;           // 信号名称
    private double[] timestamps;   // 时间戳数组
    private Object[] samples;      // 采样值数组（支持多种类型）
    private String unit;           // 单位
    private String description;    // 描述
    private DataType dataType;     // 数据类型
    
    // Getters and Setters
}

/**
 * 信号配置
 */
public class SignalConfig {
    private String unit;
    private String description;
    private DataType dataType;
    private double conversion;     // 转换因子
    private double offset;         // 偏移量
    
    // Builder模式
}

/**
 * MDF4文件信息
 */
public class MDF4Info {
    private String version;
    private int channelGroupCount;
    private int channelCount;
    private long recordCount;
    private Date startTime;
    private double duration;
    private Map<String, Object> metadata;
    
    // Getters
}

/**
 * 数据类型枚举
 */
public enum DataType {
    UINT8, UINT16, UINT32, UINT64,
    INT8, INT16, INT32, INT64,
    FLOAT32, FLOAT64,
    STRING
}
```

### 3.2 Python端 - MDF4服务进程

#### 3.2.1 核心模块结构

```python
# mdf4_service/
# ├── __main__.py          # 入口点
# ├── server.py            # Socket服务器
# ├── handler.py           # 命令处理器
# ├── mdf4_engine.py       # MDF4核心处理
# └── protocol.py          # 通信协议

# ==================== server.py ====================

import socket
import threading
import json
import logging
from .handler import CommandHandler
from .protocol import Protocol

class MDF4SocketServer:
    """MDF4 Socket服务器"""
    
    def __init__(self, host='127.0.0.1', port=0):
        self.host = host
        self.port = port
        self.server_socket = None
        self.running = False
        self.handler = CommandHandler()
        
    def start(self):
        """启动服务器"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        
        # 获取实际分配的端口（如果port=0）
        actual_port = self.server_socket.getsockname()[1]
        print(f"PORT:{actual_port}", flush=True)  # 通知Java端端口信息
        
        self.server_socket.listen(5)
        self.running = True
        
        logging.info(f"MDF4 Server started on {self.host}:{actual_port}")
        
        # 启动心跳检测线程
        heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_socket, address)
                )
                client_thread.daemon = True
                client_thread.start()
            except Exception as e:
                if self.running:
                    logging.error(f"Server error: {e}")
                    
    def _handle_client(self, client_socket, address):
        """处理客户端连接"""
        logging.info(f"Client connected: {address}")
        try:
            while self.running:
                # 接收数据长度（4字节）
                length_bytes = client_socket.recv(4)
                if not length_bytes:
                    break
                
                data_length = int.from_bytes(length_bytes, 'big')
                
                # 接收完整数据
                data = b''
                while len(data) < data_length:
                    chunk = client_socket.recv(min(8192, data_length - len(data)))
                    if not chunk:
                        break
                    data += chunk
                
                # 解析命令
                command = json.loads(data.decode('utf-8'))
                
                # 处理命令
                response = self.handler.handle(command)
                
                # 发送响应
                response_bytes = json.dumps(response).encode('utf-8')
                client_socket.sendall(len(response_bytes).to_bytes(4, 'big'))
                client_socket.sendall(response_bytes)
                
        except Exception as e:
            logging.error(f"Client handler error: {e}")
        finally:
            client_socket.close()
            logging.info(f"Client disconnected: {address}")
    
    def _heartbeat_loop(self):
        """心跳检测循环"""
        while self.running:
            # 检测父进程是否存活（Windows: 检查PID，Linux: 检查PPID）
            if not self._check_parent_alive():
                logging.info("Parent process died, shutting down...")
                self.stop()
                break
            time.sleep(5)
    
    def _check_parent_alive(self):
        """检查父进程是否存活"""
        import os
        import platform
        
        if platform.system() == 'Windows':
            # Windows: 通过环境变量获取父进程PID
            parent_pid = os.environ.get('MDF4_PARENT_PID')
            if parent_pid:
                try:
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(1, False, int(parent_pid))
                    if handle:
                        kernel32.CloseHandle(handle)
                        return True
                    return False
                except:
                    return False
            return True
        else:
            # Unix/Linux: 检查PPID
            try:
                ppid = os.getppid()
                return ppid != 1  # 如果PPID变成1，说明父进程已终止
            except:
                return False
    
    def stop(self):
        """停止服务器"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()


# ==================== handler.py ====================

import logging
from asammdf import MDF
import numpy as np
import base64
import io

class CommandHandler:
    """命令处理器"""
    
    def __init__(self):
        self.open_files = {}  # file_id -> MDF对象
        self.file_counter = 0
        
    def handle(self, command):
        """处理命令"""
        cmd_type = command.get('type')
        params = command.get('params', {})
        
        try:
            if cmd_type == 'OPEN_READ':
                return self._handle_open_read(params)
            elif cmd_type == 'OPEN_WRITE':
                return self._handle_open_write(params)
            elif cmd_type == 'GET_SIGNALS':
                return self._handle_get_signals(params)
            elif cmd_type == 'READ_SIGNAL':
                return self._handle_read_signal(params)
            elif cmd_type == 'READ_SIGNALS_BATCH':
                return self._handle_read_signals_batch(params)
            elif cmd_type == 'APPEND_SIGNAL':
                return self._handle_append_signal(params)
            elif cmd_type == 'SAVE':
                return self._handle_save(params)
            elif cmd_type == 'CLOSE':
                return self._handle_close(params)
            elif cmd_type == 'GET_INFO':
                return self._handle_get_info(params)
            elif cmd_type == 'CONVERT_TO_CSV':
                return self._handle_convert_to_csv(params)
            elif cmd_type == 'CUT':
                return self._handle_cut(params)
            elif cmd_type == 'PING':
                return {'status': 'OK', 'message': 'pong'}
            else:
                return {'status': 'ERROR', 'message': f'Unknown command: {cmd_type}'}
        except Exception as e:
            logging.error(f"Command error: {e}")
            return {'status': 'ERROR', 'message': str(e)}
    
    def _handle_open_read(self, params):
        """打开文件用于读取"""
        file_path = params['file_path']
        mdf = MDF(file_path)
        self.file_counter += 1
        file_id = str(self.file_counter)
        self.open_files[file_id] = mdf
        return {
            'status': 'OK',
            'file_id': file_id,
            'version': mdf.version
        }
    
    def _handle_read_signal(self, params):
        """读取信号数据"""
        file_id = params['file_id']
        signal_name = params['signal_name']
        start_time = params.get('start_time')
        end_time = params.get('end_time')
        
        mdf = self.open_files.get(file_id)
        if not mdf:
            return {'status': 'ERROR', 'message': 'File not open'}
        
        # 获取信号
        signal = mdf.get(signal_name)
        
        # 时间范围过滤
        if start_time is not None or end_time is not None:
            mask = np.ones(len(signal.timestamps), dtype=bool)
            if start_time is not None:
                mask &= signal.timestamps >= start_time
            if end_time is not None:
                mask &= signal.timestamps <= end_time
            timestamps = signal.timestamps[mask]
            samples = signal.samples[mask]
        else:
            timestamps = signal.timestamps
            samples = signal.samples
        
        # 序列化数据
        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'timestamps': self._encode_array(timestamps),
            'samples': self._encode_array(samples),
            'data_type': str(samples.dtype)
        }
    
    def _encode_array(self, arr):
        """编码numpy数组为base64字符串"""
        buffer = io.BytesIO()
        np.save(buffer, arr, allow_pickle=False)
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _handle_close(self, params):
        """关闭文件"""
        file_id = params['file_id']
        mdf = self.open_files.pop(file_id, None)
        if mdf:
            mdf.close()
        return {'status': 'OK'}


# ==================== __main__.py ====================

import sys
import argparse
from .server import MDF4SocketServer

def main():
    parser = argparse.ArgumentParser(description='MDF4 Socket Service')
    parser.add_argument('--port', type=int, default=0, help='Server port (0 for auto)')
    parser.add_argument('--parent-pid', type=str, help='Parent process PID')
    args = parser.parse_args()
    
    # 设置父进程PID环境变量（用于心跳检测）
    if args.parent_pid:
        import os
        os.environ['MDF4_PARENT_PID'] = args.parent_pid
    
    server = MDF4SocketServer(port=args.port)
    
    try:
        server.start()
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        server.stop()

if __name__ == '__main__':
    main()
```

### 3.3 Socket通信协议

#### 3.3.1 协议格式

```
┌─────────────────────────────────────────────────────────────┐
│                     请求/响应格式                            │
├─────────────────────────────────────────────────────────────┤
│  长度字段 (4字节, Big Endian)  │  JSON数据 (变长)            │
│  表示后续JSON数据的字节长度     │  UTF-8编码                  │
└─────────────────────────────────────────────────────────────┘
```

#### 3.3.2 命令类型

| 命令 | 方向 | 说明 |
|------|------|------|
| `OPEN_READ` | Java→Python | 打开MDF4文件用于读取 |
| `OPEN_WRITE` | Java→Python | 创建新MDF4文件用于写入 |
| `GET_SIGNALS` | Java→Python | 获取所有信号名称列表 |
| `READ_SIGNAL` | Java→Python | 读取单个信号数据 |
| `READ_SIGNALS_BATCH` | Java→Python | 批量读取多个信号 |
| `APPEND_SIGNAL` | Java→Python | 追加信号数据 |
| `SAVE` | Java→Python | 保存文件 |
| `CLOSE` | Java→Python | 关闭文件 |
| `GET_INFO` | Java→Python | 获取文件信息 |
| `CONVERT_TO_CSV` | Java→Python | 转换为CSV格式 |
| `CUT` | Java→Python | 按时间裁剪 |
| `PING` | Java→Python | 心跳检测 |

#### 3.3.3 消息示例

```json
// OPEN_READ 请求
{
    "type": "OPEN_READ",
    "params": {
        "file_path": "/data/measurement.mf4"
    }
}

// OPEN_READ 响应
{
    "status": "OK",
    "file_id": "1",
    "version": "4.10"
}

// READ_SIGNAL 请求
{
    "type": "READ_SIGNAL",
    "params": {
        "file_id": "1",
        "signal_name": "EngineSpeed",
        "start_time": 0.0,
        "end_time": 60.0
    }
}

// READ_SIGNAL 响应
{
    "status": "OK",
    "name": "EngineSpeed",
    "unit": "rpm",
    "timestamps": "base64_encoded_numpy_array...",
    "samples": "base64_encoded_numpy_array...",
    "data_type": "float64"
}
```

---

## 4. 生命周期管理

### 4.1 启动流程

```
Java Application Start
        │
        ▼
┌───────────────────┐
│ 首次调用MDF4Service │
│   .getInstance()   │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│   initialize()    │
└─────────┬─────────┘
          │
          ├──► 查找可用端口
          │
          ├──► ProcessBuilder启动Python
          │         python -m mdf4_service --port 0 --parent-pid <pid>
          │
          ├──► 读取Python输出的PORT信息
          │
          ├──► 建立Socket连接
          │
          └──► 注册ShutdownHook
                    │
                    └──► Runtime.getRuntime().addShutdownHook()
                              │
                              └──► 进程终止时调用shutdown()
```

### 4.2 关闭流程

```
Java Application Shutdown
        │
        ├── 正常关闭 ──► ShutdownHook触发
        │                    │
        │                    ├──► 关闭所有打开的文件
        │                    │
        │                    ├──► 关闭Socket连接
        │                    │
        │                    ├──► 发送终止信号给Python
        │                    │
        │                    └──► process.destroy()
        │
        └── 异常终止 ──► Python心跳检测发现父进程死亡
                              │
                              └──► 自动关闭并退出
```

### 4.3 Java端生命周期代码

```java
public class MDF4Service {
    
    private void initialize() {
        if (initialized) return;
        
        try {
            // 1. 查找可用端口
            this.port = findAvailablePort();
            
            // 2. 构建Python命令
            List<String> command = new ArrayList<>();
            command.add(getPythonPath());
            command.add("-m");
            command.add("mdf4_service");
            command.add("--port");
            command.add(String.valueOf(port));
            command.add("--parent-pid");
            command.add(String.valueOf(ProcessHandle.current().pid()));
            
            // 3. 启动Python进程
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            pb.environment().put("PYTHONPATH", getPythonModulePath());
            
            this.pythonProcess = pb.start();
            
            // 4. 读取Python输出的端口信息
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(pythonProcess.getInputStream())
            );
            String line;
            int actualPort = -1;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("PORT:")) {
                    actualPort = Integer.parseInt(line.substring(5));
                    break;
                }
            }
            
            if (actualPort == -1) {
                throw new RuntimeException("Failed to get Python service port");
            }
            
            // 5. 等待服务启动
            waitForService(actualPort);
            
            // 6. 建立Socket连接
            this.clientSocket = new Socket("127.0.0.1", actualPort);
            this.out = new PrintWriter(clientSocket.getOutputStream(), true);
            this.in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream())
            );
            
            // 7. 注册ShutdownHook
            registerShutdownHook();
            
            this.initialized = true;
            
        } catch (Exception e) {
            shutdown();
            throw new RuntimeException("Failed to initialize MDF4 service", e);
        }
    }
    
    private void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("MDF4Service: Shutdown hook triggered");
            shutdown();
        }));
    }
    
    public synchronized void shutdown() {
        if (!initialized) return;
        
        try {
            // 关闭Socket
            if (clientSocket != null && !clientSocket.isClosed()) {
                clientSocket.close();
            }
            
            // 终止Python进程
            if (pythonProcess != null && pythonProcess.isAlive()) {
                pythonProcess.destroy();
                
                // 等待进程终止，最多5秒
                boolean terminated = pythonProcess.waitFor(5, TimeUnit.SECONDS);
                if (!terminated) {
                    pythonProcess.destroyForcibly();
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error during shutdown: " + e.getMessage());
        } finally {
            initialized = false;
        }
    }
}
```

---

## 5. 使用示例

### 5.1 读取MDF4文件

```java
import com.example.mdf4.*;

public class MDF4ReadExample {
    public static void main(String[] args) {
        // 方式1: 使用try-with-resources（推荐）
        try (MDF4Reader reader = MDF4Service.getInstance().createReader()) {
            reader.open("/data/measurement.mf4");
            
            // 获取所有信号名称
            List<String> signals = reader.getSignalNames();
            System.out.println("Signals: " + signals);
            
            // 读取单个信号
            SignalData engineSpeed = reader.readSignal("EngineSpeed");
            System.out.println("Engine Speed Unit: " + engineSpeed.getUnit());
            System.out.println("Sample Count: " + engineSpeed.getSamples().length);
            
            // 按时间范围读取
            SignalData torque = reader.readSignal("EngineTorque", 0.0, 60.0);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // 方式2: 手动管理生命周期
        MDF4Service service = MDF4Service.getInstance();
        service.initialize();
        
        try {
            MDF4Reader reader = service.createReader();
            reader.open("/data/measurement.mf4");
            // ... 读取操作
            reader.close();
        } finally {
            service.shutdown();
        }
    }
}
```

### 5.2 写入MDF4文件

```java
import com.example.mdf4.*;

public class MDF4WriteExample {
    public static void main(String[] args) {
        try (MDF4Writer writer = MDF4Service.getInstance().createWriter()) {
            // 创建新文件
            writer.create("/output/new_file.mf4", "4.10");
            
            // 准备时间戳和数据
            double[] timestamps = new double[1000];
            double[] samples = new double[1000];
            for (int i = 0; i < 1000; i++) {
                timestamps[i] = i * 0.01;
                samples[i] = Math.sin(i * 0.1);
            }
            
            // 配置信号
            SignalConfig config = SignalConfig.builder()
                .unit("V")
                .description("Voltage signal")
                .dataType(DataType.FLOAT64)
                .build();
            
            // 追加信号
            writer.appendSignal("Voltage", timestamps, samples, config);
            
            // 追加更多信号...
            
            // 保存文件
            writer.save();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### 5.3 批量处理

```java
import com.example.mdf4.*;
import java.util.*;

public class MDF4BatchExample {
    public static void main(String[] args) {
        MDF4Service service = MDF4Service.getInstance();
        
        // 批量读取多个信号
        try (MDF4Reader reader = service.createReader()) {
            reader.open("/data/large_file.mf4");
            
            List<String> signalNames = Arrays.asList(
                "EngineSpeed", "EngineTorque", "ThrottlePosition", "VehicleSpeed"
            );
            
            // 一次性读取多个信号（更高效）
            Map<String, SignalData> signals = reader.readSignals(signalNames);
            
            for (Map.Entry<String, SignalData> entry : signals.entrySet()) {
                System.out.println(entry.getKey() + ": " + 
                    entry.getValue().getSamples().length + " samples");
            }
            
        }
        
        // 文件转换
        MDF4Converter converter = service.createConverter();
        
        // MDF4转CSV
        CSVConfig csvConfig = CSVConfig.builder()
            .delimiter(",")
            .includeTime(true)
            .timeFormat("SECONDS")
            .build();
        
        converter.toCSV("/data/input.mf4", "/output/output.csv", csvConfig);
        
        // 按时间裁剪
        converter.cut("/data/input.mf4", "/output/cropped.mf4", 10.0, 120.0);
        
        // 合并多个文件
        List<String> files = Arrays.asList(
            "/data/file1.mf4",
            "/data/file2.mf4",
            "/data/file3.mf4"
        );
        converter.concatenate(files, "/output/merged.mf4");
    }
}
```

---

## 6. 部署方案

### 6.1 项目结构

```
mdf4-tool/
├── java/
│   ├── src/main/java/com/example/mdf4/
│   │   ├── MDF4Service.java
│   │   ├── MDF4Reader.java
│   │   ├── MDF4Writer.java
│   │   ├── MDF4Converter.java
│   │   ├── model/
│   │   │   ├── SignalData.java
│   │   │   ├── SignalConfig.java
│   │   │   ├── MDF4Info.java
│   │   │   └── DataType.java
│   │   └── exception/
│   │       └── MDF4Exception.java
│   └── pom.xml
├── python/
│   ├── mdf4_service/
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── server.py
│   │   ├── handler.py
│   │   └── protocol.py
│   ├── setup.py
│   └── requirements.txt
└── README.md
```

### 6.2 Python依赖

```txt
# requirements.txt
asammdf>=7.0.0
numpy>=1.20.0
```

### 6.3 Java依赖

```xml
<!-- pom.xml -->
<dependencies>
    <!-- JSON处理 -->
    <dependency>
        <groupId>com.google.code.gson</groupId>
        <artifactId>gson</artifactId>
        <version>2.10.1</version>
    </dependency>
    
    <!-- 日志 -->
    <dependency>
        <groupId>org.slf4j</groupId>
        <artifactId>slf4j-api</artifactId>
        <version>2.0.9</version>
    </dependency>
    
    <!-- 单元测试 -->
    <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.13.2</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

### 6.4 打包部署

```bash
# 1. 打包Python模块
cd python
pip install build
python -m build

# 2. 安装Python依赖
pip install dist/mdf4_service-1.0.0-py3-none-any.whl
pip install -r requirements.txt

# 3. 打包Java库
mvn clean package

# 4. 在Java项目中引用
# 将生成的jar包添加到项目依赖
```

---

## 7. 性能优化

### 7.1 大数据处理策略

| 策略 | 说明 |
|------|------|
| 分块读取 | 对于GB级文件，按块读取避免内存溢出 |
| 流式传输 | Socket传输使用流式处理，避免一次性加载 |
| 批量操作 | 合并多个小操作为一个批量操作，减少通信开销 |
| 压缩传输 | 大数据使用gzip压缩后传输 |
| 本地缓存 | 频繁访问的数据在Java端缓存 |

### 7.2 配置参数

```java
public class MDF4Config {
    // Socket超时设置（毫秒）
    private int socketTimeout = 30000;
    
    // 数据块大小（字节）
    private int chunkSize = 1024 * 1024; // 1MB
    
    // 最大并发连接数
    private int maxConnections = 5;
    
    // 是否启用压缩
    private boolean enableCompression = true;
    
    // 心跳间隔（秒）
    private int heartbeatInterval = 5;
    
    // 临时文件目录
    private String tempDirectory = System.getProperty("java.io.tmpdir");
}
```

---

## 8. 错误处理

### 8.1 异常类型

```java
public class MDF4Exception extends RuntimeException {
    private ErrorCode errorCode;
    
    public enum ErrorCode {
        SERVICE_NOT_INITIALIZED,   // 服务未初始化
        SERVICE_START_FAILED,      // 服务启动失败
        FILE_NOT_FOUND,            // 文件不存在
        FILE_OPEN_FAILED,          // 文件打开失败
        INVALID_SIGNAL_NAME,       // 无效的信号名称
        READ_ERROR,                // 读取错误
        WRITE_ERROR,               // 写入错误
        COMMUNICATION_ERROR,       // 通信错误
        TIMEOUT_ERROR              // 超时错误
    }
}
```

### 8.2 重试机制

```java
public class MDF4Client {
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 1000;
    
    private MDF4Response executeWithRetry(MDF4Command command) {
        int attempts = 0;
        Exception lastException = null;
        
        while (attempts < MAX_RETRIES) {
            try {
                return executeCommand(command);
            } catch (CommunicationException e) {
                lastException = e;
                attempts++;
                
                if (attempts < MAX_RETRIES) {
                    try {
                        Thread.sleep(RETRY_DELAY_MS * attempts);
                        reconnect(); // 尝试重新连接
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
        
        throw new MDF4Exception("Max retries exceeded", lastException);
    }
}
```

---

## 9. 测试方案

### 9.1 单元测试

```java
public class MDF4ServiceTest {
    
    @Test
    public void testServiceLifecycle() {
        MDF4Service service = MDF4Service.getInstance();
        
        // 测试初始化
        service.initialize();
        assertTrue(service.isInitialized());
        
        // 测试关闭
        service.shutdown();
        assertFalse(service.isInitialized());
    }
    
    @Test
    public void testReadSignal() throws Exception {
        try (MDF4Reader reader = MDF4Service.getInstance().createReader()) {
            reader.open("test.mf4");
            
            SignalData data = reader.readSignal("TestSignal");
            assertNotNull(data);
            assertEquals(data.getTimestamps().length, data.getSamples().length);
        }
    }
}
```

### 9.2 性能测试

```java
public class MDF4PerformanceTest {
    
    @Test
    public void testLargeFileRead() throws Exception {
        long startTime = System.currentTimeMillis();
        
        try (MDF4Reader reader = MDF4Service.getInstance().createReader()) {
            reader.open("large_file.mf4"); // GB级文件
            
            List<String> signals = reader.getSignalNames();
            Map<String, SignalData> data = reader.readSignals(signals);
        }
        
        long duration = System.currentTimeMillis() - startTime;
        System.out.println("Read time: " + duration + "ms");
        
        assertTrue("Read should complete within 30 seconds", duration < 30000);
    }
}
```

---

## 10. 总结

### 10.1 方案优势

| 优势 | 说明 |
|------|------|
| 技术成熟 | 使用asammdf库，业界标准MDF4处理方案 |
| 跨平台 | Java + Python + Socket，支持Windows/Linux/Mac |
| 易集成 | 公共工具类设计，一行代码即可使用 |
| 生命周期管理 | 自动启动/关闭，无需手动管理 |
| 高性能 | 支持GB级大文件，流式处理不占用大量内存 |
| 可扩展 | 模块化设计，易于添加新功能 |

### 10.2 注意事项

1. **Python环境**: 需要预先安装Python 3.8+和asammdf库
2. **端口占用**: 使用动态端口分配，避免端口冲突
3. **防火墙**: 确保localhost通信不被防火墙拦截
4. **资源释放**: 建议使用try-with-resources确保资源释放
5. **并发访问**: 当前设计为单连接，多线程访问需要同步

### 10.3 后续优化方向

1. 支持连接池，提高并发性能
2. 添加更多格式转换支持（Parquet, HDF5等）
3. 实现增量读取，支持实时数据流
4. 添加DBC/LDF文件解码功能
5. 支持远程Python服务部署
