# Java MDF4文件读写工具详细设计文档（并发实时版）

## 1. 概述

### 1.1 设计目标

设计一个可在Java项目中方便使用的GB级MDF4文件读写公共工具，支持：
- **多线程并发读写** - 多个线程可同时请求读写操作
- **实时数据流** - 支持实时/流式数据读取和监控
- **高性能** - 连接池管理，避免频繁创建销毁进程

### 1.2 核心需求

| 需求项 | 说明 |
|--------|------|
| 文件大小支持 | 支持GB级别的MDF4文件读写 |
| 语言支持 | Java为主，引入Python/C辅助处理 |
| 易用性 | 公共工具类，可在项目任何位置方便调用 |
| 通信方式 | 使用Socket进行进程间通信 |
| 生命周期 | Java项目关闭时，该功能自动关闭 |
| **并发支持** | **多线程同时读写，线程安全** |
| **实时支持** | **支持流式读取、实时监控** |

### 1.3 技术选型

| 组件 | 技术 | 说明 |
|------|------|------|
| MDF4处理引擎 | Python asammdf | 业界标准的MDF4处理库 |
| 进程管理 | Java ProcessBuilder | 启动和管理Python子进程 |
| 进程通信 | TCP Socket (localhost) | 跨平台、稳定可靠 |
| **连接管理** | **连接池 (Apache Commons Pool2)** | **支持并发复用** |
| **线程安全** | **ConcurrentHashMap + ReentrantReadWriteLock** | **高效并发控制** |
| **实时流** | **NIO + 观察者模式** | **非阻塞流式处理** |
| 数据序列化 | JSON + Base64 | 易于调试且兼容性好 |
| 生命周期管理 | ShutdownHook + 心跳机制 | 确保子进程正确终止 |

---

## 2. 整体架构

### 2.1 并发架构图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Java Application                                    │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                    MDF4ServiceManager (单例)                          │   │
│  │  ┌────────────────────────────────────────────────────────────────┐  │   │
│  │  │                  Connection Pool (连接池)                       │  │   │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐              │  │   │
│  │  │  │ Conn 1  │ │ Conn 2  │ │ Conn 3  │ │ Conn N  │  ...         │  │   │
│  │  │  │ (busy)  │ │ (idle)  │ │ (busy)  │ │ (idle)  │              │  │   │
│  │  │  └────┬────┘ └────┬────┘ └────┬────┘ └────┬────┘              │  │   │
│  │  └───────┼───────────┼───────────┼───────────┼────────────────────┘  │   │
│  │          │           │           │           │                       │   │
│  │  ┌───────┴───────────┴───────────┴───────────┴────────────────────┐  │   │
│  │  │              Thread-Safe Operation Queue                        │  │   │
│  │  │  (ConcurrentLinkedQueue + ReentrantReadWriteLock)              │  │   │
│  │  └────────────────────────────────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│  ┌─────────────────────────────────┼─────────────────────────────────────┐  │
│  │         Thread 1                │         Thread 2                    │  │
│  │  ┌──────────────────┐          │  ┌──────────────────┐               │  │
│  │  │ MDF4Reader       │          │  │ MDF4Writer       │               │  │
│  │  │ - borrow conn    │          │  │ - borrow conn    │               │  │
│  │  │ - read signal    │          │  │ - append signal  │               │  │
│  │  │ - return conn    │          │  │ - return conn    │               │  │
│  │  └──────────────────┘          │  └──────────────────┘               │  │
│  └─────────────────────────────────┴─────────────────────────────────────┘  │
│                                    │                                         │
│                                    │ Socket (TCP)                           │
│                                    ▼                                         │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                    Python Process Pool                                │   │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │   │
│  │  │ Process 1   │ │ Process 2   │ │ Process 3   │ │ Process N   │    │   │
│  │  │ :port 9001  │ │ :port 9002  │ │ :port 9003  │ │ :port 90xx  │    │   │
│  │  │ (asammdf)   │ │ (asammdf)   │ │ (asammdf)   │ │ (asammdf)   │    │   │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 实时流架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Real-Time Streaming                                 │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                     MDF4StreamManager                                 │   │
│  │  ┌────────────────────────────────────────────────────────────────┐  │   │
│  │  │                    File Monitor (WatchService)                  │  │   │
│  │  │  - 监控文件变化 (MDF4文件追加写入)                               │  │   │
│  │  │  - 触发增量读取事件                                             │  │   │
│  │  └────────────────────────────────────────────────────────────────┘  │   │
│  │                              │                                        │   │
│  │                              ▼                                        │   │
│  │  ┌────────────────────────────────────────────────────────────────┐  │   │
│  │  │                   Stream Buffer (RingBuffer)                    │  │   │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐              │  │   │
│  │  │  │ Chunk 1 │ │ Chunk 2 │ │ Chunk 3 │ │ Chunk 4 │  (循环覆盖)   │  │   │
│  │  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘              │  │   │
│  │  └────────────────────────────────────────────────────────────────┘  │   │
│  │                              │                                        │   │
│  │                              ▼                                        │   │
│  │  ┌────────────────────────────────────────────────────────────────┐  │   │
│  │  │              Event Bus (Publish-Subscribe)                      │  │   │
│  │  │  ┌──────────┐ ┌──────────┐ ┌──────────┐                       │  │   │
│  │  │  │ Listener1│ │ Listener2│ │ Listener3│  (多订阅者)            │  │   │
│  │  │  │ (Thread) │ │ (Thread) │ │ (Thread) │                       │  │   │
│  │  │  └──────────┘ └──────────┘ └──────────┘                       │  │   │
│  │  └────────────────────────────────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. 模块详细设计

### 3.1 Java端 - 核心服务类

#### 3.1.1 连接池设计

```java
/**
 * MDF4连接对象 - 包装Socket连接
 */
public class MDF4Connection implements AutoCloseable {
    private final String connectionId;
    private final Socket socket;
    private final PrintWriter out;
    private final BufferedReader in;
    private final long createTime;
    private volatile long lastUseTime;
    private volatile boolean valid = true;
    private volatile boolean inUse = false;
    
    // 线程本地存储的打开文件映射 (fileId -> filePath)
    private final ConcurrentHashMap<String, String> openFiles = new ConcurrentHashMap<>();
    
    public MDF4Connection(String connectionId, Socket socket) throws IOException {
        this.connectionId = connectionId;
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.createTime = System.currentTimeMillis();
        this.lastUseTime = createTime;
    }
    
    /**
     * 执行命令（线程安全）
     */
    public synchronized MDF4Response execute(MDF4Command command) throws IOException {
        if (!valid) {
            throw new IOException("Connection is invalid");
        }
        
        try {
            // 发送命令
            String json = GsonUtils.toJson(command);
            byte[] data = json.getBytes(StandardCharsets.UTF_8);
            
            // 发送长度 + 数据
            synchronized (this) {
                socket.getOutputStream().write(intToBytes(data.length));
                socket.getOutputStream().write(data);
                socket.getOutputStream().flush();
                
                // 读取响应
                byte[] lengthBytes = readNBytes(4);
                int responseLength = bytesToInt(lengthBytes);
                byte[] responseBytes = readNBytes(responseLength);
                
                String responseJson = new String(responseBytes, StandardCharsets.UTF_8);
                lastUseTime = System.currentTimeMillis();
                
                return GsonUtils.fromJson(responseJson, MDF4Response.class);
            }
        } catch (Exception e) {
            valid = false;
            throw new IOException("Command execution failed", e);
        }
    }
    
    /**
     * 注册打开的文件
     */
    public void registerOpenFile(String fileId, String filePath) {
        openFiles.put(fileId, filePath);
    }
    
    /**
     * 注销打开的文件
     */
    public void unregisterOpenFile(String fileId) {
        openFiles.remove(fileId);
    }
    
    /**
     * 关闭所有打开的文件
     */
    public void closeAllFiles() {
        for (String fileId : openFiles.keySet()) {
            try {
                execute(new MDF4Command("CLOSE", Map.of("file_id", fileId)));
            } catch (Exception e) {
                // 忽略关闭错误
            }
        }
        openFiles.clear();
    }
    
    @Override
    public void close() {
        closeAllFiles();
        valid = false;
        try {
            socket.close();
        } catch (IOException e) {
            // 忽略
        }
    }
    
    // Getters
    public boolean isValid() { return valid && socket.isConnected() && !socket.isClosed(); }
    public boolean isInUse() { return inUse; }
    public void setInUse(boolean inUse) { this.inUse = inUse; }
    public long getIdleTime() { return System.currentTimeMillis() - lastUseTime; }
    public String getConnectionId() { return connectionId; }
}

/**
 * MDF4连接池 - 基于Apache Commons Pool2
 */
public class MDF4ConnectionPool {
    private final GenericObjectPool<MDF4Connection> pool;
    private final MDF4ConnectionFactory factory;
    
    public MDF4ConnectionPool(MDF4ConnectionFactory factory, PoolConfig config) {
        this.factory = factory;
        
        GenericObjectPoolConfig<MDF4Connection> poolConfig = new GenericObjectPoolConfig<>();
        poolConfig.setMaxTotal(config.getMaxConnections());
        poolConfig.setMaxIdle(config.getMaxIdle());
        poolConfig.setMinIdle(config.getMinIdle());
        poolConfig.setMaxWaitMillis(config.getMaxWaitMillis());
        poolConfig.setTestOnBorrow(true);
        poolConfig.setTestOnReturn(true);
        poolConfig.setTestWhileIdle(true);
        poolConfig.setTimeBetweenEvictionRunsMillis(30000); // 30秒检查一次
        poolConfig.setMinEvictableIdleTimeMillis(60000);    // 空闲60秒可驱逐
        
        this.pool = new GenericObjectPool<>(factory, poolConfig);
    }
    
    /**
     * 获取连接（阻塞）
     */
    public MDF4Connection borrowConnection() throws MDF4Exception {
        try {
            MDF4Connection conn = pool.borrowObject();
            conn.setInUse(true);
            return conn;
        } catch (Exception e) {
            throw new MDF4Exception("Failed to borrow connection", e);
        }
    }
    
    /**
     * 获取连接（带超时）
     */
    public MDF4Connection borrowConnection(long timeout, TimeUnit unit) throws MDF4Exception {
        try {
            MDF4Connection conn = pool.borrowObject(unit.toMillis(timeout));
            conn.setInUse(true);
            return conn;
        } catch (Exception e) {
            throw new MDF4Exception("Failed to borrow connection within timeout", e);
        }
    }
    
    /**
     * 归还连接
     */
    public void returnConnection(MDF4Connection connection) {
        if (connection != null) {
            connection.setInUse(false);
            pool.returnObject(connection);
        }
    }
    
    /**
     * 关闭连接池
     */
    public void shutdown() {
        pool.close();
    }
    
    public int getActiveCount() { return pool.getNumActive(); }
    public int getIdleCount() { return pool.getNumIdle(); }
}

/**
 * MDF4连接工厂
 */
public class MDF4ConnectionFactory extends BasePooledObjectFactory<MDF4Connection> {
    private final AtomicInteger counter = new AtomicInteger(0);
    private final String pythonPath;
    private final String pythonModule;
    
    @Override
    public MDF4Connection create() throws Exception {
        int port = findAvailablePort();
        String connId = "conn-" + counter.incrementAndGet();
        
        // 启动Python进程
        ProcessBuilder pb = new ProcessBuilder(
            pythonPath, "-m", pythonModule,
            "--port", String.valueOf(port),
            "--parent-pid", String.valueOf(ProcessHandle.current().pid())
        );
        
        Process process = pb.start();
        
        // 等待Python服务启动并获取端口确认
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(process.getInputStream())
        );
        
        String line;
        int actualPort = -1;
        long startTime = System.currentTimeMillis();
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("PORT:")) {
                actualPort = Integer.parseInt(line.substring(5));
                break;
            }
            if (System.currentTimeMillis() - startTime > 30000) {
                process.destroy();
                throw new RuntimeException("Python service startup timeout");
            }
        }
        
        if (actualPort == -1) {
            process.destroy();
            throw new RuntimeException("Failed to get Python service port");
        }
        
        // 等待服务就绪
        waitForServiceReady(actualPort);
        
        // 建立Socket连接
        Socket socket = new Socket("127.0.0.1", actualPort);
        socket.setSoTimeout(30000);
        socket.setKeepAlive(true);
        
        return new MDF4Connection(connId, socket);
    }
    
    @Override
    public PooledObject<MDF4Connection> wrap(MDF4Connection connection) {
        return new DefaultPooledObject<>(connection);
    }
    
    @Override
    public boolean validateObject(PooledObject<MDF4Connection> p) {
        return p.getObject().isValid();
    }
    
    @Override
    public void destroyObject(PooledObject<MDF4Connection> p) throws Exception {
        p.getObject().close();
    }
}
```

#### 3.1.2 线程安全的MDF4服务管理器

```java
/**
 * MDF4服务管理器 - 线程安全的单例
 */
public class MDF4ServiceManager {
    private static volatile MDF4ServiceManager INSTANCE;
    private static final Object LOCK = new Object();
    
    private volatile boolean initialized = false;
    private MDF4ConnectionPool connectionPool;
    private MDF4StreamManager streamManager;
    
    // 文件级读写锁映射 (filePath -> ReadWriteLock)
    private final ConcurrentHashMap<String, ReentrantReadWriteLock> fileLocks = new ConcurrentHashMap<>();
    
    // 打开文件引用计数 (filePath -> AtomicInteger)
    private final ConcurrentHashMap<String, AtomicInteger> fileRefCounts = new ConcurrentHashMap<>();
    
    private MDF4ServiceManager() {}
    
    public static MDF4ServiceManager getInstance() {
        if (INSTANCE == null) {
            synchronized (LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new MDF4ServiceManager();
                }
            }
        }
        return INSTANCE;
    }
    
    /**
     * 初始化服务
     */
    public void initialize(PoolConfig config) {
        if (initialized) return;
        
        synchronized (LOCK) {
            if (initialized) return;
            
            // 创建连接池
            MDF4ConnectionFactory factory = new MDF4ConnectionFactory(
                getPythonPath(), 
                "mdf4_service"
            );
            this.connectionPool = new MDF4ConnectionPool(factory, config);
            
            // 创建流管理器
            this.streamManager = new MDF4StreamManager(this);
            
            // 注册ShutdownHook
            registerShutdownHook();
            
            initialized = true;
        }
    }
    
    /**
     * 获取文件读锁
     */
    public ReentrantReadWriteLock.ReadLock acquireReadLock(String filePath) {
        ReentrantReadWriteLock lock = fileLocks.computeIfAbsent(
            filePath, 
            k -> new ReentrantReadWriteLock()
        );
        lock.readLock().lock();
        fileRefCounts.computeIfAbsent(filePath, k -> new AtomicInteger(0)).incrementAndGet();
        return lock.readLock();
    }
    
    /**
     * 获取文件写锁
     */
    public ReentrantReadWriteLock.WriteLock acquireWriteLock(String filePath) {
        ReentrantReadWriteLock lock = fileLocks.computeIfAbsent(
            filePath, 
            k -> new ReentrantReadWriteLock()
        );
        lock.writeLock().lock();
        return lock.writeLock();
    }
    
    /**
     * 释放文件锁
     */
    public void releaseLock(String filePath) {
        AtomicInteger refCount = fileRefCounts.get(filePath);
        if (refCount != null) {
            int count = refCount.decrementAndGet();
            if (count <= 0) {
                fileLocks.remove(filePath);
                fileRefCounts.remove(filePath);
            }
        }
    }
    
    /**
     * 创建线程安全的读取器
     */
    public MDF4Reader createReader() {
        ensureInitialized();
        return new MDF4Reader(this);
    }
    
    /**
     * 创建线程安全的写入器
     */
    public MDF4Writer createWriter() {
        ensureInitialized();
        return new MDF4Writer(this);
    }
    
    /**
     * 创建流式读取器
     */
    public MDF4StreamReader createStreamReader(String filePath, List<String> signalNames) {
        ensureInitialized();
        return streamManager.createStreamReader(filePath, signalNames);
    }
    
    /**
     * 获取连接池
     */
    MDF4ConnectionPool getConnectionPool() {
        return connectionPool;
    }
    
    /**
     * 关闭服务
     */
    public void shutdown() {
        synchronized (LOCK) {
            if (!initialized) return;
            
            // 关闭流管理器
            if (streamManager != null) {
                streamManager.shutdown();
            }
            
            // 关闭连接池
            if (connectionPool != null) {
                connectionPool.shutdown();
            }
            
            initialized = false;
        }
    }
    
    private void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("MDF4ServiceManager: Shutdown hook triggered");
            shutdown();
        }));
    }
    
    private void ensureInitialized() {
        if (!initialized) {
            throw new IllegalStateException("MDF4ServiceManager not initialized. Call initialize() first.");
        }
    }
}
```

#### 3.1.3 线程安全的读取器

```java
/**
 * MDF4读取器 - 线程安全
 */
public class MDF4Reader implements AutoCloseable {
    private final MDF4ServiceManager manager;
    private final List<String> openedFiles = new CopyOnWriteArrayList<>();
    
    public MDF4Reader(MDF4ServiceManager manager) {
        this.manager = manager;
    }
    
    /**
     * 打开文件（线程安全，支持并发读）
     */
    public String open(String filePath) throws MDF4Exception {
        // 获取读锁
        manager.acquireReadLock(filePath);
        
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("OPEN_READ", 
                Map.of("file_path", filePath)
            );
            
            MDF4Response response = conn.execute(command);
            
            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to open file: " + response.getMessage());
            }
            
            String fileId = response.getFileId();
            conn.registerOpenFile(fileId, filePath);
            openedFiles.add(filePath);
            
            return fileId;
            
        } catch (Exception e) {
            manager.releaseLock(filePath);
            throw new MDF4Exception("Failed to open file: " + filePath, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 读取信号（支持并发）
     */
    public SignalData readSignal(String fileId, String signalName) throws MDF4Exception {
        return readSignal(fileId, signalName, null, null);
    }
    
    /**
     * 读取信号（带时间范围）
     */
    public SignalData readSignal(String fileId, String signalName, 
                                  Double startTime, Double endTime) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            Map<String, Object> params = new HashMap<>();
            params.put("file_id", fileId);
            params.put("signal_name", signalName);
            if (startTime != null) params.put("start_time", startTime);
            if (endTime != null) params.put("end_time", endTime);
            
            MDF4Command command = new MDF4Command("READ_SIGNAL", params);
            MDF4Response response = conn.execute(command);
            
            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to read signal: " + response.getMessage());
            }
            
            return decodeSignalData(response);
            
        } catch (Exception e) {
            throw new MDF4Exception("Failed to read signal: " + signalName, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 批量读取信号（更高效）
     */
    public Map<String, SignalData> readSignals(String fileId, List<String> signalNames) 
            throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("READ_SIGNALS_BATCH",
                Map.of("file_id", fileId, "signal_names", signalNames)
            );
            
            MDF4Response response = conn.execute(command);
            
            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to read signals: " + response.getMessage());
            }
            
            return decodeBatchSignalData(response);
            
        } catch (Exception e) {
            throw new MDF4Exception("Failed to read signals batch", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 流式读取信号（大数据量）
     */
    public void readSignalStream(String fileId, String signalName, 
                                  SignalDataConsumer consumer) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            // 先获取信号总信息
            MDF4Command infoCmd = new MDF4Command("GET_SIGNAL_INFO",
                Map.of("file_id", fileId, "signal_name", signalName)
            );
            MDF4Response infoResponse = conn.execute(infoCmd);
            long totalSamples = infoResponse.getSampleCount();
            
            // 分块读取
            int chunkSize = 10000;
            for (long offset = 0; offset < totalSamples; offset += chunkSize) {
                MDF4Command readCmd = new MDF4Command("READ_SIGNAL_CHUNK",
                    Map.of(
                        "file_id", fileId,
                        "signal_name", signalName,
                        "offset", offset,
                        "limit", chunkSize
                    )
                );
                
                MDF4Response response = conn.execute(readCmd);
                SignalData chunk = decodeSignalData(response);
                
                // 回调处理数据块
                boolean continueReading = consumer.consume(chunk, offset, totalSamples);
                if (!continueReading) {
                    break;
                }
            }
            
        } catch (Exception e) {
            throw new MDF4Exception("Failed to stream signal: " + signalName, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 关闭文件
     */
    public void close(String fileId) {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("CLOSE",
                Map.of("file_id", fileId)
            );
            
            conn.execute(command);
            conn.unregisterOpenFile(fileId);
            
        } catch (Exception e) {
            // 忽略关闭错误
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
            // 释放文件锁
            openedFiles.removeIf(path -> {
                manager.releaseLock(path);
                return true;
            });
        }
    }
    
    @Override
    public void close() {
        // 关闭所有打开的文件
        for (String filePath : openedFiles) {
            manager.releaseLock(filePath);
        }
        openedFiles.clear();
    }
    
    // 解码方法...
    private SignalData decodeSignalData(MDF4Response response) {
        // 实现解码逻辑
        return new SignalData();
    }
    
    private Map<String, SignalData> decodeBatchSignalData(MDF4Response response) {
        // 实现批量解码逻辑
        return new HashMap<>();
    }
}

/**
 * 信号数据消费者接口（用于流式读取）
 */
public interface SignalDataConsumer {
    /**
     * 消费数据块
     * @param chunk 当前数据块
     * @param offset 当前偏移量
     * @param total 总样本数
     * @return 是否继续读取
     */
    boolean consume(SignalData chunk, long offset, long total);
}
```

#### 3.1.4 线程安全的写入器

```java
/**
 * MDF4写入器 - 线程安全（独占写）
 */
public class MDF4Writer implements AutoCloseable {
    private final MDF4ServiceManager manager;
    private final List<String> openedFiles = new CopyOnWriteArrayList<>();
    
    public MDF4Writer(MDF4ServiceManager manager) {
        this.manager = manager;
    }
    
    /**
     * 创建文件（独占写锁）
     */
    public String create(String filePath, String version) throws MDF4Exception {
        // 获取写锁（独占）
        manager.acquireWriteLock(filePath);
        
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("OPEN_WRITE",
                Map.of("file_path", filePath, "version", version)
            );
            
            MDF4Response response = conn.execute(command);
            
            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to create file: " + response.getMessage());
            }
            
            String fileId = response.getFileId();
            conn.registerOpenFile(fileId, filePath);
            openedFiles.add(filePath);
            
            return fileId;
            
        } catch (Exception e) {
            manager.releaseLock(filePath);
            throw new MDF4Exception("Failed to create file: " + filePath, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 追加信号（需要持有写锁）
     */
    public void appendSignal(String fileId, String name, 
                             double[] timestamps, Object[] samples, 
                             SignalConfig config) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            // 大数据量分块传输
            int batchSize = 5000;
            for (int i = 0; i < timestamps.length; i += batchSize) {
                int end = Math.min(i + batchSize, timestamps.length);
                
                Map<String, Object> params = new HashMap<>();
                params.put("file_id", fileId);
                params.put("name", name);
                params.put("timestamps", encodeArray(Arrays.copyOfRange(timestamps, i, end)));
                params.put("samples", encodeArray(Arrays.copyOfRange(samples, i, end)));
                params.put("config", config);
                params.put("is_last", end >= timestamps.length);
                
                MDF4Command command = new MDF4Command("APPEND_SIGNAL_CHUNK", params);
                MDF4Response response = conn.execute(command);
                
                if (!"OK".equals(response.getStatus())) {
                    throw new MDF4Exception("Failed to append signal: " + response.getMessage());
                }
            }
            
        } catch (Exception e) {
            throw new MDF4Exception("Failed to append signal: " + name, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 保存文件
     */
    public void save(String fileId) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("SAVE",
                Map.of("file_id", fileId)
            );
            
            MDF4Response response = conn.execute(command);
            
            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to save file: " + response.getMessage());
            }
            
        } catch (Exception e) {
            throw new MDF4Exception("Failed to save file", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }
    
    /**
     * 关闭文件（释放写锁）
     */
    public void close(String fileId) {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();
            
            MDF4Command command = new MDF4Command("CLOSE",
                Map.of("file_id", fileId)
            );
            
            conn.execute(command);
            conn.unregisterOpenFile(fileId);
            
        } catch (Exception e) {
            // 忽略关闭错误
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
            // 释放写锁
            openedFiles.removeIf(path -> {
                manager.releaseLock(path);
                return true;
            });
        }
    }
    
    @Override
    public void close() {
        for (String filePath : openedFiles) {
            manager.releaseLock(filePath);
        }
        openedFiles.clear();
    }
    
    private String encodeArray(Object array) {
        // 实现编码逻辑
        return "";
    }
}
```

### 3.2 实时流式读取设计

```java
/**
 * MDF4流管理器 - 支持实时监控和流式读取
 */
public class MDF4StreamManager {
    private final MDF4ServiceManager serviceManager;
    private final ExecutorService executor;
    private final Map<String, StreamSession> sessions = new ConcurrentHashMap<>();
    private final EventBus eventBus;
    
    public MDF4StreamManager(MDF4ServiceManager serviceManager) {
        this.serviceManager = serviceManager;
        this.executor = Executors.newCachedThreadPool();
        this.eventBus = new EventBus();
    }
    
    /**
     * 创建流式读取器
     */
    public MDF4StreamReader createStreamReader(String filePath, List<String> signalNames) {
        String sessionId = UUID.randomUUID().toString();
        StreamSession session = new StreamSession(sessionId, filePath, signalNames);
        sessions.put(sessionId, session);
        return new MDF4StreamReader(session, eventBus);
    }
    
    /**
     * 监控文件变化（实时追加检测）
     */
    public void monitorFile(String filePath, FileChangeListener listener) {
        executor.submit(() -> {
            try {
                Path path = Paths.get(filePath);
                WatchService watchService = FileSystems.getDefault().newWatchService();
                path.getParent().register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
                
                long lastSize = Files.size(path);
                
                while (true) {
                    WatchKey key = watchService.poll(1, TimeUnit.SECONDS);
                    if (key != null) {
                        for (WatchEvent<?> event : key.pollEvents()) {
                            Path changed = (Path) event.context();
                            if (changed.endsWith(path.getFileName())) {
                                long newSize = Files.size(path);
                                if (newSize > lastSize) {
                                    listener.onFileAppended(filePath, lastSize, newSize);
                                    lastSize = newSize;
                                }
                            }
                        }
                        key.reset();
                    }
                }
            } catch (Exception e) {
                listener.onError(filePath, e);
            }
        });
    }
    
    /**
     * 发布流数据事件
     */
    public void publishStreamData(String sessionId, SignalData data) {
        eventBus.publish(new StreamDataEvent(sessionId, data));
    }
    
    public void shutdown() {
        executor.shutdown();
        for (StreamSession session : sessions.values()) {
            session.close();
        }
        sessions.clear();
    }
}

/**
 * MDF4流式读取器
 */
public class MDF4StreamReader implements AutoCloseable {
    private final StreamSession session;
    private final EventBus eventBus;
    private final List<StreamDataListener> listeners = new CopyOnWriteArrayList<>();
    private volatile boolean running = false;
    private ExecutorService executor;
    
    public MDF4StreamReader(StreamSession session, EventBus eventBus) {
        this.session = session;
        this.eventBus = eventBus;
    }
    
    /**
     * 添加数据监听器
     */
    public void addListener(StreamDataListener listener) {
        listeners.add(listener);
    }
    
    /**
     * 开始流式读取
     */
    public void start() {
        if (running) return;
        running = true;
        
        executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            MDF4Reader reader = serviceManager.createReader();
            
            try {
                String fileId = reader.open(session.getFilePath());
                long lastOffset = 0;
                
                while (running) {
                    for (String signalName : session.getSignalNames()) {
                        // 增量读取新数据
                        SignalData data = reader.readSignal(
                            fileId, signalName, (double) lastOffset, null
                        );
                        
                        if (data.getSamples().length > 0) {
                            // 通知所有监听器
                            for (StreamDataListener listener : listeners) {
                                listener.onDataReceived(signalName, data);
                            }
                            lastOffset += data.getSamples().length;
                        }
                    }
                    
                    // 等待一段时间再检查
                    Thread.sleep(100);
                }
                
            } catch (Exception e) {
                for (StreamDataListener listener : listeners) {
                    listener.onError(e);
                }
            } finally {
                reader.close();
            }
        });
    }
    
    /**
     * 停止流式读取
     */
    public void stop() {
        running = false;
        if (executor != null) {
            executor.shutdown();
        }
    }
    
    @Override
    public void close() {
        stop();
        listeners.clear();
    }
}

/**
 * 流数据监听器接口
 */
public interface StreamDataListener {
    void onDataReceived(String signalName, SignalData data);
    void onError(Exception e);
}

/**
 * 流会话
 */
public class StreamSession {
    private final String sessionId;
    private final String filePath;
    private final List<String> signalNames;
    
    public StreamSession(String sessionId, String filePath, List<String> signalNames) {
        this.sessionId = sessionId;
        this.filePath = filePath;
        this.signalNames = signalNames;
    }
    
    // Getters...
}
```

### 3.3 Python端 - 支持并发的服务进程

```python
# mdf4_service/server.py

import socket
import threading
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from .handler import CommandHandler

class MDF4SocketServer:
    """支持并发的MDF4 Socket服务器"""
    
    def __init__(self, host='127.0.0.1', port=0, max_workers=10):
        self.host = host
        self.port = port
        self.max_workers = max_workers
        self.server_socket = None
        self.running = False
        self.handler = CommandHandler()
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.client_locks = {}  # file_id -> threading.Lock()
        
    def start(self):
        """启动服务器"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        
        actual_port = self.server_socket.getsockname()[1]
        print(f"PORT:{actual_port}", flush=True)
        
        self.server_socket.listen(20)
        self.running = True
        
        logging.info(f"MDF4 Server started on {self.host}:{actual_port}")
        
        # 启动心跳检测
        heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                # 使用线程池处理客户端
                self.executor.submit(self._handle_client, client_socket, address)
            except Exception as e:
                if self.running:
                    logging.error(f"Server error: {e}")
                    
    def _handle_client(self, client_socket, address):
        """处理客户端连接"""
        logging.info(f"Client connected: {address}")
        try:
            while self.running:
                # 接收数据长度
                length_bytes = self._recv_all(client_socket, 4)
                if not length_bytes:
                    break
                
                data_length = int.from_bytes(length_bytes, 'big')
                
                # 接收完整数据
                data = self._recv_all(client_socket, data_length)
                if not data:
                    break
                
                # 解析命令
                command = json.loads(data.decode('utf-8'))
                
                # 处理命令（线程安全）
                response = self._handle_command_safe(command)
                
                # 发送响应
                response_bytes = json.dumps(response).encode('utf-8')
                client_socket.sendall(len(response_bytes).to_bytes(4, 'big'))
                client_socket.sendall(response_bytes)
                
        except Exception as e:
            logging.error(f"Client handler error: {e}")
        finally:
            client_socket.close()
            logging.info(f"Client disconnected: {address}")
    
    def _handle_command_safe(self, command):
        """线程安全地处理命令"""
        cmd_type = command.get('type')
        params = command.get('params', {})
        file_id = params.get('file_id')
        
        # 对于写操作，获取文件锁
        if cmd_type in ['OPEN_WRITE', 'APPEND_SIGNAL', 'APPEND_SIGNAL_CHUNK', 'SAVE']:
            if file_id:
                lock = self.client_locks.setdefault(file_id, threading.Lock())
                with lock:
                    return self.handler.handle(command)
        
        # 读操作不需要锁（asammdf读是线程安全的）
        return self.handler.handle(command)
    
    def _recv_all(self, sock, n):
        """接收指定字节数的数据"""
        data = b''
        while len(data) < n:
            chunk = sock.recv(min(8192, n - len(data)))
            if not chunk:
                return None
            data += chunk
        return data
    
    def _heartbeat_loop(self):
        """心跳检测循环"""
        import time
        import os
        import platform
        
        while self.running:
            if not self._check_parent_alive():
                logging.info("Parent process died, shutting down...")
                self.stop()
                break
            time.sleep(5)
    
    def _check_parent_alive(self):
        """检查父进程是否存活"""
        import os
        import platform
        
        if platform.system() == 'Windows':
            parent_pid = os.environ.get('MDF4_PARENT_PID')
            if parent_pid:
                try:
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(1, False, int(parent_pid))
                    if handle:
                        kernel32.CloseHandle(handle)
                        return True
                    return False
                except:
                    return False
            return True
        else:
            try:
                ppid = os.getppid()
                return ppid != 1
            except:
                return False
    
    def stop(self):
        """停止服务器"""
        self.running = False
        self.executor.shutdown(wait=False)
        if self.server_socket:
            self.server_socket.close()
```

---

## 4. 并发控制策略

### 4.1 读写锁策略

```
┌─────────────────────────────────────────────────────────────────┐
│                      读写锁策略                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   文件A: /data/file1.mf4                                        │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │  读锁 (共享)    │   写锁 (独占)                          │  │
│   │  ┌─────────┐   │   ┌─────────┐                          │  │
│   │  │Thread 1 │◄──┼───┤         │                          │  │
│   │  │  READ   │   │   │         │                          │  │
│   │  └─────────┘   │   │         │                          │  │
│   │  ┌─────────┐   │   │Thread 3 │                          │  │
│   │  │Thread 2 │◄──┼───┤  WRITE  │  ← 阻塞直到读锁释放       │  │
│   │  │  READ   │   │   │         │                          │  │
│   │  └─────────┘   │   │         │                          │  │
│   │                │   └─────────┘                          │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│   规则:                                                         │
│   1. 多个线程可同时获取读锁                                      │
│   2. 写锁独占，阻塞其他读写                                      │
│   3. 同一线程内读锁可重入                                        │
│   4. 锁按文件路径管理                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 连接池配置

```java
public class PoolConfig {
    // 最大连接数（建议：CPU核心数 * 2）
    private int maxConnections = Runtime.getRuntime().availableProcessors() * 2;
    
    // 最大空闲连接数
    private int maxIdle = maxConnections;
    
    // 最小空闲连接数
    private int minIdle = 2;
    
    // 获取连接最大等待时间（毫秒）
    private long maxWaitMillis = 30000;
    
    // 连接空闲超时时间（毫秒）
    private long idleTimeoutMillis = 60000;
    
    // 连接最大生命周期（毫秒）
    private long maxLifetimeMillis = 300000;
    
    // Getters and Setters...
}
```

---

## 5. 使用示例

### 5.1 多线程并发读取

```java
import com.example.mdf4.*;
import java.util.*;
import java.util.concurrent.*;

public class ConcurrentReadExample {
    public static void main(String[] args) throws Exception {
        // 初始化服务
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(10);
        MDF4ServiceManager.getInstance().initialize(config);
        
        // 多线程并发读取
        ExecutorService executor = Executors.newFixedThreadPool(5);
        List<Future<List<SignalData>>> futures = new ArrayList<>();
        
        String filePath = "/data/large_measurement.mf4";
        List<String> signals = Arrays.asList(
            "EngineSpeed", "EngineTorque", "ThrottlePosition", 
            "VehicleSpeed", "CoolantTemp"
        );
        
        // 每个信号一个线程读取
        for (String signalName : signals) {
            Future<List<SignalData>> future = executor.submit(() -> {
                try (MDF4Reader reader = MDF4ServiceManager.getInstance().createReader()) {
                    String fileId = reader.open(filePath);
                    SignalData data = reader.readSignal(fileId, signalName);
                    reader.close(fileId);
                    return Collections.singletonList(data);
                }
            });
            futures.add(future);
        }
        
        // 收集结果
        for (Future<List<SignalData>> future : futures) {
            List<SignalData> data = future.get();
            System.out.println("Read signal: " + data.get(0).getName());
        }
        
        executor.shutdown();
    }
}
```

### 5.2 实时流式读取

```java
import com.example.mdf4.*;

public class RealTimeStreamExample {
    public static void main(String[] args) throws Exception {
        // 初始化
        MDF4ServiceManager.getInstance().initialize(new PoolConfig());
        
        // 创建流式读取器
        List<String> signals = Arrays.asList("EngineSpeed", "VehicleSpeed");
        MDF4StreamReader streamReader = MDF4ServiceManager.getInstance()
            .createStreamReader("/data/realtime.mf4", signals);
        
        // 添加数据监听器
        streamReader.addListener(new StreamDataListener() {
            @Override
            public void onDataReceived(String signalName, SignalData data) {
                System.out.printf("[%s] %s: %d samples%n", 
                    new Date(), signalName, data.getSamples().length);
                
                // 实时处理数据
                processRealTimeData(signalName, data);
            }
            
            @Override
            public void onError(Exception e) {
                e.printStackTrace();
            }
        });
        
        // 开始流式读取
        streamReader.start();
        
        // 运行一段时间后停止
        Thread.sleep(60000);
        streamReader.stop();
    }
    
    private static void processRealTimeData(String signalName, SignalData data) {
        // 实时数据处理逻辑
    }
}
```

### 5.3 并发读写（生产-消费者模式）

```java
import com.example.mdf4.*;
import java.util.concurrent.*;

public class ProducerConsumerExample {
    public static void main(String[] args) throws Exception {
        MDF4ServiceManager.getInstance().initialize(new PoolConfig());
        
        String inputFile = "/data/input.mf4";
        String outputFile = "/data/output.mf4";
        
        // 生产者-消费者队列
        BlockingQueue<SignalData> queue = new LinkedBlockingQueue<>(100);
        
        // 生产者线程：读取数据
        Thread producer = new Thread(() -> {
            try (MDF4Reader reader = MDF4ServiceManager.getInstance().createReader()) {
                String fileId = reader.open(inputFile);
                
                // 流式读取并放入队列
                reader.readSignalStream(fileId, "EngineSpeed", (chunk, offset, total) -> {
                    try {
                        queue.put(chunk);
                        return true;
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return false;
                    }
                });
                
                reader.close(fileId);
            }
        });
        
        // 消费者线程：处理并写入数据
        Thread consumer = new Thread(() -> {
            try (MDF4Writer writer = MDF4ServiceManager.getInstance().createWriter()) {
                String fileId = writer.create(outputFile, "4.10");
                
                while (!Thread.interrupted()) {
                    SignalData data = queue.poll(1, TimeUnit.SECONDS);
                    if (data != null) {
                        // 处理数据
                        SignalData processed = processData(data);
                        
                        // 写入
                        writer.appendSignal(fileId, processed.getName(),
                            processed.getTimestamps(),
                            processed.getSamples(),
                            new SignalConfig());
                    }
                }
                
                writer.save(fileId);
            }
        });
        
        producer.start();
        consumer.start();
        
        producer.join();
        consumer.interrupt();
        consumer.join();
    }
    
    private static SignalData processData(SignalData data) {
        // 数据处理逻辑
        return data;
    }
}
```

---

## 6. 性能优化

### 6.1 并发性能优化

| 优化策略 | 说明 |
|----------|------|
| 连接池 | 复用Python进程连接，避免频繁创建销毁 |
| 读写锁分离 | 读操作并行，写操作串行 |
| 批量操作 | 合并多个小操作为一个批量操作 |
| 分块传输 | 大数据分块传输，减少内存占用 |
| 异步IO | 使用NIO提高并发处理能力 |

### 6.2 实时性能优化

| 优化策略 | 说明 |
|----------|------|
| 环形缓冲区 | 固定大小的循环缓冲区，避免GC |
| 增量读取 | 只读取新增数据，减少IO |
| 事件驱动 | 文件变化时触发读取，而非轮询 |
| 背压控制 | 消费者慢时自动降速，避免OOM |

---

## 7. 监控与诊断

```java
/**
 * MDF4服务监控
 */
public class MDF4Monitor {
    
    public static void printStatus() {
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        MDF4ConnectionPool pool = manager.getConnectionPool();
        
        System.out.println("=== MDF4 Service Status ===");
        System.out.println("Active Connections: " + pool.getActiveCount());
        System.out.println("Idle Connections: " + pool.getIdleCount());
        System.out.println("===========================");
    }
}
```

---

## 8. 总结

### 8.1 方案优势

| 优势 | 说明 |
|------|------|
| **高并发** | 连接池 + 读写锁，支持多线程同时读写 |
| **实时性** | 流式读取 + 文件监控，支持实时数据流 |
| **线程安全** | 完善的锁机制，保证数据一致性 |
| **高性能** | 连接复用、批量操作、分块传输 |
| **易用性** | 简洁的API，支持try-with-resources |
| **可扩展** | 模块化设计，易于扩展新功能 |

### 8.2 注意事项

1. **Python环境**: 需要预先安装Python 3.8+和asammdf库
2. **连接池大小**: 根据实际并发需求调整
3. **文件锁**: 写操作会阻塞同一文件的其他读写
4. **资源释放**: 建议使用try-with-resources确保资源释放
5. **实时精度**: 文件监控精度取决于操作系统（通常1秒）

### 8.3 后续优化方向

1. 支持多进程Python服务，进一步提高并发
2. 添加缓存层，热点数据内存缓存
3. 支持分布式部署，远程Python服务
4. 添加Metrics监控，集成Prometheus
