# MDF4工具配置指南

## Python资源文件位置配置

当Python资源文件的位置发生修改时，需要在以下位置进行配置更新：

---

## 1. Java端配置（主要修改位置）

### 1.1 代码中的默认配置

**文件**: `java/src/main/java/com/example/mdf4/MDF4ServiceManager.java`

```java
// ==================== Python资源文件位置配置（修改点1） ====================
/**
 * 默认Python解释器路径
 * <p>修改此常量可改变默认Python解释器位置</p>
 */
private static final String DEFAULT_PYTHON_PATH = "python";

/**
 * 默认Python模块名称
 * <p>修改此常量可改变默认Python模块名称</p>
 */
private static final String DEFAULT_PYTHON_MODULE = "mdf4_service";
// ========================================================================
```

**修改说明**:
- `DEFAULT_PYTHON_PATH`: Python解释器的路径
  - Windows: `C:\Python39\python.exe` 或 `python`
  - Linux/Mac: `/usr/bin/python3` 或 `python3`
- `DEFAULT_PYTHON_MODULE`: Python模块名称
  - 如果Python包名改变，需要修改此处

### 1.2 环境变量配置（运行时覆盖）

可以在运行时通过环境变量覆盖默认配置：

```bash
# Linux/Mac
export MDF4_PYTHON_PATH=/usr/local/bin/python3.9
export MDF4_PYTHON_MODULE=mdf4_service

# Windows
set MDF4_PYTHON_PATH=C:\Python39\python.exe
set MDF4_PYTHON_MODULE=mdf4_service
```

### 1.3 代码中动态设置

```java
MDF4ServiceManager manager = MDF4ServiceManager.getInstance();

// 在initialize()之前设置
manager.setPythonPath("/usr/local/bin/python3.9");
manager.setPythonModule("mdf4_service");

manager.initialize();
```

---

## 2. Python端配置

### 2.1 Python模块名称

**文件**: `python/setup.py`

```python
setup(
    name="mdf4-service",  # 修改包名
    ...
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "mdf4-service=mdf4_service.__main__:main",  # 修改入口点
        ],
    },
)
```

### 2.2 Python模块目录结构

如果修改了Python模块的目录名称，需要同时修改：

1. **目录名**: `python/mdf4_service/` → `python/your_module_name/`
2. **setup.py中的包名**: 确保`find_packages()`能正确找到
3. **Java端的模块名**: 修改`DEFAULT_PYTHON_MODULE`

---

## 3. 配置文件方式（推荐）

### 3.1 创建配置文件

**文件**: `config/mdf4.properties`

```properties
# Python配置
mdf4.python.path=python
mdf4.python.module=mdf4_service

# 连接池配置
mdf4.pool.maxConnections=10
mdf4.pool.maxIdle=10
mdf4.pool.minIdle=2
mdf4.pool.maxWaitMillis=30000
```

### 3.2 在代码中读取配置

```java
Properties props = new Properties();
try (InputStream is = new FileInputStream("config/mdf4.properties")) {
    props.load(is);
}

MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
manager.setPythonPath(props.getProperty("mdf4.python.path", "python"));
manager.setPythonModule(props.getProperty("mdf4.python.module", "mdf4_service"));
manager.initialize();
```

---

## 4. 常见配置场景

### 场景1: Python安装在非标准位置

```java
// Windows
manager.setPythonPath("C:\\Python39\\python.exe");

// Linux
manager.setPythonPath("/opt/python3.9/bin/python3");

// Mac
manager.setPythonPath("/usr/local/bin/python3");
```

### 场景2: 使用虚拟环境

```java
// Windows
manager.setPythonPath("C:\\myproject\\venv\\Scripts\\python.exe");

// Linux/Mac
manager.setPythonPath("/home/user/myproject/venv/bin/python");
```

### 场景3: Python模块名称改变

```java
// 如果重命名了Python包
manager.setPythonModule("my_mdf4_service");
```

---

## 5. 配置优先级

配置优先级从高到低：

1. **代码中动态设置** (`setPythonPath()`, `setPythonModule()`)
2. **环境变量** (`MDF4_PYTHON_PATH`, `MDF4_PYTHON_MODULE`)
3. **代码中的默认配置** (`DEFAULT_PYTHON_PATH`, `DEFAULT_PYTHON_MODULE`)

---

## 6. 验证配置

### 6.1 验证Python环境

```java
MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
System.out.println("Python Path: " + manager.getPythonPath());
System.out.println("Python Module: " + manager.getPythonModule());
manager.initialize();  // 这会验证Python环境
```

### 6.2 验证Python模块安装

```bash
# 检查asammdf是否安装
python -c "import asammdf; print(asammdf.__version__)"

# 检查mdf4_service模块
python -m mdf4_service --help
```

---

## 7. 故障排除

### 问题1: "Python environment validation failed"

**原因**: Python路径不正确

**解决**:
```java
// 检查Python路径
manager.setPythonPath("python3");  // Linux/Mac
// 或
manager.setPythonPath("python");   // Windows
```

### 问题2: "asammdf is not installed"

**原因**: Python环境中没有安装asammdf

**解决**:
```bash
pip install asammdf>=7.0.0
```

### 问题3: "Failed to get Python service port"

**原因**: Python模块名称不正确或模块未安装

**解决**:
```bash
# 安装Python模块
cd python
pip install -e .

# 验证模块
python -m mdf4_service --help
```

---

## 8. 总结

| 配置项 | 代码位置 | 环境变量 | 动态设置 |
|--------|----------|----------|----------|
| Python路径 | `DEFAULT_PYTHON_PATH` | `MDF4_PYTHON_PATH` | `setPythonPath()` |
| Python模块 | `DEFAULT_PYTHON_MODULE` | `MDF4_PYTHON_MODULE` | `setPythonModule()` |

**推荐做法**:
1. 开发环境：使用环境变量或动态设置
2. 生产环境：使用配置文件
3. 打包部署：在启动脚本中设置环境变量
