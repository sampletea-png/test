package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 读取信号请求
 */
public class ReadSignalRequest {
    private final RequestType type = RequestType.READ_SIGNAL;
    private String fileId;
    private String signalName;
    private Double startTime;
    private Double endTime;

    public ReadSignalRequest() {
    }

    public ReadSignalRequest(String fileId, String signalName) {
        this.fileId = fileId;
        this.signalName = signalName;
    }

    public ReadSignalRequest(String fileId, String signalName, Double startTime, Double endTime) {
        this.fileId = fileId;
        this.signalName = signalName;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getSignalName() {
        return signalName;
    }

    public void setSignalName(String signalName) {
        this.signalName = signalName;
    }

    public Double getStartTime() {
        return startTime;
    }

    public void setStartTime(Double startTime) {
        this.startTime = startTime;
    }

    public Double getEndTime() {
        return endTime;
    }

    public void setEndTime(Double endTime) {
        this.endTime = endTime;
    }
}
