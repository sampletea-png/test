package com.example.mdf4.pool;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

/**
 * MDF4连接工厂
 * <p>
 * 用于创建和管理MDF4连接对象。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4ConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(MDF4ConnectionFactory.class);

    private final String pythonPath;
    private final String pythonModule;

    public MDF4ConnectionFactory(String pythonPath, String pythonModule) {
        this.pythonPath = pythonPath;
        this.pythonModule = pythonModule;
    }

    /**
     * 创建新连接
     *
     * @param connId 连接ID
     * @return MDF4连接
     * @throws IOException 如果创建失败
     */
    public MDF4Connection createConnection(String connId) throws IOException {
        int port = findAvailablePort();

        logger.info("Creating new connection {} on port {}", connId, port);

        // 启动Python进程
        ProcessBuilder pb = new ProcessBuilder(
                pythonPath, "-m", pythonModule,
                "--port", String.valueOf(port),
                "--parent-pid", String.valueOf(ProcessHandle.current().pid())
        );

        pb.redirectErrorStream(true);
        Process process = pb.start();

        // 等待Python服务启动并获取端口确认
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream())
        );

        String line;
        int actualPort = -1;
        long startTime = System.currentTimeMillis();

        while ((line = reader.readLine()) != null) {
            logger.debug("Python output: {}", line);

            if (line.startsWith("PORT:")) {
                actualPort = Integer.parseInt(line.substring(5));
                break;
            }

            if (line.startsWith("ERROR:")) {
                process.destroy();
                throw new RuntimeException("Python service failed to start: " + line);
            }

            if (System.currentTimeMillis() - startTime > 30000) {
                process.destroy();
                throw new RuntimeException("Python service startup timeout");
            }
        }

        if (actualPort == -1) {
            process.destroy();
            throw new RuntimeException("Failed to get Python service port");
        }

        // 等待服务就绪
        waitForServiceReady(actualPort);

        // 建立Socket连接
        Socket socket = new Socket("127.0.0.1", actualPort);
        socket.setSoTimeout(30000);
        socket.setKeepAlive(true);

        logger.info("Connection {} created successfully on port {}", connId, actualPort);

        return new MDF4Connection(connId, socket);
    }

    /**
     * 查找可用端口
     *
     * @return 可用端口号
     * @throws IOException 如果找不到可用端口
     */
    private int findAvailablePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }

    /**
     * 等待服务就绪
     *
     * @param port 端口号
     * @throws IOException 如果服务未就绪
     */
    private void waitForServiceReady(int port) throws IOException {
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 10000) {
            try {
                Socket testSocket = new Socket("127.0.0.1", port);
                testSocket.close();
                return;
            } catch (IOException e) {
                // 服务还未就绪，等待
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Interrupted while waiting for service", ie);
                }
            }
        }
        throw new IOException("Service failed to become ready within timeout");
    }
}
