package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

import java.util.List;

/**
 * 批量读取信号请求
 */
public class ReadSignalsBatchRequest {
    private final RequestType type = RequestType.READ_SIGNALS_BATCH;
    private String fileId;
    private List<String> signalNames;

    public ReadSignalsBatchRequest() {
    }

    public ReadSignalsBatchRequest(String fileId, List<String> signalNames) {
        this.fileId = fileId;
        this.signalNames = signalNames;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public List<String> getSignalNames() {
        return signalNames;
    }

    public void setSignalNames(List<String> signalNames) {
        this.signalNames = signalNames;
    }
}
