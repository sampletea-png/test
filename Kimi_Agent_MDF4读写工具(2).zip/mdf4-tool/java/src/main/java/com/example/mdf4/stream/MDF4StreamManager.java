package com.example.mdf4.stream;

import com.example.mdf4.MDF4ServiceManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * MDF4流管理器
 * <p>
 * 支持实时监控和流式数据读取。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4StreamManager {
    private static final Logger logger = LoggerFactory.getLogger(MDF4StreamManager.class);

    private final MDF4ServiceManager serviceManager;
    private final ExecutorService executor;
    private final Map<String, StreamSession> sessions;
    private final EventBus eventBus;
    private volatile boolean running = false;

    public MDF4StreamManager(MDF4ServiceManager serviceManager) {
        this.serviceManager = serviceManager;
        this.executor = Executors.newCachedThreadPool();
        this.sessions = new ConcurrentHashMap<>();
        this.eventBus = new EventBus();
        this.running = true;
    }

    /**
     * 创建流式读取器
     *
     * @param filePath    MDF4文件路径
     * @param signalNames 信号名称列表
     * @return MDF4StreamReader实例
     */
    public MDF4StreamReader createStreamReader(String filePath, List<String> signalNames) {
        String sessionId = generateSessionId();
        StreamSession session = new StreamSession(sessionId, filePath, signalNames);
        sessions.put(sessionId, session);
        return new MDF4StreamReader(session, eventBus, serviceManager);
    }

    /**
     * 监控文件变化
     *
     * @param filePath MDF4文件路径
     * @param listener 文件变化监听器
     */
    public void monitorFile(String filePath, FileChangeListener listener) {
        executor.submit(() -> {
            try {
                Path path = Paths.get(filePath);
                Path parentDir = path.getParent();

                if (parentDir == null) {
                    listener.onError(filePath, new IllegalArgumentException("Invalid file path"));
                    return;
                }

                WatchService watchService = FileSystems.getDefault().newWatchService();
                parentDir.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

                long lastSize = Files.exists(path) ? Files.size(path) : 0;

                logger.info("Started monitoring file: {}", filePath);

                while (running) {
                    WatchKey key = watchService.poll(1, TimeUnit.SECONDS);
                    if (key != null) {
                        for (WatchEvent<?> event : key.pollEvents()) {
                            Path changed = (Path) event.context();
                            if (changed.endsWith(path.getFileName())) {
                                if (Files.exists(path)) {
                                    long newSize = Files.size(path);
                                    if (newSize > lastSize) {
                                        listener.onFileAppended(filePath, lastSize, newSize);
                                        lastSize = newSize;
                                    }
                                }
                            }
                        }
                        key.reset();
                    }
                }

                watchService.close();

            } catch (Exception e) {
                listener.onError(filePath, e);
            }
        });
    }

    /**
     * 发布流数据事件
     *
     * @param sessionId 会话ID
     * @param data      信号数据
     */
    public void publishStreamData(String sessionId, com.example.mdf4.model.SignalData data) {
        eventBus.publish(new StreamDataEvent(sessionId, data));
    }

    /**
     * 关闭会话
     *
     * @param sessionId 会话ID
     */
    public void closeSession(String sessionId) {
        StreamSession session = sessions.remove(sessionId);
        if (session != null) {
            session.close();
        }
    }

    /**
     * 关闭流管理器
     */
    public void shutdown() {
        running = false;
        executor.shutdown();

        for (StreamSession session : sessions.values()) {
            session.close();
        }
        sessions.clear();

        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        logger.info("MDF4StreamManager shut down");
    }

    private String generateSessionId() {
        return "session-" + System.currentTimeMillis() + "-" +
                ThreadLocalRandom.current().nextInt(10000);
    }

    /**
     * 文件变化监听器接口
     */
    public interface FileChangeListener {
        void onFileAppended(String filePath, long oldSize, long newSize);
        void onError(String filePath, Exception e);
    }

    /**
     * 流数据事件
     */
    public static class StreamDataEvent {
        private final String sessionId;
        private final com.example.mdf4.model.SignalData data;

        public StreamDataEvent(String sessionId, com.example.mdf4.model.SignalData data) {
            this.sessionId = sessionId;
            this.data = data;
        }

        public String getSessionId() {
            return sessionId;
        }

        public com.example.mdf4.model.SignalData getData() {
            return data;
        }
    }

    /**
     * 事件总线
     */
    public static class EventBus {
        private final Map<String, List<StreamDataListener>> listeners = new ConcurrentHashMap<>();

        public void subscribe(String sessionId, StreamDataListener listener) {
            listeners.computeIfAbsent(sessionId, k -> new CopyOnWriteArrayList<>()).add(listener);
        }

        public void unsubscribe(String sessionId, StreamDataListener listener) {
            List<StreamDataListener> list = listeners.get(sessionId);
            if (list != null) {
                list.remove(listener);
            }
        }

        public void publish(StreamDataEvent event) {
            List<StreamDataListener> list = listeners.get(event.getSessionId());
            if (list != null) {
                for (StreamDataListener listener : list) {
                    try {
                        listener.onDataReceived(event.getData().getName(), event.getData());
                    } catch (Exception e) {
                        logger.error("Error in stream data listener", e);
                    }
                }
            }
        }
    }

    /**
     * 流会话
     */
    public static class StreamSession {
        private final String sessionId;
        private final String filePath;
        private final List<String> signalNames;
        private volatile boolean active = true;

        public StreamSession(String sessionId, String filePath, List<String> signalNames) {
            this.sessionId = sessionId;
            this.filePath = filePath;
            this.signalNames = signalNames;
        }

        public String getSessionId() {
            return sessionId;
        }

        public String getFilePath() {
            return filePath;
        }

        public List<String> getSignalNames() {
            return signalNames;
        }

        public boolean isActive() {
            return active;
        }

        public void close() {
            active = false;
        }
    }
}
