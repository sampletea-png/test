package com.example.mdf4;

import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.util.List;

/**
 * MDF4工具主类
 * <p>
 * 用于测试和演示MDF4工具的基本功能。
 * </p>
 */
public class MDF4ToolMain {

    public static void main(String[] args) {
        System.out.println("=================================");
        System.out.println("      MDF4 Tool v1.0.0");
        System.out.println("=================================");

        // 打印配置信息
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        System.out.println("Python Path: " + manager.getPythonPath());
        System.out.println("Python Module: " + manager.getPythonModule());

        // 初始化服务
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(5);

        try {
            manager.initialize(config);
            System.out.println("Service initialized successfully!");
            System.out.println("Active connections: " + manager.getConnectionPool().getActiveCount());
            System.out.println("Idle connections: " + manager.getConnectionPool().getIdleCount());
        } catch (Exception e) {
            System.err.println("Failed to initialize service: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }

        // 打印使用帮助
        System.out.println("\nUsage:");
        System.out.println("  MDF4Reader reader = manager.createReader();");
        System.out.println("  MDF4Writer writer = manager.createWriter();");
        System.out.println("  MDF4StreamReader stream = manager.createStreamReader(filePath, signals);");

        // 关闭服务
        manager.shutdown();
        System.out.println("\nService shut down.");
    }
}
