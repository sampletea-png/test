package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 心跳检测请求
 */
public class PingRequest {
    private final RequestType type = RequestType.PING;

    public RequestType getType() {
        return type;
    }
}
