package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 打开文件读取请求
 */
public class OpenReadRequest {
    private final RequestType type = RequestType.OPEN_READ;
    private String filePath;

    public OpenReadRequest() {
    }

    public OpenReadRequest(String filePath) {
        this.filePath = filePath;
    }

    public RequestType getType() {
        return type;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
