package com.example.mdf4;

import com.example.mdf4.exception.MDF4Exception;
import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.pool.MDF4Connection;
import com.example.mdf4.protocol.request.*;
import com.example.mdf4.protocol.response.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MDF4写入器 - 线程安全（独占写）
 * <p>
 * 用于创建和写入MDF4文件。支持：
 * - 创建新文件
 * - 追加信号数据
 * - 批量写入
 * - 分块传输（大数据量）
 * </p>
 *
 * <p><b>使用示例：</b></p>
 * <pre>
 * try (MDF4Writer writer = MDF4ServiceManager.getInstance().createWriter()) {
 *     String fileId = writer.create("/output/new.mf4", "4.10");
 *     writer.appendSignal(fileId, "Voltage", timestamps, samples, config);
 *     writer.save(fileId);
 *     writer.close(fileId);
 * }
 * </pre>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Writer implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(MDF4Writer.class);

    // 分块大小（每次传输的样本数）
    private static final int DEFAULT_CHUNK_SIZE = 5000;

    private final MDF4ServiceManager manager;
    private final List<String> openedFiles = new CopyOnWriteArrayList<>();
    private final Map<String, ReentrantReadWriteLock.WriteLock> heldLocks = new HashMap<>();

    public MDF4Writer(MDF4ServiceManager manager) {
        this.manager = manager;
    }

    /**
     * 创建新文件用于写入
     * <p>
     * 此方法会获取文件的写锁（独占），阻塞其他线程对该文件的读写操作。
     * </p>
     *
     * @param filePath MDF4文件路径
     * @param version  MDF4版本（如 "4.10"）
     * @return 文件ID，用于后续操作
     * @throws MDF4Exception 如果创建失败
     */
    public String create(String filePath, String version) throws MDF4Exception {
        // 获取写锁（独占）
        ReentrantReadWriteLock.WriteLock lock = manager.acquireWriteLock(filePath);

        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            OpenWriteRequest request = new OpenWriteRequest(filePath, version);
            OpenWriteResponse response = conn.openWrite(request);

            if (!response.isSuccess()) {
                throw new MDF4Exception("Failed to create file: " + response.getMessage());
            }

            String fileId = response.getFileId();
            conn.registerOpenFile(fileId, filePath);
            openedFiles.add(filePath);
            heldLocks.put(filePath, lock);

            logger.debug("Created file for writing: {} (fileId={})", filePath, fileId);
            return fileId;

        } catch (Exception e) {
            manager.releaseLock(filePath);
            throw new MDF4Exception("Failed to create file: " + filePath, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 追加信号数据
     *
     * @param fileId     文件ID
     * @param name       信号名称
     * @param timestamps 时间戳数组
     * @param samples    采样值数组
     * @param config     信号配置
     * @throws MDF4Exception 如果追加失败
     */
    public void appendSignal(String fileId, String name,
                             double[] timestamps, double[] samples,
                             SignalConfig config) throws MDF4Exception {
        appendSignal(fileId, name, timestamps, samples, config, DEFAULT_CHUNK_SIZE);
    }

    /**
     * 追加信号数据（指定分块大小）
     *
     * @param fileId     文件ID
     * @param name       信号名称
     * @param timestamps 时间戳数组
     * @param samples    采样值数组
     * @param config     信号配置
     * @param chunkSize  分块大小
     * @throws MDF4Exception 如果追加失败
     */
    public void appendSignal(String fileId, String name,
                             double[] timestamps, double[] samples,
                             SignalConfig config, int chunkSize) throws MDF4Exception {
        if (timestamps.length != samples.length) {
            throw new IllegalArgumentException("timestamps and samples must have the same length");
        }

        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            // 分块传输大数据
            int totalSamples = timestamps.length;
            for (int i = 0; i < totalSamples; i += chunkSize) {
                int end = Math.min(i + chunkSize, totalSamples);
                boolean isLast = (end >= totalSamples);

                AppendSignalChunkRequest request = new AppendSignalChunkRequest();
                request.setFileId(fileId);
                request.setName(name);
                request.setTimestampsBase64(encodeArray(Arrays.copyOfRange(timestamps, i, end)));
                request.setSamplesBase64(encodeArray(Arrays.copyOfRange(samples, i, end)));
                request.setConfig(config);
                request.setLast(isLast);

                SimpleResponse response = conn.appendSignalChunk(request);

                if (!response.isSuccess()) {
                    throw new MDF4Exception("Failed to append signal chunk: " + response.getMessage());
                }

                logger.debug("Appended signal chunk {}/{} for {}", end, totalSamples, name);
            }

            logger.debug("Appended signal: {} ({} samples)", name, totalSamples);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to append signal: " + name, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 批量追加信号
     *
     * @param fileId  文件ID
     * @param signals 信号列表
     * @throws MDF4Exception 如果追加失败
     */
    public void appendSignals(String fileId, List<Signal> signals) throws MDF4Exception {
        for (Signal signal : signals) {
            appendSignal(fileId, signal.getName(), signal.getTimestamps(),
                    signal.getSamples(), signal.getConfig());
        }
    }

    /**
     * 设置压缩级别
     *
     * @param fileId 文件ID
     * @param level  压缩级别（0-9，0表示不压缩）
     * @throws MDF4Exception 如果设置失败
     */
    public void setCompression(String fileId, int level) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            SetCompressionRequest request = new SetCompressionRequest(fileId, level);
            SimpleResponse response = conn.setCompression(request);

            if (!response.isSuccess()) {
                throw new MDF4Exception("Failed to set compression: " + response.getMessage());
            }

            logger.debug("Set compression level {} for file: {}", level, fileId);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to set compression", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 保存文件
     *
     * @param fileId 文件ID
     * @throws MDF4Exception 如果保存失败
     */
    public void save(String fileId) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            SaveRequest request = new SaveRequest(fileId);
            SimpleResponse response = conn.save(request);

            if (!response.isSuccess()) {
                throw new MDF4Exception("Failed to save file: " + response.getMessage());
            }

            logger.debug("Saved file: {}", fileId);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to save file", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 关闭文件（释放写锁）
     *
     * @param fileId 文件ID
     */
    public void close(String fileId) {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            CloseRequest request = new CloseRequest(fileId);
            conn.close(request);
            conn.unregisterOpenFile(fileId);

            // 找到并释放对应的文件锁
            String filePathToRelease = null;
            for (String path : openedFiles) {
                if (heldLocks.containsKey(path)) {
                    filePathToRelease = path;
                    break;
                }
            }

            if (filePathToRelease != null) {
                heldLocks.remove(filePathToRelease);
                manager.releaseLock(filePathToRelease);
                openedFiles.remove(filePathToRelease);
            }

            logger.debug("Closed file: {}", fileId);

        } catch (Exception e) {
            logger.warn("Error closing file: {}", fileId, e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    @Override
    public void close() {
        for (String filePath : new ArrayList<>(openedFiles)) {
            manager.releaseLock(filePath);
        }
        openedFiles.clear();
        heldLocks.clear();
    }

    /**
     * 编码数组为Base64字符串
     */
    private String encodeArray(double[] array) {
        ByteBuffer buffer = ByteBuffer.allocate(array.length * 8);
        for (double value : array) {
            buffer.putDouble(value);
        }
        return Base64.getEncoder().encodeToString(buffer.array());
    }

    /**
     * 信号数据类（用于批量追加）
     */
    public static class Signal {
        private String name;
        private double[] timestamps;
        private double[] samples;
        private SignalConfig config;

        public Signal(String name, double[] timestamps, double[] samples, SignalConfig config) {
            this.name = name;
            this.timestamps = timestamps;
            this.samples = samples;
            this.config = config;
        }

        // Getters
        public String getName() { return name; }
        public double[] getTimestamps() { return timestamps; }
        public double[] getSamples() { return samples; }
        public SignalConfig getConfig() { return config; }
    }
}
