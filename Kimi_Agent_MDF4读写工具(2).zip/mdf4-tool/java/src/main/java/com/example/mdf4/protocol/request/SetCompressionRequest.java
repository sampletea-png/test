package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 设置压缩级别请求
 */
public class SetCompressionRequest {
    private final RequestType type = RequestType.SET_COMPRESSION;
    private String fileId;
    private int level;

    public SetCompressionRequest() {
    }

    public SetCompressionRequest(String fileId, int level) {
        this.fileId = fileId;
        this.level = level;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
