package com.example.mdf4.protocol;

/**
 * 请求类型枚举
 */
public enum RequestType {
    OPEN_READ,
    OPEN_WRITE,
    GET_SIGNALS,
    GET_SIGNAL_INFO,
    READ_SIGNAL,
    READ_SIGNALS_BATCH,
    READ_SIGNAL_CHUNK,
    APPEND_SIGNAL_CHUNK,
    SET_COMPRESSION,
    SAVE,
    CLOSE,
    GET_INFO,
    CONVERT_TO_CSV,
    CUT,
    CONCATENATE,
    DECODE_WITH_DBC,
    PING
}
