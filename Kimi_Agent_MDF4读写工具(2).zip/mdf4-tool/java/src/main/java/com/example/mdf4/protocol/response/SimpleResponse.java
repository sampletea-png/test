package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

/**
 * 简单响应（用于CLOSE, SAVE等操作）
 */
public class SimpleResponse {
    private ResponseStatus status;
    private String message;

    public SimpleResponse() {
    }

    public static SimpleResponse success() {
        SimpleResponse response = new SimpleResponse();
        response.status = ResponseStatus.OK;
        return response;
    }

    public static SimpleResponse success(String message) {
        SimpleResponse response = new SimpleResponse();
        response.status = ResponseStatus.OK;
        response.message = message;
        return response;
    }

    public static SimpleResponse error(String message) {
        SimpleResponse response = new SimpleResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
