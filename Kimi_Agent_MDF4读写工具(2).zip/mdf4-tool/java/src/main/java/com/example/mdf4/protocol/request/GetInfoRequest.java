package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 获取文件信息请求
 */
public class GetInfoRequest {
    private final RequestType type = RequestType.GET_INFO;
    private String fileId;

    public GetInfoRequest() {
    }

    public GetInfoRequest(String fileId) {
        this.fileId = fileId;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
