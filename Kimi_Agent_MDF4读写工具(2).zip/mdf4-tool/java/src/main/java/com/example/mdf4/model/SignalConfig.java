package com.example.mdf4.model;

/**
 * 信号配置模型
 * <p>
 * 用于配置写入MDF4文件的信号属性。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class SignalConfig {
    private String unit;
    private String description;
    private String dataType;
    private double conversion;
    private double offset;

    public SignalConfig() {
        this.dataType = "FLOAT64";
        this.conversion = 1.0;
        this.offset = 0.0;
    }

    // Builder模式
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private SignalConfig config = new SignalConfig();

        public Builder unit(String unit) {
            config.unit = unit;
            return this;
        }

        public Builder description(String description) {
            config.description = description;
            return this;
        }

        public Builder dataType(String dataType) {
            config.dataType = dataType;
            return this;
        }

        public Builder conversion(double conversion) {
            config.conversion = conversion;
            return this;
        }

        public Builder offset(double offset) {
            config.offset = offset;
            return this;
        }

        public SignalConfig build() {
            return config;
        }
    }

    // Getters and Setters

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public double getConversion() {
        return conversion;
    }

    public void setConversion(double conversion) {
        this.conversion = conversion;
    }

    public double getOffset() {
        return offset;
    }

    public void setOffset(double offset) {
        this.offset = offset;
    }
}
