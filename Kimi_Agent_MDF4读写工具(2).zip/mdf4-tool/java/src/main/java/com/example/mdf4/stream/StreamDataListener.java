package com.example.mdf4.stream;

import com.example.mdf4.model.SignalData;

/**
 * 流数据监听器接口
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public interface StreamDataListener {

    /**
     * 接收到数据时的回调
     *
     * @param signalName 信号名称
     * @param data       信号数据
     */
    void onDataReceived(String signalName, SignalData data);

    /**
     * 发生错误时的回调
     *
     * @param e 异常
     */
    void onError(Exception e);
}
