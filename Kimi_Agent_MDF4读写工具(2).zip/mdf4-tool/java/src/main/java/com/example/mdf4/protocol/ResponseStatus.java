package com.example.mdf4.protocol;

/**
 * 响应状态枚举
 */
public enum ResponseStatus {
    OK,
    ERROR
}
