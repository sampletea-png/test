package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

/**
 * 读取信号响应
 */
public class ReadSignalResponse {
    private ResponseStatus status;
    private String message;
    private String name;
    private String unit;
    private String description;
    private String dataType;
    private String timestampsBase64;
    private String samplesBase64;

    public ReadSignalResponse() {
    }

    public static ReadSignalResponse success(String name, String unit, String description,
                                              String dataType, String timestampsBase64, String samplesBase64) {
        ReadSignalResponse response = new ReadSignalResponse();
        response.status = ResponseStatus.OK;
        response.name = name;
        response.unit = unit;
        response.description = description;
        response.dataType = dataType;
        response.timestampsBase64 = timestampsBase64;
        response.samplesBase64 = samplesBase64;
        return response;
    }

    public static ReadSignalResponse error(String message) {
        ReadSignalResponse response = new ReadSignalResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getTimestampsBase64() {
        return timestampsBase64;
    }

    public void setTimestampsBase64(String timestampsBase64) {
        this.timestampsBase64 = timestampsBase64;
    }

    public String getSamplesBase64() {
        return samplesBase64;
    }

    public void setSamplesBase64(String samplesBase64) {
        this.samplesBase64 = samplesBase64;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
