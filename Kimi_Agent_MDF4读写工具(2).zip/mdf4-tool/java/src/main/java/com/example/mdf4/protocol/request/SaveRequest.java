package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 保存文件请求
 */
public class SaveRequest {
    private final RequestType type = RequestType.SAVE;
    private String fileId;

    public SaveRequest() {
    }

    public SaveRequest(String fileId) {
        this.fileId = fileId;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
