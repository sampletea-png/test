package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

/**
 * 获取文件信息响应
 */
public class GetInfoResponse {
    private ResponseStatus status;
    private String message;
    private String version;
    private int channelGroupCount;
    private int channelCount;
    private long recordCount;
    private String startTime;
    private double duration;

    public GetInfoResponse() {
    }

    public static GetInfoResponse success(String version, int channelGroupCount, int channelCount,
                                           long recordCount, String startTime, double duration) {
        GetInfoResponse response = new GetInfoResponse();
        response.status = ResponseStatus.OK;
        response.version = version;
        response.channelGroupCount = channelGroupCount;
        response.channelCount = channelCount;
        response.recordCount = recordCount;
        response.startTime = startTime;
        response.duration = duration;
        return response;
    }

    public static GetInfoResponse error(String message) {
        GetInfoResponse response = new GetInfoResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getChannelGroupCount() {
        return channelGroupCount;
    }

    public void setChannelGroupCount(int channelGroupCount) {
        this.channelGroupCount = channelGroupCount;
    }

    public int getChannelCount() {
        return channelCount;
    }

    public void setChannelCount(int channelCount) {
        this.channelCount = channelCount;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
