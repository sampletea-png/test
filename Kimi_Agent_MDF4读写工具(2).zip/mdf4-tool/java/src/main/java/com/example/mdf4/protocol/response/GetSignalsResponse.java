package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

import java.util.List;

/**
 * 获取信号列表响应
 */
public class GetSignalsResponse {
    private ResponseStatus status;
    private String message;
    private List<String> signalNames;

    public GetSignalsResponse() {
    }

    public static GetSignalsResponse success(List<String> signalNames) {
        GetSignalsResponse response = new GetSignalsResponse();
        response.status = ResponseStatus.OK;
        response.signalNames = signalNames;
        return response;
    }

    public static GetSignalsResponse error(String message) {
        GetSignalsResponse response = new GetSignalsResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<String> getSignalNames() {
        return signalNames;
    }

    public void setSignalNames(List<String> signalNames) {
        this.signalNames = signalNames;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
