package com.example.mdf4.exception;

/**
 * MDF4工具异常类
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Exception extends RuntimeException {

    private ErrorCode errorCode;

    public enum ErrorCode {
        SERVICE_NOT_INITIALIZED,
        SERVICE_START_FAILED,
        FILE_NOT_FOUND,
        FILE_OPEN_FAILED,
        INVALID_SIGNAL_NAME,
        READ_ERROR,
        WRITE_ERROR,
        COMMUNICATION_ERROR,
        TIMEOUT_ERROR,
        PYTHON_ENV_ERROR
    }

    public MDF4Exception(String message) {
        super(message);
    }

    public MDF4Exception(String message, Throwable cause) {
        super(message, cause);
    }

    public MDF4Exception(ErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public MDF4Exception(ErrorCode errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }
}
