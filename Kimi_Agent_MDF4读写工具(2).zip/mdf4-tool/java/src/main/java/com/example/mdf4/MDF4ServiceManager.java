package com.example.mdf4;

import com.example.mdf4.exception.MDF4Exception;
import com.example.mdf4.pool.MDF4Connection;
import com.example.mdf4.pool.MDF4ConnectionFactory;
import com.example.mdf4.pool.MDF4ConnectionPool;
import com.example.mdf4.pool.PoolConfig;
import com.example.mdf4.stream.MDF4StreamManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MDF4服务管理器 - 线程安全的单例
 * <p>
 * 负责管理整个MDF4服务的生命周期，包括：
 * - 连接池管理（Python进程池）
 * - 文件级读写锁管理
 * - 流管理器
 * - 服务启动/关闭
 * </p>
 *
 * <h3>Python资源文件位置配置</h3>
 * <p>
 * 当Python资源文件位置发生修改时，需要修改以下位置：
 * </p>
 * <ol>
 *   <li><b>本类中的 {@link #DEFAULT_PYTHON_PATH} 常量</b> - Python解释器路径</li>
 *   <li><b>本类中的 {@link #DEFAULT_PYTHON_MODULE} 常量</b> - Python模块名称</li>
 *   <li><b>系统环境变量 {@code MDF4_PYTHON_PATH}</b> - 可覆盖默认路径</li>
 *   <li><b>系统环境变量 {@code MDF4_PYTHON_MODULE}</b> - 可覆盖默认模块名</li>
 * </ol>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4ServiceManager {
    private static final Logger logger = LoggerFactory.getLogger(MDF4ServiceManager.class);

    // ==================== Python资源文件位置配置（修改点1） ====================
    /**
     * 默认Python解释器路径
     * <p>修改此常量可改变默认Python解释器位置</p>
     */
    private static final String DEFAULT_PYTHON_PATH = "python";

    /**
     * 默认Python模块名称
     * <p>修改此常量可改变默认Python模块名称</p>
     */
    private static final String DEFAULT_PYTHON_MODULE = "mdf4_service";
    // ========================================================================

    // 环境变量名称
    private static final String ENV_PYTHON_PATH = "MDF4_PYTHON_PATH";
    private static final String ENV_PYTHON_MODULE = "MDF4_PYTHON_MODULE";

    private static volatile MDF4ServiceManager INSTANCE;
    private static final Object LOCK = new Object();

    private volatile boolean initialized = false;
    private MDF4ConnectionPool connectionPool;
    private MDF4StreamManager streamManager;
    private String pythonPath;
    private String pythonModule;

    // 文件级读写锁映射 (filePath -> ReadWriteLock)
    private final ConcurrentHashMap<String, ReentrantReadWriteLock> fileLocks = new ConcurrentHashMap<>();

    // 打开文件引用计数 (filePath -> AtomicInteger)
    private final ConcurrentHashMap<String, AtomicInteger> fileRefCounts = new ConcurrentHashMap<>();

    private MDF4ServiceManager() {
        // 从环境变量读取配置，如果没有则使用默认值
        this.pythonPath = System.getenv(ENV_PYTHON_PATH);
        if (this.pythonPath == null || this.pythonPath.isEmpty()) {
            this.pythonPath = DEFAULT_PYTHON_PATH;
        }

        this.pythonModule = System.getenv(ENV_PYTHON_MODULE);
        if (this.pythonModule == null || this.pythonModule.isEmpty()) {
            this.pythonModule = DEFAULT_PYTHON_MODULE;
        }

        logger.info("MDF4ServiceManager created with pythonPath={}, pythonModule={}",
                this.pythonPath, this.pythonModule);
    }

    /**
     * 获取单例实例
     *
     * @return MDF4ServiceManager实例
     */
    public static MDF4ServiceManager getInstance() {
        if (INSTANCE == null) {
            synchronized (LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new MDF4ServiceManager();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 初始化服务
     * <p>
     * 使用默认配置初始化服务。如果需要自定义配置，请使用
     * {@link #initialize(PoolConfig)} 方法。
     * </p>
     */
    public void initialize() {
        initialize(new PoolConfig());
    }

    /**
     * 初始化服务
     *
     * @param config 连接池配置
     * @throws MDF4Exception 如果初始化失败
     */
    public void initialize(PoolConfig config) {
        if (initialized) {
            logger.warn("MDF4ServiceManager already initialized");
            return;
        }

        synchronized (LOCK) {
            if (initialized) {
                return;
            }

            try {
                logger.info("Initializing MDF4ServiceManager...");

                // 验证Python环境
                validatePythonEnvironment();

                // 创建连接池
                MDF4ConnectionFactory factory = new MDF4ConnectionFactory(pythonPath, pythonModule);
                this.connectionPool = new MDF4ConnectionPool(factory, config);

                // 创建流管理器
                this.streamManager = new MDF4StreamManager(this);

                // 注册ShutdownHook
                registerShutdownHook();

                initialized = true;
                logger.info("MDF4ServiceManager initialized successfully");

            } catch (Exception e) {
                logger.error("Failed to initialize MDF4ServiceManager", e);
                shutdown();
                throw new MDF4Exception("Failed to initialize MDF4 service", e);
            }
        }
    }

    /**
     * 设置Python路径（动态配置）
     * <p>
     * 此方法可以在初始化前调用，用于动态设置Python解释器路径。
     * 如果服务已经初始化，调用此方法将抛出异常。
     * </p>
     *
     * @param pythonPath Python解释器路径
     * @throws IllegalStateException 如果服务已经初始化
     */
    public void setPythonPath(String pythonPath) {
        if (initialized) {
            throw new IllegalStateException("Cannot set python path after initialization");
        }
        this.pythonPath = pythonPath;
        logger.info("Python path set to: {}", pythonPath);
    }

    /**
     * 设置Python模块名称（动态配置）
     * <p>
     * 此方法可以在初始化前调用，用于动态设置Python模块名称。
     * 如果服务已经初始化，调用此方法将抛出异常。
     * </p>
     *
     * @param pythonModule Python模块名称
     * @throws IllegalStateException 如果服务已经初始化
     */
    public void setPythonModule(String pythonModule) {
        if (initialized) {
            throw new IllegalStateException("Cannot set python module after initialization");
        }
        this.pythonModule = pythonModule;
        logger.info("Python module set to: {}", pythonModule);
    }

    /**
     * 获取Python路径
     *
     * @return Python解释器路径
     */
    public String getPythonPath() {
        return pythonPath;
    }

    /**
     * 获取Python模块名称
     *
     * @return Python模块名称
     */
    public String getPythonModule() {
        return pythonModule;
    }

    /**
     * 验证Python环境
     *
     * @throws MDF4Exception 如果Python环境验证失败
     */
    private void validatePythonEnvironment() {
        try {
            ProcessBuilder pb = new ProcessBuilder(pythonPath, "--version");
            Process process = pb.start();
            boolean finished = process.waitFor(10, TimeUnit.SECONDS);

            if (!finished) {
                process.destroyForcibly();
                throw new MDF4Exception("Python environment validation timeout");
            }

            int exitCode = process.exitValue();
            if (exitCode != 0) {
                throw new MDF4Exception("Python environment validation failed with exit code: " + exitCode);
            }

            // 检查asammdf是否安装
            pb = new ProcessBuilder(pythonPath, "-c", "import asammdf; print(asammdf.__version__)");
            process = pb.start();
            finished = process.waitFor(10, TimeUnit.SECONDS);

            if (!finished) {
                process.destroyForcibly();
                throw new MDF4Exception("asammdf check timeout");
            }

            exitCode = process.exitValue();
            if (exitCode != 0) {
                throw new MDF4Exception("asammdf is not installed. Please run: pip install asammdf");
            }

            logger.info("Python environment validated successfully");

        } catch (IOException | InterruptedException e) {
            throw new MDF4Exception("Failed to validate Python environment: " + e.getMessage(), e);
        }
    }

    /**
     * 获取文件读锁
     *
     * @param filePath 文件路径
     * @return 读锁
     */
    public ReentrantReadWriteLock.ReadLock acquireReadLock(String filePath) {
        String canonicalPath = getCanonicalPath(filePath);
        ReentrantReadWriteLock lock = fileLocks.computeIfAbsent(
                canonicalPath,
                k -> new ReentrantReadWriteLock()
        );
        lock.readLock().lock();
        fileRefCounts.computeIfAbsent(canonicalPath, k -> new AtomicInteger(0)).incrementAndGet();
        logger.debug("Read lock acquired for: {}", canonicalPath);
        return lock.readLock();
    }

    /**
     * 获取文件写锁
     *
     * @param filePath 文件路径
     * @return 写锁
     */
    public ReentrantReadWriteLock.WriteLock acquireWriteLock(String filePath) {
        String canonicalPath = getCanonicalPath(filePath);
        ReentrantReadWriteLock lock = fileLocks.computeIfAbsent(
                canonicalPath,
                k -> new ReentrantReadWriteLock()
        );
        lock.writeLock().lock();
        logger.debug("Write lock acquired for: {}", canonicalPath);
        return lock.writeLock();
    }

    /**
     * 释放文件锁
     *
     * @param filePath 文件路径
     */
    public void releaseLock(String filePath) {
        String canonicalPath = getCanonicalPath(filePath);
        AtomicInteger refCount = fileRefCounts.get(canonicalPath);
        if (refCount != null) {
            int count = refCount.decrementAndGet();
            if (count <= 0) {
                fileLocks.remove(canonicalPath);
                fileRefCounts.remove(canonicalPath);
                logger.debug("Lock removed for: {}", canonicalPath);
            }
        }
        logger.debug("Lock released for: {}", canonicalPath);
    }

    /**
     * 获取规范化路径
     *
     * @param filePath 文件路径
     * @return 规范化路径
     */
    private String getCanonicalPath(String filePath) {
        try {
            return new File(filePath).getCanonicalPath();
        } catch (IOException e) {
            return filePath;
        }
    }

    /**
     * 创建线程安全的读取器
     *
     * @return MDF4Reader实例
     * @throws IllegalStateException 如果服务未初始化
     */
    public MDF4Reader createReader() {
        ensureInitialized();
        return new MDF4Reader(this);
    }

    /**
     * 创建线程安全的写入器
     *
     * @return MDF4Writer实例
     * @throws IllegalStateException 如果服务未初始化
     */
    public MDF4Writer createWriter() {
        ensureInitialized();
        return new MDF4Writer(this);
    }

    /**
     * 创建流式读取器
     *
     * @param filePath    MDF4文件路径
     * @param signalNames 信号名称列表
     * @return MDF4StreamReader实例
     * @throws IllegalStateException 如果服务未初始化
     */
    public MDF4StreamReader createStreamReader(String filePath, java.util.List<String> signalNames) {
        ensureInitialized();
        return streamManager.createStreamReader(filePath, signalNames);
    }

    /**
     * 获取连接池
     *
     * @return 连接池实例
     */
    MDF4ConnectionPool getConnectionPool() {
        return connectionPool;
    }

    /**
     * 获取流管理器
     *
     * @return 流管理器实例
     */
    MDF4StreamManager getStreamManager() {
        return streamManager;
    }

    /**
     * 检查是否已初始化
     *
     * @return true如果已初始化
     */
    public boolean isInitialized() {
        return initialized;
    }

    /**
     * 关闭服务
     */
    public void shutdown() {
        synchronized (LOCK) {
            if (!initialized) {
                return;
            }

            logger.info("Shutting down MDF4ServiceManager...");

            try {
                // 关闭流管理器
                if (streamManager != null) {
                    streamManager.shutdown();
                    streamManager = null;
                }

                // 关闭连接池
                if (connectionPool != null) {
                    connectionPool.shutdown();
                    connectionPool = null;
                }

                // 清理锁
                fileLocks.clear();
                fileRefCounts.clear();

                initialized = false;
                logger.info("MDF4ServiceManager shut down successfully");

            } catch (Exception e) {
                logger.error("Error during shutdown", e);
            }
        }
    }

    /**
     * 注册ShutdownHook
     */
    private void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutdown hook triggered, shutting down MDF4ServiceManager...");
            shutdown();
        }));
    }

    /**
     * 确保服务已初始化
     *
     * @throws IllegalStateException 如果服务未初始化
     */
    private void ensureInitialized() {
        if (!initialized) {
            throw new IllegalStateException(
                    "MDF4ServiceManager not initialized. Call initialize() first."
            );
        }
    }
}
