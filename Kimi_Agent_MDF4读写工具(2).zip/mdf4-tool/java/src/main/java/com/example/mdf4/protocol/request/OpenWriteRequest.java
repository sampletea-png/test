package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 打开文件写入请求
 */
public class OpenWriteRequest {
    private final RequestType type = RequestType.OPEN_WRITE;
    private String filePath;
    private String version;

    public OpenWriteRequest() {
    }

    public OpenWriteRequest(String filePath, String version) {
        this.filePath = filePath;
        this.version = version;
    }

    public RequestType getType() {
        return type;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
