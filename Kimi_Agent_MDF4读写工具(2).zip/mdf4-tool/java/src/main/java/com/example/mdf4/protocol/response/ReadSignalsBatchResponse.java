package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

import java.util.Map;

/**
 * 批量读取信号响应
 */
public class ReadSignalsBatchResponse {
    private ResponseStatus status;
    private String message;
    private Map<String, SignalDataDto> signals;

    public ReadSignalsBatchResponse() {
    }

    public static ReadSignalsBatchResponse success(Map<String, SignalDataDto> signals) {
        ReadSignalsBatchResponse response = new ReadSignalsBatchResponse();
        response.status = ResponseStatus.OK;
        response.signals = signals;
        return response;
    }

    public static ReadSignalsBatchResponse error(String message) {
        ReadSignalsBatchResponse response = new ReadSignalsBatchResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, SignalDataDto> getSignals() {
        return signals;
    }

    public void setSignals(Map<String, SignalDataDto> signals) {
        this.signals = signals;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }

    /**
     * 信号数据传输对象
     */
    public static class SignalDataDto {
        private String name;
        private String unit;
        private String description;
        private String dataType;
        private String timestampsBase64;
        private String samplesBase64;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(String unit) {
            this.unit = unit;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getDataType() {
            return dataType;
        }

        public void setDataType(String dataType) {
            this.dataType = dataType;
        }

        public String getTimestampsBase64() {
            return timestampsBase64;
        }

        public void setTimestampsBase64(String timestampsBase64) {
            this.timestampsBase64 = timestampsBase64;
        }

        public String getSamplesBase64() {
            return samplesBase64;
        }

        public void setSamplesBase64(String samplesBase64) {
            this.samplesBase64 = samplesBase64;
        }
    }
}
