package com.example.mdf4.stream;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.model.SignalData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MDF4流式读取器
 * <p>
 * 支持实时流式数据读取，适用于监控实时生成的MDF4文件。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4StreamReader implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(MDF4StreamReader.class);

    private final MDF4StreamManager.StreamSession session;
    private final MDF4StreamManager.EventBus eventBus;
    private final MDF4ServiceManager serviceManager;
    private final List<StreamDataListener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private ExecutorService executor;

    public MDF4StreamReader(MDF4StreamManager.StreamSession session,
                            MDF4StreamManager.EventBus eventBus,
                            MDF4ServiceManager serviceManager) {
        this.session = session;
        this.eventBus = eventBus;
        this.serviceManager = serviceManager;
    }

    /**
     * 添加数据监听器
     *
     * @param listener 监听器
     */
    public void addListener(StreamDataListener listener) {
        listeners.add(listener);
        eventBus.subscribe(session.getSessionId(), listener);
    }

    /**
     * 移除数据监听器
     *
     * @param listener 监听器
     */
    public void removeListener(StreamDataListener listener) {
        listeners.remove(listener);
        eventBus.unsubscribe(session.getSessionId(), listener);
    }

    /**
     * 开始流式读取
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            executor = Executors.newSingleThreadExecutor();
            executor.submit(this::readLoop);
            logger.info("Stream reader started for session: {}", session.getSessionId());
        }
    }

    /**
     * 停止流式读取
     */
    public void stop() {
        if (running.compareAndSet(true, false)) {
            if (executor != null) {
                executor.shutdown();
                try {
                    if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                        executor.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    executor.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
            logger.info("Stream reader stopped for session: {}", session.getSessionId());
        }
    }

    /**
     * 读取循环
     */
    private void readLoop() {
        try (MDF4Reader reader = serviceManager.createReader()) {
            String fileId = reader.open(session.getFilePath());

            // 记录每个信号的最后读取位置
            ConcurrentHashMap<String, Long> lastOffsets = new ConcurrentHashMap<>();
            for (String signalName : session.getSignalNames()) {
                lastOffsets.put(signalName, 0L);
            }

            while (running.get() && session.isActive()) {
                try {
                    for (String signalName : session.getSignalNames()) {
                        Long lastOffset = lastOffsets.get(signalName);

                        // 增量读取新数据
                        SignalData data = reader.readSignal(fileId, signalName);

                        if (data.getSamples() != null && data.getSamples().length > 0) {
                            // 只处理新数据
                            int newSamples = data.getSamples().length - lastOffset.intValue();
                            if (newSamples > 0) {
                                SignalData newData = extractNewData(data, lastOffset.intValue());

                                // 通知所有监听器
                                for (StreamDataListener listener : listeners) {
                                    try {
                                        listener.onDataReceived(signalName, newData);
                                    } catch (Exception e) {
                                        logger.error("Error in stream listener", e);
                                    }
                                }

                                // 更新偏移量
                                lastOffsets.put(signalName, (long) data.getSamples().length);
                            }
                        }
                    }

                    // 等待一段时间再检查
                    Thread.sleep(100);

                } catch (Exception e) {
                    logger.error("Error in read loop", e);
                    for (StreamDataListener listener : listeners) {
                        listener.onError(e);
                    }
                }
            }

            reader.close(fileId);

        } catch (Exception e) {
            logger.error("Stream reader error", e);
            for (StreamDataListener listener : listeners) {
                listener.onError(e);
            }
        }
    }

    /**
     * 提取新数据
     */
    private SignalData extractNewData(SignalData data, int fromIndex) {
        SignalData newData = new SignalData();
        newData.setName(data.getName());
        newData.setUnit(data.getUnit());
        newData.setDescription(data.getDescription());
        newData.setDataType(data.getDataType());

        int length = data.getSamples().length - fromIndex;
        double[] newTimestamps = new double[length];
        double[] newSamples = new double[length];

        System.arraycopy(data.getTimestamps(), fromIndex, newTimestamps, 0, length);
        System.arraycopy(data.getSamples(), fromIndex, newSamples, 0, length);

        newData.setTimestamps(newTimestamps);
        newData.setSamples(newSamples);

        return newData;
    }

    @Override
    public void close() {
        stop();
        listeners.clear();
        serviceManager.getStreamManager().closeSession(session.getSessionId());
    }
}
