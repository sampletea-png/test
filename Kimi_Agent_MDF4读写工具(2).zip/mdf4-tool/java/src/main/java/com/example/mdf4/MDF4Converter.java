package com.example.mdf4;

import com.example.mdf4.exception.MDF4Exception;
import com.example.mdf4.pool.MDF4Connection;
import com.example.mdf4.protocol.MDF4Command;
import com.example.mdf4.protocol.MDF4Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * MDF4文件转换器
 * <p>
 * 提供MDF4文件格式转换功能：
 * - MDF4转CSV
 * - MDF4转MAT
 * - 文件合并
 * - 时间裁剪
 * - DBC解码
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Converter {
    private static final Logger logger = LoggerFactory.getLogger(MDF4Converter.class);

    private final MDF4ServiceManager manager;

    public MDF4Converter(MDF4ServiceManager manager) {
        this.manager = manager;
    }

    /**
     * MDF4转CSV
     *
     * @param mdfPath  MDF4文件路径
     * @param csvPath  输出CSV文件路径
     * @param config   CSV配置
     * @throws MDF4Exception 如果转换失败
     */
    public void toCSV(String mdfPath, String csvPath, CSVConfig config) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("mdf_path", mdfPath);
            params.put("csv_path", csvPath);
            params.put("delimiter", config.getDelimiter());
            params.put("include_time", config.isIncludeTime());
            params.put("time_format", config.getTimeFormat());

            MDF4Command command = new MDF4Command("CONVERT_TO_CSV", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to convert to CSV: " + response.getMessage());
            }

            logger.info("Converted {} to CSV: {}", mdfPath, csvPath);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to convert to CSV", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 按时间裁剪文件
     *
     * @param inputPath  输入文件路径
     * @param outputPath 输出文件路径
     * @param startTime  开始时间（秒），null表示从头开始
     * @param endTime    结束时间（秒），null表示到末尾
     * @throws MDF4Exception 如果裁剪失败
     */
    public void cut(String inputPath, String outputPath, Double startTime, Double endTime) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("input_path", inputPath);
            params.put("output_path", outputPath);
            if (startTime != null) params.put("start_time", startTime);
            if (endTime != null) params.put("end_time", endTime);

            MDF4Command command = new MDF4Command("CUT", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to cut file: " + response.getMessage());
            }

            logger.info("Cut {} to {} ({} - {})", inputPath, outputPath, startTime, endTime);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to cut file", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * 合并多个MDF4文件
     *
     * @param mdfPaths   MDF4文件路径列表
     * @param outputPath 输出文件路径
     * @throws MDF4Exception 如果合并失败
     */
    public void concatenate(List<String> mdfPaths, String outputPath) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("mdf_paths", mdfPaths);
            params.put("output_path", outputPath);

            MDF4Command command = new MDF4Command("CONCATENATE", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to concatenate files: " + response.getMessage());
            }

            logger.info("Concatenated {} files to {}", mdfPaths.size(), outputPath);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to concatenate files", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * DBC解码
     *
     * @param mdfPath    MDF4文件路径
     * @param dbcPath    DBC文件路径
     * @param outputPath 输出文件路径
     * @throws MDF4Exception 如果解码失败
     */
    public void decodeWithDBC(String mdfPath, String dbcPath, String outputPath) throws MDF4Exception {
        MDF4Connection conn = null;
        try {
            conn = manager.getConnectionPool().borrowConnection();

            Map<String, Object> params = new HashMap<>();
            params.put("mdf_path", mdfPath);
            params.put("dbc_path", dbcPath);
            params.put("output_path", outputPath);

            MDF4Command command = new MDF4Command("DECODE_WITH_DBC", params);
            MDF4Response response = conn.execute(command);

            if (!"OK".equals(response.getStatus())) {
                throw new MDF4Exception("Failed to decode with DBC: " + response.getMessage());
            }

            logger.info("Decoded {} with DBC to {}", mdfPath, outputPath);

        } catch (Exception e) {
            throw new MDF4Exception("Failed to decode with DBC", e);
        } finally {
            if (conn != null) {
                manager.getConnectionPool().returnConnection(conn);
            }
        }
    }

    /**
     * CSV配置
     */
    public static class CSVConfig {
        private String delimiter = ",";
        private boolean includeTime = true;
        private String timeFormat = "SECONDS";

        public CSVConfig() {
        }

        // Getters and Setters

        public String getDelimiter() {
            return delimiter;
        }

        public void setDelimiter(String delimiter) {
            this.delimiter = delimiter;
        }

        public boolean isIncludeTime() {
            return includeTime;
        }

        public void setIncludeTime(boolean includeTime) {
            this.includeTime = includeTime;
        }

        public String getTimeFormat() {
            return timeFormat;
        }

        public void setTimeFormat(String timeFormat) {
            this.timeFormat = timeFormat;
        }

        // Builder
        public static Builder builder() {
            return new Builder();
        }

        public static class Builder {
            private CSVConfig config = new CSVConfig();

            public Builder delimiter(String delimiter) {
                config.delimiter = delimiter;
                return this;
            }

            public Builder includeTime(boolean includeTime) {
                config.includeTime = includeTime;
                return this;
            }

            public Builder timeFormat(String timeFormat) {
                config.timeFormat = timeFormat;
                return this;
            }

            public CSVConfig build() {
                return config;
            }
        }
    }
}
