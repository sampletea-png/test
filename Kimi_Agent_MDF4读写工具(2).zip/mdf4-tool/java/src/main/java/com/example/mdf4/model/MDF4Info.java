package com.example.mdf4.model;

import java.util.Map;

/**
 * MDF4文件信息模型
 * <p>
 * 包含MDF4文件的基本信息和元数据。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class MDF4Info {
    private String version;
    private int channelGroupCount;
    private int channelCount;
    private long recordCount;
    private String startTime;
    private double duration;
    private Map<String, Object> metadata;

    // Getters and Setters

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getChannelGroupCount() {
        return channelGroupCount;
    }

    public void setChannelGroupCount(int channelGroupCount) {
        this.channelGroupCount = channelGroupCount;
    }

    public int getChannelCount() {
        return channelCount;
    }

    public void setChannelCount(int channelCount) {
        this.channelCount = channelCount;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    @Override
    public String toString() {
        return "MDF4Info{" +
                "version='" + version + '\'' +
                ", channelGroupCount=" + channelGroupCount +
                ", channelCount=" + channelCount +
                ", recordCount=" + recordCount +
                ", startTime='" + startTime + '\'' +
                ", duration=" + duration +
                '}';
    }
}
