package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

/**
 * 打开文件写入响应
 */
public class OpenWriteResponse {
    private ResponseStatus status;
    private String message;
    private String fileId;
    private String version;

    public OpenWriteResponse() {
    }

    public static OpenWriteResponse success(String fileId, String version) {
        OpenWriteResponse response = new OpenWriteResponse();
        response.status = ResponseStatus.OK;
        response.fileId = fileId;
        response.version = version;
        return response;
    }

    public static OpenWriteResponse error(String message) {
        OpenWriteResponse response = new OpenWriteResponse();
        response.status = ResponseStatus.ERROR;
        response.message = message;
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
