package com.example.mdf4;

import com.example.mdf4.model.SignalData;

/**
 * 信号数据消费者接口
 * <p>
 * 用于流式读取大数据量信号时的回调处理。
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public interface SignalDataConsumer {

    /**
     * 消费数据块
     *
     * @param chunk  当前数据块
     * @param offset 当前偏移量
     * @param total  总样本数
     * @return 是否继续读取（返回false将停止读取）
     */
    boolean consume(SignalData chunk, long offset, long total);
}
