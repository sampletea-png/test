package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 分块读取信号请求
 */
public class ReadSignalChunkRequest {
    private final RequestType type = RequestType.READ_SIGNAL_CHUNK;
    private String fileId;
    private String signalName;
    private long offset;
    private int limit;

    public ReadSignalChunkRequest() {
    }

    public ReadSignalChunkRequest(String fileId, String signalName, long offset, int limit) {
        this.fileId = fileId;
        this.signalName = signalName;
        this.offset = offset;
        this.limit = limit;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getSignalName() {
        return signalName;
    }

    public void setSignalName(String signalName) {
        this.signalName = signalName;
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}
