package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 获取信号列表请求
 */
public class GetSignalsRequest {
    private final RequestType type = RequestType.GET_SIGNALS;
    private String fileId;

    public GetSignalsRequest() {
    }

    public GetSignalsRequest(String fileId) {
        this.fileId = fileId;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
