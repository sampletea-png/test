package com.example.mdf4.protocol.response;

import com.example.mdf4.protocol.ResponseStatus;

/**
 * 心跳检测响应
 */
public class PingResponse {
    private ResponseStatus status;
    private String message;

    public PingResponse() {
    }

    public static PingResponse success() {
        PingResponse response = new PingResponse();
        response.status = ResponseStatus.OK;
        response.message = "pong";
        return response;
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return status == ResponseStatus.OK;
    }
}
