package com.example.mdf4.model;

import java.util.Arrays;

/**
 * 信号数据模型
 * <p>
 * 表示从MDF4文件中读取的信号数据，包含：
 * - 信号名称
 * - 时间戳数组
 * - 采样值数组
 * - 单位、描述等元数据
 * </p>
 *
 * @author MDF4 Tool Team
 * @version 1.0.0
 */
public class SignalData {
    private String name;
    private double[] timestamps;
    private double[] samples;
    private String unit;
    private String description;
    private String dataType;

    public SignalData() {
    }

    public SignalData(String name, double[] timestamps, double[] samples) {
        this.name = name;
        this.timestamps = timestamps;
        this.samples = samples;
    }

    // Getters and Setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double[] getTimestamps() {
        return timestamps;
    }

    public void setTimestamps(double[] timestamps) {
        this.timestamps = timestamps;
    }

    public double[] getSamples() {
        return samples;
    }

    public void setSamples(double[] samples) {
        this.samples = samples;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    /**
     * 获取样本数量
     *
     * @return 样本数量
     */
    public int getSampleCount() {
        return samples != null ? samples.length : 0;
    }

    /**
     * 获取时间范围
     *
     * @return [startTime, endTime]
     */
    public double[] getTimeRange() {
        if (timestamps == null || timestamps.length == 0) {
            return new double[]{0.0, 0.0};
        }
        return new double[]{timestamps[0], timestamps[timestamps.length - 1]};
    }

    @Override
    public String toString() {
        return "SignalData{" +
                "name='" + name + '\'' +
                ", sampleCount=" + getSampleCount() +
                ", unit='" + unit + '\'' +
                ", dataType='" + dataType + '\'' +
                '}';
    }
}
