package com.example.mdf4.protocol.request;

import com.example.mdf4.model.SignalConfig;
import com.example.mdf4.protocol.RequestType;

/**
 * 追加信号数据块请求
 */
public class AppendSignalChunkRequest {
    private final RequestType type = RequestType.APPEND_SIGNAL_CHUNK;
    private String fileId;
    private String name;
    private String timestampsBase64;
    private String samplesBase64;
    private SignalConfig config;
    private boolean last;

    public AppendSignalChunkRequest() {
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTimestampsBase64() {
        return timestampsBase64;
    }

    public void setTimestampsBase64(String timestampsBase64) {
        this.timestampsBase64 = timestampsBase64;
    }

    public String getSamplesBase64() {
        return samplesBase64;
    }

    public void setSamplesBase64(String samplesBase64) {
        this.samplesBase64 = samplesBase64;
    }

    public SignalConfig getConfig() {
        return config;
    }

    public void setConfig(SignalConfig config) {
        this.config = config;
    }

    public boolean isLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }
}
