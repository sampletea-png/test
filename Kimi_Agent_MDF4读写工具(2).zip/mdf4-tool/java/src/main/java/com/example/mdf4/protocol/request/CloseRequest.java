package com.example.mdf4.protocol.request;

import com.example.mdf4.protocol.RequestType;

/**
 * 关闭文件请求
 */
public class CloseRequest {
    private final RequestType type = RequestType.CLOSE;
    private String fileId;

    public CloseRequest() {
    }

    public CloseRequest(String fileId) {
        this.fileId = fileId;
    }

    public RequestType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
