package com.example.mdf4.examples;

import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;
import com.example.mdf4.stream.MDF4StreamReader;
import com.example.mdf4.stream.StreamDataListener;

import java.util.Arrays;
import java.util.List;

/**
 * 实时流式读取示例
 */
public class StreamExample {

    public static void main(String[] args) throws Exception {
        // 初始化服务
        PoolConfig config = new PoolConfig();
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        // 要监控的信号
        List<String> signals = Arrays.asList("EngineSpeed", "VehicleSpeed");

        // 创建流式读取器
        MDF4StreamReader streamReader = manager.createStreamReader(
                "/data/realtime.mf4", signals);

        // 添加数据监听器
        streamReader.addListener(new StreamDataListener() {
            @Override
            public void onDataReceived(String signalName, SignalData data) {
                System.out.printf("[%s] %s: %d new samples, time range: %.3f - %.3f%n",
                        new java.util.Date(),
                        signalName,
                        data.getSampleCount(),
                        data.getTimeRange()[0],
                        data.getTimeRange()[1]);

                // 实时处理数据
                processRealTimeData(signalName, data);
            }

            @Override
            public void onError(Exception e) {
                System.err.println("Stream error: " + e.getMessage());
                e.printStackTrace();
            }
        });

        // 开始流式读取
        System.out.println("Starting stream reader...");
        streamReader.start();

        // 运行一段时间后停止
        Thread.sleep(60000);  // 运行60秒

        System.out.println("Stopping stream reader...");
        streamReader.stop();
        streamReader.close();

        manager.shutdown();
    }

    private static void processRealTimeData(String signalName, SignalData data) {
        // 实时数据处理逻辑
        // 例如：计算平均值、检测异常值、触发告警等
        double[] samples = data.getSamples();
        if (samples.length > 0) {
            double sum = 0;
            for (double sample : samples) {
                sum += sample;
            }
            double average = sum / samples.length;
            // System.out.printf("  Average %s: %.2f%n", signalName, average);
        }
    }
}
