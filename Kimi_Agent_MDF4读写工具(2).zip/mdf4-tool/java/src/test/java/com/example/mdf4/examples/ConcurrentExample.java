package com.example.mdf4.examples;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

/**
 * 多线程并发读取示例
 */
public class ConcurrentExample {

    public static void main(String[] args) throws Exception {
        // 配置连接池（根据并发需求调整）
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(10);
        config.setMaxWaitMillis(60000);

        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        String filePath = "/data/large_measurement.mf4";
        List<String> signals = Arrays.asList(
                "EngineSpeed", "EngineTorque", "ThrottlePosition",
                "VehicleSpeed", "CoolantTemp", "OilPressure",
                "BatteryVoltage", "IntakeAirTemp"
        );

        // 创建线程池
        ExecutorService executor = Executors.newFixedThreadPool(signals.size());
        List<Future<SignalData>> futures = new ArrayList<>();

        long startTime = System.currentTimeMillis();

        // 每个信号一个线程读取
        for (String signalName : signals) {
            Future<SignalData> future = executor.submit(() -> {
                try (MDF4Reader reader = manager.createReader()) {
                    String fileId = reader.open(filePath);
                    SignalData data = reader.readSignal(fileId, signalName);
                    reader.close(fileId);
                    return data;
                }
            });
            futures.add(future);
        }

        // 收集结果
        for (int i = 0; i < futures.size(); i++) {
            try {
                SignalData data = futures.get(i).get(30, TimeUnit.SECONDS);
                System.out.printf("Signal: %s, Samples: %d%n",
                        signals.get(i), data.getSampleCount());
            } catch (Exception e) {
                System.err.println("Error reading signal: " + signals.get(i));
                e.printStackTrace();
            }
        }

        long duration = System.currentTimeMillis() - startTime;
        System.out.println("\nTotal time: " + duration + " ms");

        executor.shutdown();
        manager.shutdown();
    }
}
