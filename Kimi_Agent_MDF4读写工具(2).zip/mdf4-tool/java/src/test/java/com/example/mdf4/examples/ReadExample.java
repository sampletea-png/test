package com.example.mdf4.examples;

import com.example.mdf4.MDF4Reader;
import com.example.mdf4.MDF4ServiceManager;
import com.example.mdf4.model.SignalData;
import com.example.mdf4.pool.PoolConfig;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * MDF4读取示例
 */
public class ReadExample {

    public static void main(String[] args) {
        // 配置连接池
        PoolConfig config = new PoolConfig();
        config.setMaxConnections(5);

        // 初始化服务
        MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
        manager.initialize(config);

        try {
            // 方式1: 使用try-with-resources（推荐）
            try (MDF4Reader reader = manager.createReader()) {
                String fileId = reader.open("/data/measurement.mf4");

                // 获取所有信号名称
                List<String> signals = reader.getSignalNames(fileId);
                System.out.println("Signals: " + signals);

                // 读取单个信号
                SignalData engineSpeed = reader.readSignal(fileId, "EngineSpeed");
                System.out.println("Engine Speed: " + engineSpeed);
                System.out.println("Sample count: " + engineSpeed.getSampleCount());

                // 按时间范围读取
                SignalData torque = reader.readSignal(fileId, "EngineTorque", 0.0, 60.0);
                System.out.println("Torque (0-60s): " + torque.getSampleCount() + " samples");

                // 批量读取多个信号
                List<String> batchSignals = Arrays.asList("EngineSpeed", "EngineTorque", "ThrottlePosition");
                Map<String, SignalData> batchData = reader.readSignals(fileId, batchSignals);
                for (Map.Entry<String, SignalData> entry : batchData.entrySet()) {
                    System.out.println(entry.getKey() + ": " + entry.getValue().getSampleCount() + " samples");
                }

                // 关闭文件
                reader.close(fileId);
            }

            // 方式2: 流式读取（大数据量）
            try (MDF4Reader reader = manager.createReader()) {
                String fileId = reader.open("/data/large_file.mf4");

                System.out.println("\nStreaming read:");
                reader.readSignalStream(fileId, "LargeSignal", (chunk, offset, total) -> {
                    System.out.printf("Chunk: offset=%d, count=%d, total=%d%n",
                            offset, chunk.getSampleCount(), total);
                    // 处理数据块...
                    return true; // 继续读取
                });

                reader.close(fileId);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭服务
            manager.shutdown();
        }
    }
}
