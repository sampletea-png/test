# MDF4工具示例运行指南

## 示例位置

示例代码位于 `src/test/java/com/example/mdf4/examples/` 目录下：

- `ReadExample.java` - 基本读取示例
- `WriteExample.java` - 写入示例
- `ConcurrentExample.java` - 多线程并发示例
- `StreamExample.java` - 实时流式读取示例

## 运行前准备

### 1. 安装Python依赖

```bash
cd ../python
pip install -r requirements.txt
pip install -e .
```

### 2. 编译Java项目

```bash
cd java
mvn clean compile test-compile
```

## 运行示例

### 方式1：使用Maven Exec插件（推荐）

```bash
# 运行读取示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ReadExample" -Dexec.classpathScope=test

# 运行写入示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.WriteExample" -Dexec.classpathScope=test

# 运行并发示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ConcurrentExample" -Dexec.classpathScope=test

# 运行流式示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.StreamExample" -Dexec.classpathScope=test
```

### 方式2：使用Maven Profile

```bash
# 运行读取示例
mvn exec:java -Pread-example

# 运行写入示例
mvn exec:java -Pwrite-example

# 运行并发示例
mvn exec:java -Pconcurrent-example

# 运行流式示例
mvn exec:java -Pstream-example
```

### 方式3：打包后运行

```bash
# 打包
mvn clean package

# 运行（需要指定测试类路径）
java -cp "target/mdf4-tool-1.0.0.jar:target/test-classes" com.example.mdf4.examples.ReadExample
```

## 常见问题

### 问题1：找不到mdf4_service

**原因**：Python模块未安装

**解决**：
```bash
cd ../python
pip install -e .
```

### 问题2：找不到主类

**原因**：测试类未编译

**解决**：
```bash
mvn test-compile
```

### 问题3：ClassNotFoundException

**原因**：依赖未正确加载

**解决**：使用 `-Dexec.classpathScope=test` 参数
