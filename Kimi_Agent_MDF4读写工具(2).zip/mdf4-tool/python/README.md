# MDF4 Service

Python service for handling MDF4 file operations via socket communication.

## Installation

```bash
pip install -r requirements.txt
```

Or install as a package:

```bash
pip install -e .
```

## Usage

### Run as a module

```bash
python -m mdf4_service --port 0 --parent-pid <pid>
```

### Options

- `--port`: Server port (0 for auto-assign)
- `--parent-pid`: Parent process PID for heartbeat detection
- `--max-workers`: Maximum worker threads (default: 10)

## Dependencies

- Python 3.8+
- asammdf >= 7.0.0
- numpy >= 1.20.0
