"""
Setup script for mdf4_service package
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="mdf4-service",
    version="1.0.0",
    author="MDF4 Tool Team",
    author_email="",
    description="Python service for handling MDF4 file operations via socket",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "asammdf>=7.0.0",
        "numpy>=1.20.0",
    ],
    entry_points={
        "console_scripts": [
            "mdf4-service=mdf4_service.__main__:main",
        ],
    },
)
