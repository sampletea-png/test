"""
Command Handler

Handles MDF4 file operations based on received commands.
Uses strongly typed request/response instead of Map.
"""

import logging
import base64
import io
import numpy as np
import threading
from asammdf import MDF


class CommandHandler:
    """Command handler for MDF4 operations"""

    def __init__(self):
        self.open_files = {}  # file_id -> {'mdf': MDF, 'mode': 'r'|'w', 'path': str}
        self.file_counter = 0
        self.logger = logging.getLogger(__name__)
        self.lock = threading.Lock()

    def handle(self, command):
        """Handle command
        
        Args:
            command: dict with 'type' and other fields
            
        Returns:
            Response dict with 'status' and other fields
        """
        cmd_type = command.get('type')

        self.logger.debug(f"Handling command: {cmd_type}")

        handlers = {
            'OPEN_READ': self._handle_open_read,
            'OPEN_WRITE': self._handle_open_write,
            'GET_SIGNALS': self._handle_get_signals,
            'GET_SIGNAL_INFO': self._handle_get_signal_info,
            'READ_SIGNAL': self._handle_read_signal,
            'READ_SIGNALS_BATCH': self._handle_read_signals_batch,
            'READ_SIGNAL_CHUNK': self._handle_read_signal_chunk,
            'APPEND_SIGNAL_CHUNK': self._handle_append_signal_chunk,
            'SET_COMPRESSION': self._handle_set_compression,
            'SAVE': self._handle_save,
            'CLOSE': self._handle_close,
            'GET_INFO': self._handle_get_info,
            'PING': self._handle_ping,
        }

        handler = handlers.get(cmd_type)
        if handler:
            try:
                return handler(command)
            except Exception as e:
                self.logger.error(f"Error handling {cmd_type}: {e}")
                return {'status': 'ERROR', 'message': str(e)}
        else:
            return {'status': 'ERROR', 'message': f'Unknown command: {cmd_type}'}

    def _handle_open_read(self, command):
        """Open file for reading"""
        file_path = command['filePath']
        mdf = MDF(file_path)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'r',
                'path': file_path
            }

        self.logger.info(f"Opened file for reading: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'fileId': file_id,
            'version': mdf.version
        }

    def _handle_open_write(self, command):
        """Open file for writing"""
        file_path = command['filePath']
        version = command.get('version', '4.10')

        # Create new MDF file
        mdf = MDF(version=version)

        with self.lock:
            self.file_counter += 1
            file_id = str(self.file_counter)
            self.open_files[file_id] = {
                'mdf': mdf,
                'mode': 'w',
                'path': file_path
            }

        self.logger.info(f"Created file for writing: {file_path} (id={file_id})")

        return {
            'status': 'OK',
            'fileId': file_id,
            'version': version
        }

    def _handle_get_signals(self, command):
        """Get all signal names"""
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal_names = []

        for group in mdf.groups:
            for channel in group.channels:
                signal_names.append(channel.name)

        return {
            'status': 'OK',
            'signalNames': signal_names
        }

    def _handle_get_signal_info(self, command):
        """Get signal information"""
        file_id = command['fileId']
        signal_name = command['signalName']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        return {
            'status': 'OK',
            'sampleCount': len(signal.samples) if signal.samples is not None else 0,
            'unit': signal.unit,
            'comment': signal.comment
        }

    def _handle_read_signal(self, command):
        """Read signal data"""
        file_id = command['fileId']
        signal_name = command['signalName']
        start_time = command.get('startTime')
        end_time = command.get('endTime')

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        # Time range filtering
        timestamps = signal.timestamps
        samples = signal.samples

        if start_time is not None or end_time is not None:
            mask = np.ones(len(timestamps), dtype=bool)
            if start_time is not None:
                mask &= timestamps >= start_time
            if end_time is not None:
                mask &= timestamps <= end_time
            timestamps = timestamps[mask]
            samples = samples[mask]

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'dataType': str(samples.dtype) if samples is not None else 'unknown',
            'timestampsBase64': self._encode_array(timestamps),
            'samplesBase64': self._encode_array(samples)
        }

    def _handle_read_signals_batch(self, command):
        """Read multiple signals (batch)"""
        file_id = command['fileId']
        signal_names = command['signalNames']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signals_data = {}

        for signal_name in signal_names:
            signal = mdf.get(signal_name)
            signals_data[signal_name] = {
                'name': signal.name,
                'unit': signal.unit,
                'description': signal.comment,
                'dataType': str(signal.samples.dtype) if signal.samples is not None else 'unknown',
                'timestampsBase64': self._encode_array(signal.timestamps),
                'samplesBase64': self._encode_array(signal.samples)
            }

        return {
            'status': 'OK',
            'signals': signals_data
        }

    def _handle_read_signal_chunk(self, command):
        """Read signal data in chunks"""
        file_id = command['fileId']
        signal_name = command['signalName']
        offset = command.get('offset', 0)
        limit = command.get('limit', 10000)

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        signal = mdf.get(signal_name)

        timestamps = signal.timestamps
        samples = signal.samples

        # Apply chunk range
        start = int(offset)
        end = min(start + int(limit), len(timestamps))

        return {
            'status': 'OK',
            'name': signal.name,
            'unit': signal.unit,
            'description': signal.comment,
            'dataType': str(samples.dtype) if samples is not None else 'unknown',
            'timestampsBase64': self._encode_array(timestamps[start:end]),
            'samplesBase64': self._encode_array(samples[start:end]),
            'offset': offset,
            'count': end - start
        }

    def _handle_append_signal_chunk(self, command):
        """Append signal data chunk"""
        file_id = command['fileId']
        name = command['name']
        timestamps_b64 = command['timestampsBase64']
        samples_b64 = command['samplesBase64']
        config = command.get('config', {})
        is_last = command.get('last', False)

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Decode arrays
        timestamps = self._decode_array(timestamps_b64)
        samples = self._decode_array(samples_b64)

        # Append to MDF (this is simplified - actual implementation would need to handle chunks properly)
        # For now, we just store the data in memory and save when is_last is True

        if is_last:
            # Create signal and append to MDF
            # Note: This is a simplified version - actual implementation would be more complex
            pass

        return {
            'status': 'OK',
            'appended': len(samples)
        }

    def _handle_set_compression(self, command):
        """Set compression level"""
        file_id = command['fileId']
        level = command['level']

        file_info = self.open_files.get(file_id)
        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        # Set compression (implementation depends on asammdf version)
        # mdf = file_info['mdf']
        # mdf.configure(compression=level)

        self.logger.info(f"Set compression level {level} for file: {file_info['path']}")

        return {'status': 'OK'}

    def _handle_save(self, command):
        """Save file"""
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']
        file_path = file_info['path']

        mdf.save(file_path, overwrite=True)

        self.logger.info(f"Saved file: {file_path}")

        return {'status': 'OK'}

    def _handle_close(self, command):
        """Close file"""
        file_id = command['fileId']
        file_info = self.open_files.pop(file_id, None)

        if file_info:
            mdf = file_info['mdf']
            mdf.close()
            self.logger.info(f"Closed file: {file_info['path']}")

        return {'status': 'OK'}

    def _handle_get_info(self, command):
        """Get file information"""
        file_id = command['fileId']
        file_info = self.open_files.get(file_id)

        if not file_info:
            return {'status': 'ERROR', 'message': 'File not open'}

        mdf = file_info['mdf']

        # Calculate total channels
        channel_count = sum(len(group.channels) for group in mdf.groups)

        return {
            'status': 'OK',
            'version': mdf.version,
            'channelGroupCount': len(mdf.groups),
            'channelCount': channel_count,
            'recordCount': 0,  # Placeholder
            'startTime': str(mdf.header.start_time) if mdf.header.start_time else None,
            'duration': mdf.header.duration if hasattr(mdf.header, 'duration') else 0.0
        }

    def _handle_ping(self, command):
        """Ping handler"""
        return {'status': 'OK', 'message': 'pong'}

    def _encode_array(self, arr):
        """Encode numpy array to base64 string"""
        if arr is None or len(arr) == 0:
            return ''

        buffer = io.BytesIO()
        np.save(buffer, arr, allow_pickle=False)
        return base64.b64encode(buffer.getvalue()).decode('utf-8')

    def _decode_array(self, b64_str):
        """Decode base64 string to numpy array"""
        if not b64_str:
            return np.array([])

        buffer = io.BytesIO(base64.b64decode(b64_str))
        return np.load(buffer, allow_pickle=False)
