"""
MDF4 Service Entry Point

Usage:
    python -m mdf4_service --port 0 --parent-pid <pid>
"""

import argparse
import logging
import sys
from .server import MDF4SocketServer


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )


def main():
    parser = argparse.ArgumentParser(description='MDF4 Socket Service')
    parser.add_argument('--port', type=int, default=0,
                        help='Server port (0 for auto)')
    parser.add_argument('--parent-pid', type=str,
                        help='Parent process PID')
    parser.add_argument('--max-workers', type=int, default=10,
                        help='Maximum worker threads')
    args = parser.parse_args()

    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)

    # Set parent process PID environment variable (for heartbeat detection)
    if args.parent_pid:
        import os
        os.environ['MDF4_PARENT_PID'] = args.parent_pid
        logger.info(f"Parent PID set to: {args.parent_pid}")

    # Create and start server
    server = MDF4SocketServer(
        port=args.port,
        max_workers=args.max_workers
    )

    try:
        logger.info("Starting MDF4 Socket Service...")
        server.start()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        server.stop()
        logger.info("MDF4 Socket Service stopped")


if __name__ == '__main__':
    main()
