"""
MDF4 Socket Service

A Python service for handling MDF4 file operations via socket communication.
"""

__version__ = "1.0.0"
__author__ = "MDF4 Tool Team"
