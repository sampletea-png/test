"""
MDF4 Socket Server

A multi-threaded socket server for handling MDF4 file operations.
Uses strongly typed request/response protocol.
"""

import socket
import threading
import json
import logging
import time
import os
import platform
from concurrent.futures import ThreadPoolExecutor
from .handler import CommandHandler


class MDF4SocketServer:
    """MDF4 Socket Server with multi-threading support"""

    def __init__(self, host='127.0.0.1', port=0, max_workers=10):
        self.host = host
        self.port = port
        self.max_workers = max_workers
        self.server_socket = None
        self.running = False
        self.handler = CommandHandler()
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.logger = logging.getLogger(__name__)

    def start(self):
        """Start the server"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))

        # Get the actual port (if port=0)
        actual_port = self.server_socket.getsockname()[1]
        print(f"PORT:{actual_port}", flush=True)

        self.server_socket.listen(20)
        self.running = True

        self.logger.info(f"MDF4 Server started on {self.host}:{actual_port}")

        # Start heartbeat detection thread
        heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()

        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                # Use thread pool to handle client
                self.executor.submit(self._handle_client, client_socket, address)
            except OSError:
                # Server socket closed
                break
            except Exception as e:
                if self.running:
                    self.logger.error(f"Server error: {e}")

    def _handle_client(self, client_socket, address):
        """Handle client connection"""
        self.logger.info(f"Client connected: {address}")
        try:
            while self.running:
                # Receive data length (4 bytes)
                length_bytes = self._recv_all(client_socket, 4)
                if not length_bytes:
                    break

                data_length = int.from_bytes(length_bytes, 'big')

                # Receive complete data
                data = self._recv_all(client_socket, data_length)
                if not data:
                    break

                # Parse command (JSON with camelCase keys)
                command = json.loads(data.decode('utf-8'))
                self.logger.debug(f"Received command: {command.get('type')}")

                # Handle command (thread-safe)
                response = self._handle_command_safe(command)

                # Send response
                response_bytes = json.dumps(response).encode('utf-8')
                client_socket.sendall(len(response_bytes).to_bytes(4, 'big'))
                client_socket.sendall(response_bytes)

        except Exception as e:
            self.logger.error(f"Client handler error: {e}")
        finally:
            client_socket.close()
            self.logger.info(f"Client disconnected: {address}")

    def _handle_command_safe(self, command):
        """Handle command in a thread-safe manner"""
        try:
            return self.handler.handle(command)
        except Exception as e:
            self.logger.error(f"Command handling error: {e}")
            return {'status': 'ERROR', 'message': str(e)}

    def _recv_all(self, sock, n):
        """Receive exactly n bytes from socket"""
        data = b''
        while len(data) < n:
            chunk = sock.recv(min(8192, n - len(data)))
            if not chunk:
                return None
            data += chunk
        return data

    def _heartbeat_loop(self):
        """Heartbeat detection loop"""
        while self.running:
            if not self._check_parent_alive():
                self.logger.info("Parent process died, shutting down...")
                self.stop()
                break
            time.sleep(5)

    def _check_parent_alive(self):
        """Check if parent process is still alive"""
        if platform.system() == 'Windows':
            # Windows: Check PID via environment variable
            parent_pid = os.environ.get('MDF4_PARENT_PID')
            if parent_pid:
                try:
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(1, False, int(parent_pid))
                    if handle:
                        kernel32.CloseHandle(handle)
                        return True
                    return False
                except Exception:
                    return False
            return True
        else:
            # Unix/Linux: Check PPID
            try:
                ppid = os.getppid()
                return ppid != 1  # If PPID becomes 1, parent has terminated
            except Exception:
                return False

    def stop(self):
        """Stop the server"""
        self.running = False
        self.executor.shutdown(wait=False)
        if self.server_socket:
            self.server_socket.close()
        self.logger.info("Server stopped")
