# MDF4工具项目总结

## 项目概述

本项目实现了一个Java MDF4文件读写工具，通过Socket与Python进程通信，利用asammdf库处理GB级MDF4文件。支持多线程并发读写和实时流式数据读取。

---

## 项目结构

```
mdf4-tool/
├── java/                           # Java端代码
│   ├── pom.xml                     # Maven构建配置
│   └── src/main/
│       ├── java/com/example/mdf4/
│       │   ├── MDF4ServiceManager.java    # 核心服务管理器（单例）
│       │   ├── MDF4Reader.java            # 读取器（线程安全）
│       │   ├── MDF4Writer.java            # 写入器（线程安全）
│       │   ├── MDF4Converter.java         # 格式转换器
│       │   ├── MDF4ToolMain.java          # 主入口
│       │   ├── SignalDataConsumer.java    # 流式消费接口
│       │   ├── model/                     # 数据模型
│       │   │   ├── SignalData.java        # 信号数据
│       │   │   ├── SignalConfig.java      # 信号配置
│       │   │   └── MDF4Info.java          # 文件信息
│       │   ├── pool/                      # 连接池
│       │   │   ├── MDF4Connection.java    # 连接对象
│       │   │   ├── MDF4ConnectionPool.java # 连接池
│       │   │   ├── MDF4ConnectionFactory.java # 连接工厂
│       │   │   └── PoolConfig.java        # 连接池配置
│       │   ├── stream/                    # 实时流
│       │   │   ├── MDF4StreamManager.java # 流管理器
│       │   │   ├── MDF4StreamReader.java  # 流式读取器
│       │   │   └── StreamDataListener.java # 流数据监听器
│       │   ├── protocol/                  # 通信协议
│       │   │   ├── MDF4Command.java       # 命令
│       │   │   └── MDF4Response.java      # 响应
│       │   ├── exception/                 # 异常
│       │   │   └── MDF4Exception.java     # 异常类
│       │   └── util/                      # 工具类
│       │       └── GsonUtils.java         # JSON工具
│       └── resources/
│           └── logback.xml                # 日志配置
├── python/                         # Python端代码
│   ├── mdf4_service/               # Python模块
│   │   ├── __init__.py             # 模块初始化
│   │   ├── __main__.py             # 入口点
│   │   ├── server.py               # Socket服务器
│   │   └── handler.py              # 命令处理器
│   ├── setup.py                    # Python包配置
│   ├── requirements.txt            # Python依赖
│   └── README.md                   # Python端说明
├── examples/                       # 使用示例
│   ├── ReadExample.java            # 基本读取示例
│   ├── WriteExample.java           # 写入示例
│   ├── ConcurrentExample.java      # 多线程并发示例
│   └── StreamExample.java          # 实时流式读取示例
├── config/                         # 配置文件
│   └── mdf4.properties             # 配置文件示例
├── README.md                       # 项目说明
└── CONFIGURATION_GUIDE.md          # 配置指南
```

---

## Python资源文件位置配置（关键修改点）

当Python资源文件的位置发生修改时，需要在以下位置进行配置：

### 1. Java代码中的默认配置

**文件**: `java/src/main/java/com/example/mdf4/MDF4ServiceManager.java`

```java
// ==================== Python资源文件位置配置（修改点1） ====================
/**
 * 默认Python解释器路径
 * <p>修改此常量可改变默认Python解释器位置</p>
 */
private static final String DEFAULT_PYTHON_PATH = "python";

/**
 * 默认Python模块名称
 * <p>修改此常量可改变默认Python模块名称</p>
 */
private static final String DEFAULT_PYTHON_MODULE = "mdf4_service";
// ========================================================================
```

### 2. 环境变量（运行时覆盖）

```bash
# Linux/Mac
export MDF4_PYTHON_PATH=/usr/bin/python3
export MDF4_PYTHON_MODULE=mdf4_service

# Windows
set MDF4_PYTHON_PATH=C:\Python39\python.exe
set MDF4_PYTHON_MODULE=mdf4_service
```

### 3. 代码中动态设置

```java
MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
manager.setPythonPath("/usr/bin/python3");
manager.setPythonModule("mdf4_service");
manager.initialize();
```

### 4. 配置文件

**文件**: `config/mdf4.properties`

```properties
mdf4.python.path=python
mdf4.python.module=mdf4_service
```

---

## 核心功能

### 1. 多线程并发读写

- 连接池管理多个Python进程
- 文件级读写锁（读共享、写独占）
- 线程安全的连接借用/归还

### 2. 实时流式读取

- WatchService监控文件变化
- 增量数据读取
- 事件驱动数据通知

### 3. 大文件处理

- 分块传输避免内存溢出
- 流式数据消费接口
- 可配置的分块大小

### 4. 生命周期管理

- ShutdownHook自动关闭
- Python心跳检测
- 资源自动释放

---

## 使用示例

### 基本读取

```java
MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
manager.initialize();

try (MDF4Reader reader = manager.createReader()) {
    String fileId = reader.open("/data/file.mf4");
    SignalData data = reader.readSignal(fileId, "EngineSpeed");
    System.out.println("Samples: " + data.getSampleCount());
    reader.close(fileId);
}

manager.shutdown();
```

### 多线程并发读取

```java
ExecutorService executor = Executors.newFixedThreadPool(5);
for (String signal : signals) {
    executor.submit(() -> {
        try (MDF4Reader reader = manager.createReader()) {
            String fileId = reader.open("/data/file.mf4");
            SignalData data = reader.readSignal(fileId, signal);
            reader.close(fileId);
        }
    });
}
```

### 实时流式读取

```java
MDF4StreamReader stream = manager.createStreamReader("/data/realtime.mf4", signals);
stream.addListener((signalName, data) -> {
    System.out.println("Real-time: " + signalName);
});
stream.start();
```

---

## 构建与部署

### Java端构建

```bash
cd java
mvn clean package
```

### Python端安装

```bash
cd python
pip install -r requirements.txt
pip install -e .
```

---

## 依赖

### Java
- Java 11+
- Gson 2.10.1
- Apache Commons Pool2 2.12.0
- SLF4J 2.0.9
- Logback 1.4.11

### Python
- Python 3.8+
- asammdf >= 7.0.0
- numpy >= 1.20.0

---

## 注意事项

1. **Python环境**: 确保Python 3.8+和asammdf已安装
2. **端口占用**: 使用动态端口分配，避免端口冲突
3. **文件锁**: 写操作会阻塞同一文件的其他读写
4. **资源释放**: 建议使用try-with-resources确保资源释放
5. **实时精度**: 文件监控精度取决于操作系统（通常1秒）

---

## 文件清单

| 文件路径 | 说明 |
|----------|------|
| `java/pom.xml` | Maven构建配置 |
| `java/src/main/java/com/example/mdf4/MDF4ServiceManager.java` | 核心服务管理器 |
| `java/src/main/java/com/example/mdf4/MDF4Reader.java` | 读取器 |
| `java/src/main/java/com/example/mdf4/MDF4Writer.java` | 写入器 |
| `python/mdf4_service/__main__.py` | Python入口点 |
| `python/mdf4_service/server.py` | Socket服务器 |
| `python/mdf4_service/handler.py` | 命令处理器 |
| `config/mdf4.properties` | 配置文件示例 |
| `examples/*.java` | 使用示例 |

---

## 作者

MDF4 Tool Team

## License

MIT License
