# MDF4工具项目

Java项目中读写GB级MDF4文件的公共工具，支持多线程并发和实时流式读取。

## 项目结构

```
mdf4-tool/
├── java/                           # Java端代码
│   ├── src/main/java/com/example/mdf4/
│   │   ├── MDF4ServiceManager.java    # 服务管理器（核心入口）
│   │   ├── MDF4Reader.java            # 读取器
│   │   ├── MDF4Writer.java            # 写入器
│   │   ├── MDF4Converter.java         # 格式转换器
│   │   ├── SignalDataConsumer.java    # 流式消费接口
│   │   ├── model/                     # 数据模型
│   │   │   ├── SignalData.java
│   │   │   ├── SignalConfig.java
│   │   │   └── MDF4Info.java
│   │   ├── pool/                      # 连接池
│   │   │   ├── MDF4Connection.java
│   │   │   ├── MDF4ConnectionPool.java
│   │   │   ├── MDF4ConnectionFactory.java
│   │   │   └── PoolConfig.java
│   │   ├── stream/                    # 实时流
│   │   │   ├── MDF4StreamManager.java
│   │   │   ├── MDF4StreamReader.java
│   │   │   └── StreamDataListener.java
│   │   ├── protocol/                  # 通信协议
│   │   │   ├── request/               # 请求类型
│   │   │   └── response/              # 响应类型
│   │   ├── exception/                 # 异常
│   │   │   └── MDF4Exception.java
│   │   └── util/                      # 工具类
│   │       └── GsonUtils.java
│   ├── src/test/java/com/example/mdf4/examples/  # 使用示例
│   │   ├── ReadExample.java
│   │   ├── WriteExample.java
│   │   ├── ConcurrentExample.java
│   │   └── StreamExample.java
│   ├── pom.xml                        # Maven配置
│   └── src/main/resources/            # 资源文件
├── python/                         # Python端代码
│   ├── mdf4_service/                  # Python模块
│   │   ├── __init__.py
│   │   ├── __main__.py               # 入口点
│   │   ├── server.py                 # Socket服务器
│   │   └── handler.py                # 命令处理器
│   ├── setup.py                       # Python包配置
│   ├── requirements.txt               # Python依赖
│   └── README.md
├── config/                         # 配置文件
│   └── mdf4.properties
├── CONFIGURATION_GUIDE.md          # 配置指南
└── README.md                       # 本文件
```

## 快速开始

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
pip install -e .
```

### 2. 构建Java项目

```bash
cd java
mvn clean package
```

### 3. 运行示例

示例代码位于 `java/src/test/java/com/example/mdf4/examples/` 目录下。

```bash
cd java

# 编译测试代码
mvn test-compile

# 运行读取示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ReadExample" -Dexec.classpathScope=test

# 运行写入示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.WriteExample" -Dexec.classpathScope=test

# 运行并发示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.ConcurrentExample" -Dexec.classpathScope=test

# 运行流式示例
mvn exec:java -Dexec.mainClass="com.example.mdf4.examples.StreamExample" -Dexec.classpathScope=test
```

详细说明请参考 [java/EXAMPLES_README.md](java/EXAMPLES_README.md)

### 4. 在项目中使用

```java
import com.example.mdf4.*;
import com.example.mdf4.model.*;
import com.example.mdf4.pool.*;

// 初始化服务
PoolConfig config = new PoolConfig();
config.setMaxConnections(10);

MDF4ServiceManager manager = MDF4ServiceManager.getInstance();
manager.initialize(config);

// 读取MDF4文件
try (MDF4Reader reader = manager.createReader()) {
    String fileId = reader.open("/data/measurement.mf4");
    SignalData data = reader.readSignal(fileId, "EngineSpeed");
    System.out.println("Samples: " + data.getSampleCount());
    reader.close(fileId);
}

// 关闭服务
manager.shutdown();
```

## 核心特性

- **多线程并发**: 连接池管理多个Python进程，支持并发读写
- **文件级读写锁**: 读共享、写独占，保证数据一致性
- **实时流式读取**: 支持监控实时生成的MDF4文件
- **大文件处理**: 分块传输，支持GB级文件
- **生命周期管理**: Java项目关闭时自动关闭Python进程

## 配置说明

### Python资源文件位置配置

当Python资源文件位置发生修改时，需要修改以下位置：

1. **Java代码中的默认配置** (`MDF4ServiceManager.java`):
   ```java
   private static final String DEFAULT_PYTHON_PATH = "python";
   private static final String DEFAULT_PYTHON_MODULE = "mdf4_service";
   ```

2. **环境变量** (运行时覆盖):
   ```bash
   export MDF4_PYTHON_PATH=/usr/bin/python3
   export MDF4_PYTHON_MODULE=mdf4_service
   ```

3. **代码中动态设置**:
   ```java
   manager.setPythonPath("/usr/bin/python3");
   manager.setPythonModule("mdf4_service");
   ```

详细配置说明请参考 [CONFIGURATION_GUIDE.md](CONFIGURATION_GUIDE.md)

## 使用示例

### 基本读取

```java
try (MDF4Reader reader = manager.createReader()) {
    String fileId = reader.open("/data/file.mf4");
    SignalData data = reader.readSignal(fileId, "SignalName");
    reader.close(fileId);
}
```

### 多线程并发读取

```java
ExecutorService executor = Executors.newFixedThreadPool(5);
for (String signal : signals) {
    executor.submit(() -> {
        try (MDF4Reader reader = manager.createReader()) {
            String fileId = reader.open("/data/file.mf4");
            SignalData data = reader.readSignal(fileId, signal);
            reader.close(fileId);
        }
    });
}
```

### 实时流式读取

```java
MDF4StreamReader stream = manager.createStreamReader("/data/realtime.mf4", signals);
stream.addListener((signalName, data) -> {
    System.out.println("Real-time: " + signalName);
});
stream.start();
```

## 依赖

### Java
- Java 11+
- Gson 2.10.1
- SLF4J 2.0.9
- Logback 1.4.11

### Python
- Python 3.8+
- asammdf >= 7.0.0
- numpy >= 1.20.0

## License

MIT License
