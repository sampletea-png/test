# MDF4 Java 实现技术文档

## 1. MDF4文件格式概述

MDF4（Measurement Data Format version 4）是由ASAM（Association for Standardization of Automation and Measuring Systems）定义的标准文件格式，用于存储测量数据。

### 1.1 文件结构

```
MDF4 File Structure:
┌─────────────────────────────────────────────────────────────┐
│ ID Block (64 bytes)                                          │
│   - 文件标识 "MDF "                                          │
│   - 版本信息 "4.20 "                                         │
│   - 程序标识                                                 │
│   - 字节序和浮点格式                                         │
├─────────────────────────────────────────────────────────────┤
│ HD Block (Header Block)                                      │
│   - 开始时间戳                                               │
│   - 时区和夏令时信息                                         │
│   - 链接到DG块、FH块                                         │
├─────────────────────────────────────────────────────────────┤
│ FH Block (File History Block)                                │
│   - 文件创建和修改历史                                       │
│   - 程序信息                                                 │
├─────────────────────────────────────────────────────────────┤
│ DG Block (Data Group Block)                                  │
│   - 数据组元数据                                             │
│   - 链接到CG块和DT块                                         │
├─────────────────────────────────────────────────────────────┤
│ CG Block (Channel Group Block)                               │
│   - 通道组元数据                                             │
│   - 记录大小和记录数量                                       │
│   - 链接到CN块                                               │
├─────────────────────────────────────────────────────────────┤
│ CN Block (Channel Block)                                     │
│   - 通道配置信息                                             │
│   - 数据类型、偏移、位数量                                   │
│   - 链接到CC块（转换）、TX块（名称）                         │
├─────────────────────────────────────────────────────────────┤
│ TX Block (Text Block)                                        │
│   - 通道名称                                                 │
│   - 注释和描述                                               │
├─────────────────────────────────────────────────────────────┤
│ DT Block (Data Block)                                        │
│   - 实际的测量数据                                           │
│   - 变长数据存储                                             │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 块头结构

每个块都有标准的24字节块头：

```
Block Header (24 bytes):
┌─────────────────┬──────────┬────────────────────────────────┐
│ Field           │ Size     │ Description                    │
├─────────────────┼──────────┼────────────────────────────────┤
│ Block ID        │ 4 bytes  │ 块类型标识（如"##HD"）        │
│ Reserved        │ 4 bytes  │ 保留                           │
│ Block Length    │ 8 bytes  │ 块总长度（包括头）            │
│ Link Count      │ 8 bytes  │ 链接数量                       │
└─────────────────┴──────────┴────────────────────────────────┘
```

## 2. Java实现架构

### 2.1 核心组件

```
┌─────────────────────────────────────────────────────────────┐
│                    MDF4Writer (主写入器)                     │
├─────────────────────────────────────────────────────────────┤
│  - 文件管理                                                 │
│  - 块创建和链接                                             │
│  - 数据写入协调                                             │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│  Block Layer  │   │ Channel Layer │   │ Buffer Layer  │
├───────────────┤   ├───────────────┤   ├───────────────┤
│ IDBlock       │   │ ChannelConfig │   │ DataBuffer    │
│ HDBlock       │   │ ChannelGroup  │   │ AsyncWriteMgr │
│ DGBlock       │   │ RecordBuilder │   │               │
│ CGBlock       │   └───────────────┘   └───────────────┘
│ CNBlock       │
│ DTBlock       │
│ TXBlock       │
│ FHBlock       │
└───────────────┘
```

### 2.2 类层次结构

```
MDF4Block (抽象基类)
    ├── IDBlock      - 文件标识块
    ├── HDBlock      - 文件头块
    ├── DGBlock      - 数据组块
    ├── CGBlock      - 通道组块
    ├── CNBlock      - 通道块
    ├── DTBlock      - 数据块
    ├── TXBlock      - 文本块
    └── FHBlock      - 文件历史块
```

## 3. 大数据量处理策略

### 3.1 分块写入

```java
// DTBlock支持流式写入
DTBlock dtBlock = new DTBlock(expectedSize, true); // 流式模式
dtBlock.write(file, position);

// 追加数据
dtBlock.appendData(file, data);

// 完成写入
dtBlock.finalizeBlock(file);
```

### 3.2 缓冲区管理

```java
// DataBuffer提供自动刷新
DataBuffer buffer = new DataBuffer(1024 * 1024); // 1MB缓冲区
buffer.setFlushCallback(data -> {
    // 刷新到文件
    file.write(data);
});

// 自动刷新阈值：80%容量
```

### 3.3 异步写入

```java
// AsyncWriteManager管理后台写入线程
AsyncWriteManager asyncManager = new AsyncWriteManager(
    queueCapacity,    // 队列容量
    batchSize,        // 批量大小
    flushIntervalMs   // 刷新间隔
);

asyncManager.start(data -> {
    // 写入处理
    file.write(data);
});

// 提交写入任务
asyncManager.submit(data);
```

## 4. 动态通道支持

### 4.1 通道组状态管理

```java
public class ChannelGroupConfig {
    private boolean isSealed;  // 密封状态
    
    public void seal() {
        this.isSealed = true;  // 密封后不再允许添加通道
    }
    
    public int addChannel(ChannelConfig channel) {
        if (isSealed) {
            throw new IllegalStateException("Channel group is sealed");
        }
        // 添加通道...
    }
}
```

### 4.2 运行时添加通道

```java
// 创建通道组
ChannelGroupConfig cg = writer.createChannelGroup("Dynamic");

// 添加初始通道
writer.addChannel(ChannelConfig.createTimeChannel("Time"));
writer.addChannel(new ChannelConfig("BaseSignal", DataType.DOUBLE));

// 密封前可以添加更多通道
writer.addChannel(new ChannelConfig("ExtraSignal", DataType.DOUBLE));

// 密封后准备写入
writer.sealCurrentChannelGroup();

// 密封后不能再添加通道
// writer.addChannel(...); // 抛出异常
```

## 5. 数据类型处理

### 5.1 数据类型映射

| MDF4类型 | Java类型 | 大小(字节) | 说明 |
|---------|---------|-----------|------|
| UINT8   | byte    | 1         | 无符号8位整数 |
| INT8    | byte    | 1         | 有符号8位整数 |
| UINT16  | short   | 2         | 无符号16位整数 |
| INT16   | short   | 2         | 有符号16位整数 |
| UINT32  | int     | 4         | 无符号32位整数 |
| INT32   | int     | 4         | 有符号32位整数 |
| UINT64  | long    | 8         | 无符号64位整数 |
| INT64   | long    | 8         | 有符号64位整数 |
| FLOAT   | float   | 4         | 单精度浮点 |
| DOUBLE  | double  | 8         | 双精度浮点 |
| BOOLEAN | boolean | 1         | 布尔值 |

### 5.2 字节序处理

```java
// 支持小端序和大端序
ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN; // 或 BIG_ENDIAN

// 在ByteBuffer中设置
ByteBuffer buffer = ByteBuffer.allocate(size);
buffer.order(byteOrder);

// 数据转换
buffer.putDouble(value);
buffer.putInt(value);
```

## 6. 性能优化

### 6.1 写入性能

| 优化策略 | 效果 | 适用场景 |
|---------|------|---------|
| 批量写入 | 减少IO操作 | 高频数据 |
| 异步写入 | 非阻塞写入 | 实时数据流 |
| 缓冲区 | 减少系统调用 | 大数据量 |
| FileChannel | 直接内存访问 | 超大文件 |

### 6.2 内存管理

```java
// 使用内存映射文件（可选）
FileChannel channel = new RandomAccessFile(file, "rw").getChannel();
MappedByteBuffer mappedBuffer = channel.map(
    FileChannel.MapMode.READ_WRITE, 
    position, 
    size
);

// 直接写入映射缓冲区
mappedBuffer.put(data);
```

### 6.3 配置建议

```java
// 高频小数据量（<1KHz）
config.setBufferSize(64 * 1024);      // 64KB
config.setUseAsyncWrite(false);       // 同步写入

// 中频数据（1-10KHz）
config.setBufferSize(256 * 1024);     // 256KB
config.setUseAsyncWrite(true);        // 异步写入
config.setAsyncQueueSize(1000);

// 高频大数据量（>10KHz）
config.setBufferSize(1024 * 1024);    // 1MB
config.setUseAsyncWrite(true);
config.setAsyncQueueSize(5000);
```

## 7. 文件分割

### 7.1 自动分割策略

```java
public class MDF4Writer {
    private long maxFileSize = 2L * 1024 * 1024 * 1024; // 2GB
    
    private void checkFileSize() throws IOException {
        if (channel.size() > maxFileSize) {
            // 创建新文件
            createNewFile();
        }
    }
}
```

### 7.2 分割实现

```java
// 当文件达到阈值时
if (currentFileSize > FILE_SPLIT_THRESHOLD) {
    // 1. 完成当前文件
    finalizeCurrentFile();
    
    // 2. 创建新文件
    String newFileName = generateNextFileName();
    MDF4Writer newWriter = new MDF4Writer(config);
    newWriter.open(newFileName);
    
    // 3. 复制通道配置
    copyChannelConfiguration(newWriter);
}
```

## 8. 错误处理

### 8.1 异常类型

```java
// IO异常
IOException - 文件操作失败

// 状态异常
IllegalStateException - 写入器状态错误
  - Writer not open
  - Channel group not sealed
  - Channel group already sealed

// 参数异常
IllegalArgumentException - 参数错误
  - Channel name is null or empty
  - Channel not found
  - Value count mismatch
```

### 8.2 恢复策略

```java
try {
    writer.writeRecord(values);
} catch (IOException e) {
    // 1. 记录错误
    logger.error("Write failed", e);
    
    // 2. 尝试恢复
    writer.flush();
    
    // 3. 重试或跳过
    if (retryCount < MAX_RETRY) {
        retryWrite(values);
    }
}
```

## 9. 兼容性

### 9.1 MDF4版本支持

- MDF 4.0.0
- MDF 4.1.0
- MDF 4.2.0

### 9.2 工具兼容性

| 工具 | 兼容性 |
|-----|--------|
| asammdf (Python) | 完全兼容 |
| CANape | 完全兼容 |
| CANoe | 完全兼容 |
| ETAS MDF Viewer | 完全兼容 |
| Vector MDF Validator | 完全兼容 |

## 10. 扩展性

### 10.1 自定义块

```java
// 继承MDF4Block创建自定义块
public class CustomBlock extends MDF4Block {
    public CustomBlock() {
        super("##CU", 4); // 自定义块ID和链接数
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 写入自定义数据
    }
}
```

### 10.2 插件架构

```java
// 定义扩展接口
public interface MDF4Extension {
    void onFileOpen(MDF4Writer writer);
    void onChannelGroupCreate(ChannelGroupConfig cg);
    void onWriteRecord(Object[] values);
    void onFileClose();
}
```

## 11. 参考资源

- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/)
- [MDF4 File Format Specification](https://www.asam.net/index.php?eID=dumpFile&t=f&f=4092&token=)
- [asammdf Python Library](https://github.com/danielhrisca/asammdf)
- [Vector MDF Documentation](https://support.vector.com/kb?id=kb_article_view&sysparm_article=KB0011530)
