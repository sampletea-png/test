# MDF4 Java 写入器

基于ASAM MDF 4.2.0标准的Java MDF4文件写入库。

## 特性

- **完整的MDF4格式支持**：支持ID、HD、DG、CG、CN、DT等核心块
- **大数据量写入**：支持GB级别数据的分块写入和内存管理
- **多数据类型**：支持double、int、float、boolean等多种数据类型
- **异步写入**：支持后台写入线程，提高写入性能
- **动态通道**：支持运行时添加通道
- **多通道组**：支持多个通道组的数据组织

## 项目结构

```
mdf4-java/
├── src/main/java/com/mdf4/
│   ├── blocks/          # MDF4块结构实现
│   │   ├── MDF4Block.java    # 块基类
│   │   ├── IDBlock.java      # 标识块
│   │   ├── HDBlock.java      # 头块
│   │   ├── DGBlock.java      # 数据组块
│   │   ├── CGBlock.java      # 通道组块
│   │   ├── CNBlock.java      # 通道块
│   │   ├── DTBlock.java      # 数据块
│   │   ├── TXBlock.java      # 文本块
│   │   └── FHBlock.java      # 文件历史块
│   ├── channel/         # 通道配置
│   │   ├── ChannelConfig.java      # 通道配置
│   │   └── ChannelGroupConfig.java # 通道组配置
│   ├── buffer/          # 缓冲区管理
│   │   ├── DataBuffer.java         # 数据缓冲区
│   │   └── AsyncWriteManager.java  # 异步写入管理
│   ├── core/            # 核心定义
│   │   ├── MDF4Constants.java      # 常量定义
│   │   └── DataType.java           # 数据类型枚举
│   ├── util/            # 工具类
│   │   └── MDF4Utils.java          # 工具方法
│   ├── writer/          # 写入器
│   │   └── MDF4Writer.java         # 主写入器
│   └── example/         # 示例代码
│       └── MDF4Example.java        # 使用示例
└── README.md
```

## 快速开始

### 1. 基本用法

```java
import com.mdf4.writer.MDF4Writer;
import com.mdf4.channel.ChannelConfig;
import com.mdf4.channel.ChannelGroupConfig;
import com.mdf4.core.DataType;

// 创建写入器
MDF4Writer writer = new MDF4Writer();

// 打开文件
writer.open("data.mf4");

// 创建通道组
ChannelGroupConfig cg = writer.createChannelGroup("Measurement");

// 添加通道
writer.addChannel(ChannelConfig.createTimeChannel("Time"));
writer.addChannel(ChannelConfig.createValueChannel("Speed", DataType.DOUBLE, "km/h"));
writer.addChannel(ChannelConfig.createValueChannel("Temperature", DataType.DOUBLE, "C"));

// 密封通道组（准备写入数据）
writer.sealCurrentChannelGroup();

// 写入数据
for (int i = 0; i < 1000; i++) {
    double time = i * 0.01;
    double speed = 50 + 20 * Math.sin(time * 2 * Math.PI);
    double temperature = 25 + 5 * Math.cos(time * Math.PI);
    writer.writeRecord(time, speed, temperature);
}

// 关闭写入器
writer.close();
```

### 2. 使用配置

```java
// 创建配置
MDF4Writer.WriterConfig config = new MDF4Writer.WriterConfig();
config.setBufferSize(1024 * 1024);      // 1MB缓冲区
config.setUseAsyncWrite(true);          // 启用异步写入
config.setAsyncQueueSize(1000);         // 异步队列大小
config.setProgramName("MyApplication"); // 程序名称

// 使用配置创建写入器
MDF4Writer writer = new MDF4Writer(config);
```

### 3. 多通道组

```java
// 第一个通道组
ChannelGroupConfig engineCG = writer.createChannelGroup("Engine");
writer.addChannel(ChannelConfig.createTimeChannel("Time"));
writer.addChannel(ChannelConfig.createValueChannel("RPM", DataType.INT32, "rpm"));
writer.sealCurrentChannelGroup();

// 第二个通道组
ChannelGroupConfig vehicleCG = writer.createChannelGroup("Vehicle");
writer.addChannel(ChannelConfig.createTimeChannel("Time"));
writer.addChannel(ChannelConfig.createValueChannel("Speed", DataType.DOUBLE, "km/h"));
writer.sealCurrentChannelGroup();
```

### 4. 使用Map写入

```java
Map<String, Object> values = new HashMap<>();
values.put("Time", 0.0);
values.put("Speed", 60.0);
values.put("Temperature", 25.0);

writer.writeRecord(values);
```

## 数据类型支持

| 数据类型 | Java类型 | 大小(字节) |
|---------|---------|-----------|
| INT8 | byte | 1 |
| INT16 | short | 2 |
| INT32 | int | 4 |
| INT64 | long | 8 |
| UINT8 | byte | 1 |
| UINT16 | short | 2 |
| UINT32 | int | 4 |
| UINT64 | long | 8 |
| FLOAT | float | 4 |
| DOUBLE | double | 8 |
| BOOLEAN | boolean | 1 |

## 性能优化建议

### 1. 缓冲区大小

根据数据量和写入频率调整缓冲区大小：

```java
config.setBufferSize(4 * 1024 * 1024); // 4MB缓冲区适合大数据量
```

### 2. 异步写入

对于高频写入场景，启用异步写入：

```java
config.setUseAsyncWrite(true);
config.setAsyncQueueSize(5000); // 增大队列容量
```

### 3. 批量写入

尽可能批量写入数据，减少IO操作：

```java
// 推荐：批量写入
for (int i = 0; i < 10000; i++) {
    writer.writeRecord(...);
}
writer.flush(); // 批量刷新
```

### 4. 通道配置

- 合理规划通道组结构
- 避免过多的小通道组
- 使用合适的数据类型（如不需要高精度时使用FLOAT代替DOUBLE）

## MDF4文件结构

```
MDF4 File Structure:
┌─────────────────────────────────────┐
│ ID Block (64 bytes)                 │
│ - File identifier                   │
│ - Version info                      │
├─────────────────────────────────────┤
│ HD Block (Header)                   │
│ - File metadata                     │
│ - Links to DG blocks                │
├─────────────────────────────────────┤
│ FH Block (File History)             │
│ - Creation info                     │
├─────────────────────────────────────┤
│ DG Block (Data Group)               │
│ - Links to CG blocks                │
│ - Links to DT blocks                │
├─────────────────────────────────────┤
│ CG Block (Channel Group)            │
│ - Channel group metadata            │
│ - Links to CN blocks                │
├─────────────────────────────────────┤
│ CN Block (Channel)                  │
│ - Channel configuration             │
│ - Data type, offset, etc.           │
├─────────────────────────────────────┤
│ TX Block (Text)                     │
│ - Channel names                     │
│ - Comments                          │
├─────────────────────────────────────┤
│ DT Block (Data)                     │
│ - Actual measurement data           │
└─────────────────────────────────────┘
```

## 依赖

- Java 8 或更高版本
- 无外部依赖

## 编译和运行

```bash
# 编译
cd mdf4-java/src/main/java
javac -d ../../../build com/mdf4/**/*.java

# 运行示例
cd ../../../build
java com.mdf4.example.MDF4Example
```

## 许可证

MIT License

## 参考

- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/)
- [asammdf Python Library](https://github.com/danielhrisca/asammdf)
