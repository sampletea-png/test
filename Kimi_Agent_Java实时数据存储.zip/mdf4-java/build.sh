#!/bin/bash

# MDF4 Java 编译脚本

# 设置变量
SRC_DIR="src/main/java"
BUILD_DIR="build"
OUTPUT_DIR="output"

# 清理并创建目录
echo "Cleaning build directory..."
rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR
mkdir -p $OUTPUT_DIR

# 编译Java文件
echo "Compiling Java files..."
find $SRC_DIR -name "*.java" -print0 | xargs -0 javac -d $BUILD_DIR -encoding UTF-8

if [ $? -eq 0 ]; then
    echo "Compilation successful!"
    echo ""
    echo "Running examples..."
    echo ""
    
    # 运行基本示例
    echo "=== Basic Example ==="
    java -cp $BUILD_DIR com.mdf4.example.MDF4Example
    
    echo ""
    echo "=== Advanced Example ==="
    java -cp $BUILD_DIR com.mdf4.example.AdvancedExample
    
    echo ""
    echo "Build and test completed!"
    echo "Output files are in: $OUTPUT_DIR"
else
    echo "Compilation failed!"
    exit 1
fi
