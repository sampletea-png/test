package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * MDF4 DT块（Data Block）
 * 数据块，存储实际的通道数据
 * 
 * 块结构：
 * - 块头（24字节）
 * - 数据（变长）
 * 
 * 支持大数据量的分块写入策略
 */
public class DTBlock extends MDF4Block {
    
    // 数据字段
    private byte[] data;             // 数据内容
    private long dataSize;           // 数据大小
    private boolean isStreaming;     // 是否流式写入模式
    
    // 流式写入状态
    private long writtenBytes;       // 已写入字节数
    private boolean isFinalized;     // 是否已完成
    
    /**
     * 构造函数（空数据块）
     */
    public DTBlock() {
        super(MDF4Constants.BLOCK_ID_DT, 0);
        this.data = new byte[0];
        this.dataSize = 0;
        this.isStreaming = false;
        this.writtenBytes = 0;
        this.isFinalized = true;
    }
    
    /**
     * 构造函数（指定数据）
     * @param data 数据
     */
    public DTBlock(byte[] data) {
        super(MDF4Constants.BLOCK_ID_DT, 0);
        this.data = data != null ? data : new byte[0];
        this.dataSize = this.data.length;
        this.isStreaming = false;
        this.writtenBytes = dataSize;
        this.isFinalized = true;
    }
    
    /**
     * 构造函数（流式写入模式）
     * @param expectedSize 预期数据大小
     * @param isStreaming 是否流式写入
     */
    public DTBlock(long expectedSize, boolean isStreaming) {
        super(MDF4Constants.BLOCK_ID_DT, 0);
        this.data = new byte[0];
        this.dataSize = expectedSize;
        this.isStreaming = isStreaming;
        this.writtenBytes = 0;
        this.isFinalized = !isStreaming;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 数据
        return getHeaderSize() + dataSize;
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        if (isStreaming) {
            // 流式写入模式：预留空间
            // 实际数据将通过appendData方法写入
            if (dataSize > 0) {
                // 预留数据空间
                byte[] padding = new byte[(int) Math.min(dataSize, 1024 * 1024)]; // 每次最多1MB
                long remaining = dataSize;
                while (remaining > 0) {
                    int toWrite = (int) Math.min(remaining, padding.length);
                    file.write(padding, 0, toWrite);
                    remaining -= toWrite;
                }
            }
        } else {
            // 普通模式：直接写入数据
            if (data != null && data.length > 0) {
                file.write(data);
            }
        }
    }
    
    /**
     * 追加数据（流式写入）
     * @param file 随机访问文件
     * @param dataToAppend 要追加的数据
     * @return 实际写入的字节数
     * @throws IOException IO异常
     */
    public int appendData(RandomAccessFile file, byte[] dataToAppend) throws IOException {
        if (!isStreaming) {
            throw new IllegalStateException("Not in streaming mode");
        }
        if (isFinalized) {
            throw new IllegalStateException("Block is already finalized");
        }
        
        long availableSpace = dataSize - writtenBytes;
        if (availableSpace <= 0) {
            return 0; // 没有可用空间
        }
        
        int toWrite = (int) Math.min(dataToAppend.length, availableSpace);
        
        // 计算写入位置
        long writePosition = filePosition + getHeaderSize() + writtenBytes;
        file.seek(writePosition);
        file.write(dataToAppend, 0, toWrite);
        
        writtenBytes += toWrite;
        
        return toWrite;
    }
    
    /**
     * 使用FileChannel追加数据（更高效）
     * @param channel 文件通道
     * @param buffer 数据缓冲区
     * @return 实际写入的字节数
     * @throws IOException IO异常
     */
    public int appendData(FileChannel channel, ByteBuffer buffer) throws IOException {
        if (!isStreaming) {
            throw new IllegalStateException("Not in streaming mode");
        }
        if (isFinalized) {
            throw new IllegalStateException("Block is already finalized");
        }
        
        long availableSpace = dataSize - writtenBytes;
        if (availableSpace <= 0) {
            return 0;
        }
        
        int originalLimit = buffer.limit();
        int toWrite = (int) Math.min(buffer.remaining(), availableSpace);
        buffer.limit(buffer.position() + toWrite);
        
        // 计算写入位置
        long writePosition = filePosition + getHeaderSize() + writtenBytes;
        int written = channel.write(buffer, writePosition);
        
        buffer.limit(originalLimit);
        writtenBytes += written;
        
        return written;
    }
    
    /**
     * 完成数据块
     * @param file 随机访问文件
     * @throws IOException IO异常
     */
    public void finalizeBlock(RandomAccessFile file) throws IOException {
        if (!isStreaming) {
            return;
        }
        
        // 更新实际数据大小
        dataSize = writtenBytes;
        isFinalized = true;
        
        // 更新块大小
        updateBlockSize(file);
    }
    
    /**
     * 设置数据
     * @param data 数据
     */
    public void setData(byte[] data) {
        if (isStreaming) {
            throw new IllegalStateException("Cannot set data in streaming mode");
        }
        this.data = data != null ? data : new byte[0];
        this.dataSize = this.data.length;
    }
    
    /**
     * 获取数据
     * @return 数据
     */
    public byte[] getData() {
        return data;
    }
    
    /**
     * 获取数据大小
     * @return 数据大小
     */
    public long getDataSize() {
        return isStreaming ? writtenBytes : dataSize;
    }
    
    /**
     * 获取剩余空间
     * @return 剩余空间（字节）
     */
    public long getRemainingSpace() {
        if (!isStreaming) {
            return 0;
        }
        return dataSize - writtenBytes;
    }
    
    /**
     * 是否已满
     * @return true如果已满
     */
    public boolean isFull() {
        if (!isStreaming) {
            return true;
        }
        return writtenBytes >= dataSize;
    }
    
    /**
     * 创建分块数据块
     * @param chunkSize 分块大小
     * @return 分块DTBlock数组
     */
    public static DTBlock[] createChunkedBlocks(byte[] data, int chunkSize) {
        if (data == null || data.length == 0) {
            return new DTBlock[0];
        }
        
        int numChunks = (data.length + chunkSize - 1) / chunkSize;
        DTBlock[] blocks = new DTBlock[numChunks];
        
        for (int i = 0; i < numChunks; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, data.length);
            int length = end - start;
            
            byte[] chunk = new byte[length];
            System.arraycopy(data, start, chunk, 0, length);
            blocks[i] = new DTBlock(chunk);
        }
        
        return blocks;
    }
    
    // Getters
    
    public boolean isStreaming() {
        return isStreaming;
    }
    
    public long getWrittenBytes() {
        return writtenBytes;
    }
    
    public boolean isFinalized() {
        return isFinalized;
    }
}
