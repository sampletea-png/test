package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * MDF4 ID块（Identification Block）
 * 文件的第一个块，包含文件标识和基本信息
 * 
 * 块结构（64字节）：
 * - 文件标识 (8字节): "MDF " + "4.20 "
 * - 程序标识 (8字节): 创建程序名称
 * - 保留1 (4字节)
 * - 保留2 (4字节)
 * - 版本号 (2字节)
 * - 保留3 (2字节)
 * - 标准版本 (2字节)
 * - 保留4 (6字节)
 * - 字节序 (1字节): 0=小端序, 1=大端序
 * - 浮点格式 (1字节): 0=IEEE 754
 * - 版本信息 (2字节)
 * - 保留5 (2字节)
 * - 保留6 (4字节)
 * - 保留7 (2字节)
 * - 保留8 (2字节)
 * - 保留9 (4字节)
 * - 保留10 (2字节)
 * - 保留11 (2字节)
 */
public class IDBlock extends MDF4Block {
    
    // ID块特有字段
    private String versionString;      // 版本字符串 "4.20 "
    private String programIdentifier;  // 程序标识
    private byte byteOrder;            // 字节序
    private byte floatFormat;          // 浮点格式
    private short versionNumber;       // 版本号
    private short standardVersion;     // 标准版本
    
    /**
     * 构造函数
     */
    public IDBlock() {
        super(MDF4Constants.BLOCK_ID_ID, 0);
        this.versionString = MDF4Constants.MDF_ID_VERSION;
        this.programIdentifier = MDF4Constants.MDF_ID_PROGRAM;
        this.byteOrder = MDF4Constants.BYTE_ORDER_LITTLE_ENDIAN;
        this.floatFormat = MDF4Constants.FLOAT_FORMAT_IEEE_754;
        this.versionNumber = (short) ((MDF4Constants.VERSION_MAJOR << 8) | MDF4Constants.VERSION_MINOR);
        this.standardVersion = 420; // MDF 4.2.0
    }
    
    /**
     * 构造函数（自定义参数）
     * @param programIdentifier 程序标识
     * @param byteOrder 字节序
     */
    public IDBlock(String programIdentifier, byte byteOrder) {
        super(MDF4Constants.BLOCK_ID_ID, 0);
        this.versionString = MDF4Constants.MDF_ID_VERSION;
        this.programIdentifier = programIdentifier != null ? 
            String.format("%-8s", programIdentifier).substring(0, 8) : MDF4Constants.MDF_ID_PROGRAM;
        this.byteOrder = byteOrder;
        this.floatFormat = MDF4Constants.FLOAT_FORMAT_IEEE_754;
        this.versionNumber = (short) ((MDF4Constants.VERSION_MAJOR << 8) | MDF4Constants.VERSION_MINOR);
        this.standardVersion = 420;
    }
    
    @Override
    public long getTotalSize() {
        // ID块固定64字节
        return 64;
    }
    
    @Override
    protected void writeHeader(RandomAccessFile file) throws IOException {
        // ID块没有标准块头，直接写入数据
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        // ID块没有链接
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 文件标识 "MDF " (4字节)
        file.write(MDF4Constants.MDF_ID_FILE.getBytes(StandardCharsets.US_ASCII));
        
        // 版本字符串 "4.20 " (4字节)
        file.write(versionString.getBytes(StandardCharsets.US_ASCII));
        
        // 程序标识 (8字节)
        String paddedProgramId = String.format("%-8s", programIdentifier).substring(0, 8);
        file.write(paddedProgramId.getBytes(StandardCharsets.US_ASCII));
        
        // 保留1 (4字节)
        file.writeInt(0);
        
        // 保留2 (4字节)
        file.writeInt(0);
        
        // 版本号 (2字节)
        file.writeShort(versionNumber);
        
        // 保留3 (2字节)
        file.writeShort((short) 0);
        
        // 标准版本 (2字节)
        file.writeShort(standardVersion);
        
        // 保留4 (6字节)
        file.write(new byte[6]);
        
        // 字节序 (1字节)
        file.writeByte(byteOrder);
        
        // 浮点格式 (1字节)
        file.writeByte(floatFormat);
        
        // 版本信息 (2字节)
        file.writeShort(versionNumber);
        
        // 保留5 (2字节)
        file.writeShort((short) 0);
        
        // 保留6 (4字节)
        file.writeInt(0);
        
        // 保留7 (2字节)
        file.writeShort((short) 0);
        
        // 保留8 (2字节)
        file.writeShort((short) 0);
        
        // 保留9 (4字节)
        file.writeInt(0);
        
        // 保留10 (2字节)
        file.writeShort((short) 0);
        
        // 保留11 (2字节)
        file.writeShort((short) 0);
    }
    
    // Getters and Setters
    
    public String getVersionString() {
        return versionString;
    }
    
    public void setVersionString(String versionString) {
        this.versionString = versionString;
    }
    
    public String getProgramIdentifier() {
        return programIdentifier;
    }
    
    public void setProgramIdentifier(String programIdentifier) {
        this.programIdentifier = programIdentifier;
    }
    
    public byte getByteOrder() {
        return byteOrder;
    }
    
    public void setByteOrder(byte byteOrder) {
        this.byteOrder = byteOrder;
    }
    
    public byte getFloatFormat() {
        return floatFormat;
    }
    
    public void setFloatFormat(byte floatFormat) {
        this.floatFormat = floatFormat;
    }
    
    public short getVersionNumber() {
        return versionNumber;
    }
    
    public void setVersionNumber(short versionNumber) {
        this.versionNumber = versionNumber;
    }
    
    public short getStandardVersion() {
        return standardVersion;
    }
    
    public void setStandardVersion(short standardVersion) {
        this.standardVersion = standardVersion;
    }
}
