package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * MDF4 TX块（Text Block）
 * 文本块，用于存储字符串数据（如通道名称、注释等）
 * 
 * 块结构：
 * - 块头（24字节）
 * - 文本数据（变长，以null结尾）
 */
public class TXBlock extends MDF4Block {
    
    // 文本内容
    private String text;
    
    // 是否以null结尾
    private boolean nullTerminated;
    
    /**
     * 构造函数
     */
    public TXBlock() {
        super(MDF4Constants.BLOCK_ID_TX, 0);
        this.text = "";
        this.nullTerminated = true;
    }
    
    /**
     * 构造函数（指定文本）
     * @param text 文本内容
     */
    public TXBlock(String text) {
        super(MDF4Constants.BLOCK_ID_TX, 0);
        this.text = text != null ? text : "";
        this.nullTerminated = true;
    }
    
    /**
     * 构造函数（指定文本和null结尾选项）
     * @param text 文本内容
     * @param nullTerminated 是否以null结尾
     */
    public TXBlock(String text, boolean nullTerminated) {
        super(MDF4Constants.BLOCK_ID_TX, 0);
        this.text = text != null ? text : "";
        this.nullTerminated = nullTerminated;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 文本数据
        long textSize = text.getBytes(StandardCharsets.UTF_8).length;
        if (nullTerminated) {
            textSize += 1; // null终止符
        }
        // 对齐到8字节边界
        long padding = (8 - (textSize % 8)) % 8;
        return getHeaderSize() + textSize + padding;
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        byte[] textBytes = text.getBytes(StandardCharsets.UTF_8);
        
        // 写入文本
        file.write(textBytes);
        
        // 写入null终止符
        if (nullTerminated) {
            file.writeByte(0);
        }
        
        // 填充到8字节边界
        long totalSize = textBytes.length + (nullTerminated ? 1 : 0);
        long padding = (8 - (totalSize % 8)) % 8;
        for (int i = 0; i < padding; i++) {
            file.writeByte(0);
        }
    }
    
    /**
     * 设置文本
     * @param text 文本内容
     */
    public void setText(String text) {
        this.text = text != null ? text : "";
    }
    
    /**
     * 获取文本
     * @return 文本内容
     */
    public String getText() {
        return text;
    }
    
    /**
     * 获取文本字节大小
     * @return 文本字节大小
     */
    public int getTextByteSize() {
        return text.getBytes(StandardCharsets.UTF_8).length;
    }
    
    /**
     * 创建TX块并写入文件
     * @param file 随机访问文件
     * @param position 写入位置
     * @param text 文本内容
     * @return 写入后的文件位置
     * @throws IOException IO异常
     */
    public static long writeText(RandomAccessFile file, long position, String text) throws IOException {
        TXBlock txBlock = new TXBlock(text);
        return txBlock.write(file, position);
    }
    
    /**
     * 创建TX块并写入文件（带null结尾选项）
     * @param file 随机访问文件
     * @param position 写入位置
     * @param text 文本内容
     * @param nullTerminated 是否以null结尾
     * @return 写入后的文件位置
     * @throws IOException IO异常
     */
    public static long writeText(RandomAccessFile file, long position, String text, boolean nullTerminated) throws IOException {
        TXBlock txBlock = new TXBlock(text, nullTerminated);
        return txBlock.write(file, position);
    }
}
