package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * MDF4 CG块（Channel Group Block）
 * 通道组块，包含通道组的元数据和指向通道的链接
 * 
 * 链接（8个）：
 * - Link 0: 下一个CG块
 * - Link 1: 第一个CN块
 * - Link 2: TX块（通道组名称）
 * - Link 3: SI块（源信息）
 * - Link 4: SR块（采样减少）
 * - Link 5: MD块（注释）
 * - Link 6-7: 保留
 * 
 * 数据字段：
 * - 记录ID（8字节）
 * - 循环计数（8字节）
 * - 数据字节数（2字节）
 * - 无效字节数（2字节）
 * - 标志（4字节）
 * - 路径分隔符（1字节）
 * - 保留（3字节）
 * - 数据记录数量（8字节）- v4.1+
 */
public class CGBlock extends MDF4Block {
    
    // 链接索引
    public static final int LINK_NEXT_CG = 0;
    public static final int LINK_CN_FIRST = 1;
    public static final int LINK_TX_NAME = 2;
    public static final int LINK_SI_SOURCE = 3;
    public static final int LINK_SR_FIRST = 4;
    public static final int LINK_MD_COMMENT = 5;
    
    // 标志位
    public static final int FLAG_VLSD = 0x0001;      // 变长信号数据
    public static final int FLAG_BUS_EVENT = 0x0002; // 总线事件
    public static final int FLAG_PLAIN_BUS = 0x0004; // 纯总线事件
    public static final int FLAG_REMOTE = 0x0008;    // 远程主站
    public static final int FLAG_EVENT = 0x0010;     // 事件信号
    
    // 数据字段
    private long recordId;           // 记录ID
    private long cycleCount;         // 循环计数
    private short dataBytes;         // 数据字节数
    private short invalidBytes;      // 无效字节数
    private int flags;               // 标志
    private byte pathSeparator;      // 路径分隔符
    private byte[] reserved;         // 保留（3字节）
    private long dataRecordCount;    // 数据记录数量
    
    // 运行时状态
    private int recordSize;          // 记录大小（计算得出）
    private int channelCount;        // 通道数量
    
    /**
     * 构造函数
     */
    public CGBlock() {
        super(MDF4Constants.BLOCK_ID_CG, 8);
        this.recordId = 0;
        this.cycleCount = 0;
        this.dataBytes = 0;
        this.invalidBytes = 0;
        this.flags = 0;
        this.pathSeparator = (byte) '.';
        this.reserved = new byte[3];
        this.dataRecordCount = 0;
        this.recordSize = 0;
        this.channelCount = 0;
    }
    
    /**
     * 构造函数（指定记录ID）
     * @param recordId 记录ID
     */
    public CGBlock(long recordId) {
        super(MDF4Constants.BLOCK_ID_CG, 8);
        this.recordId = recordId;
        this.cycleCount = 0;
        this.dataBytes = 0;
        this.invalidBytes = 0;
        this.flags = 0;
        this.pathSeparator = (byte) '.';
        this.reserved = new byte[3];
        this.dataRecordCount = 0;
        this.recordSize = 0;
        this.channelCount = 0;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 链接 + 数据字段
        return getHeaderSize() + 40; // 40字节数据
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 记录ID（8字节）
        file.writeLong(recordId);
        
        // 循环计数（8字节）
        file.writeLong(cycleCount);
        
        // 数据字节数（2字节）
        file.writeShort(dataBytes);
        
        // 无效字节数（2字节）
        file.writeShort(invalidBytes);
        
        // 标志（4字节）
        file.writeInt(flags);
        
        // 路径分隔符（1字节）
        file.writeByte(pathSeparator);
        
        // 保留（3字节）
        file.write(reserved);
        
        // 数据记录数量（8字节）
        file.writeLong(dataRecordCount);
    }
    
    /**
     * 设置下一个CG块链接
     * @param cgPosition CG块位置
     */
    public void setNextCGBlock(long cgPosition) {
        setLink(LINK_NEXT_CG, cgPosition);
    }
    
    /**
     * 获取下一个CG块链接
     * @return CG块位置
     */
    public long getNextCGBlock() {
        return getLink(LINK_NEXT_CG);
    }
    
    /**
     * 设置第一个CN块链接
     * @param cnPosition CN块位置
     */
    public void setFirstCNBlock(long cnPosition) {
        setLink(LINK_CN_FIRST, cnPosition);
    }
    
    /**
     * 获取第一个CN块链接
     * @return CN块位置
     */
    public long getFirstCNBlock() {
        return getLink(LINK_CN_FIRST);
    }
    
    /**
     * 设置通道组名称块链接
     * @param txPosition TX块位置
     */
    public void setNameBlock(long txPosition) {
        setLink(LINK_TX_NAME, txPosition);
    }
    
    /**
     * 设置源信息块链接
     * @param siPosition SI块位置
     */
    public void setSourceInfoBlock(long siPosition) {
        setLink(LINK_SI_SOURCE, siPosition);
    }
    
    /**
     * 设置注释块链接
     * @param mdPosition MD块位置
     */
    public void setCommentBlock(long mdPosition) {
        setLink(LINK_MD_COMMENT, mdPosition);
    }
    
    /**
     * 添加通道
     * @param channelSize 通道数据大小
     */
    public void addChannel(int channelSize) {
        this.recordSize += channelSize;
        this.channelCount++;
        updateDataBytes();
    }
    
    /**
     * 更新数据字节数
     */
    private void updateDataBytes() {
        this.dataBytes = (short) recordSize;
    }
    
    /**
     * 增加记录计数
     */
    public void incrementRecordCount() {
        this.dataRecordCount++;
    }
    
    /**
     * 设置VLSD标志
     * @param vlsd true表示变长信号数据
     */
    public void setVLSDFlag(boolean vlsd) {
        if (vlsd) {
            this.flags |= FLAG_VLSD;
        } else {
            this.flags &= ~FLAG_VLSD;
        }
    }
    
    /**
     * 检查是否为VLSD
     * @return true如果是变长信号数据
     */
    public boolean isVLSD() {
        return (flags & FLAG_VLSD) != 0;
    }
    
    // Getters and Setters
    
    public long getRecordId() {
        return recordId;
    }
    
    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }
    
    public long getCycleCount() {
        return cycleCount;
    }
    
    public void setCycleCount(long cycleCount) {
        this.cycleCount = cycleCount;
    }
    
    public short getDataBytes() {
        return dataBytes;
    }
    
    public void setDataBytes(short dataBytes) {
        this.dataBytes = dataBytes;
    }
    
    public short getInvalidBytes() {
        return invalidBytes;
    }
    
    public void setInvalidBytes(short invalidBytes) {
        this.invalidBytes = invalidBytes;
    }
    
    public int getFlags() {
        return flags;
    }
    
    public void setFlags(int flags) {
        this.flags = flags;
    }
    
    public byte getPathSeparator() {
        return pathSeparator;
    }
    
    public void setPathSeparator(byte pathSeparator) {
        this.pathSeparator = pathSeparator;
    }
    
    public long getDataRecordCount() {
        return dataRecordCount;
    }
    
    public void setDataRecordCount(long dataRecordCount) {
        this.dataRecordCount = dataRecordCount;
    }
    
    public int getRecordSize() {
        return recordSize;
    }
    
    public int getChannelCount() {
        return channelCount;
    }
}
