package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Instant;

/**
 * MDF4 FH块（File History Block）
 * 文件历史块，记录文件的创建和修改历史
 * 
 * 链接（4个）：
 * - Link 0: 下一个FH块
 * - Link 1: MD块（注释）
 * - Link 2-3: 保留
 * 
 * 数据字段：
 * - 时间戳（8字节，纳秒）
 * - 时区偏移（2字节）
 * - 夏令时偏移（2字节）
 * - 时间标志（1字节）
 * - 保留（1字节）
 */
public class FHBlock extends MDF4Block {
    
    // 链接索引
    public static final int LINK_NEXT_FH = 0;
    public static final int LINK_MD_COMMENT = 1;
    
    // 数据字段
    private long timeStamp;        // 时间戳（纳秒）
    private short timeZoneOffset;  // 时区偏移（分钟）
    private short dstOffset;       // 夏令时偏移（分钟）
    private byte timeFlags;        // 时间标志
    private byte reserved;         // 保留
    
    // 历史信息
    private String programName;    // 程序名称
    private String programVersion; // 程序版本
    private String userName;       // 用户名
    private String comment;        // 注释
    
    /**
     * 构造函数
     */
    public FHBlock() {
        super(MDF4Constants.BLOCK_ID_FH, 4);
        this.timeStamp = System.nanoTime();
        this.timeZoneOffset = 0;
        this.dstOffset = 0;
        this.timeFlags = 0;
        this.reserved = 0;
        this.programName = "JavaMDF4";
        this.programVersion = "1.0";
        this.userName = System.getProperty("user.name");
        this.comment = "";
    }
    
    /**
     * 构造函数（指定程序信息）
     * @param programName 程序名称
     * @param programVersion 程序版本
     */
    public FHBlock(String programName, String programVersion) {
        super(MDF4Constants.BLOCK_ID_FH, 4);
        this.timeStamp = System.nanoTime();
        this.timeZoneOffset = 0;
        this.dstOffset = 0;
        this.timeFlags = 0;
        this.reserved = 0;
        this.programName = programName != null ? programName : "JavaMDF4";
        this.programVersion = programVersion != null ? programVersion : "1.0";
        this.userName = System.getProperty("user.name");
        this.comment = "";
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 链接 + 数据字段
        return getHeaderSize() + 16; // 16字节数据
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 时间戳（8字节）
        file.writeLong(timeStamp);
        
        // 时区偏移（2字节）
        file.writeShort(timeZoneOffset);
        
        // 夏令时偏移（2字节）
        file.writeShort(dstOffset);
        
        // 时间标志（1字节）
        file.writeByte(timeFlags);
        
        // 保留（1字节）
        file.writeByte(reserved);
    }
    
    /**
     * 设置下一个FH块链接
     * @param fhPosition FH块位置
     */
    public void setNextFHBlock(long fhPosition) {
        setLink(LINK_NEXT_FH, fhPosition);
    }
    
    /**
     * 设置注释块链接
     * @param mdPosition MD块位置
     */
    public void setCommentBlock(long mdPosition) {
        setLink(LINK_MD_COMMENT, mdPosition);
    }
    
    /**
     * 更新时间戳为当前时间
     */
    public void updateTimestamp() {
        this.timeStamp = System.nanoTime();
    }
    
    /**
     * 生成标准历史注释
     * @return 格式化的历史注释
     */
    public String generateComment() {
        StringBuilder sb = new StringBuilder();
        sb.append("Program: ").append(programName).append("\n");
        sb.append("Version: ").append(programVersion).append("\n");
        sb.append("User: ").append(userName).append("\n");
        sb.append("Timestamp: ").append(Instant.ofEpochMilli(timeStamp / 1_000_000)).append("\n");
        if (comment != null && !comment.isEmpty()) {
            sb.append("Comment: ").append(comment);
        }
        return sb.toString();
    }
    
    // Getters and Setters
    
    public long getTimeStamp() {
        return timeStamp;
    }
    
    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }
    
    public short getTimeZoneOffset() {
        return timeZoneOffset;
    }
    
    public void setTimeZoneOffset(short timeZoneOffset) {
        this.timeZoneOffset = timeZoneOffset;
    }
    
    public short getDstOffset() {
        return dstOffset;
    }
    
    public void setDstOffset(short dstOffset) {
        this.dstOffset = dstOffset;
    }
    
    public String getProgramName() {
        return programName;
    }
    
    public void setProgramName(String programName) {
        this.programName = programName;
    }
    
    public String getProgramVersion() {
        return programVersion;
    }
    
    public void setProgramVersion(String programVersion) {
        this.programVersion = programVersion;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
}
