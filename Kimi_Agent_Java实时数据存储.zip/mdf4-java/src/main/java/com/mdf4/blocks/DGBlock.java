package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * MDF4 DG块（Data Group Block）
 * 数据组块，包含指向通道组和数据的链接
 * 
 * 链接（8个）：
 * - Link 0: 下一个DG块
 * - Link 1: 第一个CG块
 * - Link 2: 数据块（DT/DL/DZ）
 * - Link 3: 注释块（TX/MD）
 * - Link 4: 文件历史块（FH）
 * - Link 5: 通道层次块（CH）
 * - Link 6-7: 保留
 * 
 * 数据字段：
 * - 记录ID大小（1字节）
 * - 保留（1字节）
 * - 记录ID（8字节）- 可选
 */
public class DGBlock extends MDF4Block {
    
    // 链接索引
    public static final int LINK_NEXT_DG = 0;
    public static final int LINK_CG_FIRST = 1;
    public static final int LINK_DATA = 2;
    public static final int LINK_COMMENT = 3;
    public static final int LINK_FH = 4;
    public static final int LINK_CH = 5;
    
    // 数据字段
    private byte recordIdSize;     // 记录ID大小（字节）
    private byte reserved;         // 保留
    private long recordId;         // 记录ID（可选）
    
    // 数据块位置跟踪
    private long currentDataPosition = 0;
    private long totalDataSize = 0;
    
    /**
     * 构造函数
     */
    public DGBlock() {
        super(MDF4Constants.BLOCK_ID_DG, 8);
        this.recordIdSize = 0;
        this.reserved = 0;
        this.recordId = 0;
    }
    
    /**
     * 构造函数（指定记录ID大小）
     * @param recordIdSize 记录ID大小
     */
    public DGBlock(byte recordIdSize) {
        super(MDF4Constants.BLOCK_ID_DG, 8);
        this.recordIdSize = recordIdSize;
        this.reserved = 0;
        this.recordId = 0;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 链接 + 数据字段
        long size = getHeaderSize() + 2; // 2字节固定数据
        if (recordIdSize > 0) {
            size += 8; // 记录ID（8字节）
        }
        return size;
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 记录ID大小（1字节）
        file.writeByte(recordIdSize);
        
        // 保留（1字节）
        file.writeByte(reserved);
        
        // 记录ID（8字节，可选）
        if (recordIdSize > 0) {
            file.writeLong(recordId);
        }
    }
    
    /**
     * 设置下一个DG块链接
     * @param dgPosition DG块位置
     */
    public void setNextDGBlock(long dgPosition) {
        setLink(LINK_NEXT_DG, dgPosition);
    }
    
    /**
     * 获取下一个DG块链接
     * @return DG块位置
     */
    public long getNextDGBlock() {
        return getLink(LINK_NEXT_DG);
    }
    
    /**
     * 设置第一个CG块链接
     * @param cgPosition CG块位置
     */
    public void setFirstCGBlock(long cgPosition) {
        setLink(LINK_CG_FIRST, cgPosition);
    }
    
    /**
     * 获取第一个CG块链接
     * @return CG块位置
     */
    public long getFirstCGBlock() {
        return getLink(LINK_CG_FIRST);
    }
    
    /**
     * 设置数据块链接
     * @param dataPosition 数据块位置
     */
    public void setDataBlock(long dataPosition) {
        setLink(LINK_DATA, dataPosition);
    }
    
    /**
     * 获取数据块链接
     * @return 数据块位置
     */
    public long getDataBlock() {
        return getLink(LINK_DATA);
    }
    
    /**
     * 设置注释块链接
     * @param commentPosition 注释块位置
     */
    public void setCommentBlock(long commentPosition) {
        setLink(LINK_COMMENT, commentPosition);
    }
    
    /**
     * 更新数据块大小
     * @param file 随机访问文件
     * @param dataSize 数据大小
     * @throws IOException IO异常
     */
    public void updateDataSize(RandomAccessFile file, long dataSize) throws IOException {
        this.totalDataSize = dataSize;
        // 更新链接指向的数据块大小
        long dataBlockPos = getLink(LINK_DATA);
        if (dataBlockPos > 0) {
            file.seek(dataBlockPos + 8); // 跳过块标识和保留字节
            file.writeLong(dataSize + 24); // 块头大小 + 数据大小
        }
    }
    
    /**
     * 追加数据到数据块
     * @param file 随机访问文件
     * @param data 数据
     * @return 新写入的数据位置
     * @throws IOException IO异常
     */
    public long appendData(RandomAccessFile file, byte[] data) throws IOException {
        if (currentDataPosition == 0) {
            // 首次写入，创建数据块
            long dataBlockPos = getLink(LINK_DATA);
            if (dataBlockPos > 0) {
                file.seek(dataBlockPos + getHeaderSize());
                currentDataPosition = file.getFilePointer();
            } else {
                throw new IllegalStateException("Data block not initialized");
            }
        }
        
        file.seek(currentDataPosition);
        file.write(data);
        long writtenPos = currentDataPosition;
        currentDataPosition = file.getFilePointer();
        totalDataSize += data.length;
        
        return writtenPos;
    }
    
    // Getters and Setters
    
    public byte getRecordIdSize() {
        return recordIdSize;
    }
    
    public void setRecordIdSize(byte recordIdSize) {
        this.recordIdSize = recordIdSize;
    }
    
    public long getRecordId() {
        return recordId;
    }
    
    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }
    
    public long getTotalDataSize() {
        return totalDataSize;
    }
}
