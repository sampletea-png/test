package com.mdf4.blocks;

import com.mdf4.core.DataType;
import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * MDF4 CN块（Channel Block）
 * 通道块，包含通道的元数据和配置信息
 * 
 * 链接（12个）：
 * - Link 0: 下一个CN块
 * - Link 1: CC块（通道转换）
 * - Link 2: CE块（通道扩展）
 * - Link 3: CD块（通道依赖）
 * - Link 4: TX块（通道名称）
 * - Link 5: SI块（源信息）
 * - Link 6: MD块（注释）
 * - Link 7: 保留
 * - Link 8-11: 保留
 * 
 * 数据字段：
 * - 通道类型（1字节）
 * - 同步类型（1字节）
 * - 数据类型（1字节）
 * - 位偏移（1字节）
 * - 字节偏移（4字节）
 * - 位数量（4字节）
 * - 标志（4字节）
 * - 无效位位置（4字节）
 * - 精度（1字节）
 * - 保留（3字节）
 * - 附加字节（4字节）
 * - 最小值（8字节）
 * - 最大值（8字节）
 * - 下限（8字节）
 * - 上限（8字节）
 * - 下限扩展（8字节）
 * - 上限扩展（8字节）
 */
public class CNBlock extends MDF4Block {
    
    // 链接索引
    public static final int LINK_NEXT_CN = 0;
    public static final int LINK_CC = 1;
    public static final int LINK_CE = 2;
    public static final int LINK_CD = 3;
    public static final int LINK_TX_NAME = 4;
    public static final int LINK_SI_SOURCE = 5;
    public static final int LINK_MD_COMMENT = 6;
    
    // 标志位
    public static final int FLAG_ALL_INVALID = 0x00000001;
    public static final int FLAG_INVALID = 0x00000002;
    public static final int FLAG_PRECISION_VALID = 0x00000004;
    public static final int FLAG_RANGE_VALID = 0x00000008;
    public static final int FLAG_LIMIT_VALID = 0x00000010;
    public static final int FLAG_EXT_LIMIT_VALID = 0x00000020;
    public static final int FLAG_DISCRETE = 0x00000040;
    public static final int FLAG_CALIBRATION = 0x00000080;
    public static final int FLAG_CALCULATED = 0x00000100;
    public static final int FLAG_VIRTUAL = 0x00000200;
    public static final int FLAG_BUS = 0x00000400;
    public static final int FLAG_MONOTONOUS = 0x00000800;
    public static final int FLAG_DEFAULT = 0x00001000;
    public static final int FLAG_EVENT = 0x00002000;
    public static final int FLAG_VLSD = 0x00004000;
    
    // 数据字段
    private byte channelType;        // 通道类型
    private byte syncType;           // 同步类型
    private byte dataType;           // 数据类型
    private byte bitOffset;          // 位偏移
    private int byteOffset;          // 字节偏移
    private int bitCount;            // 位数量
    private int flags;               // 标志
    private int invalidBitPos;       // 无效位位置
    private byte precision;          // 精度
    private byte[] reserved;         // 保留（3字节）
    private int attachment;          // 附加字节
    private double minValue;         // 最小值
    private double maxValue;         // 最大值
    private double lowerLimit;       // 下限
    private double upperLimit;       // 上限
    private double lowerLimitExt;    // 下限扩展
    private double upperLimitExt;    // 上限扩展
    
    // 运行时字段
    private String channelName;      // 通道名称
    private int dataSize;            // 数据大小
    
    /**
     * 构造函数
     */
    public CNBlock() {
        super(MDF4Constants.BLOCK_ID_CN, 12);
        initDefaults();
    }
    
    /**
     * 构造函数（指定通道名称和数据类型）
     * @param channelName 通道名称
     * @param dataType 数据类型
     */
    public CNBlock(String channelName, DataType dataType) {
        super(MDF4Constants.BLOCK_ID_CN, 12);
        initDefaults();
        this.channelName = channelName;
        this.dataType = (byte) dataType.getTypeId();
        this.bitCount = dataType.getSize() * 8;
        this.dataSize = dataType.getSize();
    }
    
    private void initDefaults() {
        this.channelType = MDF4Constants.CHANNEL_TYPE_FIXED_LENGTH;
        this.syncType = MDF4Constants.SYNC_TYPE_NONE;
        this.dataType = (byte) DataType.DOUBLE.getTypeId();
        this.bitOffset = 0;
        this.byteOffset = 0;
        this.bitCount = 64;
        this.flags = 0;
        this.invalidBitPos = 0;
        this.precision = 0;
        this.reserved = new byte[3];
        this.attachment = 0;
        this.minValue = 0;
        this.maxValue = 0;
        this.lowerLimit = 0;
        this.upperLimit = 0;
        this.lowerLimitExt = 0;
        this.upperLimitExt = 0;
        this.dataSize = 8;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 链接 + 数据字段
        return getHeaderSize() + 96; // 96字节数据
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 通道类型（1字节）
        file.writeByte(channelType);
        
        // 同步类型（1字节）
        file.writeByte(syncType);
        
        // 数据类型（1字节）
        file.writeByte(dataType);
        
        // 位偏移（1字节）
        file.writeByte(bitOffset);
        
        // 字节偏移（4字节）
        file.writeInt(byteOffset);
        
        // 位数量（4字节）
        file.writeInt(bitCount);
        
        // 标志（4字节）
        file.writeInt(flags);
        
        // 无效位位置（4字节）
        file.writeInt(invalidBitPos);
        
        // 精度（1字节）
        file.writeByte(precision);
        
        // 保留（3字节）
        file.write(reserved);
        
        // 附加字节（4字节）
        file.writeInt(attachment);
        
        // 最小值（8字节）
        file.writeDouble(minValue);
        
        // 最大值（8字节）
        file.writeDouble(maxValue);
        
        // 下限（8字节）
        file.writeDouble(lowerLimit);
        
        // 上限（8字节）
        file.writeDouble(upperLimit);
        
        // 下限扩展（8字节）
        file.writeDouble(lowerLimitExt);
        
        // 上限扩展（8字节）
        file.writeDouble(upperLimitExt);
    }
    
    /**
     * 设置下一个CN块链接
     * @param cnPosition CN块位置
     */
    public void setNextCNBlock(long cnPosition) {
        setLink(LINK_NEXT_CN, cnPosition);
    }
    
    /**
     * 获取下一个CN块链接
     * @return CN块位置
     */
    public long getNextCNBlock() {
        return getLink(LINK_NEXT_CN);
    }
    
    /**
     * 设置通道转换块链接
     * @param ccPosition CC块位置
     */
    public void setConversionBlock(long ccPosition) {
        setLink(LINK_CC, ccPosition);
    }
    
    /**
     * 设置通道名称块链接
     * @param txPosition TX块位置
     */
    public void setNameBlock(long txPosition) {
        setLink(LINK_TX_NAME, txPosition);
    }
    
    /**
     * 设置源信息块链接
     * @param siPosition SI块位置
     */
    public void setSourceInfoBlock(long siPosition) {
        setLink(LINK_SI_SOURCE, siPosition);
    }
    
    /**
     * 设置注释块链接
     * @param mdPosition MD块位置
     */
    public void setCommentBlock(long mdPosition) {
        setLink(LINK_MD_COMMENT, mdPosition);
    }
    
    /**
     * 设置为主通道
     */
    public void setAsMasterChannel() {
        this.channelType = MDF4Constants.CHANNEL_TYPE_MASTER;
        this.syncType = MDF4Constants.SYNC_TYPE_TIME;
    }
    
    /**
     * 设置为时间通道
     */
    public void setAsTimeChannel() {
        setAsMasterChannel();
        this.dataType = (byte) DataType.DOUBLE.getTypeId();
        this.bitCount = 64;
        this.dataSize = 8;
    }
    
    /**
     * 计算数据大小
     * @return 数据大小（字节）
     */
    public int calculateDataSize() {
        return (bitCount + 7) / 8; // 向上取整到字节
    }
    
    /**
     * 设置字节偏移
     * @param offset 字节偏移
     */
    public void setByteOffset(int offset) {
        this.byteOffset = offset;
    }
    
    /**
     * 获取数据大小
     * @return 数据大小
     */
    public int getDataSize() {
        return dataSize;
    }
    
    // Getters and Setters
    
    public byte getChannelType() {
        return channelType;
    }
    
    public void setChannelType(byte channelType) {
        this.channelType = channelType;
    }
    
    public byte getSyncType() {
        return syncType;
    }
    
    public void setSyncType(byte syncType) {
        this.syncType = syncType;
    }
    
    public byte getDataType() {
        return dataType;
    }
    
    public void setDataType(byte dataType) {
        this.dataType = dataType;
    }
    
    public byte getBitOffset() {
        return bitOffset;
    }
    
    public void setBitOffset(byte bitOffset) {
        this.bitOffset = bitOffset;
    }
    
    public int getByteOffset() {
        return byteOffset;
    }
    
    public int getBitCount() {
        return bitCount;
    }
    
    public void setBitCount(int bitCount) {
        this.bitCount = bitCount;
    }
    
    public int getFlags() {
        return flags;
    }
    
    public void setFlags(int flags) {
        this.flags = flags;
    }
    
    public String getChannelName() {
        return channelName;
    }
    
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    
    public void setDataSize(int dataSize) {
        this.dataSize = dataSize;
    }
}
