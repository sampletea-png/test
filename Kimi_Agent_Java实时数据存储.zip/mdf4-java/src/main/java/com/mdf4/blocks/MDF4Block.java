package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;
import com.mdf4.util.MDF4Utils;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * MDF4块基类
 * 所有MDF4块的抽象基类，定义块的通用结构和行为
 */
public abstract class MDF4Block {
    
    // 块头字段
    protected String blockId;      // 4字节块标识
    protected long blockSize;      // 8字节块大小
    protected long linksCount;     // 8字节链接数量
    protected long[] links;        // 链接数组
    
    // 块在文件中的位置
    protected long filePosition = -1;
    
    // 字节序
    protected ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    
    /**
     * 构造函数
     * @param blockId 块标识
     * @param linksCount 链接数量
     */
    protected MDF4Block(String blockId, long linksCount) {
        this.blockId = blockId;
        this.linksCount = linksCount;
        this.links = new long[(int) linksCount];
        // 初始化链接为0（无效链接）
        for (int i = 0; i < links.length; i++) {
            links[i] = 0;
        }
    }
    
    /**
     * 获取块头大小
     * @return 块头大小（字节）
     */
    public long getHeaderSize() {
        return MDF4Constants.BLOCK_HEADER_SIZE + linksCount * MDF4Constants.LINK_SIZE;
    }
    
    /**
     * 获取块总大小
     * @return 块总大小（字节）
     */
    public abstract long getTotalSize();
    
    /**
     * 设置链接值
     * @param index 链接索引
     * @param position 文件位置
     */
    public void setLink(int index, long position) {
        if (index < 0 || index >= links.length) {
            throw new IndexOutOfBoundsException("Link index out of bounds: " + index);
        }
        links[index] = position;
    }
    
    /**
     * 获取链接值
     * @param index 链接索引
     * @return 文件位置
     */
    public long getLink(int index) {
        if (index < 0 || index >= links.length) {
            throw new IndexOutOfBoundsException("Link index out of bounds: " + index);
        }
        return links[index];
    }
    
    /**
     * 写入块到文件
     * @param file 随机访问文件
     * @param position 写入位置
     * @return 写入后的文件位置
     * @throws IOException IO异常
     */
    public long write(RandomAccessFile file, long position) throws IOException {
        this.filePosition = position;
        file.seek(position);
        
        // 写入块头
        writeHeader(file);
        
        // 写入链接
        writeLinks(file);
        
        // 写入数据
        writeData(file);
        
        return file.getFilePointer();
    }
    
    /**
     * 写入块头
     * @param file 随机访问文件
     * @throws IOException IO异常
     */
    protected void writeHeader(RandomAccessFile file) throws IOException {
        // 块标识 (4字节)
        file.write(blockId.getBytes(StandardCharsets.US_ASCII));
        
        // 保留字节 (4字节)
        file.write(new byte[4]);
        
        // 块长度 (8字节)
        file.writeLong(getTotalSize());
        
        // 链接数量 (8字节)
        file.writeLong(linksCount);
    }
    
    /**
     * 写入链接
     * @param file 随机访问文件
     * @throws IOException IO异常
     */
    protected void writeLinks(RandomAccessFile file) throws IOException {
        for (long link : links) {
            file.writeLong(link);
        }
    }
    
    /**
     * 写入数据部分
     * @param file 随机访问文件
     * @throws IOException IO异常
     */
    protected abstract void writeData(RandomAccessFile file) throws IOException;
    
    /**
     * 更新块大小（用于动态调整块大小）
     * @param file 随机访问文件
     * @throws IOException IO异常
     */
    public void updateBlockSize(RandomAccessFile file) throws IOException {
        if (filePosition < 0) {
            throw new IllegalStateException("Block has not been written yet");
        }
        file.seek(filePosition + 8); // 跳过块标识和保留字节
        file.writeLong(getTotalSize());
    }
    
    /**
     * 更新链接
     * @param file 随机访问文件
     * @param linkIndex 链接索引
     * @param targetPosition 目标位置
     * @throws IOException IO异常
     */
    public void updateLink(RandomAccessFile file, int linkIndex, long targetPosition) throws IOException {
        if (filePosition < 0) {
            throw new IllegalStateException("Block has not been written yet");
        }
        if (linkIndex < 0 || linkIndex >= links.length) {
            throw new IndexOutOfBoundsException("Link index out of bounds: " + linkIndex);
        }
        
        links[linkIndex] = targetPosition;
        long linkPosition = filePosition + MDF4Constants.BLOCK_HEADER_SIZE + linkIndex * MDF4Constants.LINK_SIZE;
        file.seek(linkPosition);
        file.writeLong(targetPosition);
    }
    
    // Getters and Setters
    
    public String getBlockId() {
        return blockId;
    }
    
    public long getBlockSize() {
        return blockSize;
    }
    
    public long getLinksCount() {
        return linksCount;
    }
    
    public long getFilePosition() {
        return filePosition;
    }
    
    public ByteOrder getByteOrder() {
        return byteOrder;
    }
    
    public void setByteOrder(ByteOrder byteOrder) {
        this.byteOrder = byteOrder;
    }
}
