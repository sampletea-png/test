package com.mdf4.blocks;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

/**
 * MDF4 HD块（Header Block）
 * 包含文件的基本信息和指向其他块的链接
 * 
 * 链接（8个）：
 * - Link 0: DG块（第一个数据组）
 * - Link 1: TX块（文件注释）
 * - Link 2: FH块（文件历史）
 * - Link 3: CH块（通道层次）
 * - Link 4-7: 保留
 * 
 * 数据字段：
 * - 开始时间戳（纳秒，8字节）
 * - 时区偏移分钟数（2字节）
 * - 夏令时偏移分钟数（2字节）
 * - 时间标志（1字节）
 * - 保留（1字节）
 */
public class HDBlock extends MDF4Block {
    
    // 链接索引
    public static final int LINK_DG_FIRST = 0;
    public static final int LINK_TX_COMMENT = 1;
    public static final int LINK_FH_FIRST = 2;
    public static final int LINK_CH_FIRST = 3;
    
    // 数据字段
    private long startTimeNs;      // 开始时间戳（纳秒）
    private short timeZoneOffset;  // 时区偏移（分钟）
    private short dstOffset;       // 夏令时偏移（分钟）
    private byte timeFlags;        // 时间标志
    private byte reserved;         // 保留
    
    /**
     * 构造函数
     */
    public HDBlock() {
        super(MDF4Constants.BLOCK_ID_HD, 8);
        this.startTimeNs = System.nanoTime();
        this.timeZoneOffset = 0;
        this.dstOffset = 0;
        this.timeFlags = 0;
        this.reserved = 0;
    }
    
    /**
     * 构造函数（指定时间）
     * @param startTimeNs 开始时间戳（纳秒）
     */
    public HDBlock(long startTimeNs) {
        super(MDF4Constants.BLOCK_ID_HD, 8);
        this.startTimeNs = startTimeNs;
        this.timeZoneOffset = 0;
        this.dstOffset = 0;
        this.timeFlags = 0;
        this.reserved = 0;
    }
    
    /**
     * 设置开始时间为当前时间
     */
    public void setStartTimeToNow() {
        this.startTimeNs = System.nanoTime();
    }
    
    /**
     * 设置开始时间为Unix时间戳
     * @param unixTimeMs Unix时间戳（毫秒）
     */
    public void setStartTimeFromUnix(long unixTimeMs) {
        this.startTimeNs = unixTimeMs * MDF4Constants.NS_PER_MS;
    }
    
    @Override
    public long getTotalSize() {
        // 块头 + 链接 + 数据字段
        return getHeaderSize() + 16; // 16字节数据
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 开始时间戳（8字节）
        file.writeLong(startTimeNs);
        
        // 时区偏移（2字节）
        file.writeShort(timeZoneOffset);
        
        // 夏令时偏移（2字节）
        file.writeShort(dstOffset);
        
        // 时间标志（1字节）
        file.writeByte(timeFlags);
        
        // 保留（1字节）
        file.writeByte(reserved);
    }
    
    /**
     * 设置第一个DG块链接
     * @param dgPosition DG块位置
     */
    public void setFirstDGBlock(long dgPosition) {
        setLink(LINK_DG_FIRST, dgPosition);
    }
    
    /**
     * 获取第一个DG块链接
     * @return DG块位置
     */
    public long getFirstDGBlock() {
        return getLink(LINK_DG_FIRST);
    }
    
    /**
     * 设置注释块链接
     * @param txPosition TX块位置
     */
    public void setCommentBlock(long txPosition) {
        setLink(LINK_TX_COMMENT, txPosition);
    }
    
    /**
     * 设置文件历史块链接
     * @param fhPosition FH块位置
     */
    public void setFileHistoryBlock(long fhPosition) {
        setLink(LINK_FH_FIRST, fhPosition);
    }
    
    // Getters and Setters
    
    public long getStartTimeNs() {
        return startTimeNs;
    }
    
    public void setStartTimeNs(long startTimeNs) {
        this.startTimeNs = startTimeNs;
    }
    
    public short getTimeZoneOffset() {
        return timeZoneOffset;
    }
    
    public void setTimeZoneOffset(short timeZoneOffset) {
        this.timeZoneOffset = timeZoneOffset;
    }
    
    public short getDstOffset() {
        return dstOffset;
    }
    
    public void setDstOffset(short dstOffset) {
        this.dstOffset = dstOffset;
    }
    
    public byte getTimeFlags() {
        return timeFlags;
    }
    
    public void setTimeFlags(byte timeFlags) {
        this.timeFlags = timeFlags;
    }
}
