package com.mdf4.channel;

import com.mdf4.core.DataType;
import com.mdf4.core.MDF4Constants;

/**
 * 通道配置类
 * 定义通道的完整配置信息
 */
public class ChannelConfig {
    
    // 基本属性
    private String name;                 // 通道名称
    private String description;          // 通道描述
    private String unit;                 // 单位
    private DataType dataType;           // 数据类型
    
    // 数据布局
    private int byteOffset;              // 字节偏移
    private byte bitOffset;              // 位偏移
    private int bitCount;                // 位数量
    
    // 通道类型
    private byte channelType;            // 通道类型
    private byte syncType;               // 同步类型
    
    // 数值范围
    private double minValue;             // 最小值
    private double maxValue;             // 最大值
    private double lowerLimit;           // 下限
    private double upperLimit;           // 上限
    
    // 转换信息
    private double factor;               // 比例因子
    private double offset;               // 偏移量
    private boolean hasConversion;       // 是否有转换
    
    // 精度
    private byte precision;              // 小数位数
    
    // 标志
    private int flags;                   // 通道标志
    
    // 源信息
    private String sourceName;           // 源名称
    private String sourcePath;           // 源路径
    
    /**
     * 构造函数
     */
    public ChannelConfig() {
        this.name = "";
        this.description = "";
        this.unit = "";
        this.dataType = DataType.DOUBLE;
        this.byteOffset = 0;
        this.bitOffset = 0;
        this.bitCount = 64;
        this.channelType = MDF4Constants.CHANNEL_TYPE_FIXED_LENGTH;
        this.syncType = MDF4Constants.SYNC_TYPE_NONE;
        this.minValue = 0;
        this.maxValue = 0;
        this.lowerLimit = 0;
        this.upperLimit = 0;
        this.factor = 1.0;
        this.offset = 0.0;
        this.hasConversion = false;
        this.precision = 0;
        this.flags = 0;
        this.sourceName = "";
        this.sourcePath = "";
    }
    
    /**
     * 构造函数（指定名称和数据类型）
     * @param name 通道名称
     * @param dataType 数据类型
     */
    public ChannelConfig(String name, DataType dataType) {
        this();
        this.name = name != null ? name : "";
        this.dataType = dataType != null ? dataType : DataType.DOUBLE;
        this.bitCount = this.dataType.getSize() * 8;
    }
    
    /**
     * 创建时间通道配置
     * @param name 通道名称
     * @return 时间通道配置
     */
    public static ChannelConfig createTimeChannel(String name) {
        ChannelConfig config = new ChannelConfig(name, DataType.DOUBLE);
        config.setChannelType(MDF4Constants.CHANNEL_TYPE_MASTER);
        config.setSyncType(MDF4Constants.SYNC_TYPE_TIME);
        config.setUnit("s");
        config.setDescription("Time channel");
        return config;
    }
    
    /**
     * 创建数值通道配置
     * @param name 通道名称
     * @param dataType 数据类型
     * @param unit 单位
     * @return 数值通道配置
     */
    public static ChannelConfig createValueChannel(String name, DataType dataType, String unit) {
        ChannelConfig config = new ChannelConfig(name, dataType);
        config.setUnit(unit != null ? unit : "");
        return config;
    }
    
    /**
     * 获取数据大小（字节）
     * @return 数据大小
     */
    public int getDataSize() {
        return dataType.getSize();
    }
    
    /**
     * 计算位数量
     * @return 位数量
     */
    public int calculateBitCount() {
        return dataType.getSize() * 8;
    }
    
    /**
     * 设置线性转换
     * @param factor 比例因子
     * @param offset 偏移量
     */
    public void setLinearConversion(double factor, double offset) {
        this.factor = factor;
        this.offset = offset;
        this.hasConversion = true;
    }
    
    /**
     * 应用转换
     * @param rawValue 原始值
     * @return 转换后的值
     */
    public double applyConversion(double rawValue) {
        if (!hasConversion) {
            return rawValue;
        }
        return rawValue * factor + offset;
    }
    
    /**
     * 反向转换
     * @param convertedValue 转换后的值
     * @return 原始值
     */
    public double reverseConversion(double convertedValue) {
        if (!hasConversion) {
            return convertedValue;
        }
        return (convertedValue - offset) / factor;
    }
    
    /**
     * 设置为主通道
     */
    public void setAsMasterChannel() {
        this.channelType = MDF4Constants.CHANNEL_TYPE_MASTER;
    }
    
    /**
     * 设置为时间通道
     */
    public void setAsTimeChannel() {
        setAsMasterChannel();
        this.syncType = MDF4Constants.SYNC_TYPE_TIME;
        this.unit = "s";
    }
    
    /**
     * 检查是否为主通道
     * @return true如果是主通道
     */
    public boolean isMasterChannel() {
        return channelType == MDF4Constants.CHANNEL_TYPE_MASTER ||
               channelType == MDF4Constants.CHANNEL_TYPE_VIRTUAL_MASTER;
    }
    
    /**
     * 检查是否为时间通道
     * @return true如果是时间通道
     */
    public boolean isTimeChannel() {
        return isMasterChannel() && syncType == MDF4Constants.SYNC_TYPE_TIME;
    }
    
    // Getters and Setters
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description != null ? description : "";
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit != null ? unit : "";
    }
    
    public DataType getDataType() {
        return dataType;
    }
    
    public void setDataType(DataType dataType) {
        this.dataType = dataType != null ? dataType : DataType.DOUBLE;
        this.bitCount = this.dataType.getSize() * 8;
    }
    
    public int getByteOffset() {
        return byteOffset;
    }
    
    public void setByteOffset(int byteOffset) {
        this.byteOffset = byteOffset;
    }
    
    public byte getBitOffset() {
        return bitOffset;
    }
    
    public void setBitOffset(byte bitOffset) {
        this.bitOffset = bitOffset;
    }
    
    public int getBitCount() {
        return bitCount;
    }
    
    public void setBitCount(int bitCount) {
        this.bitCount = bitCount;
    }
    
    public byte getChannelType() {
        return channelType;
    }
    
    public void setChannelType(byte channelType) {
        this.channelType = channelType;
    }
    
    public byte getSyncType() {
        return syncType;
    }
    
    public void setSyncType(byte syncType) {
        this.syncType = syncType;
    }
    
    public double getMinValue() {
        return minValue;
    }
    
    public void setMinValue(double minValue) {
        this.minValue = minValue;
    }
    
    public double getMaxValue() {
        return maxValue;
    }
    
    public void setMaxValue(double maxValue) {
        this.maxValue = maxValue;
    }
    
    public double getLowerLimit() {
        return lowerLimit;
    }
    
    public void setLowerLimit(double lowerLimit) {
        this.lowerLimit = lowerLimit;
    }
    
    public double getUpperLimit() {
        return upperLimit;
    }
    
    public void setUpperLimit(double upperLimit) {
        this.upperLimit = upperLimit;
    }
    
    public double getFactor() {
        return factor;
    }
    
    public void setFactor(double factor) {
        this.factor = factor;
    }
    
    public double getOffset() {
        return offset;
    }
    
    public void setOffset(double offset) {
        this.offset = offset;
    }
    
    public boolean isHasConversion() {
        return hasConversion;
    }
    
    public void setHasConversion(boolean hasConversion) {
        this.hasConversion = hasConversion;
    }
    
    public byte getPrecision() {
        return precision;
    }
    
    public void setPrecision(byte precision) {
        this.precision = precision;
    }
    
    public int getFlags() {
        return flags;
    }
    
    public void setFlags(int flags) {
        this.flags = flags;
    }
    
    public String getSourceName() {
        return sourceName;
    }
    
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName != null ? sourceName : "";
    }
    
    public String getSourcePath() {
        return sourcePath;
    }
    
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath != null ? sourcePath : "";
    }
    
    @Override
    public String toString() {
        return "ChannelConfig{" +
                "name='" + name + '\'' +
                ", dataType=" + dataType +
                ", unit='" + unit + '\'' +
                ", byteOffset=" + byteOffset +
                ", dataSize=" + getDataSize() +
                '}';
    }
}
