package com.mdf4.channel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 通道组配置类
 * 管理一组相关的通道配置
 */
public class ChannelGroupConfig {
    
    // 基本属性
    private String name;                     // 通道组名称
    private String description;              // 通道组描述
    private long recordId;                   // 记录ID
    
    // 通道列表
    private List<ChannelConfig> channels;    // 通道配置列表
    
    // 记录信息
    private int recordSize;                  // 记录大小（字节）
    private long recordCount;                // 记录数量
    
    // 标志
    private int flags;                       // 通道组标志
    
    // 路径分隔符
    private byte pathSeparator;              // 路径分隔符
    
    // 动态添加支持
    private boolean allowDynamicChannels;    // 是否允许动态添加通道
    private boolean isSealed;                // 是否已密封（不再允许修改）
    
    /**
     * 构造函数
     */
    public ChannelGroupConfig() {
        this.name = "";
        this.description = "";
        this.recordId = 0;
        this.channels = new CopyOnWriteArrayList<>(); // 线程安全
        this.recordSize = 0;
        this.recordCount = 0;
        this.flags = 0;
        this.pathSeparator = (byte) '.';
        this.allowDynamicChannels = true;
        this.isSealed = false;
    }
    
    /**
     * 构造函数（指定名称）
     * @param name 通道组名称
     */
    public ChannelGroupConfig(String name) {
        this();
        this.name = name != null ? name : "";
    }
    
    /**
     * 添加通道
     * @param channel 通道配置
     * @return 通道字节偏移
     */
    public int addChannel(ChannelConfig channel) {
        if (isSealed) {
            throw new IllegalStateException("Channel group is sealed, cannot add channels");
        }
        if (channel == null) {
            throw new IllegalArgumentException("Channel config cannot be null");
        }
        
        // 计算字节偏移
        int byteOffset = recordSize;
        channel.setByteOffset(byteOffset);
        
        // 添加通道
        channels.add(channel);
        
        // 更新记录大小
        recordSize += channel.getDataSize();
        
        return byteOffset;
    }
    
    /**
     * 批量添加通道
     * @param channelsToAdd 通道配置列表
     */
    public void addChannels(List<ChannelConfig> channelsToAdd) {
        if (channelsToAdd == null) {
            return;
        }
        for (ChannelConfig channel : channelsToAdd) {
            addChannel(channel);
        }
    }
    
    /**
     * 插入通道（在指定位置）
     * @param index 插入位置
     * @param channel 通道配置
     * @return 通道字节偏移
     */
    public int insertChannel(int index, ChannelConfig channel) {
        if (isSealed) {
            throw new IllegalStateException("Channel group is sealed, cannot insert channels");
        }
        if (channel == null) {
            throw new IllegalArgumentException("Channel config cannot be null");
        }
        if (index < 0 || index > channels.size()) {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }
        
        // 计算字节偏移
        int byteOffset = 0;
        for (int i = 0; i < index; i++) {
            byteOffset += channels.get(i).getDataSize();
        }
        channel.setByteOffset(byteOffset);
        
        // 插入通道
        channels.add(index, channel);
        
        // 重新计算后续通道的偏移
        recalculateOffsets();
        
        return byteOffset;
    }
    
    /**
     * 移除通道
     * @param channel 通道配置
     * @return 是否成功移除
     */
    public boolean removeChannel(ChannelConfig channel) {
        if (isSealed) {
            throw new IllegalStateException("Channel group is sealed, cannot remove channels");
        }
        boolean removed = channels.remove(channel);
        if (removed) {
            recalculateOffsets();
        }
        return removed;
    }
    
    /**
     * 移除通道（按名称）
     * @param channelName 通道名称
     * @return 是否成功移除
     */
    public boolean removeChannel(String channelName) {
        if (channelName == null) {
            return false;
        }
        for (ChannelConfig channel : channels) {
            if (channelName.equals(channel.getName())) {
                return removeChannel(channel);
            }
        }
        return false;
    }
    
    /**
     * 获取通道
     * @param index 通道索引
     * @return 通道配置
     */
    public ChannelConfig getChannel(int index) {
        return channels.get(index);
    }
    
    /**
     * 获取通道（按名称）
     * @param channelName 通道名称
     * @return 通道配置，未找到返回null
     */
    public ChannelConfig getChannel(String channelName) {
        if (channelName == null) {
            return null;
        }
        for (ChannelConfig channel : channels) {
            if (channelName.equals(channel.getName())) {
                return channel;
            }
        }
        return null;
    }
    
    /**
     * 获取通道索引
     * @param channelName 通道名称
     * @return 通道索引，未找到返回-1
     */
    public int getChannelIndex(String channelName) {
        if (channelName == null) {
            return -1;
        }
        for (int i = 0; i < channels.size(); i++) {
            if (channelName.equals(channels.get(i).getName())) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * 检查是否包含通道
     * @param channelName 通道名称
     * @return true如果包含
     */
    public boolean hasChannel(String channelName) {
        return getChannel(channelName) != null;
    }
    
    /**
     * 获取通道数量
     * @return 通道数量
     */
    public int getChannelCount() {
        return channels.size();
    }
    
    /**
     * 获取所有通道
     * @return 通道配置列表（不可修改视图）
     */
    public List<ChannelConfig> getChannels() {
        return Collections.unmodifiableList(channels);
    }
    
    /**
     * 重新计算通道偏移
     */
    private void recalculateOffsets() {
        recordSize = 0;
        for (ChannelConfig channel : channels) {
            channel.setByteOffset(recordSize);
            recordSize += channel.getDataSize();
        }
    }
    
    /**
     * 密封通道组（不再允许修改）
     */
    public void seal() {
        this.isSealed = true;
    }
    
    /**
     * 解封通道组
     */
    public void unseal() {
        this.isSealed = false;
    }
    
    /**
     * 检查是否已密封
     * @return true如果已密封
     */
    public boolean isSealed() {
        return isSealed;
    }
    
    /**
     * 增加记录计数
     */
    public void incrementRecordCount() {
        this.recordCount++;
    }
    
    /**
     * 增加记录计数（指定数量）
     * @param count 增加数量
     */
    public void incrementRecordCount(long count) {
        this.recordCount += count;
    }
    
    /**
     * 获取主通道
     * @return 主通道配置，未找到返回null
     */
    public ChannelConfig getMasterChannel() {
        for (ChannelConfig channel : channels) {
            if (channel.isMasterChannel()) {
                return channel;
            }
        }
        return null;
    }
    
    /**
     * 获取时间通道
     * @return 时间通道配置，未找到返回null
     */
    public ChannelConfig getTimeChannel() {
        for (ChannelConfig channel : channels) {
            if (channel.isTimeChannel()) {
                return channel;
            }
        }
        return null;
    }
    
    /**
     * 创建默认时间通道
     * @return 时间通道配置
     */
    public ChannelConfig createDefaultTimeChannel() {
        ChannelConfig timeChannel = ChannelConfig.createTimeChannel("Time");
        addChannel(timeChannel);
        return timeChannel;
    }
    
    // Getters and Setters
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description != null ? description : "";
    }
    
    public long getRecordId() {
        return recordId;
    }
    
    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }
    
    public int getRecordSize() {
        return recordSize;
    }
    
    public long getRecordCount() {
        return recordCount;
    }
    
    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }
    
    public int getFlags() {
        return flags;
    }
    
    public void setFlags(int flags) {
        this.flags = flags;
    }
    
    public byte getPathSeparator() {
        return pathSeparator;
    }
    
    public void setPathSeparator(byte pathSeparator) {
        this.pathSeparator = pathSeparator;
    }
    
    public boolean isAllowDynamicChannels() {
        return allowDynamicChannels;
    }
    
    public void setAllowDynamicChannels(boolean allowDynamicChannels) {
        this.allowDynamicChannels = allowDynamicChannels;
    }
    
    @Override
    public String toString() {
        return "ChannelGroupConfig{" +
                "name='" + name + '\'' +
                ", channels=" + channels.size() +
                ", recordSize=" + recordSize +
                ", recordCount=" + recordCount +
                '}';
    }
}
