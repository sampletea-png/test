package com.mdf4.example;

import com.mdf4.channel.ChannelConfig;
import com.mdf4.channel.ChannelGroupConfig;
import com.mdf4.core.DataType;
import com.mdf4.writer.MDF4Writer;
import com.mdf4.writer.RecordBuilder;

import java.io.IOException;

/**
 * MDF4写入器高级用法示例
 */
public class AdvancedExample {
    
    public static void main(String[] args) {
        System.out.println("=== MDF4 Advanced Examples ===\n");
        
        // RecordBuilder示例
        recordBuilderExample();
        
        // 性能测试示例
        performanceTest();
        
        // 多线程写入示例（概念）
        multiThreadExample();
        
        System.out.println("\n=== All advanced examples completed ===");
    }
    
    /**
     * RecordBuilder使用示例
     */
    private static void recordBuilderExample() {
        System.out.println("--- RecordBuilder Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_builder.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            System.out.println("Created file: " + filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("BuilderTest");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("X", DataType.DOUBLE, "m"));
            writer.addChannel(ChannelConfig.createValueChannel("Y", DataType.DOUBLE, "m"));
            writer.addChannel(ChannelConfig.createValueChannel("Z", DataType.DOUBLE, "m"));
            writer.addChannel(ChannelConfig.createValueChannel("Status", DataType.INT32, ""));
            writer.sealCurrentChannelGroup();
            
            // 创建RecordBuilder
            RecordBuilder builder = new RecordBuilder(cg);
            
            // 使用Builder写入数据
            System.out.println("Writing 100 records using RecordBuilder...");
            for (int i = 0; i < 100; i++) {
                double time = i * 0.01;
                
                // 方式1：链式调用
                builder.clear()
                       .setTime(time)
                       .setDouble("X", Math.sin(time * 10))
                       .setDouble("Y", Math.cos(time * 10))
                       .setDouble("Z", Math.sin(time * 5) * Math.cos(time * 5))
                       .setInt("Status", i % 4);
                
                // 写入数据
                writer.writeRecord(builder.buildArray());
                
                // 每20条打印状态
                if ((i + 1) % 20 == 0) {
                    System.out.println("  Record " + (i + 1) + ": " + builder);
                }
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 性能测试示例
     */
    private static void performanceTest() {
        System.out.println("--- Performance Test ---");
        
        String filePath = "/mnt/okcomputer/output/test_performance.mf4";
        
        // 测试不同配置
        testConfiguration("Sync + 1MB Buffer", filePath, false, 1024 * 1024);
        testConfiguration("Async + 1MB Buffer", filePath, true, 1024 * 1024);
        testConfiguration("Async + 4MB Buffer", filePath, true, 4 * 1024 * 1024);
        
        System.out.println();
    }
    
    /**
     * 测试特定配置
     */
    private static void testConfiguration(String name, String filePath, 
                                          boolean async, int bufferSize) {
        System.out.println("\nConfiguration: " + name);
        
        String testFile = filePath.replace(".mf4", "_" + name.replace(" ", "_") + ".mf4");
        
        MDF4Writer.WriterConfig config = new MDF4Writer.WriterConfig();
        config.setUseAsyncWrite(async);
        config.setBufferSize(bufferSize);
        
        try (MDF4Writer writer = new MDF4Writer(config)) {
            writer.open(testFile);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("PerfTest");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal1", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal2", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal3", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal4", DataType.DOUBLE, "V"));
            writer.sealCurrentChannelGroup();
            
            // 写入50万条记录
            int recordCount = 500_000;
            
            long startTime = System.currentTimeMillis();
            
            for (int i = 0; i < recordCount; i++) {
                double time = i * 0.001;
                writer.writeRecord(
                    time,
                    Math.sin(2 * Math.PI * 10 * time),
                    Math.sin(2 * Math.PI * 50 * time),
                    Math.sin(2 * Math.PI * 100 * time),
                    Math.sin(2 * Math.PI * 200 * time)
                );
            }
            
            long elapsedMs = System.currentTimeMillis() - startTime;
            double recordsPerSecond = recordCount * 1000.0 / elapsedMs;
            double mbPerSecond = writer.getTotalBytesWritten() * 1000.0 / elapsedMs / 1024 / 1024;
            
            System.out.println("  Records: " + recordCount);
            System.out.println("  Time: " + elapsedMs + " ms");
            System.out.println("  Speed: " + String.format("%.0f", recordsPerSecond) + " records/s");
            System.out.println("  Throughput: " + String.format("%.2f", mbPerSecond) + " MB/s");
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    /**
     * 多线程写入示例（概念演示）
     */
    private static void multiThreadExample() {
        System.out.println("--- Multi-Thread Example (Concept) ---");
        
        System.out.println("Note: This is a conceptual example.");
        System.out.println("For actual multi-threaded writing, consider:");
        System.out.println("  1. Using separate MDF4Writer instances per thread");
        System.out.println("  2. Using a thread-safe queue for data buffering");
        System.out.println("  3. Merging files after parallel writing");
        System.out.println();
        
        String filePath = "/mnt/okcomputer/output/test_multithread.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("MultiThread");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("Thread1", DataType.DOUBLE, ""));
            writer.addChannel(ChannelConfig.createValueChannel("Thread2", DataType.DOUBLE, ""));
            writer.addChannel(ChannelConfig.createValueChannel("Thread3", DataType.DOUBLE, ""));
            writer.sealCurrentChannelGroup();
            
            // 模拟多线程数据
            System.out.println("Simulating multi-threaded data...");
            for (int i = 0; i < 1000; i++) {
                double time = i * 0.001;
                writer.writeRecord(
                    time,
                    Math.sin(2 * Math.PI * 10 * time),   // Thread1 data
                    Math.sin(2 * Math.PI * 20 * time),   // Thread2 data
                    Math.sin(2 * Math.PI * 30 * time)    // Thread3 data
                );
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 实时数据流示例
     */
    private static void streamingExample() {
        System.out.println("--- Streaming Data Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_streaming.mf4";
        
        // 使用异步写入配置
        MDF4Writer.WriterConfig config = new MDF4Writer.WriterConfig();
        config.setUseAsyncWrite(true);
        config.setBufferSize(2 * 1024 * 1024); // 2MB缓冲区
        config.setAsyncQueueSize(2000);
        
        try (MDF4Writer writer = new MDF4Writer(config)) {
            writer.open(filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("Streaming");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("Sensor1", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Sensor2", DataType.DOUBLE, "V"));
            writer.sealCurrentChannelGroup();
            
            // 模拟实时数据流
            System.out.println("Simulating real-time data stream...");
            long startTime = System.currentTimeMillis();
            
            for (int i = 0; i < 10000; i++) {
                double time = (System.currentTimeMillis() - startTime) / 1000.0;
                
                writer.writeRecord(
                    time,
                    Math.sin(time * 10) + Math.random() * 0.1,  // Sensor1 with noise
                    Math.cos(time * 10) + Math.random() * 0.1   // Sensor2 with noise
                );
                
                // 模拟10ms采样间隔
                if (i % 100 == 0) {
                    Thread.sleep(1);
                }
            }
            
            System.out.println("Streaming completed: " + writer.getStatistics());
            
        } catch (IOException | InterruptedException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
}
