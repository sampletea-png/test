package com.mdf4.example;

import com.mdf4.channel.ChannelConfig;
import com.mdf4.channel.ChannelGroupConfig;
import com.mdf4.core.DataType;
import com.mdf4.writer.MDF4Writer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * MDF4写入器使用示例
 */
public class MDF4Example {
    
    public static void main(String[] args) {
        System.out.println("=== MDF4 Writer Example ===\n");
        
        // 示例1：基本用法
        basicExample();
        
        // 示例2：多通道组
        multiChannelGroupExample();
        
        // 示例3：大数据量写入
        largeDataExample();
        
        // 示例4：动态通道
        dynamicChannelExample();
        
        System.out.println("\n=== All examples completed ===");
    }
    
    /**
     * 基本用法示例
     */
    private static void basicExample() {
        System.out.println("--- Basic Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_basic.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            // 打开文件
            writer.open(filePath);
            System.out.println("Created file: " + filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("Measurement");
            System.out.println("Created channel group: " + cg.getName());
            
            // 添加时间通道
            ChannelConfig timeChannel = ChannelConfig.createTimeChannel("Time");
            writer.addChannel(timeChannel);
            System.out.println("Added time channel");
            
            // 添加数值通道
            ChannelConfig speedChannel = ChannelConfig.createValueChannel("Speed", DataType.DOUBLE, "km/h");
            writer.addChannel(speedChannel);
            System.out.println("Added speed channel");
            
            ChannelConfig tempChannel = ChannelConfig.createValueChannel("Temperature", DataType.DOUBLE, "C");
            writer.addChannel(tempChannel);
            System.out.println("Added temperature channel");
            
            // 密封通道组
            writer.sealCurrentChannelGroup();
            System.out.println("Sealed channel group");
            
            // 写入数据
            System.out.println("Writing 100 records...");
            for (int i = 0; i < 100; i++) {
                double time = i * 0.01; // 10ms间隔
                double speed = 50 + 20 * Math.sin(time * 2 * Math.PI); // 正弦波
                double temperature = 25 + 5 * Math.cos(time * Math.PI); // 余弦波
                
                writer.writeRecord(time, speed, temperature);
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 多通道组示例
     */
    private static void multiChannelGroupExample() {
        System.out.println("--- Multi Channel Group Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_multi_cg.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            System.out.println("Created file: " + filePath);
            
            // 第一个通道组 - 发动机数据
            ChannelGroupConfig engineCG = writer.createChannelGroup("Engine");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("RPM", DataType.INT32, "rpm"));
            writer.addChannel(ChannelConfig.createValueChannel("Torque", DataType.DOUBLE, "Nm"));
            writer.sealCurrentChannelGroup();
            System.out.println("Created 'Engine' channel group with 3 channels");
            
            // 第二个通道组 - 车辆数据
            ChannelGroupConfig vehicleCG = writer.createChannelGroup("Vehicle");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("Speed", DataType.DOUBLE, "km/h"));
            writer.addChannel(ChannelConfig.createValueChannel("Acceleration", DataType.DOUBLE, "m/s^2"));
            writer.addChannel(ChannelConfig.createValueChannel("BrakePressure", DataType.DOUBLE, "bar"));
            writer.sealCurrentChannelGroup();
            System.out.println("Created 'Vehicle' channel group with 4 channels");
            
            // 写入发动机数据
            System.out.println("Writing engine data...");
            for (int i = 0; i < 50; i++) {
                double time = i * 0.1;
                int rpm = 1000 + (int) (3000 * Math.sin(time));
                double torque = 100 + 50 * Math.cos(time * 2);
                writer.writeRecord(time, rpm, torque);
            }
            
            // 写入车辆数据
            System.out.println("Writing vehicle data...");
            for (int i = 0; i < 50; i++) {
                double time = i * 0.1;
                double speed = 60 + 20 * Math.sin(time);
                double acceleration = 2 * Math.cos(time * 2);
                double brakePressure = Math.max(0, -acceleration * 10);
                writer.writeRecord(time, speed, acceleration, brakePressure);
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 大数据量写入示例
     */
    private static void largeDataExample() {
        System.out.println("--- Large Data Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_large.mf4";
        
        // 配置写入器
        MDF4Writer.WriterConfig config = new MDF4Writer.WriterConfig();
        config.setBufferSize(1024 * 1024); // 1MB缓冲区
        config.setUseAsyncWrite(true); // 启用异步写入
        
        try (MDF4Writer writer = new MDF4Writer(config)) {
            writer.open(filePath);
            System.out.println("Created file: " + filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("HighFrequency");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal1", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal2", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal3", DataType.DOUBLE, "V"));
            writer.addChannel(ChannelConfig.createValueChannel("Signal4", DataType.DOUBLE, "V"));
            writer.sealCurrentChannelGroup();
            System.out.println("Created channel group with 5 channels");
            
            // 写入大量数据（100,000条记录）
            int recordCount = 100_000;
            System.out.println("Writing " + recordCount + " records...");
            
            long startTime = System.currentTimeMillis();
            
            for (int i = 0; i < recordCount; i++) {
                double time = i * 0.001; // 1ms采样率
                double signal1 = Math.sin(2 * Math.PI * 10 * time); // 10Hz
                double signal2 = Math.sin(2 * Math.PI * 50 * time); // 50Hz
                double signal3 = Math.sin(2 * Math.PI * 100 * time); // 100Hz
                double signal4 = Math.sin(2 * Math.PI * 200 * time); // 200Hz
                
                writer.writeRecord(time, signal1, signal2, signal3, signal4);
                
                // 每10000条记录打印进度
                if ((i + 1) % 10000 == 0) {
                    System.out.println("  Progress: " + (i + 1) + " / " + recordCount);
                }
            }
            
            long elapsedMs = System.currentTimeMillis() - startTime;
            System.out.println("Write completed in " + elapsedMs + " ms");
            System.out.println("Statistics: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 动态通道示例
     */
    private static void dynamicChannelExample() {
        System.out.println("--- Dynamic Channel Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_dynamic.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            System.out.println("Created file: " + filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("Dynamic");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("BaseSignal", DataType.DOUBLE, "V"));
            writer.sealCurrentChannelGroup();
            System.out.println("Created channel group with 2 channels");
            
            // 写入初始数据
            System.out.println("Writing initial data...");
            for (int i = 0; i < 50; i++) {
                double time = i * 0.01;
                double baseSignal = Math.sin(time * 10);
                writer.writeRecord(time, baseSignal);
            }
            
            // 注意：实际动态添加通道需要在通道组未密封时进行
            // 这里演示的是概念
            System.out.println("Note: Dynamic channel addition requires unsealed channel group");
            System.out.println("This example demonstrates the concept");
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println();
    }
    
    /**
     * 使用Map写入示例
     */
    private static void mapWriteExample() {
        System.out.println("--- Map Write Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_map.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("MapData");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(ChannelConfig.createValueChannel("X", DataType.DOUBLE, "m"));
            writer.addChannel(ChannelConfig.createValueChannel("Y", DataType.DOUBLE, "m"));
            writer.addChannel(ChannelConfig.createValueChannel("Z", DataType.DOUBLE, "m"));
            writer.sealCurrentChannelGroup();
            
            // 使用Map写入
            Map<String, Object> values = new HashMap<>();
            for (int i = 0; i < 100; i++) {
                values.put("Time", i * 0.01);
                values.put("X", Math.sin(i * 0.1));
                values.put("Y", Math.cos(i * 0.1));
                values.put("Z", Math.sin(i * 0.05) * Math.cos(i * 0.05));
                
                writer.writeRecord(values);
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 不同数据类型示例
     */
    private static void dataTypesExample() {
        System.out.println("--- Data Types Example ---");
        
        String filePath = "/mnt/okcomputer/output/test_types.mf4";
        
        try (MDF4Writer writer = new MDF4Writer()) {
            writer.open(filePath);
            
            // 创建通道组
            ChannelGroupConfig cg = writer.createChannelGroup("Types");
            writer.addChannel(ChannelConfig.createTimeChannel("Time"));
            writer.addChannel(new ChannelConfig("Int8Val", DataType.INT8));
            writer.addChannel(new ChannelConfig("Int16Val", DataType.INT16));
            writer.addChannel(new ChannelConfig("Int32Val", DataType.INT32));
            writer.addChannel(new ChannelConfig("FloatVal", DataType.FLOAT));
            writer.addChannel(new ChannelConfig("DoubleVal", DataType.DOUBLE));
            writer.addChannel(new ChannelConfig("BoolVal", DataType.BOOLEAN));
            writer.sealCurrentChannelGroup();
            
            // 写入不同数据类型
            for (int i = 0; i < 100; i++) {
                writer.writeRecord(
                    i * 0.01,           // Time (double)
                    (byte) (i % 128),   // Int8
                    (short) (i * 10),   // Int16
                    i * 100,            // Int32
                    (float) (i * 0.1f), // Float
                    i * 0.001,          // Double
                    i % 2 == 0          // Boolean
                );
            }
            
            System.out.println("Write completed: " + writer.getStatistics());
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
