package com.mdf4.buffer;

import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 异步写入管理器
 * 管理后台写入线程，支持异步写入和批量处理
 */
public class AsyncWriteManager {
    
    // 写入任务队列
    private final BlockingQueue<WriteTask> writeQueue;
    
    // 执行器服务
    private final ExecutorService executorService;
    
    // 写入线程
    private final Thread writeThread;
    
    // 运行状态
    private final AtomicBoolean isRunning;
    
    // 统计信息
    private final AtomicLong totalTasksSubmitted;
    private final AtomicLong totalTasksCompleted;
    private final AtomicLong totalTasksFailed;
    private final AtomicLong totalBytesWritten;
    
    // 写入处理器
    private WriteHandler writeHandler;
    
    // 队列容量
    private final int queueCapacity;
    
    // 批量大小
    private final int batchSize;
    
    // 刷新间隔（毫秒）
    private final long flushIntervalMs;
    
    /**
     * 写入任务
     */
    public static class WriteTask {
        private final byte[] data;
        private final long timestamp;
        private final CompletableFuture<Void> future;
        
        public WriteTask(byte[] data) {
            this.data = data;
            this.timestamp = System.nanoTime();
            this.future = new CompletableFuture<>();
        }
        
        public byte[] getData() {
            return data;
        }
        
        public long getTimestamp() {
            return timestamp;
        }
        
        public CompletableFuture<Void> getFuture() {
            return future;
        }
    }
    
    /**
     * 写入处理器接口
     */
    @FunctionalInterface
    public interface WriteHandler {
        /**
         * 处理写入
         * @param data 数据
         * @throws IOException IO异常
         */
        void write(byte[] data) throws IOException;
    }
    
    /**
     * 构造函数（默认配置）
     */
    public AsyncWriteManager() {
        this(1000, 100, 100);
    }
    
    /**
     * 构造函数（指定配置）
     * @param queueCapacity 队列容量
     * @param batchSize 批量大小
     * @param flushIntervalMs 刷新间隔（毫秒）
     */
    public AsyncWriteManager(int queueCapacity, int batchSize, long flushIntervalMs) {
        this.queueCapacity = queueCapacity;
        this.batchSize = batchSize;
        this.flushIntervalMs = flushIntervalMs;
        
        this.writeQueue = new LinkedBlockingQueue<>(queueCapacity);
        this.executorService = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MDF4-AsyncWrite");
            t.setDaemon(true);
            return t;
        });
        
        this.isRunning = new AtomicBoolean(false);
        this.totalTasksSubmitted = new AtomicLong(0);
        this.totalTasksCompleted = new AtomicLong(0);
        this.totalTasksFailed = new AtomicLong(0);
        this.totalBytesWritten = new AtomicLong(0);
        
        this.writeThread = new Thread(this::writeLoop, "MDF4-WriteLoop");
        this.writeThread.setDaemon(true);
    }
    
    /**
     * 启动异步写入
     * @param handler 写入处理器
     */
    public void start(WriteHandler handler) {
        if (handler == null) {
            throw new IllegalArgumentException("Write handler cannot be null");
        }
        
        if (isRunning.compareAndSet(false, true)) {
            this.writeHandler = handler;
            writeThread.start();
        }
    }
    
    /**
     * 停止异步写入
     * @param waitForCompletion 是否等待完成
     * @param timeoutMs 超时时间（毫秒）
     * @return 是否成功停止
     */
    public boolean stop(boolean waitForCompletion, long timeoutMs) {
        if (!isRunning.compareAndSet(true, false)) {
            return true; // 已经停止
        }
        
        // 添加结束标记任务
        writeQueue.offer(new WriteTask(null) {
            @Override
            public byte[] getData() {
                return null; // 结束标记
            }
        });
        
        if (waitForCompletion) {
            try {
                writeThread.join(timeoutMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        
        executorService.shutdown();
        return true;
    }
    
    /**
     * 提交写入任务
     * @param data 数据
     * @return CompletableFuture
     * @throws IOException IO异常
     */
    public CompletableFuture<Void> submit(byte[] data) throws IOException {
        if (!isRunning.get()) {
            throw new IllegalStateException("Async write manager is not running");
        }
        
        WriteTask task = new WriteTask(data);
        
        if (!writeQueue.offer(task)) {
            // 队列已满，同步处理
            try {
                writeHandler.write(data);
                task.getFuture().complete(null);
                totalTasksCompleted.incrementAndGet();
                totalBytesWritten.addAndGet(data.length);
            } catch (IOException e) {
                task.getFuture().completeExceptionally(e);
                totalTasksFailed.incrementAndGet();
                throw e;
            }
        } else {
            totalTasksSubmitted.incrementAndGet();
        }
        
        return task.getFuture();
    }
    
    /**
     * 提交写入任务（不等待完成）
     * @param data 数据
     * @return 是否成功提交
     */
    public boolean submitAsync(byte[] data) {
        if (!isRunning.get()) {
            return false;
        }
        
        WriteTask task = new WriteTask(data);
        boolean offered = writeQueue.offer(task);
        
        if (offered) {
            totalTasksSubmitted.incrementAndGet();
        }
        
        return offered;
    }
    
    /**
     * 写入循环
     */
    private void writeLoop() {
        while (isRunning.get() || !writeQueue.isEmpty()) {
            try {
                // 批量收集任务
                WriteTask task = writeQueue.poll(flushIntervalMs, TimeUnit.MILLISECONDS);
                
                if (task == null) {
                    continue; // 超时，继续循环
                }
                
                // 检查结束标记
                if (task.getData() == null) {
                    break;
                }
                
                // 处理单个任务
                processTask(task);
                
                // 批量处理更多任务
                int batchCount = 1;
                while (batchCount < batchSize && (task = writeQueue.poll()) != null) {
                    if (task.getData() == null) {
                        break; // 结束标记
                    }
                    processTask(task);
                    batchCount++;
                }
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    /**
     * 处理单个任务
     * @param task 写入任务
     */
    private void processTask(WriteTask task) {
        try {
            byte[] data = task.getData();
            if (data != null && writeHandler != null) {
                writeHandler.write(data);
                totalBytesWritten.addAndGet(data.length);
            }
            task.getFuture().complete(null);
            totalTasksCompleted.incrementAndGet();
        } catch (IOException e) {
            task.getFuture().completeExceptionally(e);
            totalTasksFailed.incrementAndGet();
        }
    }
    
    /**
     * 等待队列为空
     * @param timeoutMs 超时时间（毫秒）
     * @return 是否成功
     */
    public boolean awaitEmpty(long timeoutMs) {
        long startTime = System.currentTimeMillis();
        while (!writeQueue.isEmpty()) {
            if (System.currentTimeMillis() - startTime > timeoutMs) {
                return false;
            }
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return true;
    }
    
    /**
     * 获取队列大小
     * @return 队列中的任务数
     */
    public int getQueueSize() {
        return writeQueue.size();
    }
    
    /**
     * 获取总提交任务数
     * @return 总提交任务数
     */
    public long getTotalTasksSubmitted() {
        return totalTasksSubmitted.get();
    }
    
    /**
     * 获取总完成任务数
     * @return 总完成任务数
     */
    public long getTotalTasksCompleted() {
        return totalTasksCompleted.get();
    }
    
    /**
     * 获取总失败任务数
     * @return 总失败任务数
     */
    public long getTotalTasksFailed() {
        return totalTasksFailed.get();
    }
    
    /**
     * 获取总写入字节数
     * @return 总写入字节数
     */
    public long getTotalBytesWritten() {
        return totalBytesWritten.get();
    }
    
    /**
     * 检查是否正在运行
     * @return true如果正在运行
     */
    public boolean isRunning() {
        return isRunning.get();
    }
    
    /**
     * 获取统计信息
     * @return 统计信息字符串
     */
    public String getStatistics() {
        return String.format(
            "AsyncWriteManager{queueSize=%d, submitted=%d, completed=%d, failed=%d, bytesWritten=%d}",
            getQueueSize(),
            getTotalTasksSubmitted(),
            getTotalTasksCompleted(),
            getTotalTasksFailed(),
            getTotalBytesWritten()
        );
    }
}
