package com.mdf4.buffer;

import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据缓冲区
 * 管理数据写入的缓冲区，支持批量写入和自动刷新
 */
public class DataBuffer {
    
    // 缓冲区
    private ByteBuffer buffer;
    
    // 缓冲区大小
    private final int capacity;
    
    // 字节序
    private final ByteOrder byteOrder;
    
    // 统计信息
    private final AtomicLong totalBytesWritten;
    private final AtomicLong totalFlushCount;
    
    // 回调接口
    private FlushCallback flushCallback;
    
    // 自动刷新阈值
    private final int autoFlushThreshold;
    
    // 是否自动刷新
    private final boolean autoFlush;
    
    /**
     * 刷新回调接口
     */
    @FunctionalInterface
    public interface FlushCallback {
        /**
         * 刷新缓冲区时调用
         * @param data 要刷新的数据
         * @throws IOException IO异常
         */
        void onFlush(byte[] data) throws IOException;
    }
    
    /**
     * 构造函数（默认大小）
     */
    public DataBuffer() {
        this(MDF4Constants.DEFAULT_BUFFER_SIZE, ByteOrder.LITTLE_ENDIAN);
    }
    
    /**
     * 构造函数（指定大小）
     * @param capacity 缓冲区容量
     */
    public DataBuffer(int capacity) {
        this(capacity, ByteOrder.LITTLE_ENDIAN);
    }
    
    /**
     * 构造函数（指定大小和字节序）
     * @param capacity 缓冲区容量
     * @param byteOrder 字节序
     */
    public DataBuffer(int capacity, ByteOrder byteOrder) {
        this.capacity = Math.max(capacity, 1024); // 最小1KB
        this.byteOrder = byteOrder;
        this.buffer = ByteBuffer.allocate(this.capacity);
        this.buffer.order(byteOrder);
        this.totalBytesWritten = new AtomicLong(0);
        this.totalFlushCount = new AtomicLong(0);
        this.autoFlush = true;
        this.autoFlushThreshold = (int) (this.capacity * 0.8); // 80%阈值
    }
    
    /**
     * 构造函数（完整参数）
     * @param capacity 缓冲区容量
     * @param byteOrder 字节序
     * @param autoFlush 是否自动刷新
     * @param autoFlushThreshold 自动刷新阈值
     */
    public DataBuffer(int capacity, ByteOrder byteOrder, boolean autoFlush, int autoFlushThreshold) {
        this.capacity = Math.max(capacity, 1024);
        this.byteOrder = byteOrder;
        this.buffer = ByteBuffer.allocate(this.capacity);
        this.buffer.order(byteOrder);
        this.totalBytesWritten = new AtomicLong(0);
        this.totalFlushCount = new AtomicLong(0);
        this.autoFlush = autoFlush;
        this.autoFlushThreshold = Math.min(autoFlushThreshold, this.capacity);
    }
    
    /**
     * 写入字节
     * @param b 字节
     * @return 写入的字节数
     * @throws IOException IO异常
     */
    public int write(byte b) throws IOException {
        ensureCapacity(1);
        buffer.put(b);
        totalBytesWritten.incrementAndGet();
        checkAutoFlush();
        return 1;
    }
    
    /**
     * 写入字节数组
     * @param data 数据
     * @return 写入的字节数
     * @throws IOException IO异常
     */
    public int write(byte[] data) throws IOException {
        return write(data, 0, data.length);
    }
    
    /**
     * 写入字节数组（指定范围）
     * @param data 数据
     * @param offset 偏移
     * @param length 长度
     * @return 写入的字节数
     * @throws IOException IO异常
     */
    public int write(byte[] data, int offset, int length) throws IOException {
        if (data == null || length <= 0) {
            return 0;
        }
        
        int written = 0;
        while (written < length) {
            int remaining = length - written;
            int available = buffer.remaining();
            
            if (available == 0) {
                flush();
                available = buffer.remaining();
            }
            
            int toWrite = Math.min(remaining, available);
            buffer.put(data, offset + written, toWrite);
            written += toWrite;
            totalBytesWritten.addAndGet(toWrite);
        }
        
        checkAutoFlush();
        return written;
    }
    
    /**
     * 写入ByteBuffer
     * @param src 源缓冲区
     * @return 写入的字节数
     * @throws IOException IO异常
     */
    public int write(ByteBuffer src) throws IOException {
        if (src == null || !src.hasRemaining()) {
            return 0;
        }
        
        int written = 0;
        while (src.hasRemaining()) {
            int available = buffer.remaining();
            
            if (available == 0) {
                flush();
                available = buffer.remaining();
            }
            
            int toWrite = Math.min(src.remaining(), available);
            
            // 保存原始限制
            int originalLimit = src.limit();
            src.limit(src.position() + toWrite);
            
            buffer.put(src);
            
            // 恢复原始限制
            src.limit(originalLimit);
            
            written += toWrite;
            totalBytesWritten.addAndGet(toWrite);
        }
        
        checkAutoFlush();
        return written;
    }
    
    /**
     * 写入short
     * @param value short值
     * @throws IOException IO异常
     */
    public void writeShort(short value) throws IOException {
        ensureCapacity(2);
        buffer.putShort(value);
        totalBytesWritten.addAndGet(2);
        checkAutoFlush();
    }
    
    /**
     * 写入int
     * @param value int值
     * @throws IOException IO异常
     */
    public void writeInt(int value) throws IOException {
        ensureCapacity(4);
        buffer.putInt(value);
        totalBytesWritten.addAndGet(4);
        checkAutoFlush();
    }
    
    /**
     * 写入long
     * @param value long值
     * @throws IOException IO异常
     */
    public void writeLong(long value) throws IOException {
        ensureCapacity(8);
        buffer.putLong(value);
        totalBytesWritten.addAndGet(8);
        checkAutoFlush();
    }
    
    /**
     * 写入float
     * @param value float值
     * @throws IOException IO异常
     */
    public void writeFloat(float value) throws IOException {
        ensureCapacity(4);
        buffer.putFloat(value);
        totalBytesWritten.addAndGet(4);
        checkAutoFlush();
    }
    
    /**
     * 写入double
     * @param value double值
     * @throws IOException IO异常
     */
    public void writeDouble(double value) throws IOException {
        ensureCapacity(8);
        buffer.putDouble(value);
        totalBytesWritten.addAndGet(8);
        checkAutoFlush();
    }
    
    /**
     * 确保缓冲区有足够空间
     * @param required 需要的字节数
     * @throws IOException IO异常
     */
    private void ensureCapacity(int required) throws IOException {
        if (buffer.remaining() < required) {
            flush();
        }
    }
    
    /**
     * 检查自动刷新
     * @throws IOException IO异常
     */
    private void checkAutoFlush() throws IOException {
        if (autoFlush && buffer.position() >= autoFlushThreshold) {
            flush();
        }
    }
    
    /**
     * 刷新缓冲区
     * @throws IOException IO异常
     */
    public synchronized void flush() throws IOException {
        if (buffer.position() == 0) {
            return; // 没有数据需要刷新
        }
        
        // 准备读取
        buffer.flip();
        
        // 获取数据
        byte[] data = new byte[buffer.remaining()];
        buffer.get(data);
        
        // 调用回调
        if (flushCallback != null) {
            flushCallback.onFlush(data);
        }
        
        // 清空缓冲区
        buffer.clear();
        buffer.order(byteOrder);
        
        totalFlushCount.incrementAndGet();
    }
    
    /**
     * 清空缓冲区（不刷新）
     */
    public void clear() {
        buffer.clear();
        buffer.order(byteOrder);
    }
    
    /**
     * 获取已使用空间
     * @return 已使用字节数
     */
    public int getUsedSpace() {
        return buffer.position();
    }
    
    /**
     * 获取剩余空间
     * @return 剩余字节数
     */
    public int getRemainingSpace() {
        return buffer.remaining();
    }
    
    /**
     * 获取容量
     * @return 缓冲区容量
     */
    public int getCapacity() {
        return capacity;
    }
    
    /**
     * 获取总写入字节数
     * @return 总写入字节数
     */
    public long getTotalBytesWritten() {
        return totalBytesWritten.get();
    }
    
    /**
     * 获取刷新次数
     * @return 刷新次数
     */
    public long getTotalFlushCount() {
        return totalFlushCount.get();
    }
    
    /**
     * 设置刷新回调
     * @param callback 回调接口
     */
    public void setFlushCallback(FlushCallback callback) {
        this.flushCallback = callback;
    }
    
    /**
     * 关闭缓冲区
     * @throws IOException IO异常
     */
    public void close() throws IOException {
        flush();
    }
}
