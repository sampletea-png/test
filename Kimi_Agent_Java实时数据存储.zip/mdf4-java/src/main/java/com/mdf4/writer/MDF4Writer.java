package com.mdf4.writer;

import com.mdf4.blocks.*;
import com.mdf4.buffer.AsyncWriteManager;
import com.mdf4.buffer.DataBuffer;
import com.mdf4.channel.ChannelConfig;
import com.mdf4.channel.ChannelGroupConfig;
import com.mdf4.core.DataType;
import com.mdf4.core.MDF4Constants;
import com.mdf4.util.MDF4Utils;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * MDF4文件写入器
 * 主写入器类，提供完整的MDF4文件写入功能
 * 
 * 特性：
 * - 支持大数据量写入（GB级别）
 * - 支持动态添加通道
 * - 支持异步写入
 * - 支持分块写入
 */
public class MDF4Writer implements AutoCloseable {
    
    // 文件
    private RandomAccessFile file;
    private FileChannel channel;
    private String filePath;
    
    // MDF4块
    private IDBlock idBlock;
    private HDBlock hdBlock;
    private List<DGBlock> dgBlocks;
    private List<CGBlock> cgBlocks;
    private List<CNBlock> cnBlocks;
    private List<TXBlock> txBlocks;
    private FHBlock fhBlock;
    
    // 通道组配置
    private Map<String, ChannelGroupConfig> channelGroups;
    private ChannelGroupConfig currentChannelGroup;
    
    // 写入状态
    private final AtomicBoolean isOpen;
    private final AtomicBoolean isWriting;
    private long currentPosition;
    
    // 缓冲区
    private DataBuffer dataBuffer;
    private AsyncWriteManager asyncWriteManager;
    
    // 统计信息
    private final AtomicLong totalRecordsWritten;
    private final AtomicLong totalBytesWritten;
    private long startTime;
    
    // 配置
    private final WriterConfig config;
    
    // 数据块位置跟踪
    private long currentDataBlockPosition;
    private long currentDataBlockSize;
    
    /**
     * 写入器配置
     */
    public static class WriterConfig {
        private ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
        private int bufferSize = MDF4Constants.DEFAULT_WRITE_BUFFER_SIZE;
        private boolean useAsyncWrite = false;
        private int asyncQueueSize = 1000;
        private long maxFileSize = MDF4Constants.FILE_SPLIT_THRESHOLD;
        private boolean enableCompression = false;
        private String programName = "JavaMDF4";
        private String programVersion = "1.0";
        
        // Getters and Setters
        public ByteOrder getByteOrder() { return byteOrder; }
        public void setByteOrder(ByteOrder byteOrder) { this.byteOrder = byteOrder; }
        public int getBufferSize() { return bufferSize; }
        public void setBufferSize(int bufferSize) { this.bufferSize = bufferSize; }
        public boolean isUseAsyncWrite() { return useAsyncWrite; }
        public void setUseAsyncWrite(boolean useAsyncWrite) { this.useAsyncWrite = useAsyncWrite; }
        public int getAsyncQueueSize() { return asyncQueueSize; }
        public void setAsyncQueueSize(int asyncQueueSize) { this.asyncQueueSize = asyncQueueSize; }
        public long getMaxFileSize() { return maxFileSize; }
        public void setMaxFileSize(long maxFileSize) { this.maxFileSize = maxFileSize; }
        public boolean isEnableCompression() { return enableCompression; }
        public void setEnableCompression(boolean enableCompression) { this.enableCompression = enableCompression; }
        public String getProgramName() { return programName; }
        public void setProgramName(String programName) { this.programName = programName; }
        public String getProgramVersion() { return programVersion; }
        public void setProgramVersion(String programVersion) { this.programVersion = programVersion; }
    }
    
    /**
     * 构造函数（默认配置）
     */
    public MDF4Writer() {
        this(new WriterConfig());
    }
    
    /**
     * 构造函数（指定配置）
     * @param config 写入器配置
     */
    public MDF4Writer(WriterConfig config) {
        this.config = config != null ? config : new WriterConfig();
        this.dgBlocks = new ArrayList<>();
        this.cgBlocks = new ArrayList<>();
        this.cnBlocks = new ArrayList<>();
        this.txBlocks = new ArrayList<>();
        this.channelGroups = new ConcurrentHashMap<>();
        this.isOpen = new AtomicBoolean(false);
        this.isWriting = new AtomicBoolean(false);
        this.totalRecordsWritten = new AtomicLong(0);
        this.totalBytesWritten = new AtomicLong(0);
    }
    
    /**
     * 打开文件
     * @param filePath 文件路径
     * @throws IOException IO异常
     */
    public void open(String filePath) throws IOException {
        if (isOpen.compareAndSet(false, true)) {
            this.filePath = filePath;
            this.file = new RandomAccessFile(filePath, "rw");
            this.channel = file.getChannel();
            this.currentPosition = 0;
            this.startTime = System.currentTimeMillis();
            
            // 初始化缓冲区
            this.dataBuffer = new DataBuffer(config.getBufferSize(), config.getByteOrder());
            this.dataBuffer.setFlushCallback(this::flushData);
            
            // 初始化异步写入
            if (config.isUseAsyncWrite()) {
                this.asyncWriteManager = new AsyncWriteManager(
                    config.getAsyncQueueSize(), 100, 100
                );
                this.asyncWriteManager.start(this::flushData);
            }
            
            // 写入文件头
            writeFileHeader();
            
        } else {
            throw new IllegalStateException("Writer is already open");
        }
    }
    
    /**
     * 写入文件头
     * @throws IOException IO异常
     */
    private void writeFileHeader() throws IOException {
        // 写入ID块
        idBlock = new IDBlock(config.getProgramName(), 
            config.getByteOrder() == ByteOrder.LITTLE_ENDIAN ? 
                MDF4Constants.BYTE_ORDER_LITTLE_ENDIAN : MDF4Constants.BYTE_ORDER_BIG_ENDIAN);
        currentPosition = idBlock.write(file, currentPosition);
        
        // 写入HD块
        hdBlock = new HDBlock();
        hdBlock.setStartTimeToNow();
        currentPosition = hdBlock.write(file, currentPosition);
        
        // 写入FH块
        fhBlock = new FHBlock(config.getProgramName(), config.getProgramVersion());
        long fhPosition = fhBlock.write(file, currentPosition);
        hdBlock.setFileHistoryBlock(fhPosition);
        currentPosition = fhPosition;
        
        // 更新HD块链接
        hdBlock.updateLink(file, HDBlock.LINK_FH_FIRST, fhPosition);
    }
    
    /**
     * 创建通道组
     * @param name 通道组名称
     * @return 通道组配置
     * @throws IOException IO异常
     */
    public ChannelGroupConfig createChannelGroup(String name) throws IOException {
        if (!isOpen.get()) {
            throw new IllegalStateException("Writer is not open");
        }
        
        String validatedName = MDF4Utils.validateChannelName(name);
        
        if (channelGroups.containsKey(validatedName)) {
            throw new IllegalArgumentException("Channel group already exists: " + validatedName);
        }
        
        // 创建通道组配置
        ChannelGroupConfig cgConfig = new ChannelGroupConfig(validatedName);
        channelGroups.put(validatedName, cgConfig);
        currentChannelGroup = cgConfig;
        
        // 创建CG块
        CGBlock cgBlock = new CGBlock(cgBlocks.size() + 1);
        cgBlocks.add(cgBlock);
        
        // 写入CG块
        currentPosition = cgBlock.write(file, currentPosition);
        
        // 写入通道组名称
        TXBlock txName = new TXBlock(validatedName);
        long txPosition = txName.write(file, currentPosition);
        cgBlock.setNameBlock(txPosition);
        cgBlock.updateLink(file, CGBlock.LINK_TX_NAME, txPosition);
        currentPosition = txPosition;
        txBlocks.add(txName);
        
        // 链接DG块和CG块
        if (dgBlocks.isEmpty()) {
            // 创建第一个DG块
            DGBlock dgBlock = new DGBlock();
            dgBlocks.add(dgBlock);
            currentPosition = dgBlock.write(file, currentPosition);
            hdBlock.setFirstDGBlock(dgBlock.getFilePosition());
            hdBlock.updateLink(file, HDBlock.LINK_DG_FIRST, dgBlock.getFilePosition());
        }
        
        DGBlock dgBlock = dgBlocks.get(0);
        if (dgBlock.getFirstCGBlock() == 0) {
            dgBlock.setFirstCGBlock(cgBlock.getFilePosition());
            dgBlock.updateLink(file, DGBlock.LINK_CG_FIRST, cgBlock.getFilePosition());
        } else {
            // 链接到上一个CG块
            CGBlock lastCgBlock = cgBlocks.get(cgBlocks.size() - 2);
            lastCgBlock.setNextCGBlock(cgBlock.getFilePosition());
            lastCgBlock.updateLink(file, CGBlock.LINK_NEXT_CG, cgBlock.getFilePosition());
        }
        
        return cgConfig;
    }
    
    /**
     * 添加通道
     * @param channelConfig 通道配置
     * @throws IOException IO异常
     */
    public void addChannel(ChannelConfig channelConfig) throws IOException {
        if (!isOpen.get()) {
            throw new IllegalStateException("Writer is not open");
        }
        
        if (currentChannelGroup == null) {
            throw new IllegalStateException("No channel group created");
        }
        
        if (currentChannelGroup.isSealed()) {
            throw new IllegalStateException("Current channel group is sealed");
        }
        
        // 添加通道到通道组
        int byteOffset = currentChannelGroup.addChannel(channelConfig);
        channelConfig.setByteOffset(byteOffset);
        
        // 创建CN块
        CNBlock cnBlock = new CNBlock(channelConfig.getName(), channelConfig.getDataType());
        cnBlock.setByteOffset(channelConfig.getByteOffset());
        cnBlock.setBitCount(channelConfig.getBitCount());
        cnBlock.setChannelType(channelConfig.getChannelType());
        cnBlock.setSyncType(channelConfig.getSyncType());
        cnBlock.setFlags(channelConfig.getFlags());
        
        if (channelConfig.getMinValue() != 0 || channelConfig.getMaxValue() != 0) {
            cnBlock.setMinValue(channelConfig.getMinValue());
            cnBlock.setMaxValue(channelConfig.getMaxValue());
        }
        
        cnBlocks.add(cnBlock);
        
        // 写入CN块
        currentPosition = cnBlock.write(file, currentPosition);
        
        // 写入通道名称
        TXBlock txName = new TXBlock(channelConfig.getName());
        long txPosition = txName.write(file, currentPosition);
        cnBlock.setNameBlock(txPosition);
        cnBlock.updateLink(file, CNBlock.LINK_TX_NAME, txPosition);
        currentPosition = txPosition;
        txBlocks.add(txName);
        
        // 链接CG块和CN块
        CGBlock cgBlock = cgBlocks.get(cgBlocks.size() - 1);
        if (cgBlock.getFirstCNBlock() == 0) {
            cgBlock.setFirstCNBlock(cnBlock.getFilePosition());
            cgBlock.updateLink(file, CGBlock.LINK_CN_FIRST, cnBlock.getFilePosition());
        } else {
            // 链接到上一个CN块
            CNBlock lastCnBlock = cnBlocks.get(cnBlocks.size() - 2);
            lastCnBlock.setNextCNBlock(cnBlock.getFilePosition());
            lastCnBlock.updateLink(file, CNBlock.LINK_NEXT_CN, cnBlock.getFilePosition());
        }
        
        // 更新CG块数据字节数
        cgBlock.setDataBytes((short) currentChannelGroup.getRecordSize());
    }
    
    /**
     * 密封当前通道组（不再允许添加通道）
     */
    public void sealCurrentChannelGroup() {
        if (currentChannelGroup != null) {
            currentChannelGroup.seal();
            
            // 初始化数据块
            try {
                initializeDataBlock();
            } catch (IOException e) {
                throw new RuntimeException("Failed to initialize data block", e);
            }
        }
    }
    
    /**
     * 初始化数据块
     * @throws IOException IO异常
     */
    private void initializeDataBlock() throws IOException {
        if (currentChannelGroup == null || currentChannelGroup.getChannelCount() == 0) {
            return;
        }
        
        // 创建DT块
        DTBlock dtBlock = new DTBlock(config.getMaxFileSize(), true);
        currentDataBlockPosition = dtBlock.write(file, currentPosition);
        currentPosition = currentDataBlockPosition + dtBlock.getTotalSize();
        
        // 链接DG块到DT块
        DGBlock dgBlock = dgBlocks.get(0);
        dgBlock.setDataBlock(currentDataBlockPosition);
        dgBlock.updateLink(file, DGBlock.LINK_DATA, currentDataBlockPosition);
        
        currentDataBlockSize = 0;
    }
    
    /**
     * 写入记录
     * @param values 通道值数组（按通道顺序）
     * @throws IOException IO异常
     */
    public void writeRecord(Object... values) throws IOException {
        if (!isOpen.get()) {
            throw new IllegalStateException("Writer is not open");
        }
        
        if (currentChannelGroup == null) {
            throw new IllegalStateException("No channel group created");
        }
        
        if (!currentChannelGroup.isSealed()) {
            throw new IllegalStateException("Channel group must be sealed before writing");
        }
        
        List<ChannelConfig> channels = currentChannelGroup.getChannels();
        if (values.length != channels.size()) {
            throw new IllegalArgumentException(
                "Value count mismatch: expected " + channels.size() + ", got " + values.length);
        }
        
        // 构建记录数据
        byte[] recordData = new byte[currentChannelGroup.getRecordSize()];
        int offset = 0;
        
        for (int i = 0; i < channels.size(); i++) {
            ChannelConfig channel = channels.get(i);
            Object value = values[i];
            
            // 转换值为字节数组
            byte[] valueBytes = convertValueToBytes(value, channel.getDataType());
            
            // 复制到记录数据
            System.arraycopy(valueBytes, 0, recordData, offset, valueBytes.length);
            offset += valueBytes.length;
        }
        
        // 写入数据
        writeRecordData(recordData);
        
        // 更新统计
        totalRecordsWritten.incrementAndGet();
        currentChannelGroup.incrementRecordCount();
    }
    
    /**
     * 写入记录（使用Map）
     * @param values 通道值Map
     * @throws IOException IO异常
     */
    public void writeRecord(Map<String, Object> values) throws IOException {
        if (currentChannelGroup == null) {
            throw new IllegalStateException("No channel group created");
        }
        
        List<ChannelConfig> channels = currentChannelGroup.getChannels();
        Object[] orderedValues = new Object[channels.size()];
        
        for (int i = 0; i < channels.size(); i++) {
            ChannelConfig channel = channels.get(i);
            orderedValues[i] = values.get(channel.getName());
        }
        
        writeRecord(orderedValues);
    }
    
    /**
     * 将值转换为字节数组
     * @param value 值
     * @param dataType 数据类型
     * @return 字节数组
     */
    private byte[] convertValueToBytes(Object value, DataType dataType) {
        if (value instanceof Number) {
            return MDF4Utils.doubleToBytes(((Number) value).doubleValue(), dataType, config.getByteOrder());
        } else if (value instanceof Boolean) {
            return new byte[] { (Boolean) value ? (byte) 1 : (byte) 0 };
        } else if (value instanceof byte[]) {
            return (byte[]) value;
        } else {
            throw new IllegalArgumentException("Unsupported value type: " + value.getClass());
        }
    }
    
    /**
     * 写入记录数据
     * @param data 记录数据
     * @throws IOException IO异常
     */
    private void writeRecordData(byte[] data) throws IOException {
        if (config.isUseAsyncWrite() && asyncWriteManager != null) {
            asyncWriteManager.submitAsync(data);
        } else {
            dataBuffer.write(data);
        }
        
        totalBytesWritten.addAndGet(data.length);
        currentDataBlockSize += data.length;
    }
    
    /**
     * 刷新数据
     * @param data 数据
     * @throws IOException IO异常
     */
    private void flushData(byte[] data) throws IOException {
        if (data == null || data.length == 0) {
            return;
        }
        
        // 写入到文件
        file.seek(currentDataBlockPosition + 24 + currentDataBlockSize); // 跳过块头
        file.write(data);
        
        // 更新数据块大小
        currentDataBlockSize += data.length;
        
        // 更新CG块记录计数
        if (!cgBlocks.isEmpty()) {
            CGBlock cgBlock = cgBlocks.get(cgBlocks.size() - 1);
            cgBlock.setDataRecordCount(currentChannelGroup.getRecordCount());
        }
    }
    
    /**
     * 刷新缓冲区
     * @throws IOException IO异常
     */
    public void flush() throws IOException {
        if (dataBuffer != null) {
            dataBuffer.flush();
        }
        
        if (channel != null) {
            channel.force(true);
        }
    }
    
    /**
     * 关闭写入器
     * @throws IOException IO异常
     */
    @Override
    public void close() throws IOException {
        if (isOpen.compareAndSet(true, false)) {
            try {
                // 停止异步写入
                if (asyncWriteManager != null) {
                    asyncWriteManager.stop(true, 5000);
                }
                
                // 刷新缓冲区
                flush();
                
                // 更新最终块大小
                finalizeBlocks();
                
            } finally {
                // 关闭文件
                if (channel != null) {
                    channel.close();
                }
                if (file != null) {
                    file.close();
                }
            }
        }
    }
    
    /**
     * 最终化块
     * @throws IOException IO异常
     */
    private void finalizeBlocks() throws IOException {
        // 更新CG块数据记录计数
        for (int i = 0; i < cgBlocks.size(); i++) {
            CGBlock cgBlock = cgBlocks.get(i);
            ChannelGroupConfig cgConfig = new ArrayList<>(channelGroups.values()).get(i);
            cgBlock.setDataRecordCount(cgConfig.getRecordCount());
            
            // 重写CG块以更新数据
            file.seek(cgBlock.getFilePosition() + 24); // 跳过块头和链接
            file.writeLong(cgBlock.getRecordId());
            file.writeLong(cgBlock.getCycleCount());
            file.writeShort(cgBlock.getDataBytes());
            file.writeShort(cgBlock.getInvalidBytes());
            file.writeInt(cgBlock.getFlags());
            file.writeByte(cgBlock.getPathSeparator());
            file.write(new byte[3]); // 保留
            file.writeLong(cgBlock.getDataRecordCount());
        }
        
        // 更新DT块大小
        if (currentDataBlockPosition > 0) {
            file.seek(currentDataBlockPosition + 8); // 跳过块标识和保留字节
            file.writeLong(currentDataBlockSize + 24); // 块头 + 数据
        }
    }
    
    /**
     * 获取统计信息
     * @return 统计信息
     */
    public String getStatistics() {
        long elapsedMs = System.currentTimeMillis() - startTime;
        double writeRate = elapsedMs > 0 ? (totalBytesWritten.get() * 1000.0 / elapsedMs / 1024 / 1024) : 0;
        
        return String.format(
            "MDF4Writer{file='%s', records=%d, bytes=%d, rate=%.2f MB/s, elapsed=%d ms}",
            filePath,
            totalRecordsWritten.get(),
            totalBytesWritten.get(),
            writeRate,
            elapsedMs
        );
    }
    
    // Getters
    
    public String getFilePath() {
        return filePath;
    }
    
    public boolean isOpen() {
        return isOpen.get();
    }
    
    public long getTotalRecordsWritten() {
        return totalRecordsWritten.get();
    }
    
    public long getTotalBytesWritten() {
        return totalBytesWritten.get();
    }
    
    public ChannelGroupConfig getCurrentChannelGroup() {
        return currentChannelGroup;
    }
    
    public Map<String, ChannelGroupConfig> getChannelGroups() {
        return channelGroups;
    }
}
