package com.mdf4.writer;

import com.mdf4.channel.ChannelConfig;
import com.mdf4.channel.ChannelGroupConfig;
import com.mdf4.core.DataType;
import com.mdf4.util.MDF4Utils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据记录构建器
 * 简化数据记录的构建过程
 */
public class RecordBuilder {
    
    // 通道组配置
    private final ChannelGroupConfig channelGroup;
    
    // 字节序
    private final ByteOrder byteOrder;
    
    // 记录数据
    private final Map<String, Object> values;
    
    // 记录大小
    private final int recordSize;
    
    // 通道列表
    private final List<ChannelConfig> channels;
    
    // 通道索引映射
    private final Map<String, Integer> channelIndexMap;
    
    /**
     * 构造函数
     * @param channelGroup 通道组配置
     */
    public RecordBuilder(ChannelGroupConfig channelGroup) {
        this(channelGroup, ByteOrder.LITTLE_ENDIAN);
    }
    
    /**
     * 构造函数
     * @param channelGroup 通道组配置
     * @param byteOrder 字节序
     */
    public RecordBuilder(ChannelGroupConfig channelGroup, ByteOrder byteOrder) {
        if (channelGroup == null) {
            throw new IllegalArgumentException("Channel group cannot be null");
        }
        this.channelGroup = channelGroup;
        this.byteOrder = byteOrder;
        this.values = new HashMap<>();
        this.recordSize = channelGroup.getRecordSize();
        this.channels = new ArrayList<>(channelGroup.getChannels());
        this.channelIndexMap = new HashMap<>();
        
        // 构建通道索引映射
        for (int i = 0; i < channels.size(); i++) {
            channelIndexMap.put(channels.get(i).getName(), i);
        }
    }
    
    /**
     * 设置时间值（自动查找时间通道）
     * @param time 时间值
     * @return this
     */
    public RecordBuilder setTime(double time) {
        ChannelConfig timeChannel = channelGroup.getTimeChannel();
        if (timeChannel != null) {
            values.put(timeChannel.getName(), time);
        }
        return this;
    }
    
    /**
     * 设置通道值
     * @param channelName 通道名称
     * @param value 值
     * @return this
     */
    public RecordBuilder setValue(String channelName, Object value) {
        if (channelName == null) {
            throw new IllegalArgumentException("Channel name cannot be null");
        }
        
        // 验证通道存在
        if (!channelIndexMap.containsKey(channelName)) {
            throw new IllegalArgumentException("Channel not found: " + channelName);
        }
        
        values.put(channelName, value);
        return this;
    }
    
    /**
     * 设置多个通道值
     * @param valuesMap 值映射
     * @return this
     */
    public RecordBuilder setValues(Map<String, Object> valuesMap) {
        if (valuesMap != null) {
            for (Map.Entry<String, Object> entry : valuesMap.entrySet()) {
                if (channelIndexMap.containsKey(entry.getKey())) {
                    values.put(entry.getKey(), entry.getValue());
                }
            }
        }
        return this;
    }
    
    /**
     * 设置整数通道值
     * @param channelName 通道名称
     * @param value 整数值
     * @return this
     */
    public RecordBuilder setInt(String channelName, int value) {
        return setValue(channelName, value);
    }
    
    /**
     * 设置长整数通道值
     * @param channelName 通道名称
     * @param value 长整数值
     * @return this
     */
    public RecordBuilder setLong(String channelName, long value) {
        return setValue(channelName, value);
    }
    
    /**
     * 设置浮点通道值
     * @param channelName 通道名称
     * @param value 浮点值
     * @return this
     */
    public RecordBuilder setFloat(String channelName, float value) {
        return setValue(channelName, value);
    }
    
    /**
     * 设置双精度通道值
     * @param channelName 通道名称
     * @param value 双精度值
     * @return this
     */
    public RecordBuilder setDouble(String channelName, double value) {
        return setValue(channelName, value);
    }
    
    /**
     * 设置布尔通道值
     * @param channelName 通道名称
     * @param value 布尔值
     * @return this
     */
    public RecordBuilder setBoolean(String channelName, boolean value) {
        return setValue(channelName, value);
    }
    
    /**
     * 清除所有值
     * @return this
     */
    public RecordBuilder clear() {
        values.clear();
        return this;
    }
    
    /**
     * 构建记录字节数组
     * @return 记录字节数组
     */
    public byte[] build() {
        byte[] record = new byte[recordSize];
        
        for (ChannelConfig channel : channels) {
            Object value = values.get(channel.getName());
            
            // 如果未设置值，使用默认值
            if (value == null) {
                value = getDefaultValue(channel.getDataType());
            }
            
            // 转换为字节数组
            byte[] valueBytes = convertValueToBytes(value, channel.getDataType());
            
            // 复制到记录
            System.arraycopy(valueBytes, 0, record, channel.getByteOffset(), valueBytes.length);
        }
        
        return record;
    }
    
    /**
     * 构建值数组（用于writeRecord方法）
     * @return 值数组
     */
    public Object[] buildArray() {
        Object[] array = new Object[channels.size()];
        
        for (int i = 0; i < channels.size(); i++) {
            ChannelConfig channel = channels.get(i);
            Object value = values.get(channel.getName());
            
            if (value == null) {
                value = getDefaultValue(channel.getDataType());
            }
            
            array[i] = value;
        }
        
        return array;
    }
    
    /**
     * 构建值Map（用于writeRecord方法）
     * @return 值Map
     */
    public Map<String, Object> buildMap() {
        return new HashMap<>(values);
    }
    
    /**
     * 将值转换为字节数组
     * @param value 值
     * @param dataType 数据类型
     * @return 字节数组
     */
    private byte[] convertValueToBytes(Object value, DataType dataType) {
        if (value instanceof Number) {
            return MDF4Utils.doubleToBytes(((Number) value).doubleValue(), dataType, byteOrder);
        } else if (value instanceof Boolean) {
            return new byte[] { (Boolean) value ? (byte) 1 : (byte) 0 };
        } else if (value instanceof byte[]) {
            byte[] bytes = (byte[]) value;
            if (bytes.length != dataType.getSize()) {
                throw new IllegalArgumentException(
                    "Byte array size mismatch: expected " + dataType.getSize() + ", got " + bytes.length);
            }
            return bytes;
        } else {
            throw new IllegalArgumentException("Unsupported value type: " + value.getClass());
        }
    }
    
    /**
     * 获取默认值
     * @param dataType 数据类型
     * @return 默认值
     */
    private Object getDefaultValue(DataType dataType) {
        switch (dataType) {
            case UINT8:
            case INT8:
                return (byte) 0;
            case UINT16:
            case INT16:
                return (short) 0;
            case UINT32:
            case INT32:
                return 0;
            case UINT64:
            case INT64:
                return 0L;
            case FLOAT:
                return 0.0f;
            case DOUBLE:
                return 0.0;
            case BOOLEAN:
                return false;
            default:
                return 0;
        }
    }
    
    /**
     * 检查是否设置了指定通道的值
     * @param channelName 通道名称
     * @return true如果已设置
     */
    public boolean hasValue(String channelName) {
        return values.containsKey(channelName);
    }
    
    /**
     * 获取通道值
     * @param channelName 通道名称
     * @return 值，未设置返回null
     */
    public Object getValue(String channelName) {
        return values.get(channelName);
    }
    
    /**
     * 获取已设置值的通道数量
     * @return 通道数量
     */
    public int getSetValueCount() {
        return values.size();
    }
    
    /**
     * 获取总通道数量
     * @return 总通道数量
     */
    public int getTotalChannelCount() {
        return channels.size();
    }
    
    /**
     * 获取记录大小
     * @return 记录大小（字节）
     */
    public int getRecordSize() {
        return recordSize;
    }
    
    /**
     * 检查是否所有通道都已设置值
     * @return true如果所有通道都已设置
     */
    public boolean isComplete() {
        return values.size() == channels.size();
    }
    
    /**
     * 获取未设置值的通道列表
     * @return 通道名称列表
     */
    public List<String> getUnsetChannels() {
        List<String> unset = new ArrayList<>();
        for (ChannelConfig channel : channels) {
            if (!values.containsKey(channel.getName())) {
                unset.add(channel.getName());
            }
        }
        return unset;
    }
    
    @Override
    public String toString() {
        return "RecordBuilder{" +
                "channelGroup='" + channelGroup.getName() + '\'' +
                ", setValues=" + values.size() +
                ", totalChannels=" + channels.size() +
                ", complete=" + isComplete() +
                '}';
    }
}
