package com.mdf4.util;

import com.mdf4.core.DataType;
import com.mdf4.core.MDF4Constants;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * MDF4工具类
 * 提供MDF4相关的实用方法
 */
public final class MDF4Utils {
    
    // 日期时间格式化器
    private static final DateTimeFormatter DATE_TIME_FORMATTER = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.systemDefault());
    
    private MDF4Utils() {
        // 私有构造函数防止实例化
    }
    
    /**
     * 对齐到指定边界
     * @param value 值
     * @param alignment 对齐边界
     * @return 对齐后的值
     */
    public static long alignTo(long value, int alignment) {
        long mask = alignment - 1;
        return (value + mask) & ~mask;
    }
    
    /**
     * 计算填充字节数
     * @param currentSize 当前大小
     * @param alignment 对齐边界
     * @return 需要的填充字节数
     */
    public static int calculatePadding(long currentSize, int alignment) {
        long aligned = alignTo(currentSize, alignment);
        return (int) (aligned - currentSize);
    }
    
    /**
     * 写入填充字节
     * @param file 随机访问文件
     * @param count 填充字节数
     * @throws IOException IO异常
     */
    public static void writePadding(RandomAccessFile file, int count) throws IOException {
        for (int i = 0; i < count; i++) {
            file.writeByte(0);
        }
    }
    
    /**
     * 将值转换为字节数组
     * @param value 值
     * @param dataType 数据类型
     * @param byteOrder 字节序
     * @return 字节数组
     */
    public static byte[] valueToBytes(Object value, DataType dataType, ByteOrder byteOrder) {
        ByteBuffer buffer = ByteBuffer.allocate(dataType.getSize());
        buffer.order(byteOrder);
        
        switch (dataType) {
            case UINT8:
            case INT8:
                buffer.put(((Number) value).byteValue());
                break;
            case UINT16:
            case INT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case UINT32:
            case INT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case UINT64:
            case INT64:
                buffer.putLong(((Number) value).longValue());
                break;
            case FLOAT:
                buffer.putFloat(((Number) value).floatValue());
                break;
            case DOUBLE:
                buffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                buffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            default:
                throw new IllegalArgumentException("Unsupported data type: " + dataType);
        }
        
        return buffer.array();
    }
    
    /**
     * 将double值转换为字节数组
     * @param value double值
     * @param dataType 数据类型
     * @param byteOrder 字节序
     * @return 字节数组
     */
    public static byte[] doubleToBytes(double value, DataType dataType, ByteOrder byteOrder) {
        ByteBuffer buffer = ByteBuffer.allocate(dataType.getSize());
        buffer.order(byteOrder);
        
        switch (dataType) {
            case UINT8:
            case INT8:
                buffer.put((byte) value);
                break;
            case UINT16:
            case INT16:
                buffer.putShort((short) value);
                break;
            case UINT32:
            case INT32:
                buffer.putInt((int) value);
                break;
            case UINT64:
            case INT64:
                buffer.putLong((long) value);
                break;
            case FLOAT:
                buffer.putFloat((float) value);
                break;
            case DOUBLE:
                buffer.putDouble(value);
                break;
            default:
                throw new IllegalArgumentException("Unsupported data type for double conversion: " + dataType);
        }
        
        return buffer.array();
    }
    
    /**
     * 将字节数组转换为double值
     * @param bytes 字节数组
     * @param dataType 数据类型
     * @param byteOrder 字节序
     * @return double值
     */
    public static double bytesToDouble(byte[] bytes, DataType dataType, ByteOrder byteOrder) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        buffer.order(byteOrder);
        
        switch (dataType) {
            case UINT8:
                return buffer.get() & 0xFF;
            case INT8:
                return buffer.get();
            case UINT16:
                return buffer.getShort() & 0xFFFF;
            case INT16:
                return buffer.getShort();
            case UINT32:
                return buffer.getInt() & 0xFFFFFFFFL;
            case INT32:
                return buffer.getInt();
            case UINT64:
            case INT64:
                return buffer.getLong();
            case FLOAT:
                return buffer.getFloat();
            case DOUBLE:
                return buffer.getDouble();
            default:
                throw new IllegalArgumentException("Unsupported data type for double conversion: " + dataType);
        }
    }
    
    /**
     * 格式化时间戳
     * @param timestampNs 时间戳（纳秒）
     * @return 格式化字符串
     */
    public static String formatTimestamp(long timestampNs) {
        Instant instant = Instant.ofEpochMilli(timestampNs / 1_000_000);
        return DATE_TIME_FORMATTER.format(instant);
    }
    
    /**
     * 获取当前时间戳（纳秒）
     * @return 当前时间戳
     */
    public static long getCurrentTimestampNs() {
        return System.nanoTime();
    }
    
    /**
     * 将Unix时间戳转换为MDF4时间戳
     * @param unixTimeMs Unix时间戳（毫秒）
     * @return MDF4时间戳（纳秒）
     */
    public static long unixToMdfTimestamp(long unixTimeMs) {
        return unixTimeMs * MDF4Constants.NS_PER_MS;
    }
    
    /**
     * 将MDF4时间戳转换为Unix时间戳
     * @param mdfTimestampNs MDF4时间戳（纳秒）
     * @return Unix时间戳（毫秒）
     */
    public static long mdfToUnixTimestamp(long mdfTimestampNs) {
        return mdfTimestampNs / MDF4Constants.NS_PER_MS;
    }
    
    /**
     * 验证通道名称
     * @param name 通道名称
     * @return 验证后的名称
     */
    public static String validateChannelName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Channel name cannot be null or empty");
        }
        
        // 移除非法字符
        String validated = name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
        
        // 限制长度
        if (validated.length() > 63) {
            validated = validated.substring(0, 63);
        }
        
        return validated;
    }
    
    /**
     * 截断字符串到指定长度
     * @param str 字符串
     * @param maxLength 最大长度
     * @return 截断后的字符串
     */
    public static String truncateString(String str, int maxLength) {
        if (str == null) {
            return "";
        }
        if (str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength);
    }
    
    /**
     * 填充字符串到指定长度
     * @param str 字符串
     * @param length 目标长度
     * @param padChar 填充字符
     * @return 填充后的字符串
     */
    public static String padString(String str, int length, char padChar) {
        if (str == null) {
            str = "";
        }
        if (str.length() >= length) {
            return str.substring(0, length);
        }
        
        StringBuilder sb = new StringBuilder(str);
        while (sb.length() < length) {
            sb.append(padChar);
        }
        return sb.toString();
    }
    
    /**
     * 计算数据类型的字节大小
     * @param dataType 数据类型
     * @return 字节大小
     */
    public static int getDataTypeSize(DataType dataType) {
        return dataType.getSize();
    }
    
    /**
     * 检查数据类型是否为整数类型
     * @param dataType 数据类型
     * @return true如果是整数类型
     */
    public static boolean isIntegerType(DataType dataType) {
        switch (dataType) {
            case UINT8:
            case UINT16:
            case UINT32:
            case UINT64:
            case INT8:
            case INT16:
            case INT32:
            case INT64:
                return true;
            default:
                return false;
        }
    }
    
    /**
     * 检查数据类型是否为浮点类型
     * @param dataType 数据类型
     * @return true如果是浮点类型
     */
    public static boolean isFloatType(DataType dataType) {
        return dataType == DataType.FLOAT || dataType == DataType.DOUBLE;
    }
    
    /**
     * 检查数据类型是否为有符号类型
     * @param dataType 数据类型
     * @return true如果是有符号类型
     */
    public static boolean isSignedType(DataType dataType) {
        return dataType.isSigned();
    }
    
    /**
     * 将字节数组转换为十六进制字符串
     * @param bytes 字节数组
     * @return 十六进制字符串
     */
    public static String bytesToHex(byte[] bytes) {
        if (bytes == null) {
            return "";
        }
        
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
    
    /**
     * 将十六进制字符串转换为字节数组
     * @param hex 十六进制字符串
     * @return 字节数组
     */
    public static byte[] hexToBytes(String hex) {
        if (hex == null || hex.isEmpty()) {
            return new byte[0];
        }
        
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
