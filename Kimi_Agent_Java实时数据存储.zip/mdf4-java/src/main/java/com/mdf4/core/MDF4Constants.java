package com.mdf4.core;

/**
 * MDF4文件格式常量定义
 * 基于ASAM MDF 4.2.0标准
 */
public final class MDF4Constants {
    
    // 文件标识
    public static final String MDF_ID_FILE = "MDF ";
    public static final String MDF_ID_VERSION = "4.20 ";
    public static final String MDF_ID_PROGRAM = "JavaMDF4";
    public static final String MDF_ID_RESERVED = "    ";
    public static final String MDF_ID_RESERVED2 = "    ";
    
    // 块类型标识
    public static final String BLOCK_ID_ID = "##ID";
    public static final String BLOCK_ID_HD = "##HD";
    public static final String BLOCK_ID_DG = "##DG";
    public static final String BLOCK_ID_CG = "##CG";
    public static final String BLOCK_ID_CN = "##CN";
    public static final String BLOCK_ID_CC = "##CC";
    public static final String BLOCK_ID_DT = "##DT";
    public static final String BLOCK_ID_SR = "##SR";
    public static final String BLOCK_ID_RD = "##RD";
    public static final String BLOCK_ID_SD = "##SD";
    public static final String BLOCK_ID_AT = "##AT";
    public static final String BLOCK_ID_EV = "##EV";
    public static final String BLOCK_ID_DZ = "##DZ";
    public static final String BLOCK_ID_HL = "##HL";
    public static final String BLOCK_ID_CH = "##CH";
    public static final String BLOCK_ID_CGH = "##CG";
    public static final String BLOCK_ID_CNH = "##CN";
    public static final String BLOCK_ID_TX = "##TX";
    public static final String BLOCK_ID_MD = "##MD";
    public static final String BLOCK_ID_FH = "##FH";
    public static final String BLOCK_ID_SI = "##SI";
    
    // 字节序标识
    public static final byte BYTE_ORDER_LITTLE_ENDIAN = 0;
    public static final byte BYTE_ORDER_BIG_ENDIAN = 1;
    
    // 浮点格式标识
    public static final byte FLOAT_FORMAT_IEEE_754 = 0;
    public static final byte FLOAT_FORMAT_G_FLOAT = 1;
    public static final byte FLOAT_FORMAT_D_FLOAT = 2;
    
    // 版本号
    public static final byte VERSION_MAJOR = 4;
    public static final byte VERSION_MINOR = 2;
    
    // 标准时间戳
    public static final long NS_PER_SEC = 1_000_000_000L;
    public static final long NS_PER_MS = 1_000_000L;
    
    // 块头大小（字节）
    public static final short BLOCK_HEADER_SIZE = 24;
    
    // 链接大小（64位）
    public static final int LINK_SIZE = 8;
    
    // 数据类型大小
    public static final int SIZE_UINT8 = 1;
    public static final int SIZE_UINT16 = 2;
    public static final int SIZE_UINT32 = 4;
    public static final int SIZE_UINT64 = 8;
    public static final int SIZE_INT8 = 1;
    public static final int SIZE_INT16 = 2;
    public static final int SIZE_INT32 = 4;
    public static final int SIZE_INT64 = 8;
    public static final int SIZE_FLOAT = 4;
    public static final int SIZE_DOUBLE = 8;
    
    // 通道类型
    public static final byte CHANNEL_TYPE_FIXED_LENGTH = 0;
    public static final byte CHANNEL_TYPE_VARIABLE_LENGTH = 1;
    public static final byte CHANNEL_TYPE_MASTER = 2;
    public static final byte CHANNEL_TYPE_VIRTUAL_MASTER = 3;
    public static final byte CHANNEL_TYPE_SYNC = 4;
    public static final byte CHANNEL_TYPE_MAX_LENGTH = 5;
    public static final byte CHANNEL_TYPE_VIRTUAL = 6;
    
    // 同步类型
    public static final byte SYNC_TYPE_NONE = 0;
    public static final byte SYNC_TYPE_TIME = 1;
    public static final byte SYNC_TYPE_ANGLE = 2;
    public static final byte SYNC_TYPE_DISTANCE = 3;
    public static final byte SYNC_TYPE_INDEX = 4;
    
    // 数据类型
    public static final int DATA_TYPE_UNSIGNED_INT = 0;
    public static final int DATA_TYPE_SIGNED_INT = 1;
    public static final int DATA_TYPE_FLOAT = 2;
    public static final int DATA_TYPE_STRING = 3;
    public static final int DATA_TYPE_BYTE_ARRAY = 4;
    public static final int DATA_TYPE_UNSIGNED_INT_BE = 5;
    public static final int DATA_TYPE_SIGNED_INT_BE = 6;
    public static final int DATA_TYPE_FLOAT_BE = 7;
    public static final int DATA_TYPE_STRING_UTF8 = 8;
    public static final int DATA_TYPE_STRING_UTF16 = 9;
    public static final int DATA_TYPE_STRING_UTF16_BE = 10;
    public static final int DATA_TYPE_BOOLEAN = 11;
    
    // 默认缓冲区大小
    public static final int DEFAULT_BUFFER_SIZE = 64 * 1024; // 64KB
    public static final int DEFAULT_WRITE_BUFFER_SIZE = 1024 * 1024; // 1MB
    public static final int MAX_BUFFER_SIZE = 16 * 1024 * 1024; // 16MB
    
    // 文件分割阈值（2GB）
    public static final long FILE_SPLIT_THRESHOLD = 2L * 1024 * 1024 * 1024;
    
    // 时间戳基准（2000年1月1日）
    public static final long TIME_BASE_NS = 946684800L * NS_PER_SEC;
    
    private MDF4Constants() {
        // 私有构造函数防止实例化
    }
}
