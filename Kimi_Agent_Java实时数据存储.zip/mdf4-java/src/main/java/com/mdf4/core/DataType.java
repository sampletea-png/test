package com.mdf4.core;

/**
 * MDF4数据类型枚举
 * 定义支持的所有数据类型及其属性
 */
public enum DataType {
    
    // 无符号整数类型
    UINT8(0, 1, false, false),
    UINT16(2, 2, false, false),
    UINT32(4, 4, false, false),
    UINT64(8, 8, false, false),
    
    // 有符号整数类型
    INT8(1, 1, true, false),
    INT16(3, 2, true, false),
    INT32(5, 4, true, false),
    INT64(7, 8, true, false),
    
    // 浮点类型
    FLOAT(6, 4, true, false),
    DOUBLE(7, 8, true, false),
    
    // 字符串类型
    STRING(8, -1, false, false),
    STRING_UTF8(9, -1, false, false),
    STRING_UTF16(10, -1, false, false),
    STRING_UTF16_BE(11, -1, false, true),
    
    // 字节数组
    BYTE_ARRAY(12, -1, false, false),
    
    // 布尔类型
    BOOLEAN(13, 1, false, false),
    
    // 大端序类型
    UINT16_BE(14, 2, false, true),
    UINT32_BE(15, 4, false, true),
    UINT64_BE(16, 8, false, true),
    INT16_BE(17, 2, true, true),
    INT32_BE(18, 4, true, true),
    INT64_BE(19, 8, true, true),
    FLOAT_BE(20, 4, true, true),
    DOUBLE_BE(21, 8, true, true);
    
    private final int typeId;
    private final int size;
    private final boolean signed;
    private final boolean bigEndian;
    
    DataType(int typeId, int size, boolean signed, boolean bigEndian) {
        this.typeId = typeId;
        this.size = size;
        this.signed = signed;
        this.bigEndian = bigEndian;
    }
    
    public int getTypeId() {
        return typeId;
    }
    
    public int getSize() {
        return size;
    }
    
    public boolean isSigned() {
        return signed;
    }
    
    public boolean isBigEndian() {
        return bigEndian;
    }
    
    public boolean isVariableLength() {
        return size < 0;
    }
    
    /**
     * 获取固定大小的数据类型大小
     * @return 数据类型大小（字节），如果是变长类型返回-1
     */
    public int getFixedSize() {
        return size;
    }
    
    /**
     * 根据Java类型获取对应的MDF4数据类型
     */
    public static DataType fromJavaType(Class<?> javaType) {
        if (javaType == byte.class || javaType == Byte.class) {
            return INT8;
        } else if (javaType == short.class || javaType == Short.class) {
            return INT16;
        } else if (javaType == int.class || javaType == Integer.class) {
            return INT32;
        } else if (javaType == long.class || javaType == Long.class) {
            return INT64;
        } else if (javaType == float.class || javaType == Float.class) {
            return FLOAT;
        } else if (javaType == double.class || javaType == Double.class) {
            return DOUBLE;
        } else if (javaType == boolean.class || javaType == Boolean.class) {
            return BOOLEAN;
        } else if (javaType == String.class) {
            return STRING_UTF8;
        } else if (javaType == byte[].class) {
            return BYTE_ARRAY;
        }
        throw new IllegalArgumentException("Unsupported Java type: " + javaType);
    }
    
    /**
     * 根据类型ID获取数据类型
     */
    public static DataType fromTypeId(int typeId) {
        for (DataType type : values()) {
            if (type.typeId == typeId) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown type ID: " + typeId);
    }
}
