# Java数据观察器系统 - 项目结构

## 1. 目录结构

```
data-observer/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── dataobserver/
│   │   │           ├── core/                          # 核心接口和实现
│   │   │           │   ├── DataObserver.java          # 数据观察器主接口
│   │   │           │   ├── DataSample.java            # 数据样本接口
│   │   │           │   ├── ObservableSource.java      # 可观察数据源接口
│   │   │           │   ├── DataCollector.java         # 数据收集器接口
│   │   │           │   ├── DataBuffer.java            # 数据缓冲区接口
│   │   │           │   ├── SourceMetadata.java        # 数据源元数据接口
│   │   │           │   ├── DataType.java              # 数据类型枚举
│   │   │           │   ├── ObserverState.java         # 观察器状态枚举
│   │   │           │   ├── ObserverConfig.java        # 观察器配置
│   │   │           │   ├── ObserverStats.java         # 观察统计接口
│   │   │           │   ├── CollectionStats.java       # 收集统计接口
│   │   │           │   ├── DataChangeListener.java    # 数据变化监听器
│   │   │           │   ├── ObserverEventListener.java # 观察器事件监听器
│   │   │           │   └── impl/                      # 核心实现
│   │   │           │       ├── DataObserverImpl.java  # 观察器实现
│   │   │           │       ├── DataSampleImpl.java    # 数据样本实现
│   │   │           │       ├── DataCollectorImpl.java # 收集器实现
│   │   │           │       ├── RingBuffer.java        # 环形缓冲区实现
│   │   │           │       └── SourceMetadataImpl.java# 元数据实现
│   │   │           │
│   │   │           ├── source/                        # 数据源实现
│   │   │           │   ├── AbstractObservableSource.java
│   │   │           │   ├── FieldObservableSource.java
│   │   │           │   ├── MethodObservableSource.java
│   │   │           │   ├── SupplierObservableSource.java
│   │   │           │   ├── ProxyObservableSource.java
│   │   │           │   ├── CompositeObservableSource.java
│   │   │           │   ├── ObservableSourceBuilder.java
│   │   │           │   └── ObservableSourceFactory.java
│   │   │           │
│   │   │           ├── storage/                       # 存储层实现
│   │   │           │   ├── DataStorage.java           # 存储接口
│   │   │           │   ├── StorageException.java      # 存储异常
│   │   │           │   ├── AbstractDataStorage.java   # 存储抽象基类
│   │   │           │   ├── MDF4DataStorage.java       # MDF4格式实现
│   │   │           │   ├── CSVDataStorage.java        # CSV格式实现
│   │   │           │   ├── HDF5DataStorage.java       # HDF5格式实现
│   │   │           │   └── StorageFactory.java        # 存储工厂
│   │   │           │
│   │   │           ├── serialization/                 # 序列化实现
│   │   │           │   ├── DataSerializer.java        # 序列化器接口
│   │   │           │   ├── AbstractDataSerializer.java
│   │   │           │   ├── MDF4DataSerializer.java
│   │   │           │   ├── CSVDataSerializer.java
│   │   │           │   ├── HDF5DataSerializer.java
│   │   │           │   ├── JSONDataSerializer.java
│   │   │           │   └── SerializerFactory.java
│   │   │           │
│   │   │           ├── annotation/                    # 注解支持（可选）
│   │   │           │   ├── Observable.java
│   │   │           │   └── SampleRate.java
│   │   │           │
│   │   │           └── util/                          # 工具类
│   │   │               ├── ByteBufferPool.java
│   │   │               └── TimeUtils.java
│   │   │
│   │   └── resources/
│   │       └── log4j2.xml
│   │
│   └── test/
│       └── java/
│           └── com/
│               └── dataobserver/
│                   ├── core/
│                   │   ├── DataObserverTest.java
│                   │   ├── RingBufferTest.java
│                   │   └── DataCollectorTest.java
│                   ├── storage/
│                   │   ├── MDF4StorageTest.java
│                   │   └── CSVStorageTest.java
│                   └── benchmark/
│                       └── PerformanceBenchmark.java
│
├── docs/
│   ├── architecture.md
│   ├── class-diagram.md
│   ├── api-guide.md
│   └── examples.md
│
├── lib/                           # 第三方库（HDF5等）
│   └── jhdf5.jar
│
├── output/                        # 输出目录
│   └── data/
│
├── pom.xml                        # Maven配置
├── build.gradle                   # Gradle配置
└── README.md
```

## 2. Maven依赖配置 (pom.xml)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.dataobserver</groupId>
    <artifactId>data-observer</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>Data Observer</name>
    <description>High-performance data observation system for Java applications</description>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <junit.version>5.8.2</junit.version>
    </properties>

    <dependencies>
        <!-- HDF5 Support (Optional) -->
        <dependency>
            <groupId>cisd</groupId>
            <artifactId>jhdf5</artifactId>
            <version>19.04.0</version>
            <optional>true</optional>
        </dependency>

        <!-- Logging -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
            <version>1.7.36</version>
        </dependency>
        <dependency>
            <groupId>org.apache.logging.log4j</groupId>
            <artifactId>log4j-slf4j-impl</artifactId>
            <version>2.17.2</version>
        </dependency>

        <!-- Testing -->
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>${junit.version}</version>
            <scope>test</scope>
        </dependency>

        <!-- Benchmark -->
        <dependency>
            <groupId>org.openjdk.jmh</groupId>
            <artifactId>jmh-core</artifactId>
            <version>1.35</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.10.1</version>
                <configuration>
                    <source>11</source>
                    <target>11</target>
                </configuration>
            </plugin>

            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-surefire-plugin</artifactId>
                <version>3.0.0-M7</version>
            </plugin>

            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-jar-plugin</artifactId>
                <version>3.2.2</version>
                <configuration>
                    <archive>
                        <manifest>
                            <addClasspath>true</addClasspath>
                            <classpathPrefix>lib/</classpathPrefix>
                        </manifest>
                    </archive>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
```

## 3. Gradle配置 (build.gradle)

```groovy
plugins {
    id 'java'
    id 'idea'
}

group = 'com.dataobserver'
version = '1.0.0'

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

repositories {
    mavenCentral()
    // HDF5 repository
    maven { url 'https://maven.imagej.net/content/repositories/public/' }
}

dependencies {
    // HDF5 Support (Optional)
    compileOnly 'cisd:jhdf5:19.04.0'

    // Logging
    implementation 'org.slf4j:slf4j-api:1.7.36'
    implementation 'org.apache.logging.log4j:log4j-slf4j-impl:2.17.2'

    // Testing
    testImplementation 'org.junit.jupiter:junit-jupiter:5.8.2'
    testImplementation 'org.openjdk.jmh:jmh-core:1.35'
}

test {
    useJUnitPlatform()
    testLogging {
        events "passed", "skipped", "failed"
    }
}

jar {
    manifest {
        attributes(
            'Implementation-Title': 'Data Observer',
            'Implementation-Version': version
        )
    }
}
```

## 4. 核心组件包依赖关系

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           包依赖关系图                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌──────────────┐                                                          │
│   │     core     │                                                          │
│   │   (核心接口)  │                                                          │
│   └──────┬───────┘                                                          │
│          │                                                                  │
│     ┌────┴────┬────────────┬────────────┐                                   │
│     ▼         ▼            ▼            ▼                                   │
│  ┌──────┐  ┌──────┐   ┌────────┐   ┌──────────┐                            │
│  │source│  │storage│   │serialization│   │annotation│                            │
│  │(数据源)│  │(存储层)│   │(序列化)   │   │(注解)    │                            │
│  └──┬───┘  └──┬───┘   └────┬───┘   └────┬─────┘                            │
│     │         │            │              │                                 │
│     └─────────┴────────────┴──────────────┘                                 │
│                    │                                                        │
│                    ▼                                                        │
│               ┌────────┐                                                    │
│               │  util  │                                                    │
│               │(工具类) │                                                    │
│               └────────┘                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 5. 关键类职责说明

| 包路径 | 类名 | 职责 |
|--------|------|------|
| `core` | `DataObserver` | 系统主接口，管理所有组件 |
| `core` | `DataSample` | 单次数据采集的封装 |
| `core` | `ObservableSource` | 可观察数据源接口 |
| `core` | `DataCollector` | 数据收集器接口 |
| `core` | `DataBuffer` | 数据缓冲区接口 |
| `core` | `DataType` | 支持的数据类型枚举 |
| `core.impl` | `DataObserverImpl` | 观察器实现（外观模式） |
| `core.impl` | `DataSampleImpl` | 数据样本实现（对象池） |
| `core.impl` | `RingBuffer` | 无锁环形缓冲区 |
| `core.impl` | `DataCollectorImpl` | 批量收集器实现 |
| `source` | `FieldObservableSource` | 字段数据源 |
| `source` | `MethodObservableSource` | 方法数据源 |
| `source` | `SupplierObservableSource` | 函数式数据源 |
| `source` | `ObservableSourceBuilder` | 数据源构建器 |
| `storage` | `DataStorage` | 存储接口 |
| `storage` | `AbstractDataStorage` | 存储抽象基类 |
| `storage` | `MDF4DataStorage` | MDF4格式存储 |
| `storage` | `CSVDataStorage` | CSV格式存储 |
| `storage` | `StorageFactory` | 存储工厂 |
| `serialization` | `DataSerializer` | 序列化器接口 |
| `serialization` | `MDF4DataSerializer` | MDF4序列化器 |
| `serialization` | `SerializerFactory` | 序列化器工厂 |

## 6. 模块划分建议

```
data-observer-parent/
├── data-observer-core/          # 核心模块（必须）
│   ├── 核心接口
│   ├── 基础实现
│   └── 无锁缓冲区
│
├── data-observer-source/        # 数据源模块（必须）
│   ├── 字段数据源
│   ├── 方法数据源
│   └── 构建器/工厂
│
├── data-observer-storage-mdf4/  # MDF4存储模块（可选）
│   └── MDF4格式支持
│
├── data-observer-storage-csv/   # CSV存储模块（可选）
│   └── CSV格式支持
│
├── data-observer-storage-hdf5/  # HDF5存储模块（可选）
│   └── HDF5格式支持
│
└── data-observer-examples/      # 示例模块
    └── 各种使用示例
```

