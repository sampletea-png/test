package com.dataobserver.storage.core;

import java.io.IOException;
import java.util.List;

/**
 * 批量存储接口
 * 优化大批量数据写入的存储格式实现此接口
 */
public interface BatchStorage {
    
    /**
     * 批量写入缓冲区大小（字节）
     */
    int DEFAULT_BATCH_SIZE = 1024 * 1024; // 1MB
    
    /**
     * 设置批量写入缓冲区大小
     * @param batchSize 缓冲区大小（字节）
     */
    void setBatchSize(int batchSize);
    
    /**
     * 获取当前批量写入缓冲区大小
     */
    int getBatchSize();
    
    /**
     * 开始批量写入模式
     * @throws IOException 开始失败时抛出
     */
    void beginBatch() throws IOException;
    
    /**
     * 提交批量写入
     * @throws IOException 提交失败时抛出
     */
    void commitBatch() throws IOException;
    
    /**
     * 回滚批量写入
     * @throws IOException 回滚失败时抛出
     */
    void rollbackBatch() throws IOException;
    
    /**
     * 是否在批量写入模式
     */
    boolean isInBatchMode();
    
    /**
     * 获取批量写入队列大小
     */
    int getBatchQueueSize();
    
    /**
     * 批量写入数据块
     * @param dataBlocks 数据块列表
     * @throws IOException 写入失败时抛出
     */
    <T> void writeDataBlocks(List<DataBlock<T>> dataBlocks) throws IOException;
    
    /**
     * 数据块类
     */
    class DataBlock<T> {
        private final String channelName;
        private final long[] timestamps;
        private final T[] values;
        private final DataType dataType;
        
        public DataBlock(String channelName, long[] timestamps, T[] values, DataType dataType) {
            this.channelName = channelName;
            this.timestamps = timestamps;
            this.values = values;
            this.dataType = dataType;
        }
        
        public String getChannelName() { return channelName; }
        public long[] getTimestamps() { return timestamps; }
        public T[] getValues() { return values; }
        public DataType getDataType() { return dataType; }
        public int getSize() { return timestamps.length; }
    }
    
    /**
     * 数据类型枚举
     */
    enum DataType {
        INT8, INT16, INT32, INT64,
        UINT8, UINT16, UINT32, UINT64,
        FLOAT32, FLOAT64,
        BOOLEAN,
        STRING,
        BYTE_ARRAY,
        UNKNOWN
    }
}
