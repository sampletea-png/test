package com.dataobserver.storage.core;

/**
 * 存储格式枚举
 * 定义系统支持的所有存储格式
 * 新增格式时只需在此添加枚举值
 */
public enum StorageFormat {
    
    /**
     * MDF4格式 - Measurement Data Format 4.0
     * 汽车测量数据标准格式
     */
    MDF4("mdf4", "MDF4", "Measurement Data Format 4.0"),
    
    /**
     * CSV格式 - 逗号分隔值
     * 通用文本格式，便于查看和导入
     */
    CSV("csv", "CSV", "Comma Separated Values"),
    
    /**
     * HDF5格式 - 层次数据格式
     * 科学计算常用格式
     */
    HDF5("hdf5", "HDF5", "Hierarchical Data Format 5"),
    
    /**
     * Parquet格式 - 列式存储
     * 大数据处理常用格式
     */
    PARQUET("parquet", "Parquet", "Apache Parquet Columnar Format"),
    
    /**
     * 自定义二进制格式
     * 高性能专用格式
     */
    BINARY("bin", "Binary", "Custom Binary Format"),
    
    /**
     * JSON格式
     * 便于Web集成的格式
     */
    JSON("json", "JSON", "JavaScript Object Notation");
    
    private final String extension;
    private final String displayName;
    private final String description;
    
    StorageFormat(String extension, String displayName, String description) {
        this.extension = extension;
        this.displayName = displayName;
        this.description = description;
    }
    
    public String getExtension() {
        return extension;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getDescription() {
        return description;
    }
    
    /**
     * 根据扩展名获取存储格式
     */
    public static StorageFormat fromExtension(String extension) {
        for (StorageFormat format : values()) {
            if (format.extension.equalsIgnoreCase(extension)) {
                return format;
            }
        }
        throw new IllegalArgumentException("不支持的存储格式扩展名: " + extension);
    }
    
    /**
     * 根据名称获取存储格式
     */
    public static StorageFormat fromName(String name) {
        for (StorageFormat format : values()) {
            if (format.name().equalsIgnoreCase(name) || 
                format.displayName.equalsIgnoreCase(name)) {
                return format;
            }
        }
        throw new IllegalArgumentException("不支持的存储格式名称: " + name);
    }
}
