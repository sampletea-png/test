package com.dataobserver.storage.core;

import java.io.IOException;

/**
 * 可追加存储接口
 * 支持向已有文件追加数据的存储格式实现此接口
 */
public interface AppendableStorage {
    
    /**
     * 打开已有文件进行追加
     * @param appendMode 追加模式
     * @throws IOException 打开失败时抛出
     */
    void openForAppend(AppendMode appendMode) throws IOException;
    
    /**
     * 检查是否支持追加模式
     */
    boolean supportsAppend();
    
    /**
     * 获取文件末尾位置
     */
    long getEndPosition() throws IOException;
    
    /**
     * 追加模式枚举
     */
    enum AppendMode {
        /**
         * 严格追加 - 只允许在末尾添加
         */
        STRICT,
        
        /**
         * 合并追加 - 合并重复通道的数据
         */
        MERGE,
        
        /**
         * 覆盖追加 - 允许覆盖已有数据
         */
        OVERWRITE
    }
}
