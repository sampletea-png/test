package com.dataobserver.storage.core;

import com.dataobserver.storage.metadata.StorageMetadata;
import com.dataobserver.storage.metadata.ChannelMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * 数据存储接口
 * 所有存储格式的抽象接口，定义统一的存储操作
 * 
 * 设计原则：
 * 1. 接口隔离：将不同职责分离到不同接口
 * 2. 开闭原则：对扩展开放，对修改关闭
 * 3. 依赖倒置：依赖抽象而非具体实现
 */
public interface DataStorage extends AutoCloseable {
    
    // ==================== 生命周期管理 ====================
    
    /**
     * 初始化存储
     * @param filePath 存储文件路径
     * @param metadata 存储元数据
     * @throws IOException 初始化失败时抛出
     */
    void initialize(Path filePath, StorageMetadata metadata) throws IOException;
    
    /**
     * 检查存储是否已初始化
     */
    boolean isInitialized();
    
    /**
     * 获取存储格式类型
     */
    StorageFormat getFormat();
    
    /**
     * 获取当前存储文件路径
     */
    Path getFilePath();
    
    // ==================== 数据写入操作 ====================
    
    /**
     * 写入单条数据记录
     * @param channelName 通道名称
     * @param timestamp 时间戳（纳秒或微秒）
     * @param value 数据值
     * @throws IOException 写入失败时抛出
     */
    void writeRecord(String channelName, long timestamp, Object value) throws IOException;
    
    /**
     * 批量写入数据记录
     * @param channelName 通道名称
     * @param timestamps 时间戳数组
     * @param values 数据值数组
     * @throws IOException 写入失败时抛出
     */
    void writeRecords(String channelName, long[] timestamps, Object[] values) throws IOException;
    
    /**
     * 写入多个通道的同步数据
     * @param timestamp 时间戳
     * @param channelValues 通道名到值的映射
     * @throws IOException 写入失败时抛出
     */
    void writeSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException;
    
    /**
     * 批量写入多个通道的同步数据
     * @param timestamps 时间戳数组
     * @param channelData 通道数据映射（通道名 -> 值数组）
     * @throws IOException 写入失败时抛出
     */
    void writeSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException;
    
    // ==================== 数据读取操作 ====================
    
    /**
     * 读取指定通道的所有数据
     * @param channelName 通道名称
     * @return 数据数组
     * @throws IOException 读取失败时抛出
     */
    Object[] readChannel(String channelName) throws IOException;
    
    /**
     * 读取指定时间范围的数据
     * @param channelName 通道名称
     * @param startTime 开始时间戳
     * @param endTime 结束时间戳
     * @return 数据数组
     * @throws IOException 读取失败时抛出
     */
    Object[] readChannelRange(String channelName, long startTime, long endTime) throws IOException;
    
    /**
     * 获取所有通道名称
     */
    List<String> getChannelNames() throws IOException;
    
    // ==================== 元数据操作 ====================
    
    /**
     * 添加通道元数据
     * @param channelMetadata 通道元数据
     */
    void addChannelMetadata(ChannelMetadata channelMetadata);
    
    /**
     * 获取通道元数据
     * @param channelName 通道名称
     * @return 通道元数据
     */
    ChannelMetadata getChannelMetadata(String channelName);
    
    /**
     * 获取所有通道元数据
     */
    List<ChannelMetadata> getAllChannelMetadata();
    
    /**
     * 更新存储元数据
     */
    void updateMetadata(StorageMetadata metadata);
    
    /**
     * 获取存储元数据
     */
    StorageMetadata getMetadata();
    
    // ==================== 存储管理 ====================
    
    /**
     * 刷新数据到磁盘
     * @throws IOException 刷新失败时抛出
     */
    void flush() throws IOException;
    
    /**
     * 获取当前存储大小（字节）
     */
    long getSize() throws IOException;
    
    /**
     * 获取已写入的记录数
     */
    long getRecordCount();
    
    /**
     * 关闭存储
     * @throws IOException 关闭失败时抛出
     */
    @Override
    void close() throws IOException;
}
