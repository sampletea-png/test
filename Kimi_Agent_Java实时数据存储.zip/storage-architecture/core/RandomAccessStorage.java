package com.dataobserver.storage.core;

import java.io.IOException;

/**
 * 随机访问存储接口
 * 支持随机读写位置的存储格式实现此接口
 */
public interface RandomAccessStorage {
    
    /**
     * 定位到指定位置
     * @param position 文件位置（字节）
     * @throws IOException 定位失败时抛出
     */
    void seek(long position) throws IOException;
    
    /**
     * 获取当前位置
     */
    long getPosition() throws IOException;
    
    /**
     * 读取指定位置的数据
     * @param position 文件位置
     * @param length 读取长度
     * @return 读取的字节数据
     * @throws IOException 读取失败时抛出
     */
    byte[] readAt(long position, int length) throws IOException;
    
    /**
     * 写入数据到指定位置
     * @param position 文件位置
     * @param data 要写入的数据
     * @throws IOException 写入失败时抛出
     */
    void writeAt(long position, byte[] data) throws IOException;
    
    /**
     * 获取文件总大小
     */
    long getTotalSize() throws IOException;
    
    /**
     * 检查是否支持随机写入
     */
    boolean supportsRandomWrite();
}
