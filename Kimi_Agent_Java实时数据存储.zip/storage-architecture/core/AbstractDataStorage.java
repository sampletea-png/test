package com.dataobserver.storage.core;

import com.dataobserver.storage.metadata.ChannelMetadata;
import com.dataobserver.storage.metadata.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据存储抽象基类
 * 提供数据存储的通用实现
 */
public abstract class AbstractDataStorage implements DataStorage {
    
    // 状态
    protected final AtomicBoolean initialized = new AtomicBoolean(false);
    protected final AtomicBoolean closed = new AtomicBoolean(false);
    
    // 文件路径
    protected Path filePath;
    
    // 元数据
    protected StorageMetadata storageMetadata;
    protected final Map<String, ChannelMetadata> channelMetadataMap = new ConcurrentHashMap<>();
    
    // 统计
    protected final AtomicLong recordCount = new AtomicLong(0);
    protected final AtomicLong writeCount = new AtomicLong(0);
    
    // 缓冲区
    protected final Map<String, List<DataPoint>> writeBuffer = new HashMap<>();
    protected int bufferSize = 1000;
    protected boolean bufferingEnabled = true;
    
    /**
     * 数据点内部类
     */
    protected static class DataPoint {
        final long timestamp;
        final Object value;
        
        DataPoint(long timestamp, Object value) {
            this.timestamp = timestamp;
            this.value = value;
        }
    }
    
    // ==================== 生命周期管理 ====================
    
    @Override
    public void initialize(Path filePath, StorageMetadata metadata) throws IOException {
        if (initialized.get()) {
            throw new IllegalStateException("存储已经初始化");
        }
        
        this.filePath = filePath;
        this.storageMetadata = metadata != null ? metadata : new StorageMetadata();
        
        // 确保目录存在
        Path parent = filePath.getParent();
        if (parent != null) {
            java.nio.file.Files.createDirectories(parent);
        }
        
        doInitialize();
        
        initialized.set(true);
        closed.set(false);
    }
    
    /**
     * 实际初始化操作，子类实现
     */
    protected abstract void doInitialize() throws IOException;
    
    @Override
    public boolean isInitialized() {
        return initialized.get();
    }
    
    @Override
    public Path getFilePath() {
        return filePath;
    }
    
    // ==================== 数据写入操作 ====================
    
    @Override
    public void writeRecord(String channelName, long timestamp, Object value) throws IOException {
        ensureOpen();
        
        if (bufferingEnabled) {
            bufferRecord(channelName, timestamp, value);
        } else {
            doWriteRecord(channelName, timestamp, value);
            recordCount.incrementAndGet();
        }
        
        writeCount.incrementAndGet();
    }
    
    @Override
    public void writeRecords(String channelName, long[] timestamps, Object[] values) throws IOException {
        ensureOpen();
        
        if (timestamps.length != values.length) {
            throw new IllegalArgumentException("时间戳数组和值数组长度不一致");
        }
        
        doWriteRecords(channelName, timestamps, values);
        recordCount.addAndGet(timestamps.length);
        writeCount.incrementAndGet();
    }
    
    @Override
    public void writeSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException {
        ensureOpen();
        
        doWriteSyncRecord(timestamp, channelValues);
        recordCount.addAndGet(channelValues.size());
        writeCount.incrementAndGet();
    }
    
    @Override
    public void writeSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException {
        ensureOpen();
        
        doWriteSyncRecords(timestamps, channelData);
        recordCount.addAndGet(timestamps.length * channelData.size());
        writeCount.incrementAndGet();
    }
    
    /**
     * 缓冲单条记录
     */
    protected void bufferRecord(String channelName, long timestamp, Object value) throws IOException {
        List<DataPoint> buffer = writeBuffer.computeIfAbsent(channelName, k -> new ArrayList<>());
        buffer.add(new DataPoint(timestamp, value));
        
        if (buffer.size() >= bufferSize) {
            flushBuffer(channelName);
        }
    }
    
    /**
     * 刷新指定通道的缓冲区
     */
    protected void flushBuffer(String channelName) throws IOException {
        List<DataPoint> buffer = writeBuffer.get(channelName);
        if (buffer == null || buffer.isEmpty()) {
            return;
        }
        
        long[] timestamps = new long[buffer.size()];
        Object[] values = new Object[buffer.size()];
        
        for (int i = 0; i < buffer.size(); i++) {
            DataPoint dp = buffer.get(i);
            timestamps[i] = dp.timestamp;
            values[i] = dp.value;
        }
        
        doWriteRecords(channelName, timestamps, values);
        recordCount.addAndGet(buffer.size());
        buffer.clear();
    }
    
    /**
     * 刷新所有缓冲区
     */
    protected void flushAllBuffers() throws IOException {
        for (String channelName : new ArrayList<>(writeBuffer.keySet())) {
            flushBuffer(channelName);
        }
    }
    
    // ==================== 抽象写入方法 - 子类实现 ====================
    
    protected abstract void doWriteRecord(String channelName, long timestamp, Object value) throws IOException;
    
    protected abstract void doWriteRecords(String channelName, long[] timestamps, Object[] values) throws IOException;
    
    protected abstract void doWriteSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException;
    
    protected abstract void doWriteSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException;
    
    // ==================== 数据读取操作 ====================
    
    @Override
    public abstract Object[] readChannel(String channelName) throws IOException;
    
    @Override
    public abstract Object[] readChannelRange(String channelName, long startTime, long endTime) throws IOException;
    
    @Override
    public abstract List<String> getChannelNames() throws IOException;
    
    // ==================== 元数据操作 ====================
    
    @Override
    public void addChannelMetadata(ChannelMetadata channelMetadata) {
        if (channelMetadata == null || channelMetadata.getName() == null) {
            throw new IllegalArgumentException("通道元数据不能为空");
        }
        
        channelMetadataMap.put(channelMetadata.getName(), channelMetadata);
        
        if (storageMetadata != null) {
            storageMetadata.setChannelCount(channelMetadataMap.size());
        }
    }
    
    @Override
    public ChannelMetadata getChannelMetadata(String channelName) {
        return channelMetadataMap.get(channelName);
    }
    
    @Override
    public List<ChannelMetadata> getAllChannelMetadata() {
        return new ArrayList<>(channelMetadataMap.values());
    }
    
    @Override
    public void updateMetadata(StorageMetadata metadata) {
        this.storageMetadata = metadata;
    }
    
    @Override
    public StorageMetadata getMetadata() {
        return storageMetadata;
    }
    
    // ==================== 存储管理 ====================
    
    @Override
    public void flush() throws IOException {
        ensureOpen();
        flushAllBuffers();
        doFlush();
    }
    
    /**
     * 实际刷新操作，子类实现
     */
    protected abstract void doFlush() throws IOException;
    
    @Override
    public long getRecordCount() {
        return recordCount.get();
    }
    
    @Override
    public void close() throws IOException {
        if (closed.compareAndSet(false, true)) {
            try {
                flush();
            } finally {
                doClose();
                initialized.set(false);
            }
        }
    }
    
    /**
     * 实际关闭操作，子类实现
     */
    protected abstract void doClose() throws IOException;
    
    // ==================== 辅助方法 ====================
    
    /**
     * 确保存储已打开
     */
    protected void ensureOpen() {
        if (!initialized.get()) {
            throw new IllegalStateException("存储未初始化");
        }
        if (closed.get()) {
            throw new IllegalStateException("存储已关闭");
        }
    }
    
    /**
     * 设置缓冲区大小
     */
    public void setBufferSize(int bufferSize) {
        this.bufferSize = bufferSize;
    }
    
    /**
     * 启用/禁用缓冲
     */
    public void setBufferingEnabled(boolean enabled) {
        this.bufferingEnabled = enabled;
    }
    
    /**
     * 获取写入计数
     */
    public long getWriteCount() {
        return writeCount.get();
    }
}
