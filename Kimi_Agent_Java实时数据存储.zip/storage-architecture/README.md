# 可扩展数据存储架构

## 项目概述

本项目为Java数据观察器系统设计了一套可扩展的存储架构，支持多种数据存储格式，并提供统一的抽象接口。

## 核心特性

- **格式抽象**: 统一的 `DataStorage` 接口，隐藏具体格式差异
- **可扩展性**: 通过工厂模式和提供者模式，轻松添加新的存储格式
- **配置驱动**: 通过配置对象创建和配置存储实例
- **大数据处理**: 支持分块存储和多种滚动策略
- **元数据管理**: 完整的存储和通道元数据管理

## 支持的存储格式

| 格式 | 扩展名 | 特性支持 |
|------|--------|----------|
| MDF4 | .mf4, .mdf | 读写、追加、批量、随机访问、分块 |
| CSV | .csv, .txt | 读写、追加、分块 |
| HDF5 | .h5, .hdf5 | 读写、批量、压缩、分块 |
| Parquet | .parquet | 读写、批量、压缩、分块 |
| Binary | .bin, .dat | 读写、随机访问、分块 |

## 项目结构

```
storage-architecture/
├── core/                       # 核心接口和抽象类
│   ├── StorageFormat.java      # 存储格式枚举
│   ├── DataStorage.java        # 存储接口
│   ├── AbstractDataStorage.java # 存储抽象基类
│   ├── AppendableStorage.java  # 可追加接口
│   ├── BatchStorage.java       # 批量存储接口
│   └── RandomAccessStorage.java # 随机访问接口
├── chunk/                      # 分块存储
│   ├── ChunkStorage.java       # 分块存储接口
│   ├── AbstractChunkStorage.java # 分块存储抽象基类
│   ├── RolloverStrategy.java   # 滚动策略接口
│   └── RolloverStrategies.java # 滚动策略实现
├── metadata/                   # 元数据管理
│   ├── StorageMetadata.java    # 存储元数据
│   └── ChannelMetadata.java    # 通道元数据
├── factory/                    # 工厂模式
│   ├── StorageFactory.java     # 存储工厂
│   ├── StorageProvider.java    # 存储提供者接口
│   ├── StorageConfiguration.java # 存储配置
│   └── ChunkConfiguration.java # 分块配置
├── format/                     # 具体格式实现
│   ├── MDF4Storage.java        # MDF4实现
│   ├── CSVStorage.java         # CSV实现
│   ├── HDF5Storage.java        # HDF5实现
│   ├── ParquetStorage.java     # Parquet实现
│   └── BinaryStorage.java      # 二进制实现
├── StorageUsageExample.java    # 使用示例
├── EXTENDING_GUIDE.md          # 扩展指南
└── README.md                   # 本文档
```

## 快速开始

### 1. 注册存储提供者

```java
StorageFactory factory = StorageFactory.getInstance();

// 注册MDF4提供者
factory.registerProvider(StorageFormat.MDF4, new MDF4Storage.Provider());

// 注册其他提供者...
```

### 2. 创建存储实例

```java
// 方式1: 直接创建
Path filePath = Paths.get("/data/output.mf4");
StorageMetadata metadata = new StorageMetadata("测试数据");

try (DataStorage storage = factory.createStorage(StorageFormat.MDF4, filePath, metadata)) {
    // 使用存储...
}

// 方式2: 配置驱动
StorageConfiguration config = StorageConfiguration.builder()
    .name("配置测试")
    .filePath(Paths.get("/data/output.csv"))
    .format(StorageFormat.CSV)
    .bufferSize(1000)
    .build();

try (DataStorage storage = factory.createStorage(config)) {
    // 使用存储...
}
```

### 3. 写入数据

```java
// 单条写入
storage.writeRecord("Channel1", System.currentTimeMillis(), 100.0);

// 批量写入
long[] timestamps = new long[1000];
Object[] values = new Object[1000];
// ... 填充数据
storage.writeRecords("Channel1", timestamps, values);

// 同步写入多通道
Map<String, Object> data = new HashMap<>();
data.put("Temperature", 25.5);
data.put("Pressure", 101.3);
storage.writeSyncRecord(System.currentTimeMillis(), data);
```

### 4. 读取数据

```java
// 读取全部数据
Object[] allData = storage.readChannel("Channel1");

// 读取时间范围
long startTime = System.currentTimeMillis() - 60000; // 1分钟前
long endTime = System.currentTimeMillis();
Object[] rangeData = storage.readChannelRange("Channel1", startTime, endTime);

// 获取通道列表
List<String> channels = storage.getChannelNames();
```

## 分块存储

### 使用分块存储

```java
// 创建分块配置
ChunkConfiguration chunkConfig = ChunkConfiguration.builder()
    .maxChunkSize(100 * 1024 * 1024)  // 100MB
    .maxRecordsPerChunk(1_000_000)
    .chunkTimeInterval(5 * 60 * 1000)  // 5分钟
    .build();

StorageConfiguration config = StorageConfiguration.builder()
    .name("分块测试")
    .filePath(Paths.get("/data/chunked/test.mf4"))
    .format(StorageFormat.MDF4)
    .chunkConfig(chunkConfig)
    .build();

try (ChunkStorage storage = (ChunkStorage) factory.createStorage(config)) {
    // 写入数据，自动触发分块
    for (int i = 0; i < 1000000; i++) {
        storage.writeRecord("Channel1", System.currentTimeMillis(), (double) i);
    }
    
    // 获取分块信息
    System.out.println("总分块数: " + storage.getTotalChunkCount());
    System.out.println("分块文件: " + storage.getChunkFiles());
    
    // 手动触发分块
    storage.rollover();
    
    // 合并分块
    storage.mergeChunks(Paths.get("/data/chunked/merged.mf4"));
}
```

### 滚动策略

```java
// 基于文件大小
RolloverStrategy sizeStrategy = RolloverStrategies.size100MB();

// 基于时间
RolloverStrategy timeStrategy = RolloverStrategies.time5Minutes();

// 基于记录数
RolloverStrategy countStrategy = RolloverStrategies.records1M();

// 组合策略
RolloverStrategy composite = RolloverStrategies.createSizeOrTimeStrategy(
    100 * 1024 * 1024,  // 100MB
    5 * 60 * 1000       // 或5分钟
);
```

## 扩展新格式

参考 [EXTENDING_GUIDE.md](EXTENDING_GUIDE.md) 了解如何添加新的存储格式支持。

简要步骤：

1. 创建存储类实现 `DataStorage` 接口
2. 创建提供者类实现 `StorageProvider` 接口
3. 注册提供者到 `StorageFactory`
4. 使用新格式创建存储

## 设计模式

本架构使用了以下设计模式：

| 模式 | 应用位置 | 目的 |
|------|----------|------|
| 策略模式 | `RolloverStrategy` | 运行时切换滚动策略 |
| 工厂模式 | `StorageFactory` | 动态创建存储实例 |
| 抽象工厂 | `StorageProvider` | 统一格式创建接口 |
| 模板方法 | `AbstractDataStorage` | 定义存储操作骨架 |
| 接口隔离 | `AppendableStorage` 等 | 细粒度接口设计 |

## 依赖说明

### 必需依赖

- Java 11+

### 可选依赖（根据使用的格式）

- **MDF4**: asammdf 或 MDF4J 库
- **HDF5**: JHDF5 或 HDFJava 库
- **Parquet**: Apache Parquet Java 库
- **CSV**: 无额外依赖

## 性能考虑

### 写入优化

1. **使用批量写入**: 减少I/O次数
2. **启用缓冲**: 设置合适的缓冲区大小
3. **使用分块存储**: 避免单文件过大

### 读取优化

1. **时间范围查询**: 避免读取全部数据
2. **使用随机访问**: 直接定位到数据位置
3. **缓存元数据**: 避免重复读取

## 配置参考

### StorageConfiguration 属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| name | String | null | 存储名称 |
| description | String | null | 存储描述 |
| filePath | Path | 必填 | 文件路径 |
| format | StorageFormat | 必填 | 存储格式 |
| bufferSize | int | 1000 | 缓冲区大小 |
| bufferingEnabled | boolean | true | 是否启用缓冲 |
| compressionEnabled | boolean | false | 是否启用压缩 |
| chunkConfig | ChunkConfiguration | null | 分块配置 |

### ChunkConfiguration 属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| maxChunkSize | long | 500MB | 最大分块大小 |
| maxRecordsPerChunk | long | 1000万 | 最大记录数 |
| chunkTimeInterval | long | 5分钟 | 分块时间间隔 |
| rolloverStrategy | String | "default" | 滚动策略 |

## 示例代码

详见 [StorageUsageExample.java](StorageUsageExample.java) 获取完整使用示例。

## 许可证

本项目采用 MIT 许可证。

## 贡献

欢迎提交Issue和Pull Request来改进本项目。
