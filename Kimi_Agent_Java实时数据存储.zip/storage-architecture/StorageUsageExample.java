package com.dataobserver.storage;

import com.dataobserver.storage.chunk.ChunkStorage;
import com.dataobserver.storage.chunk.RolloverStrategies;
import com.dataobserver.storage.core.DataStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.factory.*;
import com.dataobserver.storage.format.*;
import com.dataobserver.storage.metadata.ChannelMetadata;
import com.dataobserver.storage.metadata.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * 存储系统使用示例
 * 演示如何使用可扩展存储架构
 */
public class StorageUsageExample {
    
    public static void main(String[] args) throws IOException {
        // 注册存储提供者
        registerProviders();
        
        // 示例1: 基本使用
        basicUsage();
        
        // 示例2: 使用配置创建存储
        configurationDrivenUsage();
        
        // 示例3: 分块存储
        chunkedStorageUsage();
        
        // 示例4: 批量写入
        batchWriteUsage();
        
        // 示例5: 追加模式
        appendModeUsage();
        
        // 示例6: 格式切换
        formatSwitchingUsage();
    }
    
    /**
     * 注册所有存储提供者
     */
    private static void registerProviders() {
        StorageFactory factory = StorageFactory.getInstance();
        
        // 注册MDF4提供者
        factory.registerProvider(StorageFormat.MDF4, new MDF4Storage.Provider());
        
        // 注册CSV提供者
        factory.registerProvider(StorageFormat.CSV, new CSVStorage.Provider());
        
        // 注册HDF5提供者
        factory.registerProvider(StorageFormat.HDF5, new HDF5Storage.Provider());
        
        // 注册Parquet提供者
        factory.registerProvider(StorageFormat.PARQUET, new ParquetStorage.Provider());
        
        // 注册二进制提供者
        factory.registerProvider(StorageFormat.BINARY, new BinaryStorage.Provider());
    }
    
    /**
     * 示例1: 基本使用
     */
    private static void basicUsage() throws IOException {
        System.out.println("=== 示例1: 基本使用 ===");
        
        Path filePath = Paths.get("/tmp/data/basic.mf4");
        StorageMetadata metadata = new StorageMetadata("基本测试");
        metadata.setDescription("存储系统基本使用示例");
        metadata.setCreator("DataObserver");
        metadata.setApplication("StorageExample");
        
        // 创建存储
        try (DataStorage storage = StorageFactory.getInstance()
                .createStorage(StorageFormat.MDF4, filePath, metadata)) {
            
            // 添加通道元数据
            ChannelMetadata channelMeta = new ChannelMetadata("EngineSpeed");
            channelMeta.setDisplayName("发动机转速");
            channelMeta.setUnit("rpm");
            channelMeta.setDataType(ChannelMetadata.DataType.FLOAT);
            channelMeta.setSampleRate(100); // 100Hz
            storage.addChannelMetadata(channelMeta);
            
            // 写入数据
            long baseTime = System.currentTimeMillis();
            for (int i = 0; i < 1000; i++) {
                long timestamp = baseTime + i * 10; // 10ms间隔
                float value = (float) (1000 + Math.sin(i * 0.1) * 500);
                storage.writeRecord("EngineSpeed", timestamp, value);
            }
            
            // 刷新到磁盘
            storage.flush();
            
            System.out.println("写入记录数: " + storage.getRecordCount());
            System.out.println("文件大小: " + storage.getSize() + " bytes");
        }
        
        System.out.println();
    }
    
    /**
     * 示例2: 使用配置创建存储
     */
    private static void configurationDrivenUsage() throws IOException {
        System.out.println("=== 示例2: 配置驱动使用 ===");
        
        // 使用构建器模式创建配置
        StorageConfiguration config = StorageConfiguration.builder()
            .name("配置驱动测试")
            .description("使用配置对象创建存储")
            .filePath(Paths.get("/tmp/data/config_driven.csv"))
            .format(StorageFormat.CSV)
            .creator("DataObserver")
            .application("StorageExample")
            .applicationVersion("1.0.0")
            .bufferSize(500)
            .bufferingEnabled(true)
            .property("custom.property", "value")
            .build();
        
        try (DataStorage storage = StorageFactory.getInstance().createStorage(config)) {
            
            // 写入多通道同步数据
            long baseTime = System.currentTimeMillis();
            for (int i = 0; i < 100; i++) {
                long timestamp = baseTime + i * 100;
                
                Map<String, Object> data = new HashMap<>();
                data.put("Temperature", 25.0 + Math.random() * 10);
                data.put("Pressure", 101.3 + Math.random() * 5);
                data.put("Humidity", 50.0 + Math.random() * 20);
                
                storage.writeSyncRecord(timestamp, data);
            }
            
            System.out.println("配置驱动写入完成");
            System.out.println("通道列表: " + storage.getChannelNames());
        }
        
        System.out.println();
    }
    
    /**
     * 示例3: 分块存储
     */
    private static void chunkedStorageUsage() throws IOException {
        System.out.println("=== 示例3: 分块存储 ===");
        
        // 创建分块配置
        ChunkConfiguration chunkConfig = ChunkConfiguration.builder()
            .maxChunkSize(10 * 1024 * 1024)  // 10MB
            .maxRecordsPerChunk(100_000)
            .chunkTimeInterval(60 * 1000)     // 1分钟
            .build();
        
        StorageConfiguration config = StorageConfiguration.builder()
            .name("分块存储测试")
            .filePath(Paths.get("/tmp/data/chunked/test.mf4"))
            .format(StorageFormat.MDF4)
            .chunkConfig(chunkConfig)
            .build();
        
        try (ChunkStorage storage = (ChunkStorage) StorageFactory.getInstance().createStorage(config)) {
            
            // 写入大量数据，触发分块
            long baseTime = System.currentTimeMillis();
            for (int i = 0; i < 10000; i++) {
                long timestamp = baseTime + i;
                storage.writeRecord("DataChannel", timestamp, (double) i);
                
                // 检查是否需要分块
                if (storage.shouldRollover()) {
                    System.out.println("分块滚动，当前分块索引: " + storage.getCurrentChunkIndex());
                    storage.rollover();
                }
            }
            
            System.out.println("总分块数: " + storage.getTotalChunkCount());
            System.out.println("分块文件列表:");
            for (Path chunkFile : storage.getChunkFiles()) {
                System.out.println("  - " + chunkFile);
            }
            
            // 合并分块（可选）
            // storage.mergeChunks(Paths.get("/tmp/data/chunked/merged.mf4"));
        }
        
        System.out.println();
    }
    
    /**
     * 示例4: 批量写入
     */
    private static void batchWriteUsage() throws IOException {
        System.out.println("=== 示例4: 批量写入 ===");
        
        Path filePath = Paths.get("/tmp/data/batch_write.bin");
        
        try (BinaryStorage storage = new BinaryStorage()) {
            storage.initialize(filePath, new StorageMetadata("批量写入测试"));
            
            // 准备批量数据
            int batchSize = 10000;
            long[] timestamps = new long[batchSize];
            Object[] values = new Object[batchSize];
            
            long baseTime = System.currentTimeMillis();
            for (int i = 0; i < batchSize; i++) {
                timestamps[i] = baseTime + i;
                values[i] = Math.random() * 100;
            }
            
            // 批量写入
            long startTime = System.currentTimeMillis();
            storage.writeRecords("BatchChannel", timestamps, values);
            long endTime = System.currentTimeMillis();
            
            System.out.println("批量写入 " + batchSize + " 条记录");
            System.out.println("耗时: " + (endTime - startTime) + " ms");
            System.out.println("平均速度: " + (batchSize * 1000.0 / (endTime - startTime)) + " 记录/秒");
        }
        
        System.out.println();
    }
    
    /**
     * 示例5: 追加模式
     */
    private static void appendModeUsage() throws IOException {
        System.out.println("=== 示例5: 追加模式 ===");
        
        Path filePath = Paths.get("/tmp/data/append_test.csv");
        
        // 第一次写入
        try (CSVStorage storage = new CSVStorage()) {
            storage.initialize(filePath, new StorageMetadata("追加测试"));
            
            storage.writeSyncRecord(System.currentTimeMillis(), 
                Map.of("Channel1", 100, "Channel2", 200));
            storage.writeSyncRecord(System.currentTimeMillis() + 100, 
                Map.of("Channel1", 110, "Channel2", 210));
            
            System.out.println("第一次写入完成，记录数: " + storage.getRecordCount());
        }
        
        // 追加写入
        try (CSVStorage storage = new CSVStorage()) {
            storage.openForAppend(AppendableStorage.AppendMode.STRICT);
            storage.initialize(filePath, new StorageMetadata("追加测试"));
            
            storage.writeSyncRecord(System.currentTimeMillis() + 200, 
                Map.of("Channel1", 120, "Channel2", 220));
            
            System.out.println("追加写入完成，记录数: " + storage.getRecordCount());
        }
        
        System.out.println();
    }
    
    /**
     * 示例6: 格式切换
     */
    private static void formatSwitchingUsage() throws IOException {
        System.out.println("=== 示例6: 格式切换 ===");
        
        // 相同的数据，不同的格式
        String baseName = "/tmp/data/format_switch/test";
        StorageFormat[] formats = {
            StorageFormat.MDF4,
            StorageFormat.CSV,
            StorageFormat.BINARY
        };
        
        for (StorageFormat format : formats) {
            Path filePath = Paths.get(baseName + "." + format.getExtension());
            
            try (DataStorage storage = StorageFactory.getInstance()
                    .createStorage(format, filePath)) {
                
                // 写入相同的数据
                long baseTime = System.currentTimeMillis();
                for (int i = 0; i < 1000; i++) {
                    storage.writeRecord("TestChannel", baseTime + i, (double) i);
                }
                
                storage.flush();
                
                System.out.println(format.getDisplayName() + " 格式:");
                System.out.println("  文件: " + filePath);
                System.out.println("  大小: " + storage.getSize() + " bytes");
            }
        }
        
        System.out.println();
    }
    
    /**
     * 示例7: 使用滚动策略
     */
    private static void rolloverStrategyUsage() throws IOException {
        System.out.println("=== 示例7: 滚动策略 ===");
        
        // 创建基于大小的滚动策略（100MB）
        ChunkStorage storage1 = (ChunkStorage) StorageFactory.getInstance()
            .createStorage(StorageConfiguration.builder()
                .name("大小滚动")
                .filePath(Paths.get("/tmp/data/rollover/size.mf4"))
                .format(StorageFormat.MDF4)
                .enableChunking(100 * 1024 * 1024, 0, 0)
                .build());
        
        // 创建基于时间的滚动策略（5分钟）
        ChunkStorage storage2 = (ChunkStorage) StorageFactory.getInstance()
            .createStorage(StorageConfiguration.builder()
                .name("时间滚动")
                .filePath(Paths.get("/tmp/data/rollover/time.mf4"))
                .format(StorageFormat.MDF4)
                .enableChunking(0, 0, 5 * 60 * 1000)
                .build());
        
        // 创建组合滚动策略
        ChunkStorage storage3 = (ChunkStorage) StorageFactory.getInstance()
            .createStorage(StorageConfiguration.builder()
                .name("组合滚动")
                .filePath(Paths.get("/tmp/data/rollover/composite.mf4"))
                .format(StorageFormat.MDF4)
                .enableChunking(100 * 1024 * 1024, 1_000_000, 5 * 60 * 1000)
                .build());
        
        System.out.println("滚动策略创建完成");
        System.out.println();
    }
    
    /**
     * 示例8: 读取数据
     */
    private static void readDataUsage() throws IOException {
        System.out.println("=== 示例8: 读取数据 ===");
        
        Path filePath = Paths.get("/tmp/data/read_test.mf4");
        
        // 先写入一些数据
        try (DataStorage storage = StorageFactory.getInstance()
                .createStorage(StorageFormat.MDF4, filePath)) {
            
            long baseTime = System.currentTimeMillis();
            for (int i = 0; i < 1000; i++) {
                storage.writeRecord("ReadChannel", baseTime + i * 10, (double) i);
            }
        }
        
        // 读取数据
        try (DataStorage storage = StorageFactory.getInstance()
                .createStorage(StorageFormat.MDF4, filePath)) {
            
            // 获取通道列表
            System.out.println("通道列表: " + storage.getChannelNames());
            
            // 读取全部数据
            Object[] allData = storage.readChannel("ReadChannel");
            System.out.println("全部数据条数: " + allData.length);
            
            // 读取时间范围数据
            long baseTime = System.currentTimeMillis();
            Object[] rangeData = storage.readChannelRange(
                "ReadChannel", 
                baseTime + 100, 
                baseTime + 500
            );
            System.out.println("范围数据条数: " + rangeData.length);
        }
        
        System.out.println();
    }
}
