package com.dataobserver.storage.chunk;

import com.dataobserver.storage.core.AbstractDataStorage;
import com.dataobserver.storage.metadata.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 分块存储抽象基类
 * 提供分块存储的通用实现
 */
public abstract class AbstractChunkStorage extends AbstractDataStorage implements ChunkStorage {
    
    // 默认配置
    public static final long DEFAULT_MAX_CHUNK_SIZE = 500 * 1024 * 1024; // 500MB
    public static final long DEFAULT_MAX_RECORDS_PER_CHUNK = 10_000_000; // 1000万
    public static final long DEFAULT_CHUNK_TIME_INTERVAL = 5 * 60 * 1000; // 5分钟
    
    // 分块配置
    protected long maxChunkSize = DEFAULT_MAX_CHUNK_SIZE;
    protected long maxRecordsPerChunk = DEFAULT_MAX_RECORDS_PER_CHUNK;
    protected long chunkTimeInterval = DEFAULT_CHUNK_TIME_INTERVAL;
    
    // 分块状态
    protected int currentChunkIndex = 0;
    protected long currentChunkSize = 0;
    protected long currentChunkRecords = 0;
    protected long currentChunkStartTime = 0;
    protected long totalRecords = 0;
    protected long totalSize = 0;
    
    // 分块文件列表
    protected final List<Path> chunkFiles = new ArrayList<>();
    protected final List<ChunkMetadata> chunkMetadataList = new ArrayList<>();
    
    // 滚动策略
    protected RolloverStrategy rolloverStrategy;
    
    public AbstractChunkStorage() {
        // 默认使用组合策略
        this.rolloverStrategy = RolloverStrategies.createDefaultStrategy(
            maxChunkSize, maxRecordsPerChunk, chunkTimeInterval
        );
    }
    
    // ==================== 分块配置实现 ====================
    
    @Override
    public void setMaxChunkSize(long maxChunkSize) {
        this.maxChunkSize = maxChunkSize;
        updateRolloverStrategy();
    }
    
    @Override
    public long getMaxChunkSize() {
        return maxChunkSize;
    }
    
    @Override
    public void setMaxRecordsPerChunk(long maxRecords) {
        this.maxRecordsPerChunk = maxRecords;
        updateRolloverStrategy();
    }
    
    @Override
    public long getMaxRecordsPerChunk() {
        return maxRecordsPerChunk;
    }
    
    @Override
    public void setChunkTimeInterval(long intervalMs) {
        this.chunkTimeInterval = intervalMs;
        updateRolloverStrategy();
    }
    
    @Override
    public long getChunkTimeInterval() {
        return chunkTimeInterval;
    }
    
    /**
     * 更新滚动策略
     */
    protected void updateRolloverStrategy() {
        this.rolloverStrategy = RolloverStrategies.createDefaultStrategy(
            maxChunkSize, maxRecordsPerChunk, chunkTimeInterval
        );
    }
    
    /**
     * 设置自定义滚动策略
     */
    public void setRolloverStrategy(RolloverStrategy strategy) {
        this.rolloverStrategy = strategy;
    }
    
    // ==================== 分块操作实现 ====================
    
    @Override
    public int getCurrentChunkIndex() {
        return currentChunkIndex;
    }
    
    @Override
    public int getTotalChunkCount() {
        return chunkFiles.size();
    }
    
    @Override
    public long getCurrentChunkSize() {
        return currentChunkSize;
    }
    
    @Override
    public long getCurrentChunkRecordCount() {
        return currentChunkRecords;
    }
    
    @Override
    public List<Path> getChunkFiles() {
        return new ArrayList<>(chunkFiles);
    }
    
    @Override
    public Path getChunkFile(int chunkIndex) {
        if (chunkIndex < 0 || chunkIndex >= chunkFiles.size()) {
            return null;
        }
        return chunkFiles.get(chunkIndex);
    }
    
    @Override
    public ChunkMetadata getChunkMetadata(int chunkIndex) {
        if (chunkIndex < 0 || chunkIndex >= chunkMetadataList.size()) {
            return null;
        }
        return chunkMetadataList.get(chunkIndex);
    }
    
    @Override
    public List<ChunkMetadata> getAllChunkMetadata() {
        return new ArrayList<>(chunkMetadataList);
    }
    
    @Override
    public boolean shouldRollover() {
        if (rolloverStrategy == null) {
            return false;
        }
        
        RolloverStrategy.RolloverContext context = new RolloverStrategy.RolloverContext(
            currentChunkIndex,
            currentChunkSize,
            currentChunkRecords,
            currentChunkStartTime,
            System.currentTimeMillis(),
            totalRecords,
            totalSize
        );
        
        return rolloverStrategy.shouldRollover(context);
    }
    
    @Override
    public int rollover() throws IOException {
        // 保存当前分块元数据
        saveCurrentChunkMetadata();
        
        // 关闭当前分块
        closeCurrentChunk();
        
        // 创建新分块
        currentChunkIndex++;
        currentChunkSize = 0;
        currentChunkRecords = 0;
        currentChunkStartTime = System.currentTimeMillis();
        
        Path newChunkPath = generateChunkPath(currentChunkIndex);
        chunkFiles.add(newChunkPath);
        
        createNewChunk(newChunkPath);
        
        return currentChunkIndex;
    }
    
    /**
     * 保存当前分块元数据
     */
    protected void saveCurrentChunkMetadata() {
        if (chunkFiles.isEmpty()) {
            return;
        }
        
        Path currentPath = chunkFiles.get(chunkFiles.size() - 1);
        ChunkMetadata metadata = new ChunkMetadata(
            currentChunkIndex,
            currentPath,
            currentChunkStartTime,
            System.currentTimeMillis(),
            currentChunkRecords,
            currentChunkSize,
            getFormat(),
            new StorageMetadata() // 可以复制当前元数据
        );
        
        chunkMetadataList.add(metadata);
    }
    
    /**
     * 生成新的分块路径
     */
    protected Path generateChunkPath(int chunkIndex) {
        String baseName = filePath.getFileName().toString();
        String extension = getFormat().getExtension();
        
        // 移除原有扩展名
        if (baseName.endsWith("." + extension)) {
            baseName = baseName.substring(0, baseName.length() - extension.length() - 1);
        }
        
        String chunkFileName = String.format("%s_chunk%04d.%s", baseName, chunkIndex, extension);
        return filePath.getParent().resolve(chunkFileName);
    }
    
    /**
     * 检查并执行滚动
     */
    protected void checkAndRollover() throws IOException {
        if (shouldRollover()) {
            rollover();
        }
    }
    
    /**
     * 更新分块统计信息
     */
    protected void updateChunkStats(long bytesWritten) {
        currentChunkSize += bytesWritten;
        currentChunkRecords++;
        totalRecords++;
        totalSize += bytesWritten;
    }
    
    // ==================== 抽象方法 - 子类实现 ====================
    
    /**
     * 关闭当前分块
     */
    protected abstract void closeCurrentChunk() throws IOException;
    
    /**
     * 创建新分块
     */
    protected abstract void createNewChunk(Path chunkPath) throws IOException;
    
    // ==================== DataStorage 方法覆盖 ====================
    
    @Override
    public long getRecordCount() {
        return totalRecords;
    }
    
    @Override
    public long getSize() throws IOException {
        return totalSize;
    }
}
