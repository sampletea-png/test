package com.dataobserver.storage.chunk;

import com.dataobserver.storage.core.DataStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.metadata.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * 分块存储接口
 * 支持大文件分块存储的接口
 */
public interface ChunkStorage extends DataStorage {
    
    // ==================== 分块配置 ====================
    
    /**
     * 设置分块大小限制
     * @param maxChunkSize 最大分块大小（字节）
     */
    void setMaxChunkSize(long maxChunkSize);
    
    /**
     * 获取最大分块大小
     */
    long getMaxChunkSize();
    
    /**
     * 设置最大记录数限制
     * @param maxRecords 最大记录数
     */
    void setMaxRecordsPerChunk(long maxRecords);
    
    /**
     * 获取最大记录数限制
     */
    long getMaxRecordsPerChunk();
    
    /**
     * 设置分块时间间隔（毫秒）
     * @param intervalMs 时间间隔
     */
    void setChunkTimeInterval(long intervalMs);
    
    /**
     * 获取分块时间间隔
     */
    long getChunkTimeInterval();
    
    // ==================== 分块操作 ====================
    
    /**
     * 获取当前分块索引
     */
    int getCurrentChunkIndex();
    
    /**
     * 获取总分块数
     */
    int getTotalChunkCount();
    
    /**
     * 获取当前分块大小
     */
    long getCurrentChunkSize();
    
    /**
     * 获取当前分块记录数
     */
    long getCurrentChunkRecordCount();
    
    /**
     * 强制创建新分块
     * @return 新分块索引
     * @throws IOException 创建失败时抛出
     */
    int rollover() throws IOException;
    
    /**
     * 检查是否需要分块滚动
     */
    boolean shouldRollover();
    
    /**
     * 获取所有分块文件路径
     */
    List<Path> getChunkFiles();
    
    /**
     * 获取指定分块文件路径
     * @param chunkIndex 分块索引
     */
    Path getChunkFile(int chunkIndex);
    
    /**
     * 合并所有分块
     * @param outputPath 输出文件路径
     * @throws IOException 合并失败时抛出
     */
    void mergeChunks(Path outputPath) throws IOException;
    
    // ==================== 分块元数据 ====================
    
    /**
     * 获取分块元数据
     * @param chunkIndex 分块索引
     */
    ChunkMetadata getChunkMetadata(int chunkIndex);
    
    /**
     * 获取所有分块元数据
     */
    List<ChunkMetadata> getAllChunkMetadata();
    
    /**
     * 分块元数据类
     */
    class ChunkMetadata {
        private final int index;
        private final Path filePath;
        private final long startTime;
        private final long endTime;
        private final long recordCount;
        private final long fileSize;
        private final StorageFormat format;
        private final StorageMetadata storageMetadata;
        
        public ChunkMetadata(int index, Path filePath, long startTime, long endTime,
                            long recordCount, long fileSize, StorageFormat format,
                            StorageMetadata storageMetadata) {
            this.index = index;
            this.filePath = filePath;
            this.startTime = startTime;
            this.endTime = endTime;
            this.recordCount = recordCount;
            this.fileSize = fileSize;
            this.format = format;
            this.storageMetadata = storageMetadata;
        }
        
        // Getters
        public int getIndex() { return index; }
        public Path getFilePath() { return filePath; }
        public long getStartTime() { return startTime; }
        public long getEndTime() { return endTime; }
        public long getRecordCount() { return recordCount; }
        public long getFileSize() { return fileSize; }
        public StorageFormat getFormat() { return format; }
        public StorageMetadata getStorageMetadata() { return storageMetadata; }
        
        public long getDuration() {
            return endTime - startTime;
        }
        
        @Override
        public String toString() {
            return String.format(
                "ChunkMetadata[index=%d, records=%d, size=%d, duration=%dms]",
                index, recordCount, fileSize, getDuration()
            );
        }
    }
}
