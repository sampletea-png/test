package com.dataobserver.storage.chunk;

/**
 * 分块滚动策略接口
 * 定义何时创建新分块的策略
 */
public interface RolloverStrategy {
    
    /**
     * 检查是否需要滚动到新分块
     * @param context 滚动上下文
     * @return true表示需要滚动
     */
    boolean shouldRollover(RolloverContext context);
    
    /**
     * 获取策略名称
     */
    String getName();
    
    /**
     * 获取策略描述
     */
    String getDescription();
    
    /**
     * 滚动上下文类
     * 包含当前分块的状态信息
     */
    class RolloverContext {
        private final int currentChunkIndex;
        private final long currentChunkSize;
        private final long currentChunkRecords;
        private final long currentChunkStartTime;
        private final long currentTimestamp;
        private final long totalRecords;
        private final long totalSize;
        
        public RolloverContext(int currentChunkIndex, long currentChunkSize,
                              long currentChunkRecords, long currentChunkStartTime,
                              long currentTimestamp, long totalRecords, long totalSize) {
            this.currentChunkIndex = currentChunkIndex;
            this.currentChunkSize = currentChunkSize;
            this.currentChunkRecords = currentChunkRecords;
            this.currentChunkStartTime = currentChunkStartTime;
            this.currentTimestamp = currentTimestamp;
            this.totalRecords = totalRecords;
            this.totalSize = totalSize;
        }
        
        // Getters
        public int getCurrentChunkIndex() { return currentChunkIndex; }
        public long getCurrentChunkSize() { return currentChunkSize; }
        public long getCurrentChunkRecords() { return currentChunkRecords; }
        public long getCurrentChunkStartTime() { return currentChunkStartTime; }
        public long getCurrentTimestamp() { return currentTimestamp; }
        public long getTotalRecords() { return totalRecords; }
        public long getTotalSize() { return totalSize; }
        
        /**
         * 获取当前分块持续时间
         */
        public long getCurrentChunkDuration() {
            return currentTimestamp - currentChunkStartTime;
        }
    }
}
