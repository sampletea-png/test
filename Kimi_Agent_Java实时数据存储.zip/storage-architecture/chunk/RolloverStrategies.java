package com.dataobserver.storage.chunk;

import java.util.ArrayList;
import java.util.List;

/**
 * 滚动策略实现集合
 * 提供常用的滚动策略实现
 */
public final class RolloverStrategies {
    
    private RolloverStrategies() {
        // 工具类，禁止实例化
    }
    
    /**
     * 基于文件大小的滚动策略
     */
    public static class SizeBasedRollover implements RolloverStrategy {
        
        private final long maxSize;
        
        public SizeBasedRollover(long maxSizeBytes) {
            if (maxSizeBytes <= 0) {
                throw new IllegalArgumentException("最大大小必须大于0");
            }
            this.maxSize = maxSizeBytes;
        }
        
        @Override
        public boolean shouldRollover(RolloverContext context) {
            return context.getCurrentChunkSize() >= maxSize;
        }
        
        @Override
        public String getName() {
            return "SizeBased";
        }
        
        @Override
        public String getDescription() {
            return String.format("当文件大小达到 %d 字节时滚动", maxSize);
        }
        
        public long getMaxSize() {
            return maxSize;
        }
    }
    
    /**
     * 基于记录数的滚动策略
     */
    public static class RecordCountRollover implements RolloverStrategy {
        
        private final long maxRecords;
        
        public RecordCountRollover(long maxRecords) {
            if (maxRecords <= 0) {
                throw new IllegalArgumentException("最大记录数必须大于0");
            }
            this.maxRecords = maxRecords;
        }
        
        @Override
        public boolean shouldRollover(RolloverContext context) {
            return context.getCurrentChunkRecords() >= maxRecords;
        }
        
        @Override
        public String getName() {
            return "RecordCount";
        }
        
        @Override
        public String getDescription() {
            return String.format("当记录数达到 %d 时滚动", maxRecords);
        }
        
        public long getMaxRecords() {
            return maxRecords;
        }
    }
    
    /**
     * 基于时间间隔的滚动策略
     */
    public static class TimeBasedRollover implements RolloverStrategy {
        
        private final long intervalMs;
        
        public TimeBasedRollover(long intervalMs) {
            if (intervalMs <= 0) {
                throw new IllegalArgumentException("时间间隔必须大于0");
            }
            this.intervalMs = intervalMs;
        }
        
        @Override
        public boolean shouldRollover(RolloverContext context) {
            long duration = context.getCurrentChunkDuration();
            return duration >= intervalMs;
        }
        
        @Override
        public String getName() {
            return "TimeBased";
        }
        
        @Override
        public String getDescription() {
            return String.format("当时间间隔达到 %d ms时滚动", intervalMs);
        }
        
        public long getIntervalMs() {
            return intervalMs;
        }
    }
    
    /**
     * 组合滚动策略
     * 任一条件满足时触发滚动
     */
    public static class CompositeRollover implements RolloverStrategy {
        
        private final List<RolloverStrategy> strategies;
        private final String name;
        
        public CompositeRollover(String name) {
            this.name = name;
            this.strategies = new ArrayList<>();
        }
        
        public CompositeRollover addStrategy(RolloverStrategy strategy) {
            strategies.add(strategy);
            return this;
        }
        
        @Override
        public boolean shouldRollover(RolloverContext context) {
            for (RolloverStrategy strategy : strategies) {
                if (strategy.shouldRollover(context)) {
                    return true;
                }
            }
            return false;
        }
        
        @Override
        public String getName() {
            return name;
        }
        
        @Override
        public String getDescription() {
            StringBuilder sb = new StringBuilder("组合策略: ");
            for (int i = 0; i < strategies.size(); i++) {
                if (i > 0) sb.append(" OR ");
                sb.append(strategies.get(i).getName());
            }
            return sb.toString();
        }
        
        public List<RolloverStrategy> getStrategies() {
            return new ArrayList<>(strategies);
        }
    }
    
    /**
     * 创建常用组合策略
     * 按大小或时间滚动
     */
    public static CompositeRollover createSizeOrTimeStrategy(
            long maxSizeBytes, long maxTimeMs) {
        return new CompositeRollover("SizeOrTime")
            .addStrategy(new SizeBasedRollover(maxSizeBytes))
            .addStrategy(new TimeBasedRollover(maxTimeMs));
    }
    
    /**
     * 创建常用组合策略
     * 按大小、记录数或时间滚动
     */
    public static CompositeRollover createDefaultStrategy(
            long maxSizeBytes, long maxRecords, long maxTimeMs) {
        return new CompositeRollover("Default")
            .addStrategy(new SizeBasedRollover(maxSizeBytes))
            .addStrategy(new RecordCountRollover(maxRecords))
            .addStrategy(new TimeBasedRollover(maxTimeMs));
    }
    
    // ==================== 便捷工厂方法 ====================
    
    /**
     * 100MB大小限制
     */
    public static SizeBasedRollover size100MB() {
        return new SizeBasedRollover(100 * 1024 * 1024);
    }
    
    /**
     * 500MB大小限制
     */
    public static SizeBasedRollover size500MB() {
        return new SizeBasedRollover(500 * 1024 * 1024);
    }
    
    /**
     * 1GB大小限制
     */
    public static SizeBasedRollover size1GB() {
        return new SizeBasedRollover(1024 * 1024 * 1024L);
    }
    
    /**
     * 1分钟时间限制
     */
    public static TimeBasedRollover time1Minute() {
        return new TimeBasedRollover(60 * 1000);
    }
    
    /**
     * 5分钟时间限制
     */
    public static TimeBasedRollover time5Minutes() {
        return new TimeBasedRollover(5 * 60 * 1000);
    }
    
    /**
     * 1小时时间限制
     */
    public static TimeBasedRollover time1Hour() {
        return new TimeBasedRollover(60 * 60 * 1000);
    }
    
    /**
     * 100万记录限制
     */
    public static RecordCountRollover records1M() {
        return new RecordCountRollover(1_000_000);
    }
    
    /**
     * 1000万记录限制
     */
    public static RecordCountRollover records10M() {
        return new RecordCountRollover(10_000_000);
    }
}
