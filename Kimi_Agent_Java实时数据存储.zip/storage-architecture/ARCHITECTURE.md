# 存储架构设计文档

## 架构概览

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              应用层 (Application)                            │
│                    StorageUsageExample, 用户代码...                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            工厂层 (Factory Layer)                            │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ StorageFactory  │  │StorageProvider  │  │ StorageConfig   │             │
│  │  (单例工厂)      │  │  (提供者接口)    │  │  (配置类)        │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            抽象层 (Abstraction Layer)                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │  DataStorage    │  │AbstractDataStore│  │AbstractChunkStore│            │
│  │  (核心接口)      │  │  (抽象基类)      │  │  (分块抽象基类)   │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │AppendableStorage│  │  BatchStorage   │  │RandomAccessStore│             │
│  │  (可追加接口)    │  │  (批量接口)      │  │  (随机访问接口)   │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            实现层 (Implementation Layer)                     │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐      │
│  │ MDF4Storage  │ │  CSVStorage  │ │ HDF5Storage  │ │ParquetStorage│      │
│  │  (MDF4格式)   │ │  (CSV格式)   │ │  (HDF5格式)  │ │ (Parquet格式) │      │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘      │
│  ┌──────────────┐ ┌──────────────┐                                          │
│  │BinaryStorage │ │ 其他格式...   │                                          │
│  │ (二进制格式)  │ │              │                                          │
│  └──────────────┘ └──────────────┘                                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            策略层 (Strategy Layer)                           │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │RolloverStrategy │  │ SizeBasedRollover│  │ TimeBasedRollover│           │
│  │  (滚动策略接口)  │  │  (大小策略)      │  │  (时间策略)      │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │RecordCountRollover│ │CompositeRollover│                                  │
│  │  (记录数策略)    │  │  (组合策略)      │                                 │
│  └─────────────────┘  └─────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            元数据层 (Metadata Layer)                         │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │ StorageMetadata │  │ ChannelMetadata │                                   │
│  │  (存储元数据)    │  │  (通道元数据)    │                                   │
│  └─────────────────┘  └─────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 核心类图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              DataStorage (Interface)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ + initialize(Path, StorageMetadata): void                                    │
│ + isInitialized(): boolean                                                  │
│ + getFormat(): StorageFormat                                                │
│ + getFilePath(): Path                                                       │
│ + writeRecord(String, long, Object): void                                   │
│ + writeRecords(String, long[], Object[]): void                              │
│ + writeSyncRecord(long, Map<String, Object>): void                          │
│ + writeSyncRecords(long[], Map<String, Object[]>): void                     │
│ + readChannel(String): Object[]                                             │
│ + readChannelRange(String, long, long): Object[]                            │
│ + getChannelNames(): List<String>                                           │
│ + addChannelMetadata(ChannelMetadata): void                                 │
│ + getChannelMetadata(String): ChannelMetadata                               │
│ + getAllChannelMetadata(): List<ChannelMetadata>                            │
│ + updateMetadata(StorageMetadata): void                                     │
│ + getMetadata(): StorageMetadata                                            │
│ + flush(): void                                                             │
│ + getSize(): long                                                           │
│ + getRecordCount(): long                                                    │
│ + close(): void                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      △
                                      │ implements
                                      │
┌─────────────────────────────────────────────────────────────────────────────┐
│                          AbstractDataStorage (Abstract)                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ # initialized: AtomicBoolean                                                │
│ # closed: AtomicBoolean                                                     │
│ # filePath: Path                                                            │
│ # storageMetadata: StorageMetadata                                          │
│ # channelMetadataMap: Map<String, ChannelMetadata>                          │
│ # recordCount: AtomicLong                                                   │
│ # writeBuffer: Map<String, List<DataPoint>>                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│ # doInitialize(): void [abstract]                                           │
│ # doWriteRecord(String, long, Object): void [abstract]                      │
│ # doWriteRecords(String, long[], Object[]): void [abstract]                 │
│ # doWriteSyncRecord(long, Map): void [abstract]                             │
│ # doWriteSyncRecords(long[], Map): void [abstract]                          │
│ # doFlush(): void [abstract]                                                │
│ # doClose(): void [abstract]                                                │
└─────────────────────────────────────────────────────────────────────────────┘
                                      △
                                      │ extends
                                      │
┌─────────────────────────────────────────────────────────────────────────────┐
│                          AbstractChunkStorage (Abstract)                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ # maxChunkSize: long                                                        │
│ # maxRecordsPerChunk: long                                                  │
│ # chunkTimeInterval: long                                                   │
│ # currentChunkIndex: int                                                    │
│ # currentChunkSize: long                                                    │
│ # currentChunkRecords: long                                                 │
│ # chunkFiles: List<Path>                                                    │
│ # rolloverStrategy: RolloverStrategy                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│ # closeCurrentChunk(): void [abstract]                                      │
│ # createNewChunk(Path): void [abstract]                                     │
│ + rollover(): int                                                           │
│ + shouldRollover(): boolean                                                 │
│ + getChunkFiles(): List<Path>                                               │
│ + mergeChunks(Path): void                                                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 工厂模式类图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          StorageFactory (Singleton)                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ - instance: StorageFactory                                                  │
│ - providers: Map<StorageFormat, StorageProvider>                            │
│ - storageCache: Map<String, DataStorage>                                    │
│ - defaultFormat: StorageFormat                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ + getInstance(): StorageFactory                                             │
│ + registerProvider(StorageFormat, StorageProvider): void                    │
│ + unregisterProvider(StorageFormat): void                                   │
│ + isFormatSupported(StorageFormat): boolean                                 │
│ + createStorage(StorageFormat, Path, StorageMetadata): DataStorage          │
│ + createStorage(StorageConfiguration): DataStorage                          │
│ + setDefaultFormat(StorageFormat): void                                     │
│ + getDefaultFormat(): StorageFormat                                         │
│ + setCachingEnabled(boolean): void                                          │
│ + closeAllStorages(): void                                                  │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │ uses
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          StorageProvider (Interface)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ + createStorage(): DataStorage                                              │
│ + getName(): String                                                         │
│ + getDescription(): String                                                  │
│ + getSupportedExtensions(): String[]                                        │
│ + supportsCapability(String): boolean                                       │
│ + getVersion(): String                                                      │
└─────────────────────────────────────────────────────────────────────────────┘
                                      △
                                      │ implements
                    ┌─────────────────┼─────────────────┐
                    │                 │                 │
                    ▼                 ▼                 ▼
┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────────────┐
│ MDF4Storage.Provider  │ │ CSVStorage.Provider   │ │ HDF5Storage.Provider  │
└───────────────────────┘ └───────────────────────┘ └───────────────────────┘
```

## 策略模式类图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          RolloverStrategy (Interface)                        │
├─────────────────────────────────────────────────────────────────────────────┤
│ + shouldRollover(RolloverContext): boolean                                  │
│ + getName(): String                                                         │
│ + getDescription(): String                                                  │
└─────────────────────────────────────────────────────────────────────────────┘
                                      △
                                      │ implements
        ┌─────────────────────────────┼─────────────────────────────┐
        │                             │                             │
        ▼                             ▼                             ▼
┌───────────────────┐   ┌───────────────────┐   ┌───────────────────┐
│ SizeBasedRollover │   │ TimeBasedRollover │   │RecordCountRollover│
├───────────────────┤   ├───────────────────┤   ├───────────────────┤
│ - maxSize: long   │   │ - intervalMs: long│   │ - maxRecords: long│
├───────────────────┤   ├───────────────────┤   ├───────────────────┤
│ + shouldRollover()│   │ + shouldRollover()│   │ + shouldRollover()│
└───────────────────┘   └───────────────────┘   └───────────────────┘
        △
        │ uses
        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CompositeRollover                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ - strategies: List<RolloverStrategy>                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│ + addStrategy(RolloverStrategy): CompositeRollover                          │
│ + shouldRollover(RolloverContext): boolean                                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 元数据类图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          StorageMetadata                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ - id: String                                                                │
│ - name: String                                                              │
│ - description: String                                                       │
│ - version: String                                                           │
│ - createdAt: Instant                                                        │
│ - modifiedAt: Instant                                                       │
│ - startTime: Instant                                                        │
│ - endTime: Instant                                                          │
│ - recordCount: long                                                         │
│ - fileSize: long                                                            │
│ - channelCount: int                                                         │
│ - properties: Map<String, Object>                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ + setProperty(String, Object): void                                         │
│ + getProperty(String): Object                                               │
│ + getDurationMs(): long                                                     │
│ + getEstimatedSampleRate(): double                                          │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                          ChannelMetadata                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ - name: String                                                              │
│ - displayName: String                                                       │
│ - description: String                                                       │
│ - unit: String                                                              │
│ - dataType: DataType                                                        │
│ - minimum: double                                                           │
│ - maximum: double                                                           │
│ - sampleRate: double                                                        │
│ - recordCount: long                                                         │
│ - conversionType: ConversionType                                            │
│ - properties: Map<String, Object>                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ + applyConversion(double): double                                           │
│ + isInRange(double): boolean                                                │
│ + getFullDisplayName(): String                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 调用流程

### 创建存储流程

```
用户代码
    │
    │ 1. 调用 StorageFactory.createStorage(config)
    ▼
StorageFactory
    │
    │ 2. 根据 format 查找 StorageProvider
    ▼
StorageProvider
    │
    │ 3. 调用 createStorage() 创建实例
    ▼
DataStorage (具体实现类)
    │
    │ 4. 调用 initialize(path, metadata)
    ▼
初始化完成
```

### 写入数据流程

```
用户代码
    │
    │ 1. 调用 writeRecord(channel, timestamp, value)
    ▼
AbstractDataStorage
    │
    │ 2. 检查状态、缓冲处理
    ▼
AbstractDataStorage
    │
    │ 3. 调用 doWriteRecord() [模板方法]
    ▼
具体存储实现 (如 MDF4Storage)
    │
    │ 4. 执行实际写入操作
    ▼
写入完成
```

### 分块滚动流程

```
用户代码
    │
    │ 1. 调用 writeRecord()
    ▼
AbstractChunkStorage
    │
    │ 2. 调用 checkAndRollover()
    ▼
RolloverStrategy
    │
    │ 3. 调用 shouldRollover(context)
    ▼
AbstractChunkStorage
    │
    │ 4. 如果需要，调用 rollover()
    ▼
AbstractChunkStorage
    │
    │ 5. 调用 closeCurrentChunk() [模板方法]
    │ 6. 调用 createNewChunk() [模板方法]
    ▼
具体存储实现
    │
    │ 7. 执行关闭和创建操作
    ▼
滚动完成
```

## 扩展点

### 1. 添加新存储格式

```
实现 DataStorage 接口
        │
        ▼
实现 StorageProvider 接口
        │
        ▼
注册到 StorageFactory
        │
        ▼
    使用新格式
```

### 2. 添加新滚动策略

```
实现 RolloverStrategy 接口
        │
        ▼
设置到 ChunkStorage
        │
        ▼
    使用新策略
```

### 3. 扩展元数据

```
继承 StorageMetadata 或 ChannelMetadata
        │
        ▼
    添加自定义属性
        │
        ▼
    使用扩展元数据
```

## 设计原则

### 1. 开闭原则 (Open/Closed Principle)

- 对扩展开放：通过接口和抽象类支持新格式
- 对修改关闭：核心代码不需要修改即可支持新格式

### 2. 单一职责原则 (Single Responsibility Principle)

- `DataStorage`: 负责数据读写
- `StorageFactory`: 负责创建存储实例
- `RolloverStrategy`: 负责分块策略
- `StorageMetadata`: 负责元数据管理

### 3. 依赖倒置原则 (Dependency Inversion Principle)

- 高层模块依赖抽象接口
- 具体实现依赖抽象接口
- 工厂模式解耦创建和使用

### 4. 接口隔离原则 (Interface Segregation Principle)

- `AppendableStorage`: 仅追加相关操作
- `BatchStorage`: 仅批量操作
- `RandomAccessStorage`: 仅随机访问
- `ChunkStorage`: 仅分块操作

### 5. 里氏替换原则 (Liskov Substitution Principle)

- 所有存储实现可以互换使用
- 滚动策略可以互换使用
- 不影响调用方代码

## 性能考虑

### 写入性能优化

1. **批量写入**: 减少I/O次数
2. **缓冲机制**: 累积一定量后统一写入
3. **异步写入**: 后台线程写入
4. **内存映射**: 大文件使用MappedByteBuffer

### 读取性能优化

1. **索引机制**: 快速定位数据
2. **缓存机制**: 缓存热点数据
3. **延迟加载**: 按需加载数据
4. **预读取**: 预测性读取

### 内存优化

1. **分块存储**: 避免大文件占用过多内存
2. **对象池**: 重用对象减少GC
3. **流式处理**: 不一次性加载全部数据
4. **压缩存储**: 减少内存和磁盘占用

## 线程安全

### 线程安全组件

| 组件 | 线程安全 | 机制 |
|------|----------|------|
| StorageFactory | 是 | 单例 + ConcurrentHashMap |
| AbstractDataStorage | 部分 | 原子变量 + 同步 |
| 具体存储实现 | 视实现而定 | 需要子类保证 |

### 建议

1. 单线程写入：最简单高效
2. 多线程写入：需要外部同步或使用线程安全实现
3. 读写分离：读操作可以并发，写操作需要同步

## 错误处理

### 异常类型

| 异常 | 说明 | 处理建议 |
|------|------|----------|
| IOException | I/O操作失败 | 重试或记录日志 |
| IllegalStateException | 状态错误 | 检查调用顺序 |
| IllegalArgumentException | 参数错误 | 检查参数有效性 |
| UnsupportedOperationException | 不支持的操作 | 检查格式能力 |

### 最佳实践

1. 使用 try-with-resources 确保关闭
2. 在 finally 中清理资源
3. 记录详细的错误信息
4. 提供恢复机制
