package com.dataobserver.storage.format;

import com.dataobserver.storage.chunk.AbstractChunkStorage;
import com.dataobserver.storage.core.AppendableStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.factory.StorageProvider;
import com.dataobserver.storage.metadata.ChannelMetadata;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * CSV格式存储实现
 * 
 * 特性：
 * - 简单易读的文本格式
 * - 支持追加写入
 * - 支持分块存储
 * - 可配置分隔符和格式
 */
public class CSVStorage extends AbstractChunkStorage implements AppendableStorage {
    
    // 配置
    private char delimiter = ',';
    private boolean includeHeader = true;
    private boolean includeTimestamp = true;
    private String timestampFormat = "yyyy-MM-dd HH:mm:ss.SSS";
    private String encoding = "UTF-8";
    
    // 写入器
    private BufferedWriter writer;
    private boolean headerWritten = false;
    private boolean appendMode = false;
    
    // 通道顺序
    private final List<String> channelOrder = new ArrayList<>();
    
    // 时间格式化
    private SimpleDateFormat dateFormat;
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.CSV;
    }
    
    // ==================== 初始化 ====================
    
    @Override
    protected void doInitialize() throws IOException {
        dateFormat = new SimpleDateFormat(timestampFormat);
        
        boolean fileExists = filePath.toFile().exists();
        
        if (appendMode && fileExists) {
            // 追加模式，读取已有通道
            readExistingChannels();
            writer = new BufferedWriter(
                new OutputStreamWriter(
                    new FileOutputStream(filePath.toFile(), true),
                    encoding
                )
            );
            headerWritten = true;
        } else {
            // 新建文件
            writer = new BufferedWriter(
                new OutputStreamWriter(
                    new FileOutputStream(filePath.toFile(), false),
                    encoding
                )
            );
        }
        
        chunkFiles.add(filePath);
        currentChunkStartTime = System.currentTimeMillis();
    }
    
    /**
     * 读取已有文件的通道信息
     */
    private void readExistingChannels() throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath.toFile()), encoding))) {
            
            String headerLine = reader.readLine();
            if (headerLine != null && includeHeader) {
                String[] headers = parseLine(headerLine);
                int startIndex = includeTimestamp ? 1 : 0;
                for (int i = startIndex; i < headers.length; i++) {
                    String channelName = headers[i].trim();
                    channelOrder.add(channelName);
                    
                    // 创建通道元数据
                    ChannelMetadata metadata = new ChannelMetadata(channelName);
                    metadata.setDataType(ChannelMetadata.DataType.STRING);
                    addChannelMetadata(metadata);
                }
            }
        }
    }
    
    // ==================== 写入实现 ====================
    
    @Override
    protected void doWriteRecord(String channelName, long timestamp, Object value) throws IOException {
        ensureHeader();
        
        // CSV通常按行写入，单通道写入需要特殊处理
        StringBuilder line = new StringBuilder();
        
        if (includeTimestamp) {
            line.append(formatTimestamp(timestamp)).append(delimiter);
        }
        
        // 写入通道值
        for (String ch : channelOrder) {
            if (ch.equals(channelName)) {
                line.append(formatValue(value));
            }
            line.append(delimiter);
        }
        
        // 移除最后一个分隔符
        if (line.length() > 0 && line.charAt(line.length() - 1) == delimiter) {
            line.setLength(line.length() - 1);
        }
        
        writer.write(line.toString());
        writer.newLine();
        
        updateChunkStats(line.length());
    }
    
    @Override
    protected void doWriteRecords(String channelName, long[] timestamps, Object[] values) throws IOException {
        for (int i = 0; i < timestamps.length; i++) {
            doWriteRecord(channelName, timestamps[i], values[i]);
        }
    }
    
    @Override
    protected void doWriteSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException {
        ensureHeader();
        
        // 添加新通道
        for (String ch : channelValues.keySet()) {
            if (!channelOrder.contains(ch)) {
                channelOrder.add(ch);
                ChannelMetadata metadata = new ChannelMetadata(ch);
                metadata.setDataType(inferDataType(channelValues.get(ch)));
                addChannelMetadata(metadata);
            }
        }
        
        // 重新写入头（如果需要）
        if (!headerWritten && includeHeader) {
            writeHeader();
        }
        
        // 写入数据行
        StringBuilder line = new StringBuilder();
        
        if (includeTimestamp) {
            line.append(formatTimestamp(timestamp)).append(delimiter);
        }
        
        for (String ch : channelOrder) {
            Object value = channelValues.get(ch);
            line.append(formatValue(value)).append(delimiter);
        }
        
        // 移除最后一个分隔符
        if (line.length() > 0 && line.charAt(line.length() - 1) == delimiter) {
            line.setLength(line.length() - 1);
        }
        
        writer.write(line.toString());
        writer.newLine();
        
        updateChunkStats(line.length());
    }
    
    @Override
    protected void doWriteSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException {
        for (int i = 0; i < timestamps.length; i++) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (Map.Entry<String, Object[]> entry : channelData.entrySet()) {
                row.put(entry.getKey(), entry.getValue()[i]);
            }
            doWriteSyncRecord(timestamps[i], row);
        }
    }
    
    // ==================== 读取实现 ====================
    
    @Override
    public Object[] readChannel(String channelName) throws IOException {
        List<Object> values = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath.toFile()), encoding))) {
            
            String line;
            int lineNum = 0;
            int channelIndex = -1;
            
            while ((line = reader.readLine()) != null) {
                lineNum++;
                
                if (lineNum == 1 && includeHeader) {
                    // 解析头，找到通道索引
                    String[] headers = parseLine(line);
                    int startIndex = includeTimestamp ? 1 : 0;
                    for (int i = startIndex; i < headers.length; i++) {
                        if (headers[i].trim().equals(channelName)) {
                            channelIndex = i;
                            break;
                        }
                    }
                    if (channelIndex == -1) {
                        return new Object[0]; // 通道不存在
                    }
                    continue;
                }
                
                String[] fields = parseLine(line);
                if (channelIndex >= 0 && channelIndex < fields.length) {
                    values.add(parseValue(fields[channelIndex]));
                }
            }
        }
        
        return values.toArray();
    }
    
    @Override
    public Object[] readChannelRange(String channelName, long startTime, long endTime) throws IOException {
        // CSV格式按行读取后过滤
        List<Object> values = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath.toFile()), encoding))) {
            
            String line;
            int lineNum = 0;
            int channelIndex = -1;
            int timestampIndex = includeTimestamp ? 0 : -1;
            
            while ((line = reader.readLine()) != null) {
                lineNum++;
                
                if (lineNum == 1 && includeHeader) {
                    String[] headers = parseLine(line);
                    int startIndex = includeTimestamp ? 1 : 0;
                    for (int i = startIndex; i < headers.length; i++) {
                        if (headers[i].trim().equals(channelName)) {
                            channelIndex = i;
                            break;
                        }
                    }
                    continue;
                }
                
                String[] fields = parseLine(line);
                
                // 时间过滤
                if (timestampIndex >= 0 && timestampIndex < fields.length) {
                    long timestamp = parseTimestamp(fields[timestampIndex]);
                    if (timestamp < startTime || timestamp > endTime) {
                        continue;
                    }
                }
                
                if (channelIndex >= 0 && channelIndex < fields.length) {
                    values.add(parseValue(fields[channelIndex]));
                }
            }
        }
        
        return values.toArray();
    }
    
    @Override
    public List<String> getChannelNames() throws IOException {
        return new ArrayList<>(channelOrder);
    }
    
    // ==================== 追加模式 ====================
    
    @Override
    public void openForAppend(AppendMode mode) throws IOException {
        this.appendMode = true;
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public long getEndPosition() throws IOException {
        return filePath.toFile().length();
    }
    
    // ==================== 分块实现 ====================
    
    @Override
    protected void closeCurrentChunk() throws IOException {
        flush();
        if (writer != null) {
            writer.close();
            writer = null;
        }
    }
    
    @Override
    protected void createNewChunk(Path chunkPath) throws IOException {
        this.filePath = chunkPath;
        headerWritten = false;
        channelOrder.clear();
        
        writer = new BufferedWriter(
            new OutputStreamWriter(
                new FileOutputStream(filePath.toFile(), false),
                encoding
            )
        );
    }
    
    @Override
    public void mergeChunks(Path outputPath) throws IOException {
        try (BufferedWriter mergedWriter = new BufferedWriter(
                new OutputStreamWriter(
                    new FileOutputStream(outputPath.toFile()),
                    encoding
                ))) {
            
            boolean headerMerged = false;
            
            for (Path chunkFile : chunkFiles) {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(new FileInputStream(chunkFile.toFile()), encoding))) {
                    
                    String line;
                    int lineNum = 0;
                    
                    while ((line = reader.readLine()) != null) {
                        lineNum++;
                        
                        if (lineNum == 1 && includeHeader) {
                            if (!headerMerged) {
                                mergedWriter.write(line);
                                mergedWriter.newLine();
                                headerMerged = true;
                            }
                            continue;
                        }
                        
                        mergedWriter.write(line);
                        mergedWriter.newLine();
                    }
                }
            }
        }
    }
    
    // ==================== 辅助方法 ====================
    
    private void ensureHeader() throws IOException {
        if (!headerWritten && includeHeader) {
            writeHeader();
        }
    }
    
    private void writeHeader() throws IOException {
        StringBuilder header = new StringBuilder();
        
        if (includeTimestamp) {
            header.append("Timestamp").append(delimiter);
        }
        
        for (String ch : channelOrder) {
            header.append(escapeField(ch)).append(delimiter);
        }
        
        // 移除最后一个分隔符
        if (header.length() > 0 && header.charAt(header.length() - 1) == delimiter) {
            header.setLength(header.length() - 1);
        }
        
        writer.write(header.toString());
        writer.newLine();
        headerWritten = true;
    }
    
    private String formatTimestamp(long timestamp) {
        return dateFormat.format(new Date(timestamp));
    }
    
    private long parseTimestamp(String timestampStr) {
        try {
            Date date = dateFormat.parse(timestampStr);
            return date.getTime();
        } catch (Exception e) {
            try {
                return Long.parseLong(timestampStr);
            } catch (NumberFormatException ex) {
                return 0;
            }
        }
    }
    
    private String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        return escapeField(value.toString());
    }
    
    private Object parseValue(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        
        // 尝试解析为数字
        try {
            if (value.contains(".")) {
                return Double.parseDouble(value);
            } else {
                return Long.parseLong(value);
            }
        } catch (NumberFormatException e) {
            return value;
        }
    }
    
    private String escapeField(String field) {
        if (field == null) {
            return "";
        }
        
        // 如果字段包含分隔符、引号或换行，需要转义
        if (field.indexOf(delimiter) >= 0 || 
            field.indexOf('"') >= 0 || 
            field.indexOf('\n') >= 0 ||
            field.indexOf('\r') >= 0) {
            
            // 将双引号替换为两个双引号
            field = field.replace("\"", "\"\"");
            return "\"" + field + "\"";
        }
        
        return field;
    }
    
    private String[] parseLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    // 转义的引号
                    currentField.append('"');
                    i++; // 跳过下一个引号
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == delimiter && !inQuotes) {
                fields.add(currentField.toString().trim());
                currentField.setLength(0);
            } else {
                currentField.append(c);
            }
        }
        
        fields.add(currentField.toString().trim());
        
        return fields.toArray(new String[0]);
    }
    
    private ChannelMetadata.DataType inferDataType(Object value) {
        if (value instanceof Integer) return ChannelMetadata.DataType.INT32;
        if (value instanceof Long) return ChannelMetadata.DataType.INT64;
        if (value instanceof Float) return ChannelMetadata.DataType.FLOAT;
        if (value instanceof Double) return ChannelMetadata.DataType.DOUBLE;
        if (value instanceof Boolean) return ChannelMetadata.DataType.BOOLEAN;
        return ChannelMetadata.DataType.STRING;
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (writer != null) {
            writer.close();
            writer = null;
        }
    }
    
    // ==================== 配置方法 ====================
    
    public void setDelimiter(char delimiter) {
        this.delimiter = delimiter;
    }
    
    public void setIncludeHeader(boolean includeHeader) {
        this.includeHeader = includeHeader;
    }
    
    public void setIncludeTimestamp(boolean includeTimestamp) {
        this.includeTimestamp = includeTimestamp;
    }
    
    public void setTimestampFormat(String timestampFormat) {
        this.timestampFormat = timestampFormat;
        this.dateFormat = new SimpleDateFormat(timestampFormat);
    }
    
    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }
    
    // ==================== 提供者类 ====================
    
    public static class Provider implements StorageProvider {
        
        @Override
        public DataStorage createStorage() {
            return new CSVStorage();
        }
        
        @Override
        public String getName() {
            return "CSV";
        }
        
        @Override
        public String getDescription() {
            return "Comma Separated Values - 通用文本格式";
        }
        
        @Override
        public String[] getSupportedExtensions() {
            return new String[]{"csv", "txt"};
        }
        
        @Override
        public boolean supportsCapability(String capability) {
            switch (capability) {
                case CAPABILITY_READ:
                case CAPABILITY_WRITE:
                case CAPABILITY_APPEND:
                case CAPABILITY_CHUNKING:
                    return true;
                default:
                    return false;
            }
        }
        
        @Override
        public String getVersion() {
            return "1.0";
        }
    }
}
