package com.dataobserver.storage.format;

import com.dataobserver.storage.chunk.AbstractChunkStorage;
import com.dataobserver.storage.core.RandomAccessStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.factory.StorageProvider;
import com.dataobserver.storage.metadata.ChannelMetadata;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.util.*;

/**
 * 自定义二进制格式存储实现
 * 
 * 特性：
 * - 高性能二进制存储
 * - 紧凑的数据布局
 * - 支持随机访问
 * - 支持分块存储
 * 
 * 文件格式：
 * [Header][Channel Definitions][Data Blocks][Index][Footer]
 */
public class BinaryStorage extends AbstractChunkStorage implements RandomAccessStorage {
    
    // 文件标识
    private static final byte[] MAGIC = {'B', 'I', 'N', 'D'};
    private static final short VERSION = 1;
    
    // 文件句柄
    private RandomAccessFile raf;
    private FileChannel channel;
    
    // 字节序
    private ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
    
    // 通道定义
    private final Map<String, BinaryChannel> channels = new LinkedHashMap<>();
    
    // 数据位置
    private long dataStartPosition;
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.BINARY;
    }
    
    // ==================== 初始化 ====================
    
    @Override
    protected void doInitialize() throws IOException {
        raf = new RandomAccessFile(filePath.toFile(), "rw");
        channel = raf.getChannel();
        
        if (raf.length() == 0) {
            // 新文件，写入头
            writeHeader();
            dataStartPosition = 64; // 头大小
        } else {
            // 读取已有文件
            readHeader();
            readChannelDefinitions();
        }
        
        chunkFiles.add(filePath);
        currentChunkStartTime = System.currentTimeMillis();
    }
    
    private void writeHeader() throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(64);
        buffer.order(byteOrder);
        
        // 魔数
        buffer.put(MAGIC);
        
        // 版本
        buffer.putShort(VERSION);
        
        // 字节序
        buffer.put(byteOrder == ByteOrder.LITTLE_ENDIAN ? (byte) 0 : (byte) 1);
        
        // 创建时间
        buffer.putLong(System.currentTimeMillis());
        
        // 通道数量（占位，后续更新）
        buffer.putInt(0);
        
        // 数据起始位置（占位，后续更新）
        buffer.putLong(0);
        
        // 索引位置（占位，后续更新）
        buffer.putLong(0);
        
        // 填充
        while (buffer.hasRemaining()) {
            buffer.put((byte) 0);
        }
        
        buffer.flip();
        channel.write(buffer, 0);
    }
    
    private void readHeader() throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(64);
        buffer.order(byteOrder);
        
        channel.read(buffer, 0);
        buffer.flip();
        
        // 验证魔数
        byte[] magic = new byte[4];
        buffer.get(magic);
        if (!Arrays.equals(magic, MAGIC)) {
            throw new IOException("无效的二进制文件格式");
        }
        
        // 版本
        short version = buffer.getShort();
        if (version != VERSION) {
            throw new IOException("不支持的文件版本: " + version);
        }
        
        // 字节序
        byte order = buffer.get();
        byteOrder = (order == 0) ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN;
        
        // 跳过其他字段
    }
    
    private void readChannelDefinitions() throws IOException {
        // 读取通道定义
        // 实际实现需要解析文件中的通道定义区域
    }
    
    // ==================== 写入实现 ====================
    
    @Override
    protected void doWriteRecord(String channelName, long timestamp, Object value) throws IOException {
        BinaryChannel ch = getOrCreateChannel(channelName, value);
        
        ByteBuffer buffer = ByteBuffer.allocate(ch.getRecordSize());
        buffer.order(byteOrder);
        
        // 写入时间戳
        buffer.putLong(timestamp);
        
        // 写入值
        writeValue(buffer, ch.getDataType(), value);
        
        buffer.flip();
        
        long position = ch.getNextWritePosition();
        channel.write(buffer, position);
        ch.updateWritePosition(position + buffer.limit());
        ch.incrementRecordCount();
        
        updateChunkStats(buffer.limit());
    }
    
    @Override
    protected void doWriteRecords(String channelName, long[] timestamps, Object[] values) throws IOException {
        BinaryChannel ch = getOrCreateChannel(channelName, values[0]);
        
        int recordSize = ch.getRecordSize();
        ByteBuffer buffer = ByteBuffer.allocate(timestamps.length * recordSize);
        buffer.order(byteOrder);
        
        for (int i = 0; i < timestamps.length; i++) {
            buffer.putLong(timestamps[i]);
            writeValue(buffer, ch.getDataType(), values[i]);
        }
        
        buffer.flip();
        
        long position = ch.getNextWritePosition();
        channel.write(buffer, position);
        ch.updateWritePosition(position + buffer.limit());
        ch.addRecordCount(timestamps.length);
        
        updateChunkStats(buffer.limit());
    }
    
    @Override
    protected void doWriteSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException {
        // 同步记录使用统一的记录格式
        for (Map.Entry<String, Object> entry : channelValues.entrySet()) {
            doWriteRecord(entry.getKey(), timestamp, entry.getValue());
        }
    }
    
    @Override
    protected void doWriteSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException {
        for (int i = 0; i < timestamps.length; i++) {
            for (Map.Entry<String, Object[]> entry : channelData.entrySet()) {
                doWriteRecord(entry.getKey(), timestamps[i], entry.getValue()[i]);
            }
        }
    }
    
    // ==================== 读取实现 ====================
    
    @Override
    public Object[] readChannel(String channelName) throws IOException {
        BinaryChannel ch = channels.get(channelName);
        if (ch == null) {
            return new Object[0];
        }
        
        long recordCount = ch.getRecordCount();
        Object[] values = new Object[(int) recordCount];
        
        int recordSize = ch.getRecordSize();
        ByteBuffer buffer = ByteBuffer.allocate((int) (recordCount * recordSize));
        buffer.order(byteOrder);
        
        channel.read(buffer, ch.getDataOffset());
        buffer.flip();
        
        for (int i = 0; i < recordCount; i++) {
            buffer.getLong(); // 跳过时间戳
            values[i] = readValue(buffer, ch.getDataType());
        }
        
        return values;
    }
    
    @Override
    public Object[] readChannelRange(String channelName, long startTime, long endTime) throws IOException {
        BinaryChannel ch = channels.get(channelName);
        if (ch == null) {
            return new Object[0];
        }
        
        // 二分查找定位起始位置
        // 简化实现：顺序扫描
        List<Object> values = new ArrayList<>();
        
        long recordCount = ch.getRecordCount();
        int recordSize = ch.getRecordSize();
        
        ByteBuffer buffer = ByteBuffer.allocate(recordSize);
        buffer.order(byteOrder);
        
        for (long i = 0; i < recordCount; i++) {
            long position = ch.getDataOffset() + i * recordSize;
            buffer.clear();
            channel.read(buffer, position);
            buffer.flip();
            
            long timestamp = buffer.getLong();
            if (timestamp >= startTime && timestamp <= endTime) {
                values.add(readValue(buffer, ch.getDataType()));
            }
            if (timestamp > endTime) {
                break;
            }
        }
        
        return values.toArray();
    }
    
    @Override
    public List<String> getChannelNames() throws IOException {
        return new ArrayList<>(channels.keySet());
    }
    
    // ==================== 随机访问实现 ====================
    
    @Override
    public void seek(long position) throws IOException {
        raf.seek(position);
    }
    
    @Override
    public long getPosition() throws IOException {
        return raf.getFilePointer();
    }
    
    @Override
    public byte[] readAt(long position, int length) throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(length);
        channel.read(buffer, position);
        return buffer.array();
    }
    
    @Override
    public void writeAt(long position, byte[] data) throws IOException {
        channel.write(ByteBuffer.wrap(data), position);
    }
    
    @Override
    public long getTotalSize() throws IOException {
        return channel.size();
    }
    
    @Override
    public boolean supportsRandomWrite() {
        return true;
    }
    
    // ==================== 分块实现 ====================
    
    @Override
    protected void closeCurrentChunk() throws IOException {
        flush();
        writeChannelDefinitions();
        writeFooter();
    }
    
    @Override
    protected void createNewChunk(Path chunkPath) throws IOException {
        this.filePath = chunkPath;
        channels.clear();
        
        raf = new RandomAccessFile(filePath.toFile(), "rw");
        channel = raf.getChannel();
        
        writeHeader();
        dataStartPosition = 64;
    }
    
    @Override
    public void mergeChunks(Path outputPath) throws IOException {
        // 合并所有分块到一个文件
        try (RandomAccessFile mergedRaf = new RandomAccessFile(outputPath.toFile(), "rw");
             FileChannel mergedChannel = mergedRaf.getChannel()) {
            
            // 写入合并后的头
            // ...
            
            // 复制所有分块的数据
            for (Path chunkFile : chunkFiles) {
                try (RandomAccessFile chunkRaf = new RandomAccessFile(chunkFile.toFile(), "r");
                     FileChannel chunkChannel = chunkRaf.getChannel()) {
                    
                    chunkChannel.transferTo(0, chunkChannel.size(), mergedChannel);
                }
            }
        }
    }
    
    // ==================== 辅助方法 ====================
    
    private BinaryChannel getOrCreateChannel(String name, Object sampleValue) {
        return channels.computeIfAbsent(name, n -> {
            BinaryChannel ch = new BinaryChannel(n);
            ch.setDataType(inferDataType(sampleValue));
            ch.setDataOffset(dataStartPosition);
            dataStartPosition += 1024 * 1024; // 预留1MB空间
            return ch;
        });
    }
    
    private ChannelMetadata.DataType inferDataType(Object value) {
        if (value instanceof Integer) return ChannelMetadata.DataType.INT32;
        if (value instanceof Long) return ChannelMetadata.DataType.INT64;
        if (value instanceof Float) return ChannelMetadata.DataType.FLOAT;
        if (value instanceof Double) return ChannelMetadata.DataType.DOUBLE;
        if (value instanceof Boolean) return ChannelMetadata.DataType.BOOLEAN;
        return ChannelMetadata.DataType.DOUBLE;
    }
    
    private void writeValue(ByteBuffer buffer, ChannelMetadata.DataType type, Object value) {
        switch (type) {
            case INT8:
                buffer.put(((Number) value).byteValue());
                break;
            case UINT8:
                buffer.put(((Number) value).byteValue());
                break;
            case INT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case UINT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case INT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case UINT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case INT64:
            case UINT64:
                buffer.putLong(((Number) value).longValue());
                break;
            case FLOAT:
                buffer.putFloat(((Number) value).floatValue());
                break;
            case DOUBLE:
                buffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                buffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            default:
                buffer.putDouble(((Number) value).doubleValue());
        }
    }
    
    private Object readValue(ByteBuffer buffer, ChannelMetadata.DataType type) {
        switch (type) {
            case INT8:
                return buffer.get();
            case UINT8:
                return buffer.get() & 0xFF;
            case INT16:
                return buffer.getShort();
            case UINT16:
                return buffer.getShort() & 0xFFFF;
            case INT32:
                return buffer.getInt();
            case UINT32:
                return buffer.getInt() & 0xFFFFFFFFL;
            case INT64:
            case UINT64:
                return buffer.getLong();
            case FLOAT:
                return buffer.getFloat();
            case DOUBLE:
                return buffer.getDouble();
            case BOOLEAN:
                return buffer.get() != 0;
            default:
                return buffer.getDouble();
        }
    }
    
    private void writeChannelDefinitions() throws IOException {
        // 写入通道定义到文件
    }
    
    private void writeFooter() throws IOException {
        // 写入文件尾信息
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (channel != null) {
            channel.force(true);
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (raf != null) {
            raf.close();
            raf = null;
        }
        channel = null;
    }
    
    // ==================== 内部类 ====================
    
    private static class BinaryChannel {
        private final String name;
        private ChannelMetadata.DataType dataType = ChannelMetadata.DataType.DOUBLE;
        private long dataOffset;
        private long nextWritePosition;
        private long recordCount;
        
        BinaryChannel(String name) {
            this.name = name;
        }
        
        String getName() { return name; }
        
        ChannelMetadata.DataType getDataType() { return dataType; }
        void setDataType(ChannelMetadata.DataType type) { this.dataType = type; }
        
        long getDataOffset() { return dataOffset; }
        void setDataOffset(long offset) { 
            this.dataOffset = offset;
            this.nextWritePosition = offset;
        }
        
        long getNextWritePosition() { return nextWritePosition; }
        void updateWritePosition(long position) { this.nextWritePosition = position; }
        
        long getRecordCount() { return recordCount; }
        void incrementRecordCount() { this.recordCount++; }
        void addRecordCount(long count) { this.recordCount += count; }
        
        int getRecordSize() {
            return 8 + getDataSize(); // 时间戳 + 数据
        }
        
        int getDataSize() {
            switch (dataType) {
                case INT8:
                case UINT8:
                case BOOLEAN:
                    return 1;
                case INT16:
                case UINT16:
                    return 2;
                case INT32:
                case UINT32:
                case FLOAT:
                    return 4;
                case INT64:
                case UINT64:
                case DOUBLE:
                    return 8;
                default:
                    return 8;
            }
        }
    }
    
    // ==================== 提供者类 ====================
    
    public static class Provider implements StorageProvider {
        
        @Override
        public DataStorage createStorage() {
            return new BinaryStorage();
        }
        
        @Override
        public String getName() {
            return "Binary";
        }
        
        @Override
        public String getDescription() {
            return "Custom Binary Format - 高性能二进制存储";
        }
        
        @Override
        public String[] getSupportedExtensions() {
            return new String[]{"bin", "dat", "raw"};
        }
        
        @Override
        public boolean supportsCapability(String capability) {
            switch (capability) {
                case CAPABILITY_READ:
                case CAPABILITY_WRITE:
                case CAPABILITY_RANDOM_ACCESS:
                case CAPABILITY_CHUNKING:
                    return true;
                default:
                    return false;
            }
        }
        
        @Override
        public String getVersion() {
            return "1.0";
        }
    }
}
