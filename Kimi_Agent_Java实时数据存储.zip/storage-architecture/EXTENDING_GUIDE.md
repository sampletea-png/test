# 存储系统扩展指南

## 概述

本文档介绍如何为数据观察器系统添加新的存储格式支持。通过遵循本指南，您可以轻松扩展系统以支持任何新的存储格式。

## 设计模式

本存储架构使用了以下设计模式：

### 1. 策略模式 (Strategy Pattern)
- **应用**: `RolloverStrategy` 接口及其实现
- **目的**: 允许运行时切换分块滚动策略（按大小、时间、记录数等）

### 2. 工厂模式 (Factory Pattern)
- **应用**: `StorageFactory` 类和 `StorageProvider` 接口
- **目的**: 根据配置动态创建存储实例，解耦创建逻辑和使用逻辑

### 3. 抽象工厂模式 (Abstract Factory Pattern)
- **应用**: `StorageProvider` 接口
- **目的**: 为一组相关存储格式提供统一的创建接口

### 4. 模板方法模式 (Template Method Pattern)
- **应用**: `AbstractDataStorage` 和 `AbstractChunkStorage` 抽象类
- **目的**: 定义存储操作的算法骨架，子类实现具体步骤

### 5. 接口隔离原则 (Interface Segregation)
- **应用**: `AppendableStorage`, `BatchStorage`, `RandomAccessStorage`, `ChunkStorage`
- **目的**: 将大接口拆分为小接口，实现类只实现需要的接口

## 扩展步骤

### 步骤1: 创建新的存储格式枚举值（可选）

如果新格式是系统通用的，可以在 `StorageFormat` 枚举中添加：

```java
public enum StorageFormat {
    // ... 已有格式
    
    /**
     * 新格式
     */
    NEW_FORMAT("new", "NewFormat", "Description of new format");
    
    // ...
}
```

如果格式是特定应用专用的，可以直接使用字符串标识。

### 步骤2: 实现存储类

创建新的存储类，实现 `DataStorage` 接口：

```java
package com.dataobserver.storage.format;

import com.dataobserver.storage.core.AbstractDataStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.metadata.ChannelMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

public class NewFormatStorage extends AbstractDataStorage {
    
    // 文件句柄
    private Object fileHandle;
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.NEW_FORMAT; // 或返回自定义标识
    }
    
    @Override
    protected void doInitialize() throws IOException {
        // 1. 打开或创建文件
        // 2. 写入/读取文件头
        // 3. 初始化内部数据结构
    }
    
    @Override
    protected void doWriteRecord(String channelName, long timestamp, Object value) throws IOException {
        // 实现单条记录写入
    }
    
    @Override
    protected void doWriteRecords(String channelName, long[] timestamps, Object[] values) throws IOException {
        // 实现批量记录写入（可选优化）
    }
    
    @Override
    protected void doWriteSyncRecord(long timestamp, Map<String, Object> channelValues) throws IOException {
        // 实现同步记录写入
    }
    
    @Override
    protected void doWriteSyncRecords(long[] timestamps, Map<String, Object[]> channelData) throws IOException {
        // 实现批量同步记录写入
    }
    
    @Override
    public Object[] readChannel(String channelName) throws IOException {
        // 实现通道数据读取
        return new Object[0];
    }
    
    @Override
    public Object[] readChannelRange(String channelName, long startTime, long endTime) throws IOException {
        // 实现时间范围读取
        return new Object[0];
    }
    
    @Override
    public List<String> getChannelNames() throws IOException {
        // 返回所有通道名称
        return List.of();
    }
    
    @Override
    protected void doFlush() throws IOException {
        // 刷新数据到磁盘
    }
    
    @Override
    protected void doClose() throws IOException {
        // 关闭文件句柄
    }
}
```

### 步骤3: 实现存储提供者

创建对应的 `StorageProvider` 实现：

```java
public static class Provider implements StorageProvider {
    
    @Override
    public DataStorage createStorage() {
        return new NewFormatStorage();
    }
    
    @Override
    public String getName() {
        return "NewFormat";
    }
    
    @Override
    public String getDescription() {
        return "Description of the new format";
    }
    
    @Override
    public String[] getSupportedExtensions() {
        return new String[]{"new", "ext"};
    }
    
    @Override
    public boolean supportsCapability(String capability) {
        switch (capability) {
            case CAPABILITY_READ:
            case CAPABILITY_WRITE:
                return true;
            case CAPABILITY_APPEND:
                // 如果支持追加返回true
                return false;
            case CAPABILITY_RANDOM_ACCESS:
                // 如果支持随机访问返回true
                return false;
            case CAPABILITY_BATCH_WRITE:
                return true;
            case CAPABILITY_COMPRESSION:
                return false;
            default:
                return false;
        }
    }
    
    @Override
    public String getVersion() {
        return "1.0";
    }
}
```

### 步骤4: 注册存储提供者

在应用程序启动时注册新的存储提供者：

```java
// 方法1: 在应用启动时注册
StorageFactory factory = StorageFactory.getInstance();
factory.registerProvider(StorageFormat.NEW_FORMAT, new NewFormatStorage.Provider());

// 方法2: 通过配置文件自动注册
// 可以实现ServiceLoader机制自动发现并注册
```

### 步骤5: 使用新的存储格式

注册完成后，可以像使用其他格式一样使用新格式：

```java
// 直接创建
DataStorage storage = StorageFactory.getInstance()
    .createStorage(StorageFormat.NEW_FORMAT, filePath, metadata);

// 或通过配置创建
StorageConfiguration config = StorageConfiguration.builder()
    .name("测试")
    .filePath(Paths.get("/tmp/test.new"))
    .format(StorageFormat.NEW_FORMAT)
    .build();

DataStorage storage = StorageFactory.getInstance().createStorage(config);
```

## 高级功能扩展

### 支持追加模式

如果需要支持向已有文件追加数据，实现 `AppendableStorage` 接口：

```java
public class NewFormatStorage extends AbstractDataStorage implements AppendableStorage {
    
    @Override
    public void openForAppend(AppendMode mode) throws IOException {
        // 设置追加模式标志
        // 读取已有文件的元数据和通道信息
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public long getEndPosition() throws IOException {
        // 返回文件末尾位置
        return 0;
    }
}
```

### 支持批量写入优化

如果需要优化大批量数据写入，实现 `BatchStorage` 接口：

```java
public class NewFormatStorage extends AbstractDataStorage implements BatchStorage {
    
    private List<DataBlock<?>> batchQueue = new ArrayList<>();
    private boolean inBatchMode = false;
    private int batchSize = DEFAULT_BATCH_SIZE;
    
    @Override
    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }
    
    @Override
    public void beginBatch() throws IOException {
        inBatchMode = true;
        batchQueue.clear();
    }
    
    @Override
    public void commitBatch() throws IOException {
        // 批量写入所有缓存的数据
        for (DataBlock<?> block : batchQueue) {
            // 写入数据块
        }
        batchQueue.clear();
        inBatchMode = false;
    }
    
    @Override
    public void rollbackBatch() throws IOException {
        batchQueue.clear();
        inBatchMode = false;
    }
    
    @Override
    public <T> void writeDataBlocks(List<DataBlock<T>> dataBlocks) throws IOException {
        // 实现批量数据块写入
    }
}
```

### 支持分块存储

如果需要支持大文件分块，继承 `AbstractChunkStorage`：

```java
public class NewFormatStorage extends AbstractChunkStorage {
    
    @Override
    protected void closeCurrentChunk() throws IOException {
        // 关闭当前分块文件
        flush();
        // 写入分块尾信息
    }
    
    @Override
    protected void createNewChunk(Path chunkPath) throws IOException {
        // 创建新的分块文件
        // 复制必要的头信息
    }
    
    @Override
    public void mergeChunks(Path outputPath) throws IOException {
        // 将所有分块合并为一个文件
    }
}
```

### 支持随机访问

如果需要支持随机读写，实现 `RandomAccessStorage` 接口：

```java
public class NewFormatStorage extends AbstractDataStorage implements RandomAccessStorage {
    
    @Override
    public void seek(long position) throws IOException {
        // 定位到指定位置
    }
    
    @Override
    public byte[] readAt(long position, int length) throws IOException {
        // 从指定位置读取数据
        return new byte[0];
    }
    
    @Override
    public void writeAt(long position, byte[] data) throws IOException {
        // 在指定位置写入数据
    }
    
    @Override
    public boolean supportsRandomWrite() {
        return true;
    }
}
```

## 最佳实践

### 1. 错误处理

- 使用 `IOException` 报告I/O错误
- 提供有意义的错误消息
- 在关闭时确保释放所有资源

```java
@Override
protected void doClose() throws IOException {
    IOException exception = null;
    
    try {
        if (writer != null) {
            writer.close();
        }
    } catch (IOException e) {
        exception = e;
    }
    
    try {
        if (channel != null) {
            channel.close();
        }
    } catch (IOException e) {
        if (exception == null) {
            exception = e;
        } else {
            exception.addSuppressed(e);
        }
    }
    
    if (exception != null) {
        throw exception;
    }
}
```

### 2. 性能优化

- 使用缓冲写入减少I/O次数
- 批量写入多条记录
- 延迟加载通道元数据
- 使用内存映射文件（如果适用）

```java
// 使用缓冲区
private ByteBuffer buffer = ByteBuffer.allocate(8192);

@Override
protected void doWriteRecord(String channelName, long timestamp, Object value) throws IOException {
    // 写入缓冲区
    buffer.putLong(timestamp);
    buffer.putDouble((Double) value);
    
    // 缓冲区满时刷新
    if (!buffer.hasRemaining()) {
        flushBuffer();
    }
}

private void flushBuffer() throws IOException {
    buffer.flip();
    channel.write(buffer);
    buffer.clear();
}
```

### 3. 线程安全

- 使用同步机制保护共享状态
- 或使用线程局部存储

```java
public class NewFormatStorage extends AbstractDataStorage {
    
    // 线程安全的通道映射
    private final ConcurrentHashMap<String, ChannelInfo> channels = 
        new ConcurrentHashMap<>();
    
    // 原子计数器
    private final AtomicLong recordCount = new AtomicLong(0);
    
    @Override
    protected void doWriteRecord(String channelName, long timestamp, Object value) 
            throws IOException {
        // ConcurrentHashMap的computeIfAbsent是线程安全的
        ChannelInfo channel = channels.computeIfAbsent(channelName, this::createChannel);
        
        // 同步写入操作
        synchronized (channel) {
            channel.write(timestamp, value);
        }
        
        recordCount.incrementAndGet();
    }
}
```

### 4. 资源管理

- 实现 `AutoCloseable` 接口（已继承）
- 使用 try-with-resources
- 在 `close()` 中清理所有资源

```java
// 使用 try-with-resources
try (DataStorage storage = factory.createStorage(format, filePath)) {
    // 使用存储
} // 自动关闭
```

## 示例：实现JSON存储格式

以下是一个完整的JSON存储格式实现示例：

```java
package com.dataobserver.storage.format;

import com.dataobserver.storage.core.AbstractDataStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.google.gson.Gson;
import com.google.gson.stream.JsonWriter;

import java.io.*;
import java.nio.file.Path;
import java.util.*;

public class JsonStorage extends AbstractDataStorage {
    
    private final Gson gson = new Gson();
    private JsonWriter jsonWriter;
    private List<DataRecord> records = new ArrayList<>();
    
    @Override
    public StorageFormat getFormat() {
        // 可以返回自定义格式或扩展枚举
        return null; // 或使用 StorageFormat.JSON
    }
    
    @Override
    protected void doInitialize() throws IOException {
        jsonWriter = new JsonWriter(new FileWriter(filePath.toFile()));
        jsonWriter.beginArray();
    }
    
    @Override
    protected void doWriteRecord(String channelName, long timestamp, Object value) 
            throws IOException {
        records.add(new DataRecord(channelName, timestamp, value));
    }
    
    @Override
    protected void doWriteSyncRecord(long timestamp, Map<String, Object> channelValues) 
            throws IOException {
        for (Map.Entry<String, Object> entry : channelValues.entrySet()) {
            records.add(new DataRecord(entry.getKey(), timestamp, entry.getValue()));
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        for (DataRecord record : records) {
            gson.toJson(record, DataRecord.class, jsonWriter);
        }
        records.clear();
        jsonWriter.flush();
    }
    
    @Override
    protected void doClose() throws IOException {
        doFlush();
        jsonWriter.endArray();
        jsonWriter.close();
    }
    
    // ... 其他方法实现
    
    private static class DataRecord {
        String channel;
        long timestamp;
        Object value;
        
        DataRecord(String channel, long timestamp, Object value) {
            this.channel = channel;
            this.timestamp = timestamp;
            this.value = value;
        }
    }
    
    public static class Provider implements StorageProvider {
        @Override
        public DataStorage createStorage() {
            return new JsonStorage();
        }
        
        @Override
        public String getName() { return "JSON"; }
        
        @Override
        public String getDescription() { return "JSON format storage"; }
        
        @Override
        public String[] getSupportedExtensions() { 
            return new String[]{"json"}; 
        }
        
        @Override
        public boolean supportsCapability(String capability) {
            return capability.equals(CAPABILITY_READ) || 
                   capability.equals(CAPABILITY_WRITE);
        }
        
        @Override
        public String getVersion() { return "1.0"; }
    }
}
```

## 测试建议

为新的存储格式编写以下测试：

1. **单元测试**
   - 测试基本读写操作
   - 测试元数据管理
   - 测试边界条件

2. **集成测试**
   - 测试与工厂模式的集成
   - 测试配置驱动创建
   - 测试分块存储（如果支持）

3. **性能测试**
   - 测试大批量数据写入性能
   - 测试随机读取性能
   - 测试内存使用情况

4. **兼容性测试**
   - 测试与其他格式的数据交换
   - 测试版本兼容性

## 总结

通过遵循本指南，您可以：

1. 理解存储架构的设计原则和模式
2. 按照步骤实现新的存储格式
3. 根据需要添加高级功能支持
4. 遵循最佳实践确保代码质量

如有问题，请参考现有实现（MDF4Storage, CSVStorage等）作为参考。
