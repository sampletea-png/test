package com.dataobserver.storage.metadata;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 存储元数据
 * 描述整个存储文件的元信息
 */
public class StorageMetadata {
    
    // 基本信息
    private final String id;
    private String name;
    private String description;
    private String version;
    
    // 时间信息
    private Instant createdAt;
    private Instant modifiedAt;
    private Instant startTime;
    private Instant endTime;
    
    // 存储信息
    private long recordCount;
    private long fileSize;
    private int channelCount;
    
    // 扩展属性
    private final Map<String, Object> properties;
    
    // 创建者信息
    private String creator;
    private String application;
    private String applicationVersion;
    
    public StorageMetadata() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = Instant.now();
        this.modifiedAt = Instant.now();
        this.properties = new HashMap<>();
        this.version = "1.0";
    }
    
    public StorageMetadata(String name) {
        this();
        this.name = name;
    }
    
    // ==================== Getter和Setter ====================
    
    public String getId() { return id; }
    
    public String getName() { return name; }
    public void setName(String name) { 
        this.name = name; 
        updateModifiedTime();
    }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { 
        this.description = description;
        updateModifiedTime();
    }
    
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    
    public Instant getModifiedAt() { return modifiedAt; }
    public void updateModifiedTime() { this.modifiedAt = Instant.now(); }
    
    public Instant getStartTime() { return startTime; }
    public void setStartTime(Instant startTime) { this.startTime = startTime; }
    
    public Instant getEndTime() { return endTime; }
    public void setEndTime(Instant endTime) { this.endTime = endTime; }
    
    public long getRecordCount() { return recordCount; }
    public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
    public void incrementRecordCount() { this.recordCount++; }
    public void addRecordCount(long count) { this.recordCount += count; }
    
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    
    public int getChannelCount() { return channelCount; }
    public void setChannelCount(int channelCount) { this.channelCount = channelCount; }
    
    public String getCreator() { return creator; }
    public void setCreator(String creator) { this.creator = creator; }
    
    public String getApplication() { return application; }
    public void setApplication(String application) { this.application = application; }
    
    public String getApplicationVersion() { return applicationVersion; }
    public void setApplicationVersion(String applicationVersion) { 
        this.applicationVersion = applicationVersion; 
    }
    
    // ==================== 扩展属性操作 ====================
    
    public void setProperty(String key, Object value) {
        properties.put(key, value);
        updateModifiedTime();
    }
    
    public Object getProperty(String key) {
        return properties.get(key);
    }
    
    public <T> T getProperty(String key, Class<T> type) {
        Object value = properties.get(key);
        if (value == null) return null;
        if (type.isInstance(value)) {
            return type.cast(value);
        }
        throw new ClassCastException("属性 " + key + " 类型不匹配");
    }
    
    public boolean hasProperty(String key) {
        return properties.containsKey(key);
    }
    
    public void removeProperty(String key) {
        properties.remove(key);
        updateModifiedTime();
    }
    
    public Map<String, Object> getAllProperties() {
        return new HashMap<>(properties);
    }
    
    public void clearProperties() {
        properties.clear();
        updateModifiedTime();
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 获取记录持续时间（毫秒）
     */
    public long getDurationMs() {
        if (startTime == null || endTime == null) {
            return 0;
        }
        return endTime.toEpochMilli() - startTime.toEpochMilli();
    }
    
    /**
     * 获取采样率估算值
     */
    public double getEstimatedSampleRate() {
        long duration = getDurationMs();
        if (duration <= 0 || recordCount <= 0) {
            return 0;
        }
        return (double) recordCount / (duration / 1000.0);
    }
    
    @Override
    public String toString() {
        return String.format(
            "StorageMetadata[id=%s, name=%s, version=%s, channels=%d, records=%d, size=%d]",
            id, name, version, channelCount, recordCount, fileSize
        );
    }
}
