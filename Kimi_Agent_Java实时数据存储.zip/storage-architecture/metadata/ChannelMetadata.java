package com.dataobserver.storage.metadata;

import java.util.HashMap;
import java.util.Map;

/**
 * 通道元数据
 * 描述单个数据通道的元信息
 */
public class ChannelMetadata {
    
    // 基本标识
    private String name;
    private String displayName;
    private String description;
    private String unit;
    
    // 数据类型
    private DataType dataType;
    private int dataTypeSize; // 字节数
    
    // 数值范围
    private double minimum;
    private double maximum;
    private double defaultValue;
    
    // 采样信息
    private double sampleRate; // Hz
    private long recordCount;
    private long startTimestamp;
    private long endTimestamp;
    
    // 转换信息
    private ConversionType conversionType;
    private double[] conversionParams;
    
    // 扩展属性
    private final Map<String, Object> properties;
    
    /**
     * 数据类型枚举
     */
    public enum DataType {
        INT8("signed integer", 1),
        INT16("signed integer", 2),
        INT32("signed integer", 4),
        INT64("signed integer", 8),
        UINT8("unsigned integer", 1),
        UINT16("unsigned integer", 2),
        UINT32("unsigned integer", 4),
        UINT64("unsigned integer", 8),
        FLOAT("floating point", 4),
        DOUBLE("floating point", 8),
        BOOLEAN("boolean", 1),
        STRING("string", -1),
        BYTE_ARRAY("byte array", -1),
        CAN_MESSAGE("CAN message", -1),
        UNKNOWN("unknown", -1);
        
        private final String description;
        private final int size;
        
        DataType(String description, int size) {
            this.description = description;
            this.size = size;
        }
        
        public String getDescription() { return description; }
        public int getSize() { return size; }
        
        public boolean isVariableSize() {
            return size < 0;
        }
    }
    
    /**
     * 转换类型枚举
     */
    public enum ConversionType {
        NONE,           // 无转换
        LINEAR,         // 线性转换: y = a*x + b
        RATIONAL,       // 有理转换
        TABULAR,        // 表格插值
        TEXT,           // 文本转换
        COMPLEX         // 复杂转换
    }
    
    public ChannelMetadata() {
        this.properties = new HashMap<>();
        this.dataType = DataType.UNKNOWN;
        this.conversionType = ConversionType.NONE;
        this.minimum = Double.NaN;
        this.maximum = Double.NaN;
        this.defaultValue = 0;
    }
    
    public ChannelMetadata(String name) {
        this();
        this.name = name;
    }
    
    public ChannelMetadata(String name, DataType dataType) {
        this(name);
        this.dataType = dataType;
        this.dataTypeSize = dataType.getSize();
    }
    
    // ==================== Getter和Setter ====================
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    public DataType getDataType() { return dataType; }
    public void setDataType(DataType dataType) { 
        this.dataType = dataType;
        this.dataTypeSize = dataType.getSize();
    }
    
    public int getDataTypeSize() { return dataTypeSize; }
    public void setDataTypeSize(int dataTypeSize) { this.dataTypeSize = dataTypeSize; }
    
    public double getMinimum() { return minimum; }
    public void setMinimum(double minimum) { this.minimum = minimum; }
    
    public double getMaximum() { return maximum; }
    public void setMaximum(double maximum) { this.maximum = maximum; }
    
    public double getDefaultValue() { return defaultValue; }
    public void setDefaultValue(double defaultValue) { this.defaultValue = defaultValue; }
    
    public double getSampleRate() { return sampleRate; }
    public void setSampleRate(double sampleRate) { this.sampleRate = sampleRate; }
    
    public long getRecordCount() { return recordCount; }
    public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
    public void incrementRecordCount() { this.recordCount++; }
    public void addRecordCount(long count) { this.recordCount += count; }
    
    public long getStartTimestamp() { return startTimestamp; }
    public void setStartTimestamp(long startTimestamp) { this.startTimestamp = startTimestamp; }
    
    public long getEndTimestamp() { return endTimestamp; }
    public void setEndTimestamp(long endTimestamp) { this.endTimestamp = endTimestamp; }
    
    public ConversionType getConversionType() { return conversionType; }
    public void setConversionType(ConversionType conversionType) { this.conversionType = conversionType; }
    
    public double[] getConversionParams() { return conversionParams; }
    public void setConversionParams(double[] conversionParams) { this.conversionParams = conversionParams; }
    
    // ==================== 扩展属性操作 ====================
    
    public void setProperty(String key, Object value) {
        properties.put(key, value);
    }
    
    public Object getProperty(String key) {
        return properties.get(key);
    }
    
    public <T> T getProperty(String key, Class<T> type) {
        Object value = properties.get(key);
        if (value == null) return null;
        if (type.isInstance(value)) {
            return type.cast(value);
        }
        throw new ClassCastException("属性 " + key + " 类型不匹配");
    }
    
    public boolean hasProperty(String key) {
        return properties.containsKey(key);
    }
    
    public Map<String, Object> getAllProperties() {
        return new HashMap<>(properties);
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 获取持续时间（毫秒）
     */
    public long getDurationMs() {
        if (endTimestamp <= startTimestamp) {
            return 0;
        }
        return endTimestamp - startTimestamp;
    }
    
    /**
     * 检查是否有数值范围限制
     */
    public boolean hasRange() {
        return !Double.isNaN(minimum) && !Double.isNaN(maximum);
    }
    
    /**
     * 检查值是否在有效范围内
     */
    public boolean isInRange(double value) {
        if (!hasRange()) return true;
        return value >= minimum && value <= maximum;
    }
    
    /**
     * 应用转换公式
     */
    public double applyConversion(double rawValue) {
        if (conversionType == ConversionType.NONE || conversionParams == null) {
            return rawValue;
        }
        
        switch (conversionType) {
            case LINEAR:
                // y = a*x + b
                if (conversionParams.length >= 2) {
                    return conversionParams[0] * rawValue + conversionParams[1];
                }
                break;
            case RATIONAL:
                // (p1*x^2 + p2*x + p3) / (p4*x^2 + p5*x + p6)
                if (conversionParams.length >= 6) {
                    double num = conversionParams[0] * rawValue * rawValue 
                               + conversionParams[1] * rawValue 
                               + conversionParams[2];
                    double den = conversionParams[3] * rawValue * rawValue 
                               + conversionParams[4] * rawValue 
                               + conversionParams[5];
                    return den != 0 ? num / den : 0;
                }
                break;
            default:
                break;
        }
        
        return rawValue;
    }
    
    /**
     * 获取完整显示名称（包含单位）
     */
    public String getFullDisplayName() {
        if (displayName != null && unit != null) {
            return displayName + " [" + unit + "]";
        } else if (displayName != null) {
            return displayName;
        }
        return name;
    }
    
    @Override
    public String toString() {
        return String.format(
            "ChannelMetadata[name=%s, type=%s, unit=%s, records=%d]",
            name, dataType, unit, recordCount
        );
    }
}
