package com.dataobserver.storage.factory;

import com.dataobserver.storage.core.DataStorage;
import com.dataobserver.storage.core.StorageFormat;
import com.dataobserver.storage.metadata.StorageMetadata;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 存储工厂类
 * 负责创建和管理不同格式的存储实例
 * 
 * 设计模式：工厂模式 + 注册表模式
 * 1. 通过注册表管理存储提供者
 * 2. 根据配置动态创建存储实例
 * 3. 支持运行时添加新的存储格式
 */
public class StorageFactory {
    
    // 单例实例
    private static volatile StorageFactory instance;
    private static final Object lock = new Object();
    
    // 存储提供者注册表
    private final Map<StorageFormat, StorageProvider> providers = new ConcurrentHashMap<>();
    
    // 默认存储格式
    private StorageFormat defaultFormat = StorageFormat.MDF4;
    
    // 存储实例缓存
    private final Map<String, DataStorage> storageCache = new ConcurrentHashMap<>();
    
    // 是否启用缓存
    private boolean cachingEnabled = false;
    
    private StorageFactory() {
        // 私有构造函数，防止外部实例化
        registerDefaultProviders();
    }
    
    /**
     * 获取工厂单例实例
     */
    public static StorageFactory getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new StorageFactory();
                }
            }
        }
        return instance;
    }
    
    /**
     * 重置工厂实例（主要用于测试）
     */
    public static void resetInstance() {
        synchronized (lock) {
            if (instance != null) {
                instance.closeAllStorages();
            }
            instance = null;
        }
    }
    
    // ==================== 存储提供者注册 ====================
    
    /**
     * 注册存储提供者
     * @param format 存储格式
     * @param provider 存储提供者
     */
    public void registerProvider(StorageFormat format, StorageProvider provider) {
        if (format == null || provider == null) {
            throw new IllegalArgumentException("格式和提供者不能为空");
        }
        providers.put(format, provider);
    }
    
    /**
     * 注销存储提供者
     * @param format 存储格式
     */
    public void unregisterProvider(StorageFormat format) {
        providers.remove(format);
    }
    
    /**
     * 检查是否支持指定格式
     */
    public boolean isFormatSupported(StorageFormat format) {
        return providers.containsKey(format);
    }
    
    /**
     * 获取支持的格式列表
     */
    public StorageFormat[] getSupportedFormats() {
        return providers.keySet().toArray(new StorageFormat[0]);
    }
    
    /**
     * 获取存储提供者
     */
    public StorageProvider getProvider(StorageFormat format) {
        return providers.get(format);
    }
    
    // ==================== 存储创建方法 ====================
    
    /**
     * 创建存储实例
     * @param format 存储格式
     * @param filePath 文件路径
     * @param metadata 存储元数据
     * @return 存储实例
     * @throws IOException 创建失败时抛出
     */
    public DataStorage createStorage(StorageFormat format, Path filePath, 
                                     StorageMetadata metadata) throws IOException {
        StorageProvider provider = providers.get(format);
        if (provider == null) {
            throw new UnsupportedOperationException(
                "不支持的存储格式: " + format + 
                "。请先注册对应的存储提供者。"
            );
        }
        
        DataStorage storage = provider.createStorage();
        storage.initialize(filePath, metadata);
        
        // 缓存存储实例
        if (cachingEnabled) {
            String cacheKey = generateCacheKey(format, filePath);
            storageCache.put(cacheKey, storage);
        }
        
        return storage;
    }
    
    /**
     * 创建存储实例（使用默认元数据）
     */
    public DataStorage createStorage(StorageFormat format, Path filePath) throws IOException {
        return createStorage(format, filePath, new StorageMetadata());
    }
    
    /**
     * 创建存储实例（使用默认格式）
     */
    public DataStorage createStorage(Path filePath, StorageMetadata metadata) throws IOException {
        return createStorage(defaultFormat, filePath, metadata);
    }
    
    /**
     * 创建存储实例（使用默认格式和元数据）
     */
    public DataStorage createStorage(Path filePath) throws IOException {
        return createStorage(defaultFormat, filePath, new StorageMetadata());
    }
    
    /**
     * 根据扩展名创建存储
     */
    public DataStorage createStorageByExtension(String extension, Path filePath, 
                                                StorageMetadata metadata) throws IOException {
        StorageFormat format = StorageFormat.fromExtension(extension);
        return createStorage(format, filePath, metadata);
    }
    
    /**
     * 根据配置创建存储
     */
    public DataStorage createStorage(StorageConfiguration config) throws IOException {
        StorageFormat format = config.getFormat() != null ? config.getFormat() : defaultFormat;
        
        StorageMetadata metadata = new StorageMetadata(config.getName());
        metadata.setDescription(config.getDescription());
        metadata.setCreator(config.getCreator());
        metadata.setApplication(config.getApplication());
        
        // 添加自定义属性
        if (config.getProperties() != null) {
            config.getProperties().forEach(metadata::setProperty);
        }
        
        DataStorage storage = createStorage(format, config.getFilePath(), metadata);
        
        // 应用分块配置
        if (storage instanceof com.dataobserver.storage.chunk.ChunkStorage && 
            config.getChunkConfig() != null) {
            applyChunkConfig((com.dataobserver.storage.chunk.ChunkStorage) storage, config.getChunkConfig());
        }
        
        return storage;
    }
    
    // ==================== 默认配置 ====================
    
    /**
     * 设置默认存储格式
     */
    public void setDefaultFormat(StorageFormat format) {
        if (format == null) {
            throw new IllegalArgumentException("默认格式不能为空");
        }
        this.defaultFormat = format;
    }
    
    /**
     * 获取默认存储格式
     */
    public StorageFormat getDefaultFormat() {
        return defaultFormat;
    }
    
    // ==================== 缓存管理 ====================
    
    /**
     * 启用/禁用缓存
     */
    public void setCachingEnabled(boolean enabled) {
        this.cachingEnabled = enabled;
        if (!enabled) {
            storageCache.clear();
        }
    }
    
    /**
     * 从缓存获取存储实例
     */
    public DataStorage getFromCache(StorageFormat format, Path filePath) {
        String cacheKey = generateCacheKey(format, filePath);
        return storageCache.get(cacheKey);
    }
    
    /**
     * 从缓存移除存储实例
     */
    public void removeFromCache(StorageFormat format, Path filePath) {
        String cacheKey = generateCacheKey(format, filePath);
        storageCache.remove(cacheKey);
    }
    
    /**
     * 清空缓存
     */
    public void clearCache() {
        storageCache.clear();
    }
    
    /**
     * 关闭所有缓存的存储
     */
    public void closeAllStorages() {
        for (DataStorage storage : storageCache.values()) {
            try {
                storage.close();
            } catch (IOException e) {
                // 记录日志但继续关闭其他存储
                System.err.println("关闭存储失败: " + e.getMessage());
            }
        }
        storageCache.clear();
    }
    
    private String generateCacheKey(StorageFormat format, Path filePath) {
        return format.name() + ":" + filePath.toAbsolutePath().toString();
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 注册默认存储提供者
     * 实际项目中这里会注册各种格式的提供者
     */
    private void registerDefaultProviders() {
        // MDF4提供者 - 实际项目中需要实现
        // registerProvider(StorageFormat.MDF4, new MDF4StorageProvider());
        
        // CSV提供者 - 实际项目中需要实现
        // registerProvider(StorageFormat.CSV, new CSVStorageProvider());
        
        // HDF5提供者 - 实际项目中需要实现
        // registerProvider(StorageFormat.HDF5, new HDF5StorageProvider());
        
        // Parquet提供者 - 实际项目中需要实现
        // registerProvider(StorageFormat.PARQUET, new ParquetStorageProvider());
    }
    
    /**
     * 应用分块配置
     */
    private void applyChunkConfig(com.dataobserver.storage.chunk.ChunkStorage storage,
                                  ChunkConfiguration config) {
        if (config.getMaxChunkSize() > 0) {
            storage.setMaxChunkSize(config.getMaxChunkSize());
        }
        if (config.getMaxRecordsPerChunk() > 0) {
            storage.setMaxRecordsPerChunk(config.getMaxRecordsPerChunk());
        }
        if (config.getChunkTimeInterval() > 0) {
            storage.setChunkTimeInterval(config.getChunkTimeInterval());
        }
    }
}
