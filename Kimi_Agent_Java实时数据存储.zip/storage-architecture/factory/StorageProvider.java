package com.dataobserver.storage.factory;

import com.dataobserver.storage.core.DataStorage;

/**
 * 存储提供者接口
 * 每个存储格式需要实现此接口来创建对应的存储实例
 * 
 * 设计模式：抽象工厂模式
 */
public interface StorageProvider {
    
    /**
     * 创建存储实例
     * @return 新的存储实例
     */
    DataStorage createStorage();
    
    /**
     * 获取提供者名称
     */
    String getName();
    
    /**
     * 获取提供者描述
     */
    String getDescription();
    
    /**
     * 获取支持的文件扩展名
     */
    String[] getSupportedExtensions();
    
    /**
     * 检查是否支持特定特性
     * @param capability 特性名称
     */
    boolean supportsCapability(String capability);
    
    /**
     * 获取提供者版本
     */
    String getVersion();
    
    // ==================== 常用特性常量 ====================
    
    String CAPABILITY_READ = "read";
    String CAPABILITY_WRITE = "write";
    String CAPABILITY_APPEND = "append";
    String CAPABILITY_RANDOM_ACCESS = "random_access";
    String CAPABILITY_BATCH_WRITE = "batch_write";
    String CAPABILITY_COMPRESSION = "compression";
    String CAPABILITY_ENCRYPTION = "encryption";
    String CAPABILITY_CHUNKING = "chunking";
    String CAPABILITY_STREAMING = "streaming";
}
