package com.dataobserver.storage.factory;

import com.dataobserver.storage.core.StorageFormat;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * 存储配置类
 * 用于配置存储的各项参数
 */
public class StorageConfiguration {
    
    // 基本配置
    private String name;
    private String description;
    private Path filePath;
    private StorageFormat format;
    
    // 创建者信息
    private String creator;
    private String application;
    private String applicationVersion;
    
    // 分块配置
    private ChunkConfiguration chunkConfig;
    
    // 扩展属性
    private final Map<String, Object> properties = new HashMap<>();
    
    // 缓冲配置
    private int bufferSize = 1000;
    private boolean bufferingEnabled = true;
    
    // 压缩配置
    private boolean compressionEnabled = false;
    private String compressionType = "gzip";
    
    // ==================== 构建器模式 ====================
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private final StorageConfiguration config = new StorageConfiguration();
        
        public Builder name(String name) {
            config.setName(name);
            return this;
        }
        
        public Builder description(String description) {
            config.setDescription(description);
            return this;
        }
        
        public Builder filePath(Path filePath) {
            config.setFilePath(filePath);
            return this;
        }
        
        public Builder format(StorageFormat format) {
            config.setFormat(format);
            return this;
        }
        
        public Builder format(String formatName) {
            config.setFormat(StorageFormat.fromName(formatName));
            return this;
        }
        
        public Builder creator(String creator) {
            config.setCreator(creator);
            return this;
        }
        
        public Builder application(String application) {
            config.setApplication(application);
            return this;
        }
        
        public Builder applicationVersion(String version) {
            config.setApplicationVersion(version);
            return this;
        }
        
        public Builder chunkConfig(ChunkConfiguration chunkConfig) {
            config.setChunkConfig(chunkConfig);
            return this;
        }
        
        public Builder enableChunking(long maxSize, long maxRecords, long timeInterval) {
            config.setChunkConfig(new ChunkConfiguration(maxSize, maxRecords, timeInterval));
            return this;
        }
        
        public Builder bufferSize(int bufferSize) {
            config.setBufferSize(bufferSize);
            return this;
        }
        
        public Builder bufferingEnabled(boolean enabled) {
            config.setBufferingEnabled(enabled);
            return this;
        }
        
        public Builder compressionEnabled(boolean enabled) {
            config.setCompressionEnabled(enabled);
            return this;
        }
        
        public Builder compressionType(String type) {
            config.setCompressionType(type);
            return this;
        }
        
        public Builder property(String key, Object value) {
            config.setProperty(key, value);
            return this;
        }
        
        public StorageConfiguration build() {
            // 验证必填项
            if (config.getFilePath() == null) {
                throw new IllegalStateException("文件路径不能为空");
            }
            if (config.getFormat() == null) {
                throw new IllegalStateException("存储格式不能为空");
            }
            return config;
        }
    }
    
    // ==================== Getter和Setter ====================
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Path getFilePath() { return filePath; }
    public void setFilePath(Path filePath) { this.filePath = filePath; }
    
    public StorageFormat getFormat() { return format; }
    public void setFormat(StorageFormat format) { this.format = format; }
    
    public String getCreator() { return creator; }
    public void setCreator(String creator) { this.creator = creator; }
    
    public String getApplication() { return application; }
    public void setApplication(String application) { this.application = application; }
    
    public String getApplicationVersion() { return applicationVersion; }
    public void setApplicationVersion(String applicationVersion) { 
        this.applicationVersion = applicationVersion; 
    }
    
    public ChunkConfiguration getChunkConfig() { return chunkConfig; }
    public void setChunkConfig(ChunkConfiguration chunkConfig) { this.chunkConfig = chunkConfig; }
    
    public int getBufferSize() { return bufferSize; }
    public void setBufferSize(int bufferSize) { this.bufferSize = bufferSize; }
    
    public boolean isBufferingEnabled() { return bufferingEnabled; }
    public void setBufferingEnabled(boolean bufferingEnabled) { 
        this.bufferingEnabled = bufferingEnabled; 
    }
    
    public boolean isCompressionEnabled() { return compressionEnabled; }
    public void setCompressionEnabled(boolean compressionEnabled) { 
        this.compressionEnabled = compressionEnabled; 
    }
    
    public String getCompressionType() { return compressionType; }
    public void setCompressionType(String compressionType) { this.compressionType = compressionType; }
    
    public Map<String, Object> getProperties() { return new HashMap<>(properties); }
    
    public void setProperty(String key, Object value) {
        properties.put(key, value);
    }
    
    public Object getProperty(String key) {
        return properties.get(key);
    }
    
    public boolean hasProperty(String key) {
        return properties.containsKey(key);
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 检查是否启用分块
     */
    public boolean isChunkingEnabled() {
        return chunkConfig != null;
    }
    
    @Override
    public String toString() {
        return String.format(
            "StorageConfiguration[name=%s, format=%s, path=%s, chunking=%s]",
            name, format, filePath, isChunkingEnabled()
        );
    }
}
