package com.dataobserver.storage.factory;

/**
 * 分块存储配置
 */
public class ChunkConfiguration {
    
    // 默认配置
    public static final long DEFAULT_MAX_CHUNK_SIZE = 500 * 1024 * 1024; // 500MB
    public static final long DEFAULT_MAX_RECORDS = 10_000_000; // 1000万
    public static final long DEFAULT_TIME_INTERVAL = 5 * 60 * 1000; // 5分钟
    
    // 分块限制
    private long maxChunkSize = DEFAULT_MAX_CHUNK_SIZE;
    private long maxRecordsPerChunk = DEFAULT_MAX_RECORDS;
    private long chunkTimeInterval = DEFAULT_TIME_INTERVAL;
    
    // 滚动策略
    private String rolloverStrategy = "default"; // default, size, time, count, composite
    
    // 分块命名模式
    private String namingPattern = "{base}_chunk{index:04d}.{ext}";
    
    // 是否自动合并
    private boolean autoMerge = false;
    
    // 是否保留分块文件
    private boolean keepChunkFiles = true;
    
    public ChunkConfiguration() {
    }
    
    public ChunkConfiguration(long maxChunkSize, long maxRecordsPerChunk, long chunkTimeInterval) {
        this.maxChunkSize = maxChunkSize;
        this.maxRecordsPerChunk = maxRecordsPerChunk;
        this.chunkTimeInterval = chunkTimeInterval;
    }
    
    // ==================== Getter和Setter ====================
    
    public long getMaxChunkSize() { return maxChunkSize; }
    public void setMaxChunkSize(long maxChunkSize) { this.maxChunkSize = maxChunkSize; }
    
    public long getMaxRecordsPerChunk() { return maxRecordsPerChunk; }
    public void setMaxRecordsPerChunk(long maxRecordsPerChunk) { 
        this.maxRecordsPerChunk = maxRecordsPerChunk; 
    }
    
    public long getChunkTimeInterval() { return chunkTimeInterval; }
    public void setChunkTimeInterval(long chunkTimeInterval) { 
        this.chunkTimeInterval = chunkTimeInterval; 
    }
    
    public String getRolloverStrategy() { return rolloverStrategy; }
    public void setRolloverStrategy(String rolloverStrategy) { 
        this.rolloverStrategy = rolloverStrategy; 
    }
    
    public String getNamingPattern() { return namingPattern; }
    public void setNamingPattern(String namingPattern) { this.namingPattern = namingPattern; }
    
    public boolean isAutoMerge() { return autoMerge; }
    public void setAutoMerge(boolean autoMerge) { this.autoMerge = autoMerge; }
    
    public boolean isKeepChunkFiles() { return keepChunkFiles; }
    public void setKeepChunkFiles(boolean keepChunkFiles) { this.keepChunkFiles = keepChunkFiles; }
    
    // ==================== 便捷工厂方法 ====================
    
    /**
     * 创建基于大小的配置
     */
    public static ChunkConfiguration bySize(long maxSizeBytes) {
        ChunkConfiguration config = new ChunkConfiguration();
        config.setMaxChunkSize(maxSizeBytes);
        config.setRolloverStrategy("size");
        return config;
    }
    
    /**
     * 创建基于时间的配置
     */
    public static ChunkConfiguration byTime(long intervalMs) {
        ChunkConfiguration config = new ChunkConfiguration();
        config.setChunkTimeInterval(intervalMs);
        config.setRolloverStrategy("time");
        return config;
    }
    
    /**
     * 创建基于记录数的配置
     */
    public static ChunkConfiguration byCount(long maxRecords) {
        ChunkConfiguration config = new ChunkConfiguration();
        config.setMaxRecordsPerChunk(maxRecords);
        config.setRolloverStrategy("count");
        return config;
    }
    
    /**
     * 创建默认配置（大小或时间）
     */
    public static ChunkConfiguration defaultConfig() {
        ChunkConfiguration config = new ChunkConfiguration();
        config.setRolloverStrategy("default");
        return config;
    }
    
    /**
     * 100MB分块
     */
    public static ChunkConfiguration size100MB() {
        return bySize(100 * 1024 * 1024);
    }
    
    /**
     * 500MB分块
     */
    public static ChunkConfiguration size500MB() {
        return bySize(500 * 1024 * 1024);
    }
    
    /**
     * 1GB分块
     */
    public static ChunkConfiguration size1GB() {
        return bySize(1024 * 1024 * 1024L);
    }
    
    /**
     * 1分钟分块
     */
    public static ChunkConfiguration time1Minute() {
        return byTime(60 * 1000);
    }
    
    /**
     * 5分钟分块
     */
    public static ChunkConfiguration time5Minutes() {
        return byTime(5 * 60 * 1000);
    }
    
    /**
     * 1小时分块
     */
    public static ChunkConfiguration time1Hour() {
        return byTime(60 * 60 * 1000);
    }
    
    @Override
    public String toString() {
        return String.format(
            "ChunkConfiguration[size=%d, records=%d, time=%d, strategy=%s]",
            maxChunkSize, maxRecordsPerChunk, chunkTimeInterval, rolloverStrategy
        );
    }
}
