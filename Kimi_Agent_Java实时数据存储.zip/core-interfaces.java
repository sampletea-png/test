package com.dataobserver.core;

import java.time.Instant;
import java.util.concurrent.CompletableFuture;

/**
 * ============================================
 * 核心数据类型定义
 * ============================================
 */

/**
 * 支持的数据类型枚举
 */
public enum DataType {
    // 基本数值类型
    INT8("int8", 1),
    UINT8("uint8", 1),
    INT16("int16", 2),
    UINT16("uint16", 2),
    INT32("int32", 4),
    UINT32("uint32", 4),
    INT64("int64", 8),
    UINT64("uint64", 8),
    
    // 浮点类型
    FLOAT32("float32", 4),
    FLOAT64("float64", 8),
    
    // 布尔和字符串
    BOOLEAN("boolean", 1),
    STRING("string", -1),  // 变长
    
    // 数组类型
    INT8_ARRAY("int8_array", -1),
    INT16_ARRAY("int16_array", -1),
    INT32_ARRAY("int32_array", -1),
    FLOAT32_ARRAY("float32_array", -1),
    FLOAT64_ARRAY("float64_array", -1);
    
    private final String typeName;
    private final int sizeInBytes;
    
    DataType(String typeName, int sizeInBytes) {
        this.typeName = typeName;
        this.sizeInBytes = sizeInBytes;
    }
    
    public String getTypeName() { return typeName; }
    public int getSizeInBytes() { return sizeInBytes; }
    public boolean isArray() { return typeName.endsWith("_array"); }
}

/**
 * ============================================
 * 数据样本接口 - 单次数据采集的封装
 * ============================================
 */
public interface DataSample {
    
    /**
     * 获取数据源唯一标识
     */
    String getSourceId();
    
    /**
     * 获取数据时间戳（纳秒精度）
     */
    long getTimestampNanos();
    
    /**
     * 获取数据类型
     */
    DataType getDataType();
    
    /**
     * 获取原始数据值
     */
    Object getValue();
    
    /**
     * 获取数据大小（字节）
     */
    int getSizeInBytes();
    
    /**
     * 将数据序列化为字节数组
     */
    byte[] serialize();
    
    /**
     * 重置对象以便复用（对象池模式）
     */
    void reset();
}

/**
 * ============================================
 * 数据源元数据接口
 * ============================================
 */
public interface SourceMetadata {
    
    /**
     * 获取数据源唯一标识
     */
    String getId();
    
    /**
     * 获取数据源名称（人类可读）
     */
    String getName();
    
    /**
     * 获取数据源描述
     */
    String getDescription();
    
    /**
     * 获取数据类型
     */
    DataType getDataType();
    
    /**
     * 获取采样率（Hz，0表示事件驱动）
     */
    double getSampleRate();
    
    /**
     * 获取单位（如 "m/s", "°C" 等）
     */
    String getUnit();
    
    /**
     * 获取最小值（用于数值类型）
     */
    Double getMinValue();
    
    /**
     * 获取最大值（用于数值类型）
     */
    Double getMaxValue();
    
    /**
     * 获取自定义属性
     */
    String getProperty(String key);
    
    /**
     * 设置自定义属性
     */
    void setProperty(String key, String value);
}

/**
 * ============================================
 * 可观察数据源接口 - 核心抽象
 * ============================================
 */
public interface ObservableSource {
    
    /**
     * 获取数据源元数据
     */
    SourceMetadata getMetadata();
    
    /**
     * 获取当前数据值
     */
    Object getCurrentValue();
    
    /**
     * 读取数据并创建样本（由收集器调用）
     */
    DataSample readSample();
    
    /**
     * 注册数据变化监听器
     */
    void addChangeListener(DataChangeListener listener);
    
    /**
     * 移除数据变化监听器
     */
    void removeChangeListener(DataChangeListener listener);
    
    /**
     * 检查数据源是否可用
     */
    boolean isAvailable();
    
    /**
     * 启动数据源（用于周期性采样源）
     */
    void start();
    
    /**
     * 停止数据源
     */
    void stop();
}

/**
 * ============================================
 * 数据变化监听器接口
 * ============================================
 */
@FunctionalInterface
public interface DataChangeListener {
    void onDataChanged(ObservableSource source, DataSample sample);
}

/**
 * ============================================
 * 数据收集器接口
 * ============================================
 */
public interface DataCollector {
    
    /**
     * 收集单个数据样本
     * @param sample 数据样本
     * @return 是否成功
     */
    boolean collect(DataSample sample);
    
    /**
     * 批量收集数据样本
     * @param samples 数据样本数组
     * @return 成功收集的数量
     */
    int collectBatch(DataSample[] samples);
    
    /**
     * 注册数据源到收集器
     */
    void registerSource(ObservableSource source);
    
    /**
     * 从收集器注销数据源
     */
    void unregisterSource(ObservableSource source);
    
    /**
     * 启动收集器
     */
    void start();
    
    /**
     * 停止收集器
     */
    void stop();
    
    /**
     * 获取收集统计信息
     */
    CollectionStats getStats();
}

/**
 * ============================================
 * 收集统计信息
 * ============================================
 */
public interface CollectionStats {
    long getTotalSamplesCollected();
    long getTotalBytesCollected();
    long getSamplesPerSecond();
    long getDroppedSamples();
    long getBufferUtilization();
}

/**
 * ============================================
 * 数据缓冲区接口
 * ============================================
 */
public interface DataBuffer {
    
    /**
     * 写入单个数据样本
     * @return 是否成功（缓冲区满时返回false）
     */
    boolean write(DataSample sample);
    
    /**
     * 批量写入数据样本
     * @return 成功写入的数量
     */
    int writeBatch(DataSample[] samples);
    
    /**
     * 读取单个数据样本
     * @return 样本或null（缓冲区空）
     */
    DataSample read();
    
    /**
     * 批量读取数据样本
     * @param maxCount 最大读取数量
     * @return 读取的样本数组
     */
    DataSample[] readBatch(int maxCount);
    
    /**
     * 获取缓冲区当前大小
     */
    int size();
    
    /**
     * 获取缓冲区容量
     */
    int capacity();
    
    /**
     * 检查缓冲区是否为空
     */
    boolean isEmpty();
    
    /**
     * 检查缓冲区是否已满
     */
    boolean isFull();
    
    /**
     * 清空缓冲区
     */
    void clear();
    
    /**
     * 获取缓冲区利用率（0-100）
     */
    int getUtilization();
}

/**
 * ============================================
 * 数据存储接口
 * ============================================
 */
public interface DataStorage {
    
    /**
     * 打开存储（创建文件/连接）
     * @param filePath 文件路径
     * @param metadata 数据源元数据数组
     */
    void open(String filePath, SourceMetadata[] metadata) throws StorageException;
    
    /**
     * 写入数据样本
     */
    void writeSample(DataSample sample) throws StorageException;
    
    /**
     * 批量写入数据样本
     */
    void writeSamples(DataSample[] samples) throws StorageException;
    
    /**
     * 刷新缓冲区到存储
     */
    void flush() throws StorageException;
    
    /**
     * 关闭存储
     */
    void close() throws StorageException;
    
    /**
     * 获取存储格式名称
     */
    String getFormatName();
    
    /**
     * 获取存储文件扩展名
     */
    String getFileExtension();
    
    /**
     * 检查是否支持压缩
     */
    boolean supportsCompression();
    
    /**
     * 设置压缩级别
     */
    void setCompressionLevel(int level);
}

/**
 * ============================================
 * 存储异常
 * ============================================
 */
public class StorageException extends Exception {
    public StorageException(String message) { super(message); }
    public StorageException(String message, Throwable cause) { super(message, cause); }
}

/**
 * ============================================
 * 数据序列化器接口
 * ============================================
 */
public interface DataSerializer {
    
    /**
     * 将数据样本序列化为字节数组
     */
    byte[] serialize(DataSample sample);
    
    /**
     * 将字节数组反序列化为数据样本
     */
    DataSample deserialize(byte[] data, SourceMetadata metadata);
    
    /**
     * 获取序列化格式名称
     */
    String getFormatName();
}

/**
 * ============================================
 * 数据观察器主接口（外观模式）
 * ============================================
 */
public interface DataObserver {
    
    /**
     * 初始化观察器
     */
    void initialize(ObserverConfig config);
    
    /**
     * 注册可观察数据源
     */
    void registerSource(ObservableSource source);
    
    /**
     * 注销可观察数据源
     */
    void unregisterSource(String sourceId);
    
    /**
     * 获取已注册的数据源
     */
    ObservableSource getSource(String sourceId);
    
    /**
     * 获取所有已注册的数据源
     */
    ObservableSource[] getAllSources();
    
    /**
     * 开始观察（启动所有数据源和收集器）
     */
    void start();
    
    /**
     * 停止观察
     */
    void stop();
    
    /**
     * 暂停观察（不停止数据源，只暂停收集）
     */
    void pause();
    
    /**
     * 恢复观察
     */
    void resume();
    
    /**
     * 立即刷新所有缓冲区到存储
     */
    void flush();
    
    /**
     * 获取观察器状态
     */
    ObserverState getState();
    
    /**
     * 获取观察统计信息
     */
    ObserverStats getStats();
    
    /**
     * 添加观察器事件监听器
     */
    void addEventListener(ObserverEventListener listener);
    
    /**
     * 移除观察器事件监听器
     */
    void removeEventListener(ObserverEventListener listener);
}

/**
 * ============================================
 * 观察器配置
 * ============================================
 */
public class ObserverConfig {
    private String storagePath = "./data";
    private String storageFormat = "MDF4";
    private int bufferSize = 1024 * 1024;  // 1MB
    private int bufferCount = 16;
    private int flushIntervalMs = 1000;
    private int batchSize = 1000;
    private boolean compressionEnabled = true;
    private int compressionLevel = 6;
    private boolean asyncWrite = true;
    private int writeThreads = 1;
    
    // Builder模式
    public static Builder builder() { return new Builder(); }
    
    public static class Builder {
        private ObserverConfig config = new ObserverConfig();
        public Builder storagePath(String path) { config.storagePath = path; return this; }
        public Builder storageFormat(String format) { config.storageFormat = format; return this; }
        public Builder bufferSize(int size) { config.bufferSize = size; return this; }
        public Builder bufferCount(int count) { config.bufferCount = count; return this; }
        public Builder flushIntervalMs(int interval) { config.flushIntervalMs = interval; return this; }
        public Builder batchSize(int size) { config.batchSize = size; return this; }
        public Builder compressionEnabled(boolean enabled) { config.compressionEnabled = enabled; return this; }
        public Builder compressionLevel(int level) { config.compressionLevel = level; return this; }
        public Builder asyncWrite(boolean async) { config.asyncWrite = async; return this; }
        public Builder writeThreads(int threads) { config.writeThreads = threads; return this; }
        public ObserverConfig build() { return config; }
    }
    
    // Getters
    public String getStoragePath() { return storagePath; }
    public String getStorageFormat() { return storageFormat; }
    public int getBufferSize() { return bufferSize; }
    public int getBufferCount() { return bufferCount; }
    public int getFlushIntervalMs() { return flushIntervalMs; }
    public int getBatchSize() { return batchSize; }
    public boolean isCompressionEnabled() { return compressionEnabled; }
    public int getCompressionLevel() { return compressionLevel; }
    public boolean isAsyncWrite() { return asyncWrite; }
    public int getWriteThreads() { return writeThreads; }
}

/**
 * ============================================
 * 观察器状态枚举
 * ============================================
 */
public enum ObserverState {
    INITIALIZED,  // 已初始化
    RUNNING,      // 运行中
    PAUSED,       // 已暂停
    STOPPED       // 已停止
}

/**
 * ============================================
 * 观察器统计信息
 * ============================================
 */
public interface ObserverStats {
    long getTotalSources();
    long getActiveSources();
    long getTotalSamples();
    long getTotalBytes();
    double getDataRateMBps();
    long getDroppedSamples();
    long getBufferUtilization();
    ObserverState getState();
}

/**
 * ============================================
 * 观察器事件监听器
 * ============================================
 */
public interface ObserverEventListener {
    void onSourceRegistered(String sourceId, SourceMetadata metadata);
    void onSourceUnregistered(String sourceId);
    void onDataCollected(String sourceId, long timestamp);
    void onBufferFull();
    void onStorageError(StorageException error);
    void onStateChanged(ObserverState oldState, ObserverState newState);
}
