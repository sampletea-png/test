package com.dataobserver.storage;

import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

/**
 * ============================================
 * 抽象数据存储基类（模板方法模式）
 * ============================================
 */
public abstract class AbstractDataStorage implements DataStorage {
    
    protected String filePath;
    protected SourceMetadata[] metadata;
    protected boolean open = false;
    protected int compressionLevel = 6;
    
    // 模板方法模式定义存储流程
    @Override
    public final void open(String filePath, SourceMetadata[] metadata) throws StorageException {
        this.filePath = filePath;
        this.metadata = metadata;
        
        try {
            // 1. 创建文件
            createFile(filePath);
            
            // 2. 写入头部信息
            writeHeader(metadata);
            
            // 3. 初始化写入资源
            initializeWriter();
            
            this.open = true;
        } catch (Exception e) {
            throw new StorageException("Failed to open storage: " + filePath, e);
        }
    }
    
    @Override
    public final void close() throws StorageException {
        if (!open) return;
        
        try {
            // 1. 刷新缓冲区
            flush();
            
            // 2. 写入尾部信息
            writeFooter();
            
            // 3. 关闭资源
            closeWriter();
            
            this.open = false;
        } catch (Exception e) {
            throw new StorageException("Failed to close storage", e);
        }
    }
    
    // 子类需要实现的模板方法
    protected abstract void createFile(String filePath) throws IOException;
    protected abstract void writeHeader(SourceMetadata[] metadata) throws IOException;
    protected abstract void initializeWriter() throws IOException;
    protected abstract void doWriteSample(DataSample sample) throws IOException;
    protected abstract void doWriteSamples(DataSample[] samples) throws IOException;
    protected abstract void doFlush() throws IOException;
    protected abstract void writeFooter() throws IOException;
    protected abstract void closeWriter() throws IOException;
    
    @Override
    public void writeSample(DataSample sample) throws StorageException {
        ensureOpen();
        try {
            doWriteSample(sample);
        } catch (IOException e) {
            throw new StorageException("Failed to write sample", e);
        }
    }
    
    @Override
    public void writeSamples(DataSample[] samples) throws StorageException {
        ensureOpen();
        try {
            doWriteSamples(samples);
        } catch (IOException e) {
            throw new StorageException("Failed to write samples", e);
        }
    }
    
    @Override
    public void flush() throws StorageException {
        ensureOpen();
        try {
            doFlush();
        } catch (IOException e) {
            throw new StorageException("Failed to flush", e);
        }
    }
    
    protected void ensureOpen() throws StorageException {
        if (!open) {
            throw new StorageException("Storage is not open");
        }
    }
    
    @Override
    public void setCompressionLevel(int level) {
        this.compressionLevel = Math.max(0, Math.min(9, level));
    }
    
    @Override
    public boolean supportsCompression() {
        return false;
    }
}

/**
 * ============================================
 * MDF4格式存储实现
 * ============================================
 * MDF4 (Measurement Data Format version 4) 是汽车测量领域标准格式
 * 
 * MDF4文件结构：
 * - ID Block (64 bytes): 文件标识
 * - Header Block (104 bytes): 文件头部信息
 * - Data Group Block: 数据组信息
 * - Channel Group Block: 通道组信息
 * - Channel Block: 通道（数据源）信息
 * - Data Block: 实际数据
 */
public class MDF4DataStorage extends AbstractDataStorage {
    
    // MDF4常量定义
    private static final String MDF_ID = "MDF ";
    private static final String MDF_VERSION = "4.10";
    private static final int ID_BLOCK_SIZE = 64;
    private static final int HEADER_BLOCK_SIZE = 104;
    
    // 文件通道
    private FileChannel fileChannel;
    private ByteBuffer writeBuffer;
    
    // 数据块位置跟踪
    private long dataBlockOffset;
    private final List<Long> dataBlockPositions = new ArrayList<>();
    
    // 压缩
    private Deflater deflater;
    private boolean useCompression = false;
    
    @Override
    protected void createFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        Files.createDirectories(path.getParent());
        
        // 使用FileChannel进行高效文件操作
        this.fileChannel = FileChannel.open(path, 
            StandardOpenOption.CREATE, 
            StandardOpenOption.WRITE,
            StandardOpenOption.READ);
        
        // 分配直接缓冲区（堆外内存）
        this.writeBuffer = ByteBuffer.allocateDirect(1024 * 1024); // 1MB
    }
    
    @Override
    protected void writeHeader(SourceMetadata[] metadata) throws IOException {
        // 写入ID Block
        writeIdBlock();
        
        // 写入Header Block
        writeHeaderBlock(metadata);
        
        // 写入Channel信息
        writeChannelBlocks(metadata);
        
        // 记录数据块起始位置
        this.dataBlockOffset = fileChannel.position();
        
        // 初始化压缩器
        if (useCompression) {
            this.deflater = new Deflater(compressionLevel);
        }
    }
    
    private void writeIdBlock() throws IOException {
        ByteBuffer idBlock = ByteBuffer.allocate(ID_BLOCK_SIZE);
        
        // 文件标识 "MDF "
        idBlock.put(MDF_ID.getBytes());
        
        // 格式版本
        idBlock.put(MDF_VERSION.getBytes());
        
        // 标准版本 (4.0)
        idBlock.putShort((short) 400);
        
        // 保留字段
        idBlock.put(new byte[34]);
        
        // 默认字节序 (0=little endian)
        idBlock.put((byte) 0);
        
        // 浮点格式 (0=IEEE 754)
        idBlock.put((byte) 0);
        
        // 版本信息
        idBlock.putShort((short) 0);
        
        // 保留
        idBlock.put(new byte[14]);
        
        idBlock.flip();
        fileChannel.write(idBlock);
    }
    
    private void writeHeaderBlock(SourceMetadata[] metadata) throws IOException {
        ByteBuffer headerBlock = ByteBuffer.allocate(HEADER_BLOCK_SIZE);
        
        // Block Type "HD"
        headerBlock.put("HD".getBytes());
        
        // Block Size
        headerBlock.putInt(HEADER_BLOCK_SIZE);
        
        // 链接数量
        headerBlock.putInt(4);
        
        // 链接指针 (简化实现)
        headerBlock.putLong(0); // DG block link
        headerBlock.putLong(0); // Text block link
        headerBlock.putLong(0); // Program block link
        headerBlock.putLong(0); // Data block link
        
        // 时间戳
        headerBlock.putLong(System.currentTimeMillis());
        
        // 时区偏移
        headerBlock.putShort((short) TimeZone.getDefault().getRawOffset() / 60000);
        
        // 夏令时标志
        headerBlock.put((byte) 0);
        
        // 时间精度
        headerBlock.put((byte) 0);
        
        // 保留
        headerBlock.put(new byte[66]);
        
        headerBlock.flip();
        fileChannel.write(headerBlock);
    }
    
    private void writeChannelBlocks(SourceMetadata[] metadata) throws IOException {
        // 为每个数据源创建通道块
        for (int i = 0; i < metadata.length; i++) {
            SourceMetadata meta = metadata[i];
            writeChannelBlock(meta, i);
        }
    }
    
    private void writeChannelBlock(SourceMetadata metadata, int index) throws IOException {
        ByteBuffer channelBlock = ByteBuffer.allocate(128);
        
        // Block Type "CN"
        channelBlock.put("CN".getBytes());
        
        // Block Size
        channelBlock.putInt(128);
        
        // 链接数量
        channelBlock.putInt(8);
        
        // 链接指针（简化）
        channelBlock.putLong(0); // Next channel
        channelBlock.putLong(0); // Component
        channelBlock.putLong(0); // Text name
        channelBlock.putLong(0); // Text source
        channelBlock.putLong(0); // Conversion
        channelBlock.putLong(0); // Data
        channelBlock.putLong(0); // Unit
        channelBlock.putLong(0); // Comment
        
        // 通道类型 (0=data channel)
        channelBlock.put((byte) 0);
        
        // 同步类型
        channelBlock.put((byte) 0);
        
        // 数据类型
        channelBlock.put((byte) getMDF4DataType(metadata.getDataType()));
        
        // 位偏移
        channelBlock.put((byte) 0);
        
        // 字节偏移
        channelBlock.putInt(0);
        
        // 位计数
        channelBlock.putInt(getBitCount(metadata.getDataType()));
        
        // 标志
        channelBlock.putInt(0);
        
        // 无效位位置
        channelBlock.putInt(0);
        
        // 精度
        channelBlock.putInt(3);
        
        // 保留
        channelBlock.put(new byte[20]);
        
        // 附加数据（如范围限制）
        if (metadata.getMinValue() != null) {
            channelBlock.putDouble(metadata.getMinValue());
        } else {
            channelBlock.putDouble(0);
        }
        
        if (metadata.getMaxValue() != null) {
            channelBlock.putDouble(metadata.getMaxValue());
        } else {
            channelBlock.putDouble(0);
        }
        
        channelBlock.flip();
        fileChannel.write(channelBlock);
    }
    
    private byte getMDF4DataType(DataType type) {
        switch (type) {
            case INT8: return 0;
            case UINT8: return 1;
            case INT16: return 2;
            case UINT16: return 3;
            case INT32: return 4;
            case UINT32: return 5;
            case INT64: return 6;
            case UINT64: return 7;
            case FLOAT32: return 8;
            case FLOAT64: return 9;
            default: return 0;
        }
    }
    
    private int getBitCount(DataType type) {
        return type.getSizeInBytes() * 8;
    }
    
    @Override
    protected void initializeWriter() throws IOException {
        // 已在writeHeader中初始化
    }
    
    @Override
    protected void doWriteSample(DataSample sample) throws IOException {
        // 写入时间戳（8字节）
        writeBuffer.putLong(sample.getTimestampNanos());
        
        // 写入数据
        writeSampleData(sample);
        
        // 检查是否需要刷新缓冲区
        if (!writeBuffer.hasRemaining()) {
            flushWriteBuffer();
        }
    }
    
    @Override
    protected void doWriteSamples(DataSample[] samples) throws IOException {
        for (DataSample sample : samples) {
            // 检查缓冲区空间
            int requiredSpace = 8 + sample.getSizeInBytes(); // 时间戳 + 数据
            
            if (writeBuffer.remaining() < requiredSpace) {
                flushWriteBuffer();
            }
            
            // 写入时间戳
            writeBuffer.putLong(sample.getTimestampNanos());
            
            // 写入数据
            writeSampleData(sample);
        }
        
        // 批量写入后刷新
        flushWriteBuffer();
    }
    
    private void writeSampleData(DataSample sample) throws IOException {
        Object value = sample.getValue();
        DataType type = sample.getDataType();
        
        switch (type) {
            case INT8:
            case UINT8:
                writeBuffer.put(((Number) value).byteValue());
                break;
            case INT16:
            case UINT16:
                writeBuffer.putShort(((Number) value).shortValue());
                break;
            case INT32:
            case UINT32:
                writeBuffer.putInt(((Number) value).intValue());
                break;
            case INT64:
            case UINT64:
                writeBuffer.putLong(((Number) value).longValue());
                break;
            case FLOAT32:
                writeBuffer.putFloat(((Number) value).floatValue());
                break;
            case FLOAT64:
                writeBuffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                writeBuffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            case STRING:
                byte[] strBytes = ((String) value).getBytes();
                writeBuffer.putInt(strBytes.length);
                writeBuffer.put(strBytes);
                break;
            default:
                // 数组类型
                if (value instanceof byte[]) {
                    byte[] arr = (byte[]) value;
                    writeBuffer.putInt(arr.length);
                    writeBuffer.put(arr);
                } else if (value instanceof float[]) {
                    float[] arr = (float[]) value;
                    writeBuffer.putInt(arr.length);
                    for (float f : arr) writeBuffer.putFloat(f);
                } else if (value instanceof double[]) {
                    double[] arr = (double[]) value;
                    writeBuffer.putInt(arr.length);
                    for (double d : arr) writeBuffer.putDouble(d);
                }
                break;
        }
    }
    
    private void flushWriteBuffer() throws IOException {
        if (writeBuffer.position() == 0) return;
        
        writeBuffer.flip();
        
        if (useCompression && deflater != null) {
            // 压缩写入
            byte[] input = new byte[writeBuffer.remaining()];
            writeBuffer.get(input);
            
            deflater.setInput(input);
            deflater.finish();
            
            byte[] output = new byte[input.length];
            int compressedSize = deflater.deflate(output);
            deflater.reset();
            
            ByteBuffer compressed = ByteBuffer.wrap(output, 0, compressedSize);
            fileChannel.write(compressed);
        } else {
            // 直接写入
            fileChannel.write(writeBuffer);
        }
        
        writeBuffer.clear();
    }
    
    @Override
    protected void doFlush() throws IOException {
        flushWriteBuffer();
        fileChannel.force(true);
    }
    
    @Override
    protected void writeFooter() throws IOException {
        // 写入数据块结束标记
        ByteBuffer footer = ByteBuffer.allocate(8);
        footer.putLong(0xFFFFFFFFFFFFFFFFL); // 结束标记
        footer.flip();
        fileChannel.write(footer);
    }
    
    @Override
    protected void closeWriter() throws IOException {
        if (deflater != null) {
            deflater.end();
        }
        if (fileChannel != null) {
            fileChannel.close();
        }
    }
    
    @Override
    public String getFormatName() {
        return "MDF4";
    }
    
    @Override
    public String getFileExtension() {
        return ".mf4";
    }
    
    @Override
    public boolean supportsCompression() {
        return true;
    }
}

/**
 * ============================================
 * CSV格式存储实现
 * ============================================
 */
public class CSVDataStorage extends AbstractDataStorage {
    
    private BufferedWriter writer;
    private final StringBuilder lineBuilder = new StringBuilder(1024);
    private int batchCount = 0;
    private static final int BATCH_FLUSH_SIZE = 1000;
    
    @Override
    protected void createFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        Files.createDirectories(path.getParent());
        this.writer = Files.newBufferedWriter(path, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
    }
    
    @Override
    protected void writeHeader(SourceMetadata[] metadata) throws IOException {
        // 写入CSV头部
        lineBuilder.setLength(0);
        lineBuilder.append("timestamp_nanos");
        
        for (SourceMetadata meta : metadata) {
            lineBuilder.append(",").append(escapeCSV(meta.getName()));
            if (meta.getUnit() != null && !meta.getUnit().isEmpty()) {
                lineBuilder.append(" (").append(meta.getUnit()).append(")");
            }
        }
        
        writer.write(lineBuilder.toString());
        writer.newLine();
        
        // 写入元数据注释
        writer.write("# Data source metadata:");
        writer.newLine();
        for (SourceMetadata meta : metadata) {
            writer.write(String.format("# %s: type=%s, rate=%.2fHz", 
                meta.getId(), meta.getDataType(), meta.getSampleRate()));
            writer.newLine();
        }
    }
    
    @Override
    protected void initializeWriter() throws IOException {
        // 已在createFile中初始化
    }
    
    @Override
    protected void doWriteSample(DataSample sample) throws IOException {
        lineBuilder.setLength(0);
        lineBuilder.append(sample.getTimestampNanos());
        lineBuilder.append(",");
        appendValue(lineBuilder, sample);
        
        writer.write(lineBuilder.toString());
        writer.newLine();
        
        if (++batchCount >= BATCH_FLUSH_SIZE) {
            writer.flush();
            batchCount = 0;
        }
    }
    
    @Override
    protected void doWriteSamples(DataSample[] samples) throws IOException {
        for (DataSample sample : samples) {
            lineBuilder.setLength(0);
            lineBuilder.append(sample.getTimestampNanos());
            lineBuilder.append(",");
            appendValue(lineBuilder, sample);
            
            writer.write(lineBuilder.toString());
            writer.newLine();
        }
        
        writer.flush();
        batchCount = 0;
    }
    
    private void appendValue(StringBuilder sb, DataSample sample) {
        Object value = sample.getValue();
        if (value == null) {
            sb.append("");
            return;
        }
        
        if (value.getClass().isArray()) {
            sb.append("\"");
            if (value instanceof byte[]) {
                byte[] arr = (byte[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(";");
                    sb.append(arr[i]);
                }
            } else if (value instanceof float[]) {
                float[] arr = (float[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(";");
                    sb.append(arr[i]);
                }
            } else if (value instanceof double[]) {
                double[] arr = (double[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(";");
                    sb.append(arr[i]);
                }
            }
            sb.append("\"");
        } else {
            sb.append(value.toString());
        }
    }
    
    private String escapeCSV(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
    
    @Override
    protected void doFlush() throws IOException {
        writer.flush();
    }
    
    @Override
    protected void writeFooter() throws IOException {
        writer.write("# End of data");
        writer.newLine();
    }
    
    @Override
    protected void closeWriter() throws IOException {
        if (writer != null) {
            writer.close();
        }
    }
    
    @Override
    public String getFormatName() {
        return "CSV";
    }
    
    @Override
    public String getFileExtension() {
        return ".csv";
    }
}

/**
 * ============================================
 * HDF5格式存储实现（简化框架）
 * ============================================
 * 实际实现需要使用HDF5 Java库（如jhdf5）
 */
public class HDF5DataStorage extends AbstractDataStorage {
    
    // HDF5文件句柄（实际实现需要使用HDF5库）
    private Object hdf5File; // 占位符
    
    @Override
    protected void createFile(String filePath) throws IOException {
        // 使用HDF5库创建文件
        // 实际实现: hdf5File = HDF5Factory.open(filePath);
        throw new UnsupportedOperationException("HDF5 support requires HDF5 library");
    }
    
    @Override
    protected void writeHeader(SourceMetadata[] metadata) throws IOException {
        // 创建HDF5数据集结构
        // 实际实现需要创建Group和Dataset
    }
    
    @Override
    protected void initializeWriter() throws IOException {
        // HDF5特定初始化
    }
    
    @Override
    protected void doWriteSample(DataSample sample) throws IOException {
        // 写入HDF5数据集
    }
    
    @Override
    protected void doWriteSamples(DataSample[] samples) throws IOException {
        // 批量写入HDF5数据集
    }
    
    @Override
    protected void doFlush() throws IOException {
        // HDF5 flush
    }
    
    @Override
    protected void writeFooter() throws IOException {
        // HDF5 footer
    }
    
    @Override
    protected void closeWriter() throws IOException {
        // 关闭HDF5文件
    }
    
    @Override
    public String getFormatName() {
        return "HDF5";
    }
    
    @Override
    public String getFileExtension() {
        return ".h5";
    }
    
    @Override
    public boolean supportsCompression() {
        return true;
    }
}
