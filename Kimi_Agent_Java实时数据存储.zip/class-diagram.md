# Java数据观察器系统 - 类图文档

## 1. 核心接口类图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              核心接口层 (Core Interfaces)                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐         ┌─────────────────────┐                        │
│  │   <<interface>>     │         │   <<interface>>     │                        │
│  │    DataObserver     │◄────────│  ObserverEvent      │                        │
│  │  (数据观察器主接口)  │         │     Listener        │                        │
│  ├─────────────────────┤         ├─────────────────────┤                        │
│  │ +initialize()       │         │ +onSourceRegistered │                        │
│  │ +registerSource()   │         │ +onSourceUnregistered│                       │
│  │ +unregisterSource() │         │ +onDataCollected()  │                        │
│  │ +start()            │         │ +onBufferFull()     │                        │
│  │ +stop()             │         │ +onStorageError()   │                        │
│  │ +pause()            │         │ +onStateChanged()   │                        │
│  │ +resume()           │         └─────────────────────┘                        │
│  │ +flush()            │                                                        │
│  │ +getState()         │         ┌─────────────────────┐                        │
│  │ +getStats()         │         │   <<interface>>     │                        │
│  └─────────────────────┘         │   ObserverStats     │                        │
│                                  ├─────────────────────┤                        │
│                                  │ +getTotalSources()  │                        │
│  ┌─────────────────────┐         │ +getTotalSamples()  │                        │
│  │   <<interface>>     │         │ +getDataRateMBps()  │                        │
│  │  ObservableSource   │         └─────────────────────┘                        │
│  │  (可观察数据源接口)  │                                                        │
│  ├─────────────────────┤                                                        │
│  │ +getMetadata()      │         ┌─────────────────────┐                        │
│  │ +getCurrentValue()  │         │   <<interface>>     │                        │
│  │ +readSample()       │         │  DataChangeListener │                        │
│  │ +addChangeListener()│         ├─────────────────────┤                        │
│  │ +removeChangeListener│        │ +onDataChanged()    │                        │
│  │ +isAvailable()      │         └─────────────────────┘                        │
│  │ +start()            │                                                        │
│  │ +stop()             │                                                        │
│  └─────────────────────┘                                                        │
│                                                                                 │
│  ┌─────────────────────┐         ┌─────────────────────┐                        │
│  │   <<interface>>     │         │   <<interface>>     │                        │
│  │  SourceMetadata     │         │    DataSample       │                        │
│  │  (数据源元数据)      │         │   (数据样本)         │                        │
│  ├─────────────────────┤         ├─────────────────────┤                        │
│  │ +getId()            │         │ +getSourceId()      │                        │
│  │ +getName()          │         │ +getTimestampNanos()│                        │
│  │ +getDescription()   │         │ +getDataType()      │                        │
│  │ +getDataType()      │         │ +getValue()         │                        │
│  │ +getSampleRate()    │         │ +getSizeInBytes()   │                        │
│  │ +getUnit()          │         │ +serialize()        │                        │
│  │ +getMinValue()      │         │ +reset()            │                        │
│  │ +getMaxValue()      │         └─────────────────────┘                        │
│  └─────────────────────┘                                                        │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 2. 数据收集与缓冲类图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           收集与缓冲层 (Collection & Buffer)                     │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐         ┌─────────────────────┐                        │
│  │   <<interface>>     │         │   <<interface>>     │                        │
│  │   DataCollector     │◄────────│   CollectionStats   │                        │
│  │   (数据收集器)        │         │   (收集统计信息)      │                        │
│  ├─────────────────────┤         ├─────────────────────┤                        │
│  │ +collect()          │         │ +getTotalSamples()  │                        │
│  │ +collectBatch()     │         │ +getTotalBytes()    │                        │
│  │ +registerSource()   │         │ +getSamplesPerSecond│                        │
│  │ +unregisterSource() │         │ +getDroppedSamples()│                        │
│  │ +start()            │         │ +getBufferUtilization│                       │
│  │ +stop()             │         └─────────────────────┘                        │
│  │ +getStats()         │                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐                                                        │
│  │  DataCollectorImpl  │                                                        │
│  │  (收集器实现)        │                                                        │
│  ├─────────────────────┤                                                        │
│  │ -buffer: DataBuffer │                                                        │
│  │ -sources: Set       │                                                        │
│  │ -running: AtomicBoolean                                                    │
│  │ -totalCollected: AtomicLong                                                │
│  │ -batchBuffer: DataSample[]                                                 │
│  │ -batchIndex: AtomicInteger                                                 │
│  ├─────────────────────┤                                                        │
│  │ +collect()          │                                                        │
│  │ +collectBatch()     │         ┌─────────────────────┐                        │
│  │ +flushBatch()       │         │   <<interface>>     │                        │
│  │ +onDataChanged()    │         │    DataBuffer       │                        │
│  └─────────────────────┘         │   (数据缓冲区)        │                        │
│                                  ├─────────────────────┤                        │
│                                  │ +write()            │                        │
│  ┌─────────────────────┐         │ +writeBatch()       │                        │
│  │     RingBuffer      │◄────────│ +read()             │                        │
│  │   (环形缓冲区实现)    │         │ +readBatch()        │                        │
│  ├─────────────────────┤         │ +size()             │                        │
│  │ -buffer: DataSample[]         │ +capacity()         │                        │
│  │ -capacity: int      │         │ +isEmpty()          │                        │
│  │ -mask: int          │         │ +isFull()           │                        │
│  │ -writeSequence: AtomicLong    │ +clear()            │                        │
│  │ -readSequence: AtomicLong     │ +getUtilization()   │                        │
│  ├─────────────────────┤         └─────────────────────┘                        │
│  │ +write()            │                                                        │
│  │ +read()             │         ┌─────────────────────┐                        │
│  │ +size()             │         │   <<enum>>          │                        │
│  │ +isFull()           │         │     DataType        │                        │
│  │ +getUtilization()   │         │   (数据类型枚举)      │                        │
│  └─────────────────────┘         ├─────────────────────┤                        │
│                                  │ INT8, UINT8         │                        │
│                                  │ INT16, UINT16       │                        │
│                                  │ INT32, UINT32       │                        │
│                                  │ INT64, UINT64       │                        │
│                                  │ FLOAT32, FLOAT64    │                        │
│                                  │ BOOLEAN, STRING     │                        │
│                                  │ *_ARRAY             │                        │
│                                  └─────────────────────┘                        │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 3. 存储层类图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              存储层 (Storage Layer)                              │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐                                                        │
│  │   <<interface>>     │                                                        │
│  │    DataStorage      │                                                        │
│  │   (数据存储接口)      │                                                        │
│  ├─────────────────────┤                                                        │
│  │ +open()             │                                                        │
│  │ +writeSample()      │                                                        │
│  │ +writeSamples()     │                                                        │
│  │ +flush()            │                                                        │
│  │ +close()            │                                                        │
│  │ +getFormatName()    │                                                        │
│  │ +getFileExtension() │                                                        │
│  │ +supportsCompression│                                                        │
│  │ +setCompressionLevel│                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐                                                        │
│  │ AbstractDataStorage │                                                        │
│  │  (存储抽象基类)       │◄──────────────────────────────────────────────┐     │
│  │  [模板方法模式]       │                                               │     │
│  ├─────────────────────┤                                               │     │
│  │ #filePath: String   │                                               │     │
│  │ #metadata[]         │                                               │     │
│  │ #open: boolean      │                                               │     │
│  │ #compressionLevel   │                                               │     │
│  ├─────────────────────┤                                               │     │
│  │ +open() [final]     │                                               │     │
│  │ +close() [final]    │                                               │     │
│  │ #createFile()       │                                               │     │
│  │ #writeHeader()      │                                               │     │
│  │ #initializeWriter() │                                               │     │
│  │ #doWriteSample()    │                                               │     │
│  │ #doWriteSamples()   │                                               │     │
│  │ #doFlush()          │                                               │     │
│  │ #writeFooter()      │                                               │     │
│  │ #closeWriter()      │                                               │     │
│  └─────────────────────┘                                               │     │
│           △                                                            │     │
│           │                                                            │     │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐    │
│  │   MDF4DataStorage   │  │   CSVDataStorage    │  │   HDF5DataStorage   │    │
│  │   (MDF4格式存储)     │  │   (CSV格式存储)      │  │   (HDF5格式存储)     │    │
│  ├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤    │
│  │ -fileChannel        │  │ -writer: BufferedWriter                    │    │
│  │ -writeBuffer        │  │ -lineBuilder        │  │ -hdf5File: Object   │    │
│  │ -deflater           │  │ -batchCount         │  │                     │    │
│  ├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤    │
│  │ #createFile()       │  │ #createFile()       │  │ #createFile()       │    │
│  │ #writeIdBlock()     │  │ #writeHeader()      │  │ #writeHeader()      │    │
│  │ #writeHeaderBlock() │  │ #doWriteSample()    │  │ #doWriteSample()    │    │
│  │ #writeChannelBlock()│  │ #doWriteSamples()   │  │ #doWriteSamples()   │    │
│  │ #doWriteSample()    │  │ #appendValue()      │  │ #doFlush()          │    │
│  │ #flushWriteBuffer() │  │ #escapeCSV()        │  │ #writeFooter()      │    │
│  │ +getFormatName()    │  │ +getFormatName()    │  │ +getFormatName()    │    │
│  │ +supportsCompression│  │ +supportsCompression│  │ +supportsCompression│    │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘    │
│                                                                                 │
│  ┌─────────────────────┐                                                        │
│  │   StorageFactory    │                                                        │
│  │   (存储工厂)         │                                                        │
│  ├─────────────────────┤                                                        │
│  │ +createStorage()    │                                                        │
│  └─────────────────────┘                                                        │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 4. 数据源类图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              数据源层 (Source Layer)                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐                                                        │
│  │   <<interface>>     │                                                        │
│  │  ObservableSource   │                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐                                                        │
│  │ AbstractObservableSource                                                   │
│  │   (数据源抽象基类)   │                                                        │
│  ├─────────────────────┤                                                        │
│  │ #metadata           │                                                        │
│  │ #listeners: Set     │                                                        │
│  │ #available          │                                                        │
│  │ #running            │                                                        │
│  │ #scheduler          │                                                        │
│  ├─────────────────────┤                                                        │
│  │ #doSample()         │                                                        │
│  │ #notifyListeners()  │                                                        │
│  │ #createSample()     │                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐     │
│  │ FieldObservableSource│  │MethodObservableSource│  │SupplierObservableSource   │
│  │  (字段数据源)         │  │  (方法数据源)         │  │  (函数式数据源)        │     │
│  ├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤     │
│  │ -target: Object     │  │ -target: Object     │  │ -supplier: Supplier │     │
│  │ -field: Field       │  │ -method: Method     │  │                     │     │
│  ├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤     │
│  │ +getCurrentValue()  │  │ +getCurrentValue()  │  │ +getCurrentValue()  │     │
│  │ +readSample()       │  │ +readSample()       │  │ +readSample()       │     │
│  │ #doSample()         │  │ #doSample()         │  │ #doSample()         │     │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘     │
│                                                                                 │
│  ┌─────────────────────┐  ┌─────────────────────┐                               │
│  │ ProxyObservableSource│  │CompositeObservableSource                          │
│  │  (代理数据源)         │  │  (组合数据源)         │                               │
│  ├─────────────────────┤  ├─────────────────────┤                               │
│  │ -delegate           │  │ -sources: List      │                               │
│  │ -transformer        │  │ -combiner           │                               │
│  │ -proxyMetadata      │  │                     │                               │
│  ├─────────────────────┤  ├─────────────────────┤                               │
│  │ +getCurrentValue()  │  │ +getCurrentValue()  │                               │
│  │ +readSample()       │  │ +readSample()       │                               │
│  └─────────────────────┘  └─────────────────────┘                               │
│                                                                                 │
│  ┌─────────────────────────┐  ┌─────────────────────────┐                       │
│  │ ObservableSourceBuilder │  │ ObservableSourceFactory │                       │
│  │   (数据源构建器)         │  │   (数据源工厂)           │                       │
│  ├─────────────────────────┤  ├─────────────────────────┤                       │
│  │ +create()               │  │ +fromObjectFields()     │                       │
│  │ +name()                 │  │ +fromObjectNumericFields│                       │
│  │ +sampleRate()           │  │                         │                       │
│  │ +unit()                 │  │                         │                       │
│  │ +range()                │  │                         │                       │
│  │ +fromField()            │  │                         │                       │
│  │ +fromMethod()           │  │                         │                       │
│  │ +fromSupplier()         │  │                         │                       │
│  └─────────────────────────┘  └─────────────────────────┘                       │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 5. 序列化器类图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            序列化层 (Serialization Layer)                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐                                                        │
│  │   <<interface>>     │                                                        │
│  │   DataSerializer    │                                                        │
│  │   (数据序列化器)      │                                                        │
│  ├─────────────────────┤                                                        │
│  │ +serialize()        │                                                        │
│  │ +deserialize()      │                                                        │
│  │ +getFormatName()    │                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐                                                        │
│  │ AbstractDataSerializer                                                     │
│  │  (序列化器抽象基类)  │                                                        │
│  ├─────────────────────┤                                                        │
│  │ #calculateSerializedSize()                                                 │
│  │ #writeValue()       │                                                        │
│  │ #writeString()      │                                                        │
│  │ #writeByteArray()   │                                                        │
│  │ #writeFloatArray()  │                                                        │
│  │ #writeDoubleArray() │                                                        │
│  │ #readValue()        │                                                        │
│  │ #readString()       │                                                        │
│  │ #readByteArray()    │                                                        │
│  │ #readFloatArray()   │                                                        │
│  │ #readDoubleArray()  │                                                        │
│  └─────────────────────┘                                                        │
│           △                                                                     │
│           │                                                                     │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐     │
│  │  MDF4DataSerializer │  │  CSVDataSerializer  │  │ HDF5DataSerializer  │     │
│  │   (MDF4序列化器)     │  │   (CSV序列化器)      │  │   (HDF5序列化器)     │     │
│  ├─────────────────────┤  ├─────────────────────┤  ├─────────────────────┤     │
│  │ +serialize()        │  │ +serialize()        │  │ +serialize()        │     │
│  │ +deserialize()      │  │ +deserialize()      │  │ +deserialize()      │     │
│  │ +getFormatName()    │  │ +getFormatName()    │  │ +getFormatName()    │     │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘     │
│                                                                                 │
│  ┌─────────────────────┐  ┌─────────────────────┐                               │
│  │  JSONDataSerializer │  │  SerializerFactory  │                               │
│  │   (JSON序列化器)     │  │   (序列化器工厂)     │                               │
│  ├─────────────────────┤  ├─────────────────────┤                               │
│  │ +serialize()        │  │ +createSerializer() │                               │
│  │ +deserialize()      │  │                     │                               │
│  │ +getFormatName()    │  │                     │                               │
│  └─────────────────────┘  └─────────────────────┘                               │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 6. 完整系统类图

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    完整系统架构                                              │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────────────────────┐  │
│   │                              应用层 (Application Layer)                              │  │
│   │  ┌───────────────────────────────────────────────────────────────────────────────┐ │  │
│   │  │                         DataObserverImpl (外观模式)                            │ │  │
│   │  │  -sources: Map<String, ObservableSource>                                       │ │  │
│   │  │  -collector: DataCollector                                                     │ │  │
│   │  │  -buffer: DataBuffer                                                           │ │  │
│   │  │  -storage: DataStorage                                                         │ │  │
│   │  │  -state: ObserverState                                                         │ │  │
│   │  └───────────────────────────────────────────────────────────────────────────────┘ │  │
│   └─────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                              │
│                                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────────────────────┐  │
│   │                              观察层 (Observation Layer)                              │  │
│   │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────────────────┐ │  │
│   │  │FieldObservable│ │MethodObservable│ │SupplierObservable│ │CompositeObservable   │ │  │
│   │  │   Source     │  │   Source     │  │   Source     │  │      Source             │ │  │
│   │  └──────────────┘  └──────────────┘  └──────────────┘  └─────────────────────────┘ │  │
│   └─────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                              │
│                                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────────────────────┐  │
│   │                              收集层 (Collection Layer)                               │  │
│   │  ┌─────────────────────────────────┐  ┌─────────────────────────────────────────┐   │  │
│   │  │     DataCollectorImpl           │  │           RingBuffer                    │   │  │
│   │  │  (批量收集 + 定时刷新)            │  │      (无锁环形缓冲区)                    │   │  │
│   │  │  -batchSize: int                │  │  -writeSequence: AtomicLong             │   │  │
│   │  │  -batchBuffer: DataSample[]     │  │  -readSequence: AtomicLong              │   │  │
│   │  │  -flushIntervalMs: int          │  │  -buffer: DataSample[]                  │   │  │
│   │  └─────────────────────────────────┘  └─────────────────────────────────────────┘   │  │
│   └─────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                              │
│                                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────────────────────┐  │
│   │                              存储层 (Storage Layer)                                  │  │
│   │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────────────────┐ │  │
│   │  │ MDF4Storage  │  │  CSVStorage  │  │ HDF5Storage  │  │  (可扩展其他格式)        │ │  │
│   │  │  (二进制)     │  │  (文本)       │  │  (层次化)     │  │                         │ │  │
│   │  └──────────────┘  └──────────────┘  └──────────────┘  └─────────────────────────┘ │  │
│   └─────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 7. 设计模式汇总

| 设计模式 | 应用位置 | 用途 |
|----------|----------|------|
| **观察者模式** | ObservableSource + DataChangeListener | 数据源变化通知 |
| **生产者-消费者模式** | DataCollector + RingBuffer + DataStorage | 异步数据流转 |
| **策略模式** | DataStorage / DataSerializer | 支持多种存储/序列化格式 |
| **模板方法模式** | AbstractDataStorage | 定义存储流程骨架 |
| **外观模式** | DataObserverImpl | 简化系统使用接口 |
| **对象池模式** | DataSampleImpl | 复用数据样本对象 |
| **工厂模式** | StorageFactory / SerializerFactory | 创建存储/序列化器实例 |
| **构建器模式** | ObserverConfig / SourceMetadataImpl | 复杂对象构建 |
| **代理模式** | ProxyObservableSource | 数据源转换和增强 |
| **组合模式** | CompositeObservableSource | 组合多个数据源 |

