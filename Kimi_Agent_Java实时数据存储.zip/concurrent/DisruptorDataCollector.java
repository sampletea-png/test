package com.observer.concurrent;

import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;

import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 基于LMAX Disruptor的数据收集器
 * 
 * 这是使用Disruptor库的替代实现，提供更专业的无锁队列实现
 * 
 * 需要添加依赖：
 * <dependency>
 *     <groupId>com.lmax</groupId>
 *     <artifactId>disruptor</artifactId>
 *     <version>4.0.0</version>
 * </dependency>
 */
public class DisruptorDataCollector implements AutoCloseable {
    
    // RingBuffer大小（必须是2的幂次方）
    private static final int BUFFER_SIZE = 65536;
    
    // Disruptor实例
    private final Disruptor<DisruptorEvent> disruptor;
    
    // RingBuffer
    private final RingBuffer<DisruptorEvent> ringBuffer;
    
    // 事件处理器
    private final DisruptorEventHandler eventHandler;
    
    // 异步存储
    private final AsyncFileStorage fileStorage;
    
    // 运行标志
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    // 发布计数
    private final AtomicLong publishCount = new AtomicLong(0);
    
    // 丢弃计数
    private final AtomicLong dropCount = new AtomicLong(0);
    
    // 等待策略
    private volatile WaitStrategy waitStrategy = new BlockingWaitStrategy();
    
    public DisruptorDataCollector(String storagePath) throws Exception {
        this(storagePath, BUFFER_SIZE);
    }
    
    public DisruptorDataCollector(String storagePath, int bufferSize) throws Exception {
        // 创建线程工厂
        ThreadFactory threadFactory = r -> {
            Thread t = new Thread(r, "Disruptor-Worker");
            t.setDaemon(true);
            return t;
        };
        
        // 创建事件工厂
        DisruptorEventFactory eventFactory = new DisruptorEventFactory();
        
        // 创建Disruptor
        this.disruptor = new Disruptor<>(
                eventFactory,
                bufferSize,
                threadFactory,
                ProducerType.MULTI,  // 多生产者
                waitStrategy
        );
        
        // 创建事件处理器
        this.eventHandler = new DisruptorEventHandler();
        
        // 设置事件处理器
        disruptor.handleEventsWith(eventHandler);
        
        // 获取RingBuffer
        this.ringBuffer = disruptor.getRingBuffer();
        
        // 创建异步存储
        this.fileStorage = new AsyncFileStorage(storagePath);
        
        // 添加存储处理器
        eventHandler.addStorageHandler(fileStorage);
    }
    
    /**
     * 启动收集器
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            // 启动Disruptor
            disruptor.start();
            
            // 启动文件存储
            fileStorage.start();
            
            System.out.println("DisruptorDataCollector started");
        }
    }
    
    /**
     * 停止收集器
     */
    public void stop() {
        if (running.compareAndSet(true, false)) {
            // 停止Disruptor
            disruptor.shutdown();
            
            // 停止文件存储
            fileStorage.stop();
            
            System.out.println("DisruptorDataCollector stopped");
        }
    }
    
    @Override
    public void close() {
        stop();
    }
    
    /**
     * 发布数据点（使用Translator）
     */
    public boolean publish(DataPoint dataPoint) {
        if (!running.get() || dataPoint == null) {
            return false;
        }
        
        try {
            // 使用EventTranslator发布事件
            ringBuffer.publishEvent(EVENT_TRANSLATOR, dataPoint);
            publishCount.incrementAndGet();
            return true;
        } catch (InsufficientCapacityException e) {
            dropCount.incrementAndGet();
            return false;
        }
    }
    
    /**
     * 发布数据点（使用Lambda）
     */
    public boolean publishWithLambda(DataPoint dataPoint) {
        if (!running.get() || dataPoint == null) {
            return false;
        }
        
        ringBuffer.publishEvent((event, sequence, dp) -> {
            event.setDataPoint(dp);
            event.setTimestamp(System.currentTimeMillis());
        }, dataPoint);
        
        publishCount.incrementAndGet();
        return true;
    }
    
    /**
     * 批量发布
     */
    public int publishBatch(DataPoint[] dataPoints, int offset, int count) {
        if (!running.get() || dataPoints == null) {
            return 0;
        }
        
        int published = 0;
        for (int i = 0; i < count; i++) {
            if (publish(dataPoints[offset + i])) {
                published++;
            }
        }
        return published;
    }
    
    /**
     * 设置等待策略
     */
    public void setWaitStrategy(WaitStrategy strategy) {
        this.waitStrategy = strategy;
    }
    
    /**
     * 获取发布计数
     */
    public long getPublishCount() {
        return publishCount.get();
    }
    
    /**
     * 获取丢弃计数
     */
    public long getDropCount() {
        return dropCount.get();
    }
    
    /**
     * 获取RingBuffer剩余容量
     */
    public long getRemainingCapacity() {
        return ringBuffer.getRemainingCapacity();
    }
    
    /**
     * 获取统计信息
     */
    public String getStatistics() {
        return String.format(
                "DisruptorDataCollector{published=%d, dropped=%d, remaining=%d, cursor=%d}",
                getPublishCount(), getDropCount(), getRemainingCapacity(), 
                ringBuffer.getCursor());
    }
    
    // EventTranslator实例
    private static final EventTranslatorOneArg<DisruptorEvent, DataPoint> EVENT_TRANSLATOR = 
            (event, sequence, dataPoint) -> {
                event.setDataPoint(dataPoint);
                event.setTimestamp(System.currentTimeMillis());
            };
    
    /**
     * Disruptor事件类
     */
    public static class DisruptorEvent {
        private DataPoint dataPoint;
        private long timestamp;
        private long sequence;
        
        public DataPoint getDataPoint() {
            return dataPoint;
        }
        
        public void setDataPoint(DataPoint dataPoint) {
            this.dataPoint = dataPoint;
        }
        
        public long getTimestamp() {
            return timestamp;
        }
        
        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }
        
        public long getSequence() {
            return sequence;
        }
        
        public void setSequence(long sequence) {
            this.sequence = sequence;
        }
        
        public void reset() {
            this.dataPoint = null;
            this.timestamp = 0;
            this.sequence = -1;
        }
    }
    
    /**
     * Disruptor事件工厂
     */
    public static class DisruptorEventFactory implements EventFactory<DisruptorEvent> {
        @Override
        public DisruptorEvent newInstance() {
            return new DisruptorEvent();
        }
    }
    
    /**
     * Disruptor事件处理器
     */
    public static class DisruptorEventHandler implements EventHandler<DisruptorEvent> {
        
        // 批量缓存
        private final java.util.List<DisruptorEvent> batchBuffer = new java.util.ArrayList<>(100);
        
        // 存储处理器列表
        private final CopyOnWriteArrayList<StorageHandler> storageHandlers = 
                new CopyOnWriteArrayList<>();
        
        // 处理计数
        private final AtomicLong processCount = new AtomicLong(0);
        
        @Override
        public void onEvent(DisruptorEvent event, long sequence, boolean endOfBatch) {
            // 添加到批处理缓存
            batchBuffer.add(event);
            
            // 如果是批处理结束或缓存已满，处理批量数据
            if (endOfBatch || batchBuffer.size() >= 100) {
                processBatch();
            }
            
            processCount.incrementAndGet();
        }
        
        /**
         * 处理批量数据
         */
        private void processBatch() {
            if (batchBuffer.isEmpty()) {
                return;
            }
            
            // 通知所有存储处理器
            for (StorageHandler handler : storageHandlers) {
                try {
                    handler.handleDisruptorBatch(batchBuffer);
                } catch (Exception e) {
                    System.err.println("Storage handler error: " + e.getMessage());
                }
            }
            
            // 清空缓存
            batchBuffer.clear();
        }
        
        /**
         * 添加存储处理器
         */
        public void addStorageHandler(StorageHandler handler) {
            storageHandlers.add(handler);
        }
        
        /**
         * 获取处理计数
         */
        public long getProcessCount() {
            return processCount.get();
        }
        
        /**
         * 存储处理器接口
         */
        public interface StorageHandler {
            void handleDisruptorBatch(java.util.List<DisruptorEvent> batch) throws Exception;
        }
    }
    
    /**
     * 适配AsyncFileStorage到Disruptor
     */
    public static class DisruptorStorageAdapter implements DisruptorEventHandler.StorageHandler {
        
        private final AsyncFileStorage fileStorage;
        
        public DisruptorStorageAdapter(AsyncFileStorage fileStorage) {
            this.fileStorage = fileStorage;
        }
        
        @Override
        public void handleDisruptorBatch(java.util.List<DisruptorEvent> batch) throws Exception {
            // 转换为DataEvent列表
            java.util.List<DataEvent> dataEvents = new java.util.ArrayList<>(batch.size());
            for (DisruptorEvent event : batch) {
                DataEvent dataEvent = new DataEvent();
                dataEvent.setDataPoint(event.getDataPoint());
                dataEvents.add(dataEvent);
            }
            
            // 调用原有的存储处理器
            fileStorage.handleBatch(dataEvents);
        }
    }
}
