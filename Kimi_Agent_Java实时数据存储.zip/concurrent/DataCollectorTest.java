package com.observer.concurrent;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据收集器测试类
 * 演示高并发场景下的使用
 */
public class DataCollectorTest {
    
    public static void main(String[] args) throws Exception {
        System.out.println("========== DataCollector Test ==========");
        
        // 创建数据收集器
        DataCollector collector = new DataCollector("./data", 65536);
        
        // 注册系统指标观察点
        registerSystemObservers(collector);
        
        // 注册业务指标观察点
        registerBusinessObservers(collector);
        
        // 启动收集器
        collector.start();
        
        // 运行并发测试
        runConcurrentTest(collector);
        
        // 运行一段时间后停止
        Thread.sleep(30000);
        
        // 打印最终统计
        System.out.println("\n========== Final Statistics ==========");
        System.out.println(collector.getStatistics());
        
        // 停止收集器
        collector.stop();
        
        System.out.println("========== Test Completed ==========");
    }
    
    /**
     * 注册系统指标观察点
     */
    private static void registerSystemObservers(DataCollector collector) {
        // CPU使用率
        collector.registerObserver(MetricObserver.cpuUsageObserver());
        
        // 内存使用
        collector.registerObserver(MetricObserver.memoryUsageObserver());
        
        // GC次数
        collector.registerObserver(MetricObserver.gcCountObserver());
        
        // 线程数
        collector.registerObserver(MetricObserver.threadCountObserver());
        
        System.out.println("System observers registered");
    }
    
    /**
     * 注册业务指标观察点
     */
    private static void registerBusinessObservers(DataCollector collector) {
        // 请求数观察点
        MetricObserver requestObserver = new MetricObserver(
                "business.request.count",
                "请求数",
                DataPoint.DataType.METRIC,
                1000,
                () -> requestCounter.get()
        );
        collector.registerObserver(requestObserver);
        
        // 响应时间观察点
        MetricObserver responseTimeObserver = new MetricObserver(
                "business.response.time",
                "响应时间",
                DataPoint.DataType.METRIC,
                1000,
                () -> responseTimeCounter.get()
        );
        collector.registerObserver(responseTimeObserver);
        
        // 错误数观察点
        MetricObserver errorObserver = new MetricObserver(
                "business.error.count",
                "错误数",
                DataPoint.DataType.METRIC,
                1000,
                () -> errorCounter.get()
        );
        collector.registerObserver(errorObserver);
        
        System.out.println("Business observers registered");
    }
    
    // 业务计数器
    private static final AtomicLong requestCounter = new AtomicLong(0);
    private static final AtomicLong responseTimeCounter = new AtomicLong(0);
    private static final AtomicLong errorCounter = new AtomicLong(0);
    
    /**
     * 运行并发测试
     */
    private static void runConcurrentTest(DataCollector collector) {
        int producerCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(producerCount);
        
        for (int i = 0; i < producerCount; i++) {
            final int producerId = i;
            executor.submit(() -> {
                try {
                    runProducer(collector, producerId);
                } catch (Exception e) {
                    System.err.println("Producer error: " + e.getMessage());
                }
            });
        }
        
        executor.shutdown();
    }
    
    /**
     * 运行生产者
     */
    private static void runProducer(DataCollector collector, int producerId) {
        for (int i = 0; i < 10000; i++) {
            // 模拟业务数据采集
            simulateBusinessMetrics();
            
            // 创建数据点
            DataPoint dataPoint = new DataPoint(
                    "producer." + producerId,
                    "data_" + i,
                    DataPoint.DataType.EVENT
            );
            dataPoint.addTag("producer_id", String.valueOf(producerId));
            dataPoint.addTag("sequence", String.valueOf(i));
            
            // 采集数据
            collector.collect(dataPoint);
            
            // 模拟业务处理延迟
            if (i % 100 == 0) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        
        System.out.println("Producer " + producerId + " completed");
    }
    
    /**
     * 模拟业务指标
     */
    private static void simulateBusinessMetrics() {
        requestCounter.incrementAndGet();
        responseTimeCounter.addAndGet((long) (Math.random() * 100));
        if (Math.random() < 0.01) {
            errorCounter.incrementAndGet();
        }
    }
}
