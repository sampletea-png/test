package com.observer.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据事件处理器（消费者）
 * 负责从RingBuffer消费数据并批量处理
 * 
 * 设计特点：
 * 1. 批量消费，减少系统调用
 * 2. 异步处理，不阻塞生产者
 * 3. 支持背压处理
 * 4. 可配置的刷盘策略
 */
public class DataEventHandler implements Runnable {
    
    // 默认批量大小
    private static final int DEFAULT_BATCH_SIZE = 100;
    
    // 默认刷盘间隔（毫秒）
    private static final long DEFAULT_FLUSH_INTERVAL = 1000;
    
    // 数据缓冲区
    private final RingBuffer<DataEvent> ringBuffer;
    
    // 事件工厂
    private final DataEventFactory eventFactory;
    
    // 批处理大小
    private final int batchSize;
    
    // 刷盘间隔
    private final long flushInterval;
    
    // 处理线程
    private final ExecutorService executor;
    
    // 运行标志
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    // 处理的数据计数
    private final AtomicLong processedCount = new AtomicLong(0);
    
    // 处理的数据字节数
    private final AtomicLong processedBytes = new AtomicLong(0);
    
    // 最后一次刷盘时间
    private volatile long lastFlushTime = System.currentTimeMillis();
    
    // 批量数据缓存
    private final List<DataEvent> batchBuffer;
    
    // 存储处理器列表
    private final List<StorageHandler> storageHandlers = new CopyOnWriteArrayList<>();
    
    // 背压策略
    private volatile BackPressureStrategy backPressureStrategy = BackPressureStrategy.DROP;
    
    // 背压阈值
    private volatile double backPressureThreshold = 0.8;
    
    // 处理延迟统计（纳秒）
    private final AtomicLong totalProcessTime = new AtomicLong(0);
    
    public DataEventHandler(RingBuffer<DataEvent> ringBuffer, DataEventFactory eventFactory) {
        this(ringBuffer, eventFactory, DEFAULT_BATCH_SIZE, DEFAULT_FLUSH_INTERVAL);
    }
    
    public DataEventHandler(RingBuffer<DataEvent> ringBuffer, 
                           DataEventFactory eventFactory,
                           int batchSize, 
                           long flushInterval) {
        this.ringBuffer = ringBuffer;
        this.eventFactory = eventFactory;
        this.batchSize = batchSize;
        this.flushInterval = flushInterval;
        this.batchBuffer = new ArrayList<>(batchSize);
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "DataEventHandler");
            t.setDaemon(true);
            return t;
        });
    }
    
    /**
     * 启动处理器
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            executor.submit(this);
        }
    }
    
    /**
     * 停止处理器
     */
    public void stop() {
        if (running.compareAndSet(true, false)) {
            // 刷出剩余数据
            flushBatch();
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
    
    @Override
    public void run() {
        DataEvent[] events = new DataEvent[batchSize];
        
        while (running.get()) {
            try {
                // 批量读取数据
                int count = ringBuffer.readBatch(events, 0, batchSize);
                
                if (count > 0) {
                    long startTime = System.nanoTime();
                    
                    // 处理批量数据
                    for (int i = 0; i < count; i++) {
                        DataEvent event = events[i];
                        if (event != null) {
                            processEvent(event);
                            
                            // 回收事件对象
                            eventFactory.recycleEvent(event);
                        }
                    }
                    
                    // 更新统计
                    processedCount.addAndGet(count);
                    totalProcessTime.addAndGet(System.nanoTime() - startTime);
                    
                    // 检查是否需要刷盘
                    checkFlush();
                } else {
                    // 没有数据，短暂休眠
                    Thread.sleep(1);
                }
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                // 记录错误但继续处理
                System.err.println("Error processing events: " + e.getMessage());
            }
        }
    }
    
    /**
     * 处理单个事件
     */
    private void processEvent(DataEvent event) {
        DataPoint dataPoint = event.getDataPoint();
        if (dataPoint == null) {
            return;
        }
        
        // 添加到批处理缓存
        batchBuffer.add(event);
        
        // 更新字节数统计
        String csv = dataPoint.toCsvString();
        processedBytes.addAndGet(csv.length());
        
        // 如果达到批处理大小，执行刷盘
        if (batchBuffer.size() >= batchSize) {
            flushBatch();
        }
    }
    
    /**
     * 检查是否需要刷盘
     */
    private void checkFlush() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFlushTime >= flushInterval) {
            flushBatch();
            lastFlushTime = currentTime;
        }
    }
    
    /**
     * 刷出批量数据
     */
    private void flushBatch() {
        if (batchBuffer.isEmpty()) {
            return;
        }
        
        try {
            // 复制批量数据
            List<DataEvent> batch = new ArrayList<>(batchBuffer);
            batchBuffer.clear();
            
            // 通知所有存储处理器
            for (StorageHandler handler : storageHandlers) {
                try {
                    handler.handleBatch(batch);
                } catch (Exception e) {
                    System.err.println("Storage handler error: " + e.getMessage());
                }
            }
            
        } catch (Exception e) {
            System.err.println("Flush batch error: " + e.getMessage());
        }
    }
    
    /**
     * 添加存储处理器
     */
    public void addStorageHandler(StorageHandler handler) {
        storageHandlers.add(handler);
    }
    
    /**
     * 移除存储处理器
     */
    public void removeStorageHandler(StorageHandler handler) {
        storageHandlers.remove(handler);
    }
    
    /**
     * 设置背压策略
     */
    public void setBackPressureStrategy(BackPressureStrategy strategy) {
        this.backPressureStrategy = strategy;
    }
    
    /**
     * 设置背压阈值
     */
    public void setBackPressureThreshold(double threshold) {
        this.backPressureThreshold = threshold;
    }
    
    /**
     * 检查背压状态
     */
    public boolean isBackPressure() {
        double usage = (double) ringBuffer.availableToRead() / ringBuffer.getBufferSize();
        return usage >= backPressureThreshold;
    }
    
    /**
     * 获取已处理数据计数
     */
    public long getProcessedCount() {
        return processedCount.get();
    }
    
    /**
     * 获取已处理字节数
     */
    public long getProcessedBytes() {
        return processedBytes.get();
    }
    
    /**
     * 获取平均处理延迟（微秒）
     */
    public double getAverageProcessLatency() {
        long count = processedCount.get();
        if (count == 0) {
            return 0;
        }
        return (double) totalProcessTime.get() / count / 1000.0;
    }
    
    /**
     * 获取处理器统计信息
     */
    public String getStatistics() {
        return String.format(
                "DataEventHandler{processed=%d, bytes=%d, avgLatency=%.2fus, handlers=%d}",
                getProcessedCount(), getProcessedBytes(), getAverageProcessLatency(), 
                storageHandlers.size());
    }
    
    /**
     * 存储处理器接口
     */
    public interface StorageHandler {
        void handleBatch(List<DataEvent> batch) throws Exception;
    }
}
