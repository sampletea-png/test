package com.observer.concurrent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

/**
 * 指标观察点实现
 * 用于采集各种性能指标
 */
public class MetricObserver implements DataObserver {
    
    private final String name;
    private final String description;
    private final DataType dataType;
    private final long sampleIntervalMs;
    private final Supplier<Object> valueSupplier;
    
    private volatile boolean enabled = true;
    private final Map<String, String> tags = new ConcurrentHashMap<>();
    
    // 采集计数
    private final AtomicLong collectCount = new AtomicLong(0);
    
    public MetricObserver(String name, 
                         String description,
                         DataType dataType,
                         long sampleIntervalMs,
                         Supplier<Object> valueSupplier) {
        this.name = name;
        this.description = description;
        this.dataType = dataType;
        this.sampleIntervalMs = sampleIntervalMs;
        this.valueSupplier = valueSupplier;
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public String getDescription() {
        return description;
    }
    
    @Override
    public DataPoint collect() {
        if (!enabled || valueSupplier == null) {
            return null;
        }
        
        try {
            Object value = valueSupplier.get();
            if (value == null) {
                return null;
            }
            
            DataPoint dataPoint = new DataPoint(name, value, dataType);
            
            // 添加标签
            for (Map.Entry<String, String> entry : tags.entrySet()) {
                dataPoint.addTag(entry.getKey(), entry.getValue());
            }
            
            collectCount.incrementAndGet();
            return dataPoint;
            
        } catch (Exception e) {
            System.err.println("Collect metric error: " + e.getMessage());
            return null;
        }
    }
    
    @Override
    public DataType getDataType() {
        return dataType;
    }
    
    @Override
    public long getSampleIntervalMs() {
        return sampleIntervalMs;
    }
    
    @Override
    public boolean isEnabled() {
        return enabled;
    }
    
    @Override
    public void enable() {
        this.enabled = true;
    }
    
    @Override
    public void disable() {
        this.enabled = false;
    }
    
    @Override
    public Map<String, String> getTags() {
        return new ConcurrentHashMap<>(tags);
    }
    
    @Override
    public void addTag(String key, String value) {
        tags.put(key, value);
    }
    
    @Override
    public void removeTag(String key) {
        tags.remove(key);
    }
    
    /**
     * 获取采集计数
     */
    public long getCollectCount() {
        return collectCount.get();
    }
    
    /**
     * 创建CPU使用率观察点
     */
    public static MetricObserver cpuUsageObserver() {
        return new MetricObserver(
                "cpu.usage",
                "CPU使用率",
                DataType.METRIC,
                1000, // 1秒采样
                () -> {
                    // 这里可以使用更精确的CPU监控
                    return Runtime.getRuntime().availableProcessors();
                }
        );
    }
    
    /**
     * 创建内存使用观察点
     */
    public static MetricObserver memoryUsageObserver() {
        return new MetricObserver(
                "memory.usage",
                "内存使用量",
                DataType.METRIC,
                1000,
                () -> Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        );
    }
    
    /**
     * 创建GC次数观察点
     */
    public static MetricObserver gcCountObserver() {
        return new MetricObserver(
                "gc.count",
                "GC次数",
                DataType.METRIC,
                5000,
                () -> {
                    long count = 0;
                    for (java.lang.management.GarbageCollectorMXBean gcBean : 
                            java.lang.management.ManagementFactory.getGarbageCollectorMXBeans()) {
                        count += gcBean.getCollectionCount();
                    }
                    return count;
                }
        );
    }
    
    /**
     * 创建线程数观察点
     */
    public static MetricObserver threadCountObserver() {
        return new MetricObserver(
                "thread.count",
                "线程数",
                DataType.METRIC,
                1000,
                () -> java.lang.management.ManagementFactory.getThreadMXBean().getThreadCount()
        );
    }
}
