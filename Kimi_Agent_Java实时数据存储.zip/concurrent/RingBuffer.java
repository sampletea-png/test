package com.observer.concurrent;

import sun.misc.Unsafe;
import java.lang.reflect.Field;

/**
 * 无锁环形缓冲区实现
 * 基于Disruptor模式，使用CAS操作保证线程安全
 * 
 * 设计特点：
 * 1. 2的幂次方大小，使用位运算代替取模
 * 2. 序列号使用long类型，避免溢出
 * 3. 缓存行填充，避免伪共享
 * 4. 无锁设计，使用CAS操作
 */
public class RingBuffer<T> {
    
    // 缓存行填充 - 前导填充
    private long p1, p2, p3, p4, p5, p6, p7;
    
    // 缓冲区大小（必须是2的幂次方）
    private final int bufferSize;
    private final int mask;
    
    // 数据数组
    private final Object[] buffer;
    
    // 序列号 - 使用缓存行隔离
    private volatile long writeSequence = -1;
    private volatile long readSequence = -1;
    
    // 缓存行填充 - 后导填充
    private long p8, p9, p10, p11, p12, p13, p14;
    
    // Unsafe实例，用于CAS操作
    private static final Unsafe UNSAFE;
    private static final long WRITE_SEQUENCE_OFFSET;
    private static final long READ_SEQUENCE_OFFSET;
    
    static {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            UNSAFE = (Unsafe) field.get(null);
            WRITE_SEQUENCE_OFFSET = UNSAFE.objectFieldOffset(
                    RingBuffer.class.getDeclaredField("writeSequence"));
            READ_SEQUENCE_OFFSET = UNSAFE.objectFieldOffset(
                    RingBuffer.class.getDeclaredField("readSequence"));
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Unsafe", e);
        }
    }
    
    public RingBuffer(int bufferSize) {
        // 确保bufferSize是2的幂次方
        if (bufferSize < 1 || (bufferSize & (bufferSize - 1)) != 0) {
            throw new IllegalArgumentException("Buffer size must be power of 2");
        }
        this.bufferSize = bufferSize;
        this.mask = bufferSize - 1;
        this.buffer = new Object[bufferSize];
    }
    
    /**
     * 获取下一个写入位置
     * 非阻塞，如果缓冲区满返回-1
     */
    public long tryNextWrite() {
        long currentWrite = writeSequence;
        long nextWrite = currentWrite + 1;
        
        // 检查是否已满（环形缓冲区判断）
        long wrapPoint = nextWrite - bufferSize;
        if (wrapPoint > readSequence) {
            return -1; // 缓冲区满
        }
        
        // CAS操作尝试获取写入位置
        if (UNSAFE.compareAndSwapLong(this, WRITE_SEQUENCE_OFFSET, currentWrite, nextWrite)) {
            return nextWrite;
        }
        return -1; // CAS失败
    }
    
    /**
     * 获取下一个写入位置（自旋等待）
     */
    public long nextWrite() {
        long sequence;
        while ((sequence = tryNextWrite()) < 0) {
            // 自旋等待，可添加Thread.yield()或LockSupport.parkNanos()
            Thread.yield();
        }
        return sequence;
    }
    
    /**
     * 写入数据到指定位置
     */
    public void write(long sequence, T data) {
        buffer[(int) (sequence & mask)] = data;
        // 内存屏障，确保数据可见性
        UNSAFE.storeFence();
    }
    
    /**
     * 尝试写入数据（完整操作）
     */
    public boolean tryWrite(T data) {
        long sequence = tryNextWrite();
        if (sequence < 0) {
            return false;
        }
        write(sequence, data);
        return true;
    }
    
    /**
     * 写入数据（可能阻塞）
     */
    public void write(T data) {
        long sequence = nextWrite();
        write(sequence, data);
    }
    
    /**
     * 批量写入
     */
    public int writeBatch(T[] dataArray, int offset, int count) {
        int written = 0;
        for (int i = 0; i < count; i++) {
            if (!tryWrite(dataArray[offset + i])) {
                break;
            }
            written++;
        }
        return written;
    }
    
    /**
     * 获取下一个读取位置
     */
    public long tryNextRead() {
        long currentRead = readSequence;
        long nextRead = currentRead + 1;
        
        // 检查是否有数据可读
        if (nextRead > writeSequence) {
            return -1; // 没有数据
        }
        
        // CAS操作尝试获取读取位置
        if (UNSAFE.compareAndSwapLong(this, READ_SEQUENCE_OFFSET, currentRead, nextRead)) {
            return nextRead;
        }
        return -1;
    }
    
    /**
     * 获取下一个读取位置（自旋等待）
     */
    public long nextRead() {
        long sequence;
        while ((sequence = tryNextRead()) < 0) {
            Thread.yield();
        }
        return sequence;
    }
    
    /**
     * 读取指定位置的数据
     */
    @SuppressWarnings("unchecked")
    public T read(long sequence) {
        // 内存屏障，确保读取最新值
        UNSAFE.loadFence();
        return (T) buffer[(int) (sequence & mask)];
    }
    
    /**
     * 批量读取
     */
    @SuppressWarnings("unchecked")
    public int readBatch(T[] output, int offset, int maxCount) {
        int read = 0;
        long currentRead = readSequence;
        
        for (int i = 0; i < maxCount; i++) {
            long nextRead = currentRead + 1;
            if (nextRead > writeSequence) {
                break; // 没有更多数据
            }
            
            if (UNSAFE.compareAndSwapLong(this, READ_SEQUENCE_OFFSET, currentRead, nextRead)) {
                output[offset + read] = (T) buffer[(int) (nextRead & mask)];
                read++;
                currentRead = nextRead;
            } else {
                break; // CAS失败，停止批量读取
            }
        }
        return read;
    }
    
    /**
     * 获取当前可读取的数据数量
     */
    public long availableToRead() {
        return writeSequence - readSequence;
    }
    
    /**
     * 获取当前可写入的空间数量
     */
    public long availableToWrite() {
        return bufferSize - (writeSequence - readSequence);
    }
    
    /**
     * 检查缓冲区是否已满
     */
    public boolean isFull() {
        return availableToWrite() == 0;
    }
    
    /**
     * 检查缓冲区是否为空
     */
    public boolean isEmpty() {
        return availableToRead() == 0;
    }
    
    /**
     * 获取缓冲区大小
     */
    public int getBufferSize() {
        return bufferSize;
    }
    
    /**
     * 清空缓冲区
     */
    public void clear() {
        writeSequence = -1;
        readSequence = -1;
        for (int i = 0; i < bufferSize; i++) {
            buffer[i] = null;
        }
    }
}
