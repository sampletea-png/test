package com.observer.concurrent;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据事件工厂
 * 负责创建和管理DataEvent对象池
 * 减少GC压力，提高性能
 */
public class DataEventFactory {
    
    // 默认对象池大小
    private static final int DEFAULT_POOL_SIZE = 1024;
    
    // 对象池
    private final BlockingQueue<DataEvent> eventPool;
    
    // 对象池大小
    private final int poolSize;
    
    // 已创建对象计数
    private final AtomicLong createdCount = new AtomicLong(0);
    
    // 已复用对象计数
    private final AtomicLong recycledCount = new AtomicLong(0);
    
    // 对象池命中率
    private volatile double hitRate = 1.0;
    
    public DataEventFactory() {
        this(DEFAULT_POOL_SIZE);
    }
    
    public DataEventFactory(int poolSize) {
        this.poolSize = poolSize;
        this.eventPool = new ArrayBlockingQueue<>(poolSize);
        
        // 预创建对象
        for (int i = 0; i < poolSize / 2; i++) {
            eventPool.offer(new DataEvent());
            createdCount.incrementAndGet();
        }
    }
    
    /**
     * 获取一个DataEvent对象
     * 优先从对象池获取，池空则创建新对象
     */
    public DataEvent getEvent() {
        DataEvent event = eventPool.poll();
        if (event != null) {
            recycledCount.incrementAndGet();
            event.reset();
            return event;
        }
        
        // 池空，创建新对象
        createdCount.incrementAndGet();
        return new DataEvent();
    }
    
    /**
     * 批量获取DataEvent对象
     */
    public int getEvents(DataEvent[] events, int offset, int count) {
        int obtained = 0;
        for (int i = 0; i < count; i++) {
            DataEvent event = eventPool.poll();
            if (event != null) {
                event.reset();
                events[offset + i] = event;
                obtained++;
            } else {
                break;
            }
        }
        
        // 更新统计
        recycledCount.addAndGet(obtained);
        createdCount.addAndGet(count - obtained);
        
        // 补充创建不足的对象
        for (int i = obtained; i < count; i++) {
            events[offset + i] = new DataEvent();
        }
        
        return count;
    }
    
    /**
     * 回收DataEvent对象
     */
    public void recycleEvent(DataEvent event) {
        if (event == null) {
            return;
        }
        event.reset();
        eventPool.offer(event); // 非阻塞，失败则丢弃
    }
    
    /**
     * 批量回收DataEvent对象
     */
    public void recycleEvents(DataEvent[] events, int offset, int count) {
        for (int i = 0; i < count; i++) {
            DataEvent event = events[offset + i];
            if (event != null) {
                event.reset();
                eventPool.offer(event);
            }
        }
    }
    
    /**
     * 获取对象池大小
     */
    public int getPoolSize() {
        return poolSize;
    }
    
    /**
     * 获取当前池内对象数量
     */
    public int getAvailableCount() {
        return eventPool.size();
    }
    
    /**
     * 获取已创建对象总数
     */
    public long getCreatedCount() {
        return createdCount.get();
    }
    
    /**
     * 获取已复用对象总数
     */
    public long getRecycledCount() {
        return recycledCount.get();
    }
    
    /**
     * 获取对象池命中率
     */
    public double getHitRate() {
        long total = createdCount.get();
        if (total == 0) {
            return 1.0;
        }
        return (double) recycledCount.get() / total;
    }
    
    /**
     * 清空对象池
     */
    public void clear() {
        eventPool.clear();
        createdCount.set(0);
        recycledCount.set(0);
    }
    
    /**
     * 获取工厂统计信息
     */
    public String getStatistics() {
        return String.format(
                "DataEventFactory{poolSize=%d, available=%d, created=%d, recycled=%d, hitRate=%.2f%%}",
                poolSize, getAvailableCount(), getCreatedCount(), getRecycledCount(), getHitRate() * 100);
    }
}
