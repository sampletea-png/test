package com.observer.concurrent;

/**
 * 背压处理策略枚举
 * 
 * 背压问题：当生产者速度超过消费者速度时，缓冲区会填满，
 * 需要策略来处理这种情况。
 */
public enum BackPressureStrategy {
    
    /**
     * 丢弃策略
     * 当缓冲区满时，直接丢弃新数据
     * 适用场景：允许数据丢失，追求最低延迟
     */
    DROP,
    
    /**
     * 重试策略
     * 当缓冲区满时，短暂等待后重试
     * 适用场景：短暂的压力峰值，可接受轻微延迟
     */
    RETRY,
    
    /**
     * 阻塞策略
     * 当缓冲区满时，自旋等待直到有空间
     * 适用场景：不允许数据丢失，可接受阻塞
     */
    BLOCK,
    
    /**
     * 让出策略
     * 当缓冲区满时，让出CPU时间片后重试
     * 适用场景：多生产者环境，需要平衡性能
     */
    YIELD,
    
    /**
     * 采样策略
     * 当缓冲区满时，降低采样率
     * 适用场景：指标采集，可接受降低精度
     */
    SAMPLE,
    
    /**
     * 溢出策略
     * 当缓冲区满时，写入溢出缓冲区
     * 适用场景：需要保留所有数据，可接受额外内存
     */
    OVERFLOW;
    
    /**
     * 获取策略描述
     */
    public String getDescription() {
        switch (this) {
            case DROP:
                return "丢弃策略：缓冲区满时直接丢弃新数据，追求最低延迟";
            case RETRY:
                return "重试策略：缓冲区满时短暂等待后重试，适用于短暂压力峰值";
            case BLOCK:
                return "阻塞策略：缓冲区满时自旋等待，确保数据不丢失";
            case YIELD:
                return "让出策略：缓冲区满时让出CPU后重试，平衡多生产者性能";
            case SAMPLE:
                return "采样策略：缓冲区满时降低采样率，适用于指标采集";
            case OVERFLOW:
                return "溢出策略：缓冲区满时写入溢出缓冲区，保留所有数据";
            default:
                return "未知策略";
        }
    }
    
    /**
     * 是否可能丢失数据
     */
    public boolean mayLoseData() {
        return this == DROP || this == SAMPLE;
    }
    
    /**
     * 是否可能阻塞
     */
    public boolean mayBlock() {
        return this == BLOCK || this == RETRY || this == YIELD;
    }
    
    /**
     * 是否需要额外内存
     */
    public boolean needExtraMemory() {
        return this == OVERFLOW;
    }
}
