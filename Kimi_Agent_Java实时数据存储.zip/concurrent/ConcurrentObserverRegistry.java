package com.observer.concurrent;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.StampedLock;

/**
 * 线程安全的观察点注册表
 * 
 * 设计特点：
 * 1. 使用ConcurrentHashMap保证线程安全
 * 2. 使用StampedLock优化读多写少场景
 * 3. 支持批量操作
 * 4. 读写分离，提高并发性能
 */
public class ConcurrentObserverRegistry {
    
    // 观察点映射表
    private final ConcurrentHashMap<String, DataObserver> observers = new ConcurrentHashMap<>();
    
    // 按类型分组的观察点
    private final ConcurrentHashMap<DataPoint.DataType, Set<DataObserver>> observersByType = 
            new ConcurrentHashMap<>();
    
    // 读写锁（用于批量操作）
    private final StampedLock lock = new StampedLock();
    
    // 注册计数
    private final AtomicLong registerCount = new AtomicLong(0);
    
    // 注销计数
    private final AtomicLong unregisterCount = new AtomicLong(0);
    
    // 访问计数
    private final AtomicLong accessCount = new AtomicLong(0);
    
    // 监听器列表
    private final CopyOnWriteArrayList<RegistryListener> listeners = new CopyOnWriteArrayList<>();
    
    public ConcurrentObserverRegistry() {
        // 初始化类型分组
        for (DataPoint.DataType type : DataPoint.DataType.values()) {
            observersByType.put(type, ConcurrentHashMap.newKeySet());
        }
    }
    
    /**
     * 注册观察点
     */
    public boolean register(DataObserver observer) {
        if (observer == null || observer.getName() == null) {
            return false;
        }
        
        long stamp = lock.writeLock();
        try {
            String name = observer.getName();
            
            // 检查是否已存在
            if (observers.containsKey(name)) {
                return false;
            }
            
            // 添加到主映射表
            observers.put(name, observer);
            
            // 添加到类型分组
            observersByType.get(observer.getDataType()).add(observer);
            
            registerCount.incrementAndGet();
            
            // 通知监听器
            notifyRegistered(observer);
            
            return true;
            
        } finally {
            lock.unlockWrite(stamp);
        }
    }
    
    /**
     * 注销观察点
     */
    public boolean unregister(String name) {
        if (name == null) {
            return false;
        }
        
        long stamp = lock.writeLock();
        try {
            DataObserver observer = observers.remove(name);
            if (observer == null) {
                return false;
            }
            
            // 从类型分组中移除
            observersByType.get(observer.getDataType()).remove(observer);
            
            unregisterCount.incrementAndGet();
            
            // 通知监听器
            notifyUnregistered(observer);
            
            return true;
            
        } finally {
            lock.unlockWrite(stamp);
        }
    }
    
    /**
     * 获取观察点
     */
    public DataObserver getObserver(String name) {
        accessCount.incrementAndGet();
        
        // 乐观读
        long stamp = lock.tryOptimisticRead();
        DataObserver observer = observers.get(name);
        if (lock.validate(stamp)) {
            return observer;
        }
        
        // 乐观读失败，转为普通读锁
        stamp = lock.readLock();
        try {
            return observers.get(name);
        } finally {
            lock.unlockRead(stamp);
        }
    }
    
    /**
     * 获取所有观察点
     */
    public Collection<DataObserver> getAllObservers() {
        accessCount.incrementAndGet();
        return new ArrayList<>(observers.values());
    }
    
    /**
     * 获取指定类型的观察点
     */
    public Set<DataObserver> getObserversByType(DataPoint.DataType type) {
        accessCount.incrementAndGet();
        return new HashSet<>(observersByType.getOrDefault(type, Collections.emptySet()));
    }
    
    /**
     * 批量注册观察点
     */
    public int registerBatch(Collection<DataObserver> observerList) {
        if (observerList == null || observerList.isEmpty()) {
            return 0;
        }
        
        long stamp = lock.writeLock();
        int count = 0;
        try {
            for (DataObserver observer : observerList) {
                if (observer != null && observer.getName() != null 
                        && !observers.containsKey(observer.getName())) {
                    observers.put(observer.getName(), observer);
                    observersByType.get(observer.getDataType()).add(observer);
                    count++;
                    notifyRegistered(observer);
                }
            }
            registerCount.addAndGet(count);
            return count;
            
        } finally {
            lock.unlockWrite(stamp);
        }
    }
    
    /**
     * 批量注销观察点
     */
    public int unregisterBatch(Collection<String> names) {
        if (names == null || names.isEmpty()) {
            return 0;
        }
        
        long stamp = lock.writeLock();
        int count = 0;
        try {
            for (String name : names) {
                DataObserver observer = observers.remove(name);
                if (observer != null) {
                    observersByType.get(observer.getDataType()).remove(observer);
                    count++;
                    notifyUnregistered(observer);
                }
            }
            unregisterCount.addAndGet(count);
            return count;
            
        } finally {
            lock.unlockWrite(stamp);
        }
    }
    
    /**
     * 检查观察点是否存在
     */
    public boolean contains(String name) {
        accessCount.incrementAndGet();
        return observers.containsKey(name);
    }
    
    /**
     * 获取观察点数量
     */
    public int size() {
        return observers.size();
    }
    
    /**
     * 清空所有观察点
     */
    public void clear() {
        long stamp = lock.writeLock();
        try {
            observers.clear();
            for (Set<DataObserver> set : observersByType.values()) {
                set.clear();
            }
        } finally {
            lock.unlockWrite(stamp);
        }
    }
    
    /**
     * 添加注册表监听器
     */
    public void addListener(RegistryListener listener) {
        listeners.add(listener);
    }
    
    /**
     * 移除注册表监听器
     */
    public void removeListener(RegistryListener listener) {
        listeners.remove(listener);
    }
    
    /**
     * 通知观察点已注册
     */
    private void notifyRegistered(DataObserver observer) {
        for (RegistryListener listener : listeners) {
            try {
                listener.onRegistered(observer);
            } catch (Exception e) {
                // 忽略监听器异常
            }
        }
    }
    
    /**
     * 通知观察点已注销
     */
    private void notifyUnregistered(DataObserver observer) {
        for (RegistryListener listener : listeners) {
            try {
                listener.onUnregistered(observer);
            } catch (Exception e) {
                // 忽略监听器异常
            }
        }
    }
    
    /**
     * 获取注册计数
     */
    public long getRegisterCount() {
        return registerCount.get();
    }
    
    /**
     * 获取注销计数
     */
    public long getUnregisterCount() {
        return unregisterCount.get();
    }
    
    /**
     * 获取访问计数
     */
    public long getAccessCount() {
        return accessCount.get();
    }
    
    /**
     * 获取注册表统计信息
     */
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("ConcurrentObserverRegistry{");
        sb.append("total=").append(size());
        sb.append(", registered=").append(getRegisterCount());
        sb.append(", unregistered=").append(getUnregisterCount());
        sb.append(", accesses=").append(getAccessCount());
        sb.append(", byType={");
        
        for (Map.Entry<DataPoint.DataType, Set<DataObserver>> entry : observersByType.entrySet()) {
            sb.append(entry.getKey()).append("=").append(entry.getValue().size()).append(", ");
        }
        sb.append("}}");
        
        return sb.toString();
    }
    
    /**
     * 注册表监听器接口
     */
    public interface RegistryListener {
        void onRegistered(DataObserver observer);
        void onUnregistered(DataObserver observer);
    }
}
