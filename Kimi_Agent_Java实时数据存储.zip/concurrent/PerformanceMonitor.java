package com.observer.concurrent;

import java.lang.management.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 性能监控器
 * 监控系统性能指标
 */
public class PerformanceMonitor implements Runnable {
    
    // 监控间隔（毫秒）
    private static final long MONITOR_INTERVAL = 1000;
    
    // 监控线程
    private final ScheduledExecutorService monitorExecutor;
    
    // 运行标志
    private volatile boolean running = false;
    
    // CPU使用率
    private volatile double cpuUsage = 0.0;
    
    // 内存使用量（字节）
    private volatile long memoryUsage = 0;
    
    // GC次数
    private final AtomicLong gcCount = new AtomicLong(0);
    
    // GC时间（毫秒）
    private final AtomicLong gcTime = new AtomicLong(0);
    
    // 线程数
    private volatile int threadCount = 0;
    
    // 峰值线程数
    private volatile int peakThreadCount = 0;
    
    // 类加载数
    private volatile long loadedClassCount = 0;
    
    // 上次GC统计
    private long lastGcCount = 0;
    private long lastGcTime = 0;
    
    // 操作系统MXBean
    private final OperatingSystemMXBean osMXBean;
    
    // 内存MXBean
    private final MemoryMXBean memoryMXBean;
    
    // 线程MXBean
    private final ThreadMXBean threadMXBean;
    
    // 类加载MXBean
    private final ClassLoadingMXBean classLoadingMXBean;
    
    // GC MXBeans
    private final java.util.List<GarbageCollectorMXBean> gcMXBeans;
    
    public PerformanceMonitor() {
        this.monitorExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "PerformanceMonitor");
            t.setDaemon(true);
            return t;
        });
        
        this.osMXBean = ManagementFactory.getOperatingSystemMXBean();
        this.memoryMXBean = ManagementFactory.getMemoryMXBean();
        this.threadMXBean = ManagementFactory.getThreadMXBean();
        this.classLoadingMXBean = ManagementFactory.getClassLoadingMXBean();
        this.gcMXBeans = ManagementFactory.getGarbageCollectorMXBeans();
    }
    
    /**
     * 启动监控
     */
    public void start() {
        if (!running) {
            running = true;
            monitorExecutor.scheduleAtFixedRate(this, 0, MONITOR_INTERVAL, TimeUnit.MILLISECONDS);
        }
    }
    
    /**
     * 停止监控
     */
    public void stop() {
        running = false;
        monitorExecutor.shutdown();
    }
    
    @Override
    public void run() {
        try {
            // 采集CPU使用率
            collectCpuUsage();
            
            // 采集内存使用
            collectMemoryUsage();
            
            // 采集GC统计
            collectGcStats();
            
            // 采集线程统计
            collectThreadStats();
            
            // 采集类加载统计
            collectClassLoadingStats();
            
        } catch (Exception e) {
            System.err.println("Performance monitor error: " + e.getMessage());
        }
    }
    
    /**
     * 采集CPU使用率
     */
    private void collectCpuUsage() {
        // 获取进程CPU使用率
        cpuUsage = osMXBean.getProcessCpuLoad() * 100;
    }
    
    /**
     * 采集内存使用
     */
    private void collectMemoryUsage() {
        MemoryUsage heapUsage = memoryMXBean.getHeapMemoryUsage();
        MemoryUsage nonHeapUsage = memoryMXBean.getNonHeapMemoryUsage();
        memoryUsage = heapUsage.getUsed() + nonHeapUsage.getUsed();
    }
    
    /**
     * 采集GC统计
     */
    private void collectGcStats() {
        long totalGcCount = 0;
        long totalGcTime = 0;
        
        for (GarbageCollectorMXBean gcMXBean : gcMXBeans) {
            long count = gcMXBean.getCollectionCount();
            long time = gcMXBean.getCollectionTime();
            
            if (count > 0) {
                totalGcCount += count;
                totalGcTime += time;
            }
        }
        
        // 计算增量
        long deltaCount = totalGcCount - lastGcCount;
        long deltaTime = totalGcTime - lastGcTime;
        
        gcCount.addAndGet(deltaCount);
        gcTime.addAndGet(deltaTime);
        
        lastGcCount = totalGcCount;
        lastGcTime = totalGcTime;
    }
    
    /**
     * 采集线程统计
     */
    private void collectThreadStats() {
        threadCount = threadMXBean.getThreadCount();
        peakThreadCount = threadMXBean.getPeakThreadCount();
    }
    
    /**
     * 采集类加载统计
     */
    private void collectClassLoadingStats() {
        loadedClassCount = classLoadingMXBean.getLoadedClassCount();
    }
    
    /**
     * 获取CPU使用率
     */
    public double getCpuUsage() {
        return cpuUsage;
    }
    
    /**
     * 获取内存使用量（MB）
     */
    public double getMemoryUsageMB() {
        return memoryUsage / (1024.0 * 1024.0);
    }
    
    /**
     * 获取GC次数
     */
    public long getGcCount() {
        return gcCount.get();
    }
    
    /**
     * 获取GC时间（毫秒）
     */
    public long getGcTime() {
        return gcTime.get();
    }
    
    /**
     * 获取线程数
     */
    public int getThreadCount() {
        return threadCount;
    }
    
    /**
     * 获取峰值线程数
     */
    public int getPeakThreadCount() {
        return peakThreadCount;
    }
    
    /**
     * 获取类加载数
     */
    public long getLoadedClassCount() {
        return loadedClassCount;
    }
    
    /**
     * 获取统计信息
     */
    public String getStatistics() {
        return String.format(
                "PerformanceMonitor{cpu=%.2f%%, memory=%.2fMB, gcCount=%d, gcTime=%dms, threads=%d, classes=%d}",
                getCpuUsage(), getMemoryUsageMB(), getGcCount(), getGcTime(), 
                getThreadCount(), getLoadedClassCount());
    }
}
