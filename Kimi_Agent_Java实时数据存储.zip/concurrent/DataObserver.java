package com.observer.concurrent;

/**
 * 数据观察点接口
 * 定义观察点的基本行为
 */
public interface DataObserver {
    
    /**
     * 获取观察点名称
     */
    String getName();
    
    /**
     * 获取观察点描述
     */
    String getDescription();
    
    /**
     * 采集数据
     * @return 采集的数据点
     */
    DataPoint collect();
    
    /**
     * 获取数据类型
     */
    DataPoint.DataType getDataType();
    
    /**
     * 获取采样间隔（毫秒）
     */
    long getSampleIntervalMs();
    
    /**
     * 是否启用
     */
    boolean isEnabled();
    
    /**
     * 启用观察点
     */
    void enable();
    
    /**
     * 禁用观察点
     */
    void disable();
    
    /**
     * 获取观察点标签
     */
    java.util.Map<String, String> getTags();
    
    /**
     * 添加标签
     */
    void addTag(String key, String value);
    
    /**
     * 移除标签
     */
    void removeTag(String key);
}
