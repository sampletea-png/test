package com.observer.concurrent;

/**
 * Disruptor事件类
 * 用于在RingBuffer中传递数据
 * 支持对象复用，减少GC压力
 */
public class DataEvent {
    
    // 数据点引用
    private DataPoint dataPoint;
    
    // 事件序列号
    private long sequence;
    
    // 事件状态
    private volatile EventState state = EventState.NEW;
    
    // 生产者ID，用于追踪
    private long producerId;
    
    // 批处理标志
    private volatile boolean endOfBatch = false;
    
    public enum EventState {
        NEW,        // 新建
        FILLED,     // 已填充数据
        PROCESSING, // 处理中
        PROCESSED,  // 已处理
        RECYCLED    // 已回收
    }
    
    /**
     * 获取数据点
     */
    public DataPoint getDataPoint() {
        return dataPoint;
    }
    
    /**
     * 设置数据点
     */
    public void setDataPoint(DataPoint dataPoint) {
        this.dataPoint = dataPoint;
    }
    
    /**
     * 获取序列号
     */
    public long getSequence() {
        return sequence;
    }
    
    /**
     * 设置序列号
     */
    public void setSequence(long sequence) {
        this.sequence = sequence;
    }
    
    /**
     * 获取事件状态
     */
    public EventState getState() {
        return state;
    }
    
    /**
     * 设置事件状态
     */
    public void setState(EventState state) {
        this.state = state;
    }
    
    /**
     * 获取生产者ID
     */
    public long getProducerId() {
        return producerId;
    }
    
    /**
     * 设置生产者ID
     */
    public void setProducerId(long producerId) {
        this.producerId = producerId;
    }
    
    /**
     * 是否是批处理结束标志
     */
    public boolean isEndOfBatch() {
        return endOfBatch;
    }
    
    /**
     * 设置批处理结束标志
     */
    public void setEndOfBatch(boolean endOfBatch) {
        this.endOfBatch = endOfBatch;
    }
    
    /**
     * 重置事件，用于对象复用
     */
    public void reset() {
        this.dataPoint = null;
        this.sequence = -1;
        this.state = EventState.NEW;
        this.producerId = -1;
        this.endOfBatch = false;
    }
    
    /**
     * 复制事件数据
     */
    public void copyFrom(DataEvent other) {
        this.dataPoint = other.dataPoint;
        this.sequence = other.sequence;
        this.state = other.state;
        this.producerId = other.producerId;
        this.endOfBatch = other.endOfBatch;
    }
    
    @Override
    public String toString() {
        return String.format("DataEvent{seq=%d, state=%s, producer=%d, endOfBatch=%s, dataPoint=%s}",
                sequence, state, producerId, endOfBatch, dataPoint);
    }
}
