package com.observer.concurrent;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据收集器主类
 * 整合RingBuffer、生产者、消费者、存储等组件
 * 
 * 设计特点：
 * 1. 多生产者单消费者模型
 * 2. 无锁RingBuffer
 * 3. 异步存储
 * 4. 背压处理
 * 5. 性能监控
 */
public class DataCollector implements AutoCloseable {
    
    // 默认RingBuffer大小（必须是2的幂次方）
    private static final int DEFAULT_BUFFER_SIZE = 65536; // 64K
    
    // 数据缓冲区
    private final RingBuffer<DataEvent> ringBuffer;
    
    // 事件工厂
    private final DataEventFactory eventFactory;
    
    // 事件处理器（消费者）
    private final DataEventHandler eventHandler;
    
    // 观察点注册表
    private final ConcurrentObserverRegistry observerRegistry;
    
    // 异步存储
    private final AsyncFileStorage fileStorage;
    
    // 性能监控
    private final PerformanceMonitor performanceMonitor;
    
    // 运行标志
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    // 采集计数
    private final AtomicLong collectCount = new AtomicLong(0);
    
    // 丢弃计数
    private final AtomicLong dropCount = new AtomicLong(0);
    
    // 背压策略
    private volatile BackPressureStrategy backPressureStrategy = BackPressureStrategy.RETRY;
    
    // 采样线程池
    private final ScheduledExecutorService sampleExecutor;
    
    public DataCollector(String storagePath) throws Exception {
        this(storagePath, DEFAULT_BUFFER_SIZE);
    }
    
    public DataCollector(String storagePath, int bufferSize) throws Exception {
        // 初始化组件
        this.ringBuffer = new RingBuffer<>(bufferSize);
        this.eventFactory = new DataEventFactory(bufferSize / 2);
        this.eventHandler = new DataEventHandler(ringBuffer, eventFactory);
        this.observerRegistry = new ConcurrentObserverRegistry();
        this.fileStorage = new AsyncFileStorage(storagePath);
        this.performanceMonitor = new PerformanceMonitor();
        this.sampleExecutor = Executors.newScheduledThreadPool(2, r -> {
            Thread t = new Thread(r, "DataCollector-Sampler");
            t.setDaemon(true);
            return t;
        });
        
        // 添加存储处理器
        eventHandler.addStorageHandler(fileStorage);
    }
    
    /**
     * 启动数据收集器
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            // 启动事件处理器
            eventHandler.start();
            
            // 启动文件存储
            fileStorage.start();
            
            // 启动性能监控
            performanceMonitor.start();
            
            // 启动定期采样任务
            sampleExecutor.scheduleAtFixedRate(this::sampleAllObservers, 
                    0, 100, TimeUnit.MILLISECONDS);
            
            // 启动统计打印任务
            sampleExecutor.scheduleAtFixedRate(this::printStatistics, 
                    10, 10, TimeUnit.SECONDS);
            
            System.out.println("DataCollector started");
        }
    }
    
    /**
     * 停止数据收集器
     */
    public void stop() {
        if (running.compareAndSet(true, false)) {
            // 停止采样
            sampleExecutor.shutdown();
            
            // 停止事件处理器
            eventHandler.stop();
            
            // 停止文件存储
            fileStorage.stop();
            
            // 停止性能监控
            performanceMonitor.stop();
            
            System.out.println("DataCollector stopped");
        }
    }
    
    @Override
    public void close() {
        stop();
    }
    
    /**
     * 采集单个数据点
     */
    public boolean collect(DataPoint dataPoint) {
        if (!running.get() || dataPoint == null) {
            return false;
        }
        
        // 创建生产者并写入
        DataEventProducer producer = new DataEventProducer(ringBuffer, eventFactory);
        producer.setBackPressureStrategy(backPressureStrategy);
        
        boolean success = producer.write(dataPoint);
        
        if (success) {
            collectCount.incrementAndGet();
        } else {
            dropCount.incrementAndGet();
        }
        
        return success;
    }
    
    /**
     * 尝试采集（非阻塞）
     */
    public boolean tryCollect(DataPoint dataPoint) {
        if (!running.get() || dataPoint == null) {
            return false;
        }
        
        DataEventProducer producer = new DataEventProducer(ringBuffer, eventFactory);
        
        boolean success = producer.tryWrite(dataPoint);
        
        if (success) {
            collectCount.incrementAndGet();
        } else {
            dropCount.incrementAndGet();
        }
        
        return success;
    }
    
    /**
     * 批量采集
     */
    public int collectBatch(DataPoint[] dataPoints, int offset, int count) {
        if (!running.get() || dataPoints == null) {
            return 0;
        }
        
        DataEventProducer producer = new DataEventProducer(ringBuffer, eventFactory);
        producer.setBackPressureStrategy(backPressureStrategy);
        
        int written = producer.writeBatchOptimized(dataPoints, offset, count);
        collectCount.addAndGet(written);
        dropCount.addAndGet(count - written);
        
        return written;
    }
    
    /**
     * 注册观察点
     */
    public boolean registerObserver(DataObserver observer) {
        return observerRegistry.register(observer);
    }
    
    /**
     * 注销观察点
     */
    public boolean unregisterObserver(String name) {
        return observerRegistry.unregister(name);
    }
    
    /**
     * 获取观察点
     */
    public DataObserver getObserver(String name) {
        return observerRegistry.getObserver(name);
    }
    
    /**
     * 采样所有观察点
     */
    private void sampleAllObservers() {
        for (DataObserver observer : observerRegistry.getAllObservers()) {
            if (observer.isEnabled()) {
                try {
                    DataPoint dataPoint = observer.collect();
                    if (dataPoint != null) {
                        collect(dataPoint);
                    }
                } catch (Exception e) {
                    System.err.println("Sample observer error: " + e.getMessage());
                }
            }
        }
    }
    
    /**
     * 设置背压策略
     */
    public void setBackPressureStrategy(BackPressureStrategy strategy) {
        this.backPressureStrategy = strategy;
        eventHandler.setBackPressureStrategy(strategy);
    }
    
    /**
     * 获取RingBuffer
     */
    public RingBuffer<DataEvent> getRingBuffer() {
        return ringBuffer;
    }
    
    /**
     * 获取事件工厂
     */
    public DataEventFactory getEventFactory() {
        return eventFactory;
    }
    
    /**
     * 获取观察点注册表
     */
    public ConcurrentObserverRegistry getObserverRegistry() {
        return observerRegistry;
    }
    
    /**
     * 获取异步存储
     */
    public AsyncFileStorage getFileStorage() {
        return fileStorage;
    }
    
    /**
     * 获取性能监控
     */
    public PerformanceMonitor getPerformanceMonitor() {
        return performanceMonitor;
    }
    
    /**
     * 获取采集计数
     */
    public long getCollectCount() {
        return collectCount.get();
    }
    
    /**
     * 获取丢弃计数
     */
    public long getDropCount() {
        return dropCount.get();
    }
    
    /**
     * 获取采集成功率
     */
    public double getSuccessRate() {
        long total = collectCount.get() + dropCount.get();
        if (total == 0) {
            return 1.0;
        }
        return (double) collectCount.get() / total;
    }
    
    /**
     * 打印统计信息
     */
    private void printStatistics() {
        System.out.println("========== DataCollector Statistics ==========");
        System.out.println("Collect: " + getCollectCount() + ", Drop: " + getDropCount() 
                + ", Success Rate: " + String.format("%.2f%%", getSuccessRate() * 100));
        System.out.println("RingBuffer: availableRead=" + ringBuffer.availableToRead() 
                + ", availableWrite=" + ringBuffer.availableToWrite());
        System.out.println(eventFactory.getStatistics());
        System.out.println(eventHandler.getStatistics());
        System.out.println(fileStorage.getStatistics());
        System.out.println(observerRegistry.getStatistics());
        System.out.println(performanceMonitor.getStatistics());
        System.out.println("==============================================");
    }
    
    /**
     * 获取完整统计信息
     */
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("DataCollector Statistics:\n");
        sb.append("  Collect: ").append(getCollectCount()).append("\n");
        sb.append("  Drop: ").append(getDropCount()).append("\n");
        sb.append("  Success Rate: ").append(String.format("%.2f%%", getSuccessRate() * 100)).append("\n");
        sb.append("  ").append(eventFactory.getStatistics()).append("\n");
        sb.append("  ").append(eventHandler.getStatistics()).append("\n");
        sb.append("  ").append(fileStorage.getStatistics()).append("\n");
        sb.append("  ").append(observerRegistry.getStatistics()).append("\n");
        sb.append("  ").append(performanceMonitor.getStatistics()).append("\n");
        return sb.toString();
    }
}
