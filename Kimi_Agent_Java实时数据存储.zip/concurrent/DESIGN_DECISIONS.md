# 并发设计关键决策

## 1. 数据缓冲区设计

### 1.1 RingBuffer实现选择

**决策：使用自定义无锁RingBuffer而非Java标准库**

| 方案 | 优点 | 缺点 |
|------|------|------|
| ArrayBlockingQueue | 简单易用 | 有锁，性能较低 |
| LinkedTransferQueue | 无锁，性能较好 | 内存开销大，GC压力大 |
| **自定义RingBuffer** | **无锁，内存可控，零GC** | **实现复杂** |
| Disruptor库 | 专业，性能最优 | 外部依赖 |

**关键设计点：**
```java
// 1. 2的幂次方大小，位运算代替取模
private final int bufferSize = 65536;  // 2^16
private final int mask = bufferSize - 1;
// sequence & mask 代替 sequence % bufferSize

// 2. 缓存行填充，避免伪共享
private long p1, p2, p3, p4, p5, p6, p7;  // 64字节前导填充
private volatile long writeSequence;       // 实际数据
private long p8, p9, p10, p11, p12, p13, p14;  // 64字节后导填充

// 3. 使用Unsafe进行CAS操作
UNSAFE.compareAndSwapLong(this, WRITE_SEQUENCE_OFFSET, current, next);
```

### 1.2 序列号设计

**决策：使用long类型序列号，避免溢出**

```java
// long类型可以支持约292年（每秒1亿次操作）
// 2^63 / (100_000_000 * 365 * 24 * 3600) ≈ 292年
private volatile long writeSequence = -1;
private volatile long readSequence = -1;
```

## 2. 生产者端设计

### 2.1 写入策略选择

**决策：支持多种背压策略，根据场景选择**

```java
public enum BackPressureStrategy {
    DROP,    // 丢弃策略 - 追求最低延迟
    RETRY,   // 重试策略 - 短暂压力峰值
    BLOCK,   // 阻塞策略 - 不允许数据丢失
    YIELD,   // 让出策略 - 多生产者平衡
    SAMPLE,  // 采样策略 - 指标采集
    OVERFLOW // 溢出策略 - 保留所有数据
}
```

### 2.2 批量写入优化

**决策：预分配对象，批量写入减少CAS**

```java
public int writeBatchOptimized(DataPoint[] dataPoints, int offset, int count) {
    // 1. 预分配事件对象（减少内存分配）
    DataEvent[] events = new DataEvent[count];
    eventFactory.getEvents(events, 0, count);
    
    // 2. 批量填充数据
    for (int i = 0; i < count; i++) {
        events[i].setDataPoint(dataPoints[offset + i]);
    }
    
    // 3. 批量写入（减少CAS操作次数）
    return ringBuffer.writeBatch(events, 0, count);
}
```

### 2.3 对象池设计

**决策：使用对象池复用DataEvent，减少GC压力**

```java
public class DataEventFactory {
    private final BlockingQueue<DataEvent> eventPool;
    
    public DataEvent getEvent() {
        DataEvent event = eventPool.poll();
        if (event != null) {
            event.reset();  // 复用前重置
            return event;
        }
        return new DataEvent();  // 池空则创建新对象
    }
    
    public void recycleEvent(DataEvent event) {
        event.reset();
        eventPool.offer(event);  // 回收对象
    }
}
```

## 3. 消费者端设计

### 3.1 批量消费策略

**决策：批量读取+定时刷盘，平衡延迟和吞吐量**

```java
public void run() {
    while (running.get()) {
        // 1. 批量读取（减少锁竞争）
        int count = ringBuffer.readBatch(events, 0, batchSize);
        
        if (count > 0) {
            // 2. 批量处理
            for (int i = 0; i < count; i++) {
                processEvent(events[i]);
                eventFactory.recycleEvent(events[i]);  // 回收对象
            }
            
            // 3. 检查是否需要刷盘
            checkFlush();
        }
    }
}

private void checkFlush() {
    long currentTime = System.currentTimeMillis();
    if (currentTime - lastFlushTime >= flushInterval) {
        flushBatch();  // 定时刷盘
        lastFlushTime = currentTime;
    }
}
```

### 3.2 异步存储设计

**决策：使用独立线程+队列实现异步存储**

```java
public class AsyncFileStorage {
    // 写入队列（解耦生产者和消费者）
    private final BlockingQueue<String> dataQueue;
    
    // 异步写入线程
    private final ExecutorService writeExecutor;
    
    private void writeLoop() {
        List<String> batch = new ArrayList<>(batchSize);
        
        while (running.get()) {
            // 1. 收集批量数据
            String line = dataQueue.poll(flushInterval, TimeUnit.MILLISECONDS);
            if (line != null) {
                batch.add(line);
                dataQueue.drainTo(batch, batchSize - batch.size());
            }
            
            // 2. 批量写入文件
            if (batch.size() >= batchSize || 
                (currentTime - lastFlushTime >= flushInterval)) {
                writeBatch(batch);
                batch.clear();
            }
        }
    }
}
```

## 4. 观察点管理设计

### 4.1 并发安全选择

**决策：ConcurrentHashMap + StampedLock组合**

```java
public class ConcurrentObserverRegistry {
    // 基本存储使用ConcurrentHashMap
    private final ConcurrentHashMap<String, DataObserver> observers;
    
    // 批量操作使用StampedLock
    private final StampedLock lock = new StampedLock();
    
    public DataObserver getObserver(String name) {
        // 乐观读（读多写少场景优化）
        long stamp = lock.tryOptimisticRead();
        DataObserver observer = observers.get(name);
        if (lock.validate(stamp)) {
            return observer;  // 乐观读成功
        }
        
        // 乐观读失败，转为普通读锁
        stamp = lock.readLock();
        try {
            return observers.get(name);
        } finally {
            lock.unlockRead(stamp);
        }
    }
}
```

### 4.2 读写分离

**决策：按类型分组存储，优化查询性能**

```java
// 按类型分组的观察点
private final ConcurrentHashMap<DataType, Set<DataObserver>> observersByType;

public Set<DataObserver> getObserversByType(DataType type) {
    return new HashSet<>(observersByType.getOrDefault(type, Collections.emptySet()));
}
```

## 5. 内存模型考虑

### 5.1 内存屏障使用

**决策：显式使用内存屏障保证可见性**

```java
// 写入后使用storeFence保证数据可见性
public void write(long sequence, T data) {
    buffer[(int) (sequence & mask)] = data;
    UNSAFE.storeFence();  // StoreStore屏障
}

// 读取前使用loadFence保证读取最新值
public T read(long sequence) {
    UNSAFE.loadFence();  // LoadLoad屏障
    return (T) buffer[(int) (sequence & mask)];
}
```

### 5.2 volatile使用

**决策：关键变量使用volatile保证可见性**

```java
// 序列号使用volatile
private volatile long writeSequence = -1;
private volatile long readSequence = -1;

// 状态标志使用volatile
private volatile boolean running = false;
private volatile BackPressureStrategy backPressureStrategy = BackPressureStrategy.RETRY;
```

## 6. 性能优化策略

### 6.1 减少锁竞争

| 技术 | 应用场景 | 效果 |
|------|----------|------|
| CAS操作 | RingBuffer写入 | 无锁，高并发 |
| StampedLock | 观察点注册表 | 读多写少优化 |
| CopyOnWriteArrayList | 监听器列表 | 读多写少 |
| ThreadLocal | 生产者ID | 避免竞争 |

### 6.2 减少GC压力

| 技术 | 实现方式 | 效果 |
|------|----------|------|
| 对象池 | DataEventFactory | 复用对象 |
| 预分配 | RingBuffer数组 | 避免动态扩容 |
| 批量操作 | 批量读写 | 减少对象创建 |

### 6.3 缓存优化

| 技术 | 实现方式 | 效果 |
|------|----------|------|
| 缓存行填充 | 前后填充64字节 | 避免伪共享 |
| 顺序访问 | RingBuffer数组 | CPU缓存友好 |
| 直接内存 | ByteBuffer.allocateDirect | 零拷贝 |

## 7. 监控和诊断

### 7.1 性能监控

```java
public class PerformanceMonitor {
    // CPU使用率
    private volatile double cpuUsage;
    
    // 内存使用量
    private volatile long memoryUsage;
    
    // GC统计
    private final AtomicLong gcCount = new AtomicLong(0);
    private final AtomicLong gcTime = new AtomicLong(0);
    
    // 线程统计
    private volatile int threadCount;
}
```

### 7.2 统计信息

```java
// 各环节统计
public String getStatistics() {
    return String.format(
        "DataCollector{collect=%d, drop=%d, successRate=%.2f%%}\n" +
        "RingBuffer{availableRead=%d, availableWrite=%d}\n" +
        "EventFactory{created=%d, recycled=%d, hitRate=%.2f%%}\n" +
        "EventHandler{processed=%d, avgLatency=%.2fus}\n" +
        "FileStorage{writes=%d, bytes=%d}",
        // ... 具体数值
    );
}
```

## 8. 异常处理

### 8.1 生产者异常

```java
public boolean write(DataPoint dataPoint) {
    try {
        return tryWrite(dataPoint);
    } catch (Exception e) {
        // 记录异常但不影响其他生产者
        writeFailCount.incrementAndGet();
        return false;
    }
}
```

### 8.2 消费者异常

```java
public void run() {
    while (running.get()) {
        try {
            processEvents();
        } catch (Exception e) {
            // 记录异常但继续处理
            System.err.println("Process error: " + e.getMessage());
        }
    }
}
```

## 9. 扩展性设计

### 9.1 存储扩展

```java
public interface StorageHandler {
    void handleBatch(List<DataEvent> batch) throws Exception;
}

// 可以扩展多种存储
public class KafkaStorage implements StorageHandler { }
public class ElasticsearchStorage implements StorageHandler { }
public class InfluxDBStorage implements StorageHandler { }
```

### 9.2 背压策略扩展

```java
public interface BackPressureHandler {
    boolean handle(RingBuffer<?> buffer, DataPoint dataPoint);
}

// 可以自定义背压处理
public class CustomBackPressureHandler implements BackPressureHandler { }
```

## 10. 部署建议

### 10.1 JVM参数

```bash
# GC优化
-XX:+UseG1GC
-XX:MaxGCPauseMillis=10
-XX:+UnlockExperimentalVMOptions
-XX:+UseCGroupMemoryLimitForHeap

# 内存优化
-Xms4g -Xmx4g
-XX:MaxDirectMemorySize=1g
-XX:+UseLargePages

# 编译优化
-XX:+UseStringDeduplication
-XX:+OptimizeStringConcat

# 禁用偏向锁（高并发场景）
-XX:-UseBiasedLocking
```

### 10.2 线程绑定

```bash
# 将消费者线程绑定到特定CPU核心
taskset -c 0,1,2,3 java -jar app.jar
```

## 总结

本设计通过以下关键技术实现高并发读写：

1. **无锁设计**：使用CAS操作代替锁
2. **批量操作**：减少系统调用和CAS次数
3. **对象池**：减少GC压力
4. **缓存优化**：避免伪共享，提高CPU缓存命中率
5. **异步处理**：解耦生产者和消费者
6. **背压处理**：防止系统过载
