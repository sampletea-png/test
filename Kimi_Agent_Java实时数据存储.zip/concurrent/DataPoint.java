package com.observer.concurrent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 数据点实体类
 * 用于存储观察点采集的数据
 */
public class DataPoint {
    
    // 使用volatile保证可见性
    private volatile long timestamp;
    private volatile String observerName;
    private volatile Object value;
    private volatile DataType type;
    
    // 使用ConcurrentHashMap存储标签，支持并发访问
    private final Map<String, String> tags = new ConcurrentHashMap<>();
    
    public enum DataType {
        METRIC,      // 指标数据
        EVENT,       // 事件数据
        TRACE,       // 追踪数据
        LOG          // 日志数据
    }
    
    public DataPoint() {
        // 默认构造函数，用于对象池复用
    }
    
    public DataPoint(String observerName, Object value, DataType type) {
        this.timestamp = System.currentTimeMillis();
        this.observerName = observerName;
        this.value = value;
        this.type = type;
    }
    
    /**
     * 重置数据点，用于对象池复用
     */
    public void reset() {
        this.timestamp = 0;
        this.observerName = null;
        this.value = null;
        this.type = null;
        this.tags.clear();
    }
    
    /**
     * 设置数据点值
     */
    public void set(String observerName, Object value, DataType type) {
        this.timestamp = System.currentTimeMillis();
        this.observerName = observerName;
        this.value = value;
        this.type = type;
    }
    
    // Getters
    public long getTimestamp() {
        return timestamp;
    }
    
    public String getObserverName() {
        return observerName;
    }
    
    public Object getValue() {
        return value;
    }
    
    public DataType getType() {
        return type;
    }
    
    public Map<String, String> getTags() {
        return tags;
    }
    
    /**
     * 添加标签
     */
    public DataPoint addTag(String key, String value) {
        tags.put(key, value);
        return this;
    }
    
    @Override
    public String toString() {
        return String.format("DataPoint{time=%d, observer='%s', value=%s, type=%s, tags=%s}",
                timestamp, observerName, value, type, tags);
    }
    
    /**
     * 转换为CSV格式字符串
     */
    public String toCsvString() {
        return String.format("%d,%s,%s,%s,%s",
                timestamp, observerName, value, type, tags);
    }
}
