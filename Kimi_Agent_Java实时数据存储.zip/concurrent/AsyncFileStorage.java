package com.observer.concurrent;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.GZIPOutputStream;

/**
 * 异步文件存储
 * 负责将数据异步写入文件
 * 
 * 设计特点：
 * 1. 异步写入，不阻塞业务线程
 * 2. 批量刷盘，减少IO次数
 * 3. 文件滚动，避免单文件过大
 * 4. 支持压缩，节省存储空间
 * 5. 内存映射优化
 */
public class AsyncFileStorage implements DataEventHandler.StorageHandler, AutoCloseable {
    
    // 默认批量刷盘大小
    private static final int DEFAULT_BATCH_SIZE = 1000;
    
    // 默认刷盘间隔（毫秒）
    private static final long DEFAULT_FLUSH_INTERVAL = 1000;
    
    // 默认文件大小限制（字节）
    private static final long DEFAULT_FILE_SIZE_LIMIT = 100 * 1024 * 1024; // 100MB
    
    // 默认文件保留天数
    private static final int DEFAULT_RETENTION_DAYS = 7;
    
    // 存储目录
    private final Path storageDir;
    
    // 文件名前缀
    private final String filePrefix;
    
    // 当前写入文件
    private volatile FileChannel currentChannel;
    private volatile Path currentFile;
    
    // 批量大小
    private final int batchSize;
    
    // 刷盘间隔
    private final long flushInterval;
    
    // 文件大小限制
    private final long fileSizeLimit;
    
    // 文件保留天数
    private final int retentionDays;
    
    // 是否启用压缩
    private final boolean enableCompression;
    
    // 写入缓冲区
    private final ByteBuffer writeBuffer;
    
    // 批量数据队列
    private final BlockingQueue<String> dataQueue;
    
    // 写入线程
    private final ExecutorService writeExecutor;
    
    // 运行标志
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    // 写入计数
    private final AtomicLong writeCount = new AtomicLong(0);
    
    // 写入字节数
    private final AtomicLong writeBytes = new AtomicLong(0);
    
    // 刷盘计数
    private final AtomicLong flushCount = new AtomicLong(0);
    
    // 文件滚动计数
    private final AtomicLong rollCount = new AtomicLong(0);
    
    // 日期格式
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
    
    public AsyncFileStorage(String storagePath) throws IOException {
        this(storagePath, "data", DEFAULT_BATCH_SIZE, DEFAULT_FLUSH_INTERVAL,
                DEFAULT_FILE_SIZE_LIMIT, DEFAULT_RETENTION_DAYS, false);
    }
    
    public AsyncFileStorage(String storagePath, 
                           String filePrefix,
                           int batchSize,
                           long flushInterval,
                           long fileSizeLimit,
                           int retentionDays,
                           boolean enableCompression) throws IOException {
        this.storageDir = Paths.get(storagePath);
        this.filePrefix = filePrefix;
        this.batchSize = batchSize;
        this.flushInterval = flushInterval;
        this.fileSizeLimit = fileSizeLimit;
        this.retentionDays = retentionDays;
        this.enableCompression = enableCompression;
        this.writeBuffer = ByteBuffer.allocateDirect(1024 * 1024); // 1MB直接缓冲区
        this.dataQueue = new LinkedBlockingQueue<>(batchSize * 2);
        this.writeExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AsyncFileStorage-Writer");
            t.setDaemon(true);
            return t;
        });
        
        // 创建存储目录
        Files.createDirectories(storageDir);
        
        // 创建新文件
        rollFile();
    }
    
    /**
     * 启动存储服务
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            writeExecutor.submit(this::writeLoop);
            
            // 启动清理任务
            ScheduledExecutorService cleanupExecutor = Executors.newSingleThreadScheduledExecutor();
            cleanupExecutor.scheduleAtFixedRate(this::cleanupOldFiles, 1, 1, TimeUnit.HOURS);
        }
    }
    
    /**
     * 停止存储服务
     */
    public void stop() {
        if (running.compareAndSet(true, false)) {
            // 刷出剩余数据
            flushRemaining();
            
            writeExecutor.shutdown();
            try {
                if (!writeExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    writeExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                writeExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            
            // 关闭文件通道
            closeChannel();
        }
    }
    
    @Override
    public void close() {
        stop();
    }
    
    /**
     * 处理批量数据（实现StorageHandler接口）
     */
    @Override
    public void handleBatch(List<DataEvent> batch) throws Exception {
        for (DataEvent event : batch) {
            DataPoint dataPoint = event.getDataPoint();
            if (dataPoint != null) {
                String line = dataPoint.toCsvString() + "\n";
                
                // 非阻塞添加到队列
                if (!dataQueue.offer(line)) {
                    // 队列满，直接写入
                    writeDirect(line);
                }
            }
        }
    }
    
    /**
     * 写入循环
     */
    private void writeLoop() {
        List<String> batch = new ArrayList<>(batchSize);
        long lastFlushTime = System.currentTimeMillis();
        
        while (running.get()) {
            try {
                // 收集批量数据
                String line = dataQueue.poll(flushInterval, TimeUnit.MILLISECONDS);
                if (line != null) {
                    batch.add(line);
                    dataQueue.drainTo(batch, batchSize - batch.size());
                }
                
                // 检查是否需要刷盘
                long currentTime = System.currentTimeMillis();
                boolean shouldFlush = batch.size() >= batchSize 
                        || (currentTime - lastFlushTime >= flushInterval && !batch.isEmpty());
                
                if (shouldFlush) {
                    writeBatch(batch);
                    batch.clear();
                    lastFlushTime = currentTime;
                }
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("Write loop error: " + e.getMessage());
            }
        }
    }
    
    /**
     * 批量写入
     */
    private void writeBatch(List<String> batch) {
        if (batch.isEmpty()) {
            return;
        }
        
        try {
            // 检查是否需要文件滚动
            checkAndRollFile();
            
            // 构建批量数据
            StringBuilder sb = new StringBuilder();
            for (String line : batch) {
                sb.append(line);
            }
            
            byte[] data = sb.toString().getBytes(StandardCharsets.UTF_8);
            
            // 写入文件
            writeBuffer.clear();
            writeBuffer.put(data);
            writeBuffer.flip();
            
            while (writeBuffer.hasRemaining()) {
                currentChannel.write(writeBuffer);
            }
            
            // 更新统计
            writeCount.addAndGet(batch.size());
            writeBytes.addAndGet(data.length);
            flushCount.incrementAndGet();
            
        } catch (IOException e) {
            System.err.println("Write batch error: " + e.getMessage());
        }
    }
    
    /**
     * 直接写入（绕过队列）
     */
    private void writeDirect(String line) {
        try {
            checkAndRollFile();
            
            byte[] data = line.getBytes(StandardCharsets.UTF_8);
            writeBuffer.clear();
            writeBuffer.put(data);
            writeBuffer.flip();
            
            while (writeBuffer.hasRemaining()) {
                currentChannel.write(writeBuffer);
            }
            
            writeCount.incrementAndGet();
            writeBytes.addAndGet(data.length);
            
        } catch (IOException e) {
            System.err.println("Direct write error: " + e.getMessage());
        }
    }
    
    /**
     * 检查并执行文件滚动
     */
    private void checkAndRollFile() throws IOException {
        if (currentChannel == null) {
            rollFile();
            return;
        }
        
        long currentSize = currentChannel.position();
        if (currentSize >= fileSizeLimit) {
            rollFile();
        }
    }
    
    /**
     * 文件滚动
     */
    private synchronized void rollFile() throws IOException {
        // 关闭当前文件
        closeChannel();
        
        // 压缩旧文件
        if (enableCompression && currentFile != null) {
            compressFile(currentFile);
        }
        
        // 创建新文件
        String fileName = String.format("%s_%s.log", 
                filePrefix, dateFormat.format(new Date()));
        currentFile = storageDir.resolve(fileName);
        currentChannel = FileChannel.open(currentFile, 
                StandardOpenOption.CREATE, 
                StandardOpenOption.WRITE,
                StandardOpenOption.APPEND);
        
        rollCount.incrementAndGet();
    }
    
    /**
     * 关闭文件通道
     */
    private void closeChannel() {
        if (currentChannel != null) {
            try {
                currentChannel.force(true); // 强制刷盘
                currentChannel.close();
            } catch (IOException e) {
                System.err.println("Close channel error: " + e.getMessage());
            }
            currentChannel = null;
        }
    }
    
    /**
     * 压缩文件
     */
    private void compressFile(Path file) {
        try {
            Path compressedFile = Paths.get(file.toString() + ".gz");
            
            try (FileInputStream fis = new FileInputStream(file.toFile());
                 FileOutputStream fos = new FileOutputStream(compressedFile.toFile());
                 GZIPOutputStream gzos = new GZIPOutputStream(fos)) {
                
                byte[] buffer = new byte[8192];
                int len;
                while ((len = fis.read(buffer)) > 0) {
                    gzos.write(buffer, 0, len);
                }
            }
            
            // 删除原文件
            Files.deleteIfExists(file);
            
        } catch (IOException e) {
            System.err.println("Compress file error: " + e.getMessage());
        }
    }
    
    /**
     * 清理旧文件
     */
    private void cleanupOldFiles() {
        try {
            long cutoffTime = System.currentTimeMillis() - 
                    (retentionDays * 24 * 60 * 60 * 1000L);
            
            Files.list(storageDir).forEach(file -> {
                try {
                    if (Files.getLastModifiedTime(file).toMillis() < cutoffTime) {
                        Files.deleteIfExists(file);
                    }
                } catch (IOException e) {
                    System.err.println("Cleanup file error: " + e.getMessage());
                }
            });
            
        } catch (IOException e) {
            System.err.println("Cleanup error: " + e.getMessage());
        }
    }
    
    /**
     * 刷出剩余数据
     */
    private void flushRemaining() {
        List<String> remaining = new ArrayList<>();
        dataQueue.drainTo(remaining);
        writeBatch(remaining);
    }
    
    /**
     * 强制刷盘
     */
    public void force() {
        if (currentChannel != null) {
            try {
                currentChannel.force(true);
            } catch (IOException e) {
                System.err.println("Force error: " + e.getMessage());
            }
        }
    }
    
    /**
     * 获取写入计数
     */
    public long getWriteCount() {
        return writeCount.get();
    }
    
    /**
     * 获取写入字节数
     */
    public long getWriteBytes() {
        return writeBytes.get();
    }
    
    /**
     * 获取刷盘计数
     */
    public long getFlushCount() {
        return flushCount.get();
    }
    
    /**
     * 获取文件滚动计数
     */
    public long getRollCount() {
        return rollCount.get();
    }
    
    /**
     * 获取队列大小
     */
    public int getQueueSize() {
        return dataQueue.size();
    }
    
    /**
     * 获取存储统计信息
     */
    public String getStatistics() {
        return String.format(
                "AsyncFileStorage{writes=%d, bytes=%d, flushes=%d, rolls=%d, queue=%d, file=%s}",
                getWriteCount(), getWriteBytes(), getFlushCount(), getRollCount(), 
                getQueueSize(), currentFile);
    }
}
