package com.observer.concurrent;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 数据事件生产者
 * 负责将数据点写入RingBuffer
 * 
 * 设计特点：
 * 1. 非阻塞写入，失败可重试
 * 2. 批量写入优化
 * 3. 支持背压处理
 * 4. 无锁设计
 */
public class DataEventProducer {
    
    // 默认重试次数
    private static final int DEFAULT_RETRY_COUNT = 3;
    
    // 默认重试延迟（纳秒）
    private static final long DEFAULT_RETRY_DELAY_NS = 100;
    
    // 数据缓冲区
    private final RingBuffer<DataEvent> ringBuffer;
    
    // 事件工厂
    private final DataEventFactory eventFactory;
    
    // 最大重试次数
    private final int maxRetryCount;
    
    // 重试延迟
    private final long retryDelayNs;
    
    // 生产者ID
    private final long producerId;
    
    // 写入计数
    private final AtomicLong writeCount = new AtomicLong(0);
    
    // 写入失败计数
    private final AtomicLong writeFailCount = new AtomicLong(0);
    
    // 背压丢弃计数
    private final AtomicLong dropCount = new AtomicLong(0);
    
    // 背压策略
    private volatile BackPressureStrategy backPressureStrategy = BackPressureStrategy.RETRY;
    
    // 静态生产者ID生成器
    private static final AtomicLong PRODUCER_ID_GENERATOR = new AtomicLong(0);
    
    public DataEventProducer(RingBuffer<DataEvent> ringBuffer, DataEventFactory eventFactory) {
        this(ringBuffer, eventFactory, DEFAULT_RETRY_COUNT, DEFAULT_RETRY_DELAY_NS);
    }
    
    public DataEventProducer(RingBuffer<DataEvent> ringBuffer, 
                            DataEventFactory eventFactory,
                            int maxRetryCount, 
                            long retryDelayNs) {
        this.ringBuffer = ringBuffer;
        this.eventFactory = eventFactory;
        this.maxRetryCount = maxRetryCount;
        this.retryDelayNs = retryDelayNs;
        this.producerId = PRODUCER_ID_GENERATOR.incrementAndGet();
    }
    
    /**
     * 写入单个数据点（非阻塞）
     * @return true if success, false if buffer full
     */
    public boolean tryWrite(DataPoint dataPoint) {
        // 获取事件对象
        DataEvent event = eventFactory.getEvent();
        event.setDataPoint(dataPoint);
        event.setProducerId(producerId);
        event.setState(DataEvent.EventState.FILLED);
        
        // 尝试写入RingBuffer
        if (ringBuffer.tryWrite(event)) {
            writeCount.incrementAndGet();
            return true;
        }
        
        // 写入失败，回收事件对象
        eventFactory.recycleEvent(event);
        return false;
    }
    
    /**
     * 写入单个数据点（带重试）
     */
    public boolean writeWithRetry(DataPoint dataPoint) {
        for (int i = 0; i < maxRetryCount; i++) {
            if (tryWrite(dataPoint)) {
                return true;
            }
            
            // 短暂延迟后重试
            if (i < maxRetryCount - 1) {
                spinWait(retryDelayNs);
            }
        }
        
        writeFailCount.incrementAndGet();
        return false;
    }
    
    /**
     * 写入单个数据点（根据背压策略处理）
     */
    public boolean write(DataPoint dataPoint) {
        switch (backPressureStrategy) {
            case DROP:
                // 直接尝试写入，失败则丢弃
                if (!tryWrite(dataPoint)) {
                    dropCount.incrementAndGet();
                    return false;
                }
                return true;
                
            case RETRY:
                // 带重试的写入
                return writeWithRetry(dataPoint);
                
            case BLOCK:
                // 阻塞写入（自旋等待）
                while (!tryWrite(dataPoint)) {
                    spinWait(retryDelayNs);
                }
                return true;
                
            case YIELD:
                // 让出CPU后重试
                for (int i = 0; i < maxRetryCount; i++) {
                    if (tryWrite(dataPoint)) {
                        return true;
                    }
                    Thread.yield();
                }
                dropCount.incrementAndGet();
                return false;
                
            default:
                return tryWrite(dataPoint);
        }
    }
    
    /**
     * 批量写入数据点
     */
    public int writeBatch(DataPoint[] dataPoints, int offset, int count) {
        int written = 0;
        
        for (int i = 0; i < count; i++) {
            if (write(dataPoints[offset + i])) {
                written++;
            }
        }
        
        return written;
    }
    
    /**
     * 批量写入数据点（优化版本）
     * 尽可能连续写入，减少CAS操作
     */
    public int writeBatchOptimized(DataPoint[] dataPoints, int offset, int count) {
        DataEvent[] events = new DataEvent[count];
        
        // 预分配事件对象
        eventFactory.getEvents(events, 0, count);
        
        // 填充事件数据
        for (int i = 0; i < count; i++) {
            events[i].setDataPoint(dataPoints[offset + i]);
            events[i].setProducerId(producerId);
            events[i].setState(DataEvent.EventState.FILLED);
        }
        
        // 批量写入
        int written = ringBuffer.writeBatch(events, 0, count);
        
        // 回收未写入的事件
        if (written < count) {
            eventFactory.recycleEvents(events, written, count - written);
            writeFailCount.addAndGet(count - written);
        }
        
        writeCount.addAndGet(written);
        return written;
    }
    
    /**
     * 自旋等待
     */
    private void spinWait(long nanos) {
        long deadline = System.nanoTime() + nanos;
        while (System.nanoTime() < deadline) {
            // 自旋
        }
    }
    
    /**
     * 设置背压策略
     */
    public void setBackPressureStrategy(BackPressureStrategy strategy) {
        this.backPressureStrategy = strategy;
    }
    
    /**
     * 获取生产者ID
     */
    public long getProducerId() {
        return producerId;
    }
    
    /**
     * 获取写入计数
     */
    public long getWriteCount() {
        return writeCount.get();
    }
    
    /**
     * 获取写入失败计数
     */
    public long getWriteFailCount() {
        return writeFailCount.get();
    }
    
    /**
     * 获取背压丢弃计数
     */
    public long getDropCount() {
        return dropCount.get();
    }
    
    /**
     * 获取写入成功率
     */
    public double getSuccessRate() {
        long total = writeCount.get() + writeFailCount.get();
        if (total == 0) {
            return 1.0;
        }
        return (double) writeCount.get() / total;
    }
    
    /**
     * 获取生产者统计信息
     */
    public String getStatistics() {
        return String.format(
                "DataEventProducer{id=%d, writes=%d, fails=%d, drops=%d, successRate=%.2f%%}",
                producerId, getWriteCount(), getWriteFailCount(), getDropCount(), 
                getSuccessRate() * 100);
    }
}
