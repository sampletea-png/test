package com.dataobserver.core.impl;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.*;
import java.nio.ByteBuffer;
import java.util.concurrent.locks.*;

/**
 * ============================================
 * 数据源元数据实现
 * ============================================
 */
public class SourceMetadataImpl implements SourceMetadata {
    private final String id;
    private final String name;
    private final String description;
    private final DataType dataType;
    private final double sampleRate;
    private final String unit;
    private final Double minValue;
    private final Double maxValue;
    private final Map<String, String> properties = new ConcurrentHashMap<>();
    
    private SourceMetadataImpl(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.description = builder.description;
        this.dataType = builder.dataType;
        this.sampleRate = builder.sampleRate;
        this.unit = builder.unit;
        this.minValue = builder.minValue;
        this.maxValue = builder.maxValue;
    }
    
    public static Builder builder(String id, DataType dataType) {
        return new Builder(id, dataType);
    }
    
    public static class Builder {
        private final String id;
        private final DataType dataType;
        private String name;
        private String description = "";
        private double sampleRate = 0;
        private String unit = "";
        private Double minValue = null;
        private Double maxValue = null;
        
        public Builder(String id, DataType dataType) {
            this.id = Objects.requireNonNull(id);
            this.dataType = Objects.requireNonNull(dataType);
            this.name = id;
        }
        
        public Builder name(String name) { this.name = name; return this; }
        public Builder description(String desc) { this.description = desc; return this; }
        public Builder sampleRate(double rate) { this.sampleRate = rate; return this; }
        public Builder unit(String unit) { this.unit = unit; return this; }
        public Builder minValue(double min) { this.minValue = min; return this; }
        public Builder maxValue(double max) { this.maxValue = max; return this; }
        public Builder range(double min, double max) { 
            this.minValue = min; 
            this.maxValue = max; 
            return this; 
        }
        
        public SourceMetadataImpl build() { return new SourceMetadataImpl(this); }
    }
    
    @Override public String getId() { return id; }
    @Override public String getName() { return name; }
    @Override public String getDescription() { return description; }
    @Override public DataType getDataType() { return dataType; }
    @Override public double getSampleRate() { return sampleRate; }
    @Override public String getUnit() { return unit; }
    @Override public Double getMinValue() { return minValue; }
    @Override public Double getMaxValue() { return maxValue; }
    @Override public String getProperty(String key) { return properties.get(key); }
    @Override public void setProperty(String key, String value) { properties.put(key, value); }
}

/**
 * ============================================
 * 数据样本实现（支持对象池复用）
 * ============================================
 */
public class DataSampleImpl implements DataSample {
    
    // 对象池
    private static final ThreadLocal<Queue<DataSampleImpl>> POOL = 
        ThreadLocal.withInitial(() -> new ArrayDeque<>(100));
    
    private String sourceId;
    private long timestampNanos;
    private DataType dataType;
    private Object value;
    private boolean fromPool = false;
    
    // 私有构造函数，通过工厂方法创建
    private DataSampleImpl() {}
    
    /**
     * 从对象池获取实例
     */
    public static DataSampleImpl acquire() {
        Queue<DataSampleImpl> pool = POOL.get();
        DataSampleImpl sample = pool.poll();
        if (sample == null) {
            sample = new DataSampleImpl();
        }
        sample.fromPool = true;
        return sample;
    }
    
    /**
     * 创建新实例（不来自对象池）
     */
    public static DataSampleImpl create(String sourceId, DataType type, Object value) {
        DataSampleImpl sample = new DataSampleImpl();
        sample.sourceId = sourceId;
        sample.timestampNanos = System.nanoTime();
        sample.dataType = type;
        sample.value = value;
        sample.fromPool = false;
        return sample;
    }
    
    /**
     * 初始化方法（用于对象池复用）
     */
    public DataSampleImpl initialize(String sourceId, DataType type, Object value) {
        this.sourceId = sourceId;
        this.timestampNanos = System.nanoTime();
        this.dataType = type;
        this.value = value;
        return this;
    }
    
    /**
     * 释放回对象池
     */
    public void release() {
        if (fromPool) {
            reset();
            POOL.get().offer(this);
        }
    }
    
    @Override
    public void reset() {
        this.sourceId = null;
        this.value = null;
        this.dataType = null;
        this.timestampNanos = 0;
    }
    
    @Override public String getSourceId() { return sourceId; }
    @Override public long getTimestampNanos() { return timestampNanos; }
    @Override public DataType getDataType() { return dataType; }
    @Override public Object getValue() { return value; }
    
    @Override
    public int getSizeInBytes() {
        if (dataType == null) return 0;
        if (dataType.isArray()) {
            if (value instanceof byte[]) return ((byte[]) value).length;
            if (value instanceof short[]) return ((short[]) value).length * 2;
            if (value instanceof int[]) return ((int[]) value).length * 4;
            if (value instanceof float[]) return ((float[]) value).length * 4;
            if (value instanceof double[]) return ((double[]) value).length * 8;
            return 0;
        }
        return dataType.getSizeInBytes();
    }
    
    @Override
    public byte[] serialize() {
        // 简化的序列化实现，实际应根据DataType实现完整逻辑
        ByteBuffer buffer = ByteBuffer.allocate(8 + 4 + getSizeInBytes());
        buffer.putLong(timestampNanos);
        buffer.putInt(dataType.ordinal());
        // ... 序列化value
        return buffer.array();
    }
}

/**
 * ============================================
 * 无锁环形缓冲区实现（基于Disruptor思想）
 * ============================================
 */
public class RingBuffer implements DataBuffer {
    
    private final DataSample[] buffer;
    private final int capacity;
    private final int mask;
    
    // 使用Sequence来跟踪读写位置
    private final AtomicLong writeSequence = new AtomicLong(-1);
    private final AtomicLong readSequence = new AtomicLong(-1);
    
    // 缓存行填充，避免伪共享
    private long p1, p2, p3, p4, p5, p6, p7;
    
    public RingBuffer(int capacity) {
        // 容量必须是2的幂，便于位运算
        this.capacity = nextPowerOfTwo(capacity);
        this.mask = this.capacity - 1;
        this.buffer = new DataSample[this.capacity];
    }
    
    private static int nextPowerOfTwo(int value) {
        return Integer.highestOneBit(value - 1) << 1;
    }
    
    @Override
    public boolean write(DataSample sample) {
        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + 1;
        
        // 检查是否有空间
        long wrapPoint = nextWrite - capacity;
        if (readSequence.get() < wrapPoint) {
            return false; // 缓冲区已满
        }
        
        // CAS操作尝试写入
        if (writeSequence.compareAndSet(currentWrite, nextWrite)) {
            buffer[(int) (nextWrite & mask)] = sample;
            return true;
        }
        return false;
    }
    
    @Override
    public int writeBatch(DataSample[] samples) {
        int written = 0;
        for (DataSample sample : samples) {
            if (write(sample)) {
                written++;
            } else {
                break;
            }
        }
        return written;
    }
    
    @Override
    public DataSample read() {
        long currentRead = readSequence.get();
        long nextRead = currentRead + 1;
        
        // 检查是否有数据可读
        if (nextRead > writeSequence.get()) {
            return null; // 缓冲区为空
        }
        
        // CAS操作尝试读取
        if (readSequence.compareAndSet(currentRead, nextRead)) {
            DataSample sample = buffer[(int) (nextRead & mask)];
            buffer[(int) (nextRead & mask)] = null; // 帮助GC
            return sample;
        }
        return null;
    }
    
    @Override
    public DataSample[] readBatch(int maxCount) {
        List<DataSample> samples = new ArrayList<>(maxCount);
        for (int i = 0; i < maxCount; i++) {
            DataSample sample = read();
            if (sample == null) break;
            samples.add(sample);
        }
        return samples.toArray(new DataSample[0]);
    }
    
    @Override public int size() {
        return (int) (writeSequence.get() - readSequence.get());
    }
    @Override public int capacity() { return capacity; }
    @Override public boolean isEmpty() { return size() == 0; }
    @Override public boolean isFull() { return size() >= capacity; }
    
    @Override
    public void clear() {
        while (read() != null) {
            // 持续读取直到为空
        }
    }
    
    @Override
    public int getUtilization() {
        return (int) ((size() * 100L) / capacity);
    }
}

/**
 * ============================================
 * 数据收集器实现
 * ============================================
 */
public class DataCollectorImpl implements DataCollector, DataChangeListener {
    
    private final DataBuffer buffer;
    private final Set<ObservableSource> sources = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicLong totalCollected = new AtomicLong(0);
    private final AtomicLong totalBytes = new AtomicLong(0);
    private final AtomicLong droppedSamples = new AtomicLong(0);
    
    // 批量收集配置
    private final int batchSize;
    private final DataSample[] batchBuffer;
    private final AtomicInteger batchIndex = new AtomicInteger(0);
    
    // 定时刷新
    private ScheduledExecutorService flushExecutor;
    private final int flushIntervalMs;
    
    public DataCollectorImpl(DataBuffer buffer, int batchSize, int flushIntervalMs) {
        this.buffer = buffer;
        this.batchSize = batchSize;
        this.flushIntervalMs = flushIntervalMs;
        this.batchBuffer = new DataSample[batchSize];
    }
    
    @Override
    public boolean collect(DataSample sample) {
        if (!running.get()) return false;
        
        int index = batchIndex.getAndIncrement();
        if (index < batchSize) {
            batchBuffer[index] = sample;
            
            // 批量满，写入缓冲区
            if (index == batchSize - 1) {
                flushBatch();
            }
            return true;
        } else {
            // 超出批量大小，直接写入
            batchIndex.decrementAndGet();
            return writeDirectly(sample);
        }
    }
    
    @Override
    public int collectBatch(DataSample[] samples) {
        int written = buffer.writeBatch(samples);
        int dropped = samples.length - written;
        
        totalCollected.addAndGet(written);
        droppedSamples.addAndGet(dropped);
        
        for (int i = 0; i < written; i++) {
            totalBytes.addAndGet(samples[i].getSizeInBytes());
        }
        
        return written;
    }
    
    private boolean writeDirectly(DataSample sample) {
        if (buffer.write(sample)) {
            totalCollected.incrementAndGet();
            totalBytes.addAndGet(sample.getSizeInBytes());
            return true;
        } else {
            droppedSamples.incrementAndGet();
            return false;
        }
    }
    
    private void flushBatch() {
        DataSample[] toFlush = new DataSample[batchSize];
        System.arraycopy(batchBuffer, 0, toFlush, 0, batchSize);
        batchIndex.set(0);
        collectBatch(toFlush);
    }
    
    @Override
    public void registerSource(ObservableSource source) {
        sources.add(source);
        source.addChangeListener(this);
        if (running.get() && source.getMetadata().getSampleRate() > 0) {
            source.start();
        }
    }
    
    @Override
    public void unregisterSource(ObservableSource source) {
        sources.remove(source);
        source.removeChangeListener(this);
        source.stop();
    }
    
    @Override
    public void start() {
        if (running.compareAndSet(false, true)) {
            // 启动周期性采样源
            for (ObservableSource source : sources) {
                if (source.getMetadata().getSampleRate() > 0) {
                    source.start();
                }
            }
            
            // 启动定时刷新
            flushExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "DataCollector-Flush");
                t.setDaemon(true);
                return t;
            });
            flushExecutor.scheduleAtFixedRate(this::flushBatch, 
                flushIntervalMs, flushIntervalMs, TimeUnit.MILLISECONDS);
        }
    }
    
    @Override
    public void stop() {
        if (running.compareAndSet(true, false)) {
            // 停止所有源
            for (ObservableSource source : sources) {
                source.stop();
            }
            
            // 停止定时刷新
            if (flushExecutor != null) {
                flushExecutor.shutdown();
                try {
                    flushExecutor.awaitTermination(5, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            
            // 最后刷新
            flushBatch();
        }
    }
    
    @Override
    public CollectionStats getStats() {
        return new CollectionStats() {
            @Override public long getTotalSamplesCollected() { return totalCollected.get(); }
            @Override public long getTotalBytesCollected() { return totalBytes.get(); }
            @Override public long getSamplesPerSecond() { 
                // 简化实现，实际需要时间窗口计算
                return 0; 
            }
            @Override public long getDroppedSamples() { return droppedSamples.get(); }
            @Override public long getBufferUtilization() { return buffer.getUtilization(); }
        };
    }
    
    // DataChangeListener 实现
    @Override
    public void onDataChanged(ObservableSource source, DataSample sample) {
        collect(sample);
    }
}

/**
 * ============================================
 * 数据观察器主类实现（外观模式）
 * ============================================
 */
public class DataObserverImpl implements DataObserver {
    
    private final Map<String, ObservableSource> sources = new ConcurrentHashMap<>();
    private final List<ObserverEventListener> eventListeners = new CopyOnWriteArrayList<>();
    
    private DataCollector collector;
    private DataBuffer buffer;
    private DataStorage storage;
    private DataSerializer serializer;
    
    private volatile ObserverState state = ObserverState.STOPPED;
    private ObserverConfig config;
    
    // 存储写入线程
    private ExecutorService storageExecutor;
    private volatile boolean storageRunning = false;
    
    // 统计信息
    private final AtomicLong totalSamples = new AtomicLong(0);
    private final AtomicLong totalBytes = new AtomicLong(0);
    private final AtomicLong droppedSamples = new AtomicLong(0);
    
    @Override
    public void initialize(ObserverConfig config) {
        this.config = config;
        
        // 创建缓冲区
        this.buffer = new RingBuffer(config.getBufferSize());
        
        // 创建收集器
        this.collector = new DataCollectorImpl(buffer, config.getBatchSize(), config.getFlushIntervalMs());
        
        // 创建存储（使用工厂模式）
        this.storage = StorageFactory.createStorage(config.getStorageFormat());
        this.storage.setCompressionLevel(config.getCompressionLevel());
        
        // 创建序列化器
        this.serializer = SerializerFactory.createSerializer(config.getStorageFormat());
        
        state = ObserverState.INITIALIZED;
    }
    
    @Override
    public void registerSource(ObservableSource source) {
        String sourceId = source.getMetadata().getId();
        sources.put(sourceId, source);
        collector.registerSource(source);
        
        // 通知监听器
        for (ObserverEventListener listener : eventListeners) {
            listener.onSourceRegistered(sourceId, source.getMetadata());
        }
    }
    
    @Override
    public void unregisterSource(String sourceId) {
        ObservableSource source = sources.remove(sourceId);
        if (source != null) {
            collector.unregisterSource(source);
            for (ObserverEventListener listener : eventListeners) {
                listener.onSourceUnregistered(sourceId);
            }
        }
    }
    
    @Override
    public ObservableSource getSource(String sourceId) {
        return sources.get(sourceId);
    }
    
    @Override
    public ObservableSource[] getAllSources() {
        return sources.values().toArray(new ObservableSource[0]);
    }
    
    @Override
    public void start() {
        if (state == ObserverState.RUNNING) return;
        
        // 打开存储
        try {
            String filePath = config.getStoragePath() + "/data_" + System.currentTimeMillis() + 
                storage.getFileExtension();
            storage.open(filePath, getAllSourceMetadata());
        } catch (StorageException e) {
            for (ObserverEventListener listener : eventListeners) {
                listener.onStorageError(e);
            }
            return;
        }
        
        // 启动收集器
        collector.start();
        
        // 启动存储写入线程
        storageRunning = true;
        storageExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "DataObserver-Storage");
            t.setDaemon(true);
            return t;
        });
        storageExecutor.submit(this::storageLoop);
        
        ObserverState oldState = state;
        state = ObserverState.RUNNING;
        for (ObserverEventListener listener : eventListeners) {
            listener.onStateChanged(oldState, state);
        }
    }
    
    @Override
    public void stop() {
        if (state != ObserverState.RUNNING && state != ObserverState.PAUSED) return;
        
        // 停止收集器
        collector.stop();
        
        // 停止存储线程
        storageRunning = false;
        if (storageExecutor != null) {
            storageExecutor.shutdown();
            try {
                storageExecutor.awaitTermination(10, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        // 关闭存储
        try {
            storage.close();
        } catch (StorageException e) {
            for (ObserverEventListener listener : eventListeners) {
                listener.onStorageError(e);
            }
        }
        
        ObserverState oldState = state;
        state = ObserverState.STOPPED;
        for (ObserverEventListener listener : eventListeners) {
            listener.onStateChanged(oldState, state);
        }
    }
    
    @Override
    public void pause() {
        if (state != ObserverState.RUNNING) return;
        
        ObserverState oldState = state;
        state = ObserverState.PAUSED;
        for (ObserverEventListener listener : eventListeners) {
            listener.onStateChanged(oldState, state);
        }
    }
    
    @Override
    public void resume() {
        if (state != ObserverState.PAUSED) return;
        
        ObserverState oldState = state;
        state = ObserverState.RUNNING;
        for (ObserverEventListener listener : eventListeners) {
            listener.onStateChanged(oldState, state);
        }
    }
    
    @Override
    public void flush() {
        try {
            storage.flush();
        } catch (StorageException e) {
            for (ObserverEventListener listener : eventListeners) {
                listener.onStorageError(e);
            }
        }
    }
    
    @Override
    public ObserverState getState() {
        return state;
    }
    
    @Override
    public ObserverStats getStats() {
        CollectionStats collectorStats = collector.getStats();
        return new ObserverStats() {
            @Override public long getTotalSources() { return sources.size(); }
            @Override public long getActiveSources() { 
                return sources.values().stream().filter(ObservableSource::isAvailable).count();
            }
            @Override public long getTotalSamples() { return totalSamples.get(); }
            @Override public long getTotalBytes() { return totalBytes.get(); }
            @Override public double getDataRateMBps() { 
                // 简化实现
                return 0; 
            }
            @Override public long getDroppedSamples() { return droppedSamples.get(); }
            @Override public long getBufferUtilization() { return buffer.getUtilization(); }
            @Override public ObserverState getState() { return state; }
        };
    }
    
    @Override
    public void addEventListener(ObserverEventListener listener) {
        eventListeners.add(listener);
    }
    
    @Override
    public void removeEventListener(ObserverEventListener listener) {
        eventListeners.remove(listener);
    }
    
    /**
     * 存储写入循环
     */
    private void storageLoop() {
        while (storageRunning) {
            try {
                // 批量读取缓冲区
                DataSample[] samples = buffer.readBatch(config.getBatchSize());
                
                if (samples.length > 0) {
                    // 写入存储
                    storage.writeSamples(samples);
                    
                    // 更新统计
                    totalSamples.addAndGet(samples.length);
                    for (DataSample sample : samples) {
                        totalBytes.addAndGet(sample.getSizeInBytes());
                    }
                    
                    // 释放对象池中的对象
                    for (DataSample sample : samples) {
                        if (sample instanceof DataSampleImpl) {
                            ((DataSampleImpl) sample).release();
                        }
                    }
                } else {
                    // 缓冲区为空，短暂休眠
                    Thread.sleep(1);
                }
            } catch (Exception e) {
                if (e instanceof StorageException) {
                    for (ObserverEventListener listener : eventListeners) {
                        listener.onStorageError((StorageException) e);
                    }
                }
            }
        }
    }
    
    private SourceMetadata[] getAllSourceMetadata() {
        return sources.values().stream()
            .map(ObservableSource::getMetadata)
            .toArray(SourceMetadata[]::new);
    }
}

/**
 * ============================================
 * 存储工厂
 * ============================================
 */
class StorageFactory {
    public static DataStorage createStorage(String format) {
        switch (format.toUpperCase()) {
            case "MDF4":
                return new MDF4DataStorage();
            case "CSV":
                return new CSVDataStorage();
            case "HDF5":
                return new HDF5DataStorage();
            default:
                throw new IllegalArgumentException("Unknown storage format: " + format);
        }
    }
}

/**
 * ============================================
 * 序列化器工厂
 * ============================================
 */
class SerializerFactory {
    public static DataSerializer createSerializer(String format) {
        switch (format.toUpperCase()) {
            case "MDF4":
                return new MDF4DataSerializer();
            case "CSV":
                return new CSVDataSerializer();
            case "HDF5":
                return new HDF5DataSerializer();
            default:
                throw new IllegalArgumentException("Unknown serializer format: " + format);
        }
    }
}
