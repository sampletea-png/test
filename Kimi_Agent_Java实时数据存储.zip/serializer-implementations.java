package com.dataobserver.serialization;

import java.nio.*;
import java.util.*;

/**
 * ============================================
 * 抽象数据序列化器基类
 * ============================================
 */
public abstract class AbstractDataSerializer implements DataSerializer {
    
    protected static final int TIMESTAMP_SIZE = 8; // long类型时间戳
    protected static final int TYPE_SIZE = 4;      // int类型数据类型
    protected static final int LENGTH_SIZE = 4;    // int类型长度（变长数据）
    
    /**
     * 计算序列化后的大小
     */
    protected int calculateSerializedSize(DataSample sample) {
        int dataSize = sample.getSizeInBytes();
        int totalSize = TIMESTAMP_SIZE + TYPE_SIZE;
        
        if (sample.getDataType().isArray() || sample.getDataType() == DataType.STRING) {
            totalSize += LENGTH_SIZE + dataSize;
        } else {
            totalSize += dataSize;
        }
        
        return totalSize;
    }
    
    /**
     * 将数据值写入ByteBuffer
     */
    protected void writeValue(ByteBuffer buffer, DataSample sample) {
        Object value = sample.getValue();
        DataType type = sample.getDataType();
        
        if (value == null) {
            return;
        }
        
        switch (type) {
            case INT8:
            case UINT8:
                buffer.put(((Number) value).byteValue());
                break;
            case INT16:
            case UINT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case INT32:
            case UINT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case INT64:
            case UINT64:
                buffer.putLong(((Number) value).longValue());
                break;
            case FLOAT32:
                buffer.putFloat(((Number) value).floatValue());
                break;
            case FLOAT64:
                buffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                buffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            case STRING:
                writeString(buffer, (String) value);
                break;
            case INT8_ARRAY:
            case UINT8_ARRAY:
                writeByteArray(buffer, (byte[]) value);
                break;
            case INT16_ARRAY:
            case UINT16_ARRAY:
                writeShortArray(buffer, (short[]) value);
                break;
            case INT32_ARRAY:
            case UINT32_ARRAY:
                writeIntArray(buffer, (int[]) value);
                break;
            case FLOAT32_ARRAY:
                writeFloatArray(buffer, (float[]) value);
                break;
            case FLOAT64_ARRAY:
                writeDoubleArray(buffer, (double[]) value);
                break;
        }
    }
    
    protected void writeString(ByteBuffer buffer, String value) {
        byte[] bytes = value.getBytes();
        buffer.putInt(bytes.length);
        buffer.put(bytes);
    }
    
    protected void writeByteArray(ByteBuffer buffer, byte[] value) {
        buffer.putInt(value.length);
        buffer.put(value);
    }
    
    protected void writeShortArray(ByteBuffer buffer, short[] value) {
        buffer.putInt(value.length);
        for (short s : value) {
            buffer.putShort(s);
        }
    }
    
    protected void writeIntArray(ByteBuffer buffer, int[] value) {
        buffer.putInt(value.length);
        for (int i : value) {
            buffer.putInt(i);
        }
    }
    
    protected void writeFloatArray(ByteBuffer buffer, float[] value) {
        buffer.putInt(value.length);
        for (float f : value) {
            buffer.putFloat(f);
        }
    }
    
    protected void writeDoubleArray(ByteBuffer buffer, double[] value) {
        buffer.putInt(value.length);
        for (double d : value) {
            buffer.putDouble(d);
        }
    }
    
    /**
     * 从ByteBuffer读取数据值
     */
    protected Object readValue(ByteBuffer buffer, DataType type) {
        switch (type) {
            case INT8:
                return buffer.get();
            case UINT8:
                return buffer.get() & 0xFF;
            case INT16:
                return buffer.getShort();
            case UINT16:
                return buffer.getShort() & 0xFFFF;
            case INT32:
                return buffer.getInt();
            case UINT32:
                return buffer.getInt() & 0xFFFFFFFFL;
            case INT64:
                return buffer.getLong();
            case UINT64:
                return buffer.getLong(); // Java无符号long需特殊处理
            case FLOAT32:
                return buffer.getFloat();
            case FLOAT64:
                return buffer.getDouble();
            case BOOLEAN:
                return buffer.get() != 0;
            case STRING:
                return readString(buffer);
            case INT8_ARRAY:
            case UINT8_ARRAY:
                return readByteArray(buffer);
            case INT16_ARRAY:
            case UINT16_ARRAY:
                return readShortArray(buffer);
            case INT32_ARRAY:
            case UINT32_ARRAY:
                return readIntArray(buffer);
            case FLOAT32_ARRAY:
                return readFloatArray(buffer);
            case FLOAT64_ARRAY:
                return readDoubleArray(buffer);
            default:
                return null;
        }
    }
    
    protected String readString(ByteBuffer buffer) {
        int length = buffer.getInt();
        byte[] bytes = new byte[length];
        buffer.get(bytes);
        return new String(bytes);
    }
    
    protected byte[] readByteArray(ByteBuffer buffer) {
        int length = buffer.getInt();
        byte[] arr = new byte[length];
        buffer.get(arr);
        return arr;
    }
    
    protected short[] readShortArray(ByteBuffer buffer) {
        int length = buffer.getInt();
        short[] arr = new short[length];
        for (int i = 0; i < length; i++) {
            arr[i] = buffer.getShort();
        }
        return arr;
    }
    
    protected int[] readIntArray(ByteBuffer buffer) {
        int length = buffer.getInt();
        int[] arr = new int[length];
        for (int i = 0; i < length; i++) {
            arr[i] = buffer.getInt();
        }
        return arr;
    }
    
    protected float[] readFloatArray(ByteBuffer buffer) {
        int length = buffer.getInt();
        float[] arr = new float[length];
        for (int i = 0; i < length; i++) {
            arr[i] = buffer.getFloat();
        }
        return arr;
    }
    
    protected double[] readDoubleArray(ByteBuffer buffer) {
        int length = buffer.getInt();
        double[] arr = new double[length];
        for (int i = 0; i < length; i++) {
            arr[i] = buffer.getDouble();
        }
        return arr;
    }
}

/**
 * ============================================
 * MDF4数据序列化器
 * ============================================
 */
public class MDF4DataSerializer extends AbstractDataSerializer {
    
    @Override
    public byte[] serialize(DataSample sample) {
        int size = calculateSerializedSize(sample);
        ByteBuffer buffer = ByteBuffer.allocate(size);
        
        // 写入时间戳（纳秒）
        buffer.putLong(sample.getTimestampNanos());
        
        // 写入数据类型
        buffer.putInt(sample.getDataType().ordinal());
        
        // 写入数据值
        writeValue(buffer, sample);
        
        buffer.flip();
        byte[] result = new byte[buffer.remaining()];
        buffer.get(result);
        return result;
    }
    
    @Override
    public DataSample deserialize(byte[] data, SourceMetadata metadata) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        
        // 读取时间戳
        long timestamp = buffer.getLong();
        
        // 读取数据类型
        int typeOrdinal = buffer.getInt();
        DataType type = DataType.values()[typeOrdinal];
        
        // 读取数据值
        Object value = readValue(buffer, type);
        
        // 创建数据样本（注意：这里使用create而不是acquire，因为需要指定时间戳）
        DataSampleImpl sample = DataSampleImpl.create(metadata.getId(), type, value);
        
        return sample;
    }
    
    @Override
    public String getFormatName() {
        return "MDF4";
    }
}

/**
 * ============================================
 * CSV数据序列化器
 * ============================================
 */
public class CSVDataSerializer implements DataSerializer {
    
    private static final String DELIMITER = ",";
    private static final String ARRAY_DELIMITER = ";";
    
    @Override
    public byte[] serialize(DataSample sample) {
        StringBuilder sb = new StringBuilder();
        
        // 时间戳
        sb.append(sample.getTimestampNanos());
        sb.append(DELIMITER);
        
        // 数据值
        appendValue(sb, sample);
        
        sb.append("\n");
        return sb.toString().getBytes();
    }
    
    private void appendValue(StringBuilder sb, DataSample sample) {
        Object value = sample.getValue();
        DataType type = sample.getDataType();
        
        if (value == null) {
            return;
        }
        
        if (type.isArray()) {
            sb.append("\"");
            if (value instanceof byte[]) {
                byte[] arr = (byte[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(ARRAY_DELIMITER);
                    sb.append(arr[i]);
                }
            } else if (value instanceof short[]) {
                short[] arr = (short[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(ARRAY_DELIMITER);
                    sb.append(arr[i]);
                }
            } else if (value instanceof int[]) {
                int[] arr = (int[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(ARRAY_DELIMITER);
                    sb.append(arr[i]);
                }
            } else if (value instanceof float[]) {
                float[] arr = (float[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(ARRAY_DELIMITER);
                    sb.append(arr[i]);
                }
            } else if (value instanceof double[]) {
                double[] arr = (double[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) sb.append(ARRAY_DELIMITER);
                    sb.append(arr[i]);
                }
            }
            sb.append("\"");
        } else if (value instanceof String) {
            String str = (String) value;
            if (str.contains(DELIMITER) || str.contains("\"") || str.contains("\n")) {
                sb.append("\"").append(str.replace("\"", "\"\"")).append("\"");
            } else {
                sb.append(str);
            }
        } else {
            sb.append(value.toString());
        }
    }
    
    @Override
    public DataSample deserialize(byte[] data, SourceMetadata metadata) {
        // CSV反序列化较复杂，需要解析整行
        // 简化实现：假设只包含时间戳和单个值
        String line = new String(data).trim();
        String[] parts = line.split(DELIMITER, 2);
        
        if (parts.length < 2) {
            return null;
        }
        
        long timestamp = Long.parseLong(parts[0]);
        Object value = parseValue(parts[1], metadata.getDataType());
        
        return DataSampleImpl.create(metadata.getId(), metadata.getDataType(), value);
    }
    
    private Object parseValue(String str, DataType type) {
        str = str.trim();
        if (str.startsWith("\"") && str.endsWith("\"")) {
            str = str.substring(1, str.length() - 1);
        }
        
        switch (type) {
            case INT8:
            case UINT8:
                return Byte.parseByte(str);
            case INT16:
            case UINT16:
                return Short.parseShort(str);
            case INT32:
            case UINT32:
                return Integer.parseInt(str);
            case INT64:
            case UINT64:
                return Long.parseLong(str);
            case FLOAT32:
                return Float.parseFloat(str);
            case FLOAT64:
                return Double.parseDouble(str);
            case BOOLEAN:
                return Boolean.parseBoolean(str);
            case STRING:
                return str;
            case INT8_ARRAY:
            case UINT8_ARRAY:
                return parseByteArray(str);
            case FLOAT32_ARRAY:
                return parseFloatArray(str);
            case FLOAT64_ARRAY:
                return parseDoubleArray(str);
            default:
                return str;
        }
    }
    
    private byte[] parseByteArray(String str) {
        String[] parts = str.split(ARRAY_DELIMITER);
        byte[] arr = new byte[parts.length];
        for (int i = 0; i < parts.length; i++) {
            arr[i] = Byte.parseByte(parts[i].trim());
        }
        return arr;
    }
    
    private float[] parseFloatArray(String str) {
        String[] parts = str.split(ARRAY_DELIMITER);
        float[] arr = new float[parts.length];
        for (int i = 0; i < parts.length; i++) {
            arr[i] = Float.parseFloat(parts[i].trim());
        }
        return arr;
    }
    
    private double[] parseDoubleArray(String str) {
        String[] parts = str.split(ARRAY_DELIMITER);
        double[] arr = new double[parts.length];
        for (int i = 0; i < parts.length; i++) {
            arr[i] = Double.parseDouble(parts[i].trim());
        }
        return arr;
    }
    
    @Override
    public String getFormatName() {
        return "CSV";
    }
}

/**
 * ============================================
 * HDF5数据序列化器（框架）
 * ============================================
 */
public class HDF5DataSerializer extends AbstractDataSerializer {
    
    @Override
    public byte[] serialize(DataSample sample) {
        // HDF5序列化需要使用HDF5库
        // 这里返回简化实现
        return serializeToByteArray(sample);
    }
    
    private byte[] serializeToByteArray(DataSample sample) {
        int size = calculateSerializedSize(sample);
        ByteBuffer buffer = ByteBuffer.allocate(size);
        
        buffer.putLong(sample.getTimestampNanos());
        buffer.putInt(sample.getDataType().ordinal());
        writeValue(buffer, sample);
        
        buffer.flip();
        byte[] result = new byte[buffer.remaining()];
        buffer.get(result);
        return result;
    }
    
    @Override
    public DataSample deserialize(byte[] data, SourceMetadata metadata) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        
        long timestamp = buffer.getLong();
        int typeOrdinal = buffer.getInt();
        DataType type = DataType.values()[typeOrdinal];
        Object value = readValue(buffer, type);
        
        return DataSampleImpl.create(metadata.getId(), type, value);
    }
    
    @Override
    public String getFormatName() {
        return "HDF5";
    }
}

/**
 * ============================================
 * JSON数据序列化器（用于调试和网络传输）
 * ============================================
 */
public class JSONDataSerializer implements DataSerializer {
    
    @Override
    public byte[] serialize(DataSample sample) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"sourceId\":\"").append(escapeJson(sample.getSourceId())).append("\",");
        json.append("\"timestampNanos\":").append(sample.getTimestampNanos()).append(",");
        json.append("\"dataType\":\"").append(sample.getDataType().name()).append("\",");
        json.append("\"value\":");
        appendJsonValue(json, sample);
        json.append("}");
        
        return json.toString().getBytes();
    }
    
    private void appendJsonValue(StringBuilder json, DataSample sample) {
        Object value = sample.getValue();
        DataType type = sample.getDataType();
        
        if (value == null) {
            json.append("null");
            return;
        }
        
        if (type.isArray()) {
            json.append("[");
            if (value instanceof byte[]) {
                byte[] arr = (byte[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) json.append(",");
                    json.append(arr[i]);
                }
            } else if (value instanceof short[]) {
                short[] arr = (short[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) json.append(",");
                    json.append(arr[i]);
                }
            } else if (value instanceof int[]) {
                int[] arr = (int[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) json.append(",");
                    json.append(arr[i]);
                }
            } else if (value instanceof float[]) {
                float[] arr = (float[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) json.append(",");
                    json.append(arr[i]);
                }
            } else if (value instanceof double[]) {
                double[] arr = (double[]) value;
                for (int i = 0; i < arr.length; i++) {
                    if (i > 0) json.append(",");
                    json.append(arr[i]);
                }
            }
            json.append("]");
        } else if (value instanceof String) {
            json.append("\"").append(escapeJson((String) value)).append("\"");
        } else if (value instanceof Boolean) {
            json.append(value);
        } else {
            json.append(value.toString());
        }
    }
    
    private String escapeJson(String str) {
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\b", "\\b")
                  .replace("\f", "\\f")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
    
    @Override
    public DataSample deserialize(byte[] data, SourceMetadata metadata) {
        // JSON反序列化需要完整JSON解析器
        // 简化实现：返回null，实际应使用Jackson或Gson
        throw new UnsupportedOperationException("JSON deserialization requires JSON parser library");
    }
    
    @Override
    public String getFormatName() {
        return "JSON";
    }
}
