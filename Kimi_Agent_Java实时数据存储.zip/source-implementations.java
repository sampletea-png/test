package com.dataobserver.source;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.lang.reflect.*;

/**
 * ============================================
 * 抽象可观察数据源基类
 * ============================================
 */
public abstract class AbstractObservableSource implements ObservableSource {
    
    protected final SourceMetadata metadata;
    protected final Set<DataChangeListener> listeners = ConcurrentHashMap.newKeySet();
    protected final AtomicBoolean available = new AtomicBoolean(true);
    protected final AtomicBoolean running = new AtomicBoolean(false);
    
    // 周期性采样相关
    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> scheduledTask;
    
    protected AbstractObservableSource(SourceMetadata metadata) {
        this.metadata = metadata;
    }
    
    @Override
    public SourceMetadata getMetadata() {
        return metadata;
    }
    
    @Override
    public void addChangeListener(DataChangeListener listener) {
        listeners.add(listener);
    }
    
    @Override
    public void removeChangeListener(DataChangeListener listener) {
        listeners.remove(listener);
    }
    
    @Override
    public boolean isAvailable() {
        return available.get();
    }
    
    @Override
    public void start() {
        if (running.compareAndSet(false, true)) {
            double sampleRate = metadata.getSampleRate();
            if (sampleRate > 0) {
                // 周期性采样源
                long periodMs = (long) (1000.0 / sampleRate);
                scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "Source-" + metadata.getId());
                    t.setDaemon(true);
                    return t;
                });
                scheduledTask = scheduler.scheduleAtFixedRate(
                    this::doSample, 0, periodMs, TimeUnit.MILLISECONDS);
            }
        }
    }
    
    @Override
    public void stop() {
        if (running.compareAndSet(true, false)) {
            if (scheduledTask != null) {
                scheduledTask.cancel(false);
            }
            if (scheduler != null) {
                scheduler.shutdown();
            }
        }
    }
    
    /**
     * 执行采样（由子类实现具体采样逻辑）
     */
    protected abstract Object doSample();
    
    /**
     * 通知所有监听器数据变化
     */
    protected void notifyListeners(DataSample sample) {
        for (DataChangeListener listener : listeners) {
            try {
                listener.onDataChanged(this, sample);
            } catch (Exception e) {
                // 日志记录，但不中断其他监听器
            }
        }
    }
    
    /**
     * 创建数据样本
     */
    protected DataSample createSample(Object value) {
        return DataSampleImpl.create(metadata.getId(), metadata.getDataType(), value);
    }
}

/**
 * ============================================
 * 字段数据源 - 通过反射观察对象字段
 * ============================================
 */
public class FieldObservableSource extends AbstractObservableSource {
    
    private final Object target;
    private final Field field;
    
    public FieldObservableSource(SourceMetadata metadata, Object target, String fieldName) 
            throws NoSuchFieldException {
        super(metadata);
        this.target = target;
        this.field = target.getClass().getDeclaredField(fieldName);
        this.field.setAccessible(true);
    }
    
    public FieldObservableSource(SourceMetadata metadata, Object target, Field field) {
        super(metadata);
        this.target = target;
        this.field = field;
        this.field.setAccessible(true);
    }
    
    @Override
    public Object getCurrentValue() {
        try {
            return field.get(target);
        } catch (IllegalAccessException e) {
            available.set(false);
            return null;
        }
    }
    
    @Override
    public DataSample readSample() {
        Object value = getCurrentValue();
        if (value != null) {
            return createSample(value);
        }
        return null;
    }
    
    @Override
    protected Object doSample() {
        DataSample sample = readSample();
        if (sample != null) {
            notifyListeners(sample);
        }
        return sample != null ? sample.getValue() : null;
    }
}

/**
 * ============================================
 * 方法数据源 - 通过调用方法获取数据
 * ============================================
 */
public class MethodObservableSource extends AbstractObservableSource {
    
    private final Object target;
    private final Method method;
    private final Object[] args;
    
    public MethodObservableSource(SourceMetadata metadata, Object target, String methodName) 
            throws NoSuchMethodException {
        this(metadata, target, methodName, new Class<?>[0]);
    }
    
    public MethodObservableSource(SourceMetadata metadata, Object target, String methodName, 
            Class<?>[] paramTypes, Object... args) throws NoSuchMethodException {
        super(metadata);
        this.target = target;
        this.method = target.getClass().getMethod(methodName, paramTypes);
        this.method.setAccessible(true);
        this.args = args;
    }
    
    @Override
    public Object getCurrentValue() {
        try {
            return method.invoke(target, args);
        } catch (Exception e) {
            available.set(false);
            return null;
        }
    }
    
    @Override
    public DataSample readSample() {
        Object value = getCurrentValue();
        if (value != null) {
            return createSample(value);
        }
        return null;
    }
    
    @Override
    protected Object doSample() {
        DataSample sample = readSample();
        if (sample != null) {
            notifyListeners(sample);
        }
        return sample != null ? sample.getValue() : null;
    }
}

/**
 * ============================================
 * 函数式数据源 - 通过Supplier提供数据
 * ============================================
 */
public class SupplierObservableSource<T> extends AbstractObservableSource {
    
    private final java.util.function.Supplier<T> supplier;
    
    public SupplierObservableSource(SourceMetadata metadata, java.util.function.Supplier<T> supplier) {
        super(metadata);
        this.supplier = supplier;
    }
    
    @Override
    public Object getCurrentValue() {
        try {
            return supplier.get();
        } catch (Exception e) {
            available.set(false);
            return null;
        }
    }
    
    @Override
    public DataSample readSample() {
        Object value = getCurrentValue();
        if (value != null) {
            return createSample(value);
        }
        return null;
    }
    
    @Override
    protected Object doSample() {
        DataSample sample = readSample();
        if (sample != null) {
            notifyListeners(sample);
        }
        return sample != null ? sample.getValue() : null;
    }
}

/**
 * ============================================
 * 代理数据源 - 包装其他数据源并添加转换
 * ============================================
 */
public class ProxyObservableSource implements ObservableSource {
    
    private final ObservableSource delegate;
    private final java.util.function.Function<Object, Object> transformer;
    private final SourceMetadata proxyMetadata;
    
    public ProxyObservableSource(ObservableSource delegate, 
            java.util.function.Function<Object, Object> transformer,
            SourceMetadata proxyMetadata) {
        this.delegate = delegate;
        this.transformer = transformer;
        this.proxyMetadata = proxyMetadata;
    }
    
    @Override
    public SourceMetadata getMetadata() {
        return proxyMetadata;
    }
    
    @Override
    public Object getCurrentValue() {
        Object value = delegate.getCurrentValue();
        return value != null ? transformer.apply(value) : null;
    }
    
    @Override
    public DataSample readSample() {
        Object value = getCurrentValue();
        if (value != null) {
            return DataSampleImpl.create(proxyMetadata.getId(), proxyMetadata.getDataType(), value);
        }
        return null;
    }
    
    @Override
    public void addChangeListener(DataChangeListener listener) {
        // 包装监听器以应用转换
        delegate.addChangeListener((source, sample) -> {
            Object transformedValue = transformer.apply(sample.getValue());
            DataSample transformedSample = DataSampleImpl.create(
                proxyMetadata.getId(), proxyMetadata.getDataType(), transformedValue);
            listener.onDataChanged(this, transformedSample);
        });
    }
    
    @Override
    public void removeChangeListener(DataChangeListener listener) {
        delegate.removeChangeListener(listener);
    }
    
    @Override
    public boolean isAvailable() {
        return delegate.isAvailable();
    }
    
    @Override
    public void start() {
        delegate.start();
    }
    
    @Override
    public void stop() {
        delegate.stop();
    }
}

/**
 * ============================================
 * 组合数据源 - 组合多个数据源
 * ============================================
 */
public class CompositeObservableSource implements ObservableSource {
    
    private final SourceMetadata metadata;
    private final List<ObservableSource> sources;
    private final java.util.function.Function<List<Object>, Object> combiner;
    
    public CompositeObservableSource(SourceMetadata metadata, 
            List<ObservableSource> sources,
            java.util.function.Function<List<Object>, Object> combiner) {
        this.metadata = metadata;
        this.sources = new ArrayList<>(sources);
        this.combiner = combiner;
    }
    
    @Override
    public SourceMetadata getMetadata() {
        return metadata;
    }
    
    @Override
    public Object getCurrentValue() {
        List<Object> values = new ArrayList<>(sources.size());
        for (ObservableSource source : sources) {
            values.add(source.getCurrentValue());
        }
        return combiner.apply(values);
    }
    
    @Override
    public DataSample readSample() {
        Object value = getCurrentValue();
        if (value != null) {
            return DataSampleImpl.create(metadata.getId(), metadata.getDataType(), value);
        }
        return null;
    }
    
    @Override
    public void addChangeListener(DataChangeListener listener) {
        // 为每个子源添加监听器
        for (ObservableSource source : sources) {
            source.addChangeListener((s, sample) -> {
                // 当任一源变化时，重新计算组合值
                DataSample combinedSample = readSample();
                if (combinedSample != null) {
                    listener.onDataChanged(this, combinedSample);
                }
            });
        }
    }
    
    @Override
    public void removeChangeListener(DataChangeListener listener) {
        for (ObservableSource source : sources) {
            source.removeChangeListener(listener);
        }
    }
    
    @Override
    public boolean isAvailable() {
        return sources.stream().allMatch(ObservableSource::isAvailable);
    }
    
    @Override
    public void start() {
        for (ObservableSource source : sources) {
            source.start();
        }
    }
    
    @Override
    public void stop() {
        for (ObservableSource source : sources) {
            source.stop();
        }
    }
}

/**
 * ============================================
 * 数据源构建器（Builder模式）
 * ============================================
 */
public class ObservableSourceBuilder {
    
    private String id;
    private String name;
    private String description = "";
    private DataType dataType;
    private double sampleRate = 0;
    private String unit = "";
    private Double minValue;
    private Double maxValue;
    
    public static ObservableSourceBuilder create(String id, DataType dataType) {
        return new ObservableSourceBuilder(id, dataType);
    }
    
    private ObservableSourceBuilder(String id, DataType dataType) {
        this.id = id;
        this.dataType = dataType;
        this.name = id;
    }
    
    public ObservableSourceBuilder name(String name) {
        this.name = name;
        return this;
    }
    
    public ObservableSourceBuilder description(String description) {
        this.description = description;
        return this;
    }
    
    public ObservableSourceBuilder sampleRate(double rateHz) {
        this.sampleRate = rateHz;
        return this;
    }
    
    public ObservableSourceBuilder unit(String unit) {
        this.unit = unit;
        return this;
    }
    
    public ObservableSourceBuilder range(double min, double max) {
        this.minValue = min;
        this.maxValue = max;
        return this;
    }
    
    private SourceMetadata buildMetadata() {
        SourceMetadataImpl.Builder builder = SourceMetadataImpl.builder(id, dataType)
            .name(name)
            .description(description)
            .sampleRate(sampleRate)
            .unit(unit);
        
        if (minValue != null && maxValue != null) {
            builder.range(minValue, maxValue);
        }
        
        return builder.build();
    }
    
    /**
     * 构建字段数据源
     */
    public FieldObservableSource fromField(Object target, String fieldName) 
            throws NoSuchFieldException {
        return new FieldObservableSource(buildMetadata(), target, fieldName);
    }
    
    /**
     * 构建方法数据源
     */
    public MethodObservableSource fromMethod(Object target, String methodName) 
            throws NoSuchMethodException {
        return new MethodObservableSource(buildMetadata(), target, methodName);
    }
    
    /**
     * 构建方法数据源（带参数）
     */
    public MethodObservableSource fromMethod(Object target, String methodName, 
            Class<?>[] paramTypes, Object... args) throws NoSuchMethodException {
        return new MethodObservableSource(buildMetadata(), target, methodName, paramTypes, args);
    }
    
    /**
     * 构建函数式数据源
     */
    public <T> SupplierObservableSource<T> fromSupplier(java.util.function.Supplier<T> supplier) {
        return new SupplierObservableSource<>(buildMetadata(), supplier);
    }
}

/**
 * ============================================
 * 数据源工厂
 * ============================================
 */
public class ObservableSourceFactory {
    
    /**
     * 从对象的所有字段创建数据源
     */
    public static List<ObservableSource> fromObjectFields(Object target, String... fieldNames) {
        List<ObservableSource> sources = new ArrayList<>();
        
        for (String fieldName : fieldNames) {
            try {
                Field field = target.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);
                
                DataType dataType = inferDataType(field.getType());
                SourceMetadata metadata = SourceMetadataImpl.builder(fieldName, dataType)
                    .name(fieldName)
                    .build();
                
                sources.add(new FieldObservableSource(metadata, target, field));
            } catch (NoSuchFieldException e) {
                // 跳过不存在的字段
            }
        }
        
        return sources;
    }
    
    /**
     * 从对象的所有数值字段自动创建数据源
     */
    public static List<ObservableSource> fromObjectNumericFields(Object target) {
        List<ObservableSource> sources = new ArrayList<>();
        
        for (Field field : target.getClass().getDeclaredFields()) {
            if (isNumericType(field.getType())) {
                field.setAccessible(true);
                
                DataType dataType = inferDataType(field.getType());
                SourceMetadata metadata = SourceMetadataImpl.builder(field.getName(), dataType)
                    .name(field.getName())
                    .build();
                
                sources.add(new FieldObservableSource(metadata, target, field));
            }
        }
        
        return sources;
    }
    
    private static DataType inferDataType(Class<?> type) {
        if (type == byte.class || type == Byte.class) return DataType.INT8;
        if (type == short.class || type == Short.class) return DataType.INT16;
        if (type == int.class || type == Integer.class) return DataType.INT32;
        if (type == long.class || type == Long.class) return DataType.INT64;
        if (type == float.class || type == Float.class) return DataType.FLOAT32;
        if (type == double.class || type == Double.class) return DataType.FLOAT64;
        if (type == boolean.class || type == Boolean.class) return DataType.BOOLEAN;
        if (type == String.class) return DataType.STRING;
        if (type.isArray()) {
            Class<?> componentType = type.getComponentType();
            if (componentType == float.class) return DataType.FLOAT32_ARRAY;
            if (componentType == double.class) return DataType.FLOAT64_ARRAY;
            if (componentType == int.class) return DataType.INT32_ARRAY;
        }
        return DataType.STRING;
    }
    
    private static boolean isNumericType(Class<?> type) {
        return type == byte.class || type == Byte.class ||
               type == short.class || type == Short.class ||
               type == int.class || type == Integer.class ||
               type == long.class || type == Long.class ||
               type == float.class || type == Float.class ||
               type == double.class || type == Double.class;
    }
}
