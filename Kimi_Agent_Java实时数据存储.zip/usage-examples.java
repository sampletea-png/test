package com.dataobserver.examples;

/**
 * ============================================
 * 使用示例
 * ============================================
 */

/**
 * 示例1: 基本使用 - 观察简单数值
 */
public class BasicUsageExample {
    
    public static void main(String[] args) throws Exception {
        // 1. 创建数据观察器
        DataObserver observer = new DataObserverImpl();
        
        // 2. 配置观察器
        ObserverConfig config = ObserverConfig.builder()
            .storagePath("./output/data")
            .storageFormat("MDF4")
            .bufferSize(1024 * 1024)  // 1MB缓冲区
            .bufferCount(16)
            .flushIntervalMs(1000)    // 1秒刷新
            .batchSize(1000)
            .compressionEnabled(true)
            .compressionLevel(6)
            .asyncWrite(true)
            .build();
        
        observer.initialize(config);
        
        // 3. 创建被观察对象
        SensorData sensor = new SensorData();
        
        // 4. 注册数据源
        // 4.1 观察字段
        ObservableSource temperatureSource = ObservableSourceBuilder
            .create("temp_01", DataType.FLOAT32)
            .name("Temperature")
            .description("环境温度传感器")
            .unit("°C")
            .range(-40.0, 125.0)
            .sampleRate(10)  // 10Hz采样
            .fromField(sensor, "temperature");
        
        ObservableSource pressureSource = ObservableSourceBuilder
            .create("pressure_01", DataType.FLOAT32)
            .name("Pressure")
            .description("气压传感器")
            .unit("kPa")
            .range(0.0, 200.0)
            .sampleRate(10)
            .fromField(sensor, "pressure");
        
        observer.registerSource(temperatureSource);
        observer.registerSource(pressureSource);
        
        // 4.2 使用方法数据源
        ObservableSource statusSource = ObservableSourceBuilder
            .create("status_01", DataType.STRING)
            .name("SystemStatus")
            .fromMethod(sensor, "getStatus");
        
        observer.registerSource(statusSource);
        
        // 4.3 使用函数式数据源
        ObservableSource counterSource = ObservableSourceBuilder
            .create("counter_01", DataType.INT32)
            .name("SampleCounter")
            .sampleRate(1)
            .fromSupplier(() -> sensor.getSampleCount());
        
        observer.registerSource(counterSource);
        
        // 5. 添加事件监听器
        observer.addEventListener(new ObserverEventListener() {
            @Override
            public void onSourceRegistered(String sourceId, SourceMetadata metadata) {
                System.out.println("Source registered: " + sourceId + " (" + metadata.getName() + ")");
            }
            
            @Override
            public void onSourceUnregistered(String sourceId) {
                System.out.println("Source unregistered: " + sourceId);
            }
            
            @Override
            public void onDataCollected(String sourceId, long timestamp) {
                // 高频事件，避免打印
            }
            
            @Override
            public void onBufferFull() {
                System.err.println("Warning: Buffer full!");
            }
            
            @Override
            public void onStorageError(StorageException error) {
                System.err.println("Storage error: " + error.getMessage());
            }
            
            @Override
            public void onStateChanged(ObserverState oldState, ObserverState newState) {
                System.out.println("State changed: " + oldState + " -> " + newState);
            }
        });
        
        // 6. 启动观察
        observer.start();
        
        // 7. 模拟数据采集
        System.out.println("Starting data collection for 10 seconds...");
        for (int i = 0; i < 100; i++) {
            sensor.update();  // 更新传感器数据
            Thread.sleep(100);
        }
        
        // 8. 获取统计信息
        ObserverStats stats = observer.getStats();
        System.out.println("\n=== Collection Statistics ===");
        System.out.println("Total sources: " + stats.getTotalSources());
        System.out.println("Active sources: " + stats.getActiveSources());
        System.out.println("Total samples: " + stats.getTotalSamples());
        System.out.println("Total bytes: " + stats.getTotalBytes());
        System.out.println("Buffer utilization: " + stats.getBufferUtilization() + "%");
        
        // 9. 停止观察
        observer.stop();
        System.out.println("\nData collection completed.");
    }
    
    /**
     * 传感器数据类
     */
    public static class SensorData {
        private float temperature = 25.0f;
        private float pressure = 101.3f;
        private int sampleCount = 0;
        
        public void update() {
            // 模拟传感器数据变化
            temperature += (Math.random() - 0.5) * 2;  // ±1度变化
            pressure += (Math.random() - 0.5) * 0.5;   // ±0.25kPa变化
            sampleCount++;
        }
        
        public float getTemperature() { return temperature; }
        public float getPressure() { return pressure; }
        public int getSampleCount() { return sampleCount; }
        
        public String getStatus() {
            return String.format("T=%.2f°C, P=%.2fkPa, Count=%d", 
                temperature, pressure, sampleCount);
        }
    }
}

/**
 * 示例2: 高级使用 - 数组数据和自定义转换
 */
public class AdvancedUsageExample {
    
    public static void main(String[] args) throws Exception {
        DataObserver observer = new DataObserverImpl();
        
        ObserverConfig config = ObserverConfig.builder()
            .storagePath("./output/advanced")
            .storageFormat("MDF4")
            .bufferSize(10 * 1024 * 1024)  // 10MB缓冲区（数组数据较大）
            .batchSize(100)
            .build();
        
        observer.initialize(config);
        
        // 创建信号发生器
        SignalGenerator generator = new SignalGenerator();
        
        // 1. 观察数组数据（FFT结果）
        ObservableSource fftSource = ObservableSourceBuilder
            .create("fft_01", DataType.FLOAT32_ARRAY)
            .name("FFT_Result")
            .description("FFT频谱分析结果")
            .unit("dB")
            .sampleRate(5)
            .fromField(generator, "fftResult");
        
        observer.registerSource(fftSource);
        
        // 2. 观察原始波形数据
        ObservableSource waveformSource = ObservableSourceBuilder
            .create("waveform_01", DataType.FLOAT32_ARRAY)
            .name("RawWaveform")
            .description("原始波形数据")
            .unit("V")
            .sampleRate(100)
            .fromField(generator, "waveform");
        
        observer.registerSource(waveformSource);
        
        // 3. 使用代理数据源进行数据转换
        // 从FFT结果中提取主频幅度
        ObservableSource peakAmplitudeSource = new ProxyObservableSource(
            fftSource,
            fft -> {
                float[] arr = (float[]) fft;
                float max = 0;
                for (float v : arr) {
                    if (v > max) max = v;
                }
                return max;
            },
            SourceMetadataImpl.builder("fft_peak", DataType.FLOAT32)
                .name("FFT_PeakAmplitude")
                .unit("dB")
                .build()
        );
        
        observer.registerSource(peakAmplitudeSource);
        
        // 4. 使用组合数据源
        List<ObservableSource> sources = new ArrayList<>();
        sources.add(fftSource);
        sources.add(waveformSource);
        
        ObservableSource combinedSource = new CompositeObservableSource(
            SourceMetadataImpl.builder("combined_01", DataType.FLOAT32)
                .name("CombinedMetric")
                .build(),
            sources,
            values -> {
                float[] fft = (float[]) values.get(0);
                float[] waveform = (float[]) values.get(1);
                // 计算某种组合指标
                float fftSum = 0;
                for (float v : fft) fftSum += v;
                float waveformAvg = 0;
                for (float v : waveform) waveformAvg += v;
                waveformAvg /= waveform.length;
                return fftSum * waveformAvg;
            }
        );
        
        observer.registerSource(combinedSource);
        
        // 启动并运行
        observer.start();
        
        System.out.println("Collecting array data for 5 seconds...");
        for (int i = 0; i < 50; i++) {
            generator.generate();
            Thread.sleep(100);
        }
        
        observer.stop();
        System.out.println("Array data collection completed.");
    }
    
    /**
     * 信号发生器
     */
    public static class SignalGenerator {
        private float[] fftResult = new float[512];
        private float[] waveform = new float[1024];
        
        public void generate() {
            // 模拟FFT结果
            for (int i = 0; i < fftResult.length; i++) {
                fftResult[i] = (float) (Math.random() * 100);
            }
            // 添加一些峰值
            fftResult[50] = 80 + (float) (Math.random() * 20);
            fftResult[100] = 60 + (float) (Math.random() * 20);
            
            // 模拟波形数据
            for (int i = 0; i < waveform.length; i++) {
                waveform[i] = (float) (Math.sin(i * 0.1) * 5 + Math.random());
            }
        }
        
        public float[] getFftResult() { return fftResult; }
        public float[] getWaveform() { return waveform; }
    }
}

/**
 * 示例3: 多格式存储对比
 */
public class MultiFormatExample {
    
    public static void main(String[] args) throws Exception {
        // 创建测试数据
        TestData testData = new TestData();
        
        // 测试不同存储格式
        String[] formats = {"MDF4", "CSV"};
        
        for (String format : formats) {
            System.out.println("\n=== Testing " + format + " format ===");
            
            DataObserver observer = new DataObserverImpl();
            
            ObserverConfig config = ObserverConfig.builder()
                .storagePath("./output/" + format.toLowerCase())
                .storageFormat(format)
                .bufferSize(1024 * 1024)
                .batchSize(100)
                .compressionEnabled(true)
                .build();
            
            observer.initialize(config);
            
            // 注册各种数据类型的源
            observer.registerSource(ObservableSourceBuilder
                .create("int_value", DataType.INT32)
                .fromField(testData, "intValue"));
            
            observer.registerSource(ObservableSourceBuilder
                .create("float_value", DataType.FLOAT32)
                .fromField(testData, "floatValue"));
            
            observer.registerSource(ObservableSourceBuilder
                .create("double_value", DataType.FLOAT64)
                .fromField(testData, "doubleValue"));
            
            observer.registerSource(ObservableSourceBuilder
                .create("bool_value", DataType.BOOLEAN)
                .fromField(testData, "boolValue"));
            
            observer.registerSource(ObservableSourceBuilder
                .create("string_value", DataType.STRING)
                .fromField(testData, "stringValue"));
            
            observer.registerSource(ObservableSourceBuilder
                .create("array_value", DataType.FLOAT32_ARRAY)
                .fromField(testData, "arrayValue"));
            
            // 记录开始时间
            long startTime = System.currentTimeMillis();
            
            observer.start();
            
            // 生成10000个样本
            for (int i = 0; i < 10000; i++) {
                testData.update();
                Thread.sleep(1);  // 1ms间隔
            }
            
            observer.stop();
            
            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;
            
            ObserverStats stats = observer.getStats();
            System.out.println("Format: " + format);
            System.out.println("Duration: " + duration + " ms");
            System.out.println("Total samples: " + stats.getTotalSamples());
            System.out.println("Samples per second: " + (stats.getTotalSamples() * 1000 / duration));
            System.out.println("Total bytes: " + stats.getTotalBytes());
        }
    }
    
    /**
     * 测试数据类
     */
    public static class TestData {
        private int intValue = 0;
        private float floatValue = 0.0f;
        private double doubleValue = 0.0;
        private boolean boolValue = false;
        private String stringValue = "test";
        private float[] arrayValue = new float[10];
        
        public void update() {
            intValue++;
            floatValue = (float) Math.sin(intValue * 0.1);
            doubleValue = Math.cos(intValue * 0.05);
            boolValue = !boolValue;
            stringValue = "test_" + intValue;
            for (int i = 0; i < arrayValue.length; i++) {
                arrayValue[i] = (float) (Math.random() * 100);
            }
        }
        
        public int getIntValue() { return intValue; }
        public float getFloatValue() { return floatValue; }
        public double getDoubleValue() { return doubleValue; }
        public boolean getBoolValue() { return boolValue; }
        public String getStringValue() { return stringValue; }
        public float[] getArrayValue() { return arrayValue; }
    }
}

/**
 * 示例4: 动态添加/移除观察点
 */
public class DynamicSourceExample {
    
    public static void main(String[] args) throws Exception {
        DataObserver observer = new DataObserverImpl();
        
        ObserverConfig config = ObserverConfig.builder()
            .storagePath("./output/dynamic")
            .storageFormat("MDF4")
            .build();
        
        observer.initialize(config);
        
        // 创建数据源容器
        DynamicDataContainer container = new DynamicDataContainer();
        
        // 注册初始数据源
        observer.registerSource(ObservableSourceBuilder
            .create("base_value", DataType.FLOAT32)
            .fromField(container, "baseValue"));
        
        observer.start();
        
        System.out.println("Starting with 1 source...");
        for (int i = 0; i < 20; i++) {
            container.update();
            Thread.sleep(100);
        }
        
        // 动态添加新数据源
        System.out.println("Adding new source...");
        container.addNewValue();
        ObservableSource newSource = ObservableSourceBuilder
            .create("new_value", DataType.FLOAT32)
            .fromField(container, "newValue");
        observer.registerSource(newSource);
        
        for (int i = 0; i < 20; i++) {
            container.update();
            Thread.sleep(100);
        }
        
        // 动态移除数据源
        System.out.println("Removing source...");
        observer.unregisterSource("base_value");
        
        for (int i = 0; i < 20; i++) {
            container.update();
            Thread.sleep(100);
        }
        
        observer.stop();
        
        ObserverStats stats = observer.getStats();
        System.out.println("\nFinal source count: " + stats.getTotalSources());
        System.out.println("Total samples collected: " + stats.getTotalSamples());
    }
    
    /**
     * 动态数据容器
     */
    public static class DynamicDataContainer {
        private float baseValue = 0.0f;
        private Float newValue = null;
        
        public void update() {
            baseValue += 0.1f;
            if (newValue != null) {
                newValue += 0.2f;
            }
        }
        
        public void addNewValue() {
            newValue = 0.0f;
        }
        
        public float getBaseValue() { return baseValue; }
        public Float getNewValue() { return newValue; }
    }
}

/**
 * 示例5: 性能测试
 */
public class PerformanceTestExample {
    
    public static void main(String[] args) throws Exception {
        System.out.println("=== Performance Test ===\n");
        
        // 测试参数
        int[] sampleRates = {100, 1000, 10000};  // Hz
        int[] bufferSizes = {1024, 10240, 102400};  // bytes
        
        for (int sampleRate : sampleRates) {
            for (int bufferSize : bufferSizes) {
                runPerformanceTest(sampleRate, bufferSize);
            }
        }
    }
    
    private static void runPerformanceTest(int sampleRate, int bufferSize) throws Exception {
        DataObserver observer = new DataObserverImpl();
        
        ObserverConfig config = ObserverConfig.builder()
            .storagePath("./output/perf")
            .storageFormat("MDF4")
            .bufferSize(bufferSize)
            .batchSize(sampleRate / 10)  // 每100ms批量写入
            .compressionEnabled(false)  // 禁用压缩以测试原始性能
            .build();
        
        observer.initialize(config);
        
        // 创建高性能数据源
        HighPerformanceData data = new HighPerformanceData();
        
        // 注册多个数据源
        for (int i = 0; i < 10; i++) {
            final int index = i;
            observer.registerSource(ObservableSourceBuilder
                .create("perf_" + i, DataType.FLOAT32)
                .sampleRate(sampleRate)
                .fromSupplier(() -> data.getValue(index)));
        }
        
        // 预热
        observer.start();
        Thread.sleep(100);
        
        // 正式测试
        long startTime = System.nanoTime();
        long testDurationMs = 5000;  // 5秒测试
        
        Thread.sleep(testDurationMs);
        
        long endTime = System.nanoTime();
        
        observer.stop();
        
        // 计算性能指标
        ObserverStats stats = observer.getStats();
        long totalSamples = stats.getTotalSamples();
        double durationSeconds = (endTime - startTime) / 1_000_000_000.0;
        double samplesPerSecond = totalSamples / durationSeconds;
        double mbPerSecond = (stats.getTotalBytes() / (1024.0 * 1024.0)) / durationSeconds;
        
        System.out.printf("SampleRate: %d Hz, BufferSize: %d bytes%n", sampleRate, bufferSize);
        System.out.printf("  Total samples: %d%n", totalSamples);
        System.out.printf("  Duration: %.2f s%n", durationSeconds);
        System.out.printf("  Samples/sec: %.0f%n", samplesPerSecond);
        System.out.printf("  Data rate: %.2f MB/s%n", mbPerSecond);
        System.out.printf("  Dropped samples: %d%n", stats.getDroppedSamples());
        System.out.printf("  Buffer utilization: %d%%%n%n", stats.getBufferUtilization());
    }
    
    /**
     * 高性能测试数据
     */
    public static class HighPerformanceData {
        private final float[] values = new float[10];
        
        public float getValue(int index) {
            values[index] = (float) (Math.random() * 1000);
            return values[index];
        }
    }
}
