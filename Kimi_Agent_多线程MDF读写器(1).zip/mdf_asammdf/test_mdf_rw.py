# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器综合测试模块

测试策略:
    本模块采用分层测试策略，覆盖单元测试、集成测试和压力测试三个层次：
    - 单元测试：针对单个类和方法的独立测试
    - 集成测试：验证写入器和读取器的端到端协作
    - 压力测试：大数据量和高并发场景下的稳定性验证

覆盖场景（14个测试类，57+测试用例）:
    1. 配置验证 (TestConfig):
       - 默认配置参数验证
       - 参数边界值验证（分片大小、缓冲区大小、锁超时）
       - 配置序列化和反序列化
       - 通道定义验证（名称非空、数据类型有效）

    2. 一般模式 (TestNormal):
       - 单文件基本写入和读取
       - 多通道数据写入
       - 状态错误处理（未定义通道写入）
       - 数据验证错误（样本数与时间戳不匹配）
       - 空数据处理
       - 空缓冲区刷新

    3. 分片模式 (TestFragmented) - 核心测试:
       - 分片自动切分（256KB 阈值触发多文件）
       - 每个分片包含完整 Schema 验证
       - 索引文件内容和结构验证
       - 读取器跨分片自动合并
       - 关闭后重新打开持久化追加
       - 分片文件命名格式验证（base_001.mf4）
       - 间歇数据触发分片切分
       - 大阈值下单分片行为

    4. 流式模式 (TestStreaming):
       - 基本缓冲写入和读取
       - 连续逐条追加
       - 关闭前自动 flush 缓冲区

    5. 连续/间歇数据 (TestIntermittent):
       - 一般模式间歇数据
       - 多通道间歇数据
       - 分片模式间歇数据
       - 未定义通道错误处理

    6. 多线程并发 (TestMultiThreading):
       - 流式模式 4 线程并发写入（100 条记录）
       - 分片模式 5 线程并发写入（100 条记录）

    7. 压缩 (TestCompression):
       - ZIP 压缩数据完整性

    8. 迭代器读取 (TestIterator):
       - 单文件大数据量分批读取
       - 分片数据分批读取

    9. 边界条件 (TestEdgeCases):
       - 单条记录
       - 5 万条大数据
       - 重复关闭幂等性
       - 零长度时间戳

    10. 读取器功能 (TestReader):
        - 单通道读取
        - 多通道批量读取
        - 通道不存在异常
        - 文件信息查询
        - 切片读取
        - 通道存在性检查

    11. 数据完整性 (TestDataIntegrity):
        - 一般模式精确值比对
        - 分片模式跨分片精确值比对
        - 多通道数据完整性
        - 时间戳完整性

    12. 追加写入器 (TestAppendWriter):
        - MDFAppendWriter 基本功能
        - 继承关系验证

    13. 异常处理 (TestExceptions):
        - 异常类继承层次
        - 重复通道名检测
        - 关闭后写入检测
        - 异常信息内容

    14. 压力测试 (TestStress):
        - 一般模式 10 万条记录
        - 分片模式 5 万条记录

测试工具函数:
    tmpfile():   创建临时文件路径
    rm():        删除文件
    rm_fragments(): 删除分片文件和索引
    gen_data():  生成连续测试数据
    gen_data_exact(): 生成精确可控的测试数据（用于完整性校验）

运行方式:
    python test_mdf_rw.py           # 运行全部测试
    python -m unittest test_mdf_rw  # 使用 unittest 框架运行

版本: 3.1.0
日期: 2026-04-22
"""

# ---------------------------------------------------------------------------
# 标准库导入
# ---------------------------------------------------------------------------
from __future__ import annotations

import os
import sys
import time
import json
import glob
import tempfile
import unittest
import logging
import threading
import numpy as np

# ---------------------------------------------------------------------------
# 本地模块导入
# ---------------------------------------------------------------------------
from mdf_config import (
    MDFConfig, ChannelDef, WriterStats, ReaderStats,
    OperationMode, DataContinuity, CompressionType,
)
from mdf_writer import (
    MDFWriter, MDFAppendWriter, FragmentIndex,
    MDFWriterError, MDFWriterStateError, MDFWriterValidationError,
    MDFWriterModeError, MDFWriterThreadError,
)
from mdf_reader import (
    MDFReader,
    MDFReaderError, MDFReaderNotFoundError, MDFReaderStateError,
    MDFReaderFormatError,
)

# ---------------------------------------------------------------------------
# 日志配置
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


# =============================================================================
# 工具函数
# =============================================================================

def tmpfile(suffix=".mf4"):
    """创建临时文件路径并确保文件不存在"""
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    return path


def rm(path):
    """删除文件（忽略错误）"""
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def rm_fragments(base_path):
    """删除分片文件和索引文件"""
    base, ext = os.path.splitext(base_path)
    for pattern in [f"{base}_*{ext}", f"{base}.index"]:
        for f in glob.glob(pattern):
            rm(f)
    rm(base_path)


def gen_data(n, names):
    """
    生成连续测试数据

    参数:
        n:     记录数
        names: 通道名称列表

    返回:
        (values_dict, timestamps_list)
    """
    ts = [i * 0.01 for i in range(n)]
    vals = {}
    for i, name in enumerate(names):
        # 每个通道的值有独特的偏移，便于验证
        vals[name] = [float(j * 10 + i) for j in range(n)]
    return vals, ts


def gen_data_exact(n, names, offset=0):
    """
    生成精确可控的测试数据

    用于数据完整性校验，每个值都是确定性的。

    参数:
        n:      记录数
        names:  通道名称列表
        offset: 时间戳偏移

    返回:
        (values_dict, timestamps_list)
    """
    ts = [offset + i * 0.01 for i in range(n)]
    vals = {}
    for name in names:
        # 值 = 时间戳 * 100 + 通道哈希，完全确定性
        ch_hash = hash(name) % 1000
        vals[name] = [offset * 100 + i + ch_hash for i in range(n)]
    return vals, ts


# =============================================================================
# 配置测试
# =============================================================================

class TestConfig(unittest.TestCase):
    """
    配置验证测试类

    测试 MDFConfig 和 ChannelDef 的配置验证逻辑，包括：
        - 默认参数值验证
        - 参数边界值验证（分片大小、缓冲区大小、锁超时时间）
        - 配置序列化（to_dict）和反序列化（from_dict）
        - 通道定义验证（名称非空、数据类型有效）
    """
    """配置验证测试"""

    def test_default(self):
        """默认配置验证"""
        c = MDFConfig()
        self.assertEqual(c.operation_mode, OperationMode.NORMAL)
        self.assertEqual(c.fragment_size, 10 * 1024 * 1024)
        self.assertEqual(c.version, "4.10")

    def test_fragment_size_validation(self):
        """分片大小必须在 256KB~1GB 范围内"""
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=100)  # 太小
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=2 * 1024 * 1024 * 1024)  # 太大

    def test_stream_buffer_validation(self):
        """流式缓冲区大小必须在合法范围内"""
        with self.assertRaises(ValueError):
            MDFConfig(stream_buffer_size=5)   # 太小
        with self.assertRaises(ValueError):
            MDFConfig(stream_buffer_size=200000)  # 太大

    def test_lock_timeout_validation(self):
        """锁超时时间必须在合法范围内"""
        with self.assertRaises(ValueError):
            MDFConfig(lock_timeout_seconds=0.5)  # 太小
        with self.assertRaises(ValueError):
            MDFConfig(lock_timeout_seconds=400)  # 太大

    def test_serialization(self):
        """配置序列化和反序列化"""
        c = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            compression=CompressionType.ZIP,
            fragment_size=5 * 1024 * 1024,
        )
        d = c.to_dict()
        r = MDFConfig.from_dict(d)
        self.assertEqual(r.operation_mode, OperationMode.FRAGMENTED)
        self.assertEqual(r.fragment_size, 5 * 1024 * 1024)
        self.assertEqual(r.compression, CompressionType.ZIP)

    def test_from_dict_with_enums(self):
        """从字典创建时正确处理枚举字符串"""
        d = {
            "operation_mode": "streaming",
            "compression": "zstd",
            "fragment_size": 262144,
        }
        c = MDFConfig.from_dict(d)
        self.assertEqual(c.operation_mode, OperationMode.STREAMING)
        self.assertEqual(c.compression, CompressionType.ZSTD)

    def test_channel_def(self):
        """通道定义创建和验证"""
        ch = ChannelDef(
            name="Temp", unit="C", data_type="<f4", comment="温度传感器"
        )
        self.assertEqual(ch.name, "Temp")
        self.assertEqual(ch.unit, "C")
        self.assertEqual(ch.display_name, "Temp")
        self.assertEqual(ch.data_type, "<f4")

    def test_channel_def_empty_name(self):
        """通道名称不能为空"""
        with self.assertRaises(ValueError):
            ChannelDef(name="")

    def test_channel_def_invalid_dtype(self):
        """无效的数据类型应报错"""
        with self.assertRaises(ValueError):
            ChannelDef(name="X", data_type="invalid_type")


# =============================================================================
# 一般模式测试
# =============================================================================

class TestNormal(unittest.TestCase):
    """
    一般模式测试类

    测试 NORMAL 模式下的单文件直接写入和读取：
        - 基本写入读取流程
        - 多通道数据写入
        - 状态错误处理（未定义通道时写入）
        - 数据验证错误（样本数与时间戳数不匹配）
        - 空数据和空缓冲区处理

    每个测试用例使用独立的临时文件，测试结束后自动清理。
    """
    """一般模式测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_basic_write_read(self):
        """基本写入读取"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Speed", unit="km/h", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            vals, ts = gen_data(100, ["Speed"])
            w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            sig = r.get_channel("Speed")
            self.assertEqual(len(sig.samples), 100)

    def test_multiple_channels(self):
        """多通道写入和读取"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef(name="A", data_type="<f4"),
            ChannelDef(name="B", data_type="<f4"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            vals, ts = gen_data(50, ["A", "B"])
            w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            a = r.get_channel("A")
            b = r.get_channel("B")
            self.assertEqual(len(a.samples), 50)
            self.assertEqual(len(b.samples), 50)

    def test_state_error_no_channels(self):
        """未定义通道时写入应报状态错误"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter(self.path, config)
        with self.assertRaises(MDFWriterStateError):
            writer.append_continuous({"X": [1.0]}, [0.0])
        writer.close()

    def test_validation_mismatched_length(self):
        """样本数与时间戳数不匹配应报验证错误"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("X", data_type="<f4")])
            with self.assertRaises(MDFWriterValidationError):
                w.append_continuous({"X": [1.0, 2.0]}, [0.0])

    def test_empty_data(self):
        """空数据应不报错"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("E", data_type="<f4")])
            w.append_continuous({"E": []}, [])

    def test_flush_empty_buffer(self):
        """刷新空缓冲区应不报错"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("F", data_type="<f4")])
            w.flush()


# =============================================================================
# 分片模式核心测试
# =============================================================================

class TestFragmented(unittest.TestCase):
    """
    分片模式核心测试类（重点测试）

    测试 FRAGMENTED 模式下的体积阈值自动分片功能：
        - 分片自动切分：大量数据触发产生多个分片文件
        - Schema 一致性：每个分片都包含完整通道定义
        - 索引文件验证：JSON 结构、字段完整性
        - 读取器合并：跨分片数据自动发现和合并
        - 持久化追加：关闭后重新打开继续写入
        - 命名规范：base_001.mf4, base_002.mf4 格式
        - 间歇数据切分：间歇数据也能触发分片
        - 大阈值行为：小数据量不产生多余分片

    分片大小使用 256KB 以在测试中快速触发切分。
    """
    """分片模式核心测试（体积阈值 + 多文件 + Schema 模式）"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm_fragments(self.path)

    def test_fragment_auto_split(self):
        """
        分片自动切分测试

        写入大量数据触发分片切分，验证：
            1. 产生多个分片文件
            2. 每个分片都是有效的 MDF 文件
            3. 索引文件存在
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef(name="BigData", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            # 写入约 1.5MB 数据，应触发多次切分
            for batch in range(150):
                vals = {"BigData": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        # 验证多个分片文件存在
        frag_paths = w.get_fragment_paths()
        self.assertGreaterEqual(len(frag_paths), 2, "应产生至少 2 个分片")

        # 验证每个分片都是有效 MDF 文件
        for path in frag_paths:
            self.assertTrue(os.path.exists(path), f"分片应存在: {path}")
            self.assertGreater(os.path.getsize(path), 64, f"分片应大于 64 字节")

        # 验证索引文件存在
        base, _ = os.path.splitext(self.path)
        index_path = base + ".index"
        self.assertTrue(os.path.exists(index_path), "索引文件应存在")

    def test_each_fragment_has_schema(self):
        """
        每个分片包含完整 Schema 测试

        验证每个分片文件都能独立读取通道定义。
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [
            ChannelDef(name="Speed", unit="km/h", data_type="<f4", comment="车速"),
            ChannelDef(name="RPM", unit="rpm", data_type="<u4", comment="转速"),
            ChannelDef(name="Temp", unit="C", data_type="<f4", comment="温度"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(100):
                vals, ts = gen_data(1000, ["Speed", "RPM", "Temp"])
                ts = [t + batch * 10 for t in ts]
                w.append_continuous(vals, ts)

        # 验证每个分片都有完整的通道
        frag_paths = sorted(glob.glob(os.path.splitext(self.path)[0] + "_*.mf4"))
        self.assertGreaterEqual(len(frag_paths), 2)

        for path in frag_paths:
            with MDFReader(path) as r:
                names = set(r.get_channel_names())
                self.assertIn("Speed", names, f"{path} 应包含 Speed")
                self.assertIn("RPM", names, f"{path} 应包含 RPM")
                self.assertIn("Temp", names, f"{path} 应包含 Temp")

    def test_index_file_content(self):
        """索引文件内容和结构验证"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef(name="Data", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(80):
                vals = {"Data": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        # 读取索引
        base, _ = os.path.splitext(self.path)
        index_path = base + ".index"
        with open(index_path, 'r') as f:
            index = json.load(f)

        # 验证结构完整性
        self.assertIn("base_path", index)
        self.assertIn("schema", index)
        self.assertIn("fragments", index)
        self.assertIn("created_at", index)
        self.assertIn("updated_at", index)

        # 验证 Schema
        self.assertIn("channels", index["schema"])
        self.assertEqual(len(index["schema"]["channels"]), 1)
        self.assertEqual(index["schema"]["channels"][0]["name"], "Data")
        self.assertEqual(index["schema"]["channels"][0]["unit"], "")

        # 验证分片列表
        self.assertGreaterEqual(len(index["fragments"]), 2)
        for frag in index["fragments"]:
            self.assertIn("index", frag)
            self.assertIn("path", frag)
            self.assertIn("size", frag)
            self.assertIn("records", frag)
            self.assertIn("start_time", frag)
            self.assertIn("end_time", frag)
            # 验证索引从 1 开始
            self.assertGreaterEqual(frag["index"], 1)

    def test_fragment_reader_merge(self):
        """
        分片读取器自动合并测试

        验证 MDFReader 能自动发现分片并正确合并数据。
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef(name="Merged", data_type="<f4")]

        total_records = 0
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(20):
                vals = {"Merged": [float(batch * 1000 + i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)
                total_records += 1000

        # 用基础路径读取（应自动发现所有分片）
        with MDFReader(self.path) as r:
            info = r.get_file_info()
            self.assertEqual(info["mode"], "fragmented")
            self.assertGreaterEqual(info["fragment_count"], 2)

            sig = r.get_channel("Merged")
            self.assertEqual(
                len(sig.samples), total_records,
                f"应合并所有分片数据，总样本数应为 {total_records}"
            )

    def test_persistence_append(self):
        """
        分片持久化追加测试

        关闭后重新打开继续追加数据。
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=2 * 1024 * 1024,
        )
        channels = [ChannelDef(name="Persistent", data_type="<f4")]

        # 第一次写入
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            vals = {"Persistent": [float(i) for i in range(2000)]}
            ts = [i * 0.01 for i in range(2000)]
            w.append_continuous(vals, ts)

        # 第二次追加
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            vals = {"Persistent": [float(2000 + i) for i in range(2000)]}
            ts = [20.0 + i * 0.01 for i in range(2000)]
            w.append_continuous(vals, ts)

        # 验证读取合并（4000 条记录，无重复）
        with MDFReader(self.path) as r:
            sig = r.get_channel("Persistent")
            self.assertEqual(len(sig.samples), 4000)

    def test_fragment_naming(self):
        """分片文件命名格式验证：base_001.mf4, base_002.mf4"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef(name="Named", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(60):
                vals = {"Named": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        base, ext = os.path.splitext(self.path)
        frag_paths = w.get_fragment_paths()
        # 验证命名格式
        for i in range(1, min(len(frag_paths) + 1, 6)):
            expected = f"{base}_{i:03d}{ext}"
            self.assertTrue(
                os.path.exists(expected),
                f"分片命名应遵循 base_{{idx:03d}}{ext} 格式"
            )

    def test_fragment_with_intermittent_split(self):
        """
        分片模式间歇数据触发切分测试

        使用大量间歇数据触发分片切分。
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [
            ChannelDef(name="EvtA", data_type="<u4"),
            ChannelDef(name="EvtB", data_type="<f4"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels, DataContinuity.INTERMITTENT)
            # 写入约 20000 条间歇记录，确保触发分片
            for i in range(20000):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)

        # 验证产生多个分片
        frag_paths = w.get_fragment_paths()
        self.assertGreaterEqual(len(frag_paths), 2, "间歇数据也应触发分片")

        # 验证数据完整性（20000 条记录 × 2 通道）
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 20000)
            self.assertEqual(len(r.get_channel("EvtB").samples), 20000)

    def test_large_fragment_threshold(self):
        """大分片阈值下数据应正确写入单分片"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=10 * 1024 * 1024,
        )
        channels = [ChannelDef(name="Small", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            vals = {"Small": [float(i) for i in range(100)]}
            ts = [i * 0.01 for i in range(100)]
            w.append_continuous(vals, ts)

        frag_paths = w.get_fragment_paths()
        self.assertEqual(len(frag_paths), 1, "小数据应只产生 1 个分片")


# =============================================================================
# 流式模式测试
# =============================================================================

class TestStreaming(unittest.TestCase):
    """
    流式模式测试类

    测试 STREAMING 模式下的缓冲区管理和刷盘机制：
        - 基本缓冲写入和读取
        - 连续逐条追加（模拟实时采集）
        - 关闭前自动 flush 缓冲区（确保数据不丢失）

    所有测试关闭后台线程以确保确定性。
    """
    """流式模式测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_basic(self):
        """流式模式基本写入和读取"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=500,
            stream_enable_background_thread=False,
        )
        channels = [ChannelDef(name="S1", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(5):
                vals, ts = gen_data(100, ["S1"])
                ts = [t + batch for t in ts]
                w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            sig = r.get_channel("S1")
            self.assertEqual(len(sig.samples), 500)

    def test_continuous_append(self):
        """流式模式连续逐条追加"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=1000,
            stream_enable_background_thread=False,
        )
        channels = [
            ChannelDef(name="C1", data_type="<u4"),
            ChannelDef(name="C2", data_type="<f4"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for i in range(100):
                w.append_continuous(
                    {"C1": [i], "C2": [float(i) * 1.5]},
                    [float(i) * 0.01]
                )

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("C1").samples), 100)
            self.assertEqual(len(r.get_channel("C2").samples), 100)

    def test_flush_before_close(self):
        """流式模式关闭前自动 flush 缓冲区"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=10000,  # 大缓冲区
            stream_enable_background_thread=False,
        )
        channels = [ChannelDef(name="Flush", data_type="<f4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            # 写入少量数据（不超过缓冲区）
            vals, ts = gen_data(50, ["Flush"])
            w.append_continuous(vals, ts)

        # 关闭后应自动 flush，所有数据持久化
        with MDFReader(self.path) as r:
            sig = r.get_channel("Flush")
            self.assertEqual(len(sig.samples), 50)


# =============================================================================
# 间歇数据测试
# =============================================================================

class TestIntermittent(unittest.TestCase):
    """
    间歇数据测试类

    测试 INTERMITTENT 连续性模式下的数据写入：
        - 一般模式单通道间歇数据
        - 多通道间歇数据（各通道独立时间基）
        - 分片模式间歇数据
        - 向未定义通道写入的错误处理

    间歇数据适用于事件触发型采集场景。
    """
    """间歇数据测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_normal_intermittent(self):
        """一般模式间歇数据写入"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef(name="Evt", data_type="<u4")]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(20):
                w.append_intermittent("Evt", float(i) * 0.5, i * 10)

        with MDFReader(self.path) as r:
            sig = r.get_channel("Evt")
            self.assertEqual(len(sig.samples), 20)

    def test_normal_intermittent_multi_channel(self):
        """一般模式多通道间歇数据"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef(name="EvtA", data_type="<u4"),
            ChannelDef(name="EvtB", data_type="<f4"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(50):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 50)
            self.assertEqual(len(r.get_channel("EvtB").samples), 50)

    def test_fragmented_intermittent(self):
        """分片模式间歇数据"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=1 * 1024 * 1024,
        )
        channels = [
            ChannelDef(name="EvtA", data_type="<u4"),
            ChannelDef(name="EvtB", data_type="<f4"),
        ]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(100):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 100)
            self.assertEqual(len(r.get_channel("EvtB").samples), 100)

    def test_intermittent_undefined_channel(self):
        """向未定义的通道写入间歇数据应报错"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("OnlyOne", data_type="<f4")])
            with self.assertRaises(MDFWriterValidationError):
                w.append_intermittent("Undefined", 0.0, 1.0)


# =============================================================================
# 多线程测试
# =============================================================================

class TestMultiThreading(unittest.TestCase):
    """
    多线程并发测试类

    测试多线程环境下写入器的线程安全性：
        - 流式模式 4 线程并发写入（共 100 条记录）
        - 分片模式 5 线程并发写入（共 100 条记录）

    每个工作线程独立生成数据，通过 RLock 保证线程安全。
    验证最终数据总量是否正确（无丢失、无重复）。
    """
    """多线程并发测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_concurrent_write_streaming(self):
        """流式模式多线程并发写入"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=1000,
            stream_enable_background_thread=False,
        )
        channels = [ChannelDef(name="ThreadData", data_type="<f4")]

        writer = MDFWriter(self.path, config)
        writer.define_channels(channels)

        def worker(tid, count):
            for i in range(count):
                writer.append_continuous(
                    {"ThreadData": [float(tid * 1000 + i)]},
                    [float(tid * 1000 + i) * 0.001]
                )

        threads = [
            threading.Thread(target=worker, args=(i, 25))
            for i in range(4)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        writer.close()

        with MDFReader(self.path) as r:
            sig = r.get_channel("ThreadData")
            self.assertEqual(len(sig.samples), 100)

    def test_concurrent_write_fragmented(self):
        """分片模式多线程并发写入"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=2 * 1024 * 1024,
        )
        channels = [ChannelDef(name="FragThread", data_type="<f4")]

        writer = MDFWriter(self.path, config)
        writer.define_channels(channels)

        def worker(tid, count):
            for i in range(count):
                writer.append_continuous(
                    {"FragThread": [float(tid * 100 + i)]},
                    [float(tid * 100 + i) * 0.01]
                )

        threads = [
            threading.Thread(target=worker, args=(i, 20))
            for i in range(5)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        writer.close()

        with MDFReader(self.path) as r:
            sig = r.get_channel("FragThread")
            self.assertEqual(len(sig.samples), 100)


# =============================================================================
# 压缩测试
# =============================================================================

class TestCompression(unittest.TestCase):
    """
    压缩功能测试类

    测试 ZIP 压缩模式下数据完整性：
        - 压缩后文件可正常读取
        - 数据内容和数量无损失

    注意：压缩主要测试功能正确性，不测试压缩率。
    """
    """压缩功能测试"""

    def test_zip_compression(self):
        """ZIP 压缩数据完整性验证"""
        path = tmpfile()
        config = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionType.ZIP,
        )
        channels = [ChannelDef(name="Comp", data_type="<f4")]

        with MDFWriter(path, config) as w:
            w.define_channels(channels)
            vals, ts = gen_data(500, ["Comp"])
            w.append_continuous(vals, ts)

        with MDFReader(path) as r:
            sig = r.get_channel("Comp")
            self.assertEqual(len(sig.samples), 500)

        rm(path)


# =============================================================================
# 迭代器读取测试
# =============================================================================

class TestIterator(unittest.TestCase):
    """
    迭代器读取测试类

    测试 MDFReader 的迭代器功能：
        - 单文件大数据量分批读取
        - 分片数据跨分片分批读取

    迭代器模式适用于内存受限的大数据集处理。
    """
    """迭代器读取测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_iter_channel(self):
        """单文件通道迭代器"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Iter", data_type="<f4")])
            vals, ts = gen_data(5000, ["Iter"])
            w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            total = 0
            for chunk in r.iter_channel("Iter", batch_size=500):
                total += len(chunk.samples)
            self.assertEqual(total, 5000)

    def test_iter_fragmented(self):
        """分片数据迭代器读取"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("FragIter", data_type="<f4")])
            for batch in range(20):
                vals = {"FragIter": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            total = 0
            for chunk in r.iter_channel("FragIter", batch_size=1000):
                total += len(chunk.samples)
            self.assertEqual(total, 20000)


# =============================================================================
# 边界条件测试
# =============================================================================

class TestEdgeCases(unittest.TestCase):
    """
    边界条件测试类

    测试各种极端和边界场景：
        - 单条记录（最小数据量）
        - 5 万条大数据量
        - 重复关闭（幂等性验证）
        - 零长度时间戳

    确保写入器在所有边界条件下都能正确处理。
    """
    """边界条件测试"""

    def test_single_record(self):
        """单条记录写入和读取"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("One", data_type="<f4")])
            w.append_continuous({"One": [42.0]}, [0.0])

        with MDFReader(path) as r:
            sig = r.get_channel("One")
            self.assertEqual(len(sig.samples), 1)
            self.assertAlmostEqual(float(sig.samples[0]), 42.0)
        rm(path)

    def test_large_data(self):
        """大数据量写入（5万条）"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Big", data_type="<f4")])
            vals, ts = gen_data(50000, ["Big"])
            w.append_continuous(vals, ts)

        with MDFReader(path) as r:
            sig = r.get_channel("Big")
            self.assertEqual(len(sig.samples), 50000)
        rm_fragments(path)

    def test_double_close(self):
        """重复关闭应不报错（幂等性）"""
        path = tmpfile()
        writer = MDFWriter(path, MDFConfig())
        writer.close()
        writer.close()  # 第二次关闭不应报错
        self.assertFalse(writer.is_open)
        rm(path)

    def test_zero_length_timestamps(self):
        """零长度时间戳应返回 0 条记录"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Zero", data_type="<f4")])
            count = w.append_continuous({"Zero": []}, [])
            self.assertEqual(count, 0)
        rm(path)


# =============================================================================
# 读取器功能测试
# =============================================================================

class TestReader(unittest.TestCase):
    """
    读取器功能测试类

    测试 MDFReader 的各种读取功能：
        - 单通道读取
        - 多通道批量读取
        - 通道不存在异常处理
        - 文件信息查询
        - 记录切片读取
        - 通道存在性检查

    使用 setUp 预创建测试文件，tearDown 自动清理。
    """
    """读取器功能测试"""

    def setUp(self):
        self.path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("Speed", unit="km/h", data_type="<f4"),
                ChannelDef("Temp", unit="C", data_type="<f4"),
            ])
            vals, ts = gen_data(100, ["Speed", "Temp"])
            w.append_continuous(vals, ts)

    def tearDown(self):
        rm(self.path)

    def test_get_channel(self):
        """读取单个通道"""
        with MDFReader(self.path) as r:
            sig = r.get_channel("Speed")
            self.assertEqual(len(sig.samples), 100)

    def test_get_channels(self):
        """批量读取多个通道"""
        with MDFReader(self.path) as r:
            data = r.get_channels(["Speed", "Temp"])
            self.assertIn("Speed", data)
            self.assertIn("Temp", data)
            self.assertEqual(len(data["Speed"].samples), 100)

    def test_channel_not_found(self):
        """不存在的通道应抛异常"""
        with MDFReader(self.path) as r:
            with self.assertRaises(MDFReaderNotFoundError):
                r.get_channel("XXX")

    def test_file_info(self):
        """文件信息查询"""
        with MDFReader(self.path) as r:
            info = r.get_file_info()
            self.assertIn("channels", info)
            self.assertGreater(info["channels"], 0)
            self.assertEqual(info["mode"], "single")

    def test_records_slice(self):
        """切片读取"""
        with MDFReader(self.path) as r:
            sig = r.get_records_slice("Speed", start=10, count=20)
            self.assertEqual(len(sig.samples), 20)

    def test_has_channel(self):
        """通道存在性检查"""
        with MDFReader(self.path) as r:
            self.assertTrue(r.has_channel("Speed"))
            self.assertFalse(r.has_channel("NonExist"))


# =============================================================================
# 数据完整性测试
# =============================================================================

class TestDataIntegrity(unittest.TestCase):
    """
    数据完整性测试类（精确值比对）

    通过确定性数据生成和精确比对，验证：
        - 写入值与读取值完全一致（逐值比对）
        - 跨分片数据合并后值正确
        - 多通道各通道数据独立正确
        - 时间戳精确无漂移

    使用 gen_data_exact() 生成确定性数据，
    避免浮点精度问题导致的误判。
    """
    """
    数据完整性测试

    精确比对写入值和读取值，确保数据无丢失、无损坏、无重复。
    """

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_exact_values_normal(self):
        """
        一般模式精确值验证

        写入确定性的值，读取后逐个比对。
        """
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef("Exact", data_type="<f4")]

        expected_values = [float(i * 3.14159) for i in range(200)]
        expected_ts = [i * 0.001 for i in range(200)]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            w.append_continuous({"Exact": expected_values}, expected_ts)

        with MDFReader(self.path) as r:
            sig = r.get_channel("Exact")
            self.assertEqual(len(sig.samples), 200)
            for i in range(200):
                self.assertAlmostEqual(
                    float(sig.samples[i]), expected_values[i], places=4
                )

    def test_exact_values_fragmented(self):
        """
        分片模式精确值验证

        验证跨分片数据合并后值仍然精确。
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef("FragExact", data_type="<f4")]

        all_values = []
        all_ts = []
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(10):
                vals = [float(batch * 1000 + i) for i in range(1000)]
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous({"FragExact": vals}, ts)
                all_values.extend(vals)
                all_ts.extend(ts)

        with MDFReader(self.path) as r:
            sig = r.get_channel("FragExact")
            self.assertEqual(len(sig.samples), 10000)
            # 验证值正确（注意：合并后按时间戳排序）
            for i in range(10000):
                self.assertAlmostEqual(
                    float(sig.samples[i]), all_values[i], places=4
                )

    def test_multi_channel_integrity(self):
        """多通道数据完整性验证"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [
            ChannelDef("A", data_type="<f4"),
            ChannelDef("B", data_type="<f4"),
            ChannelDef("C", data_type="<f4"),
        ]

        expected = {
            "A": [1.0, 2.0, 3.0, 4.0, 5.0],
            "B": [10.0, 20.0, 30.0, 40.0, 50.0],
            "C": [100.0, 200.0, 300.0, 400.0, 500.0],
        }
        ts = [0.0, 0.1, 0.2, 0.3, 0.4]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            w.append_continuous(expected, ts)

        with MDFReader(self.path) as r:
            for name in ["A", "B", "C"]:
                sig = r.get_channel(name)
                self.assertEqual(len(sig.samples), 5)
                for i in range(5):
                    self.assertAlmostEqual(
                        float(sig.samples[i]), expected[name][i]
                    )

    def test_timestamps_integrity(self):
        """时间戳完整性验证"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        channels = [ChannelDef("TS", data_type="<f4")]

        expected_ts = [i * 0.5 for i in range(100)]
        values = [float(i) for i in range(100)]

        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            w.append_continuous({"TS": values}, expected_ts)

        with MDFReader(self.path) as r:
            sig = r.get_channel("TS")
            for i in range(100):
                self.assertAlmostEqual(
                    float(sig.timestamps[i]), expected_ts[i], places=6
                )


# =============================================================================
# 追加写入器测试
# =============================================================================

class TestAppendWriter(unittest.TestCase):
    """
    追加写入器测试类

    测试 MDFAppendWriter 的追加写入功能：
        - 在已有文件上追加数据
        - 继承关系验证（MDFWriter 子类）

    MDFAppendWriter 提供语义上更清晰的追加写入接口。
    """
    """MDFAppendWriter 测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_append_writer_basic(self):
        """追加写入器基本功能"""
        # 先创建文件
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("App", data_type="<f4")])
            w.append_continuous({"App": [1.0, 2.0]}, [0.0, 0.1])

        # 使用追加写入器追加
        append_config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFAppendWriter(self.path, append_config) as w:
            w.define_channels([ChannelDef("App", data_type="<f4")])
            w.append_continuous({"App": [3.0, 4.0]}, [0.2, 0.3])

        # 验证总数据量
        with MDFReader(self.path) as r:
            sig = r.get_channel("App")
            self.assertEqual(len(sig.samples), 4)

    def test_append_writer_is_mdf_writer_subclass(self):
        """MDFAppendWriter 是 MDFWriter 的子类"""
        self.assertTrue(issubclass(MDFAppendWriter, MDFWriter))


# =============================================================================
# 异常处理测试
# =============================================================================

class TestExceptions(unittest.TestCase):
    """
    异常处理测试类

    测试异常类体系和错误处理：
        - 异常继承层次关系
        - 重复通道名称检测
        - 关闭后写入检测
        - 异常信息包含有用上下文

    完善的异常体系帮助调用者快速定位问题。
    """
    """异常处理测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_exception_hierarchy(self):
        """异常类继承关系"""
        self.assertTrue(issubclass(MDFWriterStateError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterValidationError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterModeError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterThreadError, MDFWriterError))
        self.assertTrue(issubclass(MDFReaderNotFoundError, MDFReaderError))
        self.assertTrue(issubclass(MDFReaderStateError, MDFReaderError))

    def test_duplicate_channel_names(self):
        """重复通道名称应报错"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            with self.assertRaises(MDFWriterValidationError):
                w.define_channels([
                    ChannelDef("Dup", data_type="<f4"),
                    ChannelDef("Dup", data_type="<u4"),
                ])

    def test_write_after_close(self):
        """关闭后写入应报错（通过上下文管理器）"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        w = MDFWriter(self.path, config)
        w.define_channels([ChannelDef("X", data_type="<f4")])
        w.close()

        with self.assertRaises(MDFWriterStateError):
            w.append_continuous({"X": [1.0]}, [0.0])

    def test_reader_channel_not_found_msg(self):
        """通道不存在异常应包含有用信息"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Exists", data_type="<f4")])
            w.append_continuous({"Exists": [1.0]}, [0.0])

        with MDFReader(self.path) as r:
            with self.assertRaises(MDFReaderNotFoundError) as ctx:
                r.get_channel("NotFound")
            self.assertIn("NotFound", str(ctx.exception))


# =============================================================================
# 压力测试
# =============================================================================

class TestStress(unittest.TestCase):
    """
    压力测试类

    在大数据量下进行稳定性测试：
        - 一般模式 10 万条记录（100 批次 x 1000 条）
        - 分片模式 5 万条记录（50 批次 x 1000 条）

    压力测试主要关注：
        - 大数据量下不崩溃
        - 数据总量正确
        - 内存使用稳定（无泄漏）
        - 执行时间可接受
    """
    """压力测试"""

    def test_many_batches_normal(self):
        """一般模式大批量写入（10万条）"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)

        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Stress", data_type="<f4")])
            for batch in range(100):
                vals = {"Stress": [float(i) for i in range(1000)]}
                ts = [batch + i * 0.001 for i in range(1000)]
                w.append_continuous(vals, ts)

        with MDFReader(path) as r:
            sig = r.get_channel("Stress")
            self.assertEqual(len(sig.samples), 100000)

        rm(path)

    def test_many_batches_fragmented(self):
        """分片模式大批量写入（产生多个分片）"""
        path = tmpfile()
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )

        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("StressFrag", data_type="<f4")])
            for batch in range(50):
                vals = {"StressFrag": [float(i) for i in range(1000)]}
                ts = [batch + i * 0.001 for i in range(1000)]
                w.append_continuous(vals, ts)

        with MDFReader(path) as r:
            sig = r.get_channel("StressFrag")
            self.assertEqual(len(sig.samples), 50000)

        rm_fragments(path)


# =============================================================================
# 主入口
# =============================================================================

def run_tests():
    """运行全部测试"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # 添加所有测试类
    classes = [
        TestConfig,
        TestNormal,
        TestFragmented,
        TestStreaming,
        TestIntermittent,
        TestMultiThreading,
        TestCompression,
        TestIterator,
        TestEdgeCases,
        TestReader,
        TestDataIntegrity,
        TestAppendWriter,
        TestExceptions,
        TestStress,
    ]

    for cls in classes:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # 打印测试摘要
    print("\n" + "=" * 70)
    print("测试摘要")
    print("=" * 70)
    print(f"总测试数: {result.testsRun}")
    passed = result.testsRun - len(result.failures) - len(result.errors)
    print(f"通过: {passed}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
