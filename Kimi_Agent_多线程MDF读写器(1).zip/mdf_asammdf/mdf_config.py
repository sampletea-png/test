# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器 - 配置模块

本模块定义了 MDF 读写器的全部配置参数、枚举类型、通道定义和统计信息类。
设计目标是支持三种操作模式：NORMAL / FRAGMENTED / STREAMING。

FRAGMENTED（分片）模式的核心设计思想：
    - 以文件体积（字节）为阈值进行自动分片
    - 每个分片是独立的完整 MDF 文件，包含完整 Schema（通道定义）
    - 分片文件通过 JSON 索引文件统一管理
    - 支持关闭后重新打开，继续向最新分片追加数据
    - 分片命名格式：base_001.mf4, base_002.mf4, ...

线程安全性说明：
    本模块中的所有类均为不可变 dataclass 或纯枚举类型，
    可在多线程间安全共享，无需额外同步机制。

版本: 3.1.0
日期: 2026-04-22
"""

# ---------------------------------------------------------------------------
# 导入标准库
# ---------------------------------------------------------------------------
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List

# ---------------------------------------------------------------------------
# 模块级日志记录器
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)


# =============================================================================
# 枚举类型定义
# =============================================================================

class OperationMode(enum.Enum):
    """
    操作模式枚举

    定义 MDF 写入器的三种核心操作模式：

    NORMAL:
        一般模式，直接写入单文件，无分片逻辑。
        适用于数据量较小、不需要分片的场景。
        写入路径：用户指定路径 -> 直接写入 -> close 时 save。

    FRAGMENTED:
        分片模式，以体积阈值自动切分为多个独立 MDF 文件。
        适用于大数据量采集、需要按文件分割的场景。
        写入路径：用户指定基础路径 -> 自动生成分片 -> 每个分片独立文件。
        分片触发条件：estimated_size >= fragment_size（详见 MDFWriter._check_fragment_split）

    STREAMING:
        流式模式，带内存缓冲区和可选的后台刷盘线程。
       适用于高频数据实时采集场景。
        写入路径：数据 -> 内存缓冲区 -> 定时/定量 flush -> 磁盘。
    """
    # 枚举成员定义
    NORMAL = "normal"
    FRAGMENTED = "fragmented"
    STREAMING = "streaming"


class DataContinuity(enum.Enum):
    """
    数据连续性枚举

    定义两种数据组织方式，影响时间戳的存储结构：

    CONTINUOUS:
        连续数据，所有通道共享同一时间基。
        适用于同步采样的传感器数据（如 100Hz 同步采集）。
        存储方式：所有通道使用相同的时间戳数组。

    INTERMITTENT:
        间歇数据，各通道拥有独立的时间基。
        适用于事件触发型数据（如故障码、状态变化）。
        存储方式：每条记录独立存储（时间戳, 通道名, 值）。
    """
    # 枚举成员定义
    CONTINUOUS = "continuous"
    INTERMITTENT = "intermittent"


class CompressionType(enum.Enum):
    """
    压缩类型枚举

    定义 MDF 文件保存时使用的压缩算法。
    映射到 asammdf 的 CompressionAlgorithm 枚举值。

    NONE: 不压缩，写入速度最快，文件体积最大
    ZIP:  DEFLATE 压缩，平衡速度和压缩率
    ZSTD: Zstandard 压缩，压缩率最高但速度较慢
    """
    # 枚举成员定义
    NONE = "no"
    ZIP = "zip"
    ZSTD = "zstd"


# =============================================================================
# 配置类
# =============================================================================

@dataclass
class MDFConfig:
    """
    MDF 读写器配置类

    本类集中管理 MDF 读写器的全部配置参数。
    通过 __post_init__ 进行严格的参数验证，确保配置合法性。

    关键参数说明：

    --- 分片模式参数 (FRAGMENTED) ---
    fragment_size:
        分片体积阈值（字节）。当当前分片文件估算大小达到或超过此值时，
        自动创建新的分片文件。默认值 10MB。
        合法范围: 256KB (262_144) ~ 1GB (1_073_741_824)
        估算公式: 64KB 基础头 + 记录数 × 每记录字节数

    fragment_index_format:
        分片索引格式。"json" 表示使用 JSON 索引文件管理分片。
        未来可扩展为 "sqlite" 等格式。

    --- 流式模式参数 (STREAMING) ---
    stream_buffer_size:
        流式缓冲区大小（记录数）。缓冲区达到此大小时触发刷盘。
        合法范围: 10 ~ 100_000

    stream_flush_interval_ms:
        自动刷盘间隔（毫秒）。后台线程按此间隔检查并刷盘。
        仅当 stream_enable_background_thread=True 时生效。

    stream_enable_background_thread:
        是否启用后台刷盘线程。
        True:  后台线程定时刷盘，适合实时采集
        False: 手动或缓冲区满时刷盘，适合批量写入

    --- 通用参数 ---
    version: MDF 文件版本，默认 "4.10"
    compression: 压缩算法，默认 NONE
    lock_timeout_seconds: 锁超时时间（秒），默认 30.0
    max_concurrent_readers: 最大并发读取器数，默认 10
    """

    # ===================================================================
    # 基本配置字段
    # ===================================================================
    # MDF 文件版本号，支持 3.x 和 4.x 系列
    version: str = "4.10"
    # 操作模式：NORMAL / FRAGMENTED / STREAMING
    operation_mode: OperationMode = OperationMode.NORMAL
    # 数据压缩类型
    compression: CompressionType = CompressionType.NONE

    # ===================================================================
    # 分片模式配置（以体积为阈值自动切分）
    # ===================================================================
    # 分片体积阈值，单位字节，默认 10MB
    fragment_size: int = 10 * 1024 * 1024
    # 分片索引格式：json（未来可扩展 sqlite 等）
    fragment_index_format: str = "json"

    # ===================================================================
    # 流式模式配置
    # ===================================================================
    # 流式缓冲区大小（记录数），默认 5000
    stream_buffer_size: int = 5000
    # 自动刷盘间隔（毫秒），默认 1000ms
    stream_flush_interval_ms: float = 1000.0
    # 是否启用后台刷盘线程，默认 True
    stream_enable_background_thread: bool = True

    # ===================================================================
    # 线程安全配置
    # ===================================================================
    # 锁超时时间（秒），防止死锁，默认 30 秒
    lock_timeout_seconds: float = 30.0
    # 最大并发读取器数
    max_concurrent_readers: int = 10

    # ===================================================================
    # 扩展配置（供未来扩展使用）
    # ===================================================================
    # 自定义参数字典，允许用户传入额外的键值对参数
    custom_params: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        配置参数验证

        在 dataclass 初始化后自动调用，验证所有参数的合法性。
        验证失败时抛出 ValueError，阻止创建无效配置。

        验证规则：
            1. version 必须在支持的版本列表中
            2. fragment_size 必须在 256KB ~ 1GB 范围内
            3. stream_buffer_size 必须在 10 ~ 100000 范围内
            4. lock_timeout_seconds 必须在 1 ~ 300 范围内
        """
        # 验证 MDF 版本号
        valid_versions = [
            "3.00", "3.10", "3.20", "3.30",
            "4.00", "4.10", "4.11", "4.20"
        ]
        if self.version not in valid_versions:
            raise ValueError(
                f"不支持的 MDF 版本: {self.version}. "
                f"支持的版本: {valid_versions}"
            )

        # 验证分片大小：最小 256KB，最大 1GB
        min_frag = 256 * 1024          # 256KB
        max_frag = 1024 * 1024 * 1024  # 1GB
        if self.fragment_size < min_frag or self.fragment_size > max_frag:
            raise ValueError(
                f"fragment_size 必须在 {min_frag}~{max_frag} 字节范围内 "
                f"(256KB~1GB)，当前值: {self.fragment_size}"
            )

        # 验证流式缓冲区大小
        if self.stream_buffer_size < 10 or self.stream_buffer_size > 100_000:
            raise ValueError(
                f"stream_buffer_size 范围: 10~100000，"
                f"当前值: {self.stream_buffer_size}"
            )

        # 验证锁超时时间
        if self.lock_timeout_seconds < 1 or self.lock_timeout_seconds > 300:
            raise ValueError(
                f"lock_timeout_seconds 范围: 1~300，"
                f"当前值: {self.lock_timeout_seconds}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典

        用于配置序列化（如保存到 JSON 索引文件）。
        枚举类型会被转换为其字符串值。

        返回:
            包含全部配置参数的字典
        """
        return {
            "version": self.version,
            "operation_mode": self.operation_mode.value,
            "compression": self.compression.value,
            "fragment_size": self.fragment_size,
            "fragment_index_format": self.fragment_index_format,
            "stream_buffer_size": self.stream_buffer_size,
            "stream_flush_interval_ms": self.stream_flush_interval_ms,
            "stream_enable_background_thread": self.stream_enable_background_thread,
            "lock_timeout_seconds": self.lock_timeout_seconds,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MDFConfig":
        """
        从字典创建配置对象

        支持从 JSON 索引文件中反序列化配置。
        自动将字符串值转换回枚举类型。

        参数:
            data: 包含配置参数的字典

        返回:
            新的 MDFConfig 实例
        """
        # 创建副本以避免修改原始数据
        data = dict(data)
        # 将字符串操作模式转换为枚举
        if "operation_mode" in data and isinstance(data["operation_mode"], str):
            data["operation_mode"] = OperationMode(data["operation_mode"])
        # 将字符串压缩类型转换为枚举
        if "compression" in data and isinstance(data["compression"], str):
            data["compression"] = CompressionType(data["compression"])
        # 过滤掉不存在的字段，保持前向兼容
        valid = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in data.items() if k in valid})


# =============================================================================
# 通道定义类
# =============================================================================

@dataclass
class ChannelDef:
    """
    通道定义类（Schema 定义）

    定义 MDF 通道的完整 Schema 信息，包括名称、单位、数据类型、
    注释和线性转换参数。

    在分片模式下，每个分片文件都包含相同的通道 Schema，
    确保所有分片文件的通道定义完全一致，可独立读取。

    属性:
        name: 通道名称（唯一标识符，不能为空）
        unit: 物理单位（如 "km/h", "C", "Pa"）
        data_type: NumPy 数据类型字符串（如 "<f4" 表示小端 float32）
        comment: 通道注释说明
        display_name: 显示名称（默认与 name 相同）
        conversion: 线性转换参数字典 {"a": 斜率, "b": 偏移量}

    示例:
        speed = ChannelDef(name="Speed", unit="km/h", data_type="<f4",
                           comment="车速信号", conversion={"a": 0.01, "b": 0})
    """

    # 通道名称（唯一标识符）
    name: str
    # 物理单位
    unit: str = ""
    # NumPy 数据类型字符串
    data_type: str = "<f4"
    # 注释说明
    comment: str = ""
    # 显示名称（UI 展示用）
    display_name: str = ""
    # 线性转换参数: {"a": slope, "b": offset}
    conversion: Optional[Dict[str, float]] = None

    def __post_init__(self):
        """
        验证通道定义参数

        验证规则：
            1. name 不能为空或空白字符串
            2. display_name 默认为 name
            3. data_type 必须是有效的 NumPy 数据类型
        """
        # 验证通道名称非空
        if not self.name or not self.name.strip():
            raise ValueError("通道名称不能为空或仅包含空白字符")

        # 如果未指定显示名称，使用通道名称
        if self.display_name == "":
            self.display_name = self.name

        # 验证 NumPy 数据类型的合法性
        import numpy as np
        try:
            np.dtype(self.data_type)
        except TypeError:
            raise ValueError(
                f"无效的 NumPy 数据类型: {self.data_type}. "
                f"请使用有效的 NumPy dtype 字符串（如 '<f4', '<u4', '<f8'）"
            )


# =============================================================================
# 统计信息类
# =============================================================================

@dataclass
class WriterStats:
    """
    写入器统计信息类

    记录 MDF 写入器的运行统计信息，用于监控和调试。
    所有字段均为原子整数/浮点数，可在多线程环境下安全读取
    （写入受 RLock 保护）。

    字段说明：
        total_records_written:  累计写入记录总数
        total_signals_written:  累计写入信号（通道）总数
        total_flush_count:      累计刷盘次数
        total_bytes_written:    累计写入字节数（估算）
        buffer_records_current: 当前缓冲区记录数
        buffer_records_peak:    缓冲区峰值记录数
        last_flush_timestamp:   上次刷盘时间戳（time.time()）
        error_count:            累计错误次数
        uptime_seconds:         运行时间（秒）
        fragment_count:         当前分片数量（分片模式专用）
        fragment_index:         当前分片索引号（分片模式专用）
    """

    # 累计写入记录总数
    total_records_written: int = 0
    # 累计写入信号总数
    total_signals_written: int = 0
    # 累计刷盘次数
    total_flush_count: int = 0
    # 累计写入字节数（估算值）
    total_bytes_written: int = 0
    # 当前缓冲区记录数
    buffer_records_current: int = 0
    # 缓冲区峰值记录数
    buffer_records_peak: int = 0
    # 上次刷盘时间戳
    last_flush_timestamp: float = 0.0
    # 累计错误次数
    error_count: int = 0
    # 运行时间（秒）
    uptime_seconds: float = 0.0

    # 分片模式专用统计
    # 当前分片数量
    fragment_count: int = 0
    # 当前分片索引号
    fragment_index: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """
        将统计信息转换为字典

        返回:
            包含全部统计字段的字典，便于序列化和日志输出
        """
        return {
            "total_records_written": self.total_records_written,
            "total_signals_written": self.total_signals_written,
            "total_flush_count": self.total_flush_count,
            "total_bytes_written": self.total_bytes_written,
            "buffer_records_current": self.buffer_records_current,
            "buffer_records_peak": self.buffer_records_peak,
            "last_flush_timestamp": self.last_flush_timestamp,
            "error_count": self.error_count,
            "uptime_seconds": self.uptime_seconds,
            "fragment_count": self.fragment_count,
            "fragment_index": self.fragment_index,
        }


@dataclass
class ReaderStats:
    """
    读取器统计信息类

    记录 MDF 读取器的运行统计信息，用于监控和调试。

    字段说明：
        total_reads:        累计读取次数
        total_records_read: 累计读取记录数
        cache_hit_count:    缓存命中次数
        cache_miss_count:   缓存未命中次数
        error_count:        累计错误次数
        uptime_seconds:     运行时间（秒）
        fragments_read:     读取的分片数量（分片模式专用）
    """

    # 累计读取次数
    total_reads: int = 0
    # 累计读取记录数
    total_records_read: int = 0
    # 缓存命中次数
    cache_hit_count: int = 0
    # 缓存未命中次数
    cache_miss_count: int = 0
    # 累计错误次数
    error_count: int = 0
    # 运行时间（秒）
    uptime_seconds: float = 0.0

    # 分片模式专用统计
    # 读取的分片数量
    fragments_read: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """
        将统计信息转换为字典

        返回:
            包含全部统计字段的字典
        """
        return {
            "total_reads": self.total_reads,
            "total_records_read": self.total_records_read,
            "cache_hit_count": self.cache_hit_count,
            "cache_miss_count": self.cache_miss_count,
            "error_count": self.error_count,
            "uptime_seconds": self.uptime_seconds,
            "fragments_read": self.fragments_read,
        }
