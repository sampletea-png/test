# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器包

基于 asammdf 库构建的生产级多线程 MDF 文件读写器。
支持三种操作模式（NORMAL / FRAGMENTED / STREAMING），
连续和间歇数据写入，以及持久化追加功能。

核心特性：
    1. 三种操作模式：
       - NORMAL:     单文件直接写入，简单高效
       - FRAGMENTED: 以体积阈值自动切分为多个独立文件
       - STREAMING:  带缓冲区和后台刷盘线程，适合实时采集

    2. 数据类型支持：
       - 连续数据：多通道共享时间基，适合同步采样
       - 间歇数据：各通道独立时间基，适合事件触发

    3. 分片模式特点：
       - 以文件体积（字节）为阈值自动切分
       - 每个分片是独立的完整 MDF 文件，包含完整 Schema
       - 分片命名：base_001.mf4, base_002.mf4, ...
       - 索引文件：base.index（JSON 格式）
       - 支持关闭后重新打开继续追加

    4. 线程安全：
       - 所有公共方法通过 RLock 同步
       - 支持多线程并发写入

    5. 生产级特性：
       - 完善的异常处理体系
       - 详细的统计信息
       - 资源安全释放（上下文管理器支持）
       - 幂等性关闭

子模块:
    mdf_config   - 配置模块，包含枚举和 MDFConfig 类
    mdf_writer   - 线程安全写入器 (MDFWriter, MDFAppendWriter)
    mdf_reader   - 线程安全读取器 (MDFReader)

使用示例:
    from mdf_asammdf import (
        MDFConfig, ChannelDef, OperationMode,
        MDFWriter, MDFReader,
    )

    # 写入
    config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
    with MDFWriter("output.mf4", config) as writer:
        writer.define_channels([ChannelDef("Speed", "km/h")])
        writer.append_continuous(
            {"Speed": [10.0, 20.0, 30.0]},
            [0.0, 0.1, 0.2]
        )

    # 读取
    with MDFReader("output.mf4") as reader:
        sig = reader.get_channel("Speed")
        print(f"样本: {sig.samples}, 时间戳: {sig.timestamps}")

版本: 3.1.0
"""

# ---------------------------------------------------------------------------
# 配置模块导出
# ---------------------------------------------------------------------------
from mdf_config import (
    # 配置类
    MDFConfig,
    ChannelDef,
    # 统计类
    WriterStats,
    ReaderStats,
    # 枚举类型
    OperationMode,
    DataContinuity,
    CompressionType,
)

# ---------------------------------------------------------------------------
# 写入器模块导出
# ---------------------------------------------------------------------------
from mdf_writer import (
    # 主写入器类
    MDFWriter,
    MDFAppendWriter,
    # 分片索引管理
    FragmentIndex,
    # 异常类
    MDFWriterError,
    MDFWriterStateError,
    MDFWriterValidationError,
    MDFWriterModeError,
    MDFWriterThreadError,
)

# ---------------------------------------------------------------------------
# 读取器模块导出
# ---------------------------------------------------------------------------
from mdf_reader import (
    # 主读取器类
    MDFReader,
    # 异常类
    MDFReaderError,
    MDFReaderNotFoundError,
    MDFReaderStateError,
    MDFReaderFormatError,
)

# ---------------------------------------------------------------------------
# 包元信息
# ---------------------------------------------------------------------------
__version__ = "3.1.0"
__author__ = "ASAM MDF Multi-threaded R/W"
__all__ = [
    # === 配置 ===
    "MDFConfig",
    "ChannelDef",
    "WriterStats",
    "ReaderStats",
    "OperationMode",
    "DataContinuity",
    "CompressionType",
    # === 写入器 ===
    "MDFWriter",
    "MDFAppendWriter",
    "FragmentIndex",
    # === 读取器 ===
    "MDFReader",
    # === 写入器异常 ===
    "MDFWriterError",
    "MDFWriterStateError",
    "MDFWriterValidationError",
    "MDFWriterModeError",
    "MDFWriterThreadError",
    # === 读取器异常 ===
    "MDFReaderError",
    "MDFReaderNotFoundError",
    "MDFReaderStateError",
    "MDFReaderFormatError",
    # === 元信息 ===
    "__version__",
]
