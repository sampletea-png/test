# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程写入器模块 (基于 asammdf 库)

本模块实现了线程安全的 MDF 文件写入器，支持三种操作模式：
    1. NORMAL:     一般模式，单文件直接写入
    2. FRAGMENTED: 分片模式，以体积阈值自动切分为多个独立 MDF 文件
    3. STREAMING:  流式模式，带内存缓冲区和可选后台刷盘线程

FRAGMENTED（分片）模式架构详解：
    - 当当前分片文件的估算大小 >= fragment_size 时，自动创建新分片
    - 每个分片是完全独立的 MDF 文件，使用 MDF(version) 全新创建
    - 每个分片都包含完整的通道 Schema（通过 _apply_schema_to_new_fragment）
    - 分片命名格式: base_001.mf4, base_002.mf4, ...（3 位数字零填充）
    - 索引文件格式: base.index（JSON，记录分片列表和元数据）
    - 支持关闭后重新打开，继续追加到最新分片

关键设计决策：
    - 只在 close 和分片切分时调用 save()，flush 时不 save。
      原因：asammdf 的 save(overwrite=True) 多次调用会导致内存中
      MDF.groups 数量翻倍（虽然文件数据正确）。此限制已在 v3.0.0
      中通过最小化 save 调用次数来规避。
    - 分片大小估算使用记录数 × 每记录字节数 + 基础头大小，
      而非实际文件大小，以避免频繁访问文件系统。

线程安全：
    所有公共方法均通过 threading.RLock 同步。
    后台刷盘线程在获取锁后检查 _is_open 状态。

版本: 3.1.0
日期: 2026-04-22
"""

# ---------------------------------------------------------------------------
# 标准库导入
# ---------------------------------------------------------------------------
from __future__ import annotations

import os
import time
import json
import logging
import threading
from typing import Optional, Dict, List, Any, Tuple, Union
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# 第三方库导入
# ---------------------------------------------------------------------------
import numpy as np

try:
    from asammdf import MDF, Signal
    from asammdf.blocks.v4_constants import CompressionAlgorithm
except ImportError as e:
    raise ImportError(
        "asammdf 库未安装。请运行: pip install asammdf"
    ) from e

# ---------------------------------------------------------------------------
# 本地模块导入
# ---------------------------------------------------------------------------
from mdf_config import (
    MDFConfig, ChannelDef, WriterStats,
    OperationMode, DataContinuity, CompressionType,
)

# ---------------------------------------------------------------------------
# 模块级日志记录器
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)


# =============================================================================
# 异常类定义
# =============================================================================

class MDFWriterError(Exception):
    """
    MDF 写入器基础异常类

    所有写入器相关的异常均继承自此类，便于调用者统一捕获。
    """
    pass


class MDFWriterStateError(MDFWriterError):
    """
    状态错误异常

    当操作在不正确的状态下执行时抛出，例如：
        - 文件未打开时尝试写入
        - 通道未定义时尝试追加数据
        - 写入器已关闭后尝试操作
    """
    pass


class MDFWriterValidationError(MDFWriterError):
    """
    数据验证错误异常

    当传入的数据不符合要求时抛出，例如：
        - 样本数与时间戳数不匹配
        - 通道名称重复
        - 通道名称未定义
        - 空通道列表
    """
    pass


class MDFWriterModeError(MDFWriterError):
    """
    模式错误异常

    当操作在当前模式下不支持时抛出，例如：
        - 在 NORMAL 模式下调用分片相关方法
        - 在 STREAMING 模式下尝试同步写入大数据块
    """
    pass


class MDFWriterThreadError(MDFWriterError):
    """
    线程错误异常

    当多线程操作出现问题时抛出，例如：
        - 获取锁超时
        - 后台线程异常终止
        - 线程间数据竞争
    """
    pass


# =============================================================================
# 内部数据结构
# =============================================================================

@dataclass
class _ContinuousBuffer:
    """
    连续数据内部缓冲区

    用于 FRAGMENTED 和 STREAMING 模式下缓存连续数据。
    所有通道共享同一时间基。

    字段:
        timestamps: 时间戳列表（所有通道共享）
        samples:    通道名 -> 样本列表的字典
        record_count: 当前缓冲区中的记录数

    线程安全说明：
        本类本身不加锁，调用方（MDFWriter）通过 RLock 保护。
    """

    # 时间戳列表（所有通道共享同一时间基）
    timestamps: List[float] = field(default_factory=list)
    # 通道名 -> 样本列表的映射字典
    samples: Dict[str, List[Any]] = field(default_factory=dict)
    # 当前缓冲区中的记录数
    record_count: int = 0

    def __post_init__(self):
        """
        初始化后处理

        确保 samples 为字典类型（防范 field(default_factory=list) 的错误）。
        """
        if isinstance(self.samples, list):
            self.samples = {}

    def add_record(self, timestamp: float, values: Dict[str, Any]) -> None:
        """
        向缓冲区添加一条记录

        参数:
            timestamp: 记录的时间戳
            values:    通道名 -> 值的字典
        """
        # 添加时间戳到共享时间基
        self.timestamps.append(timestamp)
        # 将每个通道的值添加到对应列表
        for name, val in values.items():
            if name not in self.samples:
                # 动态创建通道的样本列表
                self.samples[name] = []
            self.samples[name].append(val)
        # 递增记录计数器
        self.record_count += 1

    def clear(self) -> None:
        """
        清空缓冲区

        刷盘后调用，释放内存并重置状态。
        """
        self.timestamps.clear()
        self.samples.clear()
        self.record_count = 0

    def is_empty(self) -> bool:
        """
        检查缓冲区是否为空

        返回:
            True 如果缓冲区中没有记录
        """
        return self.record_count == 0


@dataclass
class _IntermittentBuffer:
    """
    间歇数据内部缓冲区

    用于 FRAGMENTED 和 STREAMING 模式下缓存间歇数据。
    每条记录独立存储（时间戳, 通道名, 值）。

    字段:
        records: 记录列表，每条为 (timestamp, channel_name, value) 元组

    线程安全说明：
        本类本身不加锁，调用方（MDFWriter）通过 RLock 保护。
    """

    # 记录列表：(时间戳, 通道名, 值)
    records: List[Tuple[float, str, Any]] = field(default_factory=list)

    def add_record(self, timestamp: float, channel_name: str, value: Any) -> None:
        """
        向缓冲区添加一条间歇记录

        参数:
            timestamp:     记录的时间戳
            channel_name:  通道名称
            value:         通道值
        """
        self.records.append((timestamp, channel_name, value))

    def clear(self) -> None:
        """
        清空缓冲区

        刷盘后调用，释放内存并重置状态。
        """
        self.records.clear()

    def is_empty(self) -> bool:
        """
        检查缓冲区是否为空

        返回:
            True 如果缓冲区中没有记录
        """
        return len(self.records) == 0

    def get_record_count(self) -> int:
        """
        获取当前缓冲区中的记录数

        返回:
            记录数量
        """
        return len(self.records)


# =============================================================================
# 分片索引管理
# =============================================================================

class FragmentIndex:
    """
    分片索引管理器

    管理分片索引文件（JSON 格式），记录所有分片文件的元数据信息：
        - 分片文件路径列表
        - 每个分片的起始时间戳、记录数、文件大小
        - 通道 Schema 定义（确保分片间一致性）
        - 创建时间和更新时间

    索引文件格式（JSON）:
        {
            "base_path": "/path/to/base.mf4",
            "schema": {
                "channels": [
                    {"name": "Speed", "unit": "km/h", "data_type": "<f4", ...},
                    ...
                ]
            },
            "fragments": [
                {
                    "index": 0,
                    "path": "/path/to/base_001.mf4",
                    "size": 1024000,
                    "records": 1000,
                    "start_time": 0.0,
                    "end_time": 9.9
                },
                ...
            ],
            "created_at": "2026-04-22T10:00:00",
            "updated_at": "2026-04-22T10:05:00"
        }

    线程安全说明：
        本类的方法由调用方（MDFWriter）通过 RLock 保护。
        文件 I/O 操作（load/save）在锁内进行。
    """

    def __init__(self, base_path: str):
        """
        初始化分片索引

        参数:
            base_path: 基础文件路径（如 "/path/to/data.mf4"）
                       索引文件将创建为 "/path/to/data.index"
        """
        # 保存基础路径
        self.base_path = base_path
        # 自动生成索引文件路径
        self.index_path = self._get_index_path(base_path)
        # 通道 Schema（从通道定义列表生成）
        self.schema: Optional[Dict[str, Any]] = None
        # 分片记录列表
        self.fragments: List[Dict[str, Any]] = []
        # 索引文件创建时间
        self.created_at: str = ""
        # 索引文件最后更新时间
        self.updated_at: str = ""

    @staticmethod
    def _get_index_path(base_path: str) -> str:
        """
        根据基础路径获取索引文件路径

        规则：将扩展名替换为 .index
            /path/to/data.mf4 -> /path/to/data.index

        参数:
            base_path: 基础文件路径

        返回:
            索引文件路径
        """
        base, _ = os.path.splitext(base_path)
        return base + ".index"

    @staticmethod
    def _get_fragment_path(base_path: str, index: int) -> str:
        """
        根据基础路径和分片索引生成分片文件路径

        命名规则：base_{index:03d}.ext
            /path/to/data.mf4, 1 -> /path/to/data_001.mf4
            /path/to/data.mf4, 12 -> /path/to/data_012.mf4

        参数:
            base_path: 基础文件路径
            index:     分片索引号（从 1 开始）

        返回:
            分片文件的完整路径
        """
        base, ext = os.path.splitext(base_path)
        return f"{base}_{index:03d}{ext}"

    def load(self) -> bool:
        """
        从磁盘加载索引文件

        步骤：
            1. 检查索引文件是否存在
            2. 读取并解析 JSON
            3. 加载 schema、fragments 和时间戳

        返回:
            True  如果加载成功
            False 如果索引文件不存在或解析失败
        """
        # 检查索引文件是否存在
        if not os.path.exists(self.index_path):
            return False
        try:
            # 打开并读取索引文件
            with open(self.index_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # 加载各字段
            self.schema = data.get("schema")
            self.fragments = data.get("fragments", [])
            self.created_at = data.get("created_at", "")
            self.updated_at = data.get("updated_at", "")
            return True
        except (json.JSONDecodeError, IOError) as e:
            # JSON 解析失败或 I/O 错误时记录警告日志
            logger.warning(f"加载索引文件失败: {e}")
            return False

    def save(self) -> None:
        """
        保存索引到磁盘

        将当前的分片列表、Schema 和元数据序列化为 JSON 文件。
        更新时间戳为当前时间。

        注意：此操作在 MDFWriter 的 RLock 保护下进行。
        """
        # 构建索引数据结构
        data = {
            "base_path": self.base_path,
            "schema": self.schema,
            "fragments": self.fragments,
            "created_at": self.created_at,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        try:
            # 以 UTF-8 编码写入，使用缩进提高可读性
            with open(self.index_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except IOError as e:
            # 保存失败时记录错误日志但不抛出异常
            # （索引文件损坏不影响主数据文件）
            logger.error(f"保存索引文件失败: {e}")

    def add_fragment(self, index: int, path: str, size: int,
                      records: int, start_time: float, end_time: float) -> None:
        """
        添加分片记录到索引

        参数:
            index:      分片索引号
            path:       分片文件路径
            size:       文件大小（字节）
            records:    记录数
            start_time: 起始时间戳
            end_time:   结束时间戳

        注意：添加后自动调用 save() 持久化索引。
        """
        # 构建分片记录字典
        self.fragments.append({
            "index": index,
            "path": path,
            "size": size,
            "records": records,
            "start_time": start_time,
            "end_time": end_time,
        })
        # 立即保存索引（确保崩溃后可恢复）
        self.save()

    def get_latest_fragment_path(self) -> Optional[str]:
        """
        获取最新分片的文件路径

        返回:
            最新分片的路径，如果没有分片则返回 None
        """
        if not self.fragments:
            return None
        return self.fragments[-1]["path"]

    def get_latest_fragment_index(self) -> int:
        """
        获取最新分片的索引号

        返回:
            最新分片的索引号，如果没有分片则返回 -1
        """
        if not self.fragments:
            return -1
        return self.fragments[-1]["index"]

    def get_all_fragment_paths(self) -> List[str]:
        """
        获取所有分片文件路径

        返回:
            分片路径列表（按索引顺序）
        """
        return [f["path"] for f in self.fragments]

    def set_schema(self, channel_defs: List[ChannelDef]) -> None:
        """
        设置通道 Schema

        将通道定义列表序列化为字典格式，保存到索引文件中。
        确保所有分片文件的通道定义一致。

        参数:
            channel_defs: 通道定义列表
        """
        self.schema = {
            "channels": [
                {
                    "name": ch.name,
                    "unit": ch.unit,
                    "data_type": ch.data_type,
                    "comment": ch.comment,
                    "display_name": ch.display_name,
                    "conversion": ch.conversion,
                }
                for ch in channel_defs
            ]
        }

    def total_records(self) -> int:
        """
        获取所有分片的总记录数

        返回:
            跨所有分片的累计记录数
        """
        return sum(f["records"] for f in self.fragments)

    def total_size(self) -> int:
        """
        获取所有分片的总大小（字节）

        返回:
            跨所有分片的累计文件大小
        """
        return sum(f["size"] for f in self.fragments)


# =============================================================================
# 主写入器类
# =============================================================================

class MDFWriter:
    """
    线程安全的 ASAM MDF 文件写入器

    核心功能：
        1. 支持三种操作模式（NORMAL/FRAGMENTED/STREAMING）
        2. 支持连续数据和间歇数据
        3. 分片模式下以体积阈值自动切分
        4. 所有公共方法线程安全（RLock 保护）

    FRAGMENTED 模式分片机制：
        - 分片触发：estimated_size = 64KB + records × 12 bytes
        - 当 estimated_size >= fragment_size 时创建新分片
        - 分片命名：base_001.mf4, base_002.mf4, ...
        - 索引文件：base.index（JSON 格式）
        - 每个分片包含完整 Schema

    使用示例:
        # 分片模式 - 自动按体积切分
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=10*1024*1024,  # 10MB 阈值
        )
        with MDFWriter("output.mf4", config) as w:
            w.define_channels([ChannelDef("Speed", "km/h")])
            for i in range(100000):
                w.append_continuous({"Speed": [float(i)]}, [i*0.01])
        # 结果: output_001.mf4, output_002.mf4, ... (每个约10MB)
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化 MDF 写入器

        步骤：
            1. 保存配置和路径
            2. 创建 RLock
            3. 初始化状态变量
            4. 初始化缓冲区
            5. 初始化分片状态（FRAGMENTED 模式）
            6. 调用 _initialize() 创建/加载 MDF
            7. 启动后台线程（STREAMING 模式且启用）
            8. 设置 _is_open = True

        参数:
            filepath: 输出文件的基础路径（逻辑文件名）
                      FRAGMENTED 模式下作为分片命名基础
            config:   MDFConfig 配置对象，默认使用 NORMAL 模式
        """
        # 保存配置对象（使用默认配置如果未提供）
        self.config: MDFConfig = config or MDFConfig()
        # 保存文件路径
        self.filepath: str = filepath

        # ===================================================================
        # 线程同步机制
        # ===================================================================
        # 可重入锁，允许同一线程多次获取
        self._lock: threading.RLock = threading.RLock()

        # ===================================================================
        # 状态管理
        # ===================================================================
        # 文件是否处于打开状态
        self._is_open: bool = False
        # 通道定义列表
        self._channel_defs: List[ChannelDef] = []
        # 通道是否已定义
        self._channels_defined: bool = False
        # 数据连续性类型
        self._continuity: DataContinuity = DataContinuity.CONTINUOUS

        # ===================================================================
        # 数据缓冲区
        # ===================================================================
        # 连续数据缓冲区
        self._cont_buffer: _ContinuousBuffer = _ContinuousBuffer()
        # 间歇数据缓冲区
        self._inter_buffer: _IntermittentBuffer = _IntermittentBuffer()
        # 上次刷盘时间戳
        self._last_flush_time: float = 0.0

        # ===================================================================
        # 后台线程（STREAMING 模式）
        # ===================================================================
        # 后台刷盘线程引用
        self._bg_thread: Optional[threading.Thread] = None
        # 后台线程停止事件
        self._bg_stop_event: threading.Event = threading.Event()

        # ===================================================================
        # asammdf 核心对象
        # ===================================================================
        # asammdf.MDF 对象，实际数据操作通过它完成
        self._mdf: Optional[MDF] = None

        # ===================================================================
        # 分片模式专用状态
        # ===================================================================
        # 分片索引管理器
        self._fragment_index: Optional[FragmentIndex] = None
        # 当前分片索引号（从 1 开始）
        self._current_fragment_idx: int = 0
        # 当前分片文件路径
        self._current_fragment_path: str = ""
        # 当前分片已写入记录数
        self._current_fragment_records: int = 0

        # ===================================================================
        # 统计信息
        # ===================================================================
        # 写入器统计对象
        self.stats: WriterStats = WriterStats()
        # 初始化开始时间
        self._start_time: float = time.time()

        # ===================================================================
        # 执行初始化
        # ===================================================================
        self._initialize()

        # ===================================================================
        # 启动后台线程（如果启用）
        # ===================================================================
        if (self.config.operation_mode == OperationMode.STREAMING
                and self.config.stream_enable_background_thread):
            self._start_background_thread()

        # 标记为打开状态
        self._is_open = True
        logger.info(
            f"MDFWriter 初始化完成: path={filepath}, "
            f"mode={self.config.operation_mode.value}, "
            f"frag_size={self.config.fragment_size}"
        )

    @property
    def is_open(self) -> bool:
        """
        文件是否处于打开状态（只读属性）

        返回:
            True 如果写入器处于打开状态
        """
        return self._is_open

    # ======================================================================
    # 初始化方法
    # ======================================================================

    def _initialize(self) -> None:
        """
        初始化 MDF 对象和分片状态

        步骤：
            1. FRAGMENTED 模式：
               a. 创建 FragmentIndex
               b. 尝试加载已有索引
               c. 如果有索引，加载最新分片
               d. 否则创建第一个分片
            2. 其他模式：直接创建/加载 MDF 对象
        """
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            # 创建分片索引管理器
            self._fragment_index = FragmentIndex(self.filepath)

            # 尝试加载已有索引
            if self._fragment_index.load():
                # 已有索引，加载最新分片继续追加
                latest_path = self._fragment_index.get_latest_fragment_path()
                self._current_fragment_idx = self._fragment_index.get_latest_fragment_index()
                if latest_path and os.path.exists(latest_path):
                    # 加载已有的最新分片文件
                    self._current_fragment_path = latest_path
                    self._mdf = MDF(latest_path)
                    # 恢复统计信息
                    self.stats.fragment_count = len(self._fragment_index.fragments)
                    self.stats.fragment_index = self._current_fragment_idx
                    logger.info(
                        f"加载已有分片 #{self._current_fragment_idx}: "
                        f"{latest_path}"
                    )
                    return
            else:
                # 新建索引，设置创建时间
                self._fragment_index.created_at = time.strftime("%Y-%m-%dT%H:%M:%S")

            # 创建第一个分片（索引从 0 开始，_create_new_fragment 会先递增）
            self._create_new_fragment()
        else:
            # 非分片模式：直接创建或加载 MDF
            self._create_mdf(self.filepath)

    def _create_mdf(self, path: str) -> None:
        """
        创建或加载 MDF 对象

        规则：
            - 如果文件存在且大小 >= 64 字节，加载已有文件
            - 否则创建新的空 MDF 对象

        参数:
            path: MDF 文件路径
        """
        if os.path.exists(path) and os.path.getsize(path) >= 64:
            # 文件存在且有效（至少包含 MDF ID 块）
            self._mdf = MDF(path)
        else:
            # 创建新的空 MDF 对象
            self._mdf = MDF(version=self.config.version)

    def _create_new_fragment(self) -> None:
        """
        创建新的分片文件

        步骤：
            1. 关闭旧的 MDF 对象（不重复 save，数据已通过 _save_current_fragment 保存）
            2. 递增分片索引
            3. 生成分片路径
            4. 创建新的空 MDF 对象
            5. 如果有通道定义，应用 Schema 到新分片
            6. 更新索引

        注意：旧 MDF 的 close 不调用 save，因为数据已在切分时保存。
        """
        # 关闭旧 MDF 对象（只 close，不 save）
        if self._mdf is not None:
            try:
                self._mdf.close()
            except Exception:
                # 忽略关闭异常，确保继续创建新分片
                pass

        # 递增分片索引（从 1 开始）
        self._current_fragment_idx += 1
        # 根据基础路径和索引生成分片路径
        self._current_fragment_path = FragmentIndex._get_fragment_path(
            self.filepath, self._current_fragment_idx
        )
        # 重置当前分片记录计数器
        self._current_fragment_records = 0

        # 创建新的空 MDF 对象
        self._mdf = MDF(version=self.config.version)

        # 如果已有通道定义，将 Schema 应用到新分片
        if self._channels_defined and self._channel_defs:
            self._apply_schema_to_new_fragment()

        # 更新统计信息
        self.stats.fragment_count = self._current_fragment_idx
        self.stats.fragment_index = self._current_fragment_idx

        # 更新索引文件
        if self._fragment_index is not None:
            self._fragment_index.add_fragment(
                index=self._current_fragment_idx,
                path=self._current_fragment_path,
                size=0,           # 新分片初始大小为 0
                records=0,        # 新分片初始记录数为 0
                start_time=0.0,
                end_time=0.0,
            )

        logger.info(
            f"创建新分片 #{self._current_fragment_idx}: "
            f"{self._current_fragment_path}"
        )

    def _apply_schema_to_new_fragment(self) -> None:
        """
        将通道 Schema 应用到新创建的分片

        方法：通过写入空 Signal 数组来创建通道结构。
        这是确保新分片具有完整 Schema 的关键步骤，
        使得每个分片都可以独立读取。

        注意：asammdf 需要至少 append 一次才能建立通道结构。
        """
        if not self._channel_defs:
            # 无通道定义时直接返回
            return

        # 为每个通道创建空 Signal
        signals = []
        for ch in self._channel_defs:
            sig = Signal(
                samples=np.array([], dtype=np.dtype(ch.data_type)),
                timestamps=np.array([], dtype=np.float64),
                name=ch.name,
                unit=ch.unit,
                comment=ch.comment,
            )
            signals.append(sig)

        # 追加到 MDF（创建通道结构）
        if signals:
            self._mdf.append(signals)

    def _check_fragment_split(self) -> None:
        """
        检查是否需要切分新分片

        估算公式：estimated_size = 64KB(基础头) + records × 12 bytes
            - 64KB: MDF 文件头、通道组、通道元数据等开销
            - 12 bytes: 每条记录的估算大小（float32 样本 + float64 时间戳）

        步骤：
            1. 估算当前分片文件大小
            2. 如果 >= fragment_size，先 save 当前分片，再创建新分片

        重要：此方法不频繁访问文件系统，使用内存中的记录数估算。
        """
        # 非分片模式直接返回
        if self.config.operation_mode != OperationMode.FRAGMENTED:
            return

        # 估算文件大小：MDF 基础头约 64KB + 数据（每记录约 12 字节）
        estimated_size = 64 * 1024 + self._current_fragment_records * 12

        # 检查是否达到分片阈值
        if estimated_size >= self.config.fragment_size:
            # 达到阈值，先保存当前分片
            self._save_current_fragment()
            # 再创建新分片
            self._create_new_fragment()

    # ======================================================================
    # 后台线程（STREAMING 模式专用）
    # ======================================================================

    def _start_background_thread(self) -> None:
        """
        启动后台刷盘线程

        创建并启动一个守护线程，按 stream_flush_interval_ms 间隔
        自动检查并刷盘缓冲区数据。

        线程安全：后台线程在获取锁后检查 _is_open 状态。
        """
        # 清除停止事件
        self._bg_stop_event.clear()
        # 创建后台线程
        self._bg_thread = threading.Thread(
            target=self._background_flush_loop,
            name="MDFWriter-BGFlush",
            daemon=True,  # 守护线程，主线程退出时自动终止
        )
        # 启动线程
        self._bg_thread.start()

    def _background_flush_loop(self) -> None:
        """
        后台刷盘循环

        按配置的时间间隔周期性地调用 _do_flush_all()。
        线程在以下情况退出：
            1. _bg_stop_event 被设置
            2. _is_open 变为 False
        """
        # 将毫秒间隔转换为秒
        interval_s = self.config.stream_flush_interval_ms / 1000.0
        while not self._bg_stop_event.is_set():
            # 等待停止事件或超时
            stopped = self._bg_stop_event.wait(timeout=interval_s)
            if stopped:
                # 收到停止信号，退出循环
                break
            # 获取锁后检查状态并刷盘
            with self._lock:
                if not self._is_open:
                    break
                self._do_flush_all()

    def _stop_background_thread(self) -> None:
        """
        停止后台刷盘线程

        设置停止事件并等待线程退出（最多 5 秒）。
        """
        if self._bg_thread and self._bg_thread.is_alive():
            # 设置停止事件
            self._bg_stop_event.set()
            # 等待线程退出
            self._bg_thread.join(timeout=5.0)
            # 清理引用
            self._bg_thread = None

    # ======================================================================
    # 通道定义
    # ======================================================================

    def define_channels(self, channels: List[ChannelDef],
                         continuity: DataContinuity = DataContinuity.CONTINUOUS) -> None:
        """
        定义通道布局（Schema）

        必须在写入数据之前调用。定义通道后：
            1. 初始化数据缓冲区
            2. 分片模式下保存 Schema 到索引
            3. 分片模式下同步到当前分片

        参数:
            channels:   通道定义列表（至少一个元素）
            continuity: 数据连续性类型（CONTINUOUS 或 INTERMITTENT）

        异常:
            MDFWriterStateError:     文件未打开
            MDFWriterValidationError: 通道列表为空或名称重复
        """
        with self._lock:
            # 检查文件状态
            if not self._is_open:
                raise MDFWriterStateError(
                    "文件未打开，无法定义通道"
                )
            # 检查通道列表非空
            if not channels:
                raise MDFWriterValidationError(
                    "通道列表不能为空"
                )

            # 检查通道名称唯一性
            names = [ch.name for ch in channels]
            if len(names) != len(set(names)):
                raise MDFWriterValidationError(
                    "通道名称必须唯一，发现重复名称"
                )

            # 保存通道定义
            self._channel_defs = list(channels)
            self._channels_defined = True
            self._continuity = continuity

            # 初始化连续数据缓冲区
            self._cont_buffer = _ContinuousBuffer()
            for ch in channels:
                if ch.name not in self._cont_buffer.samples:
                    self._cont_buffer.samples[ch.name] = []

            # 分片模式：保存 Schema 到索引文件
            if self._fragment_index is not None:
                self._fragment_index.set_schema(self._channel_defs)
                self._fragment_index.save()

            logger.info(
                f"通道定义完成: {len(channels)} 个通道, "
                f"连续性: {continuity.value}"
            )

    # ======================================================================
    # 连续数据写入
    # ======================================================================

    def append_continuous(self, values: Dict[str, List[Any]],
                           timestamps: List[float]) -> int:
        """
        追加连续数据

        所有通道共享同一时间基。数据根据操作模式决定直接写入或缓冲。

        参数:
            values:     通道名 -> 样本列表的字典
            timestamps: 时间戳列表（所有通道共享）

        返回:
            实际写入（或缓冲）的记录数

        异常:
            MDFWriterStateError:      文件未打开或通道未定义
            MDFWriterValidationError: 样本数与时间戳数不匹配
        """
        with self._lock:
            # 状态检查
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            if not self._channels_defined:
                raise MDFWriterStateError(
                    "通道未定义，请先调用 define_channels()"
                )

            # 获取记录数
            record_count = len(timestamps)
            if record_count == 0:
                # 空数据直接返回
                return 0

            # 验证每个通道的样本数与时间戳数匹配
            for name, samples in values.items():
                if len(samples) != record_count:
                    raise MDFWriterValidationError(
                        f"通道 '{name}' 样本数 ({len(samples)}) 与 "
                        f"时间戳数 ({record_count}) 不匹配"
                    )

            # 根据操作模式选择写入方式
            if self.config.operation_mode == OperationMode.NORMAL:
                # 一般模式：直接写入
                self._write_direct_continuous(values, timestamps)
            else:
                # 分片/流式模式：缓冲写入
                self._write_buffered_continuous(values, timestamps)

            # 更新统计信息
            self.stats.total_records_written += record_count
            self.stats.total_signals_written += len(values)
            return record_count

    def _write_direct_continuous(self, values: Dict[str, List[Any]],
                                  timestamps: List[float]) -> None:
        """
        直接写入连续数据（NORMAL 模式专用）

        将数据立即追加到 asammdf.MDF 对象，不经过缓冲区。

        参数:
            values:     通道名 -> 样本列表
            timestamps: 时间戳列表
        """
        # 创建 Signal 列表并追加
        signals = self._create_signals(values, timestamps)
        self._mdf.append(signals)
        # 更新刷盘时间戳
        self._last_flush_time = time.time()

    def _write_buffered_continuous(self, values: Dict[str, List[Any]],
                                    timestamps: List[float]) -> None:
        """
        缓冲写入连续数据（FRAGMENTED/STREAMING 模式）

        将数据逐条添加到缓冲区，然后根据条件触发刷盘。

        参数:
            values:     通道名 -> 样本列表
            timestamps: 时间戳列表
        """
        # 逐条添加到缓冲区
        for i, ts in enumerate(timestamps):
            record_values = {name: vals[i] for name, vals in values.items()}
            self._cont_buffer.add_record(ts, record_values)

        # 更新缓冲区统计
        self.stats.buffer_records_current = self._cont_buffer.record_count
        self.stats.buffer_records_peak = max(
            self.stats.buffer_records_peak,
            self.stats.buffer_records_current
        )

        # 检查是否需要刷盘
        self._check_flush_continuous()

        # 分片模式：刷盘后检查是否需要切分
        if (self.config.operation_mode == OperationMode.FRAGMENTED
                and self._cont_buffer.is_empty()):
            self._check_fragment_split()

    def _check_flush_continuous(self) -> None:
        """
        检查并执行连续数据刷盘

        刷盘条件：
            FRAGMENTED 模式：缓冲区 >= 1000 条记录
            STREAMING 模式：  缓冲区 >= stream_buffer_size 或超时
        """
        if self._cont_buffer.is_empty():
            return

        need_flush = False
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            # 分片模式：批量刷盘（每 1000 条）
            if self._cont_buffer.record_count >= 1000:
                need_flush = True
        elif self.config.operation_mode == OperationMode.STREAMING:
            if not self.config.stream_enable_background_thread:
                # 无后台线程：缓冲区满或超时刷盘
                if (self._cont_buffer.record_count >= self.config.stream_buffer_size):
                    need_flush = True
                else:
                    elapsed = (time.time() - self._last_flush_time) * 1000
                    if elapsed >= self.config.stream_flush_interval_ms:
                        need_flush = True

        if need_flush:
            self._do_flush_continuous()

    def _do_flush_continuous(self) -> None:
        """
        执行连续数据刷盘

        将缓冲区数据追加到 asammdf.MDF 对象。

        重要说明：
            本方法不调用 save()。save() 只在以下情况调用：
                1. close() 时保存最终状态
                2. _check_fragment_split() 切分前保存旧分片

            原因：asammdf 的 save(overwrite=True) 在 MDF 对象已
            有文件关联时，会导致内存中的 groups 列表重复增长。
            通过最小化 save 调用次数来规避此问题。
        """
        if self._cont_buffer.is_empty():
            return
        try:
            # 提取缓冲区数据
            timestamps = self._cont_buffer.timestamps
            values = self._cont_buffer.samples
            # 创建 Signal 列表
            signals = self._create_signals(values, timestamps)
            # 追加到 asammdf（内存操作，不涉及磁盘 I/O）
            self._mdf.append(signals)

            # 更新分片记录计数
            record_count = self._cont_buffer.record_count
            self._current_fragment_records += record_count

            # 清空缓冲区
            self._cont_buffer.clear()
            self.stats.buffer_records_current = 0
            self.stats.total_flush_count += 1
            self.stats.last_flush_timestamp = time.time()
            self._last_flush_time = time.time()

            logger.debug(f"连续数据刷盘: {record_count} 条记录")
        except Exception as e:
            logger.error(f"连续数据刷盘失败: {e}", exc_info=True)
            self.stats.error_count += 1
            raise

    def _save_current_fragment(self) -> None:
        """
        保存当前分片文件并更新索引

        只在以下情况调用：
            1. 分片切分时（_check_fragment_split）
            2. close() 关闭时

        参数说明：
            使用 asammdf 的 save(path, overwrite=True) 方法。
            overwrite=True 允许覆盖已有文件。

        注意：频繁调用 save 会导致 asammdf 内存数据翻倍，
        因此只在必要时调用。
        """
        if self._fragment_index is None:
            return
        try:
            # 获取压缩设置
            compression = self._get_compression()
            # 保存当前分片（覆盖模式）
            self._mdf.save(
                self._current_fragment_path,
                overwrite=True,
                compression=compression
            )

            # 更新索引中最后一个分片的信息
            if self._fragment_index.fragments:
                last_frag = self._fragment_index.fragments[-1]
                last_frag["size"] = os.path.getsize(self._current_fragment_path)
                last_frag["records"] = self._current_fragment_records
                self._fragment_index.save()

            logger.debug(
                f"分片 #{self._current_fragment_idx} 已保存: "
                f"{self._current_fragment_path}"
            )
        except Exception as e:
            # 保存失败时记录警告但不抛出（避免中断写入流程）
            logger.warning(f"保存分片失败: {e}")

    # ======================================================================
    # 间歇数据写入
    # ======================================================================

    def append_intermittent(self, channel_name: str,
                             timestamp: float, value: Any) -> None:
        """
        追加间歇数据（单通道，独立时间基）

        适用于事件触发型数据，每条记录有独立的时间戳。

        参数:
            channel_name: 通道名称（必须在 define_channels 中定义）
            timestamp:    记录的时间戳
            value:        通道值

        异常:
            MDFWriterStateError:      文件未打开或通道未定义
            MDFWriterValidationError: 通道名称未定义
        """
        with self._lock:
            # 状态检查
            if not self._is_open:
                raise MDFWriterStateError("文件未打开")
            if not self._channels_defined:
                raise MDFWriterStateError(
                    "通道未定义，请先调用 define_channels()"
                )

            # 验证通道名称是否已定义
            channel_names = {ch.name for ch in self._channel_defs}
            if channel_name not in channel_names:
                raise MDFWriterValidationError(
                    f"通道 '{channel_name}' 未定义。"
                    f"已定义通道: {sorted(channel_names)}"
                )

            # 根据操作模式选择写入方式
            if self.config.operation_mode == OperationMode.NORMAL:
                # 一般模式：直接写入
                self._write_direct_intermittent(channel_name, timestamp, value)
            else:
                # 分片/流式模式：添加到缓冲区
                self._inter_buffer.add_record(timestamp, channel_name, value)
                # 分片模式：累加记录数并检查是否需要切分
                if self.config.operation_mode == OperationMode.FRAGMENTED:
                    self._current_fragment_records += 1
                    self._check_fragment_split()
                # 检查是否需要刷盘
                self._check_flush_intermittent()

    def _write_direct_intermittent(self, channel_name: str,
                                    timestamp: float, value: Any) -> None:
        """
        直接写入间歇数据（NORMAL 模式）

        单条记录直接追加到 asammdf.MDF 对象。

        参数:
            channel_name: 通道名称
            timestamp:    时间戳
            value:        通道值
        """
        # 查找通道定义获取单位和数据类型
        unit = ""
        dtype = "<f4"
        for ch in self._channel_defs:
            if ch.name == channel_name:
                unit = ch.unit
                dtype = ch.data_type
                break

        # 转换值为 NumPy 数组
        try:
            sample_array = np.array([value], dtype=np.dtype(dtype))
        except (TypeError, ValueError):
            # 类型转换失败时使用默认类型
            sample_array = np.array([value])

        # 创建 Signal 并追加
        sig = Signal(
            samples=sample_array,
            timestamps=np.array([timestamp], dtype=np.float64),
            name=channel_name,
            unit=unit,
        )
        self._mdf.append([sig])

    def _check_flush_intermittent(self) -> None:
        """
        检查间歇数据是否需要刷盘

        刷盘条件：
            FRAGMENTED 模式：缓冲区 >= 1000 条记录
        """
        if self.config.operation_mode == OperationMode.FRAGMENTED:
            if self._inter_buffer.get_record_count() >= 1000:
                self._do_flush_intermittent()

    def _do_flush_intermittent(self) -> None:
        """
        执行间歇数据刷盘

        将缓冲区中的间歇数据按通道分组，然后批量追加到 asammdf。

        步骤：
            1. 按通道名分组记录
            2. 为每个通道创建 Signal
            3. 追加到 asammdf
            4. 清空缓冲区
        """
        if self._inter_buffer.is_empty():
            return
        try:
            # 按通道名分组数据
            channel_data: Dict[str, Tuple[List[float], List[Any]]] = {}
            for ts, name, val in self._inter_buffer.records:
                if name not in channel_data:
                    channel_data[name] = ([], [])
                channel_data[name][0].append(ts)
                channel_data[name][1].append(val)

            # 为每个通道创建 Signal 并追加
            for name, (tss, samples) in channel_data.items():
                # 查找通道定义获取单位
                unit = ""
                for ch in self._channel_defs:
                    if ch.name == name:
                        unit = ch.unit
                        break
                sig = Signal(
                    samples=np.array(samples),
                    timestamps=np.array(tss, dtype=np.float64),
                    name=name,
                    unit=unit,
                )
                self._mdf.append([sig])

            # 清空缓冲区（记录数已在 append_intermittent 中实时递增）
            self._inter_buffer.clear()
            self.stats.total_flush_count += 1

            # 分片模式下保存当前分片
            if self.config.operation_mode == OperationMode.FRAGMENTED:
                self._save_current_fragment()

            logger.debug("间歇数据刷盘完成")
        except Exception as e:
            logger.error(f"间歇数据刷盘失败: {e}", exc_info=True)
            self.stats.error_count += 1
            raise

    # ======================================================================
    # 工具方法
    # ======================================================================

    def _create_signals(self, values: Dict[str, List[Any]],
                         timestamps: List[float]) -> List[Signal]:
        """
        将数据字典转换为 asammdf.Signal 列表

        遍历 values 字典，为每个通道创建一个 Signal 对象。
        从通道定义中查找对应的单位信息。

        参数:
            values:     通道名 -> 样本列表
            timestamps: 时间戳列表（所有通道共享）

        返回:
            asammdf.Signal 对象列表
        """
        signals = []
        # 转换时间戳为 float64 NumPy 数组
        ts_array = np.array(timestamps, dtype=np.float64)
        for name, samples in values.items():
            # 查找通道定义获取单位
            unit = ""
            for ch in self._channel_defs:
                if ch.name == name:
                    unit = ch.unit
                    break
            # 转换样本为 NumPy 数组
            sample_array = np.array(samples)
            # 创建 Signal
            sig = Signal(
                samples=sample_array,
                timestamps=ts_array,
                name=name,
                unit=unit,
            )
            signals.append(sig)
        return signals

    def _get_compression(self) -> int:
        """
        获取 asammdf 压缩算法枚举值

        将本模块的 CompressionType 枚举映射到
        asammdf 的 CompressionAlgorithm 枚举值。

        映射关系：
            NONE -> NO_COMPRESSION (0)
            ZIP  -> DEFLATE (1)
            ZSTD -> ZSTD (2)

        返回:
            asammdf CompressionAlgorithm 整数值
        """
        compression_map = {
            CompressionType.NONE: CompressionAlgorithm.NO_COMPRESSION,
            CompressionType.ZIP: CompressionAlgorithm.DEFLATE,
            CompressionType.ZSTD: CompressionAlgorithm.ZSTD,
        }
        return compression_map.get(
            self.config.compression,
            CompressionAlgorithm.NO_COMPRESSION
        )

    # ======================================================================
    # 公共方法
    # ======================================================================

    def flush(self) -> None:
        """
        手动刷盘所有缓冲区数据

        强制将连续数据和间歇数据缓冲区中的数据写入 MDF。
        此方法在以下情况很有用：
            - 需要确保数据已持久化到磁盘
            - 在关键操作前同步数据
            - 调试时检查缓冲区内容
        """
        with self._lock:
            if not self._is_open:
                return
            self._do_flush_all()

    def _do_flush_all(self) -> None:
        """
        刷盘所有数据（连续 + 间歇）

        内部方法，被 flush() 和 close() 调用。
        先刷连续数据，再刷间歇数据。
        """
        self._do_flush_continuous()
        self._do_flush_intermittent()

    def get_fragment_paths(self) -> List[str]:
        """
        获取所有存在的分片文件路径（分片模式专用）

        返回实际存在于文件系统中的分片路径。
        过滤掉可能已被删除的分片。

        返回:
            存在的分片文件路径列表

        异常:
            MDFWriterModeError: 非分片模式下调用
        """
        with self._lock:
            if self._fragment_index is not None:
                # 过滤掉不存在的文件路径
                return [
                    p for p in self._fragment_index.get_all_fragment_paths()
                    if os.path.exists(p)
                ]
            return []

    def get_info(self) -> Dict[str, Any]:
        """
        获取写入器状态信息

        返回包含写入器当前状态的字典，用于监控和调试。

        返回:
            包含 filepath, version, mode, stats 等信息的字典
        """
        with self._lock:
            info = {
                "filepath": self.filepath,
                "version": self.config.version,
                "operation_mode": self.config.operation_mode.value,
                "compression": self.config.compression.value,
                "is_open": self._is_open,
                "channels_defined": self._channels_defined,
                "channel_count": len(self._channel_defs),
                "channel_names": [ch.name for ch in self._channel_defs],
                "stats": self.stats.to_dict(),
            }
            # 分片模式专用信息
            if self._fragment_index is not None:
                info["fragment_count"] = len(self._fragment_index.fragments)
                info["fragment_paths"] = self._fragment_index.get_all_fragment_paths()
                info["total_size"] = self._fragment_index.total_size()
                info["total_records"] = self._fragment_index.total_records()
            return info

    # ======================================================================
    # 关闭和资源释放
    # ======================================================================

    def close(self) -> None:
        """
        关闭写入器并释放所有资源

        步骤：
            1. 停止后台刷盘线程
            2. 刷盘所有缓冲区数据
            3. 保存最终 MDF 文件
            4. 关闭 asammdf 对象
            5. 更新统计信息

        注意：此方法可安全多次调用（幂等）。
        """
        with self._lock:
            # 幂等性检查
            if not self._is_open:
                return

            logger.info("正在关闭 MDFWriter...")

            try:
                # 停止后台刷盘线程
                self._stop_background_thread()
                # 刷盘所有剩余数据
                self._do_flush_all()

                # 保存最终状态
                if self._mdf is not None:
                    compression = self._get_compression()
                    if self.config.operation_mode == OperationMode.FRAGMENTED:
                        # 分片模式：保存当前分片（只 save 一次）
                        try:
                            self._mdf.save(
                                self._current_fragment_path,
                                overwrite=True,
                                compression=compression
                            )
                            # 更新索引
                            if self._fragment_index and self._fragment_index.fragments:
                                last = self._fragment_index.fragments[-1]
                                last["size"] = os.path.getsize(
                                    self._current_fragment_path
                                )
                                last["records"] = self._current_fragment_records
                                self._fragment_index.save()
                        except Exception as e:
                            logger.warning(f"保存最终分片失败: {e}")
                        # 关闭 asammdf 对象
                        self._mdf.close()
                    else:
                        # 非分片模式：保存到指定路径
                        self._mdf.save(
                            self.filepath,
                            overwrite=True,
                            compression=compression
                        )
                        self._mdf.close()
                    # 清除引用
                    self._mdf = None

                # 标记为关闭状态
                self._is_open = False
                # 计算运行时间
                self.stats.uptime_seconds = time.time() - self._start_time
                logger.info("MDFWriter 已关闭")

            except Exception as e:
                logger.error(f"关闭 MDFWriter 失败: {e}", exc_info=True)
                self.stats.error_count += 1
                raise

    def __enter__(self):
        """
        上下文管理器入口

        支持 with 语句使用：
            with MDFWriter("path", config) as w:
                w.append_continuous(...)
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器出口

        确保退出 with 块时自动关闭写入器。
        捕获并忽略关闭异常，避免掩盖原始异常。
        """
        try:
            self.close()
        except Exception:
            pass
        return False


# =============================================================================
# 追加写入器类
# =============================================================================

class MDFAppendWriter(MDFWriter):
    """
    追加写入器（专门用于在已有文件上追加数据）

    继承自 MDFWriter，默认以 NORMAL 模式打开已有文件并追加数据。
    是对 MDFWriter 的便捷包装，语义上更清晰。

    使用示例:
        with MDFAppendWriter("existing.mf4") as w:
            w.define_channels([ChannelDef("Speed", "km/h")])
            w.append_continuous({"Speed": [10.0]}, [0.0])
    """

    def __init__(self, filepath: str, config: Optional[MDFConfig] = None):
        """
        初始化追加写入器

        参数:
            filepath: 已有 MDF 文件路径
            config:   配置对象（默认为 NORMAL 模式）
        """
        # 使用默认配置如果未提供
        if config is None:
            config = MDFConfig(operation_mode=OperationMode.NORMAL)
        super().__init__(filepath, config)


# =============================================================================
# 模块导出
# =============================================================================

__all__ = [
    # 主写入器类
    "MDFWriter",
    "MDFAppendWriter",
    # 索引管理
    "FragmentIndex",
    # 异常类
    "MDFWriterError",
    "MDFWriterStateError",
    "MDFWriterValidationError",
    "MDFWriterModeError",
    "MDFWriterThreadError",
]
