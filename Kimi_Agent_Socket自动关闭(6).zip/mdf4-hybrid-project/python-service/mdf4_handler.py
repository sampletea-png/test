"""
MDF4 Handler Module
Core module for MDF4 file operations using asammdf library.
Supports write, read, partial read operations, and metadata storage as JSON strings in comments.
"""

import os
import json
import re
import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime
from asammdf import MDF, Signal
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants for metadata markers
META_START_MARKER = "[METADATA_JSON]"
META_END_MARKER = "[/METADATA_JSON]"


@dataclass
class DataRecord:
    """Data record for transferring between Java and Python"""
    channel_name: str
    timestamps: List[float]
    values: List[float]
    unit: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class Mdf4Handler:
    """
    Handler class for MDF4 file operations.
    Provides methods for creating, reading, and partially reading MDF4 files.
    Supports file and channel metadata storage as JSON strings in comments.
    """
    
    def __init__(self):
        self._mdf: Optional[MDF] = None
        self._file_path: Optional[str] = None
    
    def create_new_file(self, file_path: str) -> bool:
        """
        Create a new MDF4 file.
        
        Args:
            file_path: Path to the new MDF4 file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            self._mdf = MDF(version='4.10')
            self._file_path = file_path
            
            # Initialize with empty metadata
            self._save_file_metadata_to_header({})
            
            logger.info(f"Created new MDF4 file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to create MDF4 file: {e}")
            return False
    
    def open_file(self, file_path: str, read_only: bool = True) -> bool:
        """
        Open an existing MDF4 file.
        
        Args:
            file_path: Path to the MDF4 file
            read_only: Whether to open in read-only mode
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return False
            
            self._mdf = MDF(file_path)
            self._file_path = file_path
            
            logger.info(f"Opened MDF4 file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to open MDF4 file: {e}")
            return False
    
    def close_file(self) -> bool:
        """
        Close the current MDF4 file.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf:
                self._mdf.close()
                self._mdf = None
                self._file_path = None
                logger.info("Closed MDF4 file")
            return True
        except Exception as e:
            logger.error(f"Failed to close MDF4 file: {e}")
            return False
    
    def add_channel(self, channel_name: str, timestamps: List[float], 
                    values: List[float], unit: str = "", 
                    comment: str = "", data_type: str = "float",
                    metadata: Dict[str, Any] = None) -> bool:
        """
        Add a channel to the MDF4 file.
        
        Args:
            channel_name: Name of the channel
            timestamps: List of timestamp values
            values: List of data values
            unit: Unit of measurement
            comment: Channel comment/description
            data_type: Data type ('float', 'int', 'double')
            metadata: Additional channel metadata (stored as JSON string in comment)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            # Convert lists to numpy arrays
            timestamps_arr = np.array(timestamps, dtype=np.float64)
            
            # Convert values based on data type
            if data_type == "int":
                values_arr = np.array(values, dtype=np.int32)
            elif data_type == "double":
                values_arr = np.array(values, dtype=np.float64)
            else:
                values_arr = np.array(values, dtype=np.float32)
            
            # Build comment with embedded metadata as JSON string
            enhanced_comment = self._embed_metadata_in_comment(comment, metadata)
            
            # Create Signal object
            signal = Signal(
                samples=values_arr,
                timestamps=timestamps_arr,
                name=channel_name,
                unit=unit,
                comment=enhanced_comment
            )
            
            # Append to MDF file
            self._mdf.append(signal)
            
            logger.info(f"Added channel: {channel_name} ({len(values)} samples)")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add channel: {e}")
            return False
    
    def save_file(self, file_path: str = None, compression: int = 0) -> bool:
        """
        Save the MDF4 file.
        
        Args:
            file_path: Path to save the file (optional, uses original path if not specified)
            compression: Compression level (0=no compression, 1=fast, 2=standard)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            save_path = file_path or self._file_path
            if not save_path:
                logger.error("No file path specified")
                return False
            
            self._mdf.save(save_path, compression=compression, overwrite=True)
            logger.info(f"Saved MDF4 file: {save_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save MDF4 file: {e}")
            return False
    
    # ==================== Metadata Operations (JSON in Comment) ====================
    
    def _embed_metadata_in_comment(self, comment: str, metadata: Dict[str, Any] = None) -> str:
        """
        Embed metadata as JSON string in comment.
        Format: [METADATA_JSON]{...}[/METADATA_JSON]
        """
        parts = []
        
        # Add user comment if provided
        if comment:
            parts.append(comment)
        
        # Add metadata as JSON string
        if metadata:
            try:
                metadata_json = json.dumps(metadata, ensure_ascii=False)
                parts.append(f"{META_START_MARKER}{metadata_json}{META_END_MARKER}")
            except Exception as e:
                logger.warning(f"Failed to serialize metadata to JSON: {e}")
        
        return " | ".join(parts) if parts else ""
    
    def _extract_metadata_from_comment(self, comment: str) -> Tuple[str, Dict[str, Any]]:
        """
        Extract metadata JSON string from comment.
        
        Returns:
            Tuple of (clean_comment, metadata_dict)
        """
        if not comment:
            return "", {}
        
        # Look for metadata marker
        pattern = re.escape(META_START_MARKER) + r'(.*?)' + re.escape(META_END_MARKER)
        match = re.search(pattern, comment, re.DOTALL)
        
        metadata = {}
        if match:
            try:
                metadata = json.loads(match.group(1))
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse metadata JSON: {e}")
            
            # Remove metadata marker from comment
            clean_comment = re.sub(pattern, '', comment, flags=re.DOTALL).strip(' |')
            return clean_comment, metadata
        
        return comment, {}
    
    def set_file_metadata(self, metadata: Dict[str, Any]) -> bool:
        """
        Set file-level metadata (stored as JSON string in header comment).
        
        Args:
            metadata: Dictionary containing metadata fields
            
        Returns:
            True if successful
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            # Add timestamps
            metadata['createdAt'] = metadata.get('createdAt', datetime.now().isoformat())
            metadata['modifiedAt'] = datetime.now().isoformat()
            
            # Save to header comment as JSON string
            self._save_file_metadata_to_header(metadata)
            
            logger.info("File metadata updated")
            return True
        except Exception as e:
            logger.error(f"Failed to set file metadata: {e}")
            return False
    
    def _save_file_metadata_to_header(self, metadata: Dict[str, Any]):
        """Save file metadata to MDF header comment as JSON string"""
        try:
            if self._mdf is None:
                return
            
            # Store as JSON string in header comment with marker
            metadata_json = json.dumps(metadata, ensure_ascii=False)
            self._mdf.header.comment = f"{META_START_MARKER}{metadata_json}{META_END_MARKER}"
            logger.debug("File metadata saved to header as JSON string")
        except Exception as e:
            logger.warning(f"Failed to save metadata to header: {e}")
    
    def get_file_metadata(self) -> Dict[str, Any]:
        """
        Get file-level metadata (parsed from JSON string in header comment).
        
        Returns:
            Dictionary containing metadata
        """
        try:
            if self._mdf is None:
                return {}
            
            header_comment = self._mdf.header.comment
            if not header_comment:
                return {}
            
            # Extract metadata from header comment
            _, metadata = self._extract_metadata_from_comment(header_comment)
            return metadata
            
        except Exception as e:
            logger.warning(f"Failed to get file metadata: {e}")
            return {}
    
    def set_channel_metadata(self, channel_name: str, metadata: Dict[str, Any]) -> bool:
        """
        Set metadata for a specific channel.
        Note: This requires rewriting the channel comment, which may not be directly
        supported by asammdf. Metadata should be set when adding the channel.
        
        Args:
            channel_name: Name of the channel
            metadata: Dictionary containing metadata
            
        Returns:
            True if successful
        """
        logger.warning("set_channel_metadata: Metadata should be set when adding channel")
        return False
    
    def get_channel_metadata(self, channel_name: str) -> Dict[str, Any]:
        """
        Get metadata for a specific channel (parsed from JSON string in comment).
        
        Args:
            channel_name: Name of the channel
            
        Returns:
            Dictionary containing metadata
        """
        try:
            if self._mdf is None:
                return {}
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                return {}
            
            # Extract metadata from comment
            _, metadata = self._extract_metadata_from_comment(signal.comment)
            return metadata
            
        except Exception as e:
            logger.error(f"Failed to get channel metadata: {e}")
            return {}
    
    # ==================== Read Operations ====================
    
    def get_channel_names(self) -> List[str]:
        """Get list of all channel names in the file."""
        try:
            if self._mdf is None:
                return []
            return list(self._mdf.channels_db.keys())
        except Exception as e:
            logger.error(f"Failed to get channel names: {e}")
            return []
    
    def get_channel_info(self, channel_name: str) -> Optional[Dict]:
        """Get information about a specific channel - returns dict matching Java ChannelInfo."""
        try:
            if self._mdf is None:
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                return None
            
            # Extract metadata from comment
            clean_comment, metadata = self._extract_metadata_from_comment(signal.comment)
            
            # Return dict with field names matching Java ChannelInfo class
            return {
                'name': signal.name,
                'unit': signal.unit or "",
                'comment': clean_comment or "",
                'dataType': 'float',  # Default, could be enhanced
                'samplesCount': len(signal.samples),
                'firstTimestamp': float(signal.timestamps[0]) if len(signal.timestamps) > 0 else 0,
                'lastTimestamp': float(signal.timestamps[-1]) if len(signal.timestamps) > 0 else 0,
                'metadataJson': json.dumps(metadata) if metadata else "{}",
                'metadata': metadata or {}
            }
        except Exception as e:
            logger.error(f"Failed to get channel info: {e}")
            return None
    
    def read_channel(self, channel_name: str) -> Optional[DataRecord]:
        """Read all data from a specific channel."""
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                logger.error(f"Channel not found: {channel_name}")
                return None
            
            # Extract metadata from comment
            _, metadata = self._extract_metadata_from_comment(signal.comment)
            
            return DataRecord(
                channel_name=signal.name,
                timestamps=signal.timestamps.tolist(),
                values=signal.samples.tolist(),
                unit=signal.unit,
                metadata=metadata
            )
            
        except Exception as e:
            logger.error(f"Failed to read channel: {e}")
            return None
    
    def read_channels_partial(self, channel_names: List[str], 
                              start_time: float, 
                              end_time: float) -> List[DataRecord]:
        """Partially read data from multiple channels within a time range."""
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return []
            
            results = []
            for channel_name in channel_names:
                signal = self._mdf.get(channel_name)
                if signal is None:
                    logger.warning(f"Channel not found: {channel_name}")
                    continue
                
                # Filter by time range
                mask = (signal.timestamps >= start_time) & (signal.timestamps <= end_time)
                filtered_timestamps = signal.timestamps[mask]
                filtered_values = signal.samples[mask]
                
                if len(filtered_timestamps) > 0:
                    _, metadata = self._extract_metadata_from_comment(signal.comment)
                    results.append(DataRecord(
                        channel_name=signal.name,
                        timestamps=filtered_timestamps.tolist(),
                        values=filtered_values.tolist(),
                        unit=signal.unit,
                        metadata=metadata
                    ))
            
            logger.info(f"Partial read: {len(results)} channels, time range [{start_time}, {end_time}]")
            return results
            
        except Exception as e:
            logger.error(f"Failed to read channels partially: {e}")
            return []
    
    def read_channel_partial(self, channel_name: str, 
                            start_index: int, 
                            count: int) -> Optional[DataRecord]:
        """Partially read data from a channel by index range."""
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                logger.error(f"Channel not found: {channel_name}")
                return None
            
            end_index = min(start_index + count, len(signal.samples))
            _, metadata = self._extract_metadata_from_comment(signal.comment)
            
            return DataRecord(
                channel_name=signal.name,
                timestamps=signal.timestamps[start_index:end_index].tolist(),
                values=signal.samples[start_index:end_index].tolist(),
                unit=signal.unit,
                metadata=metadata
            )
            
        except Exception as e:
            logger.error(f"Failed to read channel partially: {e}")
            return None
    
    def get_sample_count(self, channel_name: str) -> int:
        """Get the total number of samples for a channel."""
        try:
            if self._mdf is None:
                return 0
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                return 0
            
            return len(signal.samples)
        except Exception as e:
            logger.error(f"Failed to get sample count: {e}")
            return 0
    
    def get_time_range(self) -> Tuple[float, float]:
        """Get the time range of the measurement."""
        try:
            if self._mdf is None:
                return (0.0, 0.0)
            
            for channel_name in self._mdf.channels_db.keys():
                signal = self._mdf.get(channel_name)
                if signal is not None and len(signal.timestamps) > 0:
                    return (float(signal.timestamps[0]), float(signal.timestamps[-1]))
            
            return (0.0, 0.0)
        except Exception as e:
            logger.error(f"Failed to get time range: {e}")
            return (0.0, 0.0)
    
    def filter_channels(self, channel_names: List[str]) -> bool:
        """Filter the MDF file to keep only specified channels."""
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            self._mdf = self._mdf.filter(channel_names)
            logger.info(f"Filtered to {len(channel_names)} channels")
            return True
            
        except Exception as e:
            logger.error(f"Failed to filter channels: {e}")
            return False
    
    def cut_time_range(self, start_time: float, end_time: float) -> bool:
        """Cut the MDF file to a specific time range."""
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            self._mdf = self._mdf.cut(start=start_time, stop=end_time)
            logger.info(f"Cut to time range [{start_time}, {end_time}]")
            return True
            
        except Exception as e:
            logger.error(f"Failed to cut time range: {e}")
            return False
    
    def write_multiple_channels(self, channels: List[Dict[str, Any]]) -> bool:
        """Write multiple channels at once."""
        try:
            for channel_data in channels:
                name = channel_data.get('name')
                timestamps = channel_data.get('timestamps', [])
                values = channel_data.get('values', [])
                unit = channel_data.get('unit', '')
                comment = channel_data.get('comment', '')
                data_type = channel_data.get('dataType', 'float')
                metadata = channel_data.get('metadata', {})
                
                success = self.add_channel(name, timestamps, values, unit, comment, data_type, metadata)
                if not success:
                    logger.error(f"Failed to add channel: {name}")
                    return False
            
            logger.info(f"Successfully wrote {len(channels)} channels")
            return True
            
        except Exception as e:
            logger.error(f"Failed to write multiple channels: {e}")
            return False
    
    def read_multiple_channels(self, channel_names: List[str]) -> List[DataRecord]:
        """Read multiple channels at once."""
        results = []
        for channel_name in channel_names:
            record = self.read_channel(channel_name)
            if record is not None:
                results.append(record)
        return results


# Singleton instance for socket server
_handler_instance = None


def get_handler() -> Mdf4Handler:
    """Get the singleton handler instance"""
    global _handler_instance
    if _handler_instance is None:
        _handler_instance = Mdf4Handler()
    return _handler_instance
