"""
Unified Protocol Module
Defines request/response structures for object-based communication.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, Any, Dict, List, TypeVar, Generic
from datetime import datetime

T = TypeVar('T')


@dataclass
class Request(Generic[T]):
    """统一请求对象"""
    cmd: str
    params: Optional[T] = None
    reqId: str = "0"


@dataclass
class Response(Generic[T]):
    """统一响应对象"""
    success: bool
    data: Optional[T] = None
    error: Optional[str] = None
    reqId: str = "0"
    
    @staticmethod
    def success_result(data: Any, req_id: str = "0") -> 'Response':
        return Response(success=True, data=data, reqId=req_id)
    
    @staticmethod
    def error_result(error: str, req_id: str = "0") -> 'Response':
        return Response(success=False, error=error, reqId=req_id)


# ==================== Request Params ====================

@dataclass
class CreateFileParams:
    filePath: str
    autoCreateDirs: bool = True
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class OpenFileParams:
    filePath: str
    readOnly: bool = True
    autoCreate: bool = False
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class SaveFileParams:
    filePath: Optional[str] = None
    compression: int = 0


@dataclass
class AddChannelParams:
    channelName: str
    timestamps: List[float] = field(default_factory=list)
    values: List[float] = field(default_factory=list)
    unit: str = ""
    comment: str = ""
    dataType: str = "float"
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ChannelNameParams:
    channelName: str


@dataclass
class ReadPartialParams:
    channelName: str
    startIndex: int = 0
    count: int = 0


@dataclass
class ReadTimeRangeParams:
    channelNames: List[str] = field(default_factory=list)
    startTime: float = 0.0
    endTime: float = 0.0


@dataclass
class FilterChannelsParams:
    channelNames: List[str] = field(default_factory=list)


@dataclass
class CutTimeRangeParams:
    startTime: float = 0.0
    endTime: float = 0.0


@dataclass
class WriteMultipleChannelsParams:
    channels: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class SetChannelMetadataParams:
    channelName: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SetFileMetadataParams:
    metadata: Dict[str, Any] = field(default_factory=dict)


# ==================== Response Results ====================

@dataclass
class SuccessResult:
    success: bool = True


@dataclass
class FilePathResult:
    success: bool = True
    filePath: Optional[str] = None
    created: Optional[bool] = None


@dataclass
class ChannelNamesResult:
    names: List[str] = field(default_factory=list)


@dataclass
class ChannelInfoResult:
    info: Optional[Dict[str, Any]] = None


@dataclass
class FileMetadataResult:
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChannelMetadataResult:
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataRecordResult:
    record: Optional[Dict[str, Any]] = None


@dataclass
class DataRecordsResult:
    records: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class SampleCountResult:
    count: int = 0


@dataclass
class TimeRangeResult:
    range: List[float] = field(default_factory=lambda: [0.0, 0.0])


@dataclass
class PingResult:
    status: str = "ok"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class HandshakeResult:
    version: str = "1.0"
    status: str = "ready"
    serverTime: str = field(default_factory=lambda: datetime.now().isoformat())
