#!/usr/bin/env python3
"""
MDF4 Socket Server - Unified Object Protocol
Uses object-based communication with Java client.
"""

import socket
import struct
import json
import threading
import logging
import time
import os
import sys
import signal
import atexit
from typing import Dict, Any, Optional, Callable, Tuple, Type
from datetime import datetime
from dataclasses import asdict

from mdf4_handler import Mdf4Handler, get_handler
from protocol import (
    Request, Response,
    CreateFileParams, OpenFileParams, SaveFileParams, AddChannelParams,
    ChannelNameParams, ReadPartialParams, ReadTimeRangeParams,
    FilterChannelsParams, CutTimeRangeParams, WriteMultipleChannelsParams,
    SetChannelMetadataParams, SetFileMetadataParams,
    SuccessResult, FilePathResult, ChannelNamesResult, ChannelInfoResult,
    FileMetadataResult, ChannelMetadataResult, DataRecordResult, DataRecordsResult,
    SampleCountResult, TimeRangeResult, PingResult, HandshakeResult
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants
DEFAULT_HOST = '0.0.0.0'
DEFAULT_PORT = 25333
PID_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdf4_server.pid')
PORT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdf4_server.port')
HANDSHAKE_TIMEOUT = 30
IDLE_TIMEOUT = 180


def to_dict(obj: Any) -> Dict[str, Any]:
    """Convert dataclass or dict to dict"""
    if hasattr(obj, '__dataclass_fields__'):
        return asdict(obj)
    return obj if obj is not None else {}


class MessageProtocol:
    """Message protocol handler for length-prefixed JSON messages"""
    
    MAX_CHUNK_SIZE = 1024 * 1024
    
    @staticmethod
    def encode_message(data: Dict[str, Any]) -> bytes:
        json_bytes = json.dumps(data, ensure_ascii=False, default=str).encode('utf-8')
        length_prefix = struct.pack('>I', len(json_bytes))
        return length_prefix + json_bytes
    
    @staticmethod
    def decode_message(data: bytes) -> Dict[str, Any]:
        return json.loads(data.decode('utf-8'))
    
    @staticmethod
    def read_message(sock: socket.socket) -> Optional[Dict[str, Any]]:
        try:
            length_bytes = sock.recv(4)
            if len(length_bytes) < 4:
                return None
            
            message_length = struct.unpack('>I', length_bytes)[0]
            
            message_bytes = b''
            remaining = message_length
            
            while remaining > 0:
                chunk_size = min(remaining, MessageProtocol.MAX_CHUNK_SIZE)
                chunk = sock.recv(chunk_size)
                if not chunk:
                    return None
                message_bytes += chunk
                remaining -= len(chunk)
            
            return MessageProtocol.decode_message(message_bytes)
        except (socket.timeout, ConnectionResetError, BrokenPipeError):
            return None
        except Exception as e:
            logger.error(f"Error reading message: {e}")
            return None
    
    @staticmethod
    def send_message(sock: socket.socket, data: Dict[str, Any]) -> bool:
        try:
            message_bytes = MessageProtocol.encode_message(data)
            sock.sendall(struct.pack('>I', len(message_bytes)))
            
            for i in range(0, len(message_bytes), MessageProtocol.MAX_CHUNK_SIZE):
                chunk = message_bytes[i:i + MessageProtocol.MAX_CHUNK_SIZE]
                sock.sendall(chunk)
            
            return True
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            return False


class Mdf4SocketHandler:
    """Handler for MDF4 operations via socket - using unified protocol"""
    
    def __init__(self):
        self._handler = get_handler()
        self._commands: Dict[str, Callable] = {
            'PING': self._cmd_ping,
            'HANDSHAKE': self._cmd_handshake,
            'SHUTDOWN': self._cmd_shutdown,
            'createNewFile': self._cmd_create_new_file,
            'openFile': self._cmd_open_file,
            'closeFile': self._cmd_close_file,
            'saveFile': self._cmd_save_file,
            'setFileMetadata': self._cmd_set_file_metadata,
            'getFileMetadata': self._cmd_get_file_metadata,
            'addChannel': self._cmd_add_channel,
            'writeMultipleChannels': self._cmd_write_multiple_channels,
            'setChannelMetadata': self._cmd_set_channel_metadata,
            'getChannelNames': self._cmd_get_channel_names,
            'getChannelInfo': self._cmd_get_channel_info,
            'getChannelMetadata': self._cmd_get_channel_metadata,
            'readChannel': self._cmd_read_channel,
            'readMultipleChannels': self._cmd_read_multiple_channels,
            'readChannelPartial': self._cmd_read_channel_partial,
            'readChannelsPartial': self._cmd_read_channels_partial,
            'getSampleCount': self._cmd_get_sample_count,
            'getTimeRange': self._cmd_get_time_range,
            'filterChannels': self._cmd_filter_channels,
            'cutTimeRange': self._cmd_cut_time_range,
        }
    
    def handle_command(self, cmd: str, params: Dict[str, Any]) -> Response:
        """Handle a command and return Response object"""
        handler = self._commands.get(cmd)
        if handler is None:
            return Response.error_result(f'Unknown command: {cmd}')
        
        try:
            return handler(params)
        except Exception as e:
            logger.error(f"Error executing command {cmd}: {e}")
            return Response.error_result(str(e))
    
    def _cmd_ping(self, params: Dict[str, Any]) -> Response:
        return Response.success_result(PingResult())
    
    def _cmd_handshake(self, params: Dict[str, Any]) -> Response:
        return Response.success_result(HandshakeResult())
    
    def _cmd_shutdown(self, params: Dict[str, Any]) -> Response:
        logger.info("Received shutdown command from client")
        return Response.success_result(SuccessResult())
    
    # ==================== File Operations ====================
    
    def _cmd_create_new_file(self, params: Dict[str, Any]) -> Response:
        p = CreateFileParams(**params)
        
        if p.autoCreateDirs and p.filePath:
            parent_dir = os.path.dirname(p.filePath)
            if parent_dir and not os.path.exists(parent_dir):
                os.makedirs(parent_dir, exist_ok=True)
        
        success = self._handler.create_new_file(p.filePath)
        
        if success and p.metadata:
            self._handler.set_file_metadata(p.metadata)
        
        return Response.success_result(SuccessResult(success))
    
    def _cmd_open_file(self, params: Dict[str, Any]) -> Response:
        p = OpenFileParams(**params)
        
        file_exists = os.path.exists(p.filePath) if p.filePath else False
        
        if not file_exists and p.autoCreate and p.filePath:
            parent_dir = os.path.dirname(p.filePath)
            if parent_dir and not os.path.exists(parent_dir):
                os.makedirs(parent_dir, exist_ok=True)
            
            success = self._handler.create_new_file(p.filePath)
            if success and p.metadata:
                self._handler.set_file_metadata(p.metadata)
            return Response.success_result(FilePathResult(success=success, filePath=p.filePath, created=True))
        
        success = self._handler.open_file(p.filePath, p.readOnly)
        return Response.success_result(FilePathResult(success=success, filePath=p.filePath, created=False))
    
    def _cmd_close_file(self, params: Dict[str, Any]) -> Response:
        success = self._handler.close_file()
        return Response.success_result(SuccessResult(success))
    
    def _cmd_save_file(self, params: Dict[str, Any]) -> Response:
        p = SaveFileParams(**params) if params else SaveFileParams()
        success = self._handler.save_file(p.filePath, p.compression)
        return Response.success_result(SuccessResult(success))
    
    def _cmd_set_file_metadata(self, params: Dict[str, Any]) -> Response:
        p = SetFileMetadataParams(**params)
        success = self._handler.set_file_metadata(p.metadata)
        return Response.success_result(SuccessResult(success))
    
    def _cmd_get_file_metadata(self, params: Dict[str, Any]) -> Response:
        metadata = self._handler.get_file_metadata()
        return Response.success_result(FileMetadataResult(metadata=metadata))
    
    # ==================== Write Operations ====================
    
    def _cmd_add_channel(self, params: Dict[str, Any]) -> Response:
        p = AddChannelParams(**params)
        success = self._handler.add_channel(
            p.channelName, p.timestamps, p.values,
            p.unit, p.comment, p.dataType, p.metadata
        )
        return Response.success_result(SuccessResult(success))
    
    def _cmd_write_multiple_channels(self, params: Dict[str, Any]) -> Response:
        p = WriteMultipleChannelsParams(**params)
        success = self._handler.write_multiple_channels(p.channels)
        return Response.success_result(SuccessResult(success))
    
    def _cmd_set_channel_metadata(self, params: Dict[str, Any]) -> Response:
        p = SetChannelMetadataParams(**params)
        success = self._handler.set_channel_metadata(p.channelName, p.metadata)
        return Response.success_result(SuccessResult(success))
    
    # ==================== Read Operations ====================
    
    def _cmd_get_channel_names(self, params: Dict[str, Any]) -> Response:
        names = self._handler.get_channel_names()
        return Response.success_result(ChannelNamesResult(names=list(names)))
    
    def _cmd_get_channel_info(self, params: Dict[str, Any]) -> Response:
        p = ChannelNameParams(**params)
        info = self._handler.get_channel_info(p.channelName)
        return Response.success_result(ChannelInfoResult(info=info))
    
    def _cmd_get_channel_metadata(self, params: Dict[str, Any]) -> Response:
        p = ChannelNameParams(**params)
        metadata = self._handler.get_channel_metadata(p.channelName)
        return Response.success_result(ChannelMetadataResult(metadata=metadata))
    
    def _cmd_read_channel(self, params: Dict[str, Any]) -> Response:
        p = ChannelNameParams(**params)
        record = self._handler.read_channel(p.channelName)
        
        if record is None:
            return Response.error_result('Channel not found')
        
        return Response.success_result(DataRecordResult(record={
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }))
    
    def _cmd_read_multiple_channels(self, params: Dict[str, Any]) -> Response:
        p = FilterChannelsParams(**params)
        records = self._handler.read_multiple_channels(p.channelNames)
        
        return Response.success_result(DataRecordsResult(records=[{
            'channelName': r.channel_name,
            'timestamps': r.timestamps,
            'values': r.values,
            'unit': r.unit
        } for r in records]))
    
    def _cmd_read_channel_partial(self, params: Dict[str, Any]) -> Response:
        p = ReadPartialParams(**params)
        record = self._handler.read_channel_partial(p.channelName, p.startIndex, p.count)
        
        if record is None:
            return Response.error_result('Channel not found')
        
        return Response.success_result(DataRecordResult(record={
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }))
    
    def _cmd_read_channels_partial(self, params: Dict[str, Any]) -> Response:
        p = ReadTimeRangeParams(**params)
        records = self._handler.read_channels_partial(p.channelNames, p.startTime, p.endTime)
        
        return Response.success_result(DataRecordsResult(records=[{
            'channelName': r.channel_name,
            'timestamps': r.timestamps,
            'values': r.values,
            'unit': r.unit
        } for r in records]))
    
    def _cmd_get_sample_count(self, params: Dict[str, Any]) -> Response:
        p = ChannelNameParams(**params)
        count = self._handler.get_sample_count(p.channelName)
        return Response.success_result(SampleCountResult(count=count))
    
    def _cmd_get_time_range(self, params: Dict[str, Any]) -> Response:
        range_tuple = self._handler.get_time_range()
        return Response.success_result(TimeRangeResult(range=list(range_tuple)))
    
    # ==================== Utility Operations ====================
    
    def _cmd_filter_channels(self, params: Dict[str, Any]) -> Response:
        p = FilterChannelsParams(**params)
        success = self._handler.filter_channels(p.channelNames)
        return Response.success_result(SuccessResult(success))
    
    def _cmd_cut_time_range(self, params: Dict[str, Any]) -> Response:
        p = CutTimeRangeParams(**params)
        success = self._handler.cut_time_range(p.startTime, p.endTime)
        return Response.success_result(SuccessResult(success))


class ClientHandler(threading.Thread):
    """Handler for individual client connections"""
    
    def __init__(self, client_socket: socket.socket, address: tuple, server: 'Mdf4SocketServer'):
        super().__init__(daemon=True)
        self._socket = client_socket
        self._address = address
        self._server = server
        self._mdf_handler = Mdf4SocketHandler()
        self._connected = False
        self._handshake_received = False
    
    def run(self):
        logger.info(f"Client connected from {self._address}")
        self._server.update_last_activity()
        
        try:
            self._socket.settimeout(HANDSHAKE_TIMEOUT)
            
            if not self._wait_for_handshake():
                logger.warning(f"Handshake timeout for {self._address}, closing connection")
                return
            
            self._socket.settimeout(60)
            self._connected = True
            
            while self._connected and self._server.is_running():
                message = MessageProtocol.read_message(self._socket)
                
                if message is None:
                    logger.info(f"Client {self._address} disconnected")
                    break
                
                self._server.update_last_activity()
                
                if message.get('cmd') == 'SHUTDOWN':
                    logger.info("Shutdown command received, stopping server...")
                    self._handle_message(message)
                    self._server.stop()
                    break
                
                self._handle_message(message)
                
        except socket.timeout:
            if not self._handshake_received:
                logger.warning(f"Handshake timeout for {self._address}")
        except Exception as e:
            logger.error(f"Error handling client {self._address}: {e}")
        finally:
            self._cleanup()
    
    def _wait_for_handshake(self) -> bool:
        try:
            message = MessageProtocol.read_message(self._socket)
            
            if message is None:
                return False
            
            cmd = message.get('cmd')
            req_id = message.get('reqId', '0')
            
            if cmd == 'HANDSHAKE':
                self._handshake_received = True
                response = Response.success_result(HandshakeResult(), req_id)
                MessageProtocol.send_message(self._socket, to_dict(response))
                logger.info(f"Handshake successful with {self._address}")
                return True
            else:
                response = Response.error_result('Expected HANDSHAKE command', req_id)
                MessageProtocol.send_message(self._socket, to_dict(response))
                return False
                
        except socket.timeout:
            logger.warning(f"Handshake timeout after {HANDSHAKE_TIMEOUT} seconds")
            return False
    
    def _handle_message(self, message: Dict[str, Any]):
        cmd = message.get('cmd', '')
        params = message.get('params', {})
        req_id = message.get('reqId', '0')
        
        logger.debug(f"Received command: {cmd} from {self._address}")
        
        result = self._mdf_handler.handle_command(cmd, params)
        result.reqId = req_id
        
        if not MessageProtocol.send_message(self._socket, to_dict(result)):
            logger.error(f"Failed to send response to {self._address}")
            self._connected = False
    
    def _cleanup(self):
        try:
            self._socket.close()
        except:
            pass
        self._server.remove_client(self)
        logger.info(f"Client handler for {self._address} cleaned up")


class Mdf4SocketServer:
    """MDF4 Socket Server - Main server class"""
    
    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self._host = host
        self._port = port
        self._server_socket: Optional[socket.socket] = None
        self._running = False
        self._clients: list = []
        self._lock = threading.Lock()
        self._start_time: Optional[datetime] = None
        self._last_activity_time = time.time()
        self._idle_check_thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()
    
    def start(self):
        try:
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind((self._host, self._port))
            self._server_socket.listen(5)
            
            self._running = True
            self._start_time = datetime.now()
            self._last_activity_time = time.time()
            
            self._write_pid_file()
            self._write_port_file()
            
            self._idle_check_thread = threading.Thread(target=self._idle_check_loop, daemon=True)
            self._idle_check_thread.start()
            
            logger.info(f"MDF4 Socket Server started on {self._host}:{self._port}")
            logger.info(f"Handshake timeout: {HANDSHAKE_TIMEOUT} seconds")
            logger.info(f"Idle timeout: {IDLE_TIMEOUT} seconds")
            logger.info(f"PID: {os.getpid()}")
            logger.info("Waiting for connections...")
            
            while self._running:
                try:
                    self._server_socket.settimeout(1.0)
                    client_socket, address = self._server_socket.accept()
                    
                    handler = ClientHandler(client_socket, address, self)
                    with self._lock:
                        self._clients.append(handler)
                    handler.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self._running:
                        logger.error(f"Error accepting connection: {e}")
                    
        except Exception as e:
            logger.error(f"Server error: {e}")
        finally:
            self.stop()
    
    def stop(self):
        if not self._running:
            return
        
        logger.info("Stopping server...")
        self._running = False
        self._shutdown_event.set()
        
        with self._lock:
            for client in self._clients:
                try:
                    client._connected = False
                    client._socket.close()
                except:
                    pass
            self._clients.clear()
        
        if self._server_socket:
            try:
                self._server_socket.close()
            except:
                pass
        
        self._remove_pid_file()
        self._remove_port_file()
        
        logger.info("Server stopped")
    
    def _idle_check_loop(self):
        while not self._shutdown_event.is_set():
            try:
                self._shutdown_event.wait(10)
                
                if not self._running:
                    break
                
                idle_time = time.time() - self._last_activity_time
                if idle_time > IDLE_TIMEOUT:
                    logger.info(f"Server idle for {idle_time:.0f} seconds, shutting down...")
                    self.stop()
                    break
                    
            except Exception as e:
                logger.error(f"Error in idle check loop: {e}")
    
    def update_last_activity(self):
        self._last_activity_time = time.time()
    
    def is_running(self) -> bool:
        return self._running
    
    def get_port(self) -> int:
        return self._port
    
    def remove_client(self, client: ClientHandler):
        with self._lock:
            if client in self._clients:
                self._clients.remove(client)
    
    def _write_pid_file(self):
        try:
            with open(PID_FILE, 'w') as f:
                f.write(str(os.getpid()))
            logger.info(f"PID file written: {PID_FILE}")
        except Exception as e:
            logger.warning(f"Failed to write PID file: {e}")
    
    def _remove_pid_file(self):
        try:
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)
                logger.info(f"PID file removed: {PID_FILE}")
        except Exception as e:
            logger.warning(f"Failed to remove PID file: {e}")
    
    def _write_port_file(self):
        try:
            with open(PORT_FILE, 'w') as f:
                f.write(str(self._port))
            logger.info(f"Port file written: {PORT_FILE} (port={self._port})")
        except Exception as e:
            logger.warning(f"Failed to write port file: {e}")
    
    def _remove_port_file(self):
        try:
            if os.path.exists(PORT_FILE):
                os.remove(PORT_FILE)
                logger.info(f"Port file removed: {PORT_FILE}")
        except Exception as e:
            logger.warning(f"Failed to remove port file: {e}")


# ==================== Service Management Functions ====================

def get_server_pid() -> Optional[int]:
    try:
        if os.path.exists(PID_FILE):
            with open(PID_FILE, 'r') as f:
                return int(f.read().strip())
    except Exception as e:
        logger.warning(f"Failed to read PID file: {e}")
    return None


def get_server_port() -> int:
    try:
        if os.path.exists(PORT_FILE):
            with open(PORT_FILE, 'r') as f:
                return int(f.read().strip())
    except Exception as e:
        logger.warning(f"Failed to read port file: {e}")
    return DEFAULT_PORT


def is_server_running(host: str = DEFAULT_HOST, port: int = None) -> bool:
    if port is None:
        port = get_server_port()
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((host, port))
        
        ping_msg = MessageProtocol.encode_message({'cmd': 'PING', 'params': {}, 'reqId': '0'})
        sock.sendall(ping_msg)
        
        length_bytes = sock.recv(4)
        if len(length_bytes) == 4:
            msg_len = struct.unpack('>I', length_bytes)[0]
            response_bytes = sock.recv(msg_len)
            response = json.loads(response_bytes.decode('utf-8'))
            sock.close()
            return response.get('success', False)
        
        sock.close()
        return True
    except Exception:
        return False


def stop_server(host: str = DEFAULT_HOST, port: int = None):
    if port is None:
        port = get_server_port()
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        sock.connect((host, port))
        
        shutdown_msg = MessageProtocol.encode_message({
            'cmd': 'SHUTDOWN',
            'params': {},
            'reqId': '999'
        })
        sock.sendall(shutdown_msg)
        sock.close()
        
        time.sleep(1)
        
        if not is_server_running(host=host, port=port):
            print("Server stopped gracefully")
            return True
    except Exception as e:
        logger.debug(f"Graceful shutdown failed: {e}")
    
    pid = get_server_pid()
    if pid is not None:
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"Sent termination signal to server (PID: {pid})")
            
            for i in range(10):
                time.sleep(0.5)
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    print("Server stopped successfully")
                    return True
            
            try:
                os.kill(pid, signal.SIGKILL)
                print("Force killed server")
            except ProcessLookupError:
                pass
            
            return True
        except ProcessLookupError:
            print("Server is not running")
            return True
        except Exception as e:
            print(f"Error stopping server: {e}")
            return False
    
    print("No server to stop")
    return True


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='MDF4 Socket Server')
    parser.add_argument('action', choices=['start', 'stop', 'status', 'foreground'],
                       default='foreground', nargs='?')
    parser.add_argument('--host', default=DEFAULT_HOST)
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    
    args = parser.parse_args()
    
    if args.action == 'start':
        if is_server_running(port=args.port):
            actual_port = get_server_port()
            print(f"Server is already running on port {actual_port}")
            sys.exit(0)
        
        if sys.platform != 'win32':
            try:
                pid = os.fork()
                if pid > 0:
                    time.sleep(2)
                    if is_server_running(port=args.port):
                        print(f"Server started successfully on port {args.port}")
                        sys.exit(0)
                    else:
                        print("Failed to start server")
                        sys.exit(1)
                
                os.setsid()
                os.umask(0)
                
                log_file = os.path.join(os.path.dirname(PID_FILE), 'mdf4_server.log')
                sys.stdout = open(log_file, 'a')
                sys.stderr = sys.stdout
                
                server = Mdf4SocketServer(args.host, args.port)
                server.start()
            except OSError as e:
                print(f"Fork failed: {e}")
                sys.exit(1)
        else:
            print("Background mode not supported on Windows, use 'foreground'")
            sys.exit(1)
            
    elif args.action == 'stop':
        if stop_server(host=args.host, port=args.port):
            sys.exit(0)
        else:
            sys.exit(1)
            
    elif args.action == 'status':
        port = get_server_port()
        if is_server_running(port=port):
            pid = get_server_pid()
            print(f"Server is running on port {port} (PID: {pid})")
            sys.exit(0)
        else:
            print("Server is not running")
            sys.exit(1)
            
    elif args.action == 'foreground':
        port = args.port
        if is_server_running(port=port):
            print(f"Server is already running on port {port}")
            print("Stop it first or use 'status' to check")
            sys.exit(1)
        
        server = Mdf4SocketServer(args.host, port)
        
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}")
            server.stop()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        try:
            server.start()
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt")
        finally:
            server.stop()


if __name__ == "__main__":
    main()
