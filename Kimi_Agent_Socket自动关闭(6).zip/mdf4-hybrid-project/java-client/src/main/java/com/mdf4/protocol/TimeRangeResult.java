package com.mdf4.protocol;

import java.util.List;

/**
 * 时间范围响应
 */
public class TimeRangeResult {
    
    private List<Double> range;
    
    public TimeRangeResult() {}
    
    public TimeRangeResult(List<Double> range) {
        this.range = range;
    }
    
    public List<Double> getRange() { return range; }
    public void setRange(List<Double> range) { this.range = range; }
}
