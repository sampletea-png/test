package com.mdf4.protocol;

/**
 * 样本数量响应
 */
public class SampleCountResult {
    
    private int count;
    
    public SampleCountResult() {}
    
    public SampleCountResult(int count) {
        this.count = count;
    }
    
    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }
}
