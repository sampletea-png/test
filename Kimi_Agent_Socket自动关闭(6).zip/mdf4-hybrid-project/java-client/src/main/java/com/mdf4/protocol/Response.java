package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 统一响应对象 - 所有响应都使用此结构
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> {
    
    private boolean success;
    private T data;
    private String error;
    private String reqId;
    
    public Response() {}
    
    public Response(boolean success, T data, String error, String reqId) {
        this.success = success;
        this.data = data;
        this.error = error;
        this.reqId = reqId;
    }
    
    // 成功响应工厂方法
    public static <T> Response<T> success(T data, String reqId) {
        return new Response<>(true, data, null, reqId);
    }
    
    // 失败响应工厂方法
    public static <T> Response<T> error(String error, String reqId) {
        return new Response<>(false, null, error, reqId);
    }
    
    // Getters and Setters
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
    
    public T getData() { return data; }
    public void setData(T data) { this.data = data; }
    
    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
    
    public String getReqId() { return reqId; }
    public void setReqId(String reqId) { this.reqId = reqId; }
}
