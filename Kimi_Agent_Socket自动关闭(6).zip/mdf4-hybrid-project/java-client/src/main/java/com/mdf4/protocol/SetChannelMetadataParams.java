package com.mdf4.protocol;

import com.mdf4.ChannelMetadata;

/**
 * 设置通道元数据参数
 */
public class SetChannelMetadataParams {
    
    private String channelName;
    private ChannelMetadata metadata;
    
    public SetChannelMetadataParams() {}
    
    public SetChannelMetadataParams(String channelName, ChannelMetadata metadata) {
        this.channelName = channelName;
        this.metadata = metadata;
    }
    
    // Getters and Setters
    public String getChannelName() { return channelName; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
    
    public ChannelMetadata getMetadata() { return metadata; }
    public void setMetadata(ChannelMetadata metadata) { this.metadata = metadata; }
}
