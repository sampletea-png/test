package com.mdf4.protocol;

import com.mdf4.ChannelData;
import java.util.List;

/**
 * 批量写入通道参数
 */
public class WriteMultipleChannelsParams {
    
    private List<ChannelData> channels;
    
    public WriteMultipleChannelsParams() {}
    
    public WriteMultipleChannelsParams(List<ChannelData> channels) {
        this.channels = channels;
    }
    
    public List<ChannelData> getChannels() { return channels; }
    public void setChannels(List<ChannelData> channels) { this.channels = channels; }
}
