package com.mdf4.protocol;

import java.util.List;

/**
 * 通道名称列表响应
 */
public class ChannelNamesResult {
    
    private List<String> names;
    
    public ChannelNamesResult() {}
    
    public ChannelNamesResult(List<String> names) {
        this.names = names;
    }
    
    public List<String> getNames() { return names; }
    public void setNames(List<String> names) { this.names = names; }
}
