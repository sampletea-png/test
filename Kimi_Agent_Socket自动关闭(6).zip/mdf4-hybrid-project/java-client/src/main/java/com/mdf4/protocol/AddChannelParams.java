package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.mdf4.ChannelMetadata;
import java.util.List;

/**
 * 添加通道请求参数
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddChannelParams {
    
    private String channelName;
    private List<Double> timestamps;
    private List<Double> values;
    private String unit = "";
    private String comment = "";
    private String dataType = "float";
    private ChannelMetadata metadata;
    
    public AddChannelParams() {}
    
    // Getters and Setters
    public String getChannelName() { return channelName; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
    
    public List<Double> getTimestamps() { return timestamps; }
    public void setTimestamps(List<Double> timestamps) { this.timestamps = timestamps; }
    
    public List<Double> getValues() { return values; }
    public void setValues(List<Double> values) { this.values = values; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public String getDataType() { return dataType; }
    public void setDataType(String dataType) { this.dataType = dataType; }
    
    public ChannelMetadata getMetadata() { return metadata; }
    public void setMetadata(ChannelMetadata metadata) { this.metadata = metadata; }
}
