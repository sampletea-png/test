package com.mdf4;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FileMetadata - Represents metadata for an MDF4 file.
 * Stored as JSON string in MDF4 header comment.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileMetadata {
    
    private String title;
    private String author;
    private String description;
    private String project;
    private String version;
    
    @JsonProperty("createdAt")
    private String createdAt;
    
    @JsonProperty("modifiedAt")
    private String modifiedAt;
    
    @JsonProperty("customProperties")
    private Map<String, String> customProperties;
    
    public FileMetadata() {
        this.title = "";
        this.author = "";
        this.description = "";
        this.project = "";
        this.version = "1.0";
        this.createdAt = "";
        this.modifiedAt = "";
        this.customProperties = new HashMap<>();
    }
    
    public FileMetadata(String title, String author, String description) {
        this();
        this.title = title;
        this.author = author;
        this.description = description;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getProject() { return project; }
    public void setProject(String project) { this.project = project; }
    
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getModifiedAt() { return modifiedAt; }
    public void setModifiedAt(String modifiedAt) { this.modifiedAt = modifiedAt; }
    
    public Map<String, String> getCustomProperties() { return customProperties; }
    public void setCustomProperties(Map<String, String> customProperties) { 
        this.customProperties = customProperties != null ? customProperties : new HashMap<>(); 
    }
    
    public void addCustomProperty(String key, String value) {
        if (this.customProperties == null) {
            this.customProperties = new HashMap<>();
        }
        this.customProperties.put(key, value);
    }
    
    public String getCustomProperty(String key) {
        return this.customProperties != null ? this.customProperties.get(key) : null;
    }
    
    // ==================== Builder Pattern ====================
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private FileMetadata metadata = new FileMetadata();
        
        public Builder title(String title) {
            metadata.setTitle(title);
            return this;
        }
        
        public Builder author(String author) {
            metadata.setAuthor(author);
            return this;
        }
        
        public Builder description(String description) {
            metadata.setDescription(description);
            return this;
        }
        
        public Builder project(String project) {
            metadata.setProject(project);
            return this;
        }
        
        public Builder version(String version) {
            metadata.setVersion(version);
            return this;
        }
        
        public Builder customProperty(String key, String value) {
            metadata.addCustomProperty(key, value);
            return this;
        }
        
        public FileMetadata build() {
            return metadata;
        }
    }
    
    @Override
    public String toString() {
        return String.format("FileMetadata{title='%s', author='%s', project='%s', version='%s'}",
                title, author, project, version);
    }
}
