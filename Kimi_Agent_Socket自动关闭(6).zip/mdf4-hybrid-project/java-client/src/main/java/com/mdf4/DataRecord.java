package com.mdf4;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DataRecord - Represents a channel's data in an MDF4 file.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataRecord {
    
    @JsonProperty("channelName")
    private String channelName;
    
    private List<Double> timestamps;
    private List<Double> values;
    private String unit;
    
    public DataRecord() {
    }
    
    public DataRecord(String channelName, List<Double> timestamps, 
                      List<Double> values, String unit) {
        this.channelName = channelName;
        this.timestamps = timestamps;
        this.values = values;
        this.unit = unit;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getChannelName() { return channelName; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
    
    public List<Double> getTimestamps() { return timestamps; }
    public void setTimestamps(List<Double> timestamps) { this.timestamps = timestamps; }
    
    public List<Double> getValues() { return values; }
    public void setValues(List<Double> values) { this.values = values; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    // ==================== Utility Methods ====================
    
    public int getSampleCount() {
        return values != null ? values.size() : 0;
    }
    
    public double getStartTime() {
        return timestamps != null && !timestamps.isEmpty() ? timestamps.get(0) : 0.0;
    }
    
    public double getEndTime() {
        return timestamps != null && !timestamps.isEmpty() ? 
               timestamps.get(timestamps.size() - 1) : 0.0;
    }
    
    public double getDuration() {
        return getEndTime() - getStartTime();
    }
    
    @Override
    public String toString() {
        return String.format("DataRecord{channel='%s', samples=%d, unit='%s', timeRange=[%.3f, %.3f]}",
                channelName, getSampleCount(), unit, getStartTime(), getEndTime());
    }
}
