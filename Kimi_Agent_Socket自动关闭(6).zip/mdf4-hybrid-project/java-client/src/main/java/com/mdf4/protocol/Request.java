package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 统一请求对象 - 所有请求都使用此结构
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Request<T> {
    
    private String cmd;
    private T params;
    private String reqId;
    
    public Request() {}
    
    public Request(String cmd, T params, String reqId) {
        this.cmd = cmd;
        this.params = params;
        this.reqId = reqId;
    }
    
    // Getters and Setters
    public String getCmd() { return cmd; }
    public void setCmd(String cmd) { this.cmd = cmd; }
    
    public T getParams() { return params; }
    public void setParams(T params) { this.params = params; }
    
    public String getReqId() { return reqId; }
    public void setReqId(String reqId) { this.reqId = reqId; }
}
