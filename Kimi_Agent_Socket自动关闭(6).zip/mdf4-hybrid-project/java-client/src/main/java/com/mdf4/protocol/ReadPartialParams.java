package com.mdf4.protocol;

/**
 * 部分读取参数（按索引）
 */
public class ReadPartialParams {
    
    private String channelName;
    private int startIndex;
    private int count;
    
    public ReadPartialParams() {}
    
    public ReadPartialParams(String channelName, int startIndex, int count) {
        this.channelName = channelName;
        this.startIndex = startIndex;
        this.count = count;
    }
    
    // Getters and Setters
    public String getChannelName() { return channelName; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
    
    public int getStartIndex() { return startIndex; }
    public void setStartIndex(int startIndex) { this.startIndex = startIndex; }
    
    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }
}
