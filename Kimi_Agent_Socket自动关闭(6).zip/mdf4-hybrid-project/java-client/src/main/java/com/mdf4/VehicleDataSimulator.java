package com.mdf4;

import java.util.ArrayList;
import java.util.List;

/**
 * VehicleDataSimulator - Generates simulated vehicle data for testing.
 * Creates realistic automotive sensor data patterns.
 */
public class VehicleDataSimulator {
    
    private double sampleRate;  // Samples per second
    private double duration;    // Duration in seconds
    
    /**
     * Constructor
     * 
     * @param sampleRate Samples per second (Hz)
     * @param duration Duration in seconds
     */
    public VehicleDataSimulator(double sampleRate, double duration) {
        this.sampleRate = sampleRate;
        this.duration = duration;
    }
    
    /**
     * Generate timestamps
     */
    public List<Double> generateTimestamps() {
        List<Double> timestamps = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            timestamps.add(i * dt);
        }
        
        return timestamps;
    }
    
    /**
     * Generate engine speed data (RPM)
     * Simulates engine acceleration and steady-state operation
     */
    public List<Double> generateEngineSpeed() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            double t = i * dt;
            double rpm;
            
            if (t < 5.0) {
                // Startup and idle
                rpm = 800 + 100 * Math.sin(2 * Math.PI * 0.5 * t);
            } else if (t < 15.0) {
                // Acceleration
                double progress = (t - 5.0) / 10.0;
                rpm = 800 + (3000 - 800) * progress + 200 * Math.sin(2 * Math.PI * 2 * t);
            } else if (t < 25.0) {
                // Steady cruise
                rpm = 2500 + 150 * Math.sin(2 * Math.PI * 0.3 * t);
            } else if (t < 30.0) {
                // Deceleration
                double progress = (t - 25.0) / 5.0;
                rpm = 2500 - (2500 - 800) * progress;
            } else {
                // Back to idle
                rpm = 800 + 50 * Math.sin(2 * Math.PI * 0.5 * t);
            }
            
            // Add some noise
            rpm += 20 * (Math.random() - 0.5);
            values.add(rpm);
        }
        
        return values;
    }
    
    /**
     * Generate vehicle speed data (km/h)
     */
    public List<Double> generateVehicleSpeed() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            double t = i * dt;
            double speed;
            
            if (t < 5.0) {
                // Stationary
                speed = 0;
            } else if (t < 15.0) {
                // Acceleration
                double progress = (t - 5.0) / 10.0;
                speed = 100 * progress;  // 0 to 100 km/h
            } else if (t < 25.0) {
                // Steady cruise
                speed = 100 + 2 * Math.sin(2 * Math.PI * 0.2 * t);
            } else if (t < 30.0) {
                // Deceleration
                double progress = (t - 25.0) / 5.0;
                speed = 100 * (1 - progress);
            } else {
                // Stationary
                speed = 0;
            }
            
            // Add some noise
            speed += 0.5 * (Math.random() - 0.5);
            values.add(Math.max(0, speed));
        }
        
        return values;
    }
    
    /**
     * Generate throttle position (%)
     */
    public List<Double> generateThrottlePosition() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            double t = i * dt;
            double throttle;
            
            if (t < 5.0) {
                // Idle
                throttle = 5;
            } else if (t < 15.0) {
                // Acceleration
                throttle = 60 + 10 * Math.sin(2 * Math.PI * 0.5 * t);
            } else if (t < 25.0) {
                // Cruise
                throttle = 25 + 5 * Math.sin(2 * Math.PI * 0.3 * t);
            } else if (t < 30.0) {
                // Deceleration
                throttle = 0;
            } else {
                // Idle
                throttle = 5;
            }
            
            values.add(Math.max(0, Math.min(100, throttle)));
        }
        
        return values;
    }
    
    /**
     * Generate brake pressure (bar)
     */
    public List<Double> generateBrakePressure() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            double t = i * dt;
            double pressure;
            
            if (t >= 25.0 && t < 30.0) {
                // Braking
                double progress = (t - 25.0) / 5.0;
                pressure = 20 * Math.sin(Math.PI * progress);
            } else {
                // No braking
                pressure = 0;
            }
            
            values.add(pressure);
        }
        
        return values;
    }
    
    /**
     * Generate coolant temperature (°C)
     */
    public List<Double> generateCoolantTemperature() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        double dt = 1.0 / sampleRate;
        
        for (int i = 0; i < numSamples; i++) {
            double t = i * dt;
            double temp;
            
            if (t < 10.0) {
                // Warming up
                double progress = t / 10.0;
                temp = 20 + (90 - 20) * progress;
            } else {
                // Operating temperature
                temp = 90 + 3 * Math.sin(2 * Math.PI * 0.1 * t);
            }
            
            values.add(temp);
        }
        
        return values;
    }
    
    /**
     * Generate battery voltage (V)
     */
    public List<Double> generateBatteryVoltage() {
        List<Double> values = new ArrayList<>();
        int numSamples = (int) (sampleRate * duration);
        
        for (int i = 0; i < numSamples; i++) {
            double voltage = 12.6 + 0.3 * Math.sin(2 * Math.PI * 0.05 * i / sampleRate);
            voltage += 0.1 * (Math.random() - 0.5);
            values.add(voltage);
        }
        
        return values;
    }
    
    /**
     * Generate all vehicle data as ChannelData objects
     */
    public List<ChannelData> generateAllChannels() {
        List<ChannelData> channels = new ArrayList<>();
        List<Double> timestamps = generateTimestamps();
        
        // Engine Speed
        channels.add(ChannelData.builder()
                .name("EngineSpeed")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateEngineSpeed())
                .unit("RPM")
                .comment("Engine speed in revolutions per minute")
                .dataType("float")
                .build());
        
        // Vehicle Speed
        channels.add(ChannelData.builder()
                .name("VehicleSpeed")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateVehicleSpeed())
                .unit("km/h")
                .comment("Vehicle speed")
                .dataType("float")
                .build());
        
        // Throttle Position
        channels.add(ChannelData.builder()
                .name("ThrottlePosition")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateThrottlePosition())
                .unit("%")
                .comment("Throttle pedal position")
                .dataType("float")
                .build());
        
        // Brake Pressure
        channels.add(ChannelData.builder()
                .name("BrakePressure")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateBrakePressure())
                .unit("bar")
                .comment("Brake system pressure")
                .dataType("float")
                .build());
        
        // Coolant Temperature
        channels.add(ChannelData.builder()
                .name("CoolantTemperature")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateCoolantTemperature())
                .unit("°C")
                .comment("Engine coolant temperature")
                .dataType("float")
                .build());
        
        // Battery Voltage
        channels.add(ChannelData.builder()
                .name("BatteryVoltage")
                .timestamps(new ArrayList<>(timestamps))
                .values(generateBatteryVoltage())
                .unit("V")
                .comment("Battery voltage")
                .dataType("float")
                .build());
        
        return channels;
    }
    
    /**
     * Get sample rate
     */
    public double getSampleRate() {
        return sampleRate;
    }
    
    /**
     * Get duration
     */
    public double getDuration() {
        return duration;
    }
    
    /**
     * Get total number of samples
     */
    public int getSampleCount() {
        return (int) (sampleRate * duration);
    }
}
