package com.mdf4.protocol;

import com.mdf4.DataRecord;

/**
 * 数据记录响应
 */
public class DataRecordResult {
    
    private DataRecord record;
    
    public DataRecordResult() {}
    
    public DataRecordResult(DataRecord record) {
        this.record = record;
    }
    
    public DataRecord getRecord() { return record; }
    public void setRecord(DataRecord record) { this.record = record; }
}
