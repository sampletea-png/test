package com.mdf4.protocol;

/**
 * 裁剪时间范围参数
 */
public class CutTimeRangeParams {
    
    private double startTime;
    private double endTime;
    
    public CutTimeRangeParams() {}
    
    public CutTimeRangeParams(double startTime, double endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
    }
    
    // Getters and Setters
    public double getStartTime() { return startTime; }
    public void setStartTime(double startTime) { this.startTime = startTime; }
    
    public double getEndTime() { return endTime; }
    public void setEndTime(double endTime) { this.endTime = endTime; }
}
