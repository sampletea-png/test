package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.mdf4.FileMetadata;

/**
 * 打开文件请求参数
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OpenFileParams {
    
    private String filePath;
    private boolean readOnly = true;
    private boolean autoCreate = false;
    private FileMetadata metadata;
    
    public OpenFileParams() {}
    
    public OpenFileParams(String filePath) {
        this.filePath = filePath;
    }
    
    // Getters and Setters
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    
    public boolean isReadOnly() { return readOnly; }
    public void setReadOnly(boolean readOnly) { this.readOnly = readOnly; }
    
    public boolean isAutoCreate() { return autoCreate; }
    public void setAutoCreate(boolean autoCreate) { this.autoCreate = autoCreate; }
    
    public FileMetadata getMetadata() { return metadata; }
    public void setMetadata(FileMetadata metadata) { this.metadata = metadata; }
}
