package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 文件操作响应
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FilePathResult {
    
    private boolean success;
    private String filePath;
    private Boolean created;
    
    public FilePathResult() {}
    
    // Getters and Setters
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
    
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    
    public Boolean getCreated() { return created; }
    public void setCreated(Boolean created) { this.created = created; }
}
