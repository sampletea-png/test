package com.mdf4;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * ChannelData - Represents data to be written to an MDF4 file.
 * Used for batch writing operations.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChannelData {
    
    private String name;
    private List<Double> timestamps;
    private List<Double> values;
    private String unit;
    private String comment;
    private String dataType;
    
    public ChannelData() {
        this.dataType = "float";
    }
    
    public ChannelData(String name, List<Double> timestamps, List<Double> values) {
        this.name = name;
        this.timestamps = timestamps;
        this.values = values;
        this.unit = "";
        this.comment = "";
        this.dataType = "float";
    }
    
    public ChannelData(String name, List<Double> timestamps, List<Double> values,
                       String unit, String comment, String dataType) {
        this.name = name;
        this.timestamps = timestamps;
        this.values = values;
        this.unit = unit;
        this.comment = comment;
        this.dataType = dataType;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public List<Double> getTimestamps() { return timestamps; }
    public void setTimestamps(List<Double> timestamps) { this.timestamps = timestamps; }
    
    public List<Double> getValues() { return values; }
    public void setValues(List<Double> values) { this.values = values; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public String getDataType() { return dataType; }
    public void setDataType(String dataType) { this.dataType = dataType; }
    
    // ==================== Builder Pattern ====================
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private ChannelData data = new ChannelData();
        
        public Builder name(String name) {
            data.setName(name);
            return this;
        }
        
        public Builder timestamps(List<Double> timestamps) {
            data.setTimestamps(timestamps);
            return this;
        }
        
        public Builder values(List<Double> values) {
            data.setValues(values);
            return this;
        }
        
        public Builder unit(String unit) {
            data.setUnit(unit);
            return this;
        }
        
        public Builder comment(String comment) {
            data.setComment(comment);
            return this;
        }
        
        public Builder dataType(String dataType) {
            data.setDataType(dataType);
            return this;
        }
        
        public ChannelData build() {
            return data;
        }
    }
    
    @Override
    public String toString() {
        int sampleCount = values != null ? values.size() : 0;
        return String.format("ChannelData{name='%s', samples=%d, unit='%s', dataType='%s'}",
                name, sampleCount, unit, dataType);
    }
}
