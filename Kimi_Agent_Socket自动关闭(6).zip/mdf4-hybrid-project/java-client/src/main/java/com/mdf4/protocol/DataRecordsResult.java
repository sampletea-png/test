package com.mdf4.protocol;

import com.mdf4.DataRecord;
import java.util.List;

/**
 * 多条数据记录响应
 */
public class DataRecordsResult {
    
    private List<DataRecord> records;
    
    public DataRecordsResult() {}
    
    public DataRecordsResult(List<DataRecord> records) {
        this.records = records;
    }
    
    public List<DataRecord> getRecords() { return records; }
    public void setRecords(List<DataRecord> records) { this.records = records; }
}
