package com.mdf4.protocol;

/**
 * 通用成功响应数据（只返回success字段）
 */
public class SuccessResult {
    
    private boolean success;
    
    public SuccessResult() {}
    
    public SuccessResult(boolean success) {
        this.success = success;
    }
    
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
}
