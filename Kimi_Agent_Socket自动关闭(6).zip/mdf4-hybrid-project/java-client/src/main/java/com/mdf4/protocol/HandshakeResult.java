package com.mdf4.protocol;

/**
 * 握手响应
 */
public class HandshakeResult {
    
    private String version;
    private String status;
    private String serverTime;
    
    public HandshakeResult() {}
    
    public HandshakeResult(String version, String status, String serverTime) {
        this.version = version;
        this.status = status;
        this.serverTime = serverTime;
    }
    
    // Getters and Setters
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getServerTime() { return serverTime; }
    public void setServerTime(String serverTime) { this.serverTime = serverTime; }
}
