package com.mdf4.protocol;

import com.mdf4.FileMetadata;

/**
 * 文件元数据响应
 */
public class FileMetadataResult {
    
    private FileMetadata metadata;
    
    public FileMetadataResult() {}
    
    public FileMetadataResult(FileMetadata metadata) {
        this.metadata = metadata;
    }
    
    public FileMetadata getMetadata() { return metadata; }
    public void setMetadata(FileMetadata metadata) { this.metadata = metadata; }
}
