package com.mdf4.protocol;

import com.mdf4.ChannelMetadata;

/**
 * 通道元数据响应
 */
public class ChannelMetadataResult {
    
    private ChannelMetadata metadata;
    
    public ChannelMetadataResult() {}
    
    public ChannelMetadataResult(ChannelMetadata metadata) {
        this.metadata = metadata;
    }
    
    public ChannelMetadata getMetadata() { return metadata; }
    public void setMetadata(ChannelMetadata metadata) { this.metadata = metadata; }
}
