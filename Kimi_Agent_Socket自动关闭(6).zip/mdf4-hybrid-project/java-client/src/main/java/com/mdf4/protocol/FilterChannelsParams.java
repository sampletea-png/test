package com.mdf4.protocol;

import java.util.List;

/**
 * 过滤通道参数
 */
public class FilterChannelsParams {
    
    private List<String> channelNames;
    
    public FilterChannelsParams() {}
    
    public FilterChannelsParams(List<String> channelNames) {
        this.channelNames = channelNames;
    }
    
    public List<String> getChannelNames() { return channelNames; }
    public void setChannelNames(List<String> channelNames) { this.channelNames = channelNames; }
}
