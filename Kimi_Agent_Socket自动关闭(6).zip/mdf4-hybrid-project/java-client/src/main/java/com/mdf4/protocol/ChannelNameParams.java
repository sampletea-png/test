package com.mdf4.protocol;

/**
 * 通道名称参数（用于需要channelName的请求）
 */
public class ChannelNameParams {
    
    private String channelName;
    
    public ChannelNameParams() {}
    
    public ChannelNameParams(String channelName) {
        this.channelName = channelName;
    }
    
    public String getChannelName() { return channelName; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
}
