package com.mdf4.protocol;

import com.mdf4.ChannelInfo;

/**
 * 通道信息响应
 */
public class ChannelInfoResult {
    
    private ChannelInfo info;
    
    public ChannelInfoResult() {}
    
    public ChannelInfoResult(ChannelInfo info) {
        this.info = info;
    }
    
    public ChannelInfo getInfo() { return info; }
    public void setInfo(ChannelInfo info) { this.info = info; }
}
