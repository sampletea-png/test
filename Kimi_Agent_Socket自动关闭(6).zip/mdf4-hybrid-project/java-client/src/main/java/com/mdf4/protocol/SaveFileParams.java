package com.mdf4.protocol;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 保存文件请求参数
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SaveFileParams {
    
    private String filePath;
    private int compression = 0;
    
    public SaveFileParams() {}
    
    // Getters and Setters
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    
    public int getCompression() { return compression; }
    public void setCompression(int compression) { this.compression = compression; }
}
