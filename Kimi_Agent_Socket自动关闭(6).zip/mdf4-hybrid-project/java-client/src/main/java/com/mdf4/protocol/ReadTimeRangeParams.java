package com.mdf4.protocol;

import java.util.List;

/**
 * 按时间范围读取参数
 */
public class ReadTimeRangeParams {
    
    private List<String> channelNames;
    private double startTime;
    private double endTime;
    
    public ReadTimeRangeParams() {}
    
    public ReadTimeRangeParams(List<String> channelNames, double startTime, double endTime) {
        this.channelNames = channelNames;
        this.startTime = startTime;
        this.endTime = endTime;
    }
    
    // Getters and Setters
    public List<String> getChannelNames() { return channelNames; }
    public void setChannelNames(List<String> channelNames) { this.channelNames = channelNames; }
    
    public double getStartTime() { return startTime; }
    public void setStartTime(double startTime) { this.startTime = startTime; }
    
    public double getEndTime() { return endTime; }
    public void setEndTime(double endTime) { this.endTime = endTime; }
}
