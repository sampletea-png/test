package com.mdf4.protocol;

import com.mdf4.FileMetadata;

/**
 * 设置文件元数据参数
 */
public class SetFileMetadataParams {
    
    private FileMetadata metadata;
    
    public SetFileMetadataParams() {}
    
    public SetFileMetadataParams(FileMetadata metadata) {
        this.metadata = metadata;
    }
    
    public FileMetadata getMetadata() { return metadata; }
    public void setMetadata(FileMetadata metadata) { this.metadata = metadata; }
}
