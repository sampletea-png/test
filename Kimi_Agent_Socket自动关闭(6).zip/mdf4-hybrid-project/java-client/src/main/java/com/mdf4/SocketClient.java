package com.mdf4;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.mdf4.protocol.*;

/**
 * SocketClient - Java client for MDF4 operations via unified object protocol.
 * 
 * Protocol:
 * - Request:  { cmd: "command", params: {...}, reqId: "id" }
 * - Response: { success: true/false, data: {...}, error: "msg", reqId: "id" }
 * 
 * All conversions are done through objects (Java Object <-> JSON <-> Python Object)
 */
public class SocketClient implements AutoCloseable {
    
    private static final int DEFAULT_PORT = 25333;
    private static final String DEFAULT_HOST = "localhost";
    private static final int CONNECT_TIMEOUT_MS = 5000;
    private static final int READ_TIMEOUT_MS = 120000;
    private static final int MAX_RECONNECT_ATTEMPTS = 3;
    private static final int RECONNECT_DELAY_MS = 1000;
    private static final int MAX_CHUNK_SIZE = 1024 * 1024;
    
    private final String host;
    private int port;
    private final String portFilePath;
    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;
    private final ObjectMapper mapper;
    private final AtomicInteger requestIdGenerator;
    private boolean connected;
    private PythonServiceManager serviceManager;
    private boolean autoReconnect;
    private boolean autoRestartService;
    
    public SocketClient() {
        this(DEFAULT_HOST, DEFAULT_PORT);
    }
    
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.portFilePath = System.getProperty("user.dir") + "/python-service/mdf4_server.port";
        this.mapper = new ObjectMapper();
        this.requestIdGenerator = new AtomicInteger(0);
        this.connected = false;
        this.autoReconnect = true;
        this.autoRestartService = true;
    }
    
    public void setServiceManager(PythonServiceManager serviceManager) {
        this.serviceManager = serviceManager;
    }
    
    public void setAutoReconnect(boolean enabled) {
        this.autoReconnect = enabled;
    }
    
    public void setAutoRestartService(boolean enabled) {
        this.autoRestartService = enabled;
    }
    
    // ==================== Connection ====================
    
    public void connect() throws Mdf4Exception {
        int actualPort = readActualPortFromFile();
        if (actualPort != port) {
            System.out.println("Using actual port from file: " + actualPort + " (preferred was: " + port + ")");
            this.port = actualPort;
        }
        connectWithRetry(0);
    }
    
    private void connectWithRetry(int attempt) throws Mdf4Exception {
        try {
            doConnect();
        } catch (Mdf4Exception e) {
            if (attempt < MAX_RECONNECT_ATTEMPTS && autoReconnect) {
                System.out.println("Connection failed, retrying... (attempt " + (attempt + 1) + "/" + MAX_RECONNECT_ATTEMPTS + ")");
                
                if (autoRestartService && serviceManager != null) {
                    System.out.println("Attempting to restart Python service...");
                    if (serviceManager.restartService()) {
                        int newPort = readActualPortFromFile();
                        if (newPort != port) {
                            System.out.println("Server now using port: " + newPort);
                            this.port = newPort;
                        }
                    }
                }
                
                try {
                    Thread.sleep(RECONNECT_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new Mdf4Exception("Connection interrupted", ie);
                }
                connectWithRetry(attempt + 1);
            } else {
                throw e;
            }
        }
    }
    
    private void doConnect() throws Mdf4Exception {
        try {
            socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            socket.setSoTimeout(READ_TIMEOUT_MS);
            socket.setKeepAlive(true);
            socket.setTcpNoDelay(true);
            
            input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            
            if (!performHandshake()) {
                close();
                throw new Mdf4Exception("Handshake failed with server");
            }
            
            connected = true;
            System.out.println("Connected to MDF4 Socket Server at " + host + ":" + port);
            
        } catch (java.net.ConnectException e) {
            throw new Mdf4Exception("Failed to connect to server at " + host + ":" + port, e);
        } catch (IOException e) {
            throw new Mdf4Exception("Connection error: " + e.getMessage(), e);
        }
    }
    
    private boolean performHandshake() throws IOException {
        Request<Void> request = new Request<>("HANDSHAKE", null, "0");
        sendRequest(request);
        Response<HandshakeResult> response = receiveResponse(new TypeReference<Response<HandshakeResult>>() {});
        
        if (response == null || !response.isSuccess()) {
            return false;
        }
        
        HandshakeResult data = response.getData();
        if (data != null) {
            System.out.println("Handshake successful, server version: " + data.getVersion());
        }
        return true;
    }
    
    // ==================== Unified Communication ====================
    
    /**
     * Send request object to server
     */
    private <T> void sendRequest(Request<T> request) throws IOException {
        byte[] jsonBytes = mapper.writeValueAsBytes(request);
        
        synchronized (output) {
            output.writeInt(jsonBytes.length);
            for (int i = 0; i < jsonBytes.length; i += MAX_CHUNK_SIZE) {
                int chunkSize = Math.min(MAX_CHUNK_SIZE, jsonBytes.length - i);
                output.write(jsonBytes, i, chunkSize);
            }
            output.flush();
        }
    }
    
    /**
     * Receive response object from server
     */
    private <T> Response<T> receiveResponse(TypeReference<Response<T>> typeRef) throws IOException {
        byte[] lengthBytes = new byte[4];
        input.readFully(lengthBytes);
        int messageLength = ByteBuffer.wrap(lengthBytes).getInt();
        
        byte[] messageBytes = new byte[messageLength];
        int bytesRead = 0;
        
        while (bytesRead < messageLength) {
            int chunkSize = Math.min(MAX_CHUNK_SIZE, messageLength - bytesRead);
            int read = input.read(messageBytes, bytesRead, chunkSize);
            if (read < 0) {
                throw new IOException("Unexpected end of stream");
            }
            bytesRead += read;
        }
        
        return mapper.readValue(messageBytes, typeRef);
    }
    
    /**
     * Unified send command method - object to object
     */
    private <P, R> R sendCommand(String command, P params, TypeReference<Response<R>> responseType) throws Mdf4Exception {
        return sendCommand(command, params, responseType, true);
    }
    
    private <P, R> R sendCommand(String command, P params, TypeReference<Response<R>> responseType, boolean allowReconnect) throws Mdf4Exception {
        checkConnection();
        
        try {
            String reqId = String.valueOf(requestIdGenerator.incrementAndGet());
            Request<P> request = new Request<>(command, params, reqId);
            
            sendRequest(request);
            Response<R> response = receiveResponse(responseType);
            
            if (response == null) {
                throw new Mdf4Exception("No response from server");
            }
            
            if (!response.isSuccess()) {
                String error = response.getError() != null ? response.getError() : "Unknown error";
                throw new Mdf4Exception("Server error: " + error);
            }
            
            return response.getData();
            
        } catch (IOException e) {
            connected = false;
            
            if (allowReconnect && autoReconnect) {
                System.out.println("Connection lost, attempting to reconnect...");
                
                if (autoRestartService && serviceManager != null) {
                    serviceManager.restartService();
                }
                
                if (reconnect()) {
                    return sendCommand(command, params, responseType, false);
                }
            }
            
            throw new Mdf4Exception("Communication error: " + e.getMessage(), e);
        }
    }
    
    // ==================== File Operations ====================
    
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        return createNewFile(filePath, null, true);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata) throws Mdf4Exception {
        return createNewFile(filePath, metadata, true);
    }
    
    public boolean createNewFile(String filePath, FileMetadata metadata, boolean autoCreateDirs) throws Mdf4Exception {
        CreateFileParams params = new CreateFileParams(filePath);
        params.setAutoCreateDirs(autoCreateDirs);
        params.setMetadata(metadata);
        
        SuccessResult result = sendCommand("createNewFile", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean openFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, true, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        return openFile(filePath, readOnly, false, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate) throws Mdf4Exception {
        return openFile(filePath, readOnly, autoCreate, null);
    }
    
    public boolean openFile(String filePath, boolean readOnly, boolean autoCreate, FileMetadata metadata) throws Mdf4Exception {
        OpenFileParams params = new OpenFileParams(filePath);
        params.setReadOnly(readOnly);
        params.setAutoCreate(autoCreate);
        params.setMetadata(metadata);
        
        FilePathResult result = sendCommand("openFile", params, new TypeReference<Response<FilePathResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean closeFile() throws Mdf4Exception {
        SuccessResult result = sendCommand("closeFile", null, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        SaveFileParams params = new SaveFileParams();
        params.setFilePath(filePath);
        params.setCompression(compression);
        
        SuccessResult result = sendCommand("saveFile", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean saveFile() throws Mdf4Exception {
        return saveFile(null, 0);
    }
    
    // ==================== File Metadata Operations ====================
    
    public boolean setFileMetadata(FileMetadata metadata) throws Mdf4Exception {
        SetFileMetadataParams params = new SetFileMetadataParams(metadata);
        SuccessResult result = sendCommand("setFileMetadata", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public FileMetadata getFileMetadata() throws Mdf4Exception {
        FileMetadataResult result = sendCommand("getFileMetadata", null, new TypeReference<Response<FileMetadataResult>>() {});
        return result != null ? result.getMetadata() : new FileMetadata();
    }
    
    // ==================== Channel Write Operations ====================
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, unit, comment, dataType, null);
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType,
                              ChannelMetadata metadata) throws Mdf4Exception {
        AddChannelParams params = new AddChannelParams();
        params.setChannelName(channelName);
        params.setTimestamps(timestamps);
        params.setValues(values);
        params.setUnit(unit);
        params.setComment(comment);
        params.setDataType(dataType);
        params.setMetadata(metadata);
        
        SuccessResult result = sendCommand("addChannel", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, "", "", "float", null);
    }
    
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        WriteMultipleChannelsParams params = new WriteMultipleChannelsParams(channelDataList);
        SuccessResult result = sendCommand("writeMultipleChannels", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    // ==================== Channel Metadata Operations ====================
    
    public boolean setChannelMetadata(String channelName, ChannelMetadata metadata) throws Mdf4Exception {
        SetChannelMetadataParams params = new SetChannelMetadataParams(channelName, metadata);
        SuccessResult result = sendCommand("setChannelMetadata", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public ChannelMetadata getChannelMetadata(String channelName) throws Mdf4Exception {
        ChannelNameParams params = new ChannelNameParams(channelName);
        ChannelMetadataResult result = sendCommand("getChannelMetadata", params, new TypeReference<Response<ChannelMetadataResult>>() {});
        return result != null ? result.getMetadata() : new ChannelMetadata();
    }
    
    // ==================== Read Operations ====================
    
    public List<String> getChannelNames() throws Mdf4Exception {
        ChannelNamesResult result = sendCommand("getChannelNames", null, new TypeReference<Response<ChannelNamesResult>>() {});
        return result != null ? result.getNames() : new ArrayList<>();
    }
    
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        ChannelNameParams params = new ChannelNameParams(channelName);
        ChannelInfoResult result = sendCommand("getChannelInfo", params, new TypeReference<Response<ChannelInfoResult>>() {});
        return result != null ? result.getInfo() : null;
    }
    
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        ChannelNameParams params = new ChannelNameParams(channelName);
        DataRecordResult result = sendCommand("readChannel", params, new TypeReference<Response<DataRecordResult>>() {});
        return result != null ? result.getRecord() : null;
    }
    
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        FilterChannelsParams params = new FilterChannelsParams(channelNames);
        DataRecordsResult result = sendCommand("readMultipleChannels", params, new TypeReference<Response<DataRecordsResult>>() {});
        return result != null ? result.getRecords() : new ArrayList<>();
    }
    
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        ReadPartialParams params = new ReadPartialParams(channelName, startIndex, count);
        DataRecordResult result = sendCommand("readChannelPartial", params, new TypeReference<Response<DataRecordResult>>() {});
        return result != null ? result.getRecord() : null;
    }
    
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        ReadTimeRangeParams params = new ReadTimeRangeParams(channelNames, startTime, endTime);
        DataRecordsResult result = sendCommand("readChannelsPartial", params, new TypeReference<Response<DataRecordsResult>>() {});
        return result != null ? result.getRecords() : new ArrayList<>();
    }
    
    public int getSampleCount(String channelName) throws Mdf4Exception {
        ChannelNameParams params = new ChannelNameParams(channelName);
        SampleCountResult result = sendCommand("getSampleCount", params, new TypeReference<Response<SampleCountResult>>() {});
        return result != null ? result.getCount() : 0;
    }
    
    public double[] getTimeRange() throws Mdf4Exception {
        TimeRangeResult result = sendCommand("getTimeRange", null, new TypeReference<Response<TimeRangeResult>>() {});
        if (result != null && result.getRange() != null && result.getRange().size() >= 2) {
            return new double[]{result.getRange().get(0), result.getRange().get(1)};
        }
        return new double[]{0.0, 0.0};
    }
    
    // ==================== Utility Operations ====================
    
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        FilterChannelsParams params = new FilterChannelsParams(channelNames);
        SuccessResult result = sendCommand("filterChannels", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        CutTimeRangeParams params = new CutTimeRangeParams(startTime, endTime);
        SuccessResult result = sendCommand("cutTimeRange", params, new TypeReference<Response<SuccessResult>>() {});
        return result != null && result.isSuccess();
    }
    
    // ==================== Helper Methods ====================
    
    private int readActualPortFromFile() {
        try {
            String[] possiblePaths = {
                "python-service/mdf4_server.port",
                "../python-service/mdf4_server.port",
                "../../python-service/mdf4_server.port",
                System.getProperty("user.dir") + "/python-service/mdf4_server.port"
            };
            
            for (String path : possiblePaths) {
                java.io.File file = new java.io.File(path);
                if (file.exists()) {
                    String content = new String(Files.readAllBytes(file.toPath())).trim();
                    return Integer.parseInt(content);
                }
            }
        } catch (Exception e) {
            // Ignore
        }
        return port;
    }
    
    public boolean isConnectionAlive() {
        if (!isConnected()) {
            return false;
        }
        try {
            PingResult result = sendCommand("PING", null, new TypeReference<Response<PingResult>>() {});
            return result != null && result.getStatus() != null;
        } catch (Exception e) {
            return false;
        }
    }
    
    public boolean reconnect() {
        System.out.println("Attempting to reconnect...");
        disconnect();
        
        int actualPort = readActualPortFromFile();
        if (actualPort != port) {
            System.out.println("Using port from file: " + actualPort);
            this.port = actualPort;
        }
        
        try {
            connect();
            return true;
        } catch (Mdf4Exception e) {
            System.err.println("Reconnection failed: " + e.getMessage());
            return false;
        }
    }
    
    public void disconnect() {
        close();
    }
    
    public boolean isConnected() {
        return connected && socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    public int getPort() {
        return port;
    }
    
    public void setPort(int port) {
        this.port = port;
    }
    
    private void checkConnection() throws Mdf4Exception {
        if (!isConnected()) {
            if (autoReconnect) {
                if (!reconnect()) {
                    throw new Mdf4Exception("Not connected to server and reconnection failed");
                }
            } else {
                throw new Mdf4Exception("Not connected to server. Call connect() first.");
            }
        }
    }
    
    @Override
    public void close() {
        connected = false;
        try {
            if (input != null) input.close();
        } catch (IOException e) { }
        try {
            if (output != null) output.close();
        } catch (IOException e) { }
        try {
            if (socket != null) socket.close();
        } catch (IOException e) { }
        System.out.println("Disconnected from server");
    }
}
metadataJson, ChannelMetadata.class);
                info.setMetadata(metadata);
            } catch (Exception e) {
                System.err.println("Failed to parse channel metadata JSON: " + e.getMessage());
                info.setMetadata(new ChannelMetadata());
            }
        }
        
        return info;
    }
    
    /**
     * Read full channel data
     */
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("readChannel", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        if (recordObj == null) {
            return null;
        }
        
        return mapper.convertValue(recordObj, DataRecord.class);
    }
    
    /**
     * Read multiple channels at once
     */
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        
        ObjectNode result = sendCommand("readMultipleChannels", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        if (recordsArray == null) {
            return new ArrayList<>();
        }
        
        return mapper.convertValue(recordsArray, new TypeReference<List<DataRecord>>() {});
    }
    
    /**
     * Read partial channel data by index range
     */
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        params.put("startIndex", startIndex);
        params.put("count", count);
        
        ObjectNode result = sendCommand("readChannelPartial", params);
        ObjectNode recordObj = (ObjectNode) result.get("record");
        
        if (recordObj == null) {
            return null;
        }
        
        return mapper.convertValue(recordObj, DataRecord.class);
    }
    
    /**
     * Read partial channel data by time range
     */
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("readChannelsPartial", params);
        ArrayNode recordsArray = (ArrayNode) result.get("records");
        
        if (recordsArray == null) {
            return new ArrayList<>();
        }
        
        return mapper.convertValue(recordsArray, new TypeReference<List<DataRecord>>() {});
    }
    
    public int getSampleCount(String channelName) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("channelName", channelName);
        
        ObjectNode result = sendCommand("getSampleCount", params);
        return result.get("count").asInt();
    }
    
    public double[] getTimeRange() throws Mdf4Exception {
        ObjectNode result = sendCommand("getTimeRange", null);
        ArrayNode rangeArray = (ArrayNode) result.get("range");
        
        List<Double> range = mapper.convertValue(rangeArray, new TypeReference<List<Double>>() {});
        return new double[]{range.get(0), range.get(1)};
    }
    
    // ==================== Utility Operations ====================
    
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.set("channelNames", mapper.valueToTree(channelNames));
        
        ObjectNode result = sendCommand("filterChannels", params);
        return result.get("success").asBoolean();
    }
    
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        
        ObjectNode result = sendCommand("cutTimeRange", params);
        return result.get("success").asBoolean();
    }
}
