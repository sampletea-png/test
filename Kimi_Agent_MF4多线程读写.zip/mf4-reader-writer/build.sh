#!/bin/bash

# MDF4J 构建脚本

set -e

echo "==================================="
echo "MDF4J 构建脚本"
echo "==================================="

# 检查Python环境
echo ""
echo "[1/4] 检查Python环境..."
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "错误: 未找到Python"
    exit 1
fi

echo "Python版本: $($PYTHON --version)"

# 安装Python依赖
echo ""
echo "[2/4] 安装Python依赖..."
cd python
$PYTHON -m pip install -r requirements.txt -q
cd ..

# 构建Java项目
echo ""
echo "[3/4] 构建Java项目..."
cd java
if command -v mvn &> /dev/null; then
    mvn clean package -DskipTests -q
    echo "构建成功: target/mdf4j-1.0.0.jar"
else
    echo "警告: 未找到Maven，跳过Java构建"
fi
cd ..

# 运行测试
echo ""
echo "[4/4] 运行测试..."
cd java
if command -v mvn &> /dev/null; then
    mvn test -q || echo "测试完成（可能有失败）"
fi
cd ..

echo ""
echo "==================================="
echo "构建完成!"
echo "==================================="
echo ""
echo "使用说明:"
echo "  1. Java库: java/target/mdf4j-1.0.0.jar"
echo "  2. Python服务: python/mdf4_server.py"
echo ""
echo "运行示例:"
echo "  cd java"
echo "  mvn exec:java -Dexec.mainClass=com.mdf4j.Mdf4Example"
echo ""
