@echo off
chcp 65001 >nul

REM MDF4J 构建脚本 (Windows)

echo ===================================
echo MDF4J 构建脚本
echo ===================================
echo.

REM 检查Python环境
echo [1/4] 检查Python环境...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到Python
    exit /b 1
)
python --version

REM 安装Python依赖
echo.
echo [2/4] 安装Python依赖...
cd python
python -m pip install -r requirements.txt -q
cd ..

REM 构建Java项目
echo.
echo [3/4] 构建Java项目...
cd java
mvn --version >nul 2>&1
if %errorlevel% equ 0 (
    mvn clean package -DskipTests -q
    echo 构建成功: target\mdf4j-1.0.0.jar
) else (
    echo 警告: 未找到Maven，跳过Java构建
)
cd ..

REM 运行测试
echo.
echo [4/4] 运行测试...
cd java
mvn --version >nul 2>&1
if %errorlevel% equ 0 (
    mvn test -q
)
cd ..

echo.
echo ===================================
echo 构建完成!
echo ===================================
echo.
echo 使用说明:
echo   1. Java库: java\target\mdf4j-1.0.0.jar
echo   2. Python服务: python\mdf4_server.py
echo.

pause
