"""
通信协议模块
定义Java与Python之间的Request和Response数据结构
"""
import json
from enum import Enum
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict


class RequestType(Enum):
    """请求类型枚举"""
    # 文件操作
    OPEN_FILE = "open_file"              # 打开/创建文件
    SAVE_FILE = "save_file"              # 保存文件
    CLOSE_FILE = "close_file"            # 关闭文件
    GET_FILE_INFO = "get_file_info"      # 获取文件信息
    
    # Group操作
    ADD_GROUP = "add_group"              # 添加Group
    MODIFY_GROUP = "modify_group"        # 修改Group
    DELETE_GROUP = "delete_group"        # 删除Group
    GET_GROUP = "get_group"              # 获取Group
    GET_ALL_GROUPS = "get_all_groups"    # 获取所有Groups
    
    # Signal操作
    ADD_SIGNAL = "add_signal"            # 添加Signal
    MODIFY_SIGNAL = "modify_signal"      # 修改Signal
    DELETE_SIGNAL = "delete_signal"      # 删除Signal
    GET_SIGNAL = "get_signal"            # 获取Signal
    GET_SIGNAL_DATA = "get_signal_data"  # 获取Signal数据（支持分段）
    GET_ALL_SIGNALS = "get_all_signals"  # 获取所有Signals
    
    # 系统操作
    PING = "ping"                        # 心跳检测
    SHUTDOWN = "shutdown"                # 关闭服务


class ResponseStatus(Enum):
    """响应状态枚举"""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"  # 部分数据（用于分段读取）


@dataclass
class Request:
    """
    请求基类
    
    Attributes:
        request_type: 请求类型
        request_id: 请求唯一标识（用于多线程匹配）
        file_path: 操作的文件路径
        comment: 请求描述/注释
        params: 请求参数
    """
    request_type: RequestType
    request_id: str
    file_path: Optional[str] = None
    comment: Optional[str] = None
    params: Dict[str, Any] = field(default_factory=dict)
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        data = asdict(self)
        data['request_type'] = self.request_type.value
        return json.dumps(data, ensure_ascii=False)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Request':
        """从JSON字符串创建Request对象"""
        data = json.loads(json_str)
        data['request_type'] = RequestType(data['request_type'])
        return cls(**data)


@dataclass
class Response:
    """
    响应基类
    
    Attributes:
        request_id: 对应请求的ID
        status: 响应状态
        message: 响应消息
        comment: 响应描述/注释
        data: 响应数据
        has_more: 是否还有更多数据（用于分段读取）
        total_size: 总数据大小（用于分段读取）
        current_offset: 当前偏移量（用于分段读取）
    """
    request_id: str
    status: ResponseStatus
    message: str = ""
    comment: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    has_more: bool = False
    total_size: int = 0
    current_offset: int = 0
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        data = asdict(self)
        data['status'] = self.status.value
        return json.dumps(data, ensure_ascii=False)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Response':
        """从JSON字符串创建Response对象"""
        data = json.loads(json_str)
        data['status'] = ResponseStatus(data['status'])
        return cls(**data)
    
    @classmethod
    def success(cls, request_id: str, message: str = "操作成功", **kwargs) -> 'Response':
        """创建成功响应"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.SUCCESS,
            message=message,
            **kwargs
        )
    
    @classmethod
    def error(cls, request_id: str, message: str, **kwargs) -> 'Response':
        """创建错误响应"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.ERROR,
            message=message,
            **kwargs
        )
    
    @classmethod
    def partial(cls, request_id: str, message: str = "部分数据", **kwargs) -> 'Response':
        """创建部分数据响应（用于分段读取）"""
        return cls(
            request_id=request_id,
            status=ResponseStatus.PARTIAL,
            message=message,
            has_more=True,
            **kwargs
        )


# 便捷请求类定义

@dataclass
class OpenFileRequest(Request):
    """打开文件请求"""
    def __init__(self, request_id: str, file_path: str, create_if_not_exists: bool = False, 
                 comment: str = None):
        super().__init__(
            request_type=RequestType.OPEN_FILE,
            request_id=request_id,
            file_path=file_path,
            comment=comment or "打开MF4文件",
            params={"create_if_not_exists": create_if_not_exists}
        )


@dataclass
class SaveFileRequest(Request):
    """保存文件请求"""
    def __init__(self, request_id: str, file_path: str, overwrite: bool = False,
                 comment: str = None):
        super().__init__(
            request_type=RequestType.SAVE_FILE,
            request_id=request_id,
            file_path=file_path,
            comment=comment or "保存MF4文件",
            params={"overwrite": overwrite}
        )


@dataclass
class AddGroupRequest(Request):
    """添加Group请求"""
    def __init__(self, request_id: str, file_path: str, group_name: str,
                 comment: str = None, **kwargs):
        params = {"group_name": group_name}
        params.update(kwargs)
        super().__init__(
            request_type=RequestType.ADD_GROUP,
            request_id=request_id,
            file_path=file_path,
            comment=comment or f"添加Group: {group_name}",
            params=params
        )


@dataclass
class ModifyGroupRequest(Request):
    """修改Group请求"""
    def __init__(self, request_id: str, file_path: str, group_index: int,
                 new_comment: str = None, new_name: str = None, comment: str = None):
        super().__init__(
            request_type=RequestType.MODIFY_GROUP,
            request_id=request_id,
            file_path=file_path,
            comment=comment or f"修改Group[{group_index}]",
            params={
                "group_index": group_index,
                "new_comment": new_comment,
                "new_name": new_name
            }
        )


@dataclass
class AddSignalRequest(Request):
    """添加Signal请求"""
    def __init__(self, request_id: str, file_path: str, group_index: int,
                 signal_name: str, data: List[float], timestamps: List[float],
                 unit: str = "", comment: str = None, 
                 duplicate_mode: str = "append", **kwargs):
        """
        Args:
            duplicate_mode: 同名Signal处理方式 - "overwrite"覆盖或"append"追加
        """
        params = {
            "group_index": group_index,
            "signal_name": signal_name,
            "data": data,
            "timestamps": timestamps,
            "unit": unit,
            "duplicate_mode": duplicate_mode
        }
        params.update(kwargs)
        super().__init__(
            request_type=RequestType.ADD_SIGNAL,
            request_id=request_id,
            file_path=file_path,
            comment=comment or f"添加Signal: {signal_name}",
            params=params
        )


@dataclass
class GetSignalDataRequest(Request):
    """获取Signal数据请求（支持分段读取）"""
    def __init__(self, request_id: str, file_path: str, group_index: int,
                 signal_name: str, offset: int = 0, limit: int = 10000,
                 comment: str = None):
        """
        Args:
            offset: 数据起始偏移量
            limit: 每次读取的最大数据点数
        """
        super().__init__(
            request_type=RequestType.GET_SIGNAL_DATA,
            request_id=request_id,
            file_path=file_path,
            comment=comment or f"获取Signal数据: {signal_name}",
            params={
                "group_index": group_index,
                "signal_name": signal_name,
                "offset": offset,
                "limit": limit
            }
        )


@dataclass
class ShutdownRequest(Request):
    """关闭服务请求"""
    def __init__(self, request_id: str, comment: str = None):
        super().__init__(
            request_type=RequestType.SHUTDOWN,
            request_id=request_id,
            comment=comment or "关闭Python服务"
        )
