"""
日志配置模块
提供独立的日志文件记录，方便调试定位问题
"""
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from datetime import datetime


def setup_logger(name: str = "mdf4_server", log_dir: str = None, log_level: int = logging.DEBUG) -> logging.Logger:
    """
    配置并返回日志记录器
    
    Args:
        name: 日志记录器名称
        log_dir: 日志文件存放目录，默认为系统临时目录
        log_level: 日志级别
        
    Returns:
        配置好的日志记录器
    """
    logger = logging.getLogger(name)
    logger.setLevel(log_level)
    
    # 避免重复添加处理器
    if logger.handlers:
        return logger
    
    # 确定日志目录
    if log_dir is None:
        log_dir = os.path.join(os.path.expanduser("~"), ".mdf4j", "logs")
    
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名包含日期
    log_file = os.path.join(log_dir, f"mdf4_server_{datetime.now().strftime('%Y%m%d')}.log")
    
    # 文件处理器 - 使用RotatingFileHandler防止日志文件过大
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=50 * 1024 * 1024,  # 50MB
        backupCount=10,
        encoding='utf-8'
    )
    file_handler.setLevel(log_level)
    
    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    # 格式化器
    formatter = logging.Formatter(
        '[%(asctime)s] [%(levelname)s] [%(threadName)s] [%(filename)s:%(lineno)d] - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    logger.info(f"日志系统初始化完成，日志文件: {log_file}")
    
    return logger


def get_logger() -> logging.Logger:
    """获取默认日志记录器"""
    return logging.getLogger("mdf4_server")
