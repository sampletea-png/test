"""
请求处理器模块
处理各种类型的请求并调用相应的MDF4处理方法
"""
from typing import Dict, Any, Optional

from protocol import Request, Response, RequestType, ResponseStatus
from mdf4_handler import Mdf4Handler
from logger_config import get_logger

logger = get_logger()


class RequestHandler:
    """
    请求处理器
    将Request分发到对应的处理方法
    """
    
    def __init__(self, mdf_handler: Mdf4Handler):
        self._mdf_handler = mdf_handler
        logger.info("RequestHandler初始化完成")
    
    def handle(self, request: Request) -> Response:
        """
        处理请求的主入口
        
        Args:
            request: 请求对象
            
        Returns:
            响应对象
        """
        handler_map = {
            RequestType.OPEN_FILE: self._handle_open_file,
            RequestType.SAVE_FILE: self._handle_save_file,
            RequestType.CLOSE_FILE: self._handle_close_file,
            RequestType.GET_FILE_INFO: self._handle_get_file_info,
            RequestType.ADD_GROUP: self._handle_add_group,
            RequestType.MODIFY_GROUP: self._handle_modify_group,
            RequestType.DELETE_GROUP: self._handle_delete_group,
            RequestType.GET_GROUP: self._handle_get_group,
            RequestType.GET_ALL_GROUPS: self._handle_get_all_groups,
            RequestType.ADD_SIGNAL: self._handle_add_signal,
            RequestType.MODIFY_SIGNAL: self._handle_modify_signal,
            RequestType.DELETE_SIGNAL: self._handle_delete_signal,
            RequestType.GET_SIGNAL: self._handle_get_signal,
            RequestType.GET_SIGNAL_DATA: self._handle_get_signal_data,
            RequestType.GET_ALL_SIGNALS: self._handle_get_all_signals,
            RequestType.PING: self._handle_ping,
            RequestType.SHUTDOWN: self._handle_shutdown,
        }
        
        handler = handler_map.get(request.request_type)
        
        if handler is None:
            logger.error(f"未知的请求类型: {request.request_type}")
            return Response.error(
                request_id=request.request_id,
                message=f"未知的请求类型: {request.request_type}"
            )
        
        try:
            logger.debug(f"处理请求: {request.request_type.value}, id={request.request_id}")
            return handler(request)
        except Exception as e:
            logger.exception(f"处理请求时发生异常: {request.request_type.value}")
            return Response.error(
                request_id=request.request_id,
                message=f"处理请求时发生异常: {str(e)}"
            )
    
    def _handle_open_file(self, request: Request) -> Response:
        """处理打开文件请求"""
        create_if_not_exists = request.params.get("create_if_not_exists", False)
        
        success = self._mdf_handler.open_file(
            request.file_path,
            create_if_not_exists=create_if_not_exists
        )
        
        if success:
            info = self._mdf_handler.get_file_info(request.file_path)
            return Response.success(
                request_id=request.request_id,
                message="文件打开成功",
                data={"file_info": info}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="文件打开失败"
            )
    
    def _handle_save_file(self, request: Request) -> Response:
        """处理保存文件请求"""
        overwrite = request.params.get("overwrite", False)
        
        success = self._mdf_handler.save_file(
            request.file_path,
            overwrite=overwrite
        )
        
        if success:
            return Response.success(
                request_id=request.request_id,
                message="文件保存成功"
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="文件保存失败"
            )
    
    def _handle_close_file(self, request: Request) -> Response:
        """处理关闭文件请求"""
        success = self._mdf_handler.close_file(request.file_path)
        
        if success:
            return Response.success(
                request_id=request.request_id,
                message="文件关闭成功"
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="文件关闭失败"
            )
    
    def _handle_get_file_info(self, request: Request) -> Response:
        """处理获取文件信息请求"""
        info = self._mdf_handler.get_file_info(request.file_path)
        
        if info is not None:
            return Response.success(
                request_id=request.request_id,
                message="获取文件信息成功",
                data={"file_info": info}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取文件信息失败"
            )
    
    def _handle_add_group(self, request: Request) -> Response:
        """处理添加Group请求"""
        group_name = request.params.get("group_name", "")
        
        group_index = self._mdf_handler.add_group(
            request.file_path,
            group_name=group_name,
            **{k: v for k, v in request.params.items() if k != "group_name"}
        )
        
        if group_index is not None:
            return Response.success(
                request_id=request.request_id,
                message="Group添加成功",
                data={"group_index": group_index}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="Group添加失败"
            )
    
    def _handle_modify_group(self, request: Request) -> Response:
        """处理修改Group请求"""
        group_index = request.params.get("group_index")
        new_comment = request.params.get("new_comment")
        new_name = request.params.get("new_name")
        
        success = self._mdf_handler.modify_group(
            request.file_path,
            group_index=group_index,
            new_comment=new_comment,
            new_name=new_name
        )
        
        if success:
            return Response.success(
                request_id=request.request_id,
                message="Group修改成功"
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="Group修改失败"
            )
    
    def _handle_delete_group(self, request: Request) -> Response:
        """处理删除Group请求"""
        # asammdf不直接支持删除group，需要特殊处理
        logger.warning("删除Group功能暂未实现")
        return Response.error(
            request_id=request.request_id,
            message="删除Group功能暂未实现"
        )
    
    def _handle_get_group(self, request: Request) -> Response:
        """处理获取Group请求"""
        group_index = request.params.get("group_index")
        
        group_info = self._mdf_handler.get_group(
            request.file_path,
            group_index=group_index
        )
        
        if group_info is not None:
            return Response.success(
                request_id=request.request_id,
                message="获取Group成功",
                data={"group": group_info}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取Group失败"
            )
    
    def _handle_get_all_groups(self, request: Request) -> Response:
        """处理获取所有Groups请求"""
        groups = self._mdf_handler.get_all_groups(request.file_path)
        
        if groups is not None:
            return Response.success(
                request_id=request.request_id,
                message="获取所有Groups成功",
                data={"groups": groups}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取所有Groups失败"
            )
    
    def _handle_add_signal(self, request: Request) -> Response:
        """处理添加Signal请求"""
        params = request.params
        
        success = self._mdf_handler.add_signal(
            request.file_path,
            group_index=params.get("group_index", -1),
            signal_name=params.get("signal_name"),
            data=params.get("data", []),
            timestamps=params.get("timestamps", []),
            unit=params.get("unit", ""),
            duplicate_mode=params.get("duplicate_mode", "append"),
            **{k: v for k, v in params.items() 
               if k not in ["group_index", "signal_name", "data", "timestamps", "unit", "duplicate_mode"]}
        )
        
        if success:
            return Response.success(
                request_id=request.request_id,
                message="Signal添加成功"
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="Signal添加失败"
            )
    
    def _handle_modify_signal(self, request: Request) -> Response:
        """处理修改Signal请求"""
        logger.warning("修改Signal功能暂未实现")
        return Response.error(
            request_id=request.request_id,
            message="修改Signal功能暂未实现"
        )
    
    def _handle_delete_signal(self, request: Request) -> Response:
        """处理删除Signal请求"""
        logger.warning("删除Signal功能暂未实现")
        return Response.error(
            request_id=request.request_id,
            message="删除Signal功能暂未实现"
        )
    
    def _handle_get_signal(self, request: Request) -> Response:
        """处理获取Signal信息请求"""
        params = request.params
        
        signal_info = self._mdf_handler.get_signal_info(
            request.file_path,
            group_index=params.get("group_index"),
            signal_name=params.get("signal_name")
        )
        
        if signal_info is not None:
            return Response.success(
                request_id=request.request_id,
                message="获取Signal信息成功",
                data={"signal": signal_info}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取Signal信息失败"
            )
    
    def _handle_get_signal_data(self, request: Request) -> Response:
        """处理获取Signal数据请求（支持分段）"""
        params = request.params
        
        result = self._mdf_handler.get_signal_data(
            request.file_path,
            group_index=params.get("group_index"),
            signal_name=params.get("signal_name"),
            offset=params.get("offset", 0),
            limit=params.get("limit", 10000)
        )
        
        if result is not None:
            # 判断是否还有更多数据
            if result.get("has_more", False):
                return Response.partial(
                    request_id=request.request_id,
                    message="获取Signal数据成功（部分）",
                    data=result,
                    has_more=True,
                    total_size=result.get("total_samples", 0),
                    current_offset=result.get("current_offset", 0)
                )
            else:
                return Response.success(
                    request_id=request.request_id,
                    message="获取Signal数据成功",
                    data=result
                )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取Signal数据失败"
            )
    
    def _handle_get_all_signals(self, request: Request) -> Response:
        """处理获取所有Signals请求"""
        params = request.params
        group_index = params.get("group_index")
        
        # 获取指定group的所有channels
        groups = self._mdf_handler.get_all_groups(request.file_path)
        
        if groups and 0 <= group_index < len(groups):
            channels = groups[group_index].get("channels", [])
            return Response.success(
                request_id=request.request_id,
                message="获取所有Signals成功",
                data={"signals": channels}
            )
        else:
            return Response.error(
                request_id=request.request_id,
                message="获取所有Signals失败"
            )
    
    def _handle_ping(self, request: Request) -> Response:
        """处理心跳检测请求"""
        mem_info = self._mdf_handler.get_memory_usage()
        return Response.success(
            request_id=request.request_id,
            message="PONG",
            data={"memory_usage": mem_info}
        )
    
    def _handle_shutdown(self, request: Request) -> Response:
        """处理关闭服务请求"""
        logger.info("收到关闭服务请求")
        
        # 关闭所有文件
        self._mdf_handler.close_all_files()
        
        return Response.success(
            request_id=request.request_id,
            message="服务即将关闭"
        )
