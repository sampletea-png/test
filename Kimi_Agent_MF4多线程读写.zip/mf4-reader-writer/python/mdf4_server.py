#!/usr/bin/env python3
"""
MDF4 Socket服务器
提供Java端通过Socket与Python通信的能力
支持多线程并发处理请求
"""
import socket
import threading
import json
import sys
import os
import signal
import atexit
import time
from typing import Optional

from protocol import Request, Response, RequestType
from mdf4_handler import Mdf4Handler
from request_handler import RequestHandler
from logger_config import setup_logger, get_logger

# 设置日志
logger = setup_logger()


class Mdf4SocketServer:
    """
    MDF4 Socket服务器
    处理来自Java端的请求
    """
    
    def __init__(self, host: str = "127.0.0.1", port: int = 0, 
                 max_open_files: int = 10, memory_limit_mb: int = 512):
        """
        初始化服务器
        
        Args:
            host: 监听地址
            port: 监听端口，0表示自动分配
            max_open_files: 最大同时打开文件数
            memory_limit_mb: 内存限制（MB）
        """
        self._host = host
        self._port = port
        self._server_socket: Optional[socket.socket] = None
        self._running = False
        self._shutdown_event = threading.Event()
        
        # 初始化MDF4处理器
        self._mdf_handler = Mdf4Handler(
            max_open_files=max_open_files,
            memory_limit_mb=memory_limit_mb
        )
        
        # 初始化请求处理器
        self._request_handler = RequestHandler(self._mdf_handler)
        
        # 客户端连接管理
        self._client_threads: list[threading.Thread] = []
        self._client_lock = threading.Lock()
        
        # 父进程ID（用于检测Java端异常退出）
        self._parent_pid = os.getppid()
        
        logger.info(f"Mdf4SocketServer初始化完成，host={host}, port={port}")
    
    def start(self) -> int:
        """
        启动服务器
        
        Returns:
            实际监听的端口号
        """
        try:
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind((self._host, self._port))
            
            # 如果端口为0，获取实际分配的端口
            if self._port == 0:
                self._port = self._server_socket.getsockname()[1]
            
            self._server_socket.listen(10)
            self._running = True
            
            # 设置信号处理
            self._setup_signal_handlers()
            
            # 注册退出处理
            atexit.register(self.stop)
            
            # 启动父进程监控线程
            self._start_parent_monitor()
            
            logger.info(f"服务器启动成功，监听 {self._host}:{self._port}")
            
            # 打印端口号到stdout，供Java端读取
            print(f"PORT:{self._port}", flush=True)
            
            # 启动接受连接的主循环
            self._accept_loop()
            
            return self._port
            
        except Exception as e:
            logger.exception("服务器启动失败")
            raise
    
    def stop(self):
        """停止服务器"""
        if not self._running:
            return
        
        logger.info("正在停止服务器...")
        self._running = False
        self._shutdown_event.set()
        
        # 关闭服务器socket
        if self._server_socket:
            try:
                self._server_socket.close()
            except:
                pass
        
        # 等待所有客户端线程结束
        with self._client_lock:
            for thread in self._client_threads:
                if thread.is_alive():
                    thread.join(timeout=2)
        
        # 关闭所有文件
        self._mdf_handler.close_all_files()
        
        logger.info("服务器已停止")
    
    def _accept_loop(self):
        """接受客户端连接的主循环"""
        self._server_socket.settimeout(1.0)  # 设置超时以便检查running状态
        
        while self._running:
            try:
                client_socket, address = self._server_socket.accept()
                logger.info(f"新客户端连接: {address}")
                
                # 创建客户端处理线程
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_socket, address),
                    name=f"Client-{address[1]}"
                )
                client_thread.daemon = True
                
                with self._client_lock:
                    self._client_threads.append(client_thread)
                
                client_thread.start()
                
            except socket.timeout:
                continue
            except OSError:
                # socket已关闭
                break
            except Exception as e:
                if self._running:
                    logger.exception("接受连接时发生异常")
    
    def _handle_client(self, client_socket: socket.socket, address):
        """
        处理客户端连接
        
        Args:
            client_socket: 客户端socket
            address: 客户端地址
        """
        client_socket.settimeout(300)  # 5分钟超时
        
        try:
            while self._running and not self._shutdown_event.is_set():
                # 接收数据长度（4字节）
                length_bytes = self._recv_all(client_socket, 4)
                if not length_bytes:
                    break
                
                message_length = int.from_bytes(length_bytes, byteorder='big')
                
                # 接收完整消息
                message_bytes = self._recv_all(client_socket, message_length)
                if not message_bytes:
                    break
                
                # 解析请求
                request_json = message_bytes.decode('utf-8')
                request = Request.from_json(request_json)
                
                logger.debug(f"收到请求: {request.request_type.value}, id={request.request_id}")
                
                # 处理请求
                response = self._request_handler.handle(request)
                
                # 发送响应
                self._send_response(client_socket, response)
                
                # 如果是关闭请求，结束服务
                if request.request_type == RequestType.SHUTDOWN:
                    logger.info("收到关闭请求，停止服务")
                    self._running = False
                    break
                    
        except socket.timeout:
            logger.warning(f"客户端连接超时: {address}")
        except ConnectionResetError:
            logger.info(f"客户端连接重置: {address}")
        except Exception as e:
            logger.exception(f"处理客户端时发生异常: {address}")
        finally:
            try:
                client_socket.close()
            except:
                pass
            logger.info(f"客户端连接关闭: {address}")
    
    def _recv_all(self, sock: socket.socket, n: int) -> Optional[bytes]:
        """
        接收指定字节数的数据
        
        Args:
            sock: socket对象
            n: 需要接收的字节数
            
        Returns:
            接收到的数据，失败返回None
        """
        data = b""
        while len(data) < n:
            try:
                packet = sock.recv(n - len(data))
                if not packet:
                    return None
                data += packet
            except socket.timeout:
                return None
            except:
                return None
        return data
    
    def _send_response(self, sock: socket.socket, response: Response):
        """
        发送响应
        
        Args:
            sock: socket对象
            response: 响应对象
        """
        response_json = response.to_json()
        response_bytes = response_json.encode('utf-8')
        
        # 发送长度（4字节）+ 数据
        length_bytes = len(response_bytes).to_bytes(4, byteorder='big')
        sock.sendall(length_bytes + response_bytes)
        
        logger.debug(f"发送响应: {response.status.value}, id={response.request_id}")
    
    def _setup_signal_handlers(self):
        """设置信号处理器"""
        def signal_handler(signum, frame):
            logger.info(f"收到信号 {signum}，准备关闭")
            self.stop()
            sys.exit(0)
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # Windows平台不支持SIGBREAK
        if hasattr(signal, 'SIGBREAK'):
            signal.signal(signal.SIGBREAK, signal_handler)
    
    def _start_parent_monitor(self):
        """启动父进程监控线程"""
        def monitor():
            while self._running:
                try:
                    # 检查父进程是否仍然存在
                    if os.getppid() != self._parent_pid:
                        # 父进程已退出
                        logger.warning("检测到父进程退出，自动关闭服务")
                        self.stop()
                        break
                    
                    # 检查内存使用
                    mem_info = self._mdf_handler.get_memory_usage()
                    if mem_info["rss_mb"] > self._mdf_handler._memory_limit_mb:
                        logger.warning(f"内存使用超过限制: {mem_info['rss_mb']:.2f}MB")
                        # 尝试释放内存
                        self._mdf_handler.close_all_files()
                    
                    time.sleep(5)  # 每5秒检查一次
                except Exception as e:
                    logger.exception("父进程监控异常")
        
        monitor_thread = threading.Thread(target=monitor, name="ParentMonitor", daemon=True)
        monitor_thread.start()
        logger.info("父进程监控线程已启动")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="MDF4 Socket Server")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址")
    parser.add_argument("--port", type=int, default=0, help="监听端口（0表示自动分配）")
    parser.add_argument("--max-files", type=int, default=10, help="最大打开文件数")
    parser.add_argument("--memory-limit", type=int, default=512, help="内存限制（MB）")
    
    args = parser.parse_args()
    
    server = Mdf4SocketServer(
        host=args.host,
        port=args.port,
        max_open_files=args.max_files,
        memory_limit_mb=args.memory_limit
    )
    
    try:
        server.start()
    except KeyboardInterrupt:
        logger.info("收到键盘中断")
    finally:
        server.stop()


if __name__ == "__main__":
    main()
