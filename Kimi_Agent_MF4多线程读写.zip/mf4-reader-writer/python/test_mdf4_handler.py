#!/usr/bin/env python3
"""
MDF4处理器测试脚本
"""
import os
import sys
import tempfile
import time

from mdf4_handler import Mdf4Handler
from protocol import *


def test_open_and_save():
    """测试打开和保存文件"""
    print("\n=== 测试打开和保存文件 ===")
    
    handler = Mdf4Handler()
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        # 创建新文件
        result = handler.open_file(temp_path, create_if_not_exists=True)
        print(f"创建文件: {result}")
        assert result, "创建文件失败"
        
        # 保存文件
        result = handler.save_file(temp_path, overwrite=True)
        print(f"保存文件: {result}")
        assert result, "保存文件失败"
        
        # 关闭文件
        result = handler.close_file(temp_path)
        print(f"关闭文件: {result}")
        assert result, "关闭文件失败"
        
        print("✓ 打开和保存测试通过")
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_group_operations():
    """测试Group操作"""
    print("\n=== 测试Group操作 ===")
    
    handler = Mdf4Handler()
    
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        handler.open_file(temp_path, create_if_not_exists=True)
        
        # 添加Group
        group_index = handler.add_group(temp_path, "TestGroup")
        print(f"添加Group，索引: {group_index}")
        assert group_index is not None, "添加Group失败"
        
        # 获取Group信息
        group_info = handler.get_group(temp_path, group_index)
        print(f"Group信息: {group_info}")
        assert group_info is not None, "获取Group信息失败"
        
        # 获取所有Groups
        groups = handler.get_all_groups(temp_path)
        print(f"所有Groups: {groups}")
        assert groups is not None, "获取所有Groups失败"
        
        handler.close_file(temp_path)
        
        print("✓ Group操作测试通过")
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_signal_operations():
    """测试Signal操作"""
    print("\n=== 测试Signal操作 ===")
    
    handler = Mdf4Handler()
    
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        handler.open_file(temp_path, create_if_not_exists=True)
        
        # 添加Group
        group_index = handler.add_group(temp_path, "SignalGroup")
        
        # 准备数据
        import numpy as np
        data = np.sin(np.linspace(0, 10, 1000)).tolist()
        timestamps = np.linspace(0, 10, 1000).tolist()
        
        # 添加Signal
        result = handler.add_signal(
            temp_path, group_index, "SineWave",
            data, timestamps, "V", "append"
        )
        print(f"添加Signal: {result}")
        assert result, "添加Signal失败"
        
        # 保存文件
        handler.save_file(temp_path, overwrite=True)
        
        # 获取Signal数据
        signal_data = handler.get_signal_data(
            temp_path, group_index, "SineWave", 0, 100
        )
        print(f"Signal数据: 总样本数={signal_data['total_samples']}, "
              f"返回数={signal_data['returned_count']}, "
              f"has_more={signal_data['has_more']}")
        assert signal_data is not None, "获取Signal数据失败"
        
        handler.close_file(temp_path)
        
        print("✓ Signal操作测试通过")
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_large_file():
    """测试大文件处理"""
    print("\n=== 测试大文件处理 ===")
    
    handler = Mdf4Handler()
    
    with tempfile.NamedTemporaryFile(suffix='.mf4', delete=False) as f:
        temp_path = f.name
    
    try:
        handler.open_file(temp_path, create_if_not_exists=True)
        
        group_index = handler.add_group(temp_path, "LargeDataGroup")
        
        # 创建大数据（100万个数据点）
        import numpy as np
        print("正在生成100万个数据点...")
        data = np.random.randn(1000000).tolist()
        timestamps = np.linspace(0, 1000, 1000000).tolist()
        
        # 添加Signal
        result = handler.add_signal(
            temp_path, group_index, "LargeSignal",
            data, timestamps, "V", "append"
        )
        print(f"添加大数据Signal: {result}")
        assert result, "添加大数据Signal失败"
        
        handler.save_file(temp_path, overwrite=True)
        
        # 分段读取
        print("分段读取数据...")
        offset = 0
        limit = 10000
        total_read = 0
        
        while True:
            signal_data = handler.get_signal_data(
                temp_path, group_index, "LargeSignal", offset, limit
            )
            if signal_data is None:
                break
            
            total_read += signal_data['returned_count']
            
            if not signal_data['has_more']:
                break
            
            offset = signal_data['current_offset'] + signal_data['returned_count']
        
        print(f"总共读取: {total_read} 个数据点")
        assert total_read == 1000000, f"读取数据点数不匹配: {total_read} != 1000000"
        
        handler.close_file(temp_path)
        
        print("✓ 大文件处理测试通过")
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_memory_usage():
    """测试内存使用"""
    print("\n=== 测试内存使用 ===")
    
    handler = Mdf4Handler()
    
    mem_info = handler.get_memory_usage()
    print(f"内存使用: RSS={mem_info['rss_mb']:.2f}MB, "
          f"VMS={mem_info['vms_mb']:.2f}MB, "
          f"打开文件数={mem_info['open_files_count']}")
    
    print("✓ 内存使用测试通过")


def run_all_tests():
    """运行所有测试"""
    print("=" * 50)
    print("MDF4处理器测试")
    print("=" * 50)
    
    try:
        test_open_and_save()
        test_group_operations()
        test_signal_operations()
        test_large_file()
        test_memory_usage()
        
        print("\n" + "=" * 50)
        print("所有测试通过!")
        print("=" * 50)
        
    except Exception as e:
        print(f"\n测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    run_all_tests()
