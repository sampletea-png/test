"""
MDF4文件处理模块
提供对MF4文件的打开、保存、读写等操作
使用asammdf库处理MF4文件
"""
import os
import threading
import gc
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

from asammdf import MDF, Signal
import numpy as np

from logger_config import get_logger

logger = get_logger()


@dataclass
class FileHandle:
    """文件句柄封装"""
    mdf: MDF
    file_path: str
    access_lock: threading.Lock
    last_access_time: float
    is_modified: bool = False


class Mdf4Handler:
    """
    MDF4文件处理器
    管理多个MF4文件的打开、关闭和读写操作
    每个文件有独立的锁，支持多线程并发访问不同文件
    """
    
    def __init__(self, max_open_files: int = 10, memory_limit_mb: int = 512):
        """
        初始化处理器
        
        Args:
            max_open_files: 最大同时打开文件数
            memory_limit_mb: 内存使用限制（MB）
        """
        self._files: Dict[str, FileHandle] = {}
        self._global_lock = threading.RLock()
        self._max_open_files = max_open_files
        self._memory_limit_mb = memory_limit_mb
        logger.info(f"Mdf4Handler初始化完成，最大打开文件数: {max_open_files}, 内存限制: {memory_limit_mb}MB")
    
    def open_file(self, file_path: str, create_if_not_exists: bool = False) -> bool:
        """
        打开MF4文件
        
        Args:
            file_path: 文件路径
            create_if_not_exists: 文件不存在时是否创建
            
        Returns:
            是否成功打开
        """
        with self._global_lock:
            # 检查文件是否已打开
            if file_path in self._files:
                logger.debug(f"文件已打开: {file_path}")
                return True
            
            try:
                if os.path.exists(file_path):
                    # 打开现有文件
                    mdf = MDF(file_path)
                    logger.info(f"成功打开文件: {file_path}")
                elif create_if_not_exists:
                    # 创建新文件
                    mdf = MDF(version="4.10")
                    logger.info(f"创建新文件: {file_path}")
                else:
                    logger.error(f"文件不存在且不允许创建: {file_path}")
                    return False
                
                # 管理打开文件数量
                self._ensure_file_capacity()
                
                # 创建文件句柄
                handle = FileHandle(
                    mdf=mdf,
                    file_path=file_path,
                    access_lock=threading.Lock(),
                    last_access_time=__import__('time').time()
                )
                self._files[file_path] = handle
                return True
                
            except Exception as e:
                logger.exception(f"打开文件失败: {file_path}")
                return False
    
    def save_file(self, file_path: str, overwrite: bool = False) -> bool:
        """
        保存MF4文件
        
        Args:
            file_path: 文件路径
            overwrite: 是否覆盖已有文件
            
        Returns:
            是否成功保存
        """
        with self._global_lock:
            if file_path not in self._files:
                logger.error(f"文件未打开: {file_path}")
                return False
            
            handle = self._files[file_path]
            
        with handle.access_lock:
            try:
                if os.path.exists(file_path) and not overwrite:
                    logger.error(f"文件已存在且不允许覆盖: {file_path}")
                    return False
                
                handle.mdf.save(file_path, overwrite=overwrite)
                handle.is_modified = False
                handle.last_access_time = __import__('time').time()
                logger.info(f"文件保存成功: {file_path}")
                return True
                
            except Exception as e:
                logger.exception(f"保存文件失败: {file_path}")
                return False
    
    def close_file(self, file_path: str) -> bool:
        """
        关闭MF4文件
        
        Args:
            file_path: 文件路径
            
        Returns:
            是否成功关闭
        """
        with self._global_lock:
            if file_path not in self._files:
                return True
            
            handle = self._files[file_path]
            
        with handle.access_lock:
            try:
                handle.mdf.close()
                with self._global_lock:
                    del self._files[file_path]
                logger.info(f"文件关闭成功: {file_path}")
                
                # 强制垃圾回收，释放内存
                gc.collect()
                return True
                
            except Exception as e:
                logger.exception(f"关闭文件失败: {file_path}")
                return False
    
    def get_file_info(self, file_path: str) -> Optional[Dict[str, Any]]:
        """获取文件信息"""
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                info = {
                    "version": handle.mdf.version,
                    "groups_count": len(handle.mdf.groups),
                    "file_path": file_path
                }
                return info
            except Exception as e:
                logger.exception(f"获取文件信息失败: {file_path}")
                return None
    
    def add_group(self, file_path: str, group_name: str, **kwargs) -> Optional[int]:
        """
        添加Group
        
        Args:
            file_path: 文件路径
            group_name: Group名称
            
        Returns:
            新添加的Group索引，失败返回None
        """
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                # asammdf中，添加信号时会自动创建group
                # 这里返回当前group数量作为新group的索引
                group_index = len(handle.mdf.groups)
                handle.is_modified = True
                logger.info(f"添加Group成功: {group_name}, index={group_index}")
                return group_index
            except Exception as e:
                logger.exception(f"添加Group失败: {file_path}")
                return None
    
    def modify_group(self, file_path: str, group_index: int, 
                     new_comment: str = None, new_name: str = None) -> bool:
        """修改Group属性"""
        handle = self._get_handle(file_path)
        if not handle:
            return False
        
        with handle.access_lock:
            try:
                if group_index < 0 or group_index >= len(handle.mdf.groups):
                    logger.error(f"Group索引越界: {group_index}")
                    return False
                
                group = handle.mdf.groups[group_index]
                
                if new_comment is not None:
                    # 修改group的comment
                    if hasattr(group, 'channel_group'):
                        group.channel_group.comment = new_comment
                
                handle.is_modified = True
                logger.info(f"修改Group成功: index={group_index}")
                return True
                
            except Exception as e:
                logger.exception(f"修改Group失败: {file_path}, index={group_index}")
                return False
    
    def get_group(self, file_path: str, group_index: int) -> Optional[Dict[str, Any]]:
        """获取Group信息"""
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                if group_index < 0 or group_index >= len(handle.mdf.groups):
                    return None
                
                group = handle.mdf.groups[group_index]
                channels = handle.mdf.get_channel_names(group=group_index)
                
                comment = ""
                if hasattr(group, 'channel_group') and hasattr(group.channel_group, 'comment'):
                    comment = group.channel_group.comment or ""
                
                return {
                    "index": group_index,
                    "comment": comment,
                    "channels_count": len(channels),
                    "channels": channels
                }
            except Exception as e:
                logger.exception(f"获取Group失败: {file_path}, index={group_index}")
                return None
    
    def get_all_groups(self, file_path: str) -> Optional[List[Dict[str, Any]]]:
        """获取所有Groups信息"""
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                groups = []
                for i in range(len(handle.mdf.groups)):
                    group_info = self.get_group(file_path, i)
                    if group_info:
                        groups.append(group_info)
                return groups
            except Exception as e:
                logger.exception(f"获取所有Groups失败: {file_path}")
                return None
    
    def add_signal(self, file_path: str, group_index: int, signal_name: str,
                   data: List[float], timestamps: List[float], unit: str = "",
                   duplicate_mode: str = "append", **kwargs) -> bool:
        """
        添加Signal
        
        Args:
            file_path: 文件路径
            group_index: Group索引，-1表示自动创建新group
            signal_name: Signal名称
            data: 数据值列表
            timestamps: 时间戳列表
            unit: 单位
            duplicate_mode: 同名处理方式 - "overwrite"或"append"
            
        Returns:
            是否成功添加
        """
        handle = self._get_handle(file_path)
        if not handle:
            return False
        
        with handle.access_lock:
            try:
                # 转换数据为numpy数组
                np_data = np.array(data, dtype=np.float64)
                np_timestamps = np.array(timestamps, dtype=np.float64)
                
                # 检查同名signal
                existing_signals = handle.mdf.get_channel_names(group=group_index)
                
                if signal_name in existing_signals and duplicate_mode == "overwrite":
                    # 需要覆盖时，先删除旧signal
                    handle.mdf.remove(signal_name)
                    logger.debug(f"覆盖同名Signal: {signal_name}")
                
                # 创建Signal对象
                signal = Signal(
                    samples=np_data,
                    timestamps=np_timestamps,
                    name=signal_name,
                    unit=unit,
                    comment=kwargs.get("comment", "")
                )
                
                # 添加signal到mdf
                handle.mdf.append([signal])
                handle.is_modified = True
                
                logger.info(f"添加Signal成功: {signal_name}, group={group_index}, "
                          f"数据点数={len(data)}")
                return True
                
            except Exception as e:
                logger.exception(f"添加Signal失败: {file_path}, signal={signal_name}")
                return False
    
    def get_signal_data(self, file_path: str, group_index: int, signal_name: str,
                        offset: int = 0, limit: int = 10000) -> Optional[Dict[str, Any]]:
        """
        获取Signal数据（支持分段读取）
        
        Args:
            file_path: 文件路径
            group_index: Group索引
            signal_name: Signal名称
            offset: 数据起始偏移
            limit: 最大读取数据点数
            
        Returns:
            包含数据和元信息的字典
        """
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                # 获取signal
                signal = handle.mdf.get(signal_name, group=group_index)
                
                if signal is None:
                    logger.error(f"Signal不存在: {signal_name}")
                    return None
                
                total_samples = len(signal.samples)
                
                # 计算实际读取范围
                start = min(offset, total_samples)
                end = min(offset + limit, total_samples)
                
                # 分段读取数据
                data_slice = signal.samples[start:end].tolist()
                timestamps_slice = signal.timestamps[start:end].tolist()
                
                has_more = end < total_samples
                
                result = {
                    "signal_name": signal_name,
                    "group_index": group_index,
                    "data": data_slice,
                    "timestamps": timestamps_slice,
                    "unit": signal.unit if hasattr(signal, 'unit') else "",
                    "comment": signal.comment if hasattr(signal, 'comment') else "",
                    "total_samples": total_samples,
                    "current_offset": start,
                    "returned_count": len(data_slice),
                    "has_more": has_more
                }
                
                logger.debug(f"获取Signal数据: {signal_name}, offset={offset}, "
                           f"limit={limit}, returned={len(data_slice)}, has_more={has_more}")
                
                return result
                
            except Exception as e:
                logger.exception(f"获取Signal数据失败: {file_path}, signal={signal_name}")
                return None
    
    def get_signal_info(self, file_path: str, group_index: int, 
                        signal_name: str) -> Optional[Dict[str, Any]]:
        """获取Signal元信息"""
        handle = self._get_handle(file_path)
        if not handle:
            return None
        
        with handle.access_lock:
            try:
                signal = handle.mdf.get(signal_name, group=group_index)
                if signal is None:
                    return None
                
                return {
                    "name": signal_name,
                    "unit": signal.unit if hasattr(signal, 'unit') else "",
                    "comment": signal.comment if hasattr(signal, 'comment') else "",
                    "samples_count": len(signal.samples)
                }
            except Exception as e:
                logger.exception(f"获取Signal信息失败: {signal_name}")
                return None
    
    def _get_handle(self, file_path: str) -> Optional[FileHandle]:
        """获取文件句柄（内部方法）"""
        with self._global_lock:
            if file_path not in self._files:
                logger.error(f"文件未打开: {file_path}")
                return None
            handle = self._files[file_path]
            handle.last_access_time = __import__('time').time()
            return handle
    
    def _ensure_file_capacity(self):
        """确保文件容量不超过限制，关闭最久未访问的文件"""
        with self._global_lock:
            if len(self._files) < self._max_open_files:
                return
            
            # 按最后访问时间排序
            sorted_files = sorted(
                self._files.items(),
                key=lambda x: x[1].last_access_time
            )
            
            # 关闭最久未访问的文件
            files_to_close = len(self._files) - self._max_open_files + 1
            for i in range(files_to_close):
                path, handle = sorted_files[i]
                logger.info(f"自动关闭最久未访问的文件: {path}")
                threading.Thread(target=self.close_file, args=(path,)).start()
    
    def close_all_files(self):
        """关闭所有文件"""
        with self._global_lock:
            paths = list(self._files.keys())
        
        for path in paths:
            self.close_file(path)
        
        logger.info("所有文件已关闭")
    
    def get_memory_usage(self) -> Dict[str, Any]:
        """获取内存使用情况"""
        import psutil
        process = psutil.Process()
        mem_info = process.memory_info()
        
        return {
            "rss_mb": mem_info.rss / 1024 / 1024,
            "vms_mb": mem_info.vms / 1024 / 1024,
            "open_files_count": len(self._files)
        }
