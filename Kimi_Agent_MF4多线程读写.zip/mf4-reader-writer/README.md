# MDF4J - Java MF4文件读写库

MDF4J是一个Java库，用于读写MDF4（MF4）格式文件。它通过Socket与Python后端服务通信，利用asammdf库处理MF4文件的底层操作。

## 特性

- **多线程支持**: 支持多线程并发操作不同文件
- **大文件处理**: 支持GB级大文件的分段读取
- **内存优化**: Python端有内存限制和自动释放机制
- **进程管理**: Java端自动管理Python进程生命周期
- **异常安全**: Java端异常退出时Python进程自动关闭

## 项目结构

```
mf4-reader-writer/
├── java/                          # Java端代码
│   ├── src/main/java/com/mdf4j/
│   │   ├── Mdf4Client.java        # 客户端主类
│   │   ├── Mdf4File.java          # 文件操作类
│   │   ├── SocketClient.java      # Socket通信客户端
│   │   ├── PythonProcessManager.java  # Python进程管理
│   │   ├── request/               # 请求类
│   │   ├── response/              # 响应类
│   │   ├── model/                 # 数据模型
│   │   └── exception/             # 异常类
│   ├── src/test/java/             # 测试代码
│   └── pom.xml                    # Maven配置
│
└── python/                        # Python端代码
    ├── mdf4_server.py             # Socket服务器
    ├── mdf4_handler.py            # MDF4文件处理
    ├── request_handler.py         # 请求处理器
    ├── protocol.py                # 通信协议
    ├── logger_config.py           # 日志配置
    └── requirements.txt           # Python依赖
```

## 环境要求

### Java端
- JDK 8 或更高版本
- Maven 3.6+（用于构建）

### Python端
- Python 3.7 或更高版本
- asammdf >= 7.3.0
- numpy >= 1.21.0
- psutil >= 5.8.0

## 安装

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
```

### 2. 构建Java项目

```bash
cd java
mvn clean package
```

构建完成后，`target/`目录下会生成 `mdf4j-1.0.0.jar`。

## 使用示例

### 基本使用

```java
import com.mdf4j.Mdf4Client;
import com.mdf4j.Mdf4File;
import com.mdf4j.model.*;
import com.mdf4j.request.AddSignalRequest;

import java.util.ArrayList;
import java.util.List;

public class Example {
    public static void main(String[] args) {
        // 创建客户端
        Mdf4Client client = new Mdf4Client();
        
        try {
            // 初始化（自动启动Python服务）
            client.initialize();
            
            // 创建新文件
            Mdf4File file = client.createFile("/path/to/data.mf4");
            
            // 添加Group
            int groupIndex = file.addGroup("SensorData");
            
            // 准备数据
            List<Double> data = new ArrayList<>();
            List<Double> timestamps = new ArrayList<>();
            for (int i = 0; i < 1000; i++) {
                data.add(Math.sin(i * 0.1));
                timestamps.add(i * 0.01);
            }
            
            // 添加Signal
            file.addSignal(groupIndex, "SineWave", data, timestamps, 
                          "V", AddSignalRequest.DuplicateMode.APPEND);
            
            // 保存文件
            file.save();
            file.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭客户端
            client.shutdown();
        }
    }
}
```

### 读取数据

```java
// 打开已有文件
Mdf4File file = client.openFile("/path/to/data.mf4");

// 获取文件信息
FileInfo info = file.getFileInfo();
System.out.println("版本: " + info.getVersion());
System.out.println("Group数量: " + info.getGroupsCount());

// 获取所有Groups
List<GroupInfo> groups = file.getAllGroups();
for (GroupInfo group : groups) {
    System.out.println("Group[" + group.getIndex() + "]: " + group.getComment());
}

// 获取Signal数据（分段读取）
SignalData data = file.getSignalData(0, "SineWave", 0, 1000);
List<Double> values = data.getData();
List<Double> times = data.getTimestamps();

// 获取所有数据
SignalData allData = file.getSignalDataAll(0, "SineWave");

file.close();
```

### 多线程操作

```java
// 创建两个文件
final Mdf4File file1 = client.createFile("/path/to/file1.mf4");
final Mdf4File file2 = client.createFile("/path/to/file2.mf4");

// 两个线程同时操作不同文件
Thread t1 = new Thread(() -> {
    try {
        int group = file1.addGroup("Group1");
        file1.addSignal(group, "Signal1", data1, timestamps1);
        file1.save();
    } catch (Exception e) {
        e.printStackTrace();
    }
});

Thread t2 = new Thread(() -> {
    try {
        int group = file2.addGroup("Group2");
        file2.addSignal(group, "Signal2", data2, timestamps2);
        file2.save();
    } catch (Exception e) {
        e.printStackTrace();
    }
});

t1.start();
t2.start();
t1.join();
t2.join();
```

## API文档

### Mdf4Client

客户端主类，管理Python进程和提供文件操作接口。

| 方法 | 说明 |
|------|------|
| `initialize()` | 初始化客户端，启动Python服务 |
| `initialize(String pythonScriptPath)` | 使用指定Python脚本初始化 |
| `shutdown()` | 关闭客户端，释放资源 |
| `openFile(String filePath)` | 打开已有文件 |
| `openFile(String filePath, boolean createIfNotExists)` | 打开文件，可指定是否创建 |
| `createFile(String filePath)` | 创建新文件 |
| `closeFile(String filePath)` | 关闭指定文件 |
| `isHealthy()` | 检查服务是否健康 |

### Mdf4File

文件操作类，提供对单个MF4文件的操作。

| 方法 | 说明 |
|------|------|
| `save()` | 保存文件（不覆盖） |
| `save(boolean overwrite)` | 保存文件，可指定是否覆盖 |
| `close()` | 关闭文件 |
| `getFileInfo()` | 获取文件信息 |
| `addGroup(String groupName)` | 添加Group |
| `modifyGroup(int groupIndex, String newComment, String newName)` | 修改Group |
| `setGroupComment(int groupIndex, String newComment)` | 设置Group注释 |
| `getGroup(int groupIndex)` | 获取Group信息 |
| `getAllGroups()` | 获取所有Groups |
| `addSignal(...)` | 添加Signal |
| `getSignalInfo(int groupIndex, String signalName)` | 获取Signal信息 |
| `getSignalData(...)` | 获取Signal数据（分段） |
| `getSignalDataAll(...)` | 获取Signal所有数据 |
| `getAllSignalNames(int groupIndex)` | 获取所有Signal名称 |

## 配置参数

### Mdf4Client配置

```java
// 创建带配置的客户端
Mdf4Client client = new Mdf4Client(
    10,     // Python端最大打开文件数
    512,    // Python端内存限制（MB）
    null    // Python端日志目录（null使用默认）
);
```

### Python端命令行参数

```bash
python mdf4_server.py \
    --host 127.0.0.1 \      # 监听地址
    --port 0 \              # 监听端口（0表示自动分配）
    --max-files 10 \        # 最大打开文件数
    --memory-limit 512      # 内存限制（MB）
```

## 日志

### Python端日志

Python端日志默认存储在用户目录下的 `.mdf4j/logs/` 中：
- 日志文件: `mdf4_server_YYYYMMDD.log`
- 最大文件大小: 50MB
- 保留备份数: 10

### 日志格式

```
[2024-01-15 10:30:45] [INFO] [MainThread] [mdf4_server.py:123] - 服务器启动成功
```

## 大文件处理

对于GB级大文件，建议使用分段读取：

```java
int offset = 0;
int pageSize = 10000;  // 每页10000个数据点

while (true) {
    SignalData data = file.getSignalData(groupIndex, signalName, offset, pageSize);
    
    // 处理当前页数据
    processData(data.getData(), data.getTimestamps());
    
    if (!data.isHasMore()) {
        break;  // 没有更多数据
    }
    
    offset = data.getNextOffset();  // 下一页偏移量
}
```

## 注意事项

1. **线程安全**: 每个Mdf4File实例是线程安全的，但建议不同线程操作不同文件
2. **资源释放**: 确保调用 `client.shutdown()` 释放资源
3. **异常处理**: 所有操作都可能抛出 `Mdf4Exception`
4. **文件关闭**: 建议显式调用 `file.close()` 关闭文件

## 许可证

MIT License
