package com.mdf4j;

import com.mdf4j.exception.Mdf4Exception;
import com.mdf4j.request.PingRequest;
import com.mdf4j.request.ShutdownRequest;
import com.mdf4j.response.Response;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MDF4客户端主类
 * 管理Python进程生命周期，提供MF4文件操作接口
 * 线程安全：支持多线程并发操作不同文件
 */
public class Mdf4Client {
    
    private PythonProcessManager processManager;
    private SocketClient socketClient;
    private final AtomicBoolean initialized = new AtomicBoolean(false);
    
    // 已打开的文件缓存（文件路径 -> Mdf4File）
    private final ConcurrentHashMap<String, Mdf4File> openFiles = new ConcurrentHashMap<>();
    
    // Python脚本路径
    private String pythonScriptPath;
    
    // 配置参数
    private final int maxOpenFiles;
    private final int memoryLimitMb;
    private final String logDir;
    
    /**
     * 使用默认配置创建客户端
     */
    public Mdf4Client() {
        this(10, 512, null);
    }
    
    /**
     * 创建客户端
     * 
     * @param maxOpenFiles Python端最大打开文件数
     * @param memoryLimitMb Python端内存限制（MB）
     * @param logDir Python端日志目录
     */
    public Mdf4Client(int maxOpenFiles, int memoryLimitMb, String logDir) {
        this.maxOpenFiles = maxOpenFiles;
        this.memoryLimitMb = memoryLimitMb;
        this.logDir = logDir;
    }
    
    /**
     * 初始化客户端，启动Python服务
     * 
     * @throws Mdf4Exception 初始化失败时抛出
     */
    public synchronized void initialize() throws Mdf4Exception {
        if (initialized.get()) {
            return;
        }
        
        try {
            // 提取Python脚本到临时目录
            pythonScriptPath = extractPythonScript();
            
            // 启动Python进程
            processManager = new PythonProcessManager(
                pythonScriptPath, 
                maxOpenFiles, 
                memoryLimitMb, 
                logDir
            );
            processManager.start();
            
            // 创建Socket客户端
            int port = processManager.getServerPort();
            socketClient = new SocketClient("127.0.0.1", port);
            
            // 等待服务就绪
            waitForServiceReady();
            
            initialized.set(true);
            System.out.println("Mdf4Client初始化完成");
            
        } catch (Exception e) {
            shutdown();
            throw new Mdf4Exception("初始化失败", e);
        }
    }
    
    /**
     * 使用指定的Python脚本路径初始化
     * 
     * @param pythonScriptPath Python脚本路径
     * @throws Mdf4Exception 初始化失败时抛出
     */
    public synchronized void initialize(String pythonScriptPath) throws Mdf4Exception {
        if (initialized.get()) {
            return;
        }
        
        this.pythonScriptPath = pythonScriptPath;
        
        try {
            // 启动Python进程
            processManager = new PythonProcessManager(
                pythonScriptPath, 
                maxOpenFiles, 
                memoryLimitMb, 
                logDir
            );
            processManager.start();
            
            // 创建Socket客户端
            int port = processManager.getServerPort();
            socketClient = new SocketClient("127.0.0.1", port);
            
            // 等待服务就绪
            waitForServiceReady();
            
            initialized.set(true);
            System.out.println("Mdf4Client初始化完成");
            
        } catch (Exception e) {
            shutdown();
            throw new Mdf4Exception("初始化失败", e);
        }
    }
    
    /**
     * 关闭客户端，释放资源
     */
    public synchronized void shutdown() {
        if (!initialized.get() && processManager == null) {
            return;
        }
        
        // 关闭所有打开的文件
        for (Mdf4File file : openFiles.values()) {
            try {
                file.close();
            } catch (Exception e) {
                System.err.println("关闭文件失败: " + e.getMessage());
            }
        }
        openFiles.clear();
        
        // 关闭Socket连接
        if (socketClient != null) {
            try {
                // 发送关闭请求
                ShutdownRequest request = new ShutdownRequest();
                socketClient.sendRequest(request);
            } catch (Exception e) {
                System.err.println("发送关闭请求失败: " + e.getMessage());
            }
            
            socketClient.close();
            socketClient = null;
        }
        
        // 停止Python进程
        if (processManager != null) {
            processManager.stop();
            processManager = null;
        }
        
        initialized.set(false);
        System.out.println("Mdf4Client已关闭");
    }
    
    /**
     * 打开MF4文件
     * 
     * @param filePath 文件路径
     * @param createIfNotExists 文件不存在时是否创建
     * @return Mdf4File实例
     * @throws Mdf4Exception 打开失败时抛出
     */
    public Mdf4File openFile(String filePath, boolean createIfNotExists) throws Mdf4Exception {
        ensureInitialized();
        
        // 检查文件是否已打开
        Mdf4File existingFile = openFiles.get(filePath);
        if (existingFile != null && existingFile.isOpen()) {
            return existingFile;
        }
        
        Mdf4File file = Mdf4File.open(filePath, socketClient, createIfNotExists);
        openFiles.put(filePath, file);
        return file;
    }
    
    /**
     * 打开MF4文件（文件不存在时抛出异常）
     * 
     * @param filePath 文件路径
     * @return Mdf4File实例
     * @throws Mdf4Exception 打开失败时抛出
     */
    public Mdf4File openFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, false);
    }
    
    /**
     * 创建新的MF4文件
     * 
     * @param filePath 文件路径
     * @return Mdf4File实例
     * @throws Mdf4Exception 创建失败时抛出
     */
    public Mdf4File createFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, true);
    }
    
    /**
     * 关闭指定文件
     * 
     * @param filePath 文件路径
     * @throws Mdf4Exception 关闭失败时抛出
     */
    public void closeFile(String filePath) throws Mdf4Exception {
        Mdf4File file = openFiles.remove(filePath);
        if (file != null) {
            file.close();
        }
    }
    
    /**
     * 检查服务是否健康
     * 
     * @return 是否健康
     */
    public boolean isHealthy() {
        if (!initialized.get() || socketClient == null) {
            return false;
        }
        
        try {
            PingRequest request = new PingRequest();
            Response response = socketClient.sendRequest(request);
            return response.isSuccess();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 检查是否已初始化
     */
    public boolean isInitialized() {
        return initialized.get();
    }
    
    /**
     * 确保已初始化
     */
    private void ensureInitialized() throws Mdf4Exception {
        if (!initialized.get()) {
            throw new Mdf4Exception("客户端未初始化，请先调用initialize()");
        }
    }
    
    /**
     * 等待服务就绪
     */
    private void waitForServiceReady() throws Mdf4Exception {
        int maxRetries = 30;
        int retryIntervalMs = 100;
        
        for (int i = 0; i < maxRetries; i++) {
            try {
                Thread.sleep(retryIntervalMs);
                
                PingRequest request = new PingRequest();
                Response response = socketClient.sendRequest(request);
                
                if (response.isSuccess()) {
                    return;  // 服务就绪
                }
            } catch (Exception e) {
                // 继续重试
            }
        }
        
        throw new Mdf4Exception("等待Python服务就绪超时");
    }
    
    /**
     * 提取Python脚本到临时目录
     */
    private String extractPythonScript() throws Mdf4Exception {
        try {
            // 创建临时目录
            Path tempDir = Files.createTempDirectory("mdf4j_python");
            tempDir.toFile().deleteOnExit();
            
            // 需要提取的文件列表
            String[] pythonFiles = {
                "mdf4_server.py",
                "mdf4_handler.py",
                "request_handler.py",
                "protocol.py",
                "logger_config.py"
            };
            
            // 提取每个文件
            for (String fileName : pythonFiles) {
                String resourcePath = "/python/" + fileName;
                Path targetPath = tempDir.resolve(fileName);
                
                try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
                    if (is == null) {
                        throw new Mdf4Exception("无法找到资源: " + resourcePath);
                    }
                    Files.copy(is, targetPath, StandardCopyOption.REPLACE_EXISTING);
                    targetPath.toFile().deleteOnExit();
                }
            }
            
            return tempDir.resolve("mdf4_server.py").toString();
            
        } catch (Exception e) {
            throw new Mdf4Exception("提取Python脚本失败", e);
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        try {
            shutdown();
        } finally {
            super.finalize();
        }
    }
}
