package com.mdf4j.request;

/**
 * 获取Group请求
 */
public class GetGroupRequest extends Request {
    
    /**
     * 创建获取Group请求
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     */
    public GetGroupRequest(String filePath, int groupIndex) {
        super(RequestType.GET_GROUP);
        this.filePath = filePath;
        this.comment = "获取Group[" + groupIndex + "]信息";
        addParam("group_index", groupIndex);
    }
    
    /**
     * 创建获取Group请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param comment 请求注释
     */
    public GetGroupRequest(String filePath, int groupIndex, String comment) {
        this(filePath, groupIndex);
        this.comment = comment;
    }
}
