package com.mdf4j.request;

/**
 * 关闭文件请求
 */
public class CloseFileRequest extends Request {
    
    /**
     * 创建关闭文件请求
     * 
     * @param filePath 文件路径
     */
    public CloseFileRequest(String filePath) {
        super(RequestType.CLOSE_FILE);
        this.filePath = filePath;
        this.comment = "关闭MF4文件: " + filePath;
    }
    
    /**
     * 创建关闭文件请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param comment 请求注释
     */
    public CloseFileRequest(String filePath, String comment) {
        this(filePath);
        this.comment = comment;
    }
}
