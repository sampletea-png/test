package com.mdf4j.model;

import java.util.List;

/**
 * Signal数据模型
 * 包含数据值、时间戳和元信息
 */
public class SignalData {
    
    private String signalName;
    private int groupIndex;
    private List<Double> data;
    private List<Double> timestamps;
    private String unit;
    private String comment;
    private int totalSamples;
    private int currentOffset;
    private int returnedCount;
    private boolean hasMore;
    
    public SignalData() {
    }
    
    public SignalData(String signalName, int groupIndex, List<Double> data, 
                      List<Double> timestamps, String unit, String comment,
                      int totalSamples, int currentOffset, int returnedCount, boolean hasMore) {
        this.signalName = signalName;
        this.groupIndex = groupIndex;
        this.data = data;
        this.timestamps = timestamps;
        this.unit = unit;
        this.comment = comment;
        this.totalSamples = totalSamples;
        this.currentOffset = currentOffset;
        this.returnedCount = returnedCount;
        this.hasMore = hasMore;
    }
    
    // Getters and Setters
    
    public String getSignalName() {
        return signalName;
    }
    
    public void setSignalName(String signalName) {
        this.signalName = signalName;
    }
    
    public int getGroupIndex() {
        return groupIndex;
    }
    
    public void setGroupIndex(int groupIndex) {
        this.groupIndex = groupIndex;
    }
    
    public List<Double> getData() {
        return data;
    }
    
    public void setData(List<Double> data) {
        this.data = data;
    }
    
    public List<Double> getTimestamps() {
        return timestamps;
    }
    
    public void setTimestamps(List<Double> timestamps) {
        this.timestamps = timestamps;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public int getTotalSamples() {
        return totalSamples;
    }
    
    public void setTotalSamples(int totalSamples) {
        this.totalSamples = totalSamples;
    }
    
    public int getCurrentOffset() {
        return currentOffset;
    }
    
    public void setCurrentOffset(int currentOffset) {
        this.currentOffset = currentOffset;
    }
    
    public int getReturnedCount() {
        return returnedCount;
    }
    
    public void setReturnedCount(int returnedCount) {
        this.returnedCount = returnedCount;
    }
    
    public boolean isHasMore() {
        return hasMore;
    }
    
    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
    
    /**
     * 获取下一页的偏移量
     */
    public int getNextOffset() {
        return currentOffset + returnedCount;
    }
    
    @Override
    public String toString() {
        return "SignalData{" +
                "signalName='" + signalName + '\'' +
                ", groupIndex=" + groupIndex +
                ", dataSize=" + (data != null ? data.size() : 0) +
                ", totalSamples=" + totalSamples +
                ", hasMore=" + hasMore +
                '}';
    }
}
