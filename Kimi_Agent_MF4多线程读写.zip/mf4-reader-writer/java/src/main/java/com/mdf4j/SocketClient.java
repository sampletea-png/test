package com.mdf4j;

import com.google.gson.Gson;
import com.mdf4j.exception.Mdf4Exception;
import com.mdf4j.request.Request;
import com.mdf4j.response.Response;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Socket客户端
 * 负责与Python服务端通信
 */
public class SocketClient {
    
    private final String host;
    private final int port;
    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    private final ReentrantLock lock = new ReentrantLock();
    private final Gson gson = new Gson();
    
    // 超时设置
    private static final int CONNECT_TIMEOUT_MS = 10000;  // 连接超时10秒
    private static final int READ_TIMEOUT_MS = 300000;    // 读取超时5分钟
    
    public SocketClient(String host, int port) {
        this.host = host;
        this.port = port;
    }
    
    /**
     * 连接到服务器
     */
    public void connect() throws Mdf4Exception {
        lock.lock();
        try {
            if (socket != null && !socket.isClosed()) {
                return;  // 已连接
            }
            
            socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            socket.setSoTimeout(READ_TIMEOUT_MS);
            socket.setTcpNoDelay(true);  // 禁用Nagle算法，降低延迟
            socket.setKeepAlive(true);    // 启用TCP keepalive
            
            inputStream = new DataInputStream(
                new BufferedInputStream(socket.getInputStream())
            );
            outputStream = new DataOutputStream(
                new BufferedOutputStream(socket.getOutputStream())
            );
            
        } catch (IOException e) {
            close();
            throw new Mdf4Exception("连接Python服务失败: " + host + ":" + port, e);
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 发送请求并接收响应
     */
    public Response sendRequest(Request request) throws Mdf4Exception {
        lock.lock();
        try {
            ensureConnected();
            
            // 序列化请求
            String requestJson = request.toJson();
            byte[] requestBytes = requestJson.getBytes(StandardCharsets.UTF_8);
            
            // 发送长度（4字节）+ 数据
            outputStream.writeInt(requestBytes.length);
            outputStream.write(requestBytes);
            outputStream.flush();
            
            // 读取响应长度
            int responseLength = inputStream.readInt();
            if (responseLength <= 0 || responseLength > 100 * 1024 * 1024) {  // 最大100MB
                throw new Mdf4Exception("无效的响应长度: " + responseLength);
            }
            
            // 读取响应数据
            byte[] responseBytes = new byte[responseLength];
            inputStream.readFully(responseBytes);
            
            // 反序列化响应
            String responseJson = new String(responseBytes, StandardCharsets.UTF_8);
            return Response.fromJson(responseJson);
            
        } catch (IOException e) {
            close();
            throw new Mdf4Exception("通信失败: " + e.getMessage(), e);
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 发送请求并接收响应（带超时）
     */
    public Response sendRequest(Request request, long timeout, TimeUnit unit) throws Mdf4Exception {
        // 简单实现：先尝试连接，再发送请求
        // 更复杂的实现可以使用Future和ExecutorService
        return sendRequest(request);
    }
    
    /**
     * 确保已连接
     */
    private void ensureConnected() throws Mdf4Exception {
        if (socket == null || socket.isClosed() || !socket.isConnected()) {
            connect();
        }
    }
    
    /**
     * 关闭连接
     */
    public void close() {
        lock.lock();
        try {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException ignored) {
                }
                inputStream = null;
            }
            
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ignored) {
                }
                outputStream = null;
            }
            
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException ignored) {
                }
                socket = null;
            }
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * 检查连接状态
     */
    public boolean isConnected() {
        return socket != null && socket.isConnected() && !socket.isClosed();
    }
    
    public String getHost() {
        return host;
    }
    
    public int getPort() {
        return port;
    }
}
