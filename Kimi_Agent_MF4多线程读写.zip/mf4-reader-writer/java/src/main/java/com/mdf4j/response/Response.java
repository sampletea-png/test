package com.mdf4j.response;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 * 响应基类
 * 定义Python返回给Java的响应数据结构
 */
public class Response {
    
    @SerializedName("request_id")
    private String requestId;
    
    @SerializedName("status")
    private String status;
    
    @SerializedName("message")
    private String message;
    
    @SerializedName("comment")
    private String comment;
    
    @SerializedName("data")
    private Map<String, Object> data;
    
    @SerializedName("has_more")
    private boolean hasMore;
    
    @SerializedName("total_size")
    private int totalSize;
    
    @SerializedName("current_offset")
    private int currentOffset;
    
    private static final Gson gson = new Gson();
    
    /**
     * 将JSON字符串转换为响应对象
     */
    public static Response fromJson(String json) {
        return gson.fromJson(json, Response.class);
    }
    
    /**
     * 转换为JSON字符串
     */
    public String toJson() {
        return gson.toJson(this);
    }
    
    /**
     * 判断是否成功
     */
    public boolean isSuccess() {
        return "success".equals(status);
    }
    
    /**
     * 判断是否有更多数据（用于分段读取）
     */
    public boolean hasMoreData() {
        return hasMore;
    }
    
    // Getters and Setters
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public Map<String, Object> getData() {
        return data;
    }
    
    public void setData(Map<String, Object> data) {
        this.data = data;
    }
    
    public boolean isHasMore() {
        return hasMore;
    }
    
    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
    
    public int getTotalSize() {
        return totalSize;
    }
    
    public void setTotalSize(int totalSize) {
        this.totalSize = totalSize;
    }
    
    public int getCurrentOffset() {
        return currentOffset;
    }
    
    public void setCurrentOffset(int currentOffset) {
        this.currentOffset = currentOffset;
    }
    
    @Override
    public String toString() {
        return "Response{" +
                "requestId='" + requestId + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", hasMore=" + hasMore +
                ", totalSize=" + totalSize +
                ", currentOffset=" + currentOffset +
                '}';
    }
}
