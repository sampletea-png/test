package com.mdf4j;

import com.mdf4j.exception.Mdf4Exception;

import java.io.*;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Python进程管理器
 * 负责启动、监控和关闭Python服务进程
 */
public class PythonProcessManager {
    
    private Process pythonProcess;
    private final String pythonExecutable;
    private final String pythonScriptPath;
    private int serverPort = -1;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread shutdownHook;
    private Thread monitorThread;
    
    // 配置参数
    private final int maxOpenFiles;
    private final int memoryLimitMb;
    private final String logDir;
    
    // 端口范围
    private static final int MIN_PORT = 15000;
    private static final int MAX_PORT = 25000;
    private static final AtomicInteger portCounter = new AtomicInteger(MIN_PORT);
    
    public PythonProcessManager(String pythonScriptPath) {
        this(findPythonExecutable(), pythonScriptPath, 10, 512, null);
    }
    
    public PythonProcessManager(String pythonExecutable, String pythonScriptPath) {
        this(pythonExecutable, pythonScriptPath, 10, 512, null);
    }
    
    public PythonProcessManager(String pythonExecutable, String pythonScriptPath,
                                 int maxOpenFiles, int memoryLimitMb, String logDir) {
        this.pythonExecutable = pythonExecutable;
        this.pythonScriptPath = pythonScriptPath;
        this.maxOpenFiles = maxOpenFiles;
        this.memoryLimitMb = memoryLimitMb;
        this.logDir = logDir;
    }
    
    /**
     * 启动Python服务
     */
    public synchronized void start() throws Mdf4Exception {
        if (running.get()) {
            return;  // 已启动
        }
        
        try {
            // 验证Python脚本存在
            Path scriptPath = Paths.get(pythonScriptPath);
            if (!Files.exists(scriptPath)) {
                throw new Mdf4Exception("Python脚本不存在: " + pythonScriptPath);
            }
            
            // 查找可用端口
            serverPort = findAvailablePort();
            
            // 构建启动命令
            ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                pythonScriptPath,
                "--host", "127.0.0.1",
                "--port", String.valueOf(serverPort),
                "--max-files", String.valueOf(maxOpenFiles),
                "--memory-limit", String.valueOf(memoryLimitMb)
            );
            
            // 设置工作目录
            pb.directory(scriptPath.getParent().toFile());
            
            // 继承IO或重定向到文件
            pb.redirectErrorStream(true);
            
            // 启动进程
            pythonProcess = pb.start();
            
            // 读取端口号
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(pythonProcess.getInputStream())
            );
            
            String line;
            boolean portReceived = false;
            long startTime = System.currentTimeMillis();
            long timeout = 30000;  // 30秒超时
            
            while ((line = reader.readLine()) != null) {
                System.out.println("[Python] " + line);
                
                // 解析端口号
                if (line.startsWith("PORT:")) {
                    serverPort = Integer.parseInt(line.substring(5).trim());
                    portReceived = true;
                    break;
                }
                
                // 超时检查
                if (System.currentTimeMillis() - startTime > timeout) {
                    stop();
                    throw new Mdf4Exception("启动Python服务超时");
                }
            }
            
            if (!portReceived) {
                stop();
                throw new Mdf4Exception("未能获取Python服务端口号");
            }
            
            running.set(true);
            
            // 添加JVM关闭钩子
            shutdownHook = new Thread(this::stop);
            Runtime.getRuntime().addShutdownHook(shutdownHook);
            
            // 启动监控线程
            startMonitorThread();
            
            System.out.println("Python服务启动成功，端口: " + serverPort);
            
        } catch (IOException e) {
            stop();
            throw new Mdf4Exception("启动Python服务失败", e);
        }
    }
    
    /**
     * 停止Python服务
     */
    public synchronized void stop() {
        if (!running.get() && pythonProcess == null) {
            return;
        }
        
        running.set(false);
        
        // 移除关闭钩子
        if (shutdownHook != null) {
            try {
                Runtime.getRuntime().removeShutdownHook(shutdownHook);
            } catch (IllegalStateException ignored) {
                // JVM正在关闭
            }
            shutdownHook = null;
        }
        
        // 停止监控线程
        if (monitorThread != null) {
            monitorThread.interrupt();
            monitorThread = null;
        }
        
        // 关闭Python进程
        if (pythonProcess != null) {
            try {
                // 尝试优雅关闭
                pythonProcess.destroy();
                
                // 等待进程结束
                boolean terminated = pythonProcess.waitFor(5, TimeUnit.SECONDS);
                
                if (!terminated) {
                    // 强制关闭
                    pythonProcess.destroyForcibly();
                    pythonProcess.waitFor(2, TimeUnit.SECONDS);
                }
                
                System.out.println("Python服务已停止");
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                pythonProcess.destroyForcibly();
            } finally {
                pythonProcess = null;
            }
        }
        
        serverPort = -1;
    }
    
    /**
     * 获取服务器端口
     */
    public int getServerPort() {
        return serverPort;
    }
    
    /**
     * 检查是否运行中
     */
    public boolean isRunning() {
        return running.get() && pythonProcess != null && pythonProcess.isAlive();
    }
    
    /**
     * 查找可用端口
     */
    private int findAvailablePort() throws Mdf4Exception {
        for (int i = 0; i < 100; i++) {
            int port = portCounter.getAndIncrement();
            if (port > MAX_PORT) {
                portCounter.set(MIN_PORT);
                port = MIN_PORT;
            }
            
            try (ServerSocket ss = new ServerSocket(port)) {
                ss.setReuseAddress(true);
                return port;
            } catch (IOException ignored) {
                // 端口被占用，尝试下一个
            }
        }
        throw new Mdf4Exception("无法找到可用端口");
    }
    
    /**
     * 启动监控线程
     */
    private void startMonitorThread() {
        monitorThread = new Thread(() -> {
            while (running.get() && !Thread.currentThread().isInterrupted()) {
                try {
                    // 检查Python进程是否存活
                    if (pythonProcess != null && !pythonProcess.isAlive()) {
                        int exitCode = pythonProcess.exitValue();
                        System.err.println("Python进程异常退出，退出码: " + exitCode);
                        running.set(false);
                        break;
                    }
                    
                    Thread.sleep(5000);  // 每5秒检查一次
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "PythonProcessMonitor");
        monitorThread.setDaemon(true);
        monitorThread.start();
    }
    
    /**
     * 查找Python可执行文件
     */
    private static String findPythonExecutable() {
        String[] candidates = {"python3", "python", "py"};
        
        for (String candidate : candidates) {
            try {
                Process process = new ProcessBuilder(candidate, "--version")
                    .redirectErrorStream(true)
                    .start();
                
                boolean finished = process.waitFor(5, TimeUnit.SECONDS);
                if (finished && process.exitValue() == 0) {
                    return candidate;
                }
            } catch (Exception ignored) {
            }
        }
        
        // 默认返回python3
        return "python3";
    }
}
