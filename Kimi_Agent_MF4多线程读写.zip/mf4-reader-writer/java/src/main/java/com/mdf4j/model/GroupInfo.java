package com.mdf4j.model;

import java.util.List;

/**
 * Group信息模型
 */
public class GroupInfo {
    
    private int index;
    private String comment;
    private int channelsCount;
    private List<String> channels;
    
    public GroupInfo() {
    }
    
    public GroupInfo(int index, String comment, int channelsCount, List<String> channels) {
        this.index = index;
        this.comment = comment;
        this.channelsCount = channelsCount;
        this.channels = channels;
    }
    
    // Getters and Setters
    
    public int getIndex() {
        return index;
    }
    
    public void setIndex(int index) {
        this.index = index;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public int getChannelsCount() {
        return channelsCount;
    }
    
    public void setChannelsCount(int channelsCount) {
        this.channelsCount = channelsCount;
    }
    
    public List<String> getChannels() {
        return channels;
    }
    
    public void setChannels(List<String> channels) {
        this.channels = channels;
    }
    
    @Override
    public String toString() {
        return "GroupInfo{" +
                "index=" + index +
                ", comment='" + comment + '\'' +
                ", channelsCount=" + channelsCount +
                ", channels=" + channels +
                '}';
    }
}
