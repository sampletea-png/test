package com.mdf4j.request;

/**
 * 修改Group请求
 */
public class ModifyGroupRequest extends Request {
    
    /**
     * 创建修改Group请求
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param newComment 新的注释（可为null表示不修改）
     * @param newName 新的名称（可为null表示不修改）
     */
    public ModifyGroupRequest(String filePath, int groupIndex, String newComment, String newName) {
        super(RequestType.MODIFY_GROUP);
        this.filePath = filePath;
        this.comment = "修改Group[" + groupIndex + "]";
        addParam("group_index", groupIndex);
        if (newComment != null) {
            addParam("new_comment", newComment);
        }
        if (newName != null) {
            addParam("new_name", newName);
        }
    }
    
    /**
     * 创建修改Group请求（仅修改注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param newComment 新的注释
     */
    public ModifyGroupRequest(String filePath, int groupIndex, String newComment) {
        this(filePath, groupIndex, newComment, null);
    }
    
    /**
     * 创建修改Group请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param newComment 新的注释
     * @param newName 新的名称
     * @param comment 请求注释
     */
    public ModifyGroupRequest(String filePath, int groupIndex, String newComment, String newName, String comment) {
        this(filePath, groupIndex, newComment, newName);
        this.comment = comment;
    }
}
