package com.mdf4j.request;

/**
 * 获取Signal信息请求
 */
public class GetSignalRequest extends Request {
    
    /**
     * 创建获取Signal信息请求
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     */
    public GetSignalRequest(String filePath, int groupIndex, String signalName) {
        super(RequestType.GET_SIGNAL);
        this.filePath = filePath;
        this.comment = "获取Signal信息: " + signalName;
        addParam("group_index", groupIndex);
        addParam("signal_name", signalName);
    }
    
    /**
     * 创建获取Signal信息请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param comment 请求注释
     */
    public GetSignalRequest(String filePath, int groupIndex, String signalName, String comment) {
        this(filePath, groupIndex, signalName);
        this.comment = comment;
    }
}
