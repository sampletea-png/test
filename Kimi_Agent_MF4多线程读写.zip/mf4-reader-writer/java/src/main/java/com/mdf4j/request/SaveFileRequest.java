package com.mdf4j.request;

/**
 * 保存文件请求
 */
public class SaveFileRequest extends Request {
    
    /**
     * 创建保存文件请求
     * 
     * @param filePath 文件路径
     * @param overwrite 是否覆盖已有文件
     */
    public SaveFileRequest(String filePath, boolean overwrite) {
        super(RequestType.SAVE_FILE);
        this.filePath = filePath;
        this.comment = "保存MF4文件: " + filePath;
        addParam("overwrite", overwrite);
    }
    
    /**
     * 创建保存文件请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param overwrite 是否覆盖已有文件
     * @param comment 请求注释
     */
    public SaveFileRequest(String filePath, boolean overwrite, String comment) {
        this(filePath, overwrite);
        this.comment = comment;
    }
}
