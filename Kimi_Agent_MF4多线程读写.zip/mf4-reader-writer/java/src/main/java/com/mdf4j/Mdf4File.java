package com.mdf4j;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mdf4j.exception.Mdf4Exception;
import com.mdf4j.model.*;
import com.mdf4j.request.*;
import com.mdf4j.response.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * MDF4文件操作主类
 * 提供对MF4文件的打开、保存、读写等操作
 */
public class Mdf4File {
    
    private final String filePath;
    private final SocketClient socketClient;
    private final Gson gson = new Gson();
    private boolean isOpen = false;
    
    /**
     * 私有构造函数，通过工厂方法创建实例
     */
    private Mdf4File(String filePath, SocketClient socketClient) {
        this.filePath = filePath;
        this.socketClient = socketClient;
    }
    
    /**
     * 打开MF4文件
     * 
     * @param filePath 文件路径
     * @param socketClient Socket客户端
     * @param createIfNotExists 文件不存在时是否创建
     * @return Mdf4File实例
     * @throws Mdf4Exception 打开失败时抛出
     */
    public static Mdf4File open(String filePath, SocketClient socketClient, 
                                 boolean createIfNotExists) throws Mdf4Exception {
        Mdf4File mdfFile = new Mdf4File(filePath, socketClient);
        
        OpenFileRequest request = new OpenFileRequest(filePath, createIfNotExists);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("打开文件失败: " + response.getMessage());
        }
        
        mdfFile.isOpen = true;
        return mdfFile;
    }
    
    /**
     * 打开MF4文件（文件不存在时抛出异常）
     * 
     * @param filePath 文件路径
     * @param socketClient Socket客户端
     * @return Mdf4File实例
     * @throws Mdf4Exception 打开失败时抛出
     */
    public static Mdf4File open(String filePath, SocketClient socketClient) throws Mdf4Exception {
        return open(filePath, socketClient, false);
    }
    
    /**
     * 创建新的MF4文件
     * 
     * @param filePath 文件路径
     * @param socketClient Socket客户端
     * @return Mdf4File实例
     * @throws Mdf4Exception 创建失败时抛出
     */
    public static Mdf4File create(String filePath, SocketClient socketClient) throws Mdf4Exception {
        return open(filePath, socketClient, true);
    }
    
    /**
     * 保存文件
     * 
     * @param overwrite 是否覆盖已有文件
     * @throws Mdf4Exception 保存失败时抛出
     */
    public void save(boolean overwrite) throws Mdf4Exception {
        ensureOpen();
        
        SaveFileRequest request = new SaveFileRequest(filePath, overwrite);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("保存文件失败: " + response.getMessage());
        }
    }
    
    /**
     * 保存文件（不覆盖已有文件）
     * 
     * @throws Mdf4Exception 保存失败时抛出
     */
    public void save() throws Mdf4Exception {
        save(false);
    }
    
    /**
     * 关闭文件
     * 
     * @throws Mdf4Exception 关闭失败时抛出
     */
    public void close() throws Mdf4Exception {
        if (!isOpen) {
            return;
        }
        
        CloseFileRequest request = new CloseFileRequest(filePath);
        Response response = socketClient.sendRequest(request);
        
        isOpen = false;
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("关闭文件失败: " + response.getMessage());
        }
    }
    
    /**
     * 获取文件信息
     * 
     * @return 文件信息
     * @throws Mdf4Exception 获取失败时抛出
     */
    public FileInfo getFileInfo() throws Mdf4Exception {
        ensureOpen();
        
        Request request = new Request(Request.RequestType.GET_FILE_INFO);
        request.setFilePath(filePath);
        request.setComment("获取文件信息");
        
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("获取文件信息失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null && data.containsKey("file_info")) {
            LinkedTreeMap<?, ?> fileInfoMap = (LinkedTreeMap<?, ?>) data.get("file_info");
            return gson.fromJson(gson.toJson(fileInfoMap), FileInfo.class);
        }
        
        return null;
    }
    
    /**
     * 添加Group
     * 
     * @param groupName Group名称
     * @return 新Group的索引
     * @throws Mdf4Exception 添加失败时抛出
     */
    public int addGroup(String groupName) throws Mdf4Exception {
        ensureOpen();
        
        AddGroupRequest request = new AddGroupRequest(filePath, groupName);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("添加Group失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null && data.containsKey("group_index")) {
            Object index = data.get("group_index");
            if (index instanceof Number) {
                return ((Number) index).intValue();
            }
        }
        
        throw new Mdf4Exception("添加Group返回数据无效");
    }
    
    /**
     * 修改Group
     * 
     * @param groupIndex Group索引
     * @param newComment 新的注释（null表示不修改）
     * @param newName 新的名称（null表示不修改）
     * @throws Mdf4Exception 修改失败时抛出
     */
    public void modifyGroup(int groupIndex, String newComment, String newName) throws Mdf4Exception {
        ensureOpen();
        
        ModifyGroupRequest request = new ModifyGroupRequest(filePath, groupIndex, newComment, newName);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("修改Group失败: " + response.getMessage());
        }
    }
    
    /**
     * 修改Group注释
     * 
     * @param groupIndex Group索引
     * @param newComment 新的注释
     * @throws Mdf4Exception 修改失败时抛出
     */
    public void setGroupComment(int groupIndex, String newComment) throws Mdf4Exception {
        modifyGroup(groupIndex, newComment, null);
    }
    
    /**
     * 获取Group信息
     * 
     * @param groupIndex Group索引
     * @return Group信息
     * @throws Mdf4Exception 获取失败时抛出
     */
    public GroupInfo getGroup(int groupIndex) throws Mdf4Exception {
        ensureOpen();
        
        GetGroupRequest request = new GetGroupRequest(filePath, groupIndex);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("获取Group失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null && data.containsKey("group")) {
            LinkedTreeMap<?, ?> groupMap = (LinkedTreeMap<?, ?>) data.get("group");
            return gson.fromJson(gson.toJson(groupMap), GroupInfo.class);
        }
        
        return null;
    }
    
    /**
     * 获取所有Groups
     * 
     * @return Group信息列表
     * @throws Mdf4Exception 获取失败时抛出
     */
    public List<GroupInfo> getAllGroups() throws Mdf4Exception {
        ensureOpen();
        
        GetAllGroupsRequest request = new GetAllGroupsRequest(filePath);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("获取所有Groups失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        List<GroupInfo> groups = new ArrayList<>();
        
        if (data != null && data.containsKey("groups")) {
            List<?> groupsList = (List<?>) data.get("groups");
            for (Object obj : groupsList) {
                LinkedTreeMap<?, ?> groupMap = (LinkedTreeMap<?, ?>) obj;
                groups.add(gson.fromJson(gson.toJson(groupMap), GroupInfo.class));
            }
        }
        
        return groups;
    }
    
    /**
     * 添加Signal
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     * @param unit 单位
     * @param duplicateMode 同名处理方式
     * @throws Mdf4Exception 添加失败时抛出
     */
    public void addSignal(int groupIndex, String signalName, List<Double> data, 
                          List<Double> timestamps, String unit, 
                          AddSignalRequest.DuplicateMode duplicateMode) throws Mdf4Exception {
        ensureOpen();
        
        AddSignalRequest request = new AddSignalRequest(
            filePath, groupIndex, signalName, data, timestamps, unit, duplicateMode
        );
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("添加Signal失败: " + response.getMessage());
        }
    }
    
    /**
     * 添加Signal（使用默认追加模式）
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     * @throws Mdf4Exception 添加失败时抛出
     */
    public void addSignal(int groupIndex, String signalName, List<Double> data, 
                          List<Double> timestamps) throws Mdf4Exception {
        addSignal(groupIndex, signalName, data, timestamps, "", AddSignalRequest.DuplicateMode.APPEND);
    }
    
    /**
     * 获取Signal信息
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @return Signal信息
     * @throws Mdf4Exception 获取失败时抛出
     */
    public SignalInfo getSignalInfo(int groupIndex, String signalName) throws Mdf4Exception {
        ensureOpen();
        
        GetSignalRequest request = new GetSignalRequest(filePath, groupIndex, signalName);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("获取Signal信息失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null && data.containsKey("signal")) {
            LinkedTreeMap<?, ?> signalMap = (LinkedTreeMap<?, ?>) data.get("signal");
            return gson.fromJson(gson.toJson(signalMap), SignalInfo.class);
        }
        
        return null;
    }
    
    /**
     * 获取Signal数据（支持分段读取）
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param offset 数据起始偏移量
     * @param limit 每次读取的最大数据点数
     * @return Signal数据
     * @throws Mdf4Exception 获取失败时抛出
     */
    public SignalData getSignalData(int groupIndex, String signalName, int offset, int limit) throws Mdf4Exception {
        ensureOpen();
        
        GetSignalDataRequest request = new GetSignalDataRequest(filePath, groupIndex, signalName, offset, limit);
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess() && !"partial".equals(response.getStatus())) {
            throw new Mdf4Exception("获取Signal数据失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null) {
            SignalData signalData = new SignalData();
            signalData.setSignalName(getStringValue(data, "signal_name"));
            signalData.setGroupIndex(getIntValue(data, "group_index"));
            signalData.setData(getDoubleList(data, "data"));
            signalData.setTimestamps(getDoubleList(data, "timestamps"));
            signalData.setUnit(getStringValue(data, "unit"));
            signalData.setComment(getStringValue(data, "comment"));
            signalData.setTotalSamples(getIntValue(data, "total_samples"));
            signalData.setCurrentOffset(getIntValue(data, "current_offset"));
            signalData.setReturnedCount(getIntValue(data, "returned_count"));
            signalData.setHasMore(response.hasMoreData() || getBooleanValue(data, "has_more"));
            return signalData;
        }
        
        return null;
    }
    
    /**
     * 获取Signal所有数据（自动分页读取）
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param pageSize 每页大小
     * @return Signal数据
     * @throws Mdf4Exception 获取失败时抛出
     */
    public SignalData getSignalDataAll(int groupIndex, String signalName, int pageSize) throws Mdf4Exception {
        ensureOpen();
        
        List<Double> allData = new ArrayList<>();
        List<Double> allTimestamps = new ArrayList<>();
        SignalData firstPage = null;
        int offset = 0;
        
        while (true) {
            SignalData page = getSignalData(groupIndex, signalName, offset, pageSize);
            
            if (page == null) {
                break;
            }
            
            if (firstPage == null) {
                firstPage = page;
            }
            
            if (page.getData() != null) {
                allData.addAll(page.getData());
            }
            if (page.getTimestamps() != null) {
                allTimestamps.addAll(page.getTimestamps());
            }
            
            if (!page.isHasMore()) {
                break;
            }
            
            offset = page.getNextOffset();
        }
        
        if (firstPage != null) {
            firstPage.setData(allData);
            firstPage.setTimestamps(allTimestamps);
            firstPage.setReturnedCount(allData.size());
            firstPage.setHasMore(false);
        }
        
        return firstPage;
    }
    
    /**
     * 获取Signal所有数据（使用默认页大小10000）
     * 
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @return Signal数据
     * @throws Mdf4Exception 获取失败时抛出
     */
    public SignalData getSignalDataAll(int groupIndex, String signalName) throws Mdf4Exception {
        return getSignalDataAll(groupIndex, signalName, 10000);
    }
    
    /**
     * 获取所有Signal名称
     * 
     * @param groupIndex Group索引
     * @return Signal名称列表
     * @throws Mdf4Exception 获取失败时抛出
     */
    @SuppressWarnings("unchecked")
    public List<String> getAllSignalNames(int groupIndex) throws Mdf4Exception {
        ensureOpen();
        
        Request request = new Request(Request.RequestType.GET_ALL_SIGNALS);
        request.setFilePath(filePath);
        request.addParam("group_index", groupIndex);
        request.setComment("获取所有Signals");
        
        Response response = socketClient.sendRequest(request);
        
        if (!response.isSuccess()) {
            throw new Mdf4Exception("获取所有Signals失败: " + response.getMessage());
        }
        
        Map<String, Object> data = response.getData();
        if (data != null && data.containsKey("signals")) {
            return (List<String>) data.get("signals");
        }
        
        return new ArrayList<>();
    }
    
    /**
     * 确保文件已打开
     */
    private void ensureOpen() throws Mdf4Exception {
        if (!isOpen) {
            throw new Mdf4Exception("文件未打开");
        }
    }
    
    /**
     * 获取字符串值
     */
    private String getStringValue(Map<String, Object> data, String key) {
        if (data.containsKey(key)) {
            Object value = data.get(key);
            return value != null ? value.toString() : "";
        }
        return "";
    }
    
    /**
     * 获取整数值
     */
    private int getIntValue(Map<String, Object> data, String key) {
        if (data.containsKey(key)) {
            Object value = data.get(key);
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
        }
        return 0;
    }
    
    /**
     * 获取布尔值
     */
    private boolean getBooleanValue(Map<String, Object> data, String key) {
        if (data.containsKey(key)) {
            Object value = data.get(key);
            if (value instanceof Boolean) {
                return (Boolean) value;
            }
        }
        return false;
    }
    
    /**
     * 获取Double列表
     */
    @SuppressWarnings("unchecked")
    private List<Double> getDoubleList(Map<String, Object> data, String key) {
        if (data.containsKey(key)) {
            Object value = data.get(key);
            if (value instanceof List) {
                List<?> list = (List<?>) value;
                List<Double> result = new ArrayList<>(list.size());
                for (Object item : list) {
                    if (item instanceof Number) {
                        result.add(((Number) item).doubleValue());
                    }
                }
                return result;
            }
        }
        return new ArrayList<>();
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    public boolean isOpen() {
        return isOpen;
    }
}
