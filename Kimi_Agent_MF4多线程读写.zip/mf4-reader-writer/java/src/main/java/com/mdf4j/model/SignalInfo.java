package com.mdf4j.model;

/**
 * Signal信息模型
 */
public class SignalInfo {
    
    private String name;
    private String unit;
    private String comment;
    private int samplesCount;
    
    public SignalInfo() {
    }
    
    public SignalInfo(String name, String unit, String comment, int samplesCount) {
        this.name = name;
        this.unit = unit;
        this.comment = comment;
        this.samplesCount = samplesCount;
    }
    
    // Getters and Setters
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public int getSamplesCount() {
        return samplesCount;
    }
    
    public void setSamplesCount(int samplesCount) {
        this.samplesCount = samplesCount;
    }
    
    @Override
    public String toString() {
        return "SignalInfo{" +
                "name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", comment='" + comment + '\'' +
                ", samplesCount=" + samplesCount +
                '}';
    }
}
