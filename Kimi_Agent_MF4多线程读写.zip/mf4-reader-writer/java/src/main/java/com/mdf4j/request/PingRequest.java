package com.mdf4j.request;

/**
 * 心跳检测请求
 */
public class PingRequest extends Request {
    
    /**
     * 创建心跳检测请求
     */
    public PingRequest() {
        super(RequestType.PING);
        this.comment = "心跳检测";
    }
    
    /**
     * 创建心跳检测请求（带自定义注释）
     * 
     * @param comment 请求注释
     */
    public PingRequest(String comment) {
        this();
        this.comment = comment;
    }
}
