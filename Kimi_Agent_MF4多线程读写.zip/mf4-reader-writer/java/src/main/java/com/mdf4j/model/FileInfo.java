package com.mdf4j.model;

/**
 * 文件信息模型
 */
public class FileInfo {
    
    private String version;
    private int groupsCount;
    private String filePath;
    
    public FileInfo() {
    }
    
    public FileInfo(String version, int groupsCount, String filePath) {
        this.version = version;
        this.groupsCount = groupsCount;
        this.filePath = filePath;
    }
    
    // Getters and Setters
    
    public String getVersion() {
        return version;
    }
    
    public void setVersion(String version) {
        this.version = version;
    }
    
    public int getGroupsCount() {
        return groupsCount;
    }
    
    public void setGroupsCount(int groupsCount) {
        this.groupsCount = groupsCount;
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    @Override
    public String toString() {
        return "FileInfo{" +
                "version='" + version + '\'' +
                ", groupsCount=" + groupsCount +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
