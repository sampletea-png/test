package com.mdf4j.request;

import java.util.List;
import java.util.Map;

/**
 * 添加Signal请求
 */
public class AddSignalRequest extends Request {
    
    /**
     * 同名Signal处理方式
     */
    public enum DuplicateMode {
        OVERWRITE("overwrite"),  // 覆盖
        APPEND("append");        // 追加
        
        private final String value;
        
        DuplicateMode(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    /**
     * 创建添加Signal请求
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引（-1表示自动创建新Group）
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     * @param unit 单位
     * @param duplicateMode 同名处理方式
     */
    public AddSignalRequest(String filePath, int groupIndex, String signalName,
                            List<Double> data, List<Double> timestamps, 
                            String unit, DuplicateMode duplicateMode) {
        super(RequestType.ADD_SIGNAL);
        this.filePath = filePath;
        this.comment = "添加Signal: " + signalName;
        addParam("group_index", groupIndex);
        addParam("signal_name", signalName);
        addParam("data", data);
        addParam("timestamps", timestamps);
        addParam("unit", unit != null ? unit : "");
        addParam("duplicate_mode", duplicateMode != null ? duplicateMode.getValue() : "append");
    }
    
    /**
     * 创建添加Signal请求（简化版，使用默认追加模式）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     */
    public AddSignalRequest(String filePath, int groupIndex, String signalName,
                            List<Double> data, List<Double> timestamps) {
        this(filePath, groupIndex, signalName, data, timestamps, "", DuplicateMode.APPEND);
    }
    
    /**
     * 创建添加Signal请求（带额外参数）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     * @param unit 单位
     * @param duplicateMode 同名处理方式
     * @param extraParams 额外参数（如comment等）
     */
    public AddSignalRequest(String filePath, int groupIndex, String signalName,
                            List<Double> data, List<Double> timestamps, 
                            String unit, DuplicateMode duplicateMode,
                            Map<String, Object> extraParams) {
        this(filePath, groupIndex, signalName, data, timestamps, unit, duplicateMode);
        if (extraParams != null) {
            extraParams.forEach(this::addParam);
        }
    }
    
    /**
     * 创建添加Signal请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param data 数据值列表
     * @param timestamps 时间戳列表
     * @param unit 单位
     * @param duplicateMode 同名处理方式
     * @param comment 请求注释
     */
    public AddSignalRequest(String filePath, int groupIndex, String signalName,
                            List<Double> data, List<Double> timestamps, 
                            String unit, DuplicateMode duplicateMode, String comment) {
        this(filePath, groupIndex, signalName, data, timestamps, unit, duplicateMode);
        this.comment = comment;
    }
}
