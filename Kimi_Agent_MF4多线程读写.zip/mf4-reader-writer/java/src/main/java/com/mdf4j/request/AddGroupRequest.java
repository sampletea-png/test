package com.mdf4j.request;

import java.util.Map;

/**
 * 添加Group请求
 */
public class AddGroupRequest extends Request {
    
    /**
     * 创建添加Group请求
     * 
     * @param filePath 文件路径
     * @param groupName Group名称
     */
    public AddGroupRequest(String filePath, String groupName) {
        super(RequestType.ADD_GROUP);
        this.filePath = filePath;
        this.comment = "添加Group: " + groupName;
        addParam("group_name", groupName);
    }
    
    /**
     * 创建添加Group请求（带额外参数）
     * 
     * @param filePath 文件路径
     * @param groupName Group名称
     * @param extraParams 额外参数
     */
    public AddGroupRequest(String filePath, String groupName, Map<String, Object> extraParams) {
        this(filePath, groupName);
        if (extraParams != null) {
            extraParams.forEach(this::addParam);
        }
    }
    
    /**
     * 创建添加Group请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupName Group名称
     * @param comment 请求注释
     */
    public AddGroupRequest(String filePath, String groupName, String comment) {
        this(filePath, groupName);
        this.comment = comment;
    }
}
