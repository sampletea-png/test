package com.mdf4j.request;

/**
 * 获取Signal数据请求（支持分段读取）
 */
public class GetSignalDataRequest extends Request {
    
    /**
     * 创建获取Signal数据请求
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param offset 数据起始偏移量
     * @param limit 每次读取的最大数据点数
     */
    public GetSignalDataRequest(String filePath, int groupIndex, String signalName, 
                                 int offset, int limit) {
        super(RequestType.GET_SIGNAL_DATA);
        this.filePath = filePath;
        this.comment = "获取Signal数据: " + signalName;
        addParam("group_index", groupIndex);
        addParam("signal_name", signalName);
        addParam("offset", offset);
        addParam("limit", limit);
    }
    
    /**
     * 创建获取Signal数据请求（从起始位置读取）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param limit 每次读取的最大数据点数
     */
    public GetSignalDataRequest(String filePath, int groupIndex, String signalName, int limit) {
        this(filePath, groupIndex, signalName, 0, limit);
    }
    
    /**
     * 创建获取Signal数据请求（默认读取10000条）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     */
    public GetSignalDataRequest(String filePath, int groupIndex, String signalName) {
        this(filePath, groupIndex, signalName, 0, 10000);
    }
    
    /**
     * 创建获取Signal数据请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param groupIndex Group索引
     * @param signalName Signal名称
     * @param offset 数据起始偏移量
     * @param limit 每次读取的最大数据点数
     * @param comment 请求注释
     */
    public GetSignalDataRequest(String filePath, int groupIndex, String signalName, 
                                 int offset, int limit, String comment) {
        this(filePath, groupIndex, signalName, offset, limit);
        this.comment = comment;
    }
}
