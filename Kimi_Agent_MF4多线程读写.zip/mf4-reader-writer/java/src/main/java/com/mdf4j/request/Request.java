package com.mdf4j.request;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 请求基类
 * 定义Java与Python之间的请求数据结构
 */
public class Request {
    
    @SerializedName("request_type")
    protected String requestType;
    
    @SerializedName("request_id")
    protected String requestId;
    
    @SerializedName("file_path")
    protected String filePath;
    
    @SerializedName("comment")
    protected String comment;
    
    @SerializedName("params")
    protected Map<String, Object> params;
    
    private static final Gson gson = new Gson();
    
    public Request() {
        this.requestId = UUID.randomUUID().toString();
        this.params = new HashMap<>();
    }
    
    public Request(RequestType requestType) {
        this();
        this.requestType = requestType.getValue();
    }
    
    /**
     * 将请求转换为JSON字符串
     */
    public String toJson() {
        return gson.toJson(this);
    }
    
    /**
     * 从JSON字符串创建请求对象
     */
    public static Request fromJson(String json) {
        return gson.fromJson(json, Request.class);
    }
    
    // Getters and Setters
    
    public String getRequestType() {
        return requestType;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public Map<String, Object> getParams() {
        return params;
    }
    
    public void setParams(Map<String, Object> params) {
        this.params = params;
    }
    
    /**
     * 添加参数
     */
    public void addParam(String key, Object value) {
        if (this.params == null) {
            this.params = new HashMap<>();
        }
        this.params.put(key, value);
    }
    
    /**
     * 请求类型枚举
     */
    public enum RequestType {
        // 文件操作
        OPEN_FILE("open_file"),
        SAVE_FILE("save_file"),
        CLOSE_FILE("close_file"),
        GET_FILE_INFO("get_file_info"),
        
        // Group操作
        ADD_GROUP("add_group"),
        MODIFY_GROUP("modify_group"),
        DELETE_GROUP("delete_group"),
        GET_GROUP("get_group"),
        GET_ALL_GROUPS("get_all_groups"),
        
        // Signal操作
        ADD_SIGNAL("add_signal"),
        MODIFY_SIGNAL("modify_signal"),
        DELETE_SIGNAL("delete_signal"),
        GET_SIGNAL("get_signal"),
        GET_SIGNAL_DATA("get_signal_data"),
        GET_ALL_SIGNALS("get_all_signals"),
        
        // 系统操作
        PING("ping"),
        SHUTDOWN("shutdown");
        
        private final String value;
        
        RequestType(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
}
