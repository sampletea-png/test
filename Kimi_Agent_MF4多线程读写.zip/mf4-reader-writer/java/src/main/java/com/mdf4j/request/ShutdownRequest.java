package com.mdf4j.request;

/**
 * 关闭服务请求
 */
public class ShutdownRequest extends Request {
    
    /**
     * 创建关闭服务请求
     */
    public ShutdownRequest() {
        super(RequestType.SHUTDOWN);
        this.comment = "关闭Python服务";
    }
    
    /**
     * 创建关闭服务请求（带自定义注释）
     * 
     * @param comment 请求注释
     */
    public ShutdownRequest(String comment) {
        this();
        this.comment = comment;
    }
}
