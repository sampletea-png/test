package com.mdf4j.request;

/**
 * 获取所有Groups请求
 */
public class GetAllGroupsRequest extends Request {
    
    /**
     * 创建获取所有Groups请求
     * 
     * @param filePath 文件路径
     */
    public GetAllGroupsRequest(String filePath) {
        super(RequestType.GET_ALL_GROUPS);
        this.filePath = filePath;
        this.comment = "获取所有Groups信息";
    }
    
    /**
     * 创建获取所有Groups请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param comment 请求注释
     */
    public GetAllGroupsRequest(String filePath, String comment) {
        this(filePath);
        this.comment = comment;
    }
}
