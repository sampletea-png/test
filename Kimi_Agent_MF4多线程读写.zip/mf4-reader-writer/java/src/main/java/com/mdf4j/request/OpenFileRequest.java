package com.mdf4j.request;

/**
 * 打开文件请求
 */
public class OpenFileRequest extends Request {
    
    /**
     * 创建打开文件请求
     * 
     * @param filePath 文件路径
     * @param createIfNotExists 文件不存在时是否创建
     */
    public OpenFileRequest(String filePath, boolean createIfNotExists) {
        super(RequestType.OPEN_FILE);
        this.filePath = filePath;
        this.comment = "打开MF4文件: " + filePath;
        addParam("create_if_not_exists", createIfNotExists);
    }
    
    /**
     * 创建打开文件请求（带自定义注释）
     * 
     * @param filePath 文件路径
     * @param createIfNotExists 文件不存在时是否创建
     * @param comment 请求注释
     */
    public OpenFileRequest(String filePath, boolean createIfNotExists, String comment) {
        this(filePath, createIfNotExists);
        this.comment = comment;
    }
}
