package com.mdf4j;

import com.mdf4j.exception.Mdf4Exception;
import com.mdf4j.model.FileInfo;
import com.mdf4j.model.GroupInfo;
import com.mdf4j.model.SignalData;
import com.mdf4j.model.SignalInfo;
import com.mdf4j.request.AddSignalRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * MDF4J使用示例
 */
public class Mdf4Example {
    
    public static void main(String[] args) {
        // 创建客户端
        Mdf4Client client = new Mdf4Client();
        
        try {
            // 初始化客户端（自动启动Python服务）
            System.out.println("正在初始化MDF4客户端...");
            client.initialize();
            System.out.println("初始化完成！");
            
            // 示例1: 创建新文件并写入数据
            createAndWriteFile(client);
            
            // 示例2: 读取文件数据
            readFileData(client);
            
            // 示例3: 分段读取大数据
            readLargeFileData(client);
            
            // 示例4: 多线程操作
            multiThreadExample(client);
            
        } catch (Exception e) {
            System.err.println("发生错误: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 关闭客户端
            System.out.println("\n正在关闭客户端...");
            client.shutdown();
            System.out.println("客户端已关闭");
        }
    }
    
    /**
     * 示例1: 创建新文件并写入数据
     */
    private static void createAndWriteFile(Mdf4Client client) throws Mdf4Exception {
        System.out.println("\n=== 示例1: 创建新文件并写入数据 ===");
        
        String filePath = "/tmp/example1.mf4";
        
        // 创建新文件
        Mdf4File file = client.createFile(filePath);
        System.out.println("创建文件: " + filePath);
        
        // 添加Group
        int groupIndex = file.addGroup("SensorData");
        System.out.println("添加Group，索引: " + groupIndex);
        
        // 准备数据
        List<Double> temperatureData = new ArrayList<>();
        List<Double> pressureData = new ArrayList<>();
        List<Double> timestamps = new ArrayList<>();
        
        for (int i = 0; i < 1000; i++) {
            double t = i * 0.01;
            temperatureData.add(20 + 10 * Math.sin(t));
            pressureData.add(101.3 + 5 * Math.cos(t * 0.5));
            timestamps.add(t);
        }
        
        // 添加Signals
        file.addSignal(groupIndex, "Temperature", temperatureData, timestamps, 
                      "°C", AddSignalRequest.DuplicateMode.APPEND);
        System.out.println("添加Signal: Temperature (1000个数据点)");
        
        file.addSignal(groupIndex, "Pressure", pressureData, timestamps, 
                      "kPa", AddSignalRequest.DuplicateMode.APPEND);
        System.out.println("添加Signal: Pressure (1000个数据点)");
        
        // 保存文件
        file.save();
        System.out.println("文件保存成功");
        
        // 关闭文件
        file.close();
        System.out.println("文件已关闭");
    }
    
    /**
     * 示例2: 读取文件数据
     */
    private static void readFileData(Mdf4Client client) throws Mdf4Exception {
        System.out.println("\n=== 示例2: 读取文件数据 ===");
        
        String filePath = "/tmp/example1.mf4";
        
        // 打开文件
        Mdf4File file = client.openFile(filePath);
        System.out.println("打开文件: " + filePath);
        
        // 获取文件信息
        FileInfo fileInfo = file.getFileInfo();
        System.out.println("文件版本: " + fileInfo.getVersion());
        System.out.println("Group数量: " + fileInfo.getGroupsCount());
        
        // 获取所有Groups
        List<GroupInfo> groups = file.getAllGroups();
        for (GroupInfo group : groups) {
            System.out.println("\nGroup[" + group.getIndex() + "]:");
            System.out.println("  注释: " + group.getComment());
            System.out.println("  Channels: " + group.getChannelsCount());
            System.out.println("  Channel列表: " + group.getChannels());
        }
        
        // 获取Signal信息
        if (!groups.isEmpty()) {
            GroupInfo firstGroup = groups.get(0);
            for (String signalName : firstGroup.getChannels()) {
                SignalInfo signalInfo = file.getSignalInfo(firstGroup.getIndex(), signalName);
                System.out.println("\nSignal: " + signalName);
                System.out.println("  单位: " + signalInfo.getUnit());
                System.out.println("  样本数: " + signalInfo.getSamplesCount());
                System.out.println("  注释: " + signalInfo.getComment());
            }
        }
        
        file.close();
    }
    
    /**
     * 示例3: 分段读取大数据
     */
    private static void readLargeFileData(Mdf4Client client) throws Mdf4Exception {
        System.out.println("\n=== 示例3: 分段读取大数据 ===");
        
        String filePath = "/tmp/example1.mf4";
        
        Mdf4File file = client.openFile(filePath);
        
        List<GroupInfo> groups = file.getAllGroups();
        if (groups.isEmpty()) {
            System.out.println("没有Group数据");
            file.close();
            return;
        }
        
        int groupIndex = groups.get(0).getIndex();
        String signalName = "Temperature";
        
        // 方法1: 分段读取
        System.out.println("\n方法1: 分段读取（每页100个数据点）");
        int offset = 0;
        int pageSize = 100;
        int pageCount = 0;
        
        while (true) {
            SignalData data = file.getSignalData(groupIndex, signalName, offset, pageSize);
            if (data == null) break;
            
            pageCount++;
            System.out.println("  页" + pageCount + ": offset=" + offset + 
                             ", count=" + data.getReturnedCount() + 
                             ", hasMore=" + data.isHasMore());
            
            // 处理数据...
            List<Double> values = data.getData();
            List<Double> times = data.getTimestamps();
            
            if (!data.isHasMore()) break;
            offset = data.getNextOffset();
        }
        
        // 方法2: 一次性读取所有数据
        System.out.println("\n方法2: 一次性读取所有数据");
        SignalData allData = file.getSignalDataAll(groupIndex, signalName, 200);
        if (allData != null) {
            System.out.println("  总数据点数: " + allData.getReturnedCount());
            System.out.println("  时间范围: " + allData.getTimestamps().get(0) + 
                             " ~ " + allData.getTimestamps().get(allData.getTimestamps().size() - 1));
        }
        
        file.close();
    }
    
    /**
     * 示例4: 多线程操作
     */
    private static void multiThreadExample(Mdf4Client client) throws Exception {
        System.out.println("\n=== 示例4: 多线程操作 ===");
        
        final String filePath1 = "/tmp/thread1.mf4";
        final String filePath2 = "/tmp/thread2.mf4";
        
        // 创建两个文件
        final Mdf4File file1 = client.createFile(filePath1);
        final Mdf4File file2 = client.createFile(filePath2);
        
        // 线程1: 操作文件1
        Thread thread1 = new Thread(() -> {
            try {
                System.out.println("[线程1] 开始操作文件1");
                
                int groupIndex = file1.addGroup("Thread1Group");
                
                List<Double> data = new ArrayList<>();
                List<Double> timestamps = new ArrayList<>();
                for (int i = 0; i < 500; i++) {
                    data.add(Math.sin(i * 0.1));
                    timestamps.add(i * 0.01);
                }
                
                file1.addSignal(groupIndex, "SineWave", data, timestamps, "V", 
                               AddSignalRequest.DuplicateMode.APPEND);
                file1.save();
                
                System.out.println("[线程1] 文件1操作完成");
            } catch (Mdf4Exception e) {
                System.err.println("[线程1] 错误: " + e.getMessage());
            }
        }, "Worker-1");
        
        // 线程2: 操作文件2
        Thread thread2 = new Thread(() -> {
            try {
                System.out.println("[线程2] 开始操作文件2");
                
                int groupIndex = file2.addGroup("Thread2Group");
                
                List<Double> data = new ArrayList<>();
                List<Double> timestamps = new ArrayList<>();
                for (int i = 0; i < 500; i++) {
                    data.add(Math.cos(i * 0.1));
                    timestamps.add(i * 0.01);
                }
                
                file2.addSignal(groupIndex, "CosWave", data, timestamps, "V", 
                               AddSignalRequest.DuplicateMode.APPEND);
                file2.save();
                
                System.out.println("[线程2] 文件2操作完成");
            } catch (Mdf4Exception e) {
                System.err.println("[线程2] 错误: " + e.getMessage());
            }
        }, "Worker-2");
        
        // 启动线程
        long startTime = System.currentTimeMillis();
        thread1.start();
        thread2.start();
        
        // 等待线程完成
        thread1.join();
        thread2.join();
        
        long elapsed = System.currentTimeMillis() - startTime;
        System.out.println("多线程操作完成，耗时: " + elapsed + "ms");
        
        file1.close();
        file2.close();
    }
}
