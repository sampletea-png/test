# 汽车数据实时记录系统 V3 (JavaFX + 实时绘图)

基于Java的实时汽车数据记录工具，支持多种存储格式和实时数据可视化。

## 新特性

### 1. 直接从内存写入MDF4
- 不再生成CSV临时文件
- 数据先存入内存缓冲区
- 关闭时一次性转换为MDF4格式

### 2. 实时数据绘图
- 支持连续数据曲线显示
- 可切换显示的信号
- 每个信号独立颜色
- 自动滚动显示最新数据

### 3. 可插拔前端架构
- 支持JavaFX前端
- 预留Web前端接口
- 易于扩展新的前端实现

## 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                      Java 应用程序                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ 数据模拟器    │  │  数据缓冲区   │  │  数据记录服务    │  │
│  │ (100Hz)      │──▶│ (环形缓冲)   │──▶│  - 格式管理      │  │
│  └──────────────┘  └──────────────┘  │  - 存储切换      │  │
│                           │          └────────┬─────────┘  │
│                           │                   │            │
│                           ▼                   ▼            │
│                  ┌─────────────────┐  ┌─────────────────┐  │
│                  │  JavaFX前端     │  │  存储实现        │  │
│                  │  - 实时数据显示  │  │  - CSV (原生)   │  │
│                  │  - 曲线图       │  │  - JSON (原生)  │  │
│                  │  - 信号选择     │  │  - SQLite (原生)│  │
│                  └─────────────────┘  │  - MDF4 (Python)│  │
│                                       └─────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 功能特性

### 存储格式

| 格式 | 实现方式 | 特点 |
|------|----------|------|
| **CSV** | Java原生 | 通用格式，易读易处理 |
| **JSON** | Java原生 | 结构化数据，Web友好 |
| **SQLite** | Java原生 | 关系型数据库，支持SQL查询 |
| **MDF4** | Java+Python | ASAM标准，直接从内存写入 |

### 实时绘图

- **多信号显示**：同时显示多个信号的曲线
- **信号选择**：可自由切换显示的信号
- **颜色区分**：每个信号有独立的颜色
- **自动滚动**：自动显示最新数据点
- **数据点限制**：限制显示的数据点数量，保证性能

### 前端架构

```
FrontendInterface (前端接口)
    │
    ├── JavaFXFrontend (JavaFX实现)
    │
    └── WebFrontend (预留Web实现接口)
```

## 环境要求

### Java环境
- **JDK**: 17 或更高版本
- **Maven**: 3.6+

### Python环境（仅MDF4格式需要）
- **Python**: 3.8+
- **asammdf**: `pip install asammdf numpy`

## 快速开始

### 1. 编译项目

```bash
cd java
mvn clean package
cd ..
```

### 2. 运行应用

```bash
# 使用Maven JavaFX插件
mvn javafx:run

# 或直接运行JAR
java -jar java/target/automotive-data-logger-3.0.0.jar
```

### 3. 使用界面

1. 从下拉框选择存储格式
2. 在右侧选择要显示的信号
3. 点击 **"开始记录"** 按钮
4. 观察实时数据和曲线图
5. 可随时切换格式或信号
6. 点击 **"停止记录"** 结束

## 项目结构

```
automotive_data_logger_v3/
├── README.md
├── java/
│   ├── pom.xml
│   └── src/main/java/com/automotive/logger/
│       ├── VehicleDataLoggerApp.java      # 主应用
│       ├── model/
│       │   └── VehicleData.java
│       ├── service/
│       │   ├── DataSimulatorService.java
│       │   └── DataLoggerService.java
│       ├── storage/                        # 存储模块
│       │   ├── StorageInterface.java
│       │   ├── StorageConfig.java
│       │   ├── StorageFactory.java
│       │   ├── BaseStorage.java
│       │   ├── CsvStorage.java
│       │   ├── JsonStorage.java
│       │   ├── SqliteStorage.java
│       │   └── Mdf4Storage.java            # 优化版，直接内存写入
│       ├── data/                           # 数据管理
│       │   └── DataBuffer.java             # 数据缓冲区
│       ├── frontend/                       # 前端接口
│       │   ├── FrontendInterface.java
│       │   └── javafx/
│       │       └── JavaFXFrontend.java     # JavaFX实现
│       └── gui/                            # 图表组件
│           └── RealtimeChart.java
└── python/
    ├── mdf4_writer.py                      # 优化版，从JSON写入
    └── requirements.txt
```

## 扩展新的前端

实现 `FrontendInterface` 接口：

```java
public class WebFrontend implements FrontendInterface {
    
    @Override
    public void initialize() {
        // 初始化Web服务器和页面
    }
    
    @Override
    public void updateRealtimeData(VehicleData data) {
        // 通过WebSocket发送数据
    }
    
    @Override
    public void updateChartData(List<VehicleData> dataList) {
        // 更新图表数据
    }
    
    // ... 其他方法
}
```

## 扩展新的存储格式

实现 `StorageInterface` 接口：

```java
public class MyFormatStorage extends BaseStorage {
    
    @Override
    public String getFormatName() { return "myformat"; }
    
    @Override
    protected void doOpen(Path filePath) { ... }
    
    @Override
    protected void doWrite(VehicleData data) { ... }
    
    // ... 其他方法
}
```

## 配置选项

```java
StorageConfig config = new StorageConfig();
config.setOutputDir(Paths.get("output"));
config.setFilenamePrefix("vehicle_data");
config.setBatchSize(100);
config.setMaxFileSizeMb(100);
config.setSplitIntervalMinutes(60);
```

## 信号列表

| 信号名 | 显示名称 | 单位 |
|--------|----------|------|
| vehicleSpeed | 车速 | km/h |
| engineRpm | 发动机转速 | RPM |
| engineTemp | 发动机温度 | °C |
| throttlePosition | 油门位置 | % |
| brakePosition | 刹车位置 | % |
| steeringAngle | 方向盘角度 | ° |
| batteryVoltage | 电池电压 | V |
| fuelLevel | 燃油液位 | % |
| accelX | 横向加速度 | m/s² |
| accelY | 纵向加速度 | m/s² |
| accelZ | 垂直加速度 | m/s² |

## 许可证

MIT License
