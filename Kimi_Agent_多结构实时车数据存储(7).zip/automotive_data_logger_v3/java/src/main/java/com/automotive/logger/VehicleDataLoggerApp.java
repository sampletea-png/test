package com.automotive.logger;

import com.automotive.logger.data.DataBuffer;
import com.automotive.logger.frontend.FrontendInterface;
import com.automotive.logger.frontend.javafx.JavaFXFrontend;
import com.automotive.logger.model.VehicleData;
import com.automotive.logger.service.DataLoggerService;
import com.automotive.logger.service.DataSimulatorService;
import com.automotive.logger.storage.StorageFactory;

import javafx.application.Application;
import javafx.application.Platform;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 车辆数据记录器主应用
 * 整合数据模拟、存储和前端展示
 */
public class VehicleDataLoggerApp implements FrontendInterface.FrontendStatusListener {
    
    private DataSimulatorService dataSimulator;
    private DataLoggerService dataLogger;
    private DataBuffer dataBuffer;
    private FrontendInterface frontend;
    
    // 记录状态
    private final AtomicBoolean isRecording = new AtomicBoolean(false);
    private final AtomicLong recordStartTime = new AtomicLong(0);
    
    // UI更新定时器
    private ScheduledExecutorService uiUpdateExecutor;
    
    public VehicleDataLoggerApp() {
        this.dataSimulator = new DataSimulatorService();
        this.dataLogger = new DataLoggerService();
        this.dataBuffer = new DataBuffer(false);
    }
    
    /**
     * 启动应用
     */
    public void start() {
        // 设置数据管道
        setupDataPipeline();
        
        // 启动JavaFX前端
        startJavaFXFrontend();
    }
    
    /**
     * 设置数据管道
     */
    private void setupDataPipeline() {
        // 数据模拟器 -> 数据缓冲区
        dataSimulator.addDataListener(data -> {
            dataBuffer.addData(data);
        });
        
        // 数据模拟器 -> 数据记录器（仅在记录时）
        dataSimulator.addDataListener(data -> {
            if (isRecording.get()) {
                try {
                    dataLogger.write(data);
                } catch (IOException e) {
                    System.err.println("写入数据失败: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * 启动JavaFX前端
     */
    private void startJavaFXFrontend() {
        // 在JavaFX启动前设置回调
        JavaFXFrontend.setAppInitializer(frontend -> {
            this.frontend = frontend;
            
            // 设置数据缓冲区
            if (frontend instanceof JavaFXFrontend) {
                ((JavaFXFrontend) frontend).setDataBuffer(dataBuffer);
            }
            
            // 设置可用格式
            List<String> formats = dataLogger.getAvailableFormats();
            if (frontend instanceof JavaFXFrontend) {
                ((JavaFXFrontend) frontend).setAvailableFormats(formats);
            }
            
            // 添加状态监听器
            frontend.addStatusListener(this);
        });
        
        // 启动JavaFX
        Application.launch(JavaFXFrontend.class);
    }
    
    @Override
    public void onStartRecording(String format) {
        if (isRecording.compareAndSet(false, true)) {
            try {
                // 启动数据模拟器
                if (!dataSimulator.isRunning()) {
                    dataSimulator.start();
                }
                
                // 启动数据记录
                boolean success = dataLogger.startRecording(format);
                
                if (success) {
                    recordStartTime.set(System.currentTimeMillis());
                    
                    // 更新前端状态
                    frontend.setRecordingState(true);
                    
                    // 启动记录时长更新
                    startRecordTimeUpdate();
                    
                    System.out.println("开始记录数据，格式: " + format);
                } else {
                    isRecording.set(false);
                    frontend.showMessage("开始记录失败", FrontendInterface.MessageType.ERROR);
                }
            } catch (IOException e) {
                isRecording.set(false);
                frontend.showMessage("开始记录失败: " + e.getMessage(), 
                    FrontendInterface.MessageType.ERROR);
            }
        }
    }
    
    @Override
    public void onStopRecording() {
        if (isRecording.compareAndSet(true, false)) {
            try {
                // 停止数据记录
                dataLogger.stopRecording();
                
                // 停止时长更新
                stopRecordTimeUpdate();
                
                // 更新前端状态
                frontend.setRecordingState(false);
                
                System.out.println("停止记录数据");
            } catch (IOException e) {
                frontend.showMessage("停止记录失败: " + e.getMessage(), 
                    FrontendInterface.MessageType.ERROR);
            }
        }
    }
    
    @Override
    public void onSwitchFormat(String newFormat) {
        try {
            boolean success = dataLogger.switchFormat(newFormat);
            if (success) {
                frontend.showMessage("已切换到格式: " + newFormat, 
                    FrontendInterface.MessageType.INFO);
            }
        } catch (IOException e) {
            frontend.showMessage("格式切换失败: " + e.getMessage(), 
                FrontendInterface.MessageType.ERROR);
        }
    }
    
    @Override
    public void onSignalSelectionChanged(List<String> selectedSignals) {
        // 更新数据缓冲区的信号选择
        dataBuffer.setSelectedSignals(selectedSignals);
    }
    
    @Override
    public void onTimeRangeChanged(long startTime, long endTime) {
        // 处理时间范围变化（用于回放功能）
    }
    
    /**
     * 启动记录时长更新
     */
    private void startRecordTimeUpdate() {
        uiUpdateExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "RecordTimeUpdater");
            t.setDaemon(true);
            return t;
        });
        
        uiUpdateExecutor.scheduleAtFixedRate(() -> {
            long elapsed = System.currentTimeMillis() - recordStartTime.get();
            String timeStr = formatDuration(elapsed);
            
            if (frontend instanceof JavaFXFrontend) {
                ((JavaFXFrontend) frontend).updateRecordTime(timeStr);
            }
        }, 0, 100, TimeUnit.MILLISECONDS);
    }
    
    /**
     * 停止记录时长更新
     */
    private void stopRecordTimeUpdate() {
        if (uiUpdateExecutor != null) {
            uiUpdateExecutor.shutdown();
            uiUpdateExecutor = null;
        }
    }
    
    /**
     * 格式化时长
     */
    private String formatDuration(long millis) {
        long hours = millis / 3600000;
        long minutes = (millis % 3600000) / 60000;
        long seconds = (millis % 60000) / 1000;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
    
    /**
     * 关闭应用
     */
    public void shutdown() {
        // 停止记录
        if (isRecording.get()) {
            try {
                dataLogger.stopRecording();
            } catch (IOException e) {
                System.err.println("停止记录失败: " + e.getMessage());
            }
        }
        
        // 停止数据模拟
        dataSimulator.stop();
        
        // 停止UI更新
        stopRecordTimeUpdate();
        
        System.out.println("应用已关闭");
    }
    
    /**
     * 主入口
     */
    public static void main(String[] args) {
        VehicleDataLoggerApp app = new VehicleDataLoggerApp();
        
        // 添加关闭钩子
        Runtime.getRuntime().addShutdownHook(new Thread(app::shutdown));
        
        // 启动应用
        app.start();
    }
}
