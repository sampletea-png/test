package com.automotive.logger.storage;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * 存储配置类
 */
public class StorageConfig {
    
    // 输出目录
    private Path outputDir = Paths.get("output");
    
    // 文件名前缀
    private String filenamePrefix = "vehicle_data";
    
    // 批量写入大小
    private int batchSize = 100;
    
    // 是否追加模式
    private boolean appendMode = false;
    
    // 文件大小限制（MB），超过时创建新文件
    private double maxFileSizeMb = 100.0;
    
    // 时间分割间隔（分钟），0表示不分割
    private int splitIntervalMinutes = 0;
    
    // 压缩选项（gzip, bz2, null）
    private String compression = null;
    
    // 格式特定选项
    private Map<String, Object> options = new HashMap<>();
    
    // 元数据
    private Map<String, String> metadata = new HashMap<>();
    
    // 时间格式
    private static final DateTimeFormatter TIME_FORMATTER = 
        DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    
    public StorageConfig() {}
    
    public StorageConfig(Path outputDir, String filenamePrefix) {
        this.outputDir = outputDir;
        this.filenamePrefix = filenamePrefix;
    }
    
    /**
     * 生成完整文件名
     */
    public String generateFilename(String extension) {
        String timeStr = LocalDateTime.now().format(TIME_FORMATTER);
        return filenamePrefix + "_" + timeStr + "." + extension;
    }
    
    /**
     * 获取完整输出路径
     */
    public Path getOutputPath(String extension) {
        java.io.File dir = outputDir.toFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return outputDir.resolve(generateFilename(extension));
    }
    
    // Getters and Setters
    public Path getOutputDir() { return outputDir; }
    public void setOutputDir(Path outputDir) { this.outputDir = outputDir; }
    
    public String getFilenamePrefix() { return filenamePrefix; }
    public void setFilenamePrefix(String filenamePrefix) { this.filenamePrefix = filenamePrefix; }
    
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    
    public boolean isAppendMode() { return appendMode; }
    public void setAppendMode(boolean appendMode) { this.appendMode = appendMode; }
    
    public double getMaxFileSizeMb() { return maxFileSizeMb; }
    public void setMaxFileSizeMb(double maxFileSizeMb) { this.maxFileSizeMb = maxFileSizeMb; }
    
    public int getSplitIntervalMinutes() { return splitIntervalMinutes; }
    public void setSplitIntervalMinutes(int splitIntervalMinutes) { this.splitIntervalMinutes = splitIntervalMinutes; }
    
    public String getCompression() { return compression; }
    public void setCompression(String compression) { this.compression = compression; }
    
    public Map<String, Object> getOptions() { return options; }
    public void setOptions(Map<String, Object> options) { this.options = options; }
    
    public Map<String, String> getMetadata() { return metadata; }
    public void setMetadata(Map<String, String> metadata) { this.metadata = metadata; }
    
    public Object getOption(String key) {
        return options.get(key);
    }
    
    public void setOption(String key, Object value) {
        options.put(key, value);
    }
}
