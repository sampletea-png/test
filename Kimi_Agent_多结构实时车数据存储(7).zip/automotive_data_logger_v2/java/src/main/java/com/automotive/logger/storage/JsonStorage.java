package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.GZIPOutputStream;

/**
 * JSON存储格式实现
 * 支持JSON Lines格式和JSON Array格式
 */
public class JsonStorage extends BaseStorage {
    
    private final Gson gson;
    private BufferedWriter writer;
    private boolean isFirstRecord = true;
    private final String format; // "lines" 或 "array"
    
    public JsonStorage(StorageConfig config) {
        super(config);
        this.gson = new GsonBuilder()
            .setPrettyPrinting()
            .create();
        
        // 获取格式选项，默认为lines
        Object formatOption = config.getOption("format");
        this.format = formatOption != null ? formatOption.toString() : "lines";
    }
    
    @Override
    public String getFormatName() {
        return "json";
    }
    
    @Override
    public String getFileExtension() {
        return "json";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        filePath.getParent().toFile().mkdirs();
        
        boolean fileExists = filePath.toFile().exists() && filePath.toFile().length() > 0;
        isFirstRecord = !fileExists || !config.isAppendMode();
        
        OutputStream os = new FileOutputStream(filePath.toFile(), config.isAppendMode());
        
        if ("gzip".equals(config.getCompression())) {
            os = new GZIPOutputStream(os);
            currentFilePath = filePath.resolveSibling(filePath.getFileName() + ".gz");
        } else {
            currentFilePath = filePath;
        }
        
        writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        
        // array格式：写入数组开始
        if ("array".equals(format) && isFirstRecord) {
            writer.write("[\n");
        }
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        String json = gson.toJson(data);
        
        if ("lines".equals(format)) {
            // JSON Lines格式
            writer.write(json);
            writer.newLine();
        } else {
            // JSON Array格式
            if (!isFirstRecord) {
                writer.write(",\n");
            }
            writer.write(json);
            isFirstRecord = false;
        }
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        for (VehicleData data : dataList) {
            doWrite(data);
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (writer != null) {
            // array格式：写入数组结束
            if ("array".equals(format)) {
                writer.write("\n]\n");
            }
            
            writer.flush();
            writer.close();
            writer = null;
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            return currentFilePath.toFile().length();
        }
        return 0;
    }
}
