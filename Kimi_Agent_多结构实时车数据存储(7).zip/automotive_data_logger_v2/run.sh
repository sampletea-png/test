#!/bin/bash

# 汽车数据记录系统启动脚本 (Java为主版本)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JAR_FILE="$SCRIPT_DIR/java/target/automotive-data-logger-2.0.0.jar"

echo "========================================"
echo "  汽车数据实时记录系统 (Java为主)"
echo "========================================"
echo ""

# 检查Java
if ! command -v java &> /dev/null; then
    echo "错误: 未找到Java"
    exit 1
fi

# 检查Maven
if ! command -v mvn &> /dev/null; then
    echo "错误: 未找到Maven"
    exit 1
fi

# 编译（如果需要）
if [ ! -f "$JAR_FILE" ]; then
    echo "编译Java项目..."
    cd "$SCRIPT_DIR/java"
    mvn clean package -q
    cd "$SCRIPT_DIR"
fi

# 检查Python（仅MDF4格式需要）
if command -v python3 &> /dev/null; then
    if python3 -c "import asammdf" 2>/dev/null; then
        echo "✓ Python asammdf已安装，MDF4格式可用"
    else
        echo "ℹ Python asammdf未安装，MDF4格式不可用"
        echo "  如需MDF4支持，请运行: pip3 install asammdf numpy"
    fi
else
    echo "ℹ Python未安装，MDF4格式不可用"
fi

echo ""
echo "启动应用..."
echo ""

java -jar "$JAR_FILE"
