#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
存储接口基类 - 定义所有存储格式的通用接口
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
import logging

logger = logging.getLogger(__name__)


@dataclass
class StorageConfig:
    """存储配置类"""
    # 输出目录
    output_dir: str = "output"
    
    # 文件名前缀
    filename_prefix: str = "vehicle_data"
    
    # 文件扩展名（由具体存储格式决定）
    file_extension: str = ""
    
    # 批量写入大小
    batch_size: int = 100
    
    # 是否追加到现有文件
    append_mode: bool = False
    
    # 文件大小限制（MB），超过时创建新文件
    max_file_size_mb: float = 100.0
    
    # 时间分割间隔（分钟），0表示不分割
    split_interval_minutes: int = 0
    
    # 压缩选项
    compression: Optional[str] = None  # 'gzip', 'bz2', 'lz4', None
    
    # 格式特定选项
    options: Dict[str, Any] = field(default_factory=dict)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_full_filename(self, timestamp: Optional[datetime] = None) -> str:
        """生成完整文件名"""
        if timestamp is None:
            timestamp = datetime.now()
        
        time_str = timestamp.strftime("%Y%m%d_%H%M%S")
        ext = self.file_extension.lstrip('.')
        return f"{self.filename_prefix}_{time_str}.{ext}"
    
    def get_output_path(self, timestamp: Optional[datetime] = None) -> Path:
        """获取完整输出路径"""
        output_path = Path(self.output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        return output_path / self.get_full_filename(timestamp)


@dataclass
class StorageInfo:
    """存储信息/统计"""
    format_name: str = ""
    file_path: Optional[Path] = None
    is_open: bool = False
    record_count: int = 0
    file_size_bytes: int = 0
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration_seconds: float = 0.0
    write_rate: float = 0.0  # 条/秒
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'format_name': self.format_name,
            'file_path': str(self.file_path) if self.file_path else None,
            'is_open': self.is_open,
            'record_count': self.record_count,
            'file_size_bytes': self.file_size_bytes,
            'file_size_mb': round(self.file_size_bytes / (1024 * 1024), 2),
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration_seconds': round(self.duration_seconds, 2),
            'write_rate': round(self.write_rate, 2),
            'errors': self.errors
        }


class StorageInterface(ABC):
    """
    存储接口基类
    所有存储格式必须实现此接口
    """
    
    # 格式名称（子类必须覆盖）
    FORMAT_NAME: str = "base"
    
    # 默认文件扩展名（子类必须覆盖）
    DEFAULT_EXTENSION: str = ""
    
    # 是否支持追加模式
    SUPPORTS_APPEND: bool = False
    
    # 是否支持压缩
    SUPPORTS_COMPRESSION: bool = False
    
    def __init__(self, config: Optional[StorageConfig] = None):
        """
        初始化存储器
        
        Args:
            config: 存储配置，如果为None则使用默认配置
        """
        self.config = config or StorageConfig()
        self.config.file_extension = self.DEFAULT_EXTENSION
        
        self._info = StorageInfo(format_name=self.FORMAT_NAME)
        self._data_buffer: List[Dict[str, Any]] = []
        self._last_write_time: Optional[datetime] = None
        self._write_count: int = 0
        self._start_time: Optional[datetime] = None
        
        # 状态回调
        self._status_callbacks: List[Callable[[StorageInfo], None]] = []
        
        logger.debug(f"{self.FORMAT_NAME}存储器已初始化")
    
    # ==================== 抽象方法 ====================
    
    @abstractmethod
    def open(self, file_path: Optional[Path] = None) -> bool:
        """
        打开/创建存储文件
        
        Args:
            file_path: 文件路径，如果为None则自动生成
            
        Returns:
            是否成功
        """
        pass
    
    @abstractmethod
    def write(self, data: Dict[str, Any]) -> bool:
        """
        写入单条数据
        
        Args:
            data: 数据字典
            
        Returns:
            是否成功
        """
        pass
    
    @abstractmethod
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """
        批量写入数据
        
        Args:
            data_list: 数据列表
            
        Returns:
            是否成功
        """
        pass
    
    @abstractmethod
    def close(self) -> bool:
        """
        关闭存储文件
        
        Returns:
            是否成功
        """
        pass
    
    @abstractmethod
    def get_file_size(self) -> int:
        """获取当前文件大小（字节）"""
        pass
    
    # ==================== 通用方法 ====================
    
    def add_data(self, data: Dict[str, Any]) -> bool:
        """
        添加数据到缓冲区，达到批量大小时自动写入
        
        Args:
            data: 数据字典
            
        Returns:
            是否成功
        """
        if not self._info.is_open:
            logger.error("存储器未打开")
            return False
        
        # 检查是否需要分割文件
        if self._should_split_file():
            self._split_file()
        
        # 添加到缓冲区
        self._data_buffer.append(data)
        
        # 达到批量大小则写入
        if len(self._data_buffer) >= self.config.batch_size:
            return self._flush_buffer()
        
        return True
    
    def flush(self) -> bool:
        """强制刷新缓冲区"""
        return self._flush_buffer()
    
    def get_info(self) -> StorageInfo:
        """获取存储信息"""
        self._update_info()
        return self._info
    
    def add_status_callback(self, callback: Callable[[StorageInfo], None]):
        """添加状态回调函数"""
        self._status_callbacks.append(callback)
    
    def remove_status_callback(self, callback: Callable[[StorageInfo], None]):
        """移除状态回调函数"""
        if callback in self._status_callbacks:
            self._status_callbacks.remove(callback)
    
    # ==================== 内部方法 ====================
    
    def _flush_buffer(self) -> bool:
        """刷新缓冲区到存储"""
        if not self._data_buffer:
            return True
        
        try:
            success = self.write_batch(self._data_buffer)
            if success:
                self._write_count += len(self._data_buffer)
                self._data_buffer.clear()
                self._last_write_time = datetime.now()
                self._notify_status_change()
            return success
        except Exception as e:
            logger.error(f"刷新缓冲区失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def _should_split_file(self) -> bool:
        """检查是否需要分割文件"""
        # 检查文件大小
        if self.config.max_file_size_mb > 0:
            current_size_mb = self.get_file_size() / (1024 * 1024)
            if current_size_mb >= self.config.max_file_size_mb:
                return True
        
        # 检查时间间隔
        if self.config.split_interval_minutes > 0 and self._start_time:
            elapsed = (datetime.now() - self._start_time).total_seconds() / 60
            if elapsed >= self.config.split_interval_minutes:
                return True
        
        return False
    
    def _split_file(self) -> bool:
        """分割文件 - 关闭当前文件并创建新文件"""
        logger.info("分割文件...")
        
        # 刷新缓冲区
        self._flush_buffer()
        
        # 关闭当前文件
        self.close()
        
        # 创建新文件
        return self.open()
    
    def _update_info(self):
        """更新存储信息"""
        self._info.file_size_bytes = self.get_file_size()
        
        if self._start_time:
            self._info.duration_seconds = (datetime.now() - self._start_time).total_seconds()
            if self._info.duration_seconds > 0:
                self._info.write_rate = self._info.record_count / self._info.duration_seconds
    
    def _notify_status_change(self):
        """通知状态变化"""
        self._update_info()
        for callback in self._status_callbacks:
            try:
                callback(self._info)
            except Exception as e:
                logger.error(f"状态回调执行失败: {e}")
    
    def _on_open(self, file_path: Path):
        """打开文件后的回调"""
        self._info.file_path = file_path
        self._info.is_open = True
        self._info.start_time = datetime.now()
        self._start_time = datetime.now()
        self._info.record_count = 0
        self._write_count = 0
        self._data_buffer.clear()
        logger.info(f"{self.FORMAT_NAME}文件已打开: {file_path}")
    
    def _on_close(self):
        """关闭文件后的回调"""
        self._flush_buffer()
        self._info.is_open = False
        self._info.end_time = datetime.now()
        self._update_info()
        logger.info(f"{self.FORMAT_NAME}文件已关闭: {self._info.file_path}")
        logger.info(f"  记录数: {self._info.record_count}, 文件大小: {self._info.file_size_mb:.2f} MB")
    
    def _on_write(self, count: int = 1):
        """写入数据后的回调"""
        self._info.record_count += count
        self._update_info()
    
    def __enter__(self):
        """上下文管理器入口"""
        self.open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False
