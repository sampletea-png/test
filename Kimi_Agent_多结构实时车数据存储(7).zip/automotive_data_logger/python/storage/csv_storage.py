#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CSV存储格式实现
支持标准CSV和压缩CSV
"""

import csv
import gzip
import bz2
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, TextIO, Union
import logging
import io

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)


class CSVStorage(StorageInterface):
    """
    CSV存储格式
    支持标准CSV、GZIP压缩、BZ2压缩
    """
    
    FORMAT_NAME = "csv"
    DEFAULT_EXTENSION = "csv"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = True
    
    # CSV字段定义
    FIELDNAMES = [
        'timestamp', 'can_channel', 'can_id',
        'vehicle_speed', 'engine_rpm', 'engine_temp',
        'throttle_position', 'brake_position', 'steering_angle',
        'battery_voltage', 'fuel_level', 'odometer',
        'accel_x', 'accel_y', 'accel_z'
    ]
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        self._file: Optional[TextIO] = None
        self._writer: Optional[csv.DictWriter] = None
        self._header_written: bool = False
        
        # 压缩处理
        self._compression = self.config.compression
        if self._compression and self._compression not in ['gzip', 'bz2']:
            logger.warning(f"不支持的压缩格式: {self._compression}，将使用无压缩")
            self._compression = None
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建CSV文件"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            # 确保目录存在
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 确定文件模式
            mode = 'a' if self.config.append_mode else 'w'
            
            # 检查文件是否存在
            file_exists = file_path.exists() and file_path.stat().st_size > 0
            
            # 根据压缩类型打开文件
            if self._compression == 'gzip':
                # GZIP压缩
                actual_path = file_path.with_suffix('.csv.gz')
                self._file = gzip.open(actual_path, f'{mode}t', newline='', encoding='utf-8')
                file_path = actual_path
                
            elif self._compression == 'bz2':
                # BZ2压缩
                actual_path = file_path.with_suffix('.csv.bz2')
                self._file = bz2.open(actual_path, f'{mode}t', newline='', encoding='utf-8')
                file_path = actual_path
                
            else:
                # 无压缩
                self._file = open(file_path, mode, newline='', encoding='utf-8')
            
            # 创建CSV写入器
            self._writer = csv.DictWriter(
                self._file,
                fieldnames=self.FIELDNAMES,
                extrasaction='ignore'  # 忽略未知字段
            )
            
            # 写入头部（如果是新文件）
            if not file_exists or not self.config.append_mode:
                self._writer.writeheader()
                self._header_written = True
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开CSV文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            if self._writer is None:
                logger.error("CSV写入器未初始化")
                return False
            
            # 确保所有字段都存在
            row = {field: data.get(field, '') for field in self.FIELDNAMES}
            
            self._writer.writerow(row)
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入CSV数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            if self._writer is None:
                logger.error("CSV写入器未初始化")
                return False
            
            # 写入所有数据
            for data in data_list:
                row = {field: data.get(field, '') for field in self.FIELDNAMES}
                self._writer.writerow(row)
            
            # 刷新到磁盘
            self._file.flush()
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入CSV失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭CSV文件"""
        try:
            if self._file is None:
                return True
            
            # 刷新缓冲区
            self._file.flush()
            
            # 关闭文件
            self._file.close()
            self._file = None
            self._writer = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭CSV文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
    
    def flush(self) -> bool:
        """强制刷新缓冲区到磁盘"""
        try:
            if self._file:
                self._file.flush()
            return True
        except Exception as e:
            logger.error(f"刷新CSV文件失败: {e}")
            return False
