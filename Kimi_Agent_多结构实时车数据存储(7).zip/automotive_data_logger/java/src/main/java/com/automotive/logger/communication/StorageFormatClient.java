package com.automotive.logger.communication;

import com.automotive.logger.model.VehicleData;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 多格式存储客户端
 * 支持动态切换存储格式（MDF4, CSV, JSON, SQLite, Parquet等）
 */
public class StorageFormatClient {
    
    private static final String DEFAULT_HOST = "localhost";
    private static final int DEFAULT_PORT = 9999;
    private static final int RECONNECT_DELAY_MS = 2000;
    private static final int SOCKET_TIMEOUT_MS = 5000;
    
    private final String host;
    private final int port;
    private final BlockingQueue<VehicleData> dataQueue;
    private final ExecutorService executor;
    private final AtomicBoolean connected;
    private final AtomicBoolean running;
    private final AtomicLong dataCount;
    private final Gson gson;
    
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    
    // 当前存储格式
    private volatile String currentFormat = "mdf4";
    private volatile List<String> availableFormats = new ArrayList<>();
    
    // 存储信息
    private volatile StorageInfo storageInfo = new StorageInfo();
    
    // 状态监听器
    private final List<StorageStatusListener> statusListeners = new CopyOnWriteArrayList<>();
    
    // 统计信息
    private volatile long lastSendTime = 0;
    private volatile double sendRate = 0.0;
    
    /**
     * 存储信息类
     */
    public static class StorageInfo {
        public String formatName = "";
        public String filePath = "";
        public boolean isOpen = false;
        public long recordCount = 0;
        public double fileSizeMb = 0.0;
        public double durationSeconds = 0.0;
        public double writeRate = 0.0;
        public List<String> errors = new ArrayList<>();
    }
    
    /**
     * 存储状态监听器接口
     */
    public interface StorageStatusListener {
        void onStatusChanged(StorageInfo info);
        void onFormatChanged(String newFormat, String filePath);
        void onConnectionChanged(boolean connected);
    }
    
    public StorageFormatClient() {
        this(DEFAULT_HOST, DEFAULT_PORT);
    }
    
    public StorageFormatClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.dataQueue = new LinkedBlockingQueue<>(10000);
        this.executor = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "StorageClient-" + r.hashCode());
            t.setDaemon(true);
            return t;
        });
        this.connected = new AtomicBoolean(false);
        this.running = new AtomicBoolean(false);
        this.dataCount = new AtomicLong(0);
        this.gson = new Gson();
    }
    
    /**
     * 添加状态监听器
     */
    public void addStatusListener(StorageStatusListener listener) {
        statusListeners.add(listener);
    }
    
    /**
     * 移除状态监听器
     */
    public void removeStatusListener(StorageStatusListener listener) {
        statusListeners.remove(listener);
    }
    
    /**
     * 启动客户端
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            executor.submit(this::connectionManager);
            executor.submit(this::dataSender);
            System.out.println("存储客户端已启动，目标: " + host + ":" + port);
        }
    }
    
    /**
     * 停止客户端
     */
    public void stop() {
        running.set(false);
        closeConnection();
        executor.shutdown();
        try {
            if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
        System.out.println("存储客户端已停止，共发送 " + dataCount.get() + " 条数据");
    }
    
    /**
     * 发送数据
     */
    public void sendData(VehicleData data) {
        if (data != null && running.get()) {
            dataQueue.offer(data);
        }
    }
    
    /**
     * 切换存储格式
     */
    public boolean switchFormat(String format) {
        if (!connected.get() || writer == null) {
            System.err.println("无法切换格式：未连接");
            return false;
        }
        
        try {
            // 发送格式切换命令
            writer.println("FORMAT:" + format);
            writer.flush();
            
            // 读取响应
            String response = reader.readLine();
            if (response != null) {
                JsonObject json = gson.fromJson(response, JsonObject.class);
                String status = json.get("status").getAsString();
                
                if ("OK".equals(status)) {
                    JsonObject data = json.getAsJsonObject("data");
                    this.currentFormat = format;
                    String newFile = data.has("new_file") ? data.get("new_file").getAsString() : "";
                    
                    // 通知监听器
                    for (StorageStatusListener listener : statusListeners) {
                        listener.onFormatChanged(format, newFile);
                    }
                    
                    System.out.println("已切换到格式: " + format + ", 文件: " + newFile);
                    return true;
                } else {
                    String message = json.getAsJsonObject("data").get("message").getAsString();
                    System.err.println("格式切换失败: " + message);
                }
            }
        } catch (Exception e) {
            System.err.println("格式切换异常: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * 获取可用格式列表
     */
    public List<String> getAvailableFormats() {
        return new ArrayList<>(availableFormats);
    }
    
    /**
     * 获取当前格式
     */
    public String getCurrentFormat() {
        return currentFormat;
    }
    
    /**
     * 获取存储信息
     */
    public StorageInfo getStorageInfo() {
        return storageInfo;
    }
    
    /**
     * 更新配置
     */
    public boolean updateConfig(Map<String, Object> config) {
        if (!connected.get() || writer == null) {
            return false;
        }
        
        try {
            String configJson = gson.toJson(config);
            writer.println("CONFIG:" + configJson);
            writer.flush();
            
            String response = reader.readLine();
            if (response != null) {
                JsonObject json = gson.fromJson(response, JsonObject.class);
                return "OK".equals(json.get("status").getAsString());
            }
        } catch (Exception e) {
            System.err.println("更新配置异常: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * 强制刷新缓冲区
     */
    public boolean flush() {
        if (!connected.get() || writer == null) {
            return false;
        }
        
        try {
            writer.println("FLUSH");
            writer.flush();
            
            String response = reader.readLine();
            if (response != null) {
                JsonObject json = gson.fromJson(response, JsonObject.class);
                return "OK".equals(json.get("status").getAsString());
            }
        } catch (Exception e) {
            System.err.println("刷新异常: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * 查询存储信息
     */
    public boolean queryInfo() {
        if (!connected.get() || writer == null) {
            return false;
        }
        
        try {
            writer.println("INFO");
            writer.flush();
            
            String response = reader.readLine();
            if (response != null) {
                JsonObject json = gson.fromJson(response, JsonObject.class);
                if ("OK".equals(json.get("status").getAsString())) {
                    JsonObject data = json.getAsJsonObject("data");
                    
                    // 更新可用格式
                    if (data.has("available_formats")) {
                        availableFormats.clear();
                        data.getAsJsonArray("available_formats").forEach(
                            e -> availableFormats.add(e.getAsString())
                        );
                    }
                    
                    // 更新存储信息
                    if (data.has("storage")) {
                        JsonObject storage = data.getAsJsonObject("storage");
                        storageInfo.formatName = storage.has("format_name") ? 
                            storage.get("format_name").getAsString() : "";
                        storageInfo.filePath = storage.has("file_path") ? 
                            storage.get("file_path").getAsString() : "";
                        storageInfo.isOpen = storage.has("is_open") && 
                            storage.get("is_open").getAsBoolean();
                        storageInfo.recordCount = storage.has("record_count") ? 
                            storage.get("record_count").getAsLong() : 0;
                        storageInfo.fileSizeMb = storage.has("file_size_mb") ? 
                            storage.get("file_size_mb").getAsDouble() : 0.0;
                    }
                    
                    return true;
                }
            }
        } catch (Exception e) {
            System.err.println("查询信息异常: " + e.getMessage());
        }
        
        return false;
    }
    
    // ==================== 内部方法 ====================
    
    private void connectionManager() {
        while (running.get()) {
            if (!connected.get()) {
                try {
                    connect();
                } catch (Exception e) {
                    System.err.println("连接服务失败: " + e.getMessage());
                }
            }
            
            try {
                Thread.sleep(RECONNECT_DELAY_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    private void connect() throws IOException {
        socket = new Socket(host, port);
        socket.setSoTimeout(SOCKET_TIMEOUT_MS);
        socket.setTcpNoDelay(true);
        
        writer = new PrintWriter(
            new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8),
            true
        );
        reader = new BufferedReader(
            new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)
        );
        
        // 读取就绪响应
        String response = reader.readLine();
        if (response != null) {
            JsonObject json = gson.fromJson(response, JsonObject.class);
            if ("READY".equals(json.get("status").getAsString())) {
                JsonObject data = json.getAsJsonObject("data");
                
                // 获取可用格式
                if (data.has("available_formats")) {
                    availableFormats.clear();
                    data.getAsJsonArray("available_formats").forEach(
                        e -> availableFormats.add(e.getAsString())
                    );
                }
                
                // 获取默认格式
                if (data.has("default_format")) {
                    currentFormat = data.get("default_format").getAsString();
                }
                
                connected.set(true);
                System.out.println("成功连接到存储服务");
                System.out.println("可用格式: " + availableFormats);
                
                // 通知监听器
                for (StorageStatusListener listener : statusListeners) {
                    listener.onConnectionChanged(true);
                }
                
                // 发送初始化命令
                initializeStorage();
            }
        }
    }
    
    private void initializeStorage() {
        try {
            writer.println("INIT:" + currentFormat);
            writer.flush();
            
            String response = reader.readLine();
            if (response != null) {
                JsonObject json = gson.fromJson(response, JsonObject.class);
                if ("READY".equals(json.get("status").getAsString())) {
                    JsonObject data = json.getAsJsonObject("data");
                    System.out.println("存储已初始化: " + data.get("format").getAsString());
                    
                    // 发送CSV头
                    writer.println("HEADER:" + VehicleData.getCsvHeader());
                    writer.flush();
                }
            }
        } catch (Exception e) {
            System.err.println("初始化存储失败: " + e.getMessage());
        }
    }
    
    private void closeConnection() {
        connected.set(false);
        
        if (writer != null) {
            writer.println("CLOSE");
            writer.close();
        }
        
        try {
            if (reader != null) reader.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            // 忽略
        }
        
        // 通知监听器
        for (StorageStatusListener listener : statusListeners) {
            listener.onConnectionChanged(false);
        }
        
        System.out.println("已断开与存储服务的连接");
    }
    
    private void dataSender() {
        while (running.get()) {
            try {
                if (connected.get()) {
                    VehicleData data = dataQueue.poll(100, TimeUnit.MILLISECONDS);
                    if (data != null) {
                        sendDataInternal(data);
                    }
                } else {
                    Thread.sleep(100);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("发送数据异常: " + e.getMessage());
                connected.set(false);
            }
        }
        
        flushRemainingData();
    }
    
    private void sendDataInternal(VehicleData data) {
        if (writer != null && !writer.checkError()) {
            String csvData = data.toCsvString();
            writer.println("DATA:" + csvData);
            
            long count = dataCount.incrementAndGet();
            long currentTime = System.currentTimeMillis();
            
            if (lastSendTime > 0) {
                double interval = (currentTime - lastSendTime) / 1000.0;
                if (interval > 0) {
                    sendRate = 1.0 / interval;
                }
            }
            lastSendTime = currentTime;
            
            if (count % 1000 == 0) {
                System.out.printf("已发送 %d 条数据，当前速率: %.1f 条/秒%n", count, sendRate);
            }
        } else {
            connected.set(false);
        }
    }
    
    private void flushRemainingData() {
        VehicleData data;
        while ((data = dataQueue.poll()) != null && connected.get()) {
            sendDataInternal(data);
        }
    }
    
    // ==================== Getter方法 ====================
    
    public boolean isConnected() {
        return connected.get();
    }
    
    public long getDataCount() {
        return dataCount.get();
    }
    
    public double getSendRate() {
        return sendRate;
    }
    
    public int getQueueSize() {
        return dataQueue.size();
    }
}
