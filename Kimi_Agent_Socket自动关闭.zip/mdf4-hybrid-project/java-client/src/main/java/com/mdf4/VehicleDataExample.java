package com.mdf4;

import java.util.List;

/**
 * VehicleDataExample - Demonstrates generating and processing vehicle data.
 * 
 * This example shows how to:
 * 1. Generate realistic vehicle sensor data
 * 2. Write data to MDF4 file
 * 3. Perform partial reads for analysis
 */
public class VehicleDataExample {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("Vehicle Data Simulation Example");
        System.out.println("========================================\n");
        
        // Create data simulator: 100 Hz sample rate, 40 seconds duration
        VehicleDataSimulator simulator = new VehicleDataSimulator(100.0, 40.0);
        
        System.out.println("Simulation Parameters:");
        System.out.println("  Sample Rate: " + simulator.getSampleRate() + " Hz");
        System.out.println("  Duration: " + simulator.getDuration() + " seconds");
        System.out.println("  Total Samples: " + simulator.getSampleCount());
        System.out.println();
        
        // Generate all channels
        System.out.println("Generating vehicle data...");
        List<ChannelData> channels = simulator.generateAllChannels();
        System.out.println("Generated " + channels.size() + " channels:");
        for (ChannelData ch : channels) {
            System.out.println("  - " + ch.getName() + " (" + ch.getUnit() + "): " + 
                    ch.getValues().size() + " samples");
        }
        System.out.println();
        
        // Connect to Python service and write data
        try (Mdf4Client client = new Mdf4Client("localhost", 25333)) {
            
            // Connect
            System.out.println("Connecting to Python service...");
            client.connect();
            System.out.println("✓ Connected\n");
            
            // Create and write to file
            String filePath = "vehicle_data.mf4";
            System.out.println("Creating MDF4 file: " + filePath);
            client.createNewFile(filePath);
            
            System.out.println("Writing channels...");
            boolean success = client.writeMultipleChannels(channels);
            if (!success) {
                System.err.println("✗ Failed to write channels");
                return;
            }
            System.out.println("✓ Written " + channels.size() + " channels\n");
            
            // Save file
            System.out.println("Saving file...");
            client.saveFile();
            System.out.println("✓ File saved\n");
            
            // Close and reopen for reading
            client.closeFile();
            System.out.println("Reopening file for reading...");
            client.openFile(filePath);
            System.out.println("✓ File opened\n");
            
            // Display file info
            System.out.println("File Information:");
            displayFileInfo(client);
            System.out.println();
            
            // Demonstrate partial reads
            System.out.println("========================================");
            System.out.println("Partial Read Demonstrations");
            System.out.println("========================================\n");
            
            // 1. Read acceleration phase only (5-15 seconds)
            System.out.println("1. Reading acceleration phase (5-15 seconds):");
            demonstratePhaseRead(client, "Acceleration", 5.0, 15.0);
            System.out.println();
            
            // 2. Read cruise phase only (15-25 seconds)
            System.out.println("2. Reading cruise phase (15-25 seconds):");
            demonstratePhaseRead(client, "Cruise", 15.0, 25.0);
            System.out.println();
            
            // 3. Read braking phase only (25-30 seconds)
            System.out.println("3. Reading braking phase (25-30 seconds):");
            demonstratePhaseRead(client, "Braking", 25.0, 30.0);
            System.out.println();
            
            // 4. Read specific channels for specific time
            System.out.println("4. Reading specific channels (EngineSpeed, VehicleSpeed) for 10-20s:");
            demonstrateSelectiveRead(client, 10.0, 20.0);
            System.out.println();
            
            // 5. Read by index range for detailed analysis
            System.out.println("5. Reading detailed segment (samples 500-599, 5.00-5.99s):");
            demonstrateDetailedSegmentRead(client, 500, 100);
            System.out.println();
            
            // 6. Analyze brake event
            System.out.println("6. Analyzing brake event:");
            demonstrateBrakeAnalysis(client);
            System.out.println();
            
            System.out.println("========================================");
            System.out.println("All demonstrations completed!");
            System.out.println("========================================");
            
        } catch (Mdf4Exception e) {
            System.err.println("\n✗ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Display file information
     */
    private static void displayFileInfo(Mdf4Client client) throws Mdf4Exception {
        List<String> names = client.getChannelNames();
        System.out.println("  Channels: " + names.size());
        
        double[] timeRange = client.getTimeRange();
        System.out.println("  Time Range: [" + String.format("%.2f", timeRange[0]) + 
                ", " + String.format("%.2f", timeRange[1]) + "] seconds");
        
        for (String name : names) {
            ChannelInfo info = client.getChannelInfo(name);
            if (info != null) {
                System.out.println("    - " + name + ": " + info.getSamplesCount() + 
                        " samples, " + String.format("%.1f", info.getAverageSampleRate()) + " Hz");
            }
        }
    }
    
    /**
     * Demonstrate reading a specific phase
     */
    private static void demonstratePhaseRead(Mdf4Client client, String phaseName, 
                                             double startTime, double endTime) throws Mdf4Exception {
        List<String> channels = client.getChannelNames();
        List<DataRecord> records = client.readChannelsPartial(channels, startTime, endTime);
        
        System.out.println("  Phase: " + phaseName);
        System.out.println("  Time Range: [" + startTime + ", " + endTime + "] seconds");
        System.out.println("  Channels read: " + records.size());
        
        for (DataRecord record : records) {
            List<Double> values = record.getValues();
            if (!values.isEmpty()) {
                double min = values.stream().mapToDouble(Double::doubleValue).min().orElse(0);
                double max = values.stream().mapToDouble(Double::doubleValue).max().orElse(0);
                double avg = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
                
                System.out.println("    " + record.getChannelName() + ":");
                System.out.println("      Samples: " + record.getSampleCount());
                System.out.println("      Min: " + String.format("%.2f", min) + " " + record.getUnit());
                System.out.println("      Max: " + String.format("%.2f", max) + " " + record.getUnit());
                System.out.println("      Avg: " + String.format("%.2f", avg) + " " + record.getUnit());
            }
        }
    }
    
    /**
     * Demonstrate selective channel reading
     */
    private static void demonstrateSelectiveRead(Mdf4Client client, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        List<String> selectedChannels = List.of("EngineSpeed", "VehicleSpeed");
        List<DataRecord> records = client.readChannelsPartial(selectedChannels, startTime, endTime);
        
        System.out.println("  Selected channels: " + selectedChannels);
        System.out.println("  Time Range: [" + startTime + ", " + endTime + "] seconds");
        
        for (DataRecord record : records) {
            System.out.println("  " + record.getChannelName() + ":");
            System.out.println("    Samples: " + record.getSampleCount());
            System.out.println("    Time range: [" + 
                    String.format("%.2f", record.getStartTime()) + ", " +
                    String.format("%.2f", record.getEndTime()) + "] seconds");
        }
    }
    
    /**
     * Demonstrate reading a detailed segment by index
     */
    private static void demonstrateDetailedSegmentRead(Mdf4Client client, 
                                                       int startIndex, int count) throws Mdf4Exception {
        DataRecord record = client.readChannelPartial("EngineSpeed", startIndex, count);
        
        if (record != null) {
            System.out.println("  Channel: " + record.getChannelName());
            System.out.println("  Index Range: [" + startIndex + ", " + (startIndex + count - 1) + "]");
            System.out.println("  Time Range: [" + 
                    String.format("%.3f", record.getStartTime()) + ", " +
                    String.format("%.3f", record.getEndTime()) + "] seconds");
            System.out.println("  First 10 values:");
            
            List<Double> values = record.getValues();
            List<Double> timestamps = record.getTimestamps();
            
            for (int i = 0; i < Math.min(10, values.size()); i++) {
                System.out.println("    t=" + String.format("%.3f", timestamps.get(i)) + 
                        "s: " + String.format("%.1f", values.get(i)) + " " + record.getUnit());
            }
        }
    }
    
    /**
     * Demonstrate brake event analysis
     */
    private static void demonstrateBrakeAnalysis(Mdf4Client client) throws Mdf4Exception {
        // Read brake phase (25-30 seconds)
        List<String> channels = List.of("BrakePressure", "VehicleSpeed");
        List<DataRecord> records = client.readChannelsPartial(channels, 25.0, 30.0);
        
        System.out.println("  Analyzing brake event (25-30 seconds):");
        
        DataRecord brakePressure = null;
        DataRecord vehicleSpeed = null;
        
        for (DataRecord record : records) {
            if (record.getChannelName().equals("BrakePressure")) {
                brakePressure = record;
            } else if (record.getChannelName().equals("VehicleSpeed")) {
                vehicleSpeed = record;
            }
        }
        
        if (brakePressure != null && vehicleSpeed != null) {
            List<Double> pressureValues = brakePressure.getValues();
            List<Double> speedValues = vehicleSpeed.getValues();
            
            // Find max brake pressure
            double maxPressure = pressureValues.stream()
                    .mapToDouble(Double::doubleValue).max().orElse(0);
            
            // Speed at start and end of braking
            double speedAtStart = speedValues.isEmpty() ? 0 : speedValues.get(0);
            double speedAtEnd = speedValues.isEmpty() ? 0 : speedValues.get(speedValues.size() - 1);
            
            // Calculate deceleration (approximate)
            double deceleration = (speedAtStart - speedAtEnd) / 5.0;  // 5 seconds braking
            
            System.out.println("    Max Brake Pressure: " + String.format("%.2f", maxPressure) + " bar");
            System.out.println("    Speed at Start: " + String.format("%.2f", speedAtStart) + " km/h");
            System.out.println("    Speed at End: " + String.format("%.2f", speedAtEnd) + " km/h");
            System.out.println("    Average Deceleration: " + String.format("%.2f", deceleration) + " km/h/s");
        }
    }
}
