package com.mdf4;

import java.util.List;

/**
 * Mdf4Client - Java client for MDF4 file operations.
 * Uses SocketClient for communication with Python service.
 */
public class Mdf4Client implements AutoCloseable {
    
    private final SocketClient socketClient;
    
    /**
     * Default constructor - connects to localhost:25333
     */
    public Mdf4Client() {
        this.socketClient = new SocketClient();
    }
    
    /**
     * Constructor with custom host and port
     */
    public Mdf4Client(String host, int port) {
        this.socketClient = new SocketClient(host, port);
    }
    
    /**
     * Connect to the Python service
     */
    public void connect() throws Mdf4Exception {
        socketClient.connect();
    }
    
    /**
     * Disconnect from the Python service
     */
    public void disconnect() {
        socketClient.disconnect();
    }
    
    /**
     * Check if connected to the service
     */
    public boolean isConnected() {
        return socketClient.isConnected();
    }
    
    // ==================== File Operations ====================
    
    /**
     * Create a new MDF4 file
     * 
     * @param filePath Path to the new MDF4 file
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        return socketClient.createNewFile(filePath);
    }
    
    /**
     * Open an existing MDF4 file
     * 
     * @param filePath Path to the MDF4 file
     * @param readOnly Whether to open in read-only mode
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        return socketClient.openFile(filePath, readOnly);
    }
    
    /**
     * Open an existing MDF4 file (read-only by default)
     * 
     * @param filePath Path to the MDF4 file
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean openFile(String filePath) throws Mdf4Exception {
        return socketClient.openFile(filePath);
    }
    
    /**
     * Close the current MDF4 file
     * 
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean closeFile() throws Mdf4Exception {
        return socketClient.closeFile();
    }
    
    /**
     * Save the MDF4 file
     * 
     * @param filePath Path to save (null to use original path)
     * @param compression Compression level (0=none, 1=fast, 2=standard)
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        return socketClient.saveFile(filePath, compression);
    }
    
    /**
     * Save the MDF4 file (no compression, original path)
     * 
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean saveFile() throws Mdf4Exception {
        return socketClient.saveFile();
    }
    
    // ==================== Channel Write Operations ====================
    
    /**
     * Add a channel to the MDF4 file
     * 
     * @param channelName Name of the channel
     * @param timestamps List of timestamps
     * @param values List of values
     * @param unit Unit of measurement
     * @param comment Channel comment
     * @param dataType Data type ("float", "int", "double")
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        return socketClient.addChannel(channelName, timestamps, values, unit, comment, dataType);
    }
    
    /**
     * Add a channel with minimal parameters
     * 
     * @param channelName Name of the channel
     * @param timestamps List of timestamps
     * @param values List of values
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return socketClient.addChannel(channelName, timestamps, values);
    }
    
    /**
     * Write multiple channels at once
     * 
     * @param channelDataList List of ChannelData objects
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        return socketClient.writeMultipleChannels(channelDataList);
    }
    
    // ==================== Channel Read Operations ====================
    
    /**
     * Get all channel names in the file
     * 
     * @return List of channel names
     * @throws Mdf4Exception if operation fails
     */
    public List<String> getChannelNames() throws Mdf4Exception {
        return socketClient.getChannelNames();
    }
    
    /**
     * Get information about a specific channel
     * 
     * @param channelName Name of the channel
     * @return ChannelInfo object
     * @throws Mdf4Exception if operation fails
     */
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        return socketClient.getChannelInfo(channelName);
    }
    
    /**
     * Read all data from a channel
     * 
     * @param channelName Name of the channel to read
     * @return DataRecord object
     * @throws Mdf4Exception if operation fails
     */
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        return socketClient.readChannel(channelName);
    }
    
    /**
     * Read multiple channels at once
     * 
     * @param channelNames List of channel names to read
     * @return List of DataRecord objects
     * @throws Mdf4Exception if operation fails
     */
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        return socketClient.readMultipleChannels(channelNames);
    }
    
    // ==================== Partial Read Operations ====================
    
    /**
     * Partially read data from a channel by index range
     * 
     * @param channelName Name of the channel
     * @param startIndex Starting sample index
     * @param count Number of samples to read
     * @return DataRecord object
     * @throws Mdf4Exception if operation fails
     */
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        return socketClient.readChannelPartial(channelName, startIndex, count);
    }
    
    /**
     * Partially read data from multiple channels within a time range
     * 
     * @param channelNames List of channel names
     * @param startTime Start timestamp
     * @param endTime End timestamp
     * @return List of DataRecord objects
     * @throws Mdf4Exception if operation fails
     */
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        return socketClient.readChannelsPartial(channelNames, startTime, endTime);
    }
    
    /**
     * Get the total number of samples for a channel
     * 
     * @param channelName Name of the channel
     * @return Number of samples
     * @throws Mdf4Exception if operation fails
     */
    public int getSampleCount(String channelName) throws Mdf4Exception {
        return socketClient.getSampleCount(channelName);
    }
    
    /**
     * Get the time range of the measurement
     * 
     * @return Array of [startTime, endTime]
     * @throws Mdf4Exception if operation fails
     */
    public double[] getTimeRange() throws Mdf4Exception {
        return socketClient.getTimeRange();
    }
    
    // ==================== Utility Operations ====================
    
    /**
     * Filter to keep only specified channels
     * 
     * @param channelNames List of channel names to keep
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        return socketClient.filterChannels(channelNames);
    }
    
    /**
     * Cut the file to a specific time range
     * 
     * @param startTime Start timestamp
     * @param endTime End timestamp
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        return socketClient.cutTimeRange(startTime, endTime);
    }
    
    @Override
    public void close() {
        socketClient.close();
    }
}
