# MDF4 Hybrid Project - Architecture

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Java Application                                │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         Mdf4Client                                   │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   write()   │  │   read()    │  │ partial()   │  │  info()    │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         Py4J Client                                  │   │
│  │                    (Socket Communication)                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ TCP Socket (Port 25333)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Python Service                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Py4J Gateway Server                             │   │
│  │                    (Socket Server - Port 25333)                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Mdf4Service (Wrapper)                           │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │createNewFile│  │addChannel() │  │readChannel()│  │getInfo()   │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Mdf4Handler (Core)                              │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │    MDF()    │  │  Signal()   │  │  append()   │  │   get()    │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         asammdf Library                              │   │
│  │              (ASAM MDF4 Standard Implementation)                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ File I/O
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MDF4 File (.mf4)                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐   │   │
│  │  │ Header  │  │ Channel │  │ Channel │  │ Channel │  │  Data   │   │   │
│  │  │ Block   │  │  Info   │  │  Info   │  │  Info   │  │ Blocks  │   │   │
│  │  └─────────┘  │ Block 1 │  │ Block 2 │  │ Block N │  └─────────┘   │   │
│  │               └─────────┘  └─────────┘  └─────────┘                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Communication Flow

### Write Operation

```
Java Application
       │
       │ 1. client.addChannel(name, timestamps, values)
       ▼
Mdf4Client
       │
       │ 2. Py4J method invocation (socket)
       ▼
Py4J Gateway Server
       │
       │ 3. service.addChannel(...)
       ▼
Mdf4Service
       │
       │ 4. handler.add_channel(...)
       ▼
Mdf4Handler
       │
       │ 5. mdf.append(signal)
       ▼
asammdf MDF Object
       │
       │ 6. File I/O
       ▼
MDF4 File
```

### Read Operation (Full)

```
Java Application
       │
       │ 1. client.readChannel(name)
       ▼
Mdf4Client
       │
       │ 2. Py4J method invocation
       ▼
Py4J Gateway Server
       │
       │ 3. service.readChannel(name)
       ▼
Mdf4Service
       │
       │ 4. handler.read_channel(name)
       ▼
Mdf4Handler
       │
       │ 5. mdf.get(name)
       ▼
asammdf MDF Object
       │
       │ 6. File I/O (read all samples)
       ▼
MDF4 File
       │
       │ 7. Return Signal object
       ▼
Mdf4Handler
       │
       │ 8. Convert to DataRecord
       ▼
Mdf4Service
       │
       │ 9. Convert to Map for Py4J
       ▼
Py4J Gateway Server
       │
       │ 10. Serialize and send via socket
       ▼
Mdf4Client
       │
       │ 11. Convert Map to DataRecord
       ▼
Java Application
```

### Partial Read Operation (By Index)

```
Java Application
       │
       │ 1. client.readChannelPartial(name, startIndex, count)
       ▼
Mdf4Client
       │
       │ 2. Py4J method invocation
       ▼
Py4J Gateway Server
       │
       │ 3. service.readChannelPartial(name, start, count)
       ▼
Mdf4Service
       │
       │ 4. handler.read_channel_partial(name, start, count)
       ▼
Mdf4Handler
       │
       │ 5. mdf.get(name) - reads all
       │ 6. Slice array[start:end] - extracts subset
       ▼
Mdf4Service
       │
       │ 7. Convert sliced data to Map
       ▼
Py4J Gateway Server
       │
       │ 8. Send partial data
       ▼
Mdf4Client
       │
       │ 9. Convert to DataRecord
       ▼
Java Application (receives only requested subset)
```

### Partial Read Operation (By Time Range)

```
Java Application
       │
       │ 1. client.readChannelsPartial(names, startTime, endTime)
       ▼
Mdf4Client
       │
       │ 2. Py4J method invocation
       ▼
Py4J Gateway Server
       │
       │ 3. service.readChannelsPartial(names, start, end)
       ▼
Mdf4Service
       │
       │ 4. handler.read_channels_partial(names, start, end)
       ▼
Mdf4Handler
       │
       │ 5. For each channel:
       │    a. mdf.get(name) - reads all
       │    b. mask = (timestamps >= start) & (timestamps <= end)
       │    c. filtered = data[mask] - extracts time range
       ▼
Mdf4Service
       │
       │ 6. Convert filtered data to List of Maps
       ▼
Py4J Gateway Server
       │
       │ 7. Send filtered data
       ▼
Mdf4Client
       │
       │ 8. Convert to List of DataRecords
       ▼
Java Application (receives only time range data)
```

## Data Flow

### Write Data Flow

```
Java List<Double> (timestamps, values)
       │
       │ Py4J serialization
       ▼
Python list (Py4J auto-conversion)
       │
       │ numpy.array()
       ▼
numpy arrays
       │
       │ Signal constructor
       ▼
Signal object (asammdf)
       │
       │ MDF.append()
       ▼
MDF internal structure
       │
       │ MDF.save()
       ▼
Binary MDF4 file
```

### Read Data Flow

```
Binary MDF4 file
       │
       │ MDF.get()
       ▼
Signal object (asammdf)
       │
       │ Extract samples, timestamps
       ▼
numpy arrays
       │
       │ .tolist() conversion
       ▼
Python lists
       │
       │ Py4J serialization
       ▼
Java List<Double>
       │
       │ DataRecord constructor
       ▼
DataRecord object
```

## Class Diagram

### Java Classes

```
┌─────────────────────────────────────────────────────────────────┐
│                        <<interface>>                            │
│                       AutoCloseable                             │
└─────────────────────────────────────────────────────────────────┘
                              △
                              │ implements
┌─────────────────────────────────────────────────────────────────┐
│                          Mdf4Client                             │
│─────────────────────────────────────────────────────────────────│
│ - gateway: Gateway                                              │
│ - service: Object                                               │
│ - connected: boolean                                            │
│ - host: String                                                  │
│ - port: int                                                     │
│─────────────────────────────────────────────────────────────────│
│ + Mdf4Client()                                                  │
│ + Mdf4Client(host, port)                                        │
│ + connect(): void                                               │
│ + disconnect(): void                                            │
│ + createNewFile(path): boolean                                  │
│ + openFile(path): boolean                                       │
│ + openFile(path, readOnly): boolean                             │
│ + closeFile(): boolean                                          │
│ + saveFile(): boolean                                           │
│ + saveFile(path, compression): boolean                          │
│ + addChannel(name, timestamps, values): boolean                 │
│ + addChannel(name, ts, vals, unit, comment, type): boolean      │
│ + writeMultipleChannels(list): boolean                          │
│ + getChannelNames(): List<String>                               │
│ + getChannelInfo(name): ChannelInfo                             │
│ + readChannel(name): DataRecord                                 │
│ + readMultipleChannels(names): List<DataRecord>                 │
│ + readChannelPartial(name, start, count): DataRecord            │
│ + readChannelsPartial(names, startTime, endTime): List          │
│ + getSampleCount(name): int                                     │
│ + getTimeRange(): double[]                                      │
│ + filterChannels(names): boolean                                │
│ + cutTimeRange(start, end): boolean                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          DataRecord                             │
│─────────────────────────────────────────────────────────────────│
│ - channelName: String                                           │
│ - timestamps: List<Double>                                      │
│ - values: List<Double>                                          │
│ - unit: String                                                  │
│─────────────────────────────────────────────────────────────────│
│ + getSampleCount(): int                                         │
│ + getStartTime(): double                                        │
│ + getEndTime(): double                                          │
│ + getDuration(): double                                         │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          ChannelInfo                            │
│─────────────────────────────────────────────────────────────────│
│ - name: String                                                  │
│ - unit: String                                                  │
│ - comment: String                                               │
│ - dataType: String                                              │
│ - samplesCount: int                                             │
│ - firstTimestamp: double                                        │
│ - lastTimestamp: double                                         │
│─────────────────────────────────────────────────────────────────│
│ + getDuration(): double                                         │
│ + getAverageSampleRate(): double                                │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          ChannelData                            │
│─────────────────────────────────────────────────────────────────│
│ - name: String                                                  │
│ - timestamps: List<Double>                                      │
│ - values: List<Double>                                          │
│ - unit: String                                                  │
│ - comment: String                                               │
│ - dataType: String                                              │
│─────────────────────────────────────────────────────────────────│
│ + builder(): Builder                                            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          Mdf4Exception                          │
│─────────────────────────────────────────────────────────────────│
│                          (extends Exception)                    │
└─────────────────────────────────────────────────────────────────┘
```

### Python Classes

```
┌─────────────────────────────────────────────────────────────────┐
│                          Mdf4Handler                            │
│─────────────────────────────────────────────────────────────────│
│ - _mdf: MDF (asammdf)                                           │
│ - _file_path: str                                               │
│─────────────────────────────────────────────────────────────────│
│ + create_new_file(path): bool                                   │
│ + open_file(path, read_only): bool                              │
│ + close_file(): bool                                            │
│ + save_file(path, compression): bool                            │
│ + add_channel(name, ts, vals, unit, comment, dtype): bool       │
│ + get_channel_names(): List[str]                                │
│ + get_channel_info(name): Dict                                  │
│ + read_channel(name): DataRecord                                │
│ + read_channels_partial(names, start, end): List[DataRecord]    │
│ + read_channel_partial(name, start, count): DataRecord          │
│ + get_sample_count(name): int                                   │
│ + get_time_range(): Tuple[float, float]                         │
│ + filter_channels(names): bool                                  │
│ + cut_time_range(start, end): bool                              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          Mdf4Service                            │
│─────────────────────────────────────────────────────────────────│
│ - _handler: Mdf4Handler                                         │
│─────────────────────────────────────────────────────────────────│
│ + createNewFile(path): bool                                     │
│ + openFile(path, readOnly): bool                                │
│ + closeFile(): bool                                             │
│ + saveFile(path, compression): bool                             │
│ + addChannel(name, ts, vals, unit, comment, dtype): bool        │
│ + getChannelNames(): List                                       │
│ + getChannelInfo(name): Dict                                    │
│ + readChannel(name): Dict                                       │
│ + readChannelPartial(name, start, count): Dict                  │
│ + readChannelsPartial(names, start, end): List[Dict]            │
│ + getSampleCount(name): int                                     │
│ + getTimeRange(): List[float]                                   │
│ + filterChannels(names): bool                                   │
│ + cutTimeRange(start, end): bool                                │
│ + writeMultipleChannels(list): bool                             │
│ + readMultipleChannels(names): List[Dict]                       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                          DataRecord                             │
│─────────────────────────────────────────────────────────────────│
│ - channel_name: str                                             │
│ - timestamps: List[float]                                       │
│ - values: List[float]                                           │
│ - unit: str                                                     │
└─────────────────────────────────────────────────────────────────┘
```

## Partial Reading Implementation

### Index-Based Partial Read

```python
def read_channel_partial(self, channel_name, start_index, count):
    # 1. Read full channel
    signal = self._mdf.get(channel_name)
    
    # 2. Calculate end index
    end_index = min(start_index + count, len(signal.samples))
    
    # 3. Slice arrays
    return DataRecord(
        channel_name=signal.name,
        timestamps=signal.timestamps[start_index:end_index].tolist(),
        values=signal.samples[start_index:end_index].tolist(),
        unit=signal.unit
    )
```

### Time-Based Partial Read

```python
def read_channels_partial(self, channel_names, start_time, end_time):
    results = []
    for channel_name in channel_names:
        signal = self._mdf.get(channel_name)
        
        # Create boolean mask for time range
        mask = (signal.timestamps >= start_time) & (signal.timestamps <= end_time)
        
        # Apply mask to filter data
        filtered_timestamps = signal.timestamps[mask]
        filtered_values = signal.samples[mask]
        
        results.append(DataRecord(
            channel_name=signal.name,
            timestamps=filtered_timestamps.tolist(),
            values=filtered_values.tolist(),
            unit=signal.unit
        ))
    return results
```

## Benefits of This Architecture

1. **Language Best Practices**
   - Python: Excellent for data processing (asammdf)
   - Java: Excellent for enterprise applications

2. **Separation of Concerns**
   - Java handles business logic
   - Python handles MDF4 operations

3. **Flexibility**
   - Can upgrade either side independently
   - Can run on different machines

4. **Memory Efficiency**
   - Partial reads reduce memory usage
   - Large files can be processed in chunks

5. **Performance**
   - Py4J has minimal overhead for data transfer
   - asammdf is optimized for MDF4 operations
