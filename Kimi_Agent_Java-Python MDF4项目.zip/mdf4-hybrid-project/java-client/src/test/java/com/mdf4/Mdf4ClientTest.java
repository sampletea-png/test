package com.mdf4;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Mdf4ClientTest - Unit tests for the MDF4 Java client.
 * 
 * Note: These tests require the Python service to be running.
 * Start the Python service first with: python mdf4_service.py
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class Mdf4ClientTest {
    
    private static Mdf4Client client;
    private static final String TEST_FILE = "test_data.mf4";
    
    @BeforeAll
    public static void setUpClass() {
        client = new Mdf4Client("localhost", 25333);
    }
    
    @AfterAll
    public static void tearDownClass() {
        if (client != null) {
            client.disconnect();
        }
        // Clean up test file
        File file = new File(TEST_FILE);
        if (file.exists()) {
            file.delete();
        }
    }
    
    @BeforeEach
    public void setUp() throws Mdf4Exception {
        if (!client.isConnected()) {
            client.connect();
        }
    }
    
    @Test
    @Order(1)
    @DisplayName("Test connection to Python service")
    public void testConnection() {
        assertTrue(client.isConnected(), "Client should be connected");
    }
    
    @Test
    @Order(2)
    @DisplayName("Test creating a new MDF4 file")
    public void testCreateNewFile() throws Mdf4Exception {
        boolean result = client.createNewFile(TEST_FILE);
        assertTrue(result, "Should create new file successfully");
    }
    
    @Test
    @Order(3)
    @DisplayName("Test adding a channel")
    public void testAddChannel() throws Mdf4Exception {
        List<Double> timestamps = Arrays.asList(0.0, 0.1, 0.2, 0.3, 0.4);
        List<Double> values = Arrays.asList(10.0, 20.0, 30.0, 40.0, 50.0);
        
        boolean result = client.addChannel("TestChannel", timestamps, values, 
                                          "V", "Test voltage", "float");
        assertTrue(result, "Should add channel successfully");
    }
    
    @Test
    @Order(4)
    @DisplayName("Test saving the file")
    public void testSaveFile() throws Mdf4Exception {
        boolean result = client.saveFile();
        assertTrue(result, "Should save file successfully");
    }
    
    @Test
    @Order(5)
    @DisplayName("Test closing and reopening the file")
    public void testCloseAndReopen() throws Mdf4Exception {
        client.closeFile();
        boolean result = client.openFile(TEST_FILE);
        assertTrue(result, "Should open file successfully");
    }
    
    @Test
    @Order(6)
    @DisplayName("Test getting channel names")
    public void testGetChannelNames() throws Mdf4Exception {
        List<String> names = client.getChannelNames();
        assertNotNull(names, "Channel names list should not be null");
        assertTrue(names.contains("TestChannel"), "Should contain TestChannel");
    }
    
    @Test
    @Order(7)
    @DisplayName("Test getting channel info")
    public void testGetChannelInfo() throws Mdf4Exception {
        ChannelInfo info = client.getChannelInfo("TestChannel");
        assertNotNull(info, "Channel info should not be null");
        assertEquals("TestChannel", info.getName());
        assertEquals("V", info.getUnit());
        assertEquals(5, info.getSamplesCount());
    }
    
    @Test
    @Order(8)
    @DisplayName("Test reading a channel")
    public void testReadChannel() throws Mdf4Exception {
        DataRecord record = client.readChannel("TestChannel");
        assertNotNull(record, "Data record should not be null");
        assertEquals("TestChannel", record.getChannelName());
        assertEquals(5, record.getSampleCount());
        assertEquals("V", record.getUnit());
        
        // Check values
        List<Double> expectedValues = Arrays.asList(10.0, 20.0, 30.0, 40.0, 50.0);
        assertEquals(expectedValues, record.getValues(), "Values should match");
    }
    
    @Test
    @Order(9)
    @DisplayName("Test partial read by index")
    public void testReadChannelPartial() throws Mdf4Exception {
        DataRecord record = client.readChannelPartial("TestChannel", 1, 3);
        assertNotNull(record, "Data record should not be null");
        assertEquals(3, record.getSampleCount(), "Should have 3 samples");
        
        // Check values (samples 1, 2, 3)
        List<Double> expectedValues = Arrays.asList(20.0, 30.0, 40.0);
        assertEquals(expectedValues, record.getValues(), "Values should match");
    }
    
    @Test
    @Order(10)
    @DisplayName("Test getting sample count")
    public void testGetSampleCount() throws Mdf4Exception {
        int count = client.getSampleCount("TestChannel");
        assertEquals(5, count, "Should have 5 samples");
    }
    
    @Test
    @Order(11)
    @DisplayName("Test getting time range")
    public void testGetTimeRange() throws Mdf4Exception {
        double[] range = client.getTimeRange();
        assertNotNull(range, "Time range should not be null");
        assertEquals(2, range.length, "Range should have 2 elements");
        assertEquals(0.0, range[0], 0.001, "Start time should be 0.0");
        assertEquals(0.4, range[1], 0.001, "End time should be 0.4");
    }
    
    @Test
    @Order(12)
    @DisplayName("Test writing multiple channels")
    public void testWriteMultipleChannels() throws Mdf4Exception {
        // Create new file for this test
        client.createNewFile("multi_channel_test.mf4");
        
        List<ChannelData> channels = new ArrayList<>();
        
        // Channel 1
        channels.add(ChannelData.builder()
                .name("Channel1")
                .timestamps(Arrays.asList(0.0, 0.1, 0.2))
                .values(Arrays.asList(1.0, 2.0, 3.0))
                .unit("A")
                .comment("Current")
                .dataType("float")
                .build());
        
        // Channel 2
        channels.add(ChannelData.builder()
                .name("Channel2")
                .timestamps(Arrays.asList(0.0, 0.1, 0.2))
                .values(Arrays.asList(10.0, 20.0, 30.0))
                .unit("V")
                .comment("Voltage")
                .dataType("float")
                .build());
        
        boolean result = client.writeMultipleChannels(channels);
        assertTrue(result, "Should write multiple channels successfully");
        
        // Save and verify
        client.saveFile();
        client.closeFile();
        client.openFile("multi_channel_test.mf4");
        
        List<String> names = client.getChannelNames();
        assertTrue(names.contains("Channel1"), "Should contain Channel1");
        assertTrue(names.contains("Channel2"), "Should contain Channel2");
        
        // Cleanup
        client.closeFile();
        new File("multi_channel_test.mf4").delete();
        client.openFile(TEST_FILE);
    }
    
    @Test
    @Order(13)
    @DisplayName("Test reading multiple channels")
    public void testReadMultipleChannels() throws Mdf4Exception {
        List<String> channelNames = Arrays.asList("TestChannel");
        List<DataRecord> records = client.readMultipleChannels(channelNames);
        
        assertNotNull(records, "Records list should not be null");
        assertEquals(1, records.size(), "Should have 1 record");
        assertEquals("TestChannel", records.get(0).getChannelName());
    }
    
    @Test
    @Order(14)
    @DisplayName("Test partial read by time range")
    public void testReadChannelsPartial() throws Mdf4Exception {
        // Add more data for time range testing
        List<Double> timestamps = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        
        for (int i = 0; i < 100; i++) {
            timestamps.add(i * 0.1);  // 0.0 to 9.9 seconds
            values.add((double) i);
        }
        
        client.createNewFile("time_range_test.mf4");
        client.addChannel("TimeChannel", timestamps, values, "s", "Time test", "float");
        client.saveFile();
        client.closeFile();
        client.openFile("time_range_test.mf4");
        
        // Read partial data (2.0 to 5.0 seconds)
        List<String> channels = Arrays.asList("TimeChannel");
        List<DataRecord> records = client.readChannelsPartial(channels, 2.0, 5.0);
        
        assertNotNull(records, "Records should not be null");
        assertEquals(1, records.size(), "Should have 1 record");
        
        DataRecord record = records.get(0);
        // Should have samples from index 20 to 50 (2.0s to 5.0s)
        assertTrue(record.getSampleCount() >= 30, "Should have at least 30 samples");
        
        // Verify time range
        double startTime = record.getStartTime();
        double endTime = record.getEndTime();
        assertTrue(startTime >= 2.0, "Start time should be >= 2.0");
        assertTrue(endTime <= 5.0, "End time should be <= 5.0");
        
        // Cleanup
        client.closeFile();
        new File("time_range_test.mf4").delete();
        client.openFile(TEST_FILE);
    }
    
    @Test
    @Order(15)
    @DisplayName("Test error handling for non-existent channel")
    public void testNonExistentChannel() throws Mdf4Exception {
        DataRecord record = client.readChannel("NonExistentChannel");
        assertNull(record, "Should return null for non-existent channel");
    }
    
    @Test
    @Order(16)
    @DisplayName("Test auto-closeable")
    public void testAutoCloseable() {
        assertDoesNotThrow(() -> {
            try (Mdf4Client autoClient = new Mdf4Client("localhost", 25333)) {
                autoClient.connect();
                assertTrue(autoClient.isConnected());
            }
        });
    }
}
