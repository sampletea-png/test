package com.mdf4;

import py4j.GatewayServer;
import py4j.Py4JNetworkException;

import java.util.*;

/**
 * Mdf4Client - Java client for MDF4 file operations.
 * Communicates with Python service via Py4J to perform MDF4 read/write operations.
 */
public class Mdf4Client implements AutoCloseable {
    
    private py4j.Gateway gateway;
    private Object service;
    private boolean connected;
    private final String host;
    private final int port;
    
    /**
     * Default constructor - connects to localhost:25333
     */
    public Mdf4Client() {
        this("localhost", 25333);
    }
    
    /**
     * Constructor with custom host and port
     */
    public Mdf4Client(String host, int port) {
        this.host = host;
        this.port = port;
        this.connected = false;
    }
    
    /**
     * Connect to the Python service
     */
    public void connect() throws Mdf4Exception {
        try {
            gateway = new py4j.GatewayServer.GatewayClient(host, port);
            service = gateway.getEntryPoint();
            connected = true;
            System.out.println("Connected to MDF4 Python service at " + host + ":" + port);
        } catch (Py4JNetworkException e) {
            throw new Mdf4Exception("Failed to connect to Python service. " +
                    "Make sure the Python service is running.", e);
        } catch (Exception e) {
            throw new Mdf4Exception("Unexpected error connecting to Python service", e);
        }
    }
    
    /**
     * Disconnect from the Python service
     */
    public void disconnect() {
        if (gateway != null) {
            gateway.shutdown();
            gateway = null;
            service = null;
            connected = false;
            System.out.println("Disconnected from MDF4 Python service");
        }
    }
    
    /**
     * Check if connected to the service
     */
    public boolean isConnected() {
        return connected;
    }
    
    // ==================== File Operations ====================
    
    /**
     * Create a new MDF4 file
     * 
     * @param filePath Path to the new MDF4 file
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean createNewFile(String filePath) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("createNewFile", String.class)
                    .invoke(service, filePath);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to create new file", e);
        }
    }
    
    /**
     * Open an existing MDF4 file
     * 
     * @param filePath Path to the MDF4 file
     * @param readOnly Whether to open in read-only mode
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean openFile(String filePath, boolean readOnly) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("openFile", String.class, boolean.class)
                    .invoke(service, filePath, readOnly);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to open file", e);
        }
    }
    
    /**
     * Open an existing MDF4 file (read-only by default)
     * 
     * @param filePath Path to the MDF4 file
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean openFile(String filePath) throws Mdf4Exception {
        return openFile(filePath, true);
    }
    
    /**
     * Close the current MDF4 file
     * 
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean closeFile() throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("closeFile")
                    .invoke(service);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to close file", e);
        }
    }
    
    /**
     * Save the MDF4 file
     * 
     * @param filePath Path to save (null to use original path)
     * @param compression Compression level (0=none, 1=fast, 2=standard)
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean saveFile(String filePath, int compression) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("saveFile", String.class, int.class)
                    .invoke(service, filePath, compression);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to save file", e);
        }
    }
    
    /**
     * Save the MDF4 file (no compression, original path)
     * 
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean saveFile() throws Mdf4Exception {
        return saveFile(null, 0);
    }
    
    // ==================== Channel Write Operations ====================
    
    /**
     * Add a channel to the MDF4 file
     * 
     * @param channelName Name of the channel
     * @param timestamps List of timestamps
     * @param values List of values
     * @param unit Unit of measurement
     * @param comment Channel comment
     * @param dataType Data type ("float", "int", "double")
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values, String unit, 
                              String comment, String dataType) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("addChannel", String.class, List.class, List.class,
                            String.class, String.class, String.class)
                    .invoke(service, channelName, timestamps, values, unit, comment, dataType);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to add channel", e);
        }
    }
    
    /**
     * Add a channel with minimal parameters
     * 
     * @param channelName Name of the channel
     * @param timestamps List of timestamps
     * @param values List of values
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean addChannel(String channelName, List<Double> timestamps, 
                              List<Double> values) throws Mdf4Exception {
        return addChannel(channelName, timestamps, values, "", "", "float");
    }
    
    /**
     * Write multiple channels at once
     * 
     * @param channelDataList List of ChannelData objects
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public boolean writeMultipleChannels(List<ChannelData> channelDataList) throws Mdf4Exception {
        checkConnection();
        try {
            // Convert ChannelData objects to Maps for Py4J
            List<Map<String, Object>> dataList = new ArrayList<>();
            for (ChannelData data : channelDataList) {
                Map<String, Object> map = new HashMap<>();
                map.put("name", data.getName());
                map.put("timestamps", data.getTimestamps());
                map.put("values", data.getValues());
                map.put("unit", data.getUnit());
                map.put("comment", data.getComment());
                map.put("dataType", data.getDataType());
                dataList.add(map);
            }
            
            return (Boolean) service.getClass()
                    .getMethod("writeMultipleChannels", List.class)
                    .invoke(service, dataList);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to write multiple channels", e);
        }
    }
    
    // ==================== Channel Read Operations ====================
    
    /**
     * Get all channel names in the file
     * 
     * @return List of channel names
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public List<String> getChannelNames() throws Mdf4Exception {
        checkConnection();
        try {
            return (List<String>) service.getClass()
                    .getMethod("getChannelNames")
                    .invoke(service);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to get channel names", e);
        }
    }
    
    /**
     * Get information about a specific channel
     * 
     * @param channelName Name of the channel
     * @return ChannelInfo object
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public ChannelInfo getChannelInfo(String channelName) throws Mdf4Exception {
        checkConnection();
        try {
            Map<String, Object> infoMap = (Map<String, Object>) service.getClass()
                    .getMethod("getChannelInfo", String.class)
                    .invoke(service, channelName);
            
            if (infoMap == null) {
                return null;
            }
            
            ChannelInfo info = new ChannelInfo();
            info.setName((String) infoMap.get("name"));
            info.setUnit((String) infoMap.get("unit"));
            info.setComment((String) infoMap.get("comment"));
            info.setSamplesCount((Integer) infoMap.get("samplesCount"));
            info.setFirstTimestamp((Double) infoMap.get("firstTimestamp"));
            info.setLastTimestamp((Double) infoMap.get("lastTimestamp"));
            return info;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to get channel info", e);
        }
    }
    
    /**
     * Read all data from a channel
     * 
     * @param channelName Name of the channel
     * @return DataRecord object
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public DataRecord readChannel(String channelName) throws Mdf4Exception {
        checkConnection();
        try {
            Map<String, Object> recordMap = (Map<String, Object>) service.getClass()
                    .getMethod("readChannel", String.class)
                    .invoke(service, channelName);
            
            if (recordMap == null) {
                return null;
            }
            
            DataRecord record = new DataRecord();
            record.setChannelName((String) recordMap.get("channelName"));
            record.setTimestamps((List<Double>) recordMap.get("timestamps"));
            record.setValues((List<Double>) recordMap.get("values"));
            record.setUnit((String) recordMap.get("unit"));
            return record;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to read channel", e);
        }
    }
    
    /**
     * Read multiple channels at once
     * 
     * @param channelNames List of channel names
     * @return List of DataRecord objects
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public List<DataRecord> readMultipleChannels(List<String> channelNames) throws Mdf4Exception {
        checkConnection();
        try {
            List<Map<String, Object>> recordsList = (List<Map<String, Object>>) service.getClass()
                    .getMethod("readMultipleChannels", List.class)
                    .invoke(service, channelNames);
            
            List<DataRecord> results = new ArrayList<>();
            for (Map<String, Object> recordMap : recordsList) {
                DataRecord record = new DataRecord();
                record.setChannelName((String) recordMap.get("channelName"));
                record.setTimestamps((List<Double>) recordMap.get("timestamps"));
                record.setValues((List<Double>) recordMap.get("values"));
                record.setUnit((String) recordMap.get("unit"));
                results.add(record);
            }
            return results;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to read multiple channels", e);
        }
    }
    
    // ==================== Partial Read Operations ====================
    
    /**
     * Partially read data from a channel by index range
     * 
     * @param channelName Name of the channel
     * @param startIndex Starting sample index
     * @param count Number of samples to read
     * @return DataRecord object
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public DataRecord readChannelPartial(String channelName, int startIndex, int count) throws Mdf4Exception {
        checkConnection();
        try {
            Map<String, Object> recordMap = (Map<String, Object>) service.getClass()
                    .getMethod("readChannelPartial", String.class, int.class, int.class)
                    .invoke(service, channelName, startIndex, count);
            
            if (recordMap == null) {
                return null;
            }
            
            DataRecord record = new DataRecord();
            record.setChannelName((String) recordMap.get("channelName"));
            record.setTimestamps((List<Double>) recordMap.get("timestamps"));
            record.setValues((List<Double>) recordMap.get("values"));
            record.setUnit((String) recordMap.get("unit"));
            return record;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to read channel partially", e);
        }
    }
    
    /**
     * Partially read data from multiple channels within a time range
     * 
     * @param channelNames List of channel names
     * @param startTime Start timestamp
     * @param endTime End timestamp
     * @return List of DataRecord objects
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public List<DataRecord> readChannelsPartial(List<String> channelNames, 
                                                 double startTime, double endTime) throws Mdf4Exception {
        checkConnection();
        try {
            List<Map<String, Object>> recordsList = (List<Map<String, Object>>) service.getClass()
                    .getMethod("readChannelsPartial", List.class, double.class, double.class)
                    .invoke(service, channelNames, startTime, endTime);
            
            List<DataRecord> results = new ArrayList<>();
            for (Map<String, Object> recordMap : recordsList) {
                DataRecord record = new DataRecord();
                record.setChannelName((String) recordMap.get("channelName"));
                record.setTimestamps((List<Double>) recordMap.get("timestamps"));
                record.setValues((List<Double>) recordMap.get("values"));
                record.setUnit((String) recordMap.get("unit"));
                results.add(record);
            }
            return results;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to read channels partially by time range", e);
        }
    }
    
    /**
     * Get the total number of samples for a channel
     * 
     * @param channelName Name of the channel
     * @return Number of samples
     * @throws Mdf4Exception if operation fails
     */
    public int getSampleCount(String channelName) throws Mdf4Exception {
        checkConnection();
        try {
            return (Integer) service.getClass()
                    .getMethod("getSampleCount", String.class)
                    .invoke(service, channelName);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to get sample count", e);
        }
    }
    
    /**
     * Get the time range of the measurement
     * 
     * @return Array of [startTime, endTime]
     * @throws Mdf4Exception if operation fails
     */
    @SuppressWarnings("unchecked")
    public double[] getTimeRange() throws Mdf4Exception {
        checkConnection();
        try {
            List<Double> range = (List<Double>) service.getClass()
                    .getMethod("getTimeRange")
                    .invoke(service);
            return new double[]{range.get(0), range.get(1)};
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to get time range", e);
        }
    }
    
    // ==================== Utility Operations ====================
    
    /**
     * Filter to keep only specified channels
     * 
     * @param channelNames List of channel names to keep
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean filterChannels(List<String> channelNames) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("filterChannels", List.class)
                    .invoke(service, channelNames);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to filter channels", e);
        }
    }
    
    /**
     * Cut the file to a specific time range
     * 
     * @param startTime Start timestamp
     * @param endTime End timestamp
     * @return true if successful
     * @throws Mdf4Exception if operation fails
     */
    public boolean cutTimeRange(double startTime, double endTime) throws Mdf4Exception {
        checkConnection();
        try {
            return (Boolean) service.getClass()
                    .getMethod("cutTimeRange", double.class, double.class)
                    .invoke(service, startTime, endTime);
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to cut time range", e);
        }
    }
    
    // ==================== Helper Methods ====================
    
    private void checkConnection() throws Mdf4Exception {
        if (!connected || gateway == null || service == null) {
            throw new Mdf4Exception("Not connected to Python service. Call connect() first.");
        }
    }
    
    @Override
    public void close() {
        disconnect();
    }
}
