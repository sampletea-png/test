package com.mdf4;

/**
 * ChannelInfo - Represents metadata about a channel in an MDF4 file.
 */
public class ChannelInfo {
    
    private String name;
    private String unit;
    private String comment;
    private String dataType;
    private int samplesCount;
    private double firstTimestamp;
    private double lastTimestamp;
    
    /**
     * Default constructor
     */
    public ChannelInfo() {
    }
    
    /**
     * Constructor with all fields
     */
    public ChannelInfo(String name, String unit, String comment, 
                       String dataType, int samplesCount,
                       double firstTimestamp, double lastTimestamp) {
        this.name = name;
        this.unit = unit;
        this.comment = comment;
        this.dataType = dataType;
        this.samplesCount = samplesCount;
        this.firstTimestamp = firstTimestamp;
        this.lastTimestamp = lastTimestamp;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public void setUnit(String unit) {
        this.unit = unit;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public String getDataType() {
        return dataType;
    }
    
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    public int getSamplesCount() {
        return samplesCount;
    }
    
    public void setSamplesCount(int samplesCount) {
        this.samplesCount = samplesCount;
    }
    
    public double getFirstTimestamp() {
        return firstTimestamp;
    }
    
    public void setFirstTimestamp(double firstTimestamp) {
        this.firstTimestamp = firstTimestamp;
    }
    
    public double getLastTimestamp() {
        return lastTimestamp;
    }
    
    public void setLastTimestamp(double lastTimestamp) {
        this.lastTimestamp = lastTimestamp;
    }
    
    // ==================== Utility Methods ====================
    
    /**
     * Get the duration of this channel's data
     */
    public double getDuration() {
        return lastTimestamp - firstTimestamp;
    }
    
    /**
     * Get the average sample rate
     */
    public double getAverageSampleRate() {
        double duration = getDuration();
        return duration > 0 ? samplesCount / duration : 0;
    }
    
    @Override
    public String toString() {
        return String.format("ChannelInfo{name='%s', unit='%s', samples=%d, timeRange=[%.3f, %.3f]}",
                name, unit, samplesCount, firstTimestamp, lastTimestamp);
    }
}
