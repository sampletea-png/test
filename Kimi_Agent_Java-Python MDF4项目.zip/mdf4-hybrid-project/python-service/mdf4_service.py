"""
MDF4 Service - Py4J Gateway Server
Provides Java access to MDF4 file operations through Py4J.
"""

import sys
import logging
from py4j.java_gateway import GatewayServer, JavaGateway, java_import
from mdf4_handler import Mdf4Handler, get_handler, DataRecord

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class Mdf4Service:
    """
    Service class exposed to Java through Py4J.
    Acts as a wrapper around Mdf4Handler with methods suitable for Java interop.
    """
    
    def __init__(self):
        self._handler = get_handler()
        logger.info("MDF4 Service initialized")
    
    # ==================== File Operations ====================
    
    def createNewFile(self, file_path: str) -> bool:
        """Create a new MDF4 file"""
        return self._handler.create_new_file(file_path)
    
    def openFile(self, file_path: str, read_only: bool = True) -> bool:
        """Open an existing MDF4 file"""
        return self._handler.open_file(file_path, read_only)
    
    def closeFile(self) -> bool:
        """Close the current MDF4 file"""
        return self._handler.close_file()
    
    def saveFile(self, file_path: str = None, compression: int = 0) -> bool:
        """Save the MDF4 file"""
        return self._handler.save_file(file_path, compression)
    
    # ==================== Channel Write Operations ====================
    
    def addChannel(self, channel_name: str, timestamps, values, 
                   unit: str = "", comment: str = "", data_type: str = "float") -> bool:
        """
        Add a channel to the MDF4 file.
        
        Args:
            channel_name: Name of the channel
            timestamps: List of timestamps (Java List or Python list)
            values: List of values (Java List or Python list)
            unit: Unit of measurement
            comment: Channel comment
            data_type: Data type ('float', 'int', 'double')
        """
        # Convert Java lists to Python lists if necessary
        py_timestamps = list(timestamps) if hasattr(timestamps, '__iter__') else timestamps
        py_values = list(values) if hasattr(values, '__iter__') else values
        
        return self._handler.add_channel(channel_name, py_timestamps, py_values, 
                                         unit, comment, data_type)
    
    # ==================== Channel Read Operations ====================
    
    def getChannelNames(self):
        """Get all channel names"""
        return list(self._handler.get_channel_names())
    
    def getChannelInfo(self, channel_name: str):
        """Get information about a channel"""
        info = self._handler.get_channel_info(channel_name)
        if info is None:
            return None
        return info
    
    def readChannel(self, channel_name: str):
        """
        Read all data from a channel.
        Returns a dictionary with channel data for Java interop.
        """
        record = self._handler.read_channel(channel_name)
        if record is None:
            return None
        
        return {
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }
    
    def readChannelPartial(self, channel_name: str, start_index: int, count: int):
        """
        Partially read data from a channel by index range.
        Returns a dictionary with channel data for Java interop.
        """
        record = self._handler.read_channel_partial(channel_name, start_index, count)
        if record is None:
            return None
        
        return {
            'channelName': record.channel_name,
            'timestamps': record.timestamps,
            'values': record.values,
            'unit': record.unit
        }
    
    def readChannelsPartial(self, channel_names, start_time: float, end_time: float):
        """
        Partially read data from multiple channels within a time range.
        Returns a list of dictionaries with channel data.
        """
        py_channel_names = list(channel_names) if hasattr(channel_names, '__iter__') else channel_names
        records = self._handler.read_channels_partial(py_channel_names, start_time, end_time)
        
        result = []
        for record in records:
            result.append({
                'channelName': record.channel_name,
                'timestamps': record.timestamps,
                'values': record.values,
                'unit': record.unit
            })
        return result
    
    def getSampleCount(self, channel_name: str) -> int:
        """Get the total number of samples for a channel"""
        return self._handler.get_sample_count(channel_name)
    
    def getTimeRange(self):
        """Get the time range of the measurement"""
        return self._handler.get_time_range()
    
    # ==================== Utility Operations ====================
    
    def filterChannels(self, channel_names) -> bool:
        """Filter to keep only specified channels"""
        py_channel_names = list(channel_names) if hasattr(channel_names, '__iter__') else channel_names
        return self._handler.filter_channels(py_channel_names)
    
    def cutTimeRange(self, start_time: float, end_time: float) -> bool:
        """Cut the file to a specific time range"""
        return self._handler.cut_time_range(start_time, end_time)
    
    # ==================== Batch Operations ====================
    
    def writeMultipleChannels(self, channel_data_list):
        """
        Write multiple channels at once.
        
        Args:
            channel_data_list: List of dictionaries containing channel data
                Each dict should have: name, timestamps, values, unit, comment, dataType
        """
        try:
            for channel_data in channel_data_list:
                name = channel_data.get('name')
                timestamps = channel_data.get('timestamps')
                values = channel_data.get('values')
                unit = channel_data.get('unit', '')
                comment = channel_data.get('comment', '')
                data_type = channel_data.get('dataType', 'float')
                
                # Convert Java lists to Python lists
                py_timestamps = list(timestamps) if hasattr(timestamps, '__iter__') else timestamps
                py_values = list(values) if hasattr(values, '__iter__') else values
                
                success = self._handler.add_channel(name, py_timestamps, py_values, 
                                                    unit, comment, data_type)
                if not success:
                    logger.error(f"Failed to add channel: {name}")
                    return False
            
            return True
        except Exception as e:
            logger.error(f"Failed to write multiple channels: {e}")
            return False
    
    def readMultipleChannels(self, channel_names):
        """
        Read multiple channels at once.
        
        Args:
            channel_names: List of channel names to read
            
        Returns:
            List of dictionaries containing channel data
        """
        py_channel_names = list(channel_names) if hasattr(channel_names, '__iter__') else channel_names
        
        result = []
        for channel_name in py_channel_names:
            record = self._handler.read_channel(channel_name)
            if record is not None:
                result.append({
                    'channelName': record.channel_name,
                    'timestamps': record.timestamps,
                    'values': record.values,
                    'unit': record.unit
                })
        return result


def main():
    """Main entry point - starts the Py4J gateway server"""
    
    # Create service instance
    service = Mdf4Service()
    
    # Create and configure gateway server
    # Use port 25333 (default Py4J port)
    gateway_server = GatewayServer(
        entry_point=service,
        port=25333,
        auto_field=True,
        auto_convert=True
    )
    
    try:
        logger.info("Starting MDF4 Py4J Gateway Server on port 25333...")
        gateway_server.start()
        logger.info("Gateway Server started successfully!")
        logger.info("Waiting for Java client connections...")
        logger.info("Press Ctrl+C to stop the server")
        
        # Keep the server running
        gateway_server.get_callback_server().wait_for_connections()
        
    except KeyboardInterrupt:
        logger.info("\nShutting down Gateway Server...")
    except Exception as e:
        logger.error(f"Error running Gateway Server: {e}")
    finally:
        gateway_server.shutdown()
        logger.info("Gateway Server stopped")


if __name__ == "__main__":
    main()
