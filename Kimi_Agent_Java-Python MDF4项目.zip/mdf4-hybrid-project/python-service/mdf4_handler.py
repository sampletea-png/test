"""
MDF4 Handler Module
Core module for MDF4 file operations using asammdf library.
Supports write, read, and partial read operations.
"""

import os
import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from asammdf import MDF, Signal
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ChannelInfo:
    """Channel information data class"""
    name: str
    unit: str
    comment: str
    data_type: str
    samples_count: int


@dataclass
class DataRecord:
    """Data record for transferring between Java and Python"""
    channel_name: str
    timestamps: List[float]
    values: List[float]
    unit: str


class Mdf4Handler:
    """
    Handler class for MDF4 file operations.
    Provides methods for creating, reading, and partially reading MDF4 files.
    """
    
    def __init__(self):
        self._mdf: Optional[MDF] = None
        self._file_path: Optional[str] = None
    
    def create_new_file(self, file_path: str) -> bool:
        """
        Create a new MDF4 file.
        
        Args:
            file_path: Path to the new MDF4 file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            self._mdf = MDF(version='4.10')
            self._file_path = file_path
            logger.info(f"Created new MDF4 file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to create MDF4 file: {e}")
            return False
    
    def open_file(self, file_path: str, read_only: bool = True) -> bool:
        """
        Open an existing MDF4 file.
        
        Args:
            file_path: Path to the MDF4 file
            read_only: Whether to open in read-only mode
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return False
            
            self._mdf = MDF(file_path)
            self._file_path = file_path
            logger.info(f"Opened MDF4 file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to open MDF4 file: {e}")
            return False
    
    def close_file(self) -> bool:
        """
        Close the current MDF4 file.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf:
                self._mdf.close()
                self._mdf = None
                self._file_path = None
                logger.info("Closed MDF4 file")
            return True
        except Exception as e:
            logger.error(f"Failed to close MDF4 file: {e}")
            return False
    
    def add_channel(self, channel_name: str, timestamps: List[float], 
                    values: List[float], unit: str = "", 
                    comment: str = "", data_type: str = "float") -> bool:
        """
        Add a channel to the MDF4 file.
        
        Args:
            channel_name: Name of the channel
            timestamps: List of timestamp values
            values: List of data values
            unit: Unit of measurement
            comment: Channel comment/description
            data_type: Data type ('float', 'int', 'double')
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            # Convert lists to numpy arrays
            timestamps_arr = np.array(timestamps, dtype=np.float64)
            
            # Convert values based on data type
            if data_type == "int":
                values_arr = np.array(values, dtype=np.int32)
            elif data_type == "double":
                values_arr = np.array(values, dtype=np.float64)
            else:
                values_arr = np.array(values, dtype=np.float32)
            
            # Create Signal object
            signal = Signal(
                samples=values_arr,
                timestamps=timestamps_arr,
                name=channel_name,
                unit=unit,
                comment=comment
            )
            
            # Append to MDF file
            self._mdf.append(signal)
            logger.info(f"Added channel: {channel_name} ({len(values)} samples)")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add channel: {e}")
            return False
    
    def save_file(self, file_path: str = None, compression: int = 0) -> bool:
        """
        Save the MDF4 file.
        
        Args:
            file_path: Path to save the file (optional, uses original path if not specified)
            compression: Compression level (0=no compression, 1=fast, 2=standard)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            save_path = file_path or self._file_path
            if not save_path:
                logger.error("No file path specified")
                return False
            
            self._mdf.save(save_path, compression=compression, overwrite=True)
            logger.info(f"Saved MDF4 file: {save_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save MDF4 file: {e}")
            return False
    
    def get_channel_names(self) -> List[str]:
        """
        Get list of all channel names in the file.
        
        Returns:
            List of channel names
        """
        try:
            if self._mdf is None:
                return []
            return self._mdf.channels_db.keys()
        except Exception as e:
            logger.error(f"Failed to get channel names: {e}")
            return []
    
    def get_channel_info(self, channel_name: str) -> Optional[Dict]:
        """
        Get information about a specific channel.
        
        Args:
            channel_name: Name of the channel
            
        Returns:
            Dictionary containing channel information
        """
        try:
            if self._mdf is None:
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                return None
            
            return {
                'name': signal.name,
                'unit': signal.unit,
                'comment': signal.comment,
                'samples_count': len(signal.samples),
                'first_timestamp': float(signal.timestamps[0]) if len(signal.timestamps) > 0 else 0,
                'last_timestamp': float(signal.timestamps[-1]) if len(signal.timestamps) > 0 else 0
            }
        except Exception as e:
            logger.error(f"Failed to get channel info: {e}")
            return None
    
    def read_channel(self, channel_name: str) -> Optional[DataRecord]:
        """
        Read all data from a specific channel.
        
        Args:
            channel_name: Name of the channel to read
            
        Returns:
            DataRecord object containing the data
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                logger.error(f"Channel not found: {channel_name}")
                return None
            
            return DataRecord(
                channel_name=signal.name,
                timestamps=signal.timestamps.tolist(),
                values=signal.samples.tolist(),
                unit=signal.unit
            )
            
        except Exception as e:
            logger.error(f"Failed to read channel: {e}")
            return None
    
    def read_channels_partial(self, channel_names: List[str], 
                              start_time: float, 
                              end_time: float) -> List[DataRecord]:
        """
        Partially read data from multiple channels within a time range.
        
        Args:
            channel_names: List of channel names to read
            start_time: Start timestamp
            end_time: End timestamp
            
        Returns:
            List of DataRecord objects
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return []
            
            results = []
            for channel_name in channel_names:
                signal = self._mdf.get(channel_name)
                if signal is None:
                    logger.warning(f"Channel not found: {channel_name}")
                    continue
                
                # Filter by time range
                mask = (signal.timestamps >= start_time) & (signal.timestamps <= end_time)
                filtered_timestamps = signal.timestamps[mask]
                filtered_values = signal.samples[mask]
                
                if len(filtered_timestamps) > 0:
                    results.append(DataRecord(
                        channel_name=signal.name,
                        timestamps=filtered_timestamps.tolist(),
                        values=filtered_values.tolist(),
                        unit=signal.unit
                    ))
            
            logger.info(f"Partial read: {len(results)} channels, time range [{start_time}, {end_time}]")
            return results
            
        except Exception as e:
            logger.error(f"Failed to read channels partially: {e}")
            return []
    
    def read_channel_partial(self, channel_name: str, 
                            start_index: int, 
                            count: int) -> Optional[DataRecord]:
        """
        Partially read data from a channel by index range.
        
        Args:
            channel_name: Name of the channel
            start_index: Starting sample index
            count: Number of samples to read
            
        Returns:
            DataRecord object containing the partial data
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return None
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                logger.error(f"Channel not found: {channel_name}")
                return None
            
            end_index = min(start_index + count, len(signal.samples))
            
            return DataRecord(
                channel_name=signal.name,
                timestamps=signal.timestamps[start_index:end_index].tolist(),
                values=signal.samples[start_index:end_index].tolist(),
                unit=signal.unit
            )
            
        except Exception as e:
            logger.error(f"Failed to read channel partially: {e}")
            return None
    
    def get_sample_count(self, channel_name: str) -> int:
        """
        Get the total number of samples for a channel.
        
        Args:
            channel_name: Name of the channel
            
        Returns:
            Number of samples
        """
        try:
            if self._mdf is None:
                return 0
            
            signal = self._mdf.get(channel_name)
            if signal is None:
                return 0
            
            return len(signal.samples)
        except Exception as e:
            logger.error(f"Failed to get sample count: {e}")
            return 0
    
    def get_time_range(self) -> Tuple[float, float]:
        """
        Get the time range of the measurement.
        
        Returns:
            Tuple of (start_time, end_time)
        """
        try:
            if self._mdf is None:
                return (0.0, 0.0)
            
            # Get the first master channel's time range
            for channel_name in self._mdf.channels_db.keys():
                signal = self._mdf.get(channel_name)
                if signal is not None and len(signal.timestamps) > 0:
                    return (float(signal.timestamps[0]), float(signal.timestamps[-1]))
            
            return (0.0, 0.0)
        except Exception as e:
            logger.error(f"Failed to get time range: {e}")
            return (0.0, 0.0)
    
    def filter_channels(self, channel_names: List[str]) -> bool:
        """
        Filter the MDF file to keep only specified channels.
        
        Args:
            channel_names: List of channel names to keep
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            self._mdf = self._mdf.filter(channel_names)
            logger.info(f"Filtered to {len(channel_names)} channels")
            return True
            
        except Exception as e:
            logger.error(f"Failed to filter channels: {e}")
            return False
    
    def cut_time_range(self, start_time: float, end_time: float) -> bool:
        """
        Cut the MDF file to a specific time range.
        
        Args:
            start_time: Start timestamp
            end_time: End timestamp
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._mdf is None:
                logger.error("No MDF file is open")
                return False
            
            self._mdf = self._mdf.cut(start=start_time, stop=end_time)
            logger.info(f"Cut to time range [{start_time}, {end_time}]")
            return True
            
        except Exception as e:
            logger.error(f"Failed to cut time range: {e}")
            return False


# Singleton instance for Py4J gateway
_handler_instance = None


def get_handler() -> Mdf4Handler:
    """Get the singleton handler instance"""
    global _handler_instance
    if _handler_instance is None:
        _handler_instance = Mdf4Handler()
    return _handler_instance
