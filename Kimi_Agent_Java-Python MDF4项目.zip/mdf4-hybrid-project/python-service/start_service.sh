#!/bin/bash

# MDF4 Python Service Startup Script
# This script starts the Py4J gateway server for MDF4 operations

echo "========================================"
echo "MDF4 Python Service Starter"
echo "========================================"
echo ""

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    if ! command -v python &> /dev/null; then
        echo "Error: Python is not installed or not in PATH"
        exit 1
    fi
    PYTHON_CMD=python
else
    PYTHON_CMD=python3
fi

echo "Using Python: $PYTHON_CMD"

# Check if required packages are installed
echo "Checking dependencies..."
$PYTHON_CMD -c "import asammdf" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Warning: asammdf not found. Installing dependencies..."
    pip install -r requirements.txt
fi

$PYTHON_CMD -c "import py4j" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Warning: py4j not found. Installing dependencies..."
    pip install -r requirements.txt
fi

echo "Dependencies OK"
echo ""

# Start the service
echo "Starting MDF4 Python Service..."
echo "Press Ctrl+C to stop"
echo ""

$PYTHON_CMD mdf4_service.py
