# MDF4 Hybrid Project - Java & Python

A hybrid Java and Python project for reading and writing MDF4 (Measurement Data Format version 4) files, with support for partial data reading.

## Architecture

```
┌─────────────────┐         Py4J Gateway          ┌──────────────────┐
│   Java Client   │  ◄────────────────────────►  │  Python Service  │
│  (Data Source)  │      Socket Communication     │  (asammdf core)  │
└─────────────────┘                               └──────────────────┘
                                                        │
                                                        ▼
                                                  ┌──────────┐
                                                  │ MDF4 File│
                                                  │ (.mf4)   │
                                                  └──────────┘
```

## Features

### Core Features
- **Create MDF4 files** - Create new MDF4 format files (version 4.10)
- **Write data** - Add channels with timestamps and values
- **Read data** - Read complete channel data or partial data
- **Partial reading** - Read data by index range or time range
- **Batch operations** - Read/write multiple channels at once
- **File metadata** - Get channel info, sample counts, time ranges

### Advanced Features
- **Compression support** - Save files with optional compression
- **Data filtering** - Filter channels by name
- **Time cutting** - Extract data within specific time ranges
- **Multiple data types** - Support for float, double, and integer data

## Project Structure

```
mdf4-hybrid-project/
├── python-service/          # Python service (Py4J + asammdf)
│   ├── mdf4_handler.py      # Core MDF4 operations
│   ├── mdf4_service.py      # Py4J gateway service
│   └── requirements.txt     # Python dependencies
├── java-client/             # Java client library
│   ├── src/main/java/com/mdf4/
│   │   ├── Mdf4Client.java       # Main client class
│   │   ├── DataRecord.java       # Data model
│   │   ├── ChannelInfo.java      # Channel metadata
│   │   ├── ChannelData.java      # Write data model
│   │   ├── Mdf4Exception.java    # Custom exception
│   │   └── Main.java             # Example application
│   ├── src/test/java/com/mdf4/
│   │   └── Mdf4ClientTest.java   # Unit tests
│   └── pom.xml              # Maven configuration
└── README.md                # This file
```

## Prerequisites

### Python Environment
- Python 3.10 or higher
- pip package manager

### Java Environment
- Java 11 or higher
- Maven 3.6 or higher

## Installation

### 1. Clone or Download the Project

```bash
cd mdf4-hybrid-project
```

### 2. Install Python Dependencies

```bash
cd python-service
pip install -r requirements.txt
cd ..
```

### 3. Build Java Client

```bash
cd java-client
mvn clean package
cd ..
```

## Usage

### Step 1: Start the Python Service

The Python service acts as a gateway that the Java client connects to.

```bash
cd python-service
python mdf4_service.py
```

You should see output like:
```
Starting MDF4 Py4J Gateway Server on port 25333...
Gateway Server started successfully!
Waiting for Java client connections...
Press Ctrl+C to stop the server
```

### Step 2: Run the Java Example

In a new terminal:

```bash
cd java-client
java -jar target/mdf4-java-client-1.0.0.jar
```

Or run with Maven:

```bash
cd java-client
mvn exec:java -Dexec.mainClass="com.mdf4.Main"
```

## Java API Usage Examples

### Basic Operations

```java
// Create client and connect
Mdf4Client client = new Mdf4Client("localhost", 25333);
client.connect();

// Create a new MDF4 file
client.createNewFile("data.mf4");

// Add a channel with data
List<Double> timestamps = Arrays.asList(0.0, 0.1, 0.2, 0.3);
List<Double> values = Arrays.asList(10.0, 20.0, 30.0, 40.0);
client.addChannel("Temperature", timestamps, values, "°C", "Engine temp", "float");

// Save and close
client.saveFile();
client.closeFile();
```

### Reading Data

```java
// Open existing file
client.openFile("data.mf4");

// Read full channel
DataRecord record = client.readChannel("Temperature");
System.out.println("Values: " + record.getValues());
System.out.println("Timestamps: " + record.getTimestamps());

// Partial read by index (read samples 100-199)
DataRecord partial = client.readChannelPartial("Temperature", 100, 100);

// Partial read by time range (read 2.0s to 5.0s)
List<String> channels = Arrays.asList("Temperature", "Pressure");
List<DataRecord> records = client.readChannelsPartial(channels, 2.0, 5.0);
```

### Batch Operations

```java
// Write multiple channels at once
List<ChannelData> channelList = new ArrayList<>();

channelList.add(ChannelData.builder()
    .name("Speed")
    .timestamps(timestamps1)
    .values(values1)
    .unit("km/h")
    .build());

channelList.add(ChannelData.builder()
    .name("RPM")
    .timestamps(timestamps2)
    .values(values2)
    .unit("rpm")
    .build());

client.writeMultipleChannels(channelList);

// Read multiple channels at once
List<String> names = Arrays.asList("Speed", "RPM");
List<DataRecord> records = client.readMultipleChannels(names);
```

### Using Try-With-Resources

```java
try (Mdf4Client client = new Mdf4Client()) {
    client.connect();
    client.openFile("data.mf4");
    
    // Perform operations...
    DataRecord record = client.readChannel("Temperature");
    
} catch (Mdf4Exception e) {
    e.printStackTrace();
}
// Client automatically disconnects
```

## API Reference

### Mdf4Client Methods

#### File Operations
| Method | Description |
|--------|-------------|
| `connect()` | Connect to Python service |
| `disconnect()` | Disconnect from service |
| `createNewFile(path)` | Create new MDF4 file |
| `openFile(path)` | Open existing file (read-only) |
| `openFile(path, readOnly)` | Open file with mode |
| `closeFile()` | Close current file |
| `saveFile()` | Save file |
| `saveFile(path, compression)` | Save with options |

#### Write Operations
| Method | Description |
|--------|-------------|
| `addChannel(name, timestamps, values)` | Add channel (minimal) |
| `addChannel(name, timestamps, values, unit, comment, dataType)` | Add channel (full) |
| `writeMultipleChannels(channelDataList)` | Batch write |

#### Read Operations
| Method | Description |
|--------|-------------|
| `getChannelNames()` | Get all channel names |
| `getChannelInfo(name)` | Get channel metadata |
| `readChannel(name)` | Read full channel |
| `readMultipleChannels(names)` | Batch read |
| `readChannelPartial(name, startIndex, count)` | Partial by index |
| `readChannelsPartial(names, startTime, endTime)` | Partial by time |
| `getSampleCount(name)` | Get total samples |
| `getTimeRange()` | Get overall time range |

#### Utility Operations
| Method | Description |
|--------|-------------|
| `filterChannels(names)` | Keep only specified channels |
| `cutTimeRange(start, end)` | Extract time range |

## Partial Reading

The project supports two types of partial reading:

### 1. Index-Based Partial Read

Read a specific range of samples by index:

```java
// Read 100 samples starting from index 500
DataRecord partial = client.readChannelPartial("EngineSpeed", 500, 100);
```

Useful for:
- Pagination of large datasets
- Memory-efficient processing
- Sequential data processing

### 2. Time-Based Partial Read

Read data within a specific time range:

```java
// Read all channels between 10.0 and 20.0 seconds
List<String> channels = Arrays.asList("Speed", "RPM", "Temperature");
List<DataRecord> records = client.readChannelsPartial(channels, 10.0, 20.0);
```

Useful for:
- Extracting specific time periods
- Event-based analysis
- Time-synchronized data extraction

## Running Tests

### Start Python Service First

```bash
cd python-service
python mdf4_service.py
```

### Run Java Tests

In a new terminal:

```bash
cd java-client
mvn test
```

## Data Types

Supported data types for channel values:

| Type | Description |
|------|-------------|
| `"float"` | 32-bit floating point (default) |
| `"double"` | 64-bit floating point |
| `"int"` | 32-bit integer |

## Error Handling

All operations throw `Mdf4Exception` on failure:

```java
try {
    client.connect();
    client.openFile("data.mf4");
    DataRecord record = client.readChannel("Temperature");
} catch (Mdf4Exception e) {
    System.err.println("MDF4 Error: " + e.getMessage());
    e.printStackTrace();
}
```

Common errors:
- Connection failed (Python service not running)
- File not found
- Channel not found
- Invalid data format

## Performance Considerations

### Memory Usage
- Full reads load entire channel into memory
- Partial reads are memory-efficient
- Use `readChannelPartial()` for large files

### Network Communication
- Each method call involves network round-trip
- Batch operations reduce network overhead
- Keep connection open for multiple operations

### File I/O
- Python service performs actual file operations
- Java client sends commands via Py4J
- Compression reduces file size but increases CPU usage

## Troubleshooting

### Connection Refused
```
Mdf4Exception: Failed to connect to Python service
```
**Solution**: Start the Python service first:
```bash
python python-service/mdf4_service.py
```

### Module Not Found
```
ModuleNotFoundError: No module named 'asammdf'
```
**Solution**: Install Python dependencies:
```bash
pip install -r python-service/requirements.txt
```

### Port Already in Use
```
Address already in use: 25333
```
**Solution**: Kill existing Python service or change port:
```java
Mdf4Client client = new Mdf4Client("localhost", 25334);
```

## Dependencies

### Python
- `asammdf` >= 7.3.0 - MDF4 file operations
- `py4j` >= 0.10.9 - Java-Python bridge
- `numpy` >= 1.21.0 - Numerical computing

### Java
- `py4j` >= 0.10.9.7 - Java-Python bridge
- Java 11 or higher

## License

This project is provided as-is for educational and development purposes.

## Resources

- [ASAM MDF Specification](https://www.asam.net/standards/detail/mdf/)
- [asammdf Documentation](https://asammdf.readthedocs.io/)
- [Py4J Documentation](https://www.py4j.org/)

## Contributing

Feel free to submit issues or enhancements for this project.
