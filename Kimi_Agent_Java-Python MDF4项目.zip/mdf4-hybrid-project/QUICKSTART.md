# MDF4 Hybrid Project - Quick Start Guide

## 5-Minute Quick Start

### Step 1: Install Python Dependencies (1 minute)

```bash
cd python-service
pip install -r requirements.txt
cd ..
```

### Step 2: Build Java Client (1 minute)

```bash
cd java-client
mvn clean package -DskipTests
cd ..
```

### Step 3: Start Python Service (Terminal 1)

```bash
cd python-service
python mdf4_service.py
```

You should see:
```
Starting MDF4 Py4J Gateway Server on port 25333...
Gateway Server started successfully!
Waiting for Java client connections...
```

### Step 4: Run Example (Terminal 2)

```bash
cd java-client
java -jar target/mdf4-java-client-1.0.0.jar
```

## Quick Code Example

### Java Side

```java
// Create client and connect
Mdf4Client client = new Mdf4Client();
client.connect();

// Create file and write data
client.createNewFile("data.mf4");

List<Double> timestamps = Arrays.asList(0.0, 0.1, 0.2, 0.3);
List<Double> values = Arrays.asList(10.0, 20.0, 30.0, 40.0);

client.addChannel("Temperature", timestamps, values, "°C", "", "float");
client.saveFile();

// Read data back
client.closeFile();
client.openFile("data.mf4");

DataRecord record = client.readChannel("Temperature");
System.out.println("Values: " + record.getValues());

// Partial read (samples 1-3)
DataRecord partial = client.readChannelPartial("Temperature", 1, 3);

// Partial read by time (0.1s to 0.2s)
List<DataRecord> timeSlice = client.readChannelsPartial(
    Arrays.asList("Temperature"), 0.1, 0.2);

client.disconnect();
```

## Common Operations

### Write Operations

```java
// Single channel
client.addChannel("Speed", timestamps, values, "km/h", "Vehicle speed", "float");

// Multiple channels
List<ChannelData> channels = Arrays.asList(
    ChannelData.builder()
        .name("RPM").timestamps(ts1).values(v1).unit("rpm").build(),
    ChannelData.builder()
        .name("Temp").timestamps(ts2).values(v2).unit("°C").build()
);
client.writeMultipleChannels(channels);
```

### Read Operations

```java
// Full read
DataRecord record = client.readChannel("Speed");

// Partial by index (100 samples starting from index 500)
DataRecord partial = client.readChannelPartial("Speed", 500, 100);

// Partial by time (2.0s to 5.0s)
List<DataRecord> records = client.readChannelsPartial(
    Arrays.asList("Speed", "RPM"), 2.0, 5.0);

// Batch read
List<DataRecord> all = client.readMultipleChannels(
    Arrays.asList("Speed", "RPM", "Temp"));
```

### File Information

```java
// Get all channel names
List<String> names = client.getChannelNames();

// Get channel info
ChannelInfo info = client.getChannelInfo("Speed");
System.out.println("Samples: " + info.getSamplesCount());
System.out.println("Rate: " + info.getAverageSampleRate() + " Hz");

// Get time range
double[] range = client.getTimeRange();
System.out.println("Duration: " + (range[1] - range[0]) + " seconds");
```

## Troubleshooting

### "Failed to connect to Python service"

**Solution**: Start the Python service first:
```bash
cd python-service
python mdf4_service.py
```

### "ModuleNotFoundError: No module named 'asammdf'"

**Solution**: Install dependencies:
```bash
pip install asammdf py4j numpy
```

### "Address already in use: 25333"

**Solution**: Kill existing Python service or use different port:
```java
Mdf4Client client = new Mdf4Client("localhost", 25334);
```

## Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Check the [VehicleDataExample.java](java-client/src/main/java/com/mdf4/VehicleDataExample.java) for advanced usage
- Run the tests: `mvn test`
