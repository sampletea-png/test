#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4转换工具
将CSV文件转换为ASAM MDF4格式

用法:
    python mdf4_converter.py <input_csv> <output_mf4>

示例:
    python mdf4_converter.py data.csv data.mf4
"""

import sys
import csv
from pathlib import Path

try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False
    print("错误: 未安装asammdf库")
    print("请运行: pip install asammdf numpy")
    sys.exit(1)


def csv_to_mdf4(csv_path: str, mdf4_path: str):
    """将CSV文件转换为MDF4格式"""
    
    csv_file = Path(csv_path)
    mdf4_file = Path(mdf4_path)
    
    if not csv_file.exists():
        print(f"错误: CSV文件不存在: {csv_path}")
        sys.exit(1)
    
    print(f"读取CSV文件: {csv_path}")
    
    # 读取CSV数据
    data = {
        'timestamps': [],
        'vehicle_speed': [],
        'engine_rpm': [],
        'engine_temp': [],
        'throttle_position': [],
        'brake_position': [],
        'steering_angle': [],
        'battery_voltage': [],
        'fuel_level': [],
        'odometer': [],
        'accel_x': [],
        'accel_y': [],
        'accel_z': []
    }
    
    # 单位映射
    units = {
        'vehicle_speed': 'km/h',
        'engine_rpm': 'rpm',
        'engine_temp': '°C',
        'throttle_position': '%',
        'brake_position': '%',
        'steering_angle': '°',
        'battery_voltage': 'V',
        'fuel_level': '%',
        'odometer': 'km',
        'accel_x': 'm/s²',
        'accel_y': 'm/s²',
        'accel_z': 'm/s²'
    }
    
    row_count = 0
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        
        for row in reader:
            # 时间戳转换为秒
            timestamp_ms = int(row.get('timestamp', 0))
            data['timestamps'].append(timestamp_ms / 1000.0)
            
            # 读取各字段
            data['vehicle_speed'].append(float(row.get('vehicle_speed', 0)))
            data['engine_rpm'].append(float(row.get('engine_rpm', 0)))
            data['engine_temp'].append(float(row.get('engine_temp', 0)))
            data['throttle_position'].append(float(row.get('throttle_position', 0)))
            data['brake_position'].append(float(row.get('brake_position', 0)))
            data['steering_angle'].append(float(row.get('steering_angle', 0)))
            data['battery_voltage'].append(float(row.get('battery_voltage', 0)))
            data['fuel_level'].append(float(row.get('fuel_level', 0)))
            data['odometer'].append(float(row.get('odometer', 0)))
            data['accel_x'].append(float(row.get('accel_x', 0)))
            data['accel_y'].append(float(row.get('accel_y', 0)))
            data['accel_z'].append(float(row.get('accel_z', 0)))
            
            row_count += 1
            
            if row_count % 10000 == 0:
                print(f"  已读取 {row_count} 行...")
    
    print(f"共读取 {row_count} 行数据")
    
    # 创建MDF4文件
    print(f"创建MDF4文件: {mdf4_path}")
    mdf = MDF(version='4.10')
    
    # 创建信号列表
    signals = []
    timestamps = np.array(data['timestamps'], dtype=np.float64)
    
    for name in ['vehicle_speed', 'engine_rpm', 'engine_temp', 'throttle_position',
                 'brake_position', 'steering_angle', 'battery_voltage', 'fuel_level',
                 'odometer', 'accel_x', 'accel_y', 'accel_z']:
        
        values = np.array(data[name], dtype=np.float64)
        signal = Signal(
            samples=values,
            timestamps=timestamps,
            name=name,
            unit=units.get(name, '')
        )
        signals.append(signal)
    
    # 追加到MDF文件
    mdf.append(signals)
    
    # 保存文件
    mdf.save(str(mdf4_file), overwrite=True)
    mdf.close()
    
    file_size = mdf4_file.stat().st_size / (1024 * 1024)
    print(f"MDF4文件已保存: {mdf4_path}")
    print(f"  文件大小: {file_size:.2f} MB")
    print(f"  信号数量: {len(signals)}")
    print(f"  数据点数: {row_count}")


def main():
    if len(sys.argv) != 3:
        print("用法: python mdf4_converter.py <input_csv> <output_mf4>")
        print("示例: python mdf4_converter.py data.csv data.mf4")
        sys.exit(1)
    
    input_csv = sys.argv[1]
    output_mdf4 = sys.argv[2]
    
    try:
        csv_to_mdf4(input_csv, output_mdf4)
    except Exception as e:
        print(f"转换失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
