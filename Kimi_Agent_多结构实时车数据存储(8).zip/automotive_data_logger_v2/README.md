# 汽车数据实时记录系统 V2 (Java为主)

一个基于Java的实时汽车数据记录工具，支持多种存储格式。Java实现主要功能，Python仅作为MDF4格式的补充。

## 架构特点

```
┌─────────────────────────────────────────────────────────────┐
│                      Java 应用程序                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ 数据模拟器    │  │  实时GUI弹窗  │  │  数据记录服务    │  │
│  │ (100Hz)      │  │  (Swing)     │  │  ─────────────── │  │
│  └──────┬───────┘  └──────┬───────┘  │  - 格式管理      │  │
│         │                 │          │  - 存储切换      │  │
│         └─────────────────┴─────────▶│  - 文件分割      │  │
│                           │          └────────┬─────────┘  │
│                           │                   │            │
│                    数据分发 (VehicleData)      │            │
└───────────────────────────┼───────────────────┼────────────┘
                            │                   │
                            │    ┌──────────────┼────────────┐
                            │    │              │            │
                            ▼    ▼              ▼            ▼
                    ┌─────────────────────────────────────────────────┐
                    │              Java 存储实现                        │
                    │  ┌─────────┐ ┌─────────┐ ┌─────────┐           │
                    │  │  CSV    │ │  JSON   │ │ SQLite  │ (原生支持) │
                    │  └─────────┘ └─────────┘ └─────────┘           │
                    │  ┌─────────┐                                      │
                    │  │  MDF4   │ (通过Process调用Python转换)         │
                    │  └─────────┘                                      │
                    └─────────────────────────────────────────────────┘
```

## 功能特性

### Java原生支持的格式

| 格式 | 扩展名 | 特点 | 依赖 |
|------|--------|------|------|
| **CSV** | .csv | 通用格式，易读易处理 | 无 |
| **JSON** | .json | 结构化数据，Web友好 | Gson |
| **SQLite** | .db | 关系型数据库，支持SQL查询 | sqlite-jdbc |

### Python辅助的格式

| 格式 | 扩展名 | 特点 | 依赖 |
|------|--------|------|------|
| **MDF4** | .mf4 | ASAM标准，行业通用 | asammdf |

### 核心功能
- **100Hz数据模拟**：车速、发动机转速、温度等15+信号
- **实时GUI展示**：深色主题，数据实时更新
- **格式动态切换**：运行时切换存储格式
- **文件自动分割**：按大小或时间自动分割
- **批量写入优化**：缓冲区机制提高性能

## 环境要求

### Java环境
- **JDK**: 11 或更高版本
- **Maven**: 3.6+

### Python环境（仅MDF4格式需要）
- **Python**: 3.8+
- **asammdf**: `pip install asammdf numpy`

## 快速开始

### 1. 编译项目

```bash
cd java
mvn clean package
cd ..
```

### 2. 启动应用

```bash
java -jar java/target/automotive-data-logger-2.0.0.jar
```

### 3. 使用界面

1. 从下拉框选择存储格式
2. 点击 **"开始记录"** 按钮
3. 观察实时数据变化
4. 可随时点击 **"切换格式"** 切换存储格式
5. 点击 **"停止记录"** 按钮结束

## 项目结构

```
automotive_data_logger_v2/
├── README.md
├── java/
│   ├── pom.xml
│   └── src/main/java/com/automotive/logger/
│       ├── model/
│       │   └── VehicleData.java
│       ├── service/
│       │   ├── DataSimulatorService.java
│       │   └── DataLoggerService.java
│       ├── storage/
│       │   ├── StorageInterface.java
│       │   ├── StorageConfig.java
│       │   ├── StorageFactory.java
│       │   ├── BaseStorage.java
│       │   ├── CsvStorage.java
│       │   ├── JsonStorage.java
│       │   ├── SqliteStorage.java
│       │   └── Mdf4Storage.java
│       └── gui/
│           └── RealTimeDataDisplay.java
└── python/
    └── mdf4_converter.py    # MDF4转换工具
```

## 存储格式对比

| 格式 | 写入速度 | 文件大小 | 查询能力 | 兼容性 |
|------|----------|----------|----------|--------|
| CSV | ★★★☆☆ | ★☆☆☆☆ | ★☆☆☆☆ | ★★★★★ |
| JSON | ★★★☆☆ | ★☆☆☆☆ | ★★☆☆☆ | ★★★★☆ |
| SQLite | ★★☆☆☆ | ★★★☆☆ | ★★★★★ | ★★★☆☆ |
| MDF4 | ★★★★☆ | ★★★☆☆ | ★★☆☆☆ | ★★★★★ |

## 扩展新的存储格式

### 1. 实现StorageInterface接口

```java
public class MyFormatStorage extends BaseStorage {
    
    public MyFormatStorage(StorageConfig config) {
        super(config);
    }
    
    @Override
    public String getFormatName() { return "myformat"; }
    
    @Override
    public String getFileExtension() { return "my"; }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        // 实现打开文件
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        // 实现写入数据
    }
    
    // ... 其他抽象方法
}
```

### 2. 注册到工厂

```java
StorageFactory.getInstance().register(
    "myformat",
    MyFormatStorage::new,
    new FormatInfo("myformat", "my", true, false, "我的格式")
);
```

## 配置选项

```java
StorageConfig config = new StorageConfig();
config.setOutputDir(Paths.get("output"));
config.setFilenamePrefix("vehicle_data");
config.setBatchSize(100);
config.setMaxFileSizeMb(100);        // 100MB自动分割
config.setSplitIntervalMinutes(60);  // 1小时自动分割
config.setCompression("gzip");       // GZIP压缩
```

## 技术特点

### 1. 策略模式
- `StorageInterface` 定义统一接口
- 各格式实现具体逻辑
- 工厂模式创建实例

### 2. 模板方法模式
- `BaseStorage` 提供通用功能（缓冲、文件分割）
- 子类只需实现具体读写方法

### 3. Java调用Python
- MDF4格式通过 `ProcessBuilder` 调用Python
- 临时CSV文件作为中间格式
- 转换完成后自动清理

## 与V1版本对比

| 特性 | V1 (Python为主) | V2 (Java为主) |
|------|-----------------|---------------|
| 架构 | Socket通信 | Java原生调用 |
| 依赖 | Python服务常驻 | Python仅MDF4时调用 |
| 性能 | 网络开销 | 本地处理 |
| 复杂度 | 高 | 低 |
| 扩展性 | 需修改两端 | 只需Java端 |

## 许可证

MIT License
