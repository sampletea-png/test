#!/bin/bash
# 汽车数据记录系统启动脚本 (Linux/macOS)

set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   汽车数据实时记录系统 V4${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# 检查Java
if ! command -v java &> /dev/null; then
    echo -e "${RED}错误: 未找到Java，请安装JDK 17+${NC}"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
if [[ "$JAVA_VERSION" -lt 17 ]]; then
    echo -e "${RED}错误: 需要JDK 17或更高版本，当前版本: $JAVA_VERSION${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Java版本: $(java -version 2>&1 | head -n 1)${NC}"

# 检查Maven
if ! command -v mvn &> /dev/null; then
    echo -e "${RED}错误: 未找到Maven，请安装Maven 3.6+${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Maven版本: $(mvn -version | head -n 1)${NC}"

# 检查Python和asammdf（用于MDF4格式）
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${YELLOW}警告: 未找到Python，MDF4格式将无法使用${NC}"
    PYTHON_CMD=""
fi

if [ -n "$PYTHON_CMD" ]; then
    if $PYTHON_CMD -c "import asammdf" 2>/dev/null; then
        echo -e "${GREEN}✓ asammdf已安装${NC}"
    else
        echo -e "${YELLOW}警告: asammdf未安装，MDF4格式将无法使用${NC}"
        echo -e "${YELLOW}  运行: pip install asammdf numpy${NC}"
    fi
fi

echo ""

# 进入Java项目目录
cd "$PROJECT_DIR/java"

# 检查是否需要编译
JAR_FILE="target/automotive-data-logger-4.0.0.jar"

if [ ! -f "$JAR_FILE" ]; then
    echo -e "${YELLOW}正在编译项目...${NC}"
    mvn clean package -q
    echo -e "${GREEN}✓ 编译完成${NC}"
else
    echo -e "${GREEN}✓ 使用已编译的JAR文件${NC}"
fi

echo ""
echo -e "${GREEN}启动应用...${NC}"
echo ""

# 运行应用
java -jar "$JAR_FILE"
