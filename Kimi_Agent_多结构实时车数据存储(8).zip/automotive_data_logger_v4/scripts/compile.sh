#!/bin/bash
# 手动编译脚本（无需Maven）

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
JAVA_DIR="$PROJECT_DIR/java"

echo "========================================"
echo "   汽车数据记录系统 - 手动编译"
echo "========================================"
echo ""

# 创建输出目录
mkdir -p "$JAVA_DIR/target/classes"

# 下载依赖JAR
echo "下载依赖..."
DEPS_DIR="$JAVA_DIR/target/deps"
mkdir -p "$DEPS_DIR"

# 下载GSON
if [ ! -f "$DEPS_DIR/gson-2.10.1.jar" ]; then
    curl -sL -o "$DEPS_DIR/gson-2.10.1.jar" \
        "https://repo1.maven.org/maven2/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"
    echo "✓ gson-2.10.1.jar"
fi

# 下载SQLite JDBC
if [ ! -f "$DEPS_DIR/sqlite-jdbc-3.44.1.0.jar" ]; then
    curl -sL -o "$DEPS_DIR/sqlite-jdbc-3.44.1.0.jar" \
        "https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.44.1.0/sqlite-jdbc-3.44.1.0.jar"
    echo "✓ sqlite-jdbc-3.44.1.0.jar"
fi

# 下载JavaFX (Linux x64)
JAVAFX_VERSION="19"
if [ ! -f "$DEPS_DIR/javafx-base-$JAVAFX_VERSION.jar" ]; then
    for module in base controls graphics; do
        curl -sL -o "$DEPS_DIR/javafx-$module-$JAVAFX_VERSION.jar" \
            "https://repo1.maven.org/maven2/org/openjfx/javafx-$module/$JAVAFX_VERSION/javafx-$module-$JAVAFX_VERSION-linux.jar"
        echo "✓ javafx-$module-$JAVAFX_VERSION.jar"
    done
fi

# 构建classpath
CLASSPATH="$DEPS_DIR/*"

echo ""
echo "编译Java源代码..."

# 编译所有Java文件
find "$JAVA_DIR/src/main/java" -name "*.java" > "$JAVA_DIR/sources.txt"
javac -cp "$CLASSPATH" -d "$JAVA_DIR/target/classes" @$JAVA_DIR/sources.txt

rm "$JAVA_DIR/sources.txt"

echo "✓ 编译完成"
echo ""
echo "类文件位置: $JAVA_DIR/target/classes"
