package com.automotive.logger.data;

import com.automotive.logger.model.VehicleData;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * 数据缓冲区 - 管理实时和历史数据
 * 支持滑动窗口、数据回放等功能
 */
public class DataBuffer {
    
    // 最大缓存数据点数（用于图表显示）
    private static final int MAX_CHART_POINTS = 1000;
    
    // 环形缓冲区 - 存储最近的数据
    private final LinkedList<VehicleData> ringBuffer;
    
    // 所有历史数据（可选，用于回放）
    private final List<VehicleData> historyData;
    
    // 是否保存完整历史
    private final boolean saveFullHistory;
    
    // 数据更新监听器
    private final List<Consumer<List<VehicleData>>> dataListeners;
    
    // 信号选择监听器
    private final List<Consumer<List<String>>> signalSelectionListeners;
    
    // 当前选中的信号
    private final Set<String> selectedSignals;
    
    // 可用信号列表
    private static final List<String> AVAILABLE_SIGNALS = Arrays.asList(
        "vehicleSpeed",
        "engineRpm",
        "engineTemp",
        "throttlePosition",
        "brakePosition",
        "steeringAngle",
        "batteryVoltage",
        "fuelLevel",
        "odometer",
        "accelX",
        "accelY",
        "accelZ"
    );
    
    // 信号显示名称映射
    private static final Map<String, String> SIGNAL_DISPLAY_NAMES = new HashMap<>();
    static {
        SIGNAL_DISPLAY_NAMES.put("vehicleSpeed", "车速 (km/h)");
        SIGNAL_DISPLAY_NAMES.put("engineRpm", "发动机转速 (RPM)");
        SIGNAL_DISPLAY_NAMES.put("engineTemp", "发动机温度 (°C)");
        SIGNAL_DISPLAY_NAMES.put("throttlePosition", "油门位置 (%)");
        SIGNAL_DISPLAY_NAMES.put("brakePosition", "刹车位置 (%)");
        SIGNAL_DISPLAY_NAMES.put("steeringAngle", "方向盘角度 (°)");
        SIGNAL_DISPLAY_NAMES.put("batteryVoltage", "电池电压 (V)");
        SIGNAL_DISPLAY_NAMES.put("fuelLevel", "燃油液位 (%)");
        SIGNAL_DISPLAY_NAMES.put("odometer", "里程表 (km)");
        SIGNAL_DISPLAY_NAMES.put("accelX", "横向加速度 (m/s²)");
        SIGNAL_DISPLAY_NAMES.put("accelY", "纵向加速度 (m/s²)");
        SIGNAL_DISPLAY_NAMES.put("accelZ", "垂直加速度 (m/s²)");
    }
    
    public DataBuffer() {
        this(false);
    }
    
    public DataBuffer(boolean saveFullHistory) {
        this.saveFullHistory = saveFullHistory;
        this.ringBuffer = new LinkedList<>();
        this.historyData = saveFullHistory ? new ArrayList<>() : null;
        this.dataListeners = new CopyOnWriteArrayList<>();
        this.signalSelectionListeners = new CopyOnWriteArrayList<>();
        this.selectedSignals = new HashSet<>();
        
        // 默认选中几个常用信号
        selectedSignals.add("vehicleSpeed");
        selectedSignals.add("engineRpm");
        selectedSignals.add("engineTemp");
    }
    
    /**
     * 添加数据点
     */
    public synchronized void addData(VehicleData data) {
        // 添加到环形缓冲区
        ringBuffer.addLast(data);
        
        // 保持缓冲区大小
        while (ringBuffer.size() > MAX_CHART_POINTS) {
            ringBuffer.removeFirst();
        }
        
        // 保存完整历史（如果需要）
        if (saveFullHistory && historyData != null) {
            historyData.add(data);
        }
        
        // 通知监听器
        notifyDataListeners();
    }
    
    /**
     * 批量添加数据
     */
    public synchronized void addBatch(List<VehicleData> dataList) {
        for (VehicleData data : dataList) {
            ringBuffer.addLast(data);
        }
        
        // 保持缓冲区大小
        while (ringBuffer.size() > MAX_CHART_POINTS) {
            ringBuffer.removeFirst();
        }
        
        // 保存完整历史
        if (saveFullHistory && historyData != null) {
            historyData.addAll(dataList);
        }
        
        notifyDataListeners();
    }
    
    /**
     * 获取当前缓冲区数据（用于图表）
     */
    public synchronized List<VehicleData> getChartData() {
        return new ArrayList<>(ringBuffer);
    }
    
    /**
     * 获取指定时间范围的数据
     */
    public synchronized List<VehicleData> getDataInTimeRange(long startTime, long endTime) {
        List<VehicleData> result = new ArrayList<>();
        for (VehicleData data : ringBuffer) {
            if (data.getTimestamp() >= startTime && data.getTimestamp() <= endTime) {
                result.add(data);
            }
        }
        return result;
    }
    
    /**
     * 获取最新数据点
     */
    public synchronized VehicleData getLatestData() {
        return ringBuffer.isEmpty() ? null : ringBuffer.getLast();
    }
    
    /**
     * 获取数据点数量
     */
    public synchronized int getDataCount() {
        return ringBuffer.size();
    }
    
    /**
     * 清空缓冲区
     */
    public synchronized void clear() {
        ringBuffer.clear();
        if (historyData != null) {
            historyData.clear();
        }
    }
    
    /**
     * 获取可用信号列表
     */
    public static List<String> getAvailableSignals() {
        return new ArrayList<>(AVAILABLE_SIGNALS);
    }
    
    /**
     * 获取信号显示名称
     */
    public static String getSignalDisplayName(String signal) {
        return SIGNAL_DISPLAY_NAMES.getOrDefault(signal, signal);
    }
    
    /**
     * 获取信号单位
     */
    public static String getSignalUnit(String signal) {
        String displayName = SIGNAL_DISPLAY_NAMES.getOrDefault(signal, "");
        int start = displayName.indexOf('(');
        int end = displayName.indexOf(')');
        if (start >= 0 && end > start) {
            return displayName.substring(start + 1, end);
        }
        return "";
    }
    
    /**
     * 获取选中信号的值
     */
    public double getSignalValue(VehicleData data, String signal) {
        switch (signal) {
            case "vehicleSpeed": return data.getVehicleSpeed();
            case "engineRpm": return data.getEngineRpm();
            case "engineTemp": return data.getEngineTemp();
            case "throttlePosition": return data.getThrottlePosition();
            case "brakePosition": return data.getBrakePosition();
            case "steeringAngle": return data.getSteeringAngle();
            case "batteryVoltage": return data.getBatteryVoltage();
            case "fuelLevel": return data.getFuelLevel();
            case "odometer": return data.getOdometer();
            case "accelX": return data.getAccelX();
            case "accelY": return data.getAccelY();
            case "accelZ": return data.getAccelZ();
            default: return 0.0;
        }
    }
    
    /**
     * 选择信号
     */
    public void selectSignal(String signal) {
        if (AVAILABLE_SIGNALS.contains(signal)) {
            selectedSignals.add(signal);
            notifySignalSelectionListeners();
        }
    }
    
    /**
     * 取消选择信号
     */
    public void deselectSignal(String signal) {
        selectedSignals.remove(signal);
        notifySignalSelectionListeners();
    }
    
    /**
     * 切换信号选择状态
     */
    public void toggleSignal(String signal) {
        if (selectedSignals.contains(signal)) {
            deselectSignal(signal);
        } else {
            selectSignal(signal);
        }
    }
    
    /**
     * 设置选中的信号
     */
    public void setSelectedSignals(List<String> signals) {
        selectedSignals.clear();
        for (String signal : signals) {
            if (AVAILABLE_SIGNALS.contains(signal)) {
                selectedSignals.add(signal);
            }
        }
        notifySignalSelectionListeners();
    }
    
    /**
     * 获取选中的信号
     */
    public List<String> getSelectedSignals() {
        return new ArrayList<>(selectedSignals);
    }
    
    /**
     * 添加数据监听器
     */
    public void addDataListener(Consumer<List<VehicleData>> listener) {
        dataListeners.add(listener);
    }
    
    /**
     * 移除数据监听器
     */
    public void removeDataListener(Consumer<List<VehicleData>> listener) {
        dataListeners.remove(listener);
    }
    
    /**
     * 添加信号选择监听器
     */
    public void addSignalSelectionListener(Consumer<List<String>> listener) {
        signalSelectionListeners.add(listener);
    }
    
    /**
     * 移除信号选择监听器
     */
    public void removeSignalSelectionListener(Consumer<List<String>> listener) {
        signalSelectionListeners.remove(listener);
    }
    
    private void notifyDataListeners() {
        List<VehicleData> dataCopy = getChartData();
        for (Consumer<List<VehicleData>> listener : dataListeners) {
            try {
                listener.accept(dataCopy);
            } catch (Exception e) {
                System.err.println("数据监听器异常: " + e.getMessage());
            }
        }
    }
    
    private void notifySignalSelectionListeners() {
        List<String> signals = getSelectedSignals();
        for (Consumer<List<String>> listener : signalSelectionListeners) {
            try {
                listener.accept(signals);
            } catch (Exception e) {
                System.err.println("信号选择监听器异常: " + e.getMessage());
            }
        }
    }
}
