package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;
import com.google.gson.Gson;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

/**
 * MDF4存储格式实现 - 支持GB级大文件直接内存读写
 * 
 * 特性：
 * 1. 写入：内存数据直接流式写入MDF4，无中间文件
 * 2. 读取：支持迭代器分块读取，避免内存溢出
 * 3. 大文件：支持GB级文件的高效读写
 */
public class Mdf4Storage extends BaseStorage {
    
    private final Gson gson;
    
    // Python进程
    private Process pythonProcess;
    private PrintWriter processWriter;
    private BufferedReader processReader;
    private DataInputStream processDataInput;
    
    // Python脚本路径
    private String pythonScriptPath = "python/mdf4_writer_stream.py";
    private String pythonExecutable = "python3";
    
    // 读取模式
    private boolean readMode = false;
    private Path readFilePath;
    
    // 大文件分块读取配置
    private static final int DEFAULT_CHUNK_SIZE = 10000; // 每次读取1万条记录
    private int chunkSize = DEFAULT_CHUNK_SIZE;
    
    // 文件信息缓存
    private long cachedRecordCount = -1;
    private long[] cachedTimeRange = null;
    
    public Mdf4Storage(StorageConfig config) {
        super(config);
        this.gson = new Gson();
        
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            pythonExecutable = "python";
        }
        
        // 从配置读取分块大小
        Object chunkSizeOption = config.getOption("mdf4.chunkSize");
        if (chunkSizeOption != null) {
            this.chunkSize = ((Number) chunkSizeOption).intValue();
        }
    }
    
    @Override
    public String getFormatName() {
        return "mdf4";
    }
    
    @Override
    public String getFileExtension() {
        return "mf4";
    }
    
    @Override
    public boolean supportsAppend() {
        return true; // MDF4支持追加模式
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    // ==================== 写入操作 ====================
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        currentFilePath = filePath != null ? filePath : config.getOutputPath(getFileExtension());
        Files.createDirectories(currentFilePath.getParent());
        
        // 启动Python进程（写入模式）
        startPythonProcess(currentFilePath, "write", config.isAppendMode());
    }
    
    /**
     * 启动Python进程
     */
    private void startPythonProcess(Path filePath, String mode, boolean append) throws IOException {
        Path scriptPath = findPythonScript();
        
        List<String> command = new ArrayList<>();
        command.add(pythonExecutable);
        command.add(scriptPath.toAbsolutePath().toString());
        command.add(filePath.toAbsolutePath().toString());
        command.add("--mode");
        command.add(mode);
        
        if (append && mode.equals("write")) {
            command.add("--append");
        }
        
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        pb.directory(filePath.getParent().toFile());
        
        pythonProcess = pb.start();
        processWriter = new PrintWriter(new OutputStreamWriter(
            pythonProcess.getOutputStream(), "UTF-8"), true);
        processReader = new BufferedReader(new InputStreamReader(
            pythonProcess.getInputStream(), "UTF-8"));
        processDataInput = new DataInputStream(pythonProcess.getInputStream());
        
        // 等待就绪信号
        String response = processReader.readLine();
        if (response == null || !response.startsWith("READY:")) {
            throw new IOException("Python进程启动失败: " + response);
        }
        
        System.out.println("MDF4进程已启动: " + response.substring(6));
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        if (processWriter == null) {
            throw new IOException("MDF4写入器未打开");
        }
        
        // 将数据转换为JSON并发送
        String json = gson.toJson(data);
        processWriter.println("WRITE:" + json);
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        if (processWriter == null) {
            throw new IOException("MDF4写入器未打开");
        }
        
        // 批量发送，减少进程间通信开销
        StringBuilder sb = new StringBuilder();
        sb.append("BATCH:");
        sb.append(gson.toJson(dataList));
        processWriter.println(sb.toString());
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (processWriter == null) return;
        
        processWriter.println("FLUSH");
        
        // 等待确认
        String response = processReader.readLine();
        if (response == null || !response.equals("OK")) {
            throw new IOException("刷新失败: " + response);
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (processWriter != null) {
            processWriter.println("CLOSE");
            processWriter.close();
            processWriter = null;
        }
        
        if (processReader != null) {
            // 读取最终响应
            try {
                String response = processReader.readLine();
                if (response != null && response.startsWith("CLOSED:")) {
                    String[] parts = response.split(":");
                    if (parts.length >= 4) {
                        System.out.println("MDF4文件已保存: " + parts[1]);
                        System.out.println("  大小: " + parts[2]);
                        System.out.println("  记录数: " + parts[3]);
                    }
                }
            } catch (IOException e) {
                // ignore
            }
            processReader.close();
            processReader = null;
        }
        
        if (pythonProcess != null) {
            try {
                boolean finished = pythonProcess.waitFor(30, TimeUnit.SECONDS);
                if (!finished) {
                    pythonProcess.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                pythonProcess.destroyForcibly();
            }
            pythonProcess = null;
        }
    }
    
    // ==================== 读取操作（大文件优化）====================
    
    @Override
    protected void doOpenForRead(Path filePath) throws IOException {
        if (!Files.exists(filePath)) {
            throw new IOException("文件不存在: " + filePath);
        }
        
        readFilePath = filePath;
        readMode = true;
        cachedRecordCount = -1;
        cachedTimeRange = null;
        
        // 启动Python进程（读取模式）
        startPythonProcess(filePath, "read", false);
    }
    
    /**
     * 获取迭代器进行流式读取
     * 适用于大文件，避免一次性加载全部数据
     */
    public Iterator<VehicleData> iterator() throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        
        return new Mdf4Iterator(chunkSize);
    }
    
    /**
     * 分块读取数据
     * @param offset 起始位置
     * @param count 读取数量
     */
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        processWriter.println("READ_CHUNK:" + offset + ":" + count);
        
        List<VehicleData> result = new ArrayList<>();
        String line;
        
        while ((line = processReader.readLine()) != null) {
            if (line.startsWith("DATA:")) {
                String jsonData = line.substring(5);
                List<?> rawList = gson.fromJson(jsonData, List.class);
                
                for (Object obj : rawList) {
                    String itemJson = gson.toJson(obj);
                    VehicleData data = gson.fromJson(itemJson, VehicleData.class);
                    result.add(data);
                }
            } else if (line.startsWith("CHUNK_END:")) {
                break;
            } else if (line.startsWith("ERROR:")) {
                throw new IOException("读取失败: " + line.substring(6));
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readAll() throws IOException {
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        // 对于大文件，使用分块读取然后合并
        List<VehicleData> result = new ArrayList<>();
        long offset = 0;
        
        while (true) {
            List<VehicleData> chunk = readChunk(offset, chunkSize);
            if (chunk.isEmpty()) {
                break;
            }
            result.addAll(chunk);
            offset += chunk.size();
            
            // 如果读取数量不足chunkSize，说明已到文件末尾
            if (chunk.size() < chunkSize) {
                break;
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readRange(long startTime, long endTime) throws IOException {
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        processWriter.println("READ_RANGE:" + startTime + ":" + endTime);
        
        List<VehicleData> result = new ArrayList<>();
        String line;
        
        while ((line = processReader.readLine()) != null) {
            if (line.startsWith("DATA:")) {
                String jsonData = line.substring(5);
                List<?> rawList = gson.fromJson(jsonData, List.class);
                
                for (Object obj : rawList) {
                    String itemJson = gson.toJson(obj);
                    VehicleData data = gson.fromJson(itemJson, VehicleData.class);
                    result.add(data);
                }
            } else if (line.startsWith("END:")) {
                break;
            } else if (line.startsWith("ERROR:")) {
                throw new IOException("读取失败: " + line.substring(6));
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readLatest(int count) throws IOException {
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        processWriter.println("READ_LATEST:" + count);
        
        List<VehicleData> result = new ArrayList<>();
        String line;
        
        while ((line = processReader.readLine()) != null) {
            if (line.startsWith("DATA:")) {
                String jsonData = line.substring(5);
                List<?> rawList = gson.fromJson(jsonData, List.class);
                
                for (Object obj : rawList) {
                    String itemJson = gson.toJson(obj);
                    VehicleData data = gson.fromJson(itemJson, VehicleData.class);
                    result.add(data);
                }
            } else if (line.startsWith("END:")) {
                break;
            } else if (line.startsWith("ERROR:")) {
                throw new IOException("读取失败: " + line.substring(6));
            }
        }
        
        return result;
    }
    
    @Override
    public long[] getTimeRange() throws IOException {
        if (cachedTimeRange != null) {
            return cachedTimeRange.clone();
        }
        
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        processWriter.println("GET_RANGE");
        String response = processReader.readLine();
        
        if (response != null && response.startsWith("RANGE:")) {
            String[] parts = response.substring(6).split(",");
            cachedTimeRange = new long[]{
                Long.parseLong(parts[0]),
                Long.parseLong(parts[1])
            };
            return cachedTimeRange.clone();
        }
        
        return new long[]{0, 0};
    }
    
    @Override
    public long getTotalRecordCount() throws IOException {
        if (cachedRecordCount >= 0) {
            return cachedRecordCount;
        }
        
        if (!readMode || processWriter == null) {
            throw new IOException("未在读取模式");
        }
        
        processWriter.println("GET_COUNT");
        String response = processReader.readLine();
        
        if (response != null && response.startsWith("COUNT:")) {
            cachedRecordCount = Long.parseLong(response.substring(6));
            return cachedRecordCount;
        }
        
        return 0;
    }
    
    // ==================== 通用方法 ====================
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            try {
                return Files.size(currentFilePath);
            } catch (IOException e) {
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public boolean isValidFile(Path filePath) {
        if (!Files.exists(filePath)) {
            return false;
        }
        
        // 检查文件扩展名
        if (!filePath.toString().toLowerCase().endsWith(".mf4")) {
            return false;
        }
        
        // 检查文件大小（至少有一个头部）
        try {
            return Files.size(filePath) > 64;
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * 查找Python脚本
     */
    private Path findPythonScript() throws IOException {
        Path[] possiblePaths = {
            Path.of(pythonScriptPath),
            Path.of("..", "python", "mdf4_writer_stream.py"),
            Path.of("python", "mdf4_writer_stream.py"),
            currentFilePath != null ? currentFilePath.getParent().resolve("..").resolve("python").resolve("mdf4_writer_stream.py").normalize() : null
        };
        
        for (Path path : possiblePaths) {
            if (path != null && path.toFile().exists()) {
                return path;
            }
        }
        
        throw new IOException("MDF4流式写入脚本未找到: " + pythonScriptPath);
    }
    
    public void setPythonExecutable(String pythonExecutable) {
        this.pythonExecutable = pythonExecutable;
    }
    
    public void setPythonScriptPath(String pythonScriptPath) {
        this.pythonScriptPath = pythonScriptPath;
    }
    
    public void setChunkSize(int chunkSize) {
        this.chunkSize = chunkSize;
    }
    
    // ==================== 迭代器实现 ====================
    
    private class Mdf4Iterator implements Iterator<VehicleData> {
        private final int chunkSize;
        private List<VehicleData> currentChunk = new ArrayList<>();
        private int currentIndex = 0;
        private long currentOffset = 0;
        private boolean hasMore = true;
        
        public Mdf4Iterator(int chunkSize) {
            this.chunkSize = chunkSize;
            loadNextChunk();
        }
        
        private void loadNextChunk() {
            try {
                currentChunk = readChunk(currentOffset, chunkSize);
                currentIndex = 0;
                currentOffset += currentChunk.size();
                hasMore = !currentChunk.isEmpty();
            } catch (IOException e) {
                hasMore = false;
                currentChunk.clear();
            }
        }
        
        @Override
        public boolean hasNext() {
            if (currentIndex < currentChunk.size()) {
                return true;
            }
            if (hasMore) {
                loadNextChunk();
                return !currentChunk.isEmpty();
            }
            return false;
        }
        
        @Override
        public VehicleData next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return currentChunk.get(currentIndex++);
        }
    }
}
