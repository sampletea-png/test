package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * JSON存储格式实现 - 支持GB级大文件直接内存读写
 * 
 * 特性：
 * 1. 写入：内存数据直接流式写入JSON Lines格式
 * 2. 读取：支持迭代器流式读取，避免内存溢出
 * 3. 大文件：支持GB级文件的高效读写
 */
public class JsonStorage extends BaseStorage {
    
    private final Gson gson;
    
    // 写入相关
    private BufferedWriter writer;
    private boolean isFirstRecord = true;
    private final String format; // "lines" 或 "array"
    
    // 读取相关
    private BufferedReader reader;
    private JsonReader jsonReader;
    private boolean readMode = false;
    
    // 大文件分块配置
    private static final int DEFAULT_CHUNK_SIZE = 10000;
    private int chunkSize = DEFAULT_CHUNK_SIZE;
    
    // 文件信息缓存
    private long cachedRecordCount = -1;
    private long[] cachedTimeRange = null;
    
    public JsonStorage(StorageConfig config) {
        super(config);
        this.gson = new GsonBuilder().create();
        
        // 获取格式选项，默认为lines（更适合大文件）
        Object formatOption = config.getOption("format");
        this.format = formatOption != null ? formatOption.toString() : "lines";
        
        // 从配置读取分块大小
        Object chunkSizeOption = config.getOption("json.chunkSize");
        if (chunkSizeOption != null) {
            this.chunkSize = ((Number) chunkSizeOption).intValue();
        }
    }
    
    @Override
    public String getFormatName() {
        return "json";
    }
    
    @Override
    public String getFileExtension() {
        return "json";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    @Override
    public boolean supportsIterator() {
        return "lines".equals(format); // 只有lines格式支持迭代器
    }
    
    // ==================== 写入操作 ====================
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        Files.createDirectories(filePath.getParent());
        
        boolean fileExists = Files.exists(filePath) && Files.size(filePath) > 0;
        isFirstRecord = !fileExists || !config.isAppendMode();
        
        OutputStream os = new FileOutputStream(filePath.toFile(), config.isAppendMode());
        
        if ("gzip".equals(config.getCompression())) {
            os = new GZIPOutputStream(os);
            currentFilePath = filePath.resolveSibling(filePath.getFileName() + ".gz");
        } else {
            currentFilePath = filePath;
        }
        
        writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        
        // array格式：写入数组开始
        if ("array".equals(format) && isFirstRecord) {
            writer.write("[\n");
        }
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        String json = gson.toJson(data);
        
        if ("lines".equals(format)) {
            // JSON Lines格式（推荐用于大文件）
            writer.write(json);
            writer.newLine();
        } else {
            // JSON Array格式
            if (!isFirstRecord) {
                writer.write(",\n");
            }
            writer.write(json);
            isFirstRecord = false;
        }
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        for (VehicleData data : dataList) {
            doWrite(data);
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (writer != null) {
            // array格式：写入数组结束
            if ("array".equals(format)) {
                writer.write("\n]\n");
            }
            
            writer.flush();
            writer.close();
            writer = null;
        }
    }
    
    // ==================== 读取操作（大文件优化）====================
    
    @Override
    protected void doOpenForRead(Path filePath) throws IOException {
        InputStream is = new FileInputStream(filePath.toFile());
        
        // 检测是否为gzip文件
        if (filePath.toString().endsWith(".gz")) {
            is = new GZIPInputStream(is);
        }
        
        reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        jsonReader = new JsonReader(reader);
        
        readMode = true;
        cachedRecordCount = -1;
        cachedTimeRange = null;
        
        currentFilePath = filePath;
        
        if ("array".equals(format)) {
            // 准备读取JSON数组
            jsonReader.beginArray();
        }
    }
    
    @Override
    public Iterator<VehicleData> iterator() throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        
        if (!"lines".equals(format)) {
            throw new UnsupportedOperationException("只有JSON Lines格式支持迭代器");
        }
        
        return new JsonLinesIterator();
    }
    
    @Override
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        
        List<VehicleData> result = new ArrayList<>();
        
        if ("lines".equals(format)) {
            // JSON Lines格式：逐行读取
            String line;
            long currentLine = 0;
            
            while (currentLine < offset && (line = reader.readLine()) != null) {
                currentLine++;
            }
            
            while ((line = reader.readLine()) != null && result.size() < count) {
                line = line.trim();
                if (!line.isEmpty()) {
                    try {
                        VehicleData data = gson.fromJson(line, VehicleData.class);
                        if (data != null) {
                            result.add(data);
                        }
                    } catch (Exception e) {
                        System.err.println("解析JSON行失败: " + line);
                    }
                }
            }
        } else {
            // JSON Array格式：使用JsonReader流式读取
            for (long i = 0; i < offset && jsonReader.hasNext(); i++) {
                jsonReader.skipValue();
            }
            
            int readCount = 0;
            while (jsonReader.hasNext() && readCount < count) {
                VehicleData data = gson.fromJson(jsonReader, VehicleData.class);
                if (data != null) {
                    result.add(data);
                    readCount++;
                }
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readAll() throws IOException {
        if (!readMode) {
            throw new IOException("未在读取模式");
        }
        
        List<VehicleData> result = new ArrayList<>();
        
        if ("lines".equals(format)) {
            // JSON Lines格式
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    try {
                        VehicleData data = gson.fromJson(line, VehicleData.class);
                        if (data != null) {
                            result.add(data);
                        }
                    } catch (Exception e) {
                        System.err.println("解析JSON行失败: " + line);
                    }
                }
            }
        } else {
            // JSON Array格式
            while (jsonReader.hasNext()) {
                VehicleData data = gson.fromJson(jsonReader, VehicleData.class);
                if (data != null) {
                    result.add(data);
                }
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readRange(long startTime, long endTime) throws IOException {
        List<VehicleData> allData = readAll();
        List<VehicleData> result = new ArrayList<>();
        
        for (VehicleData data : allData) {
            if (data.getTimestamp() >= startTime && data.getTimestamp() <= endTime) {
                result.add(data);
            }
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readLatest(int count) throws IOException {
        List<VehicleData> allData = readAll();
        int start = Math.max(0, allData.size() - count);
        return new ArrayList<>(allData.subList(start, allData.size()));
    }
    
    @Override
    public long[] getTimeRange() throws IOException {
        if (cachedTimeRange != null) {
            return cachedTimeRange.clone();
        }
        
        List<VehicleData> allData = readAll();
        if (allData.isEmpty()) {
            return new long[]{0, 0};
        }
        
        long minTime = Long.MAX_VALUE;
        long maxTime = Long.MIN_VALUE;
        
        for (VehicleData data : allData) {
            minTime = Math.min(minTime, data.getTimestamp());
            maxTime = Math.max(maxTime, data.getTimestamp());
        }
        
        cachedTimeRange = new long[]{minTime, maxTime};
        return cachedTimeRange.clone();
    }
    
    @Override
    public long getTotalRecordCount() throws IOException {
        if (cachedRecordCount >= 0) {
            return cachedRecordCount;
        }
        
        if ("lines".equals(format)) {
            long count = 0;
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    count++;
                }
            }
            cachedRecordCount = count;
            return count;
        } else {
            long count = 0;
            while (jsonReader.hasNext()) {
                jsonReader.skipValue();
                count++;
            }
            cachedRecordCount = count;
            return count;
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            try {
                return Files.size(currentFilePath);
            } catch (IOException e) {
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public boolean isValidFile(Path filePath) {
        if (!Files.exists(filePath)) {
            return false;
        }
        
        try {
            String content = readFirstLine(filePath);
            if (content == null || content.isEmpty()) {
                return false;
            }
            
            // 简单验证JSON格式
            return content.trim().startsWith("{") || content.trim().startsWith("[");
        } catch (IOException e) {
            return false;
        }
    }
    
    private String readFirstLine(Path filePath) throws IOException {
        InputStream is = new FileInputStream(filePath.toFile());
        if (filePath.toString().endsWith(".gz")) {
            is = new GZIPInputStream(is);
        }
        
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            return br.readLine();
        }
    }
    
    // ==================== 迭代器实现 ====================
    
    private class JsonLinesIterator implements Iterator<VehicleData> {
        private VehicleData nextData = null;
        private boolean hasNext = true;
        
        public JsonLinesIterator() {
            advance();
        }
        
        private void advance() {
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty()) {
                        try {
                            VehicleData data = gson.fromJson(line, VehicleData.class);
                            if (data != null) {
                                nextData = data;
                                return;
                            }
                        } catch (Exception e) {
                            // 跳过无效的JSON行
                        }
                    }
                }
                hasNext = false;
            } catch (IOException e) {
                hasNext = false;
            }
        }
        
        @Override
        public boolean hasNext() {
            return hasNext;
        }
        
        @Override
        public VehicleData next() {
            if (!hasNext) {
                throw new NoSuchElementException();
            }
            VehicleData result = nextData;
            advance();
            return result;
        }
    }
}
