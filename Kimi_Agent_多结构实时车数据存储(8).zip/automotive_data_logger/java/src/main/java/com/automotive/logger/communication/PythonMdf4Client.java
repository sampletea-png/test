package com.automotive.logger.communication;

import com.automotive.logger.model.VehicleData;

import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Python MDF4写入服务的客户端
 * 通过Socket与Python服务通信，发送实时数据
 */
public class PythonMdf4Client {
    
    private static final String DEFAULT_HOST = "localhost";
    private static final int DEFAULT_PORT = 9999;
    private static final int RECONNECT_DELAY_MS = 2000;
    private static final int SOCKET_TIMEOUT_MS = 5000;
    
    private final String host;
    private final int port;
    private final BlockingQueue<VehicleData> dataQueue;
    private final ExecutorService executor;
    private final AtomicBoolean connected;
    private final AtomicBoolean running;
    private final AtomicLong dataCount;
    
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    
    // 统计信息
    private volatile long lastSendTime = 0;
    private volatile double sendRate = 0.0;
    
    public PythonMdf4Client() {
        this(DEFAULT_HOST, DEFAULT_PORT);
    }
    
    public PythonMdf4Client(String host, int port) {
        this.host = host;
        this.port = port;
        this.dataQueue = new LinkedBlockingQueue<>(10000); // 缓冲队列
        this.executor = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "Mdf4Client-" + r.hashCode());
            t.setDaemon(true);
            return t;
        });
        this.connected = new AtomicBoolean(false);
        this.running = new AtomicBoolean(false);
        this.dataCount = new AtomicLong(0);
    }
    
    /**
     * 启动客户端
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            executor.submit(this::connectionManager);
            executor.submit(this::dataSender);
            System.out.println("MDF4客户端已启动，目标: " + host + ":" + port);
        }
    }
    
    /**
     * 停止客户端
     */
    public void stop() {
        running.set(false);
        closeConnection();
        executor.shutdown();
        try {
            if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
        System.out.println("MDF4客户端已停止，共发送 " + dataCount.get() + " 条数据");
    }
    
    /**
     * 发送数据到Python服务
     */
    public void sendData(VehicleData data) {
        if (data != null && running.get()) {
            // 非阻塞方式添加到队列
            dataQueue.offer(data);
        }
    }
    
    /**
     * 连接管理器 - 维护与Python服务的连接
     */
    private void connectionManager() {
        while (running.get()) {
            if (!connected.get()) {
                try {
                    connect();
                } catch (Exception e) {
                    System.err.println("连接Python服务失败: " + e.getMessage());
                }
            }
            
            try {
                Thread.sleep(RECONNECT_DELAY_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    /**
     * 建立连接
     */
    private void connect() throws IOException {
        socket = new Socket(host, port);
        socket.setSoTimeout(SOCKET_TIMEOUT_MS);
        socket.setTcpNoDelay(true); // 禁用Nagle算法，降低延迟
        
        writer = new PrintWriter(
            new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), 
            true
        );
        reader = new BufferedReader(
            new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)
        );
        
        // 发送初始化命令
        writer.println("INIT");
        String response = reader.readLine();
        
        if ("READY".equals(response)) {
            connected.set(true);
            System.out.println("成功连接到Python MDF4服务");
            
            // 发送CSV头
            writer.println("HEADER:" + VehicleData.getCsvHeader());
        } else {
            throw new IOException("Python服务未就绪: " + response);
        }
    }
    
    /**
     * 关闭连接
     */
    private void closeConnection() {
        connected.set(false);
        
        if (writer != null) {
            writer.println("CLOSE");
            writer.close();
        }
        
        try {
            if (reader != null) reader.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            // 忽略关闭异常
        }
        
        System.out.println("已断开与Python服务的连接");
    }
    
    /**
     * 数据发送器 - 从队列取出数据并发送
     */
    private void dataSender() {
        while (running.get()) {
            try {
                if (connected.get()) {
                    VehicleData data = dataQueue.poll(100, TimeUnit.MILLISECONDS);
                    if (data != null) {
                        sendDataInternal(data);
                    }
                } else {
                    Thread.sleep(100);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("发送数据异常: " + e.getMessage());
                connected.set(false);
            }
        }
        
        // 发送剩余数据
        flushRemainingData();
    }
    
    /**
     * 内部发送方法
     */
    private void sendDataInternal(VehicleData data) {
        if (writer != null && !writer.checkError()) {
            String csvData = data.toCsvString();
            writer.println("DATA:" + csvData);
            
            long count = dataCount.incrementAndGet();
            long currentTime = System.currentTimeMillis();
            
            // 计算发送速率
            if (lastSendTime > 0) {
                double interval = (currentTime - lastSendTime) / 1000.0;
                if (interval > 0) {
                    sendRate = 1.0 / interval;
                }
            }
            lastSendTime = currentTime;
            
            // 每1000条数据打印一次统计
            if (count % 1000 == 0) {
                System.out.printf("已发送 %d 条数据，当前速率: %.1f 条/秒%n", count, sendRate);
            }
        } else {
            connected.set(false);
        }
    }
    
    /**
     * 刷新剩余数据
     */
    private void flushRemainingData() {
        VehicleData data;
        while ((data = dataQueue.poll()) != null && connected.get()) {
            sendDataInternal(data);
        }
    }
    
    /**
     * 获取连接状态
     */
    public boolean isConnected() {
        return connected.get();
    }
    
    /**
     * 获取已发送数据计数
     */
    public long getDataCount() {
        return dataCount.get();
    }
    
    /**
     * 获取当前发送速率
     */
    public double getSendRate() {
        return sendRate;
    }
    
    /**
     * 获取队列中待发送的数据数量
     */
    public int getQueueSize() {
        return dataQueue.size();
    }
}
