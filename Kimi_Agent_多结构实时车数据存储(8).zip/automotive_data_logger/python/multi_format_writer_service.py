#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多格式数据写入服务
支持多种存储格式，可动态切换
"""

import socket
import threading
import os
import sys
import time
import json
import signal
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 导入存储模块
from storage import (
    StorageInterface, StorageConfig, StorageInfo,
    StorageFactory, create_storage, list_available_formats
)


@dataclass
class VehicleData:
    """车辆数据结构"""
    timestamp: int
    can_channel: int
    can_id: int
    vehicle_speed: float
    engine_rpm: float
    engine_temp: float
    throttle_position: float
    brake_position: float
    steering_angle: float
    battery_voltage: float
    fuel_level: float
    odometer: float
    accel_x: float
    accel_y: float
    accel_z: float
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'VehicleData':
        return cls(**{k: data.get(k, 0) for k in cls.__dataclass_fields__.keys()})


class MultiFormatWriterService:
    """
    多格式数据写入服务
    支持动态切换存储格式
    """
    
    def __init__(
        self,
        host: str = 'localhost',
        port: int = 9999,
        default_format: str = 'mdf4',
        output_dir: str = 'output'
    ):
        self.host = host
        self.port = port
        self.default_format = default_format
        self.output_dir = output_dir
        
        self.server_socket: Optional[socket.socket] = None
        self.running = False
        self.storage: Optional[StorageInterface] = None
        self.storage_factory = StorageFactory()
        
        # 当前配置
        self.current_config = StorageConfig(
            output_dir=output_dir,
            batch_size=100
        )
        
        # 统计信息
        self.header_received = False
        self.csv_header = ""
        
        # 存储格式切换回调
        self._format_change_callbacks: List[callable] = []
    
    def start(self):
        """启动服务"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            
            logger.info("=" * 60)
            logger.info("多格式数据写入服务已启动")
            logger.info("=" * 60)
            logger.info(f"监听地址: {self.host}:{self.port}")
            logger.info(f"默认格式: {self.default_format}")
            logger.info(f"可用格式: {self.storage_factory.get_available_formats()}")
            logger.info(f"输出目录: {self.output_dir}")
            logger.info("=" * 60)
            
            while self.running:
                try:
                    self.server_socket.settimeout(1.0)
                    client_socket, address = self.server_socket.accept()
                    logger.info(f"客户端连接: {address}")
                    
                    # 处理客户端连接
                    client_thread = threading.Thread(
                        target=self._handle_client,
                        args=(client_socket,),
                        daemon=True
                    )
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        logger.error(f"接受连接失败: {e}")
                    
        except Exception as e:
            logger.error(f"启动服务失败: {e}")
        finally:
            self.stop()
    
    def _handle_client(self, client_socket: socket.socket):
        """处理客户端连接"""
        try:
            client_socket.settimeout(5.0)
            
            with client_socket:
                reader = client_socket.makefile('r', encoding='utf-8')
                writer = client_socket.makefile('w', encoding='utf-8')
                
                # 发送就绪响应
                self._send_response(writer, "READY", {
                    'available_formats': self.storage_factory.get_available_formats(),
                    'default_format': self.default_format
                })
                
                while self.running:
                    line = reader.readline()
                    if not line:
                        break
                    
                    line = line.strip()
                    if not line:
                        continue
                    
                    # 解析命令
                    self._process_command(line, writer)
                    
        except Exception as e:
            logger.error(f"处理客户端异常: {e}")
        finally:
            # 关闭存储
            if self.storage:
                self.storage.close()
                self.storage = None
            logger.info("客户端连接已关闭")
    
    def _process_command(self, line: str, writer):
        """处理客户端命令"""
        try:
            # 解析命令和参数
            if ':' in line:
                cmd, param = line.split(':', 1)
            else:
                cmd = line
                param = ""
            
            cmd = cmd.upper()
            
            if cmd == "INIT":
                # 初始化存储
                self._handle_init(param, writer)
                
            elif cmd == "FORMAT":
                # 切换存储格式
                self._handle_format_change(param, writer)
                
            elif cmd == "CONFIG":
                # 更新配置
                self._handle_config(param, writer)
                
            elif cmd == "HEADER":
                # 接收CSV头
                self.csv_header = param
                self.header_received = True
                logger.debug(f"接收CSV头: {self.csv_header}")
                
            elif cmd == "DATA":
                # 接收数据
                self._handle_data(param, writer)
                
            elif cmd == "FLUSH":
                # 强制刷新
                self._handle_flush(writer)
                
            elif cmd == "INFO":
                # 获取存储信息
                self._handle_info(writer)
                
            elif cmd == "CLOSE":
                # 关闭存储
                self._handle_close(writer)
                
            elif cmd == "PING":
                # 心跳检测
                self._send_response(writer, "PONG")
                
            else:
                self._send_response(writer, "ERROR", {'message': f'未知命令: {cmd}'})
                
        except Exception as e:
            logger.error(f"处理命令失败: {e}")
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_init(self, param: str, writer):
        """处理初始化命令"""
        try:
            # 解析参数
            format_name = param.strip() if param else self.default_format
            
            # 关闭现有存储
            if self.storage:
                self.storage.close()
            
            # 创建新存储
            self.storage = self.storage_factory.create(format_name, self.current_config)
            
            if self.storage is None:
                self._send_response(writer, "ERROR", {
                    'message': f'无法创建 {format_name} 存储',
                    'available_formats': self.storage_factory.get_available_formats()
                })
                return
            
            # 打开存储
            if self.storage.open():
                self._send_response(writer, "READY", {
                    'format': format_name,
                    'file_path': str(self.storage._info.file_path)
                })
            else:
                self._send_response(writer, "ERROR", {'message': '打开存储失败'})
                
        except Exception as e:
            logger.error(f"初始化失败: {e}")
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_format_change(self, format_name: str, writer):
        """处理格式切换命令"""
        try:
            format_name = format_name.strip().lower()
            
            if not self.storage_factory.is_registered(format_name):
                self._send_response(writer, "ERROR", {
                    'message': f'未知格式: {format_name}',
                    'available_formats': self.storage_factory.get_available_formats()
                })
                return
            
            # 关闭现有存储
            old_file = None
            if self.storage:
                old_file = self.storage._info.file_path
                self.storage.close()
            
            # 创建新存储
            self.storage = self.storage_factory.create(format_name, self.current_config)
            
            if self.storage and self.storage.open():
                self._send_response(writer, "OK", {
                    'format': format_name,
                    'new_file': str(self.storage._info.file_path),
                    'old_file': str(old_file) if old_file else None
                })
                
                # 触发回调
                for callback in self._format_change_callbacks:
                    try:
                        callback(format_name, self.storage._info.file_path)
                    except Exception as e:
                        logger.error(f"格式切换回调失败: {e}")
            else:
                self._send_response(writer, "ERROR", {'message': '切换格式失败'})
                
        except Exception as e:
            logger.error(f"格式切换失败: {e}")
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_config(self, param: str, writer):
        """处理配置更新命令"""
        try:
            config_dict = json.loads(param)
            
            # 更新配置
            for key, value in config_dict.items():
                if hasattr(self.current_config, key):
                    setattr(self.current_config, key, value)
            
            self._send_response(writer, "OK", {'config': self._config_to_dict()})
            
        except json.JSONDecodeError:
            self._send_response(writer, "ERROR", {'message': '无效的JSON格式'})
        except Exception as e:
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_data(self, param: str, writer):
        """处理数据写入命令"""
        try:
            if self.storage is None or not self.storage._info.is_open:
                self._send_response(writer, "ERROR", {'message': '存储未打开'})
                return
            
            # 解析CSV数据
            data = self._parse_csv_data(param)
            if data is None:
                self._send_response(writer, "ERROR", {'message': '数据解析失败'})
                return
            
            # 添加到存储
            success = self.storage.add_data(data)
            
            if success:
                self._send_response(writer, "OK")
            else:
                self._send_response(writer, "ERROR", {'message': '写入失败'})
                
        except Exception as e:
            logger.error(f"处理数据失败: {e}")
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_flush(self, writer):
        """处理强制刷新命令"""
        try:
            if self.storage:
                self.storage.flush()
                info = self.storage.get_info()
                self._send_response(writer, "OK", {
                    'record_count': info.record_count,
                    'file_size_mb': info.file_size_bytes / (1024 * 1024)
                })
            else:
                self._send_response(writer, "ERROR", {'message': '存储未打开'})
        except Exception as e:
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_info(self, writer):
        """处理信息查询命令"""
        try:
            info_dict = {
                'available_formats': self.storage_factory.get_available_formats(),
                'current_format': self.storage.FORMAT_NAME if self.storage else None,
                'config': self._config_to_dict()
            }
            
            if self.storage:
                storage_info = self.storage.get_info()
                info_dict['storage'] = storage_info.to_dict()
            
            self._send_response(writer, "OK", info_dict)
            
        except Exception as e:
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _handle_close(self, writer):
        """处理关闭命令"""
        try:
            if self.storage:
                info = self.storage.get_info()
                self.storage.close()
                self.storage = None
                
                self._send_response(writer, "OK", {
                    'record_count': info.record_count,
                    'file_size_mb': info.file_size_bytes / (1024 * 1024)
                })
            else:
                self._send_response(writer, "OK", {'message': '存储已关闭'})
                
        except Exception as e:
            self._send_response(writer, "ERROR", {'message': str(e)})
    
    def _send_response(self, writer, status: str, data: Any = None):
        """发送响应"""
        response = {'status': status}
        if data is not None:
            response['data'] = data
        
        writer.write(json.dumps(response) + '\n')
        writer.flush()
    
    def _parse_csv_data(self, data_str: str) -> Optional[Dict[str, Any]]:
        """解析CSV格式的数据"""
        try:
            parts = data_str.split(',')
            if len(parts) >= 15:
                return {
                    'timestamp': int(parts[0]),
                    'can_channel': int(parts[1]),
                    'can_id': int(parts[2]),
                    'vehicle_speed': float(parts[3]),
                    'engine_rpm': float(parts[4]),
                    'engine_temp': float(parts[5]),
                    'throttle_position': float(parts[6]),
                    'brake_position': float(parts[7]),
                    'steering_angle': float(parts[8]),
                    'battery_voltage': float(parts[9]),
                    'fuel_level': float(parts[10]),
                    'odometer': float(parts[11]),
                    'accel_x': float(parts[12]),
                    'accel_y': float(parts[13]),
                    'accel_z': float(parts[14])
                }
        except Exception as e:
            logger.error(f"解析数据失败: {e}, 数据: {data_str}")
        return None
    
    def _config_to_dict(self) -> Dict[str, Any]:
        """将配置转换为字典"""
        return {
            'output_dir': self.current_config.output_dir,
            'filename_prefix': self.current_config.filename_prefix,
            'batch_size': self.current_config.batch_size,
            'max_file_size_mb': self.current_config.max_file_size_mb,
            'split_interval_minutes': self.current_config.split_interval_minutes,
            'compression': self.current_config.compression
        }
    
    def add_format_change_callback(self, callback: callable):
        """添加格式切换回调"""
        self._format_change_callbacks.append(callback)
    
    def stop(self):
        """停止服务"""
        self.running = False
        
        if self.storage:
            self.storage.close()
            self.storage = None
            
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
            self.server_socket = None
            
        logger.info("多格式写入服务已停止")


# 全局服务实例
service: Optional[MultiFormatWriterService] = None


def signal_handler(signum, frame):
    """信号处理"""
    logger.info(f"接收到信号 {signum}，正在关闭...")
    if service:
        service.stop()
    sys.exit(0)


def main():
    """主函数"""
    global service
    
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 解析命令行参数
    import argparse
    parser = argparse.ArgumentParser(description='多格式数据写入服务')
    parser.add_argument('--host', default='localhost', help='监听地址')
    parser.add_argument('--port', type=int, default=9999, help='监听端口')
    parser.add_argument('--format', default='mdf4', help='默认存储格式')
    parser.add_argument('--output', default='output', help='输出目录')
    parser.add_argument('--batch-size', type=int, default=100, help='批量写入大小')
    
    args = parser.parse_args()
    
    # 创建并启动服务
    service = MultiFormatWriterService(
        host=args.host,
        port=args.port,
        default_format=args.format,
        output_dir=args.output
    )
    
    # 设置批量大小
    service.current_config.batch_size = args.batch_size
    
    try:
        service.start()
    except KeyboardInterrupt:
        logger.info("用户中断")
    finally:
        service.stop()


if __name__ == "__main__":
    main()
