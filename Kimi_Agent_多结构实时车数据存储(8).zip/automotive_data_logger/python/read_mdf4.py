#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4文件读取工具
用于读取和验证生成的MDF4文件
"""

import sys
import argparse
from pathlib import Path

try:
    from asammdf import MDF
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False
    print("错误: 未安装asammdf库")
    print("请运行: pip install asammdf")
    sys.exit(1)


def print_file_info(mdf_file: str):
    """打印MDF4文件信息"""
    print("=" * 60)
    print(f"MDF4文件: {mdf_file}")
    print("=" * 60)
    
    try:
        with MDF(mdf_file) as mdf:
            # 基本信息
            print(f"\n版本: {mdf.version}")
            print(f"程序: {mdf.header.program}")
            print(f"版本: {mdf.header.version}")
            print(f"开始时间: {mdf.header.start_time}")
            
            # 通道信息
            print(f"\n通道数量: {len(mdf.channels_db)}")
            print("\n通道列表:")
            print("-" * 60)
            
            for i, (channel_name, entries) in enumerate(sorted(mdf.channels_db.items())):
                if i >= 20:  # 只显示前20个通道
                    print(f"... 还有 {len(mdf.channels_db) - 20} 个通道")
                    break
                    
                # 获取通道信息
                try:
                    group, index = entries[0]
                    channel = mdf.groups[group].channels[index]
                    unit = channel.unit if hasattr(channel, 'unit') else ''
                    print(f"  {channel_name:<30} {unit}")
                except:
                    print(f"  {channel_name}")
            
            # 数据组信息
            print(f"\n数据组数量: {len(mdf.groups)}")
            for i, group in enumerate(mdf.groups):
                print(f"\n  数据组 {i+1}:")
                print(f"    通道数: {len(group.channels)}")
                if hasattr(group, 'channel_group') and group.channel_group:
                    cg = group.channel_group
                    print(f"    记录数: {cg.cycles_nr}")
                    print(f"    采样周期: {cg.sample_period if hasattr(cg, 'sample_period') else 'N/A'}")
            
    except Exception as e:
        print(f"读取文件失败: {e}")
        return False
    
    return True


def export_to_csv(mdf_file: str, output_file: str = None):
    """导出MDF4到CSV"""
    print("=" * 60)
    print(f"导出MDF4到CSV: {mdf_file}")
    print("=" * 60)
    
    try:
        with MDF(mdf_file) as mdf:
            if output_file is None:
                output_file = str(Path(mdf_file).with_suffix('.csv'))
            
            print(f"\n导出到: {output_file}")
            print("这可能需要一些时间...")
            
            # 导出为CSV
            mdf.export(fmt='csv', filename=output_file)
            
            print("✓ 导出完成")
            
    except Exception as e:
        print(f"导出失败: {e}")
        return False
    
    return True


def plot_signals(mdf_file: str, signals: list = None):
    """绘制信号图表"""
    print("=" * 60)
    print(f"绘制信号: {mdf_file}")
    print("=" * 60)
    
    try:
        with MDF(mdf_file) as mdf:
            if signals is None or len(signals) == 0:
                # 自动选择前4个信号
                signals = list(mdf.channels_db.keys())[:4]
            
            print(f"\n绘制信号: {', '.join(signals)}")
            
            # 获取信号数据
            fig_signals = []
            for sig_name in signals:
                try:
                    sig = mdf.get(sig_name)
                    fig_signals.append(sig)
                    print(f"  {sig_name}: {len(sig.samples)} 个样本")
                except Exception as e:
                    print(f"  {sig_name}: 获取失败 - {e}")
            
            if fig_signals:
                # 绘制图表
                try:
                    import matplotlib.pyplot as plt
                    
                    fig, axes = plt.subplots(len(fig_signals), 1, figsize=(12, 3*len(fig_signals)))
                    if len(fig_signals) == 1:
                        axes = [axes]
                    
                    for ax, sig in zip(axes, fig_signals):
                        ax.plot(sig.timestamps, sig.samples, label=sig.name)
                        ax.set_xlabel('Time (s)')
                        ax.set_ylabel(f'{sig.name} ({sig.unit})')
                        ax.legend()
                        ax.grid(True)
                    
                    plt.tight_layout()
                    plt.show()
                    
                except ImportError:
                    print("\n错误: 未安装matplotlib，无法绘制图表")
                    print("请运行: pip install matplotlib")
            else:
                print("没有可绘制的信号")
                
    except Exception as e:
        print(f"绘制失败: {e}")
        return False
    
    return True


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='MDF4文件读取工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 查看文件信息
  python read_mdf4.py info data.mf4
  
  # 导出为CSV
  python read_mdf4.py export data.mf4 -o output.csv
  
  # 绘制信号
  python read_mdf4.py plot data.mf4 -s vehicle_speed engine_rpm
        '''
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # info命令
    info_parser = subparsers.add_parser('info', help='显示文件信息')
    info_parser.add_argument('file', help='MDF4文件路径')
    
    # export命令
    export_parser = subparsers.add_parser('export', help='导出为CSV')
    export_parser.add_argument('file', help='MDF4文件路径')
    export_parser.add_argument('-o', '--output', help='输出CSV文件路径')
    
    # plot命令
    plot_parser = subparsers.add_parser('plot', help='绘制信号图表')
    plot_parser.add_argument('file', help='MDF4文件路径')
    plot_parser.add_argument('-s', '--signals', nargs='+', help='要绘制的信号名称')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    if args.command == 'info':
        print_file_info(args.file)
    elif args.command == 'export':
        export_to_csv(args.file, args.output)
    elif args.command == 'plot':
        plot_signals(args.file, args.signals)


if __name__ == "__main__":
    main()
