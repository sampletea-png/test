#!/bin/bash

# 汽车数据记录系统启动脚本 (多格式版本)
# 先启动Python多格式写入服务，再启动Java GUI

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/output"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  汽车数据实时记录系统 (多格式支持)${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# 检查Python环境
echo -e "${YELLOW}[1/5] 检查Python环境...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}错误: 未找到python3${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python版本: $PYTHON_VERSION"

# 检查/安装依赖
echo -e "${YELLOW}[2/5] 检查Python依赖...${NC}"

# 检查并安装asammdf
if python3 -c "import asammdf" 2>/dev/null; then
    echo -e "${GREEN}✓ asammdf已安装${NC}"
else
    echo -e "${YELLOW}安装asammdf...${NC}"
    pip3 install asammdf numpy
fi

# 可选依赖：pyarrow (Parquet支持)
if python3 -c "import pyarrow" 2>/dev/null; then
    echo -e "${GREEN}✓ pyarrow已安装 (Parquet格式可用)${NC}"
else
    echo -e "${BLUE}ℹ pyarrow未安装，Parquet格式不可用${NC}"
    echo "  如需Parquet支持，请运行: pip3 install pyarrow"
fi

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 启动Python服务
echo -e "${YELLOW}[3/5] 启动Python多格式写入服务...${NC}"
cd "$SCRIPT_DIR/python"

# 检查端口是否被占用
if lsof -Pi :9999 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}警告: 端口9999已被占用，尝试关闭现有进程...${NC}"
    lsof -Pi :9999 -sTCP:LISTEN -t | xargs kill -9 2>/dev/null || true
    sleep 1
fi

# 后台启动Python服务
python3 multi_format_writer_service.py --format mdf4 --output "$OUTPUT_DIR" &
PYTHON_PID=$!
echo -e "${GREEN}✓ Python服务已启动 (PID: $PYTHON_PID)${NC}"

# 等待服务启动
sleep 2

# 检查Java环境
echo -e "${YELLOW}[4/5] 检查Java环境...${NC}"
if ! command -v java &> /dev/null; then
    echo -e "${RED}错误: 未找到Java${NC}"
    kill $PYTHON_PID 2>/dev/null || true
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "Java版本: $JAVA_VERSION"

# 检查Maven
if ! command -v mvn &> /dev/null; then
    echo -e "${RED}错误: 未找到Maven${NC}"
    kill $PYTHON_PID 2>/dev/null || true
    exit 1
fi

# 检查JAR文件
JAR_FILE="$SCRIPT_DIR/java/target/automotive-data-logger-1.0.0.jar"

if [ ! -f "$JAR_FILE" ]; then
    echo -e "${YELLOW}[5/5] 编译Java项目...${NC}"
    cd "$SCRIPT_DIR/java"
    mvn clean package -q
    if [ $? -ne 0 ]; then
        echo -e "${RED}编译失败${NC}"
        kill $PYTHON_PID 2>/dev/null || true
        exit 1
    fi
    echo -e "${GREEN}✓ 编译成功${NC}"
else
    echo -e "${GREEN}[5/5] JAR文件已存在${NC}"
fi

# 启动Java应用
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  启动Java GUI应用...${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${BLUE}支持的存储格式:${NC}"
echo "  - mdf4   : ASAM MDF 4.x 格式 (默认)"
echo "  - csv    : CSV格式 (支持GZIP/BZ2压缩)"
echo "  - json   : JSON Lines/Array格式"
echo "  - sqlite : SQLite数据库格式"
echo "  - parquet: Parquet列式存储格式 (需pyarrow)"
echo ""

cd "$SCRIPT_DIR"
java -jar "$JAR_FILE"

# Java应用退出后，停止Python服务
echo ""
echo -e "${YELLOW}停止Python服务...${NC}"
kill $PYTHON_PID 2>/dev/null || true
wait $PYTHON_PID 2>/dev/null || true

echo -e "${GREEN}系统已关闭${NC}"
echo ""
echo -e "${BLUE}输出文件位于: $OUTPUT_DIR${NC}"
