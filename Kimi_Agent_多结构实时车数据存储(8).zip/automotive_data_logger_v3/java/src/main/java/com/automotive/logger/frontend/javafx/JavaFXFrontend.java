package com.automotive.logger.frontend.javafx;

import com.automotive.logger.data.DataBuffer;
import com.automotive.logger.frontend.FrontendInterface;
import com.automotive.logger.model.VehicleData;
import com.automotive.logger.storage.StorageInterface;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * JavaFX前端实现
 * 支持实时数据展示和图表绘制
 */
public class JavaFXFrontend extends Application implements FrontendInterface {
    
    private static JavaFXFrontend instance;
    private static java.util.function.Consumer<JavaFXFrontend> appInitializer;
    
    // UI组件
    private Stage primaryStage;
    private Label statusLabel;
    private Label recordTimeLabel;
    private Label dataCountLabel;
    private Label writeRateLabel;
    private Label formatLabel;
    private Label fileSizeLabel;
    
    // 数据值标签
    private Map<String, Label> valueLabels = new HashMap<>();
    
    // 图表
    private LineChart<Number, Number> lineChart;
    private Map<String, XYChart.Series<Number, Number>> chartSeries = new HashMap<>();
    
    // 控制按钮
    private Button startButton;
    private Button stopButton;
    private ComboBox<String> formatComboBox;
    private Button switchFormatButton;
    
    // 信号选择
    private VBox signalSelectionPanel;
    private Map<String, CheckBox> signalCheckBoxes = new HashMap<>();
    
    // 状态监听器
    private final List<FrontendStatusListener> statusListeners = new CopyOnWriteArrayList<>();
    
    // 数据缓冲区引用
    private DataBuffer dataBuffer;
    
    // 图表数据点计数
    private int dataPointCounter = 0;
    
    // 颜色定义
    private static final Color BG_COLOR = Color.rgb(30, 30, 30);
    private static final Color PANEL_BG = Color.rgb(45, 45, 45);
    private static final Color TEXT_COLOR = Color.rgb(220, 220, 220);
    private static final Color ACCENT_COLOR = Color.rgb(0, 150, 200);
    private static final Color RECORDING_COLOR = Color.rgb(200, 50, 50);
    private static final Color VALUE_COLOR = Color.rgb(100, 200, 100);
    
    // 信号颜色
    private static final Map<String, Color> SIGNAL_COLORS = new LinkedHashMap<>();
    static {
        SIGNAL_COLORS.put("vehicleSpeed", Color.rgb(255, 99, 71));    // 番茄红
        SIGNAL_COLORS.put("engineRpm", Color.rgb(60, 179, 113));      // 中海绿
        SIGNAL_COLORS.put("engineTemp", Color.rgb(30, 144, 255));     // 道奇蓝
        SIGNAL_COLORS.put("throttlePosition", Color.rgb(255, 165, 0)); // 橙色
        SIGNAL_COLORS.put("brakePosition", Color.rgb(220, 20, 60));   // 猩红
        SIGNAL_COLORS.put("steeringAngle", Color.rgb(138, 43, 226));  // 蓝紫
        SIGNAL_COLORS.put("batteryVoltage", Color.rgb(255, 215, 0));  // 金色
        SIGNAL_COLORS.put("fuelLevel", Color.rgb(0, 206, 209));       // 深青
        SIGNAL_COLORS.put("accelX", Color.rgb(255, 105, 180));        // 热粉
        SIGNAL_COLORS.put("accelY", Color.rgb(154, 205, 50));         // 黄绿
        SIGNAL_COLORS.put("accelZ", Color.rgb(106, 90, 205));         // 板岩蓝
    }
    
    public JavaFXFrontend() {
        instance = this;
    }
    
    public static JavaFXFrontend getInstance() {
        return instance;
    }
    
    public static void setAppInitializer(java.util.function.Consumer<JavaFXFrontend> initializer) {
        appInitializer = initializer;
    }
    
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        initialize();
    }
    
    @Override
    public void initialize() {
        // 调用应用初始化回调
        if (appInitializer != null) {
            appInitializer.accept(this);
        }
        
        primaryStage.setTitle("汽车数据实时记录系统 (JavaFX)");
        primaryStage.setMinWidth(1200);
        primaryStage.setMinHeight(800);
        
        // 创建主布局
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #1e1e1e;");
        
        // 顶部状态栏
        root.setTop(createStatusBar());
        
        // 左侧数据面板
        root.setLeft(createDataPanel());
        
        // 中间图表
        root.setCenter(createChartPanel());
        
        // 右侧信号选择
        root.setRight(createSignalSelectionPanel());
        
        // 底部控制栏
        root.setBottom(createControlBar());
        
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        
        // 设置关闭事件
        primaryStage.setOnCloseRequest(e -> {
            shutdown();
            Platform.exit();
        });
    }
    
    private HBox createStatusBar() {
        HBox statusBar = new HBox(20);
        statusBar.setPadding(new Insets(10));
        statusBar.setStyle("-fx-background-color: #2d2d2d;");
        statusBar.setAlignment(Pos.CENTER_LEFT);
        
        statusLabel = createStatusLabel("就绪", TEXT_COLOR);
        recordTimeLabel = createValueLabel("00:00:00");
        dataCountLabel = createValueLabel("0");
        writeRateLabel = createValueLabel("0.0 条/秒");
        formatLabel = createValueLabel("-");
        fileSizeLabel = createValueLabel("0.0 MB");
        
        statusBar.getChildren().addAll(
            createInfoBox("记录状态:", statusLabel),
            createInfoBox("记录时长:", recordTimeLabel),
            createInfoBox("数据条数:", dataCountLabel),
            createInfoBox("写入速率:", writeRateLabel),
            createInfoBox("存储格式:", formatLabel),
            createInfoBox("文件大小:", fileSizeLabel)
        );
        
        return statusBar;
    }
    
    private VBox createDataPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #2d2d2d;");
        panel.setPrefWidth(250);
        
        Label title = new Label("实时数据");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        title.setTextFill(ACCENT_COLOR);
        panel.getChildren().add(title);
        
        // 添加各个数据项
        String[][] dataItems = {
            {"vehicleSpeed", "车速"},
            {"engineRpm", "发动机转速"},
            {"engineTemp", "发动机温度"},
            {"throttlePosition", "油门位置"},
            {"brakePosition", "刹车位置"},
            {"steeringAngle", "方向盘角度"},
            {"batteryVoltage", "电池电压"},
            {"fuelLevel", "燃油液位"},
            {"accelX", "横向加速度"},
            {"accelY", "纵向加速度"},
            {"accelZ", "垂直加速度"}
        };
        
        for (String[] item : dataItems) {
            String key = item[0];
            String name = item[1];
            String unit = DataBuffer.getSignalUnit(key);
            
            HBox row = new HBox(10);
            row.setAlignment(Pos.CENTER_LEFT);
            
            Label nameLabel = new Label(name + ":");
            nameLabel.setTextFill(TEXT_COLOR);
            nameLabel.setFont(Font.font("Microsoft YaHei", 12));
            
            Label valueLabel = new Label("--");
            valueLabel.setTextFill(VALUE_COLOR);
            valueLabel.setFont(Font.font("Consolas", FontWeight.BOLD, 14));
            
            Label unitLabel = new Label(unit);
            unitLabel.setTextFill(Color.GRAY);
            unitLabel.setFont(Font.font("Microsoft YaHei", 10));
            
            row.getChildren().addAll(nameLabel, valueLabel, unitLabel);
            HBox.setHgrow(valueLabel, Priority.ALWAYS);
            
            panel.getChildren().add(row);
            valueLabels.put(key, valueLabel);
        }
        
        return panel;
    }
    
    private VBox createChartPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #1e1e1e;");
        
        Label title = new Label("实时曲线");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        title.setTextFill(ACCENT_COLOR);
        panel.getChildren().add(title);
        
        // 创建图表
        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("数据点");
        xAxis.setStyle("-fx-tick-label-fill: #aaaaaa;");
        yAxis.setLabel("数值");
        yAxis.setStyle("-fx-tick-label-fill: #aaaaaa;");
        
        lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setStyle("-fx-background-color: #2d2d2d;");
        lineChart.setCreateSymbols(false);
        lineChart.setLegendVisible(true);
        lineChart.setLegendSide(javafx.geometry.Side.BOTTOM);
        lineChart.setPrefHeight(500);
        
        // 设置图表区域样式
        lineChart.lookup(".chart-content").setStyle("-fx-background-color: #2d2d2d;");
        lineChart.lookup(".chart-plot-background").setStyle("-fx-background-color: #2d2d2d;");
        
        VBox.setVgrow(lineChart, Priority.ALWAYS);
        panel.getChildren().add(lineChart);
        
        return panel;
    }
    
    private VBox createSignalSelectionPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #2d2d2d;");
        panel.setPrefWidth(180);
        
        Label title = new Label("信号选择");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        title.setTextFill(ACCENT_COLOR);
        panel.getChildren().add(title);
        
        // 添加全选/全不选按钮
        HBox selectButtons = new HBox(10);
        Button selectAllBtn = new Button("全选");
        Button selectNoneBtn = new Button("全不选");
        
        selectAllBtn.setOnAction(e -> setAllSignalsSelected(true));
        selectNoneBtn.setOnAction(e -> setAllSignalsSelected(false));
        
        selectButtons.getChildren().addAll(selectAllBtn, selectNoneBtn);
        panel.getChildren().add(selectButtons);
        
        // 添加信号复选框
        for (String signal : DataBuffer.getAvailableSignals()) {
            CheckBox checkBox = new CheckBox(DataBuffer.getSignalDisplayName(signal));
            checkBox.setTextFill(TEXT_COLOR);
            checkBox.setSelected(dataBuffer != null && 
                dataBuffer.getSelectedSignals().contains(signal));
            
            // 设置颜色标记
            Color signalColor = SIGNAL_COLORS.getOrDefault(signal, Color.WHITE);
            checkBox.setStyle("-fx-mark-color: " + toRgbString(signalColor) + ";");
            
            checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                if (dataBuffer != null) {
                    if (newVal) {
                        dataBuffer.selectSignal(signal);
                    } else {
                        dataBuffer.deselectSignal(signal);
                    }
                    updateChartSeries();
                }
                notifySignalSelectionChanged();
            });
            
            panel.getChildren().add(checkBox);
            signalCheckBoxes.put(signal, checkBox);
        }
        
        this.signalSelectionPanel = panel;
        return panel;
    }
    
    private HBox createControlBar() {
        HBox controlBar = new HBox(15);
        controlBar.setPadding(new Insets(15));
        controlBar.setStyle("-fx-background-color: #2d2d2d;");
        controlBar.setAlignment(Pos.CENTER);
        
        // 开始/停止按钮
        startButton = createControlButton("开始记录", Color.rgb(50, 150, 50));
        stopButton = createControlButton("停止记录", Color.rgb(150, 50, 50));
        stopButton.setDisable(true);
        
        startButton.setOnAction(e -> notifyStartRecording());
        stopButton.setOnAction(e -> notifyStopRecording());
        
        // 格式选择
        Label formatLabel = new Label("存储格式:");
        formatLabel.setTextFill(TEXT_COLOR);
        
        formatComboBox = new ComboBox<>();
        formatComboBox.setPrefWidth(120);
        formatComboBox.setDisable(true);
        
        switchFormatButton = createControlButton("切换格式", ACCENT_COLOR);
        switchFormatButton.setDisable(true);
        switchFormatButton.setOnAction(e -> notifySwitchFormat());
        
        controlBar.getChildren().addAll(
            startButton, stopButton,
            new Region() {{ setPrefWidth(20); }},
            formatLabel, formatComboBox, switchFormatButton
        );
        
        return controlBar;
    }
    
    private Label createStatusLabel(String text, Color color) {
        Label label = new Label(text);
        label.setTextFill(color);
        label.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 12));
        return label;
    }
    
    private Label createValueLabel(String text) {
        Label label = new Label(text);
        label.setTextFill(VALUE_COLOR);
        label.setFont(Font.font("Consolas", FontWeight.BOLD, 14));
        return label;
    }
    
    private Button createControlButton(String text, Color color) {
        Button button = new Button(text);
        button.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 13));
        button.setTextFill(Color.WHITE);
        button.setStyle(String.format(
            "-fx-background-color: %s; -fx-padding: 8 16;",
            toRgbString(color)
        ));
        return button;
    }
    
    private VBox createInfoBox(String label, Label valueLabel) {
        VBox box = new VBox(2);
        box.setAlignment(Pos.CENTER);
        
        Label nameLabel = new Label(label);
        nameLabel.setTextFill(Color.GRAY);
        nameLabel.setFont(Font.font("Microsoft YaHei", 10));
        
        box.getChildren().addAll(nameLabel, valueLabel);
        return box;
    }
    
    private String toRgbString(Color color) {
        return String.format("rgb(%d, %d, %d)",
            (int)(color.getRed() * 255),
            (int)(color.getGreen() * 255),
            (int)(color.getBlue() * 255));
    }
    
    private void setAllSignalsSelected(boolean selected) {
        for (CheckBox checkBox : signalCheckBoxes.values()) {
            checkBox.setSelected(selected);
        }
    }
    
    private void updateChartSeries() {
        Platform.runLater(() -> {
            lineChart.getData().clear();
            chartSeries.clear();
            
            if (dataBuffer == null) return;
            
            List<String> selectedSignals = dataBuffer.getSelectedSignals();
            
            for (String signal : selectedSignals) {
                XYChart.Series<Number, Number> series = new XYChart.Series<>();
                series.setName(DataBuffer.getSignalDisplayName(signal));
                
                // 设置线条颜色
                Color signalColor = SIGNAL_COLORS.getOrDefault(signal, Color.WHITE);
                String colorStr = toRgbString(signalColor);
                
                lineChart.getData().add(series);
                chartSeries.put(signal, series);
            }
            
            // 重新加载现有数据
            reloadChartData();
        });
    }
    
    private void reloadChartData() {
        if (dataBuffer == null) return;
        
        List<VehicleData> dataList = dataBuffer.getChartData();
        dataPointCounter = 0;
        
        for (VehicleData data : dataList) {
            addDataToChart(data);
        }
    }
    
    private void addDataToChart(VehicleData data) {
        int pointIndex = dataPointCounter++;
        
        for (Map.Entry<String, XYChart.Series<Number, Number>> entry : chartSeries.entrySet()) {
            String signal = entry.getKey();
            XYChart.Series<Number, Number> series = entry.getValue();
            
            double value = dataBuffer.getSignalValue(data, signal);
            series.getData().add(new XYChart.Data<>(pointIndex, value));
            
            // 限制数据点数量
            if (series.getData().size() > 500) {
                series.getData().remove(0);
            }
        }
    }
    
    // ==================== FrontendInterface 实现 ====================
    
    @Override
    public void start() {
        launch(JavaFXFrontend.class);
    }
    
    @Override
    public void shutdown() {
        Platform.runLater(() -> {
            if (primaryStage != null) {
                primaryStage.close();
            }
        });
    }
    
    @Override
    public void updateRealtimeData(VehicleData data) {
        Platform.runLater(() -> {
            // 更新数值显示
            for (Map.Entry<String, Label> entry : valueLabels.entrySet()) {
                String signal = entry.getKey();
                Label label = entry.getValue();
                
                double value = dataBuffer != null ? 
                    dataBuffer.getSignalValue(data, signal) : 0;
                
                String format = getValueFormat(signal);
                label.setText(String.format(format, value));
            }
        });
    }
    
    private String getValueFormat(String signal) {
        switch (signal) {
            case "vehicleSpeed":
            case "engineTemp":
            case "throttlePosition":
            case "brakePosition":
            case "steeringAngle":
            case "fuelLevel":
                return "%.1f";
            case "engineRpm":
            case "odometer":
                return "%.0f";
            case "batteryVoltage":
                return "%.2f";
            case "accelX":
            case "accelY":
            case "accelZ":
                return "%.3f";
            default:
                return "%.2f";
        }
    }
    
    @Override
    public void updateChartData(List<VehicleData> dataList) {
        Platform.runLater(() -> {
            for (VehicleData data : dataList) {
                addDataToChart(data);
            }
        });
    }
    
    @Override
    public void updateStorageStatus(StorageInterface.StorageInfo info) {
        Platform.runLater(() -> {
            formatLabel.setText(info.getFormatName());
            fileSizeLabel.setText(String.format("%.2f MB", info.getFileSizeMb()));
            dataCountLabel.setText(String.valueOf(info.getRecordCount()));
            writeRateLabel.setText(String.format("%.1f 条/秒", info.getWriteRate()));
        });
    }
    
    @Override
    public void setRecordingState(boolean isRecording) {
        Platform.runLater(() -> {
            if (isRecording) {
                statusLabel.setText("正在记录...");
                statusLabel.setTextFill(RECORDING_COLOR);
                startButton.setDisable(true);
                stopButton.setDisable(false);
                formatComboBox.setDisable(false);
                switchFormatButton.setDisable(false);
            } else {
                statusLabel.setText("已停止");
                statusLabel.setTextFill(TEXT_COLOR);
                startButton.setDisable(false);
                stopButton.setDisable(true);
                formatComboBox.setDisable(true);
                switchFormatButton.setDisable(true);
            }
        });
    }
    
    @Override
    public void showMessage(String message, MessageType type) {
        Platform.runLater(() -> {
            Alert.AlertType alertType;
            switch (type) {
                case WARNING: alertType = Alert.AlertType.WARNING; break;
                case ERROR: alertType = Alert.AlertType.ERROR; break;
                default: alertType = Alert.AlertType.INFORMATION; break;
            }
            
            Alert alert = new Alert(alertType);
            alert.setTitle(type.toString());
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
    
    @Override
    public List<String> getSelectedSignals() {
        List<String> selected = new ArrayList<>();
        for (Map.Entry<String, CheckBox> entry : signalCheckBoxes.entrySet()) {
            if (entry.getValue().isSelected()) {
                selected.add(entry.getKey());
            }
        }
        return selected;
    }
    
    @Override
    public void addStatusListener(FrontendStatusListener listener) {
        statusListeners.add(listener);
    }
    
    @Override
    public void removeStatusListener(FrontendStatusListener listener) {
        statusListeners.remove(listener);
    }
    
    // ==================== 通知方法 ====================
    
    private void notifyStartRecording() {
        String format = formatComboBox.getValue();
        if (format == null) format = "csv";
        
        for (FrontendStatusListener listener : statusListeners) {
            listener.onStartRecording(format);
        }
    }
    
    private void notifyStopRecording() {
        for (FrontendStatusListener listener : statusListeners) {
            listener.onStopRecording();
        }
    }
    
    private void notifySwitchFormat() {
        String newFormat = formatComboBox.getValue();
        if (newFormat != null) {
            for (FrontendStatusListener listener : statusListeners) {
                listener.onSwitchFormat(newFormat);
            }
        }
    }
    
    private void notifySignalSelectionChanged() {
        List<String> selected = getSelectedSignals();
        for (FrontendStatusListener listener : statusListeners) {
            listener.onSignalSelectionChanged(selected);
        }
    }
    
    // ==================== 公共方法 ====================
    
    public void setDataBuffer(DataBuffer dataBuffer) {
        this.dataBuffer = dataBuffer;
        
        // 添加数据监听器
        dataBuffer.addDataListener(dataList -> {
            if (!dataList.isEmpty()) {
                VehicleData latest = dataList.get(dataList.size() - 1);
                updateRealtimeData(latest);
                updateChartData(Collections.singletonList(latest));
            }
        });
        
        // 初始化图表系列
        updateChartSeries();
    }
    
    public void setAvailableFormats(List<String> formats) {
        Platform.runLater(() -> {
            formatComboBox.getItems().clear();
            formatComboBox.getItems().addAll(formats);
            if (!formats.isEmpty()) {
                formatComboBox.setValue(formats.get(0));
            }
        });
    }
    
    public void updateRecordTime(String timeStr) {
        Platform.runLater(() -> recordTimeLabel.setText(timeStr));
    }
}
