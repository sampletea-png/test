# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Channel Buffer Module.

Provides an in-memory accumulation buffer for a single channel's
(timestamps, samples) pairs, with support for append and extend
semantics before the data is serialized to disk via asammdf.

Author: AI Assistant
Date: 2026-04-25
"""

from typing import List, Tuple
import numpy as np

from .models import ChannelAttributes, ChannelLocation


class ChannelBuffer:
    """
    Accumulates per-channel sample blocks in memory before flush.

    This class is the core of the writer's ability to offer fine-grained
    append/extend semantics independent of asammdf's group-level append().
    Each ChannelBuffer stores one logical channel's entire timeline as a
    concatenation of user-supplied blocks.

    Thread Safety
    -------------
    Not thread-safe by itself. The enclosing MDFWriter holds the lock.

    Attributes
    ----------
    location : ChannelLocation
        Logical address of this channel.
    name : str
        User-facing channel name (e.g., 'EngineSpeed').
    attributes : ChannelAttributes
        Metadata attached at creation time.
    _time_blocks : List[np.ndarray]
        List of timestamp arrays supplied via append/extend.
    _sample_blocks : List[np.ndarray]
        List of sample arrays, 1:1 with _time_blocks.
    _finalized : bool
        True after to_signal() has been called (buffers are then empty).
    """

    def __init__(
        self,
        location: ChannelLocation,
        name: str,
        attributes: ChannelAttributes,
    ):
        """
        Initialize an empty channel buffer.

        Parameters
        ----------
        location : ChannelLocation
            Logical address (dg, cg, ch indices).
        name : str
            Human-readable channel name used during MDF serialization.
        attributes : ChannelAttributes
            Creation-time metadata (unit, comment, etc.).
        """
        self.location = location
        self.name = name
        self.attributes = attributes
        self._time_blocks: List[np.ndarray] = []
        self._sample_blocks: List[np.ndarray] = []
        self._finalized = False
        self._dirty_since_save: bool = False

    # ------------------------------------------------------------------
    # Public mutation API
    # ------------------------------------------------------------------

    def append_block(self, timestamps: np.ndarray, samples: np.ndarray) -> None:
        """
        Append a new (timestamps, samples) block to the buffer.

        In the writer's append() method semantics, this *replaces* any
        previously accumulated data for the channel (clear-then-append).
        In extend() semantics, this concatenates to existing blocks.

        Parameters
        ----------
        timestamps : np.ndarray
            1D float64 array of time values. Must be monotonic and match
            the length of `samples`.
        samples : np.ndarray
            1D array of sample values.

        Raises
        ------
        ValueError
            If lengths mismatch or buffers have already been finalized.
        """
        if self._finalized:
            raise ValueError("Cannot append to a finalized ChannelBuffer")
        if len(timestamps) != len(samples):
            raise ValueError(
                f"timestamps length {len(timestamps)} != samples length {len(samples)}"
            )
        self._time_blocks.append(np.asarray(timestamps, dtype=np.float64))
        self._sample_blocks.append(np.asarray(samples))
        self._dirty_since_save = True

    def extend_block(self, timestamps: np.ndarray, samples: np.ndarray) -> None:
        """
        Concatenate a new block to existing buffer contents.

        Semantically identical to append_block(); the distinction is
        enforced at the writer level (extend requires existing data).

        Parameters
        ----------
        timestamps : np.ndarray
            1D float64 array. Must continue monotonically from the previous
            block (not enforced here; writer layer validates).
        samples : np.ndarray
            1D array of matching length.
        """
        # Same implementation; semantics differ only at call site
        self.append_block(timestamps, samples)

    def clear(self) -> None:
        """Reset buffers, discarding all accumulated data."""
        self._time_blocks.clear()
        self._sample_blocks.clear()
        self._finalized = False
        self._dirty_since_save = False

    def mark_saved(self) -> None:
        """Mark the current buffer content as persisted to disk."""
        self._dirty_since_save = False

    # ------------------------------------------------------------------
    # Query API
    # ------------------------------------------------------------------

    @property
    def has_data(self) -> bool:
        """True if at least one block has been appended."""
        return len(self._time_blocks) > 0

    @property
    def has_unsaved_data(self) -> bool:
        """True if the buffer holds data that has not yet been persisted."""
        return self.has_data and self._dirty_since_save

    @property
    def sample_count(self) -> int:
        """Total number of samples across all accumulated blocks."""
        return sum(len(b) for b in self._sample_blocks)

    def get_merged(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Return concatenated (timestamps, samples) arrays.

        Returns
        -------
        timestamps : np.ndarray
            Merged 1D float64 array.
        samples : np.ndarray
            Merged 1D array preserving the original dtype.

        Raises
        ------
        ValueError
            If no data has been appended.
        """
        if not self.has_data:
            raise ValueError("Cannot merge empty ChannelBuffer")
        timestamps = np.concatenate(self._time_blocks)
        samples = np.concatenate(self._sample_blocks)
        return timestamps, samples

    # ------------------------------------------------------------------
    # Conversion
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Consumption / flush-safe draining
    # ------------------------------------------------------------------

    def consume_merged(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Return merged (timestamps, samples) and permanently drain the buffers.

        This is used by the FRAGMENTED-mode writer so that each fragment
        contains exactly the data that was in memory at the moment of
        flush, without accumulating duplicate copies across rotations.

        Returns
        -------
        timestamps : np.ndarray
        samples : np.ndarray
        """
        ts, samples = self.get_merged()
        self._time_blocks.clear()
        self._sample_blocks.clear()
        self._finalized = True
        self._dirty_since_save = False
        return ts, samples
