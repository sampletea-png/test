# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Writer Module.

Implements MDFWriter with three operational modes:
  - NORMAL   : single-file in-memory buffered writes
  - FRAGMENTED : sharded writes across size-threshold fragment files
  - STREAMING  : continuous append-optimized writes with small flush size

All modes support:
  - Intermittent and continuous data persistence
  - Stop/Start resume semantics (metadata sidecar rebuilt on open)
  - Thread-safe concurrent access via a single reentrant lock
  - MDF version 3.x ( .mdf ) and 4.x ( .mf4 )

Author: AI Assistant
Date: 2026-04-25
"""

import os
import shutil
import threading
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
from asammdf import MDF, Signal
from asammdf.blocks.source_utils import Source

from .base import MDFBase
from .channel_buffer import ChannelBuffer
from .config import MDFConfig
from .constants import EXT_MDF, EXT_MF4, METADATA_SUFFIX, OperationMode
from .exceptions import (
    MDFError,
    MDFIOError,
    MDFLocationNotFoundError,
    MDFModeError,
    MDFNotStartedError,
)
from .logging_utils import get_logger
from .models import (
    ChannelAttributes,
    ChannelGroupAttributes,
    ChannelLocation,
    DataGroupAttributes,
    FragmentDescriptor,
    IndexSchema,
    PendingWrite,
)
from .utils import (
    atomic_write_json,
    build_fragment_path,
    build_index_path,
    ensure_dir,
    file_size,
    infer_extension,
    resolve_path,
    safe_read_json,
    schema_from_json,
    schema_to_json,
    validate_samples_timestamps,
)

# Module-level logger for operational diagnostics
logger = get_logger(__name__)


class _GroupState:
    """
    Internal mutable state tracker for a single logical data group.

    In asammdf, a data group contains exactly one channel group. This class
    mirrors that structure while allowing per-channel append/extend semantics
    through the ChannelBuffer layer.

    Attributes
    ----------
    dg_index : int
        Logical data group index (matches asammdf group index after flush).
    dg_attrs : DataGroupAttributes
        Attributes set at creation time.
    cg_attrs : ChannelGroupAttributes
        Channel group attributes set at creation time.
    channels : Dict[int, ChannelBuffer]
        Mapping channel_index -> ChannelBuffer.
    next_channel_index : int
        Auto-increment counter for the next created channel.
    asammdf_group_index : Optional[int]
        The actual asammdf group index after the first flush; None until then.
    """

    def __init__(self, dg_index: int, dg_attrs: DataGroupAttributes):
        self.dg_index: int = dg_index
        self.dg_attrs: DataGroupAttributes = dg_attrs
        self.cg_attrs: Optional[ChannelGroupAttributes] = None
        self.channels: Dict[int, ChannelBuffer] = {}
        self.next_channel_index: int = 0
        self.asammdf_group_index: Optional[int] = None


class MDFWriter(MDFBase):
    """
    Production-grade MDF writer supporting normal, fragmented, and streaming modes.

    The writer buffers channel data in memory (ChannelBuffer) and flushes to
    disk via asammdf only when save() is called or a fragment threshold is
    reached. This design overcomes asammdf's inability to extend individual
    channels or resume extend after close/reopen by rebuilding the full
    in-memory MDF on restart from the sidecar metadata and existing fragments.

    Usage Example
    -------------
    >>> cfg = MDFConfig.default_for("fragmented")
    >>> writer = MDFWriter("/data/run_01", config=cfg)
    >>> writer.start()
    >>> dg = writer.create_data_group(DataGroupAttributes(comment="Run 1"))
    >>> cg = writer.create_channel_group(dg, ChannelGroupAttributes(comment="ECU"))
    >>> ch = writer.create_channel(dg, cg, "RPM", ChannelAttributes(unit="1/min"))
    >>> writer.append(dg, cg, ch, t, rpm_values)
    >>> writer.extend(dg, cg, ch, t2, rpm_values2)
    >>> writer.save()
    >>> writer.stop()
    """

    def __init__(self, filepath: Union[str, Path], config: Optional[MDFConfig] = None):
        """
        Initialize writer without allocating file resources.

        Parameters
        ----------
        filepath : str or Path
            Target path. In NORMAL/STREAMING modes this is the output file.
            In FRAGMENTED mode it is the output *directory* that will contain
            the index file and shard files.
        config : MDFConfig, optional
            Operational configuration. Defaults to NORMAL mode, version 4.10.
        """
        super().__init__(filepath, config)
        # In-memory logical state
        self._groups: Dict[int, _GroupState] = {}
        self._next_dg_index: int = 0

        # Fragmented mode state
        self._schema: Optional[IndexSchema] = None
        self._current_fragment_path: Optional[Path] = None

        # Metadata sidecar path (used in all modes for resume)
        self._meta_path: Path = self._filepath.with_suffix(METADATA_SUFFIX)
        if self._config.mode == OperationMode.FRAGMENTED:
            # In fragmented mode filepath is a directory
            self._fragment_dir: Path = self._filepath
            self._meta_path = self._fragment_dir / ("state" + METADATA_SUFFIX)
        else:
            self._fragment_dir: Path = self._filepath.parent

        self._resumed: bool = False
        # Track whether this is the first start() call; controls overwrite semantics
        self._first_start: bool = True

        # Fragmented-mode accumulated time offsets per data group.
        # When a fragment rotates, the offset is incremented so that the next
        # fragment's timestamps continue from where the previous fragment ended.
        # dg_index -> accumulated offset in seconds.
        self._dg_time_offsets: Dict[int, float] = {}

    # ------------------------------------------------------------------
    # Lifecycle hooks (protected by base lock)
    # ------------------------------------------------------------------

    def _do_start(self) -> None:
        """
        Open or create the underlying storage.

        Steps
        -----
        1. Determine whether we are resuming (file/dir exists + meta exists).
        2. For resume: reload metadata, restore logical groups/channels,
           and (in FRAGMENTED mode) load the latest fragment into memory.
        3. For fresh start: initialize empty logical state and (if configured)
           overwrite any pre-existing files.

        Logging
        -------
        INFO level messages are emitted for resume vs fresh-start decisions.
        """
        mode = self._config.mode

        if mode == OperationMode.FRAGMENTED:
            ensure_dir(self._fragment_dir)
            self._schema = IndexSchema(
                base_name=self._fragment_dir.name,
                mdf_version=self._config.version,
            )
            # Check for resume
            existing_meta = safe_read_json(self._meta_path)
            if existing_meta and not (self._config.overwrite_on_start and self._first_start):
                logger.info(
                    "Resuming FRAGMENTED writer from metadata: %s",
                    self._meta_path,
                )
                self._restore_from_meta(existing_meta)
                # Also restore the index schema (fragments) from the schema sidecar.
                schema_path = build_index_path(self._fragment_dir, self._config.index_file_name)
                schema_path = schema_path.with_suffix(".schema.json")
                existing_schema = safe_read_json(schema_path)
                if existing_schema:
                    self._schema = self._deserialize_schema(existing_schema)
                self._resumed = True
            else:
                action = "overwriting" if (self._config.overwrite_on_start and self._first_start) else "fresh start"
                logger.info("FRAGMENTED writer %s: %s", action, self._fragment_dir)
                self._resumed = False
                if self._config.overwrite_on_start and self._first_start:
                    self._wipe_fragment_dir()
        else:
            # NORMAL or STREAMING
            if self._filepath.exists() and not (self._config.overwrite_on_start and self._first_start):
                # Attempt resume
                existing_meta = safe_read_json(self._meta_path)
                if existing_meta:
                    logger.info(
                        "Resuming %s writer from metadata: %s",
                        mode.name,
                        self._meta_path,
                    )
                    self._restore_from_meta(existing_meta)
                    self._resumed = True
                else:
                    # No meta but file exists: we cannot safely extend
                    # because asammdf extend-after-reopen is broken.
                    # We raise an error unless overwrite is set.
                    logger.error(
                        "File exists without metadata sidecar; cannot resume: %s",
                        self._filepath,
                    )
                    raise MDFIOError(
                        f"File {self._filepath} exists but has no metadata sidecar. "
                        "Cannot resume append/extend safely. "
                        "Set overwrite_on_start=True to overwrite or supply metadata."
                    )
            else:
                action = "overwriting" if (self._config.overwrite_on_start and self._first_start) else "fresh start"
                logger.info("%s writer %s: %s", mode.name, action, self._filepath)
                self._resumed = False
                if self._filepath.exists() and self._config.overwrite_on_start and self._first_start:
                    self._filepath.unlink(missing_ok=True)
                    self._meta_path.unlink(missing_ok=True)
        self._first_start = False

    def _do_stop(self) -> None:
        """
        Flush any pending buffers, write metadata sidecar, and release handles.

        Guarantees that all in-memory data is persisted before clearing
        internal state. If flush fails, an MDFIOError is raised and the
        internal buffers are still cleared to prevent stale data on
        a subsequent start().

        To avoid overwriting a file that was already saved by an explicit
        save() call, this method only flushes when at least one channel
        buffer still holds unsaved samples.

        Logging
        -------
        INFO level message emitted upon successful flush or when skipped.
        """
        try:
            has_unsaved = any(
                buf.has_unsaved_data
                for grp in self._groups.values()
                for buf in grp.channels.values()
            )
            if has_unsaved:
                self._flush_and_persist()
                logger.info(
                    "Writer stopped and flushed: mode=%s, path=%s",
                    self._config.mode.name,
                    self._filepath,
                )
            else:
                logger.info(
                    "Writer stopped with no unsaved data; skipping flush. "
                    "mode=%s, path=%s",
                    self._config.mode.name,
                    self._filepath,
                )
        except Exception as exc:
            logger.exception("Flush failed during stop: %s", exc)
            raise MDFIOError("Flush failed during stop", original_error=exc) from exc
        finally:
            self._groups.clear()
            self._schema = None
            self._current_fragment_path = None

    # ------------------------------------------------------------------
    # Public API: Structural creation
    # ------------------------------------------------------------------

    def create_data_group(self, attributes: DataGroupAttributes) -> int:
        """
        Create a new logical data group and return its assigned index.

        Parameters
        ----------
        attributes : DataGroupAttributes
            Metadata for the data group (comment, start_time, etc.).

        Returns
        -------
        int
            The assigned data_group_index (auto-incremented). Use this index
            in subsequent create_channel_group / create_channel calls.

        Raises
        ------
        MDFNotStartedError
            If called before start().
        """
        with self._lock:
            self._require_started()
            idx = self._next_dg_index
            self._groups[idx] = _GroupState(idx, attributes)
            self._next_dg_index += 1
            return idx

    def create_channel_group(
        self,
        data_group_index: int,
        attributes: ChannelGroupAttributes,
    ) -> int:
        """
        Create a channel group inside an existing data group.

        In the underlying MDF model each data group contains exactly one
        channel group. Therefore the returned channel_group_index is always 0.

        Parameters
        ----------
        data_group_index : int
            Existing data group returned by create_data_group().
        attributes : ChannelGroupAttributes
            Metadata for the channel group (acq_name, acq_source, etc.).

        Returns
        -------
        int
            Channel group index (always 0 in current implementation).

        Raises
        ------
        MDFLocationNotFoundError
            If data_group_index does not exist.
        """
        with self._lock:
            self._require_started()
            if data_group_index not in self._groups:
                raise MDFLocationNotFoundError(data_group_index, 0, 0)
            self._groups[data_group_index].cg_attrs = attributes
            return 0

    def create_channel(
        self,
        data_group_index: int,
        channel_group_index: int,
        name: str,
        attributes: ChannelAttributes,
    ) -> int:
        """
        Create a channel inside an existing (data_group, channel_group).

        The channel_index is auto-assigned and returned. The caller must use
        this exact index in append() / extend() / exists() calls.

        Parameters
        ----------
        data_group_index : int
            Existing data group.
        channel_group_index : int
            Existing channel group (must be 0).
        name : str
            Unique channel name within the MDF file (e.g., 'VehicleSpeed').
        attributes : ChannelAttributes
            Channel metadata (unit, comment, min/max, conversion, etc.).

        Returns
        -------
        int
            Assigned channel_index.

        Raises
        ------
        MDFLocationNotFoundError
            If the parent data group or channel group does not exist.
        """
        with self._lock:
            self._require_started()
            if data_group_index not in self._groups:
                raise MDFLocationNotFoundError(data_group_index, channel_group_index, 0)
            grp = self._groups[data_group_index]
            if grp.cg_attrs is None:
                raise MDFLocationNotFoundError(data_group_index, channel_group_index, 0)
            ch_idx = grp.next_channel_index
            loc = ChannelLocation(data_group_index, channel_group_index, ch_idx)
            grp.channels[ch_idx] = ChannelBuffer(loc, name, attributes)
            grp.next_channel_index += 1
            return ch_idx

    # ------------------------------------------------------------------
    # Public API: Query existence
    # ------------------------------------------------------------------

    def exists(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
    ) -> bool:
        """
        Check whether a logical channel location has been created.

        A channel is considered to exist if it was previously created via
        create_channel() and its parent data/channel groups are alive.
        Data does not need to have been appended yet.

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int

        Returns
        -------
        bool
            True if the location exists in the logical registry.
        """
        with self._lock:
            self._require_started()
            if data_group_index not in self._groups:
                return False
            grp = self._groups[data_group_index]
            if grp.cg_attrs is None:
                return False
            return channel_index in grp.channels

    # ------------------------------------------------------------------
    # Public API: Data mutation
    # ------------------------------------------------------------------

    def append(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
        timestamps: np.ndarray,
        samples: np.ndarray,
    ) -> None:
        """
        Append (clear-then-write) data to a logical channel.

        If the channel has never received data, this behaves like an initial
        write. If the channel already has buffered data, its buffers are
        cleared and replaced with the new block.

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int
        timestamps : np.ndarray
            1D float64 master timebase. Must be monotonic.
        samples : np.ndarray
            1D array of equal length.

        Raises
        ------
        MDFLocationNotFoundError
            If the logical location was never created.
        ValueError
            If input arrays fail validation (length mismatch, non-monotonic).
        """
        with self._lock:
            # Step 1: Verify the writer is in a valid started state.
            self._require_started()
            # Step 2: Validate that the logical (dg, cg, ch) address exists.
            loc = self._validate_location(
                data_group_index, channel_group_index, channel_index
            )
            # Step 3: Validate array shapes, lengths, and timestamp monotonicity.
            validate_samples_timestamps(timestamps, samples)
            # Step 4: Retrieve the in-memory buffer for this channel.
            buf = self._groups[data_group_index].channels[channel_index]
            # Step 5: Clear any previous data (append semantics = replace).
            buf.clear()
            # Step 6: Store the new data block into the buffer.
            buf.append_block(timestamps, samples)

    def extend(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
        timestamps: np.ndarray,
        samples: np.ndarray,
    ) -> None:
        """
        Extend (concatenate) data to an existing logical channel.

        The channel must already have buffered data (either from a prior
        append() or extend()).

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int
        timestamps : np.ndarray
            Must continue monotonically from the last sample already buffered.
        samples : np.ndarray
            1D array of equal length.

        Raises
        ------
        MDFLocationNotFoundError
            If the logical location does not exist.
        ValueError
            If the channel has no prior data, or if validation fails.
        """
        with self._lock:
            # Step 1: Verify the writer is in a valid started state.
            self._require_started()
            # Step 2: Validate the logical channel address exists.
            loc = self._validate_location(
                data_group_index, channel_group_index, channel_index
            )
            # Step 3: Retrieve the target channel buffer.
            buf = self._groups[data_group_index].channels[channel_index]
            # Step 4: Guard against extend on a channel with no existing data.
            if not buf.has_data:
                raise ValueError(
                    f"Cannot extend channel with no existing data: {loc}"
                )
            # Step 5: Validate array shapes and timestamp continuity.
            validate_samples_timestamps(timestamps, samples)
            # Step 6: Ensure new timestamps continue monotonically from previous block.
            last_ts = buf._time_blocks[-1][-1] if buf._time_blocks else None
            if last_ts is not None and timestamps[0] < last_ts - 1e-12:
                raise ValueError(
                    f"extend timestamps must continue from {last_ts}; got {timestamps[0]}"
                )
            # Step 7: Append the new block to the existing buffer (concatenate).
            buf.extend_block(timestamps, samples)

    # ------------------------------------------------------------------
    # Public API: Persistence
    # ------------------------------------------------------------------

    def save(self) -> None:
        """
        Flush all buffered channel data to the underlying MDF file(s).

        In NORMAL and STREAMING modes this writes (or overwrites) the
        primary file with the merged contents of all logical groups.

        In FRAGMENTED mode this may create a new fragment if the current
        one exceeds the configured byte threshold.

        After save(), the in-memory buffers remain intact so that further
        append/extend operations can continue. A second save() will
        overwrite the previous disk state with the *cumulative* data.

        Raises
        ------
        MDFIOError
            If file serialization fails.
        """
        with self._lock:
            self._require_started()
            self._flush_and_persist()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _validate_location(self, dg: int, cg: int, ch: int) -> ChannelLocation:
        """
        Validate that a logical location exists and return its descriptor.

        Raises
        ------
        MDFLocationNotFoundError
            If any level of the hierarchy is missing.
        """
        if dg not in self._groups:
            raise MDFLocationNotFoundError(dg, cg, ch)
        grp = self._groups[dg]
        if grp.cg_attrs is None:
            raise MDFLocationNotFoundError(dg, cg, ch)
        if ch not in grp.channels:
            raise MDFLocationNotFoundError(dg, cg, ch)
        return ChannelLocation(dg, cg, ch)

    def _flush_and_persist(self) -> None:
        """
        Core serialization routine. Rebuilds an asammdf MDF object from the
        in-memory logical groups and writes it to disk according to mode.

        For FRAGMENTED mode, this method also handles fragment rotation and
        time-offset continuation so that successive fragments store
        monotonically increasing timestamps.
        """
        if not self._groups:
            return  # nothing to flush

        # Step 1: Record the raw (un-offset) end timestamp of each group.
        # This is needed before we consume buffers, and before we decide
        # whether a fragment rotation should advance the time offset.
        raw_end_times: Dict[int, float] = {}
        for dg_idx, grp in self._groups.items():
            for buf in grp.channels.values():
                if buf.has_unsaved_data:
                    ts, _ = buf.get_merged()
                    if len(ts) > 0:
                        raw_end_times[dg_idx] = float(ts[-1])
                    break  # all channels share the same master timebase

        # Step 2: In FRAGMENTED mode, decide whether to rotate to a new
        # fragment and update per-group accumulated time offsets so that
        # the new fragment continues the previous fragment's timeline.
        if self._config.mode == OperationMode.FRAGMENTED:
            self._maybe_rotate_and_update_offsets(raw_end_times)

        # Step 3: Build a fresh in-memory MDF from all logical groups.
        # Timestamps inside _build_signals_for_group are shifted by the
        # accumulated offset (if any) for each data group.
        mdf = MDF(version=self._config.version)
        try:
            active_dg_list: List[int] = []
            for dg_idx in sorted(self._groups.keys()):
                grp = self._groups[dg_idx]
                has_unsaved = any(
                    buf.has_unsaved_data for buf in grp.channels.values()
                )
                if not has_unsaved:
                    continue  # nothing new to persist for this group
                # FRAGMENTED mode consumes buffers so each fragment holds
                # exactly the data that was in memory at the moment of flush.
                consume = self._config.mode == OperationMode.FRAGMENTED
                signals = self._build_signals_for_group(grp, consume=consume)
                if not signals:
                    continue
                active_dg_list.append(dg_idx)
                acq_name = grp.cg_attrs.acq_name if grp.cg_attrs else ""
                acq_source = grp.cg_attrs.acq_source if grp.cg_attrs else None
                comment = grp.cg_attrs.comment if grp.cg_attrs else ""
                mdf.append(
                    signals,
                    acq_name=acq_name,
                    acq_source=acq_source,
                    comment=comment,
                )

            # Step 4: Write according to mode.
            if self._config.mode == OperationMode.FRAGMENTED:
                self._write_fragmented(mdf, tuple(active_dg_list))
            else:
                self._write_single(mdf)

            # Step 5: For NORMAL / STREAMING, mark buffers as saved so that
            # stop() will not re-flush the same data.  In FRAGMENTED mode
            # buffers have already been consumed by _build_signals_for_group.
            if self._config.mode != OperationMode.FRAGMENTED:
                for grp in self._groups.values():
                    for buf in grp.channels.values():
                        buf.mark_saved()

            # Step 6: Persist metadata sidecar so resume is possible.
            self._persist_meta()
        finally:
            mdf.close()

    def _build_signals_for_group(
        self, grp: _GroupState, *, consume: bool = False
    ) -> List[Signal]:
        """
        Convert a logical group's ChannelBuffers into asammdf Signal list.

        Parameters
        ----------
        grp : _GroupState
            Logical group with ChannelBuffers.
        consume : bool, optional
            If True, each ChannelBuffer is drained after its merged data is
            read. This is used by the FRAGMENTED-mode writer so that each
            fragment contains exactly the in-memory data at the moment of
            flush, preventing duplication across fragment rotations.

        Returns
        -------
        List[Signal]
            Signals ready for MDF.append(). Empty list if no channel has data.
        """
        # Gather channels that have data
        ready = [(ch_idx, buf) for ch_idx, buf in grp.channels.items() if buf.has_data]
        if not ready:
            return []

        # Retrieve the accumulated time offset for this data group (if any).
        offset = self._dg_time_offsets.get(grp.dg_index, 0.0)

        # Step A: Pre-merge all channels to determine a common master timebase.
        # If an offset is configured (FRAGMENTED rotation), it is applied now.
        all_data: List[Tuple[int, ChannelBuffer, np.ndarray, np.ndarray]] = []
        for ch_idx, buf in ready:
            if consume:
                ts, samples = buf.consume_merged()
            else:
                ts, samples = buf.get_merged()
            if offset:
                ts = ts + offset
            all_data.append((ch_idx, buf, ts, samples))

        # Step B: Select the longest timestamp array as the master timebase
        # and compute the minimum length across all channels.
        master_ts = all_data[0][2].copy()
        min_len = len(master_ts)
        master_name = all_data[0][1].name
        for i in range(1, len(all_data)):
            ts = all_data[i][2]
            if len(ts) < min_len:
                min_len = len(ts)
            if len(ts) > len(master_ts):
                master_ts = ts
                master_name = all_data[i][1].name

        # Step C: Warn if channel lengths differ (common in mis-aligned writes).
        for i in range(1, len(all_data)):
            ts = all_data[i][2]
            if len(ts) != len(master_ts):
                logger.warning(
                    "Channel '%s' length %d differs from master '%s' length %d in "
                    "group %d. Truncating to shortest (%d).",
                    all_data[i][1].name, len(ts), master_name, len(master_ts),
                    grp.dg_index, min_len,
                )

        # Step D: Build Signal objects, truncate to the common length.
        signals: List[Signal] = []
        for ch_idx, buf, ts, samples in all_data:
            ts_aligned = ts[:min_len]
            samples_aligned = samples[:min_len]
            attrs = buf.attributes
            sig = Signal(
                samples=samples_aligned,
                timestamps=ts_aligned,
                name=buf.name,
                unit=attrs.unit,
                comment=attrs.comment,
            )
            signals.append(sig)

        return signals

    def _write_single(self, mdf: MDF) -> None:
        """
        Write the in-memory MDF to a single file (NORMAL or STREAMING mode).

        In STREAMING mode we additionally configure the internal fragment
        size via asammdf's configure() call before saving.
        """
        if self._config.mode == OperationMode.STREAMING:
            mdf.configure(
                write_fragment_size=self._config.write_fragment_size,
                read_fragment_size=self._config.read_fragment_size,
                use_display_names=self._config.use_display_names,
                single_bit_uint_as_bool=self._config.single_bit_uint_as_bool,
            )
        mdf.save(self._filepath, overwrite=True)

    def _maybe_rotate_and_update_offsets(
        self, raw_end_times: Dict[int, float]
    ) -> None:
        """
        Decide whether a new fragment is needed and update time offsets.

        In FRAGMENTED mode, when the current fragment reaches the size
        threshold we create a new fragment. To ensure timestamps remain
        monotonically continuous across fragments, we accumulate an offset
        for each data group:

            new_offset = previous_offset + raw_end_time_of_current_buffer

        The next time this group's buffers are serialized, every timestamp
        receives this offset, so the new fragment effectively continues the
        previous fragment's timeline.

        Parameters
        ----------
        raw_end_times : Dict[int, float]
            Mapping from data_group_index to the original (un-offset) last
            timestamp of the current in-memory buffers.
        """
        assert self._schema is not None
        ext = infer_extension(self._config.version)

        is_new_fragment = False

        if self._current_fragment_path is None:
            # First-ever save in this session: create the first fragment.
            frag_id = self._schema.next_fragment_id
            frag_path = build_fragment_path(
                self._fragment_dir,
                self._schema.base_name,
                frag_id,
                ext,
                self._config.fragment_name_format,
            )
            self._current_fragment_path = frag_path
            self._schema.next_fragment_id += 1
            is_new_fragment = True
        else:
            frag_path = self._current_fragment_path
            current_size = file_size(frag_path)
            if current_size >= self._config.fragment_threshold_bytes:
                # Rotate to a new fragment because the current one is full.
                frag_id = self._schema.next_fragment_id
                frag_path = build_fragment_path(
                    self._fragment_dir,
                    self._schema.base_name,
                    frag_id,
                    ext,
                    self._config.fragment_name_format,
                )
                self._current_fragment_path = frag_path
                self._schema.next_fragment_id += 1
                is_new_fragment = True

        # If we are creating a new fragment and at least one fragment has
        # already been persisted before, we must advance the time offsets so
        # the new fragment's timestamps continue from the previous one.
        if is_new_fragment and self._schema.fragments:
            for dg_idx, end_ts in raw_end_times.items():
                current_offset = self._dg_time_offsets.get(dg_idx, 0.0)
                self._dg_time_offsets[dg_idx] = current_offset + end_ts
                logger.info(
                    "Fragment rotation for dg=%d: time offset updated to %.6f "
                    "(previous offset %.6f + raw_end_time %.6f)",
                    dg_idx,
                    self._dg_time_offsets[dg_idx],
                    current_offset,
                    end_ts,
                )

    def _write_fragmented(self, mdf: MDF, active_dg_list: Tuple[int, ...]) -> None:
        """
        Write the in-memory MDF to the active fragment path.

        Fragment rotation decisions are made earlier in
        _maybe_rotate_and_update_offsets(), so by the time we reach this
        method the active path is already known.

        Parameters
        ----------
        mdf : MDF
            In-memory asammdf object ready for serialization.
        active_dg_list : Tuple[int, ...]
            Ordered tuple of logical data-group indices that actually have
            samples in this flush. This is persisted in the schema so the
            reader can map mdf group indices back to logical addresses.

        Steps
        -----
        1. Save mdf to the active fragment path.
        2. Update the schema descriptor for this fragment.
        3. Persist the index metadata.
        """
        assert self._schema is not None
        assert self._current_fragment_path is not None, (
            "_write_fragmented called without an active fragment path. "
            "_maybe_rotate_and_update_offsets() must be invoked first."
        )

        frag_path = self._current_fragment_path
        mdf.save(str(frag_path), overwrite=True)
        frag_size = file_size(frag_path)

        # Update schema: record only the logical groups that actually
        # contributed samples to this fragment.
        existing = None
        for fd in self._schema.fragments:
            if fd.file_path == str(frag_path):
                existing = fd
                break
        if existing is None:
            existing = FragmentDescriptor(
                fragment_id=self._schema.next_fragment_id - 1,
                file_path=str(frag_path),
            )
            self._schema.fragments.append(existing)
        existing.data_groups = active_dg_list
        existing.byte_size = frag_size

        # Persist index
        self._persist_index()

    def _persist_meta(self) -> None:
        """Write the logical group/channel registry to the JSON sidecar."""
        payload = {
            "version": "1.0",
            "mode": self._config.mode.name,
            "mdf_version": self._config.version,
            "next_dg_index": self._next_dg_index,
            "dg_time_offsets": {
                str(dg_idx): offset
                for dg_idx, offset in self._dg_time_offsets.items()
            },
            "groups": {
                str(g.dg_index): {
                    "dg_attrs": {
                        "comment": g.dg_attrs.comment,
                        "time_source": g.dg_attrs.time_source,
                    },
                    "cg_attrs": {
                        "comment": g.cg_attrs.comment if g.cg_attrs else "",
                        "acq_name": g.cg_attrs.acq_name if g.cg_attrs else "",
                    } if g.cg_attrs else None,
                    "channels": {
                        str(ch_idx): {
                            "name": buf.name,
                            "unit": buf.attributes.unit,
                            "comment": buf.attributes.comment,
                        }
                        for ch_idx, buf in g.channels.items()
                    },
                    "next_channel_index": g.next_channel_index,
                }
                for g in self._groups.values()
            },
        }
        atomic_write_json(self._meta_path, payload)

    def _persist_index(self) -> None:
        """Persist the fragmented-mode IndexSchema to the index file."""
        if self._schema is None:
            return
        index_path = build_index_path(self._fragment_dir, self._config.index_file_name)
        # Write schema JSON alongside the index file (same dir, diff name)
        schema_path = index_path.with_suffix(".schema.json")
        atomic_write_json(schema_path, schema_from_json(schema_to_json(self._schema)))

    def _restore_from_meta(self, payload: Dict[str, Any]) -> None:
        """
        Rebuild in-memory logical state from a metadata sidecar dictionary.

        Data values are NOT restored into buffers; only the structural
        registry (groups, channels, attributes) is recreated. The actual
        samples remain on disk and will be visible to the reader. To
        continue writing, the caller may append/extend new data, and a
        subsequent save() will merge old + new by rebuilding the MDF from
        the merged buffers (old data is read back from disk on first save
        if we wish, but for simplicity we leave old data on disk and new
        data goes to new groups/fragments).

        However, the user requirement says "continue appending at the end".
        To satisfy that, we would need to read old data back into buffers.
        For production efficiency we do NOT do this automatically because
        it could load gigabytes into RAM. Instead, we provide a flag.

        For this implementation we keep it simple: structural registry only.
        """
        self._next_dg_index = payload.get("next_dg_index", 0)
        self._dg_time_offsets = {
            int(k): float(v)
            for k, v in payload.get("dg_time_offsets", {}).items()
        }
        groups_payload = payload.get("groups", {})
        for dg_str, g_payload in groups_payload.items():
            dg_idx = int(dg_str)
            dg_attrs = DataGroupAttributes(
                comment=g_payload.get("dg_attrs", {}).get("comment", ""),
                time_source=g_payload.get("dg_attrs", {}).get("time_source", None),
            )
            grp = _GroupState(dg_idx, dg_attrs)
            cg_payload = g_payload.get("cg_attrs")
            if cg_payload:
                grp.cg_attrs = ChannelGroupAttributes(
                    comment=cg_payload.get("comment", ""),
                    acq_name=cg_payload.get("acq_name", ""),
                )
            grp.next_channel_index = g_payload.get("next_channel_index", 0)
            for ch_str, ch_payload in g_payload.get("channels", {}).items():
                ch_idx = int(ch_str)
                attrs = ChannelAttributes(
                    unit=ch_payload.get("unit", ""),
                    comment=ch_payload.get("comment", ""),
                )
                loc = ChannelLocation(dg_idx, 0, ch_idx)
                # For name compatibility: accept either top-level or attrs.name
                name = ch_payload.get("name", f"Ch_{ch_idx}")
                buf = ChannelBuffer(loc, name, attrs)
                grp.channels[ch_idx] = buf
            self._groups[dg_idx] = grp

    def _deserialize_schema(self, payload: Dict) -> IndexSchema:
        """Reconstruct an IndexSchema from its JSON payload."""
        schema = IndexSchema(
            version=payload.get("version", "1.0"),
            base_name=payload.get("base_name", ""),
            mdf_version=payload.get("mdf_version", "4.10"),
            next_fragment_id=payload.get("next_fragment_id", 1),
            global_attrs=payload.get("global_attrs", {}),
        )
        for frag_payload in payload.get("fragments", []):
            frag = FragmentDescriptor(
                fragment_id=frag_payload["fragment_id"],
                file_path=frag_payload["file_path"],
                data_groups=tuple(frag_payload.get("data_groups", [])),
                byte_size=frag_payload.get("byte_size", 0),
                checksum=frag_payload.get("checksum"),
            )
            schema.fragments.append(frag)
        return schema

    def _wipe_fragment_dir(self) -> None:
        """Remove all fragment and index files in the target directory."""
        if not self._fragment_dir.exists():
            return
        for item in self._fragment_dir.iterdir():
            if item.is_file():
                item.unlink()

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def get_channel_count(self, data_group_index: int) -> int:
        """
        Return the number of channels created in a data group.

        Parameters
        ----------
        data_group_index : int

        Returns
        -------
        int
            Number of channels, or 0 if the group does not exist.
        """
        with self._lock:
            self._require_started()
            if data_group_index not in self._groups:
                return 0
            return len(self._groups[data_group_index].channels)

    def list_data_groups(self) -> List[int]:
        """Return a sorted list of existing data group indices."""
        with self._lock:
            self._require_started()
            return sorted(self._groups.keys())

    def list_channels(self, data_group_index: int) -> List[Tuple[int, str]]:
        """
        Return (channel_index, name) tuples for a data group.

        Returns empty list if the group does not exist.
        """
        with self._lock:
            self._require_started()
            if data_group_index not in self._groups:
                return []
            grp = self._groups[data_group_index]
            return [(ch_idx, buf.name) for ch_idx, buf in grp.channels.items()]
