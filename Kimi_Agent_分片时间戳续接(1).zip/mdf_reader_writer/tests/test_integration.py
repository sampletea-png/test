# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Integration Tests.

End-to-end workflows that exercise writer and reader in concert across
all three operational modes. These tests simulate realistic acquisition
scenarios: multi-channel logging, stop/start resume cycles, fragmented
rotation under continuous write pressure, and cross-mode compatibility.

Run with: pytest tests/test_integration.py -v

Author: AI Assistant
Date: 2026-04-25
"""

import os
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    path = tempfile.mkdtemp(prefix="mdf_integ_test_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


# ------------------------------------------------------------------
# Full-cycle integration tests
# ------------------------------------------------------------------

class TestFullCycleNormal:
    """
    Complete write -> save -> stop -> read back validation for NORMAL mode.
    Covers multi-group, multi-channel, and extend-then-read scenarios.
    """

    def test_full_cycle_two_groups_two_channels(self, temp_dir):
        """
        Simulate a typical vehicle data log: two DAQ groups (engine, chassis)
        each with two channels. Write, save, stop, then read everything back
        and assert numerical fidelity.
        """
        filepath = os.path.join(temp_dir, "vehicle.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)

        # Phase 1: acquisition
        writer = MDFWriter(filepath, config=cfg)
        writer.start()

        dg_engine = writer.create_data_group(DataGroupAttributes(comment="Engine"))
        cg_engine = writer.create_channel_group(dg_engine, ChannelGroupAttributes(acq_name="ECU"))
        ch_rpm = writer.create_channel(dg_engine, cg_engine, "RPM", ChannelAttributes(unit="1/min"))
        ch_temp = writer.create_channel(dg_engine, cg_engine, "CoolantTemp", ChannelAttributes(unit="degC"))

        dg_chassis = writer.create_data_group(DataGroupAttributes(comment="Chassis"))
        cg_chassis = writer.create_channel_group(dg_chassis, ChannelGroupAttributes(acq_name="ABS"))
        ch_speed = writer.create_channel(dg_chassis, cg_chassis, "Speed", ChannelAttributes(unit="km/h"))
        ch_brake = writer.create_channel(dg_chassis, cg_chassis, "BrakePressure", ChannelAttributes(unit="bar"))

        t = np.linspace(0, 60, 6001)  # 100 Hz for 60 seconds
        writer.append(dg_engine, cg_engine, ch_rpm, t, 1000 + 500 * np.sin(t / 5))
        writer.append(dg_engine, cg_engine, ch_temp, t, 90 + 10 * np.cos(t / 10))
        writer.append(dg_chassis, cg_chassis, ch_speed, t, 120 * np.ones_like(t))
        writer.append(dg_chassis, cg_chassis, ch_brake, t, 0.5 * np.ones_like(t))

        # Extend with extra samples
        t_ext = np.linspace(60, 70, 1001)
        writer.extend(dg_engine, cg_engine, ch_rpm, t_ext, 1500 * np.ones_like(t_ext))
        writer.extend(dg_engine, cg_engine, ch_temp, t_ext, 95 * np.ones_like(t_ext))

        writer.save()
        writer.stop()

        # Phase 2: analysis
        reader = MDFReader(filepath)
        reader.start()

        # Verify group count
        groups = reader.list_data_groups()
        assert len(groups) == 2

        # Read back engine RPM
        ts_rpm, val_rpm = reader.get(dg_engine, cg_engine, ch_rpm)
        assert len(ts_rpm) == 7002  # 6001 + 1001
        np.testing.assert_allclose(val_rpm[:6001], 1000 + 500 * np.sin(ts_rpm[:6001] / 5), atol=1e-4)
        np.testing.assert_array_equal(val_rpm[6001:], 1500)

        # Read back chassis speed
        ts_speed, val_speed = reader.get(dg_chassis, cg_chassis, ch_speed)
        assert len(ts_speed) == 6001
        np.testing.assert_array_equal(val_speed, 120)

        # Time-window query on coolant temp
        ts_win, val_win = reader.get_range(dg_engine, cg_engine, ch_temp, 10.0, 20.0)
        assert ts_win[0] >= 10.0
        assert ts_win[-1] < 20.0

        reader.stop()

    def test_resume_and_continue_appending(self, temp_dir):
        """
        Simulate a long-term logger that is periodically stopped and restarted
        to continue acquisition. The final file contains the most recent write
        because each save() overwrites the file with the current in-memory state.
        (Resume restores structural metadata only; old sample data remains on disk
        but is not reloaded into memory for performance.)
        """
        filepath = os.path.join(temp_dir, "longterm.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)

        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes(comment="LongTerm"))
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Load", ChannelAttributes(unit="%"))

        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([10, 20]))
        writer.save()
        writer.stop()

        # Simulate power cycle: restart and continue
        writer.start()
        # After resume the channel exists but has no in-memory data;
        # we append new data (which replaces the previous file on save).
        writer.append(dg, cg, ch, np.array([2.0, 3.0, 4.0]), np.array([30, 40, 50]))
        writer.save()
        writer.stop()

        # Final read-back
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        # The second save overwrites the first, so we see only the latest 3 samples.
        assert len(ts) == 3
        np.testing.assert_array_equal(samples, [30, 40, 50])


class TestFullCycleFragmented:
    """
    Complete write -> read validation for FRAGMENTED mode.
    Validates that fragments rotate, index stays consistent, and reads
    transparently stitch across shards.
    """

    def test_fragmented_full_cycle_multi_group(self, temp_dir):
        """
        Create three data groups with distinct channels, force multiple fragment
        rotations with a tiny threshold, then read back every channel from every
        group via the reader.
        """
        frag_dir = os.path.join(temp_dir, "shards")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=2048,  # very small to force rotation
            overwrite_on_start=True,
        )

        writer = MDFWriter(frag_dir, config=cfg)
        writer.start()

        # Group 0: high-frequency voltage
        dg0 = writer.create_data_group(DataGroupAttributes(comment="Power"))
        cg0 = writer.create_channel_group(dg0, ChannelGroupAttributes())
        ch0 = writer.create_channel(dg0, cg0, "Voltage", ChannelAttributes(unit="V"))

        # Group 1: low-frequency temperature
        dg1 = writer.create_data_group(DataGroupAttributes(comment="Thermal"))
        cg1 = writer.create_channel_group(dg1, ChannelGroupAttributes())
        ch1 = writer.create_channel(dg1, cg1, "Temp", ChannelAttributes(unit="C"))

        # Write enough data to trigger at least one rotation.
        # In FRAGMENTED mode each save() consumes the in-memory buffer,
        # so each batch must be provided as a fresh append with zero-based
        # timestamps; the writer's offset mechanism will make them contiguous.
        for i in range(5):
            t0 = np.linspace(0, 0.9, 200)
            t1 = np.linspace(0, 0.9, 100)
            writer.append(dg0, cg0, ch0, t0, 230 * np.ones_like(t0))
            writer.append(dg1, cg1, ch1, t1, 25 + i * np.ones_like(t1))
            writer.save()

        writer.stop()

        # Read back via fragmented reader
        reader = MDFReader(frag_dir, config=cfg)
        reader.start()

        groups = reader.list_data_groups()
        assert dg0 in groups
        assert dg1 in groups

        ts0, val0 = reader.get(dg0, cg0, ch0)
        # 5 appends * 200 samples each = 1000 (the writer consumes buffers
        # per save, but each fragment contains exactly one batch).
        assert len(ts0) == 1000
        np.testing.assert_array_equal(val0, 230)

        ts1, val1 = reader.get(dg1, cg1, ch1)
        assert len(ts1) == 500

        # Verify timestamps are monotonically increasing across shards
        # (no resets to zero at fragment boundaries).
        assert ts0[0] >= 0.0
        assert np.all(np.diff(ts0) >= 0)
        assert ts1[0] >= 0.0
        assert np.all(np.diff(ts1) >= 0)

        # Range query using the actual available window
        mid = (ts1[0] + ts1[-1]) / 2
        ts_win, val_win = reader.get_range(dg1, cg1, ch1, ts1[0], mid)
        assert len(ts_win) > 0
        assert ts_win[0] >= ts1[0]
        assert ts_win[-1] < mid

        reader.stop()


class TestFullCycleStreaming:
    """
    Streaming-mode integration: continuous append with frequent save()
    calls mimicking a real-time acquisition daemon.
    """

    def test_streaming_daemon_simulation(self, temp_dir):
        """
        Simulate a daemon that receives 10 Hz samples and flushes every second.
        After stop, read back the entire timeline.
        """
        filepath = os.path.join(temp_dir, "daemon.mf4")
        cfg = MDFConfig(mode=OperationMode.STREAMING, version=MDFVersion.V4_10)

        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes(comment="Daemon"))
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Sensor", ChannelAttributes(unit="g"))

        # Simulate 5 seconds of 10 Hz data, flush every second
        for sec in range(5):
            t = np.linspace(sec, sec + 0.9, 10)
            s = np.random.uniform(-1, 1, size=10)
            if sec == 0:
                writer.append(dg, cg, ch, t, s)
            else:
                writer.extend(dg, cg, ch, t, s)
            writer.save()

        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        assert len(ts) == 50  # 5 seconds * 10 Hz
        assert ts[0] >= 0.0
        assert ts[-1] < 5.0
        # Verify monotonicity
        assert np.all(np.diff(ts) >= 0)


# ------------------------------------------------------------------
# Cross-mode compatibility tests
# ------------------------------------------------------------------

class TestCrossModeCompatibility:
    """
    Verify that files written in one mode can be read back correctly,
    and that mode-specific metadata does not leak between sessions.
    """

    def test_normal_file_read_by_streaming_config(self, temp_dir):
        """
        A NORMAL-mode file is fundamentally identical to a STREAMING-mode file
        on disk; only the write behavior differs. A reader configured for
        STREAMING must still open and parse a NORMAL-written file.
        """
        filepath = os.path.join(temp_dir, "cross_mode.mf4")
        write_cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        read_cfg = MDFConfig(mode=OperationMode.STREAMING, version=MDFVersion.V4_10)

        writer = MDFWriter(filepath, config=write_cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "X", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([10, 20]))
        writer.save()
        writer.stop()

        reader = MDFReader(filepath, config=read_cfg)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        np.testing.assert_array_equal(samples, [10, 20])

    def test_fragmented_index_survives_reader_only_access(self, temp_dir):
        """
        Opening a fragmented directory with a reader must not mutate the
        index schema or fragment files.
        """
        frag_dir = os.path.join(temp_dir, "read_only_frag")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=1024,
            overwrite_on_start=True,
        )

        writer = MDFWriter(frag_dir, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Y", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        writer.save()
        writer.stop()

        # Record pre-reader state
        schema_path = os.path.join(frag_dir, "index.schema.json")
        with open(schema_path, "r") as f:
            pre_content = f.read()

        # Reader only
        reader = MDFReader(frag_dir, config=cfg)
        reader.start()
        reader.get(dg, cg, ch)
        reader.stop()

        with open(schema_path, "r") as f:
            post_content = f.read()

        assert pre_content == post_content, "Reader must not mutate index schema"
