# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Round 1 Self-Inspection Tests.

Focus: Basic data quantity and ordering correctness across all three modes.
Detects: lost samples, ordering errors, timestamp discontinuities, file corruption.

Memory budget: < 300 MB per test process.
"""

import gc
import os
import shutil
import sys
import tempfile
import time
import tracemalloc
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
)


def current_memory_mb():
    """Return current process RSS memory in MB."""
    tracemalloc.start()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / (1024 * 1024)


@pytest.fixture
def temp_dir():
    p = tempfile.mkdtemp(prefix="selfcheck_r1_")
    yield p
    shutil.rmtree(p, ignore_errors=True)


# ------------------------------------------------------------------
# Round 1-A: Append/Extend quantity verification (NORMAL)
# ------------------------------------------------------------------

class TestR1_NormalQuantityOrdering:
    """Verify sample counts and ordering are preserved exactly."""

    def test_append_then_extend_count(self, temp_dir):
        """100 + 50 = 150 samples must round-trip."""
        f = os.path.join(temp_dir, "r1a.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(100.0), np.arange(100))
        w.extend(dg, cg, ch, np.arange(100.0, 150.0), np.arange(100, 150))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == 150
        assert len(samples) == 150
        np.testing.assert_array_equal(samples, np.arange(150))

    def test_double_append_overwrites(self, temp_dir):
        """Second append must replace first, not concatenate."""
        f = os.path.join(temp_dir, "r1b.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([10, 20]))
        w.append(dg, cg, ch, np.array([2.0, 3.0, 4.0]), np.array([30, 40, 50]))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 3
        np.testing.assert_array_equal(samples, [30, 40, 50])

    def test_alternating_append_extend(self, temp_dir):
        """append → extend → append → extend must yield only last append + extend."""
        f = os.path.join(temp_dir, "r1c.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.array([0.0]), np.array([0]))
        w.extend(dg, cg, ch, np.array([1.0]), np.array([1]))
        w.append(dg, cg, ch, np.array([10.0]), np.array([10]))
        w.extend(dg, cg, ch, np.array([11.0]), np.array([11]))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 2
        np.testing.assert_array_equal(samples, [10, 11])


# ------------------------------------------------------------------
# Round 1-B: FRAGMENTED mode data continuity across shards
# ------------------------------------------------------------------

class TestR1_FragmentedContinuity:
    """Verify no sample loss or duplication when fragments rotate."""

    def test_single_group_across_three_fragments(self, temp_dir):
        """Write 3 batches, force rotation each time, verify exact counts."""
        frag_dir = os.path.join(temp_dir, "frag_r1")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())

        # In FRAGMENTED mode each save() consumes the in-memory buffer,
        # so we use append for each batch (with contiguous raw timestamps).
        for i in range(3):
            t = np.linspace(i * 100, i * 100 + 99, 100)
            s = np.arange(i * 100, i * 100 + 100)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 300
        np.testing.assert_array_equal(samples, np.arange(300))

    def test_fragmented_timestamps_are_monotonic(self, temp_dir):
        """Timestamps across fragments must never decrease."""
        frag_dir = os.path.join(temp_dir, "frag_r1_ts")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "T", ChannelAttributes())
        for i in range(5):
            # Provide contiguous raw timestamps so each batch naturally follows.
            t = np.linspace(i * 10, i * 10 + 9, 100)
            v = t * 2
            w.append(dg, cg, ch, t, v)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, _ = r.get(dg, cg, ch)
        r.stop()
        assert np.all(np.diff(ts) >= -1e-9)
        assert ts[-1] > ts[0]


# ------------------------------------------------------------------
# Round 1-C: Multi-channel / multi-group ordering
# ------------------------------------------------------------------

class TestR1_MultiChannelOrdering:
    """Ensure multi-channel data alignment is preserved."""

    def test_two_channels_same_group(self, temp_dir):
        """Two channels with identical timestamps must align."""
        f = os.path.join(temp_dir, "r1d.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch_a = w.create_channel(dg, cg, "A", ChannelAttributes())
        ch_b = w.create_channel(dg, cg, "B", ChannelAttributes())
        t = np.arange(500.0)
        w.append(dg, cg, ch_a, t, t * 2)
        w.append(dg, cg, ch_b, t, t * 3)
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts_a, s_a = r.get(dg, cg, ch_a)
        ts_b, s_b = r.get(dg, cg, ch_b)
        r.stop()
        assert len(ts_a) == len(ts_b) == 500
        np.testing.assert_array_equal(ts_a, ts_b)
        np.testing.assert_array_equal(s_a, t * 2)
        np.testing.assert_array_equal(s_b, t * 3)

    def test_two_groups_independent(self, temp_dir):
        """Two groups with different lengths must not interfere."""
        f = os.path.join(temp_dir, "r1e.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg0 = w.create_data_group(DataGroupAttributes())
        cg0 = w.create_channel_group(dg0, ChannelGroupAttributes())
        ch0 = w.create_channel(dg0, cg0, "G0", ChannelAttributes())
        w.append(dg0, cg0, ch0, np.arange(100.0), np.arange(100))

        dg1 = w.create_data_group(DataGroupAttributes())
        cg1 = w.create_channel_group(dg1, ChannelGroupAttributes())
        ch1 = w.create_channel(dg1, cg1, "G1", ChannelAttributes())
        w.append(dg1, cg1, ch1, np.arange(200.0), np.arange(200) + 1000)

        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        _, s0 = r.get(dg0, cg0, ch0)
        _, s1 = r.get(dg1, cg1, ch1)
        r.stop()
        assert len(s0) == 100
        assert len(s1) == 200
        np.testing.assert_array_equal(s0, np.arange(100))
        np.testing.assert_array_equal(s1, np.arange(200) + 1000)


# ------------------------------------------------------------------
# Round 1-D: Memory budget check
# ------------------------------------------------------------------

class TestR1_MemoryBudget:
    """Ensure no test exceeds ~300 MB RSS."""

    def test_1m_samples_within_budget(self, temp_dir):
        """1 million double-precision samples must stay under 300 MB."""
        f = os.path.join(temp_dir, "r1mem.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Big", ChannelAttributes())
        n = 1_000_000
        t = np.linspace(0, 1, n)
        s = np.sin(t)
        w.append(dg, cg, ch, t, s)
        w.save()
        w.stop()
        del t, s
        gc.collect()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == n
        mb = current_memory_mb()
        assert mb < 300, f"Memory usage {mb:.1f} MB exceeded 300 MB"
