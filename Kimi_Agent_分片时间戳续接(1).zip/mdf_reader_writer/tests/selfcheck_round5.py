# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Round 5 Final Regression.

Runs the complete suite (existing unit tests + all 4 rounds of self-check)
in one shot to confirm zero regressions after all fixes.

Memory budget: < 300 MB per test process.
"""

import gc
import os
import shutil
import sys
import tempfile
import threading
import time
import tracemalloc
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
    MDFLocationNotFoundError,
    MDFIOError,
)


def current_memory_mb():
    tracemalloc.start()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / (1024 * 1024)


@pytest.fixture
def temp_dir():
    p = tempfile.mkdtemp(prefix="selfcheck_r5_")
    yield p
    shutil.rmtree(p, ignore_errors=True)


# ------------------------------------------------------------------
# Round 5: Full end-to-end regression for all three modes
# ------------------------------------------------------------------

class TestR5_FullRegression:
    """End-to-end workflows after all cumulative fixes."""

    def test_normal_full_lifecycle(self, temp_dir):
        """NORMAL: create → append → extend → save → read → range → count."""
        f = os.path.join(temp_dir, "r5_normal.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes(comment="engine"))
        cg = w.create_channel_group(dg, ChannelGroupAttributes(acq_name="ECU"))
        ch = w.create_channel(dg, cg, "RPM", ChannelAttributes(unit="1/min"))
        t1 = np.linspace(0, 60, 6001)
        w.append(dg, cg, ch, t1, 1000 + 500 * np.sin(t1 / 5))
        t2 = np.linspace(60, 70, 1001)
        w.extend(dg, cg, ch, t2, 1500 * np.ones(1001))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        assert len(ts) == 7002
        ts_win, s_win = r.get_range(dg, cg, ch, 10.0, 20.0)
        assert 900 <= len(ts_win) <= 1100
        ts_page, s_page = r.get_from_time(dg, cg, ch, 55.0, max_count=200)
        assert len(ts_page) == 200
        r.stop()

    def test_fragmented_full_lifecycle(self, temp_dir):
        """FRAGMENTED: multiple batches with auto-rotation and contiguous timestamps."""
        frag_dir = os.path.join(temp_dir, "r5_frag")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes(comment="telemetry"))
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Load", ChannelAttributes(unit="%"))
        for i in range(8):
            t = np.linspace(0, 9, 100)
            s = np.full(100, i)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        assert len(samples) == 800
        # Each 100-sample chunk has the same value i
        for i in range(8):
            np.testing.assert_array_equal(
                samples[i * 100:(i + 1) * 100], np.full(100, i)
            )
        # Timestamps must be monotonically increasing (offset mechanism)
        assert np.all(np.diff(ts) >= -1e-9)
        assert ts[0] >= 0.0
        r.stop()

    def test_streaming_full_lifecycle(self, temp_dir):
        """STREAMING: frequent small appends simulate real-time daemon."""
        f = os.path.join(temp_dir, "r5_stream.mf4")
        cfg = MDFConfig(OperationMode.STREAMING, MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes(comment="daemon"))
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Sensor", ChannelAttributes(unit="g"))
        for sec in range(10):
            t = np.linspace(sec, sec + 0.9, 10)
            s = np.random.uniform(-1, 1, size=10)
            if sec == 0:
                w.append(dg, cg, ch, t, s)
            else:
                w.extend(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(f, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == 100
        assert np.all(np.diff(ts) >= 0)

    def test_cross_mode_read_normal_as_streaming(self, temp_dir):
        """NORMAL file must be readable with STREAMING reader config."""
        f = os.path.join(temp_dir, "r5_cross.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(500.0), np.arange(500))
        w.save()
        w.stop()

        r = MDFReader(f, MDFConfig(OperationMode.STREAMING, MDFVersion.V4_10))
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 500
        np.testing.assert_array_equal(samples, np.arange(500))

    def test_multi_group_multi_channel(self, temp_dir):
        """3 groups * 2 channels each with different lengths."""
        f = os.path.join(temp_dir, "r5_multi.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        w.start()
        expected = {}
        for g in range(3):
            dg = w.create_data_group(DataGroupAttributes(comment=f"G{g}"))
            cg = w.create_channel_group(dg, ChannelGroupAttributes())
            channel_data = []
            min_len = float('inf')
            for c in range(2):
                ch = w.create_channel(dg, cg, f"G{g}C{c}", ChannelAttributes())
                n = (g + 1) * (c + 1) * 100
                t = np.arange(n, dtype=float)
                s = np.arange(n) + g * 1000 + c * 100
                w.append(dg, cg, ch, t, s)
                channel_data.append(s)
                min_len = min(min_len, n)
            # The MDF format requires all channels in a group to share the
            # same record count, so the writer truncates to the shortest.
            for c, s in enumerate(channel_data):
                expected[(dg, c)] = s[:min_len]
        w.save()
        w.stop()

        r = MDFReader(f, cfg)
        r.start()
        groups = r.list_data_groups()
        assert len(groups) == 3
        for g, dg in enumerate(groups):
            for c in range(2):
                _, samples = r.get(dg, 0, c)
                np.testing.assert_array_equal(samples, expected[(dg, c)])
        r.stop()

    def test_memory_under_300mb(self, temp_dir):
        """1M samples write+read must stay under 300 MB."""
        f = os.path.join(temp_dir, "r5_mem.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Big", ChannelAttributes())
        n = 1_000_000
        t = np.linspace(0, 1, n)
        s = np.sin(t)
        w.append(dg, cg, ch, t, s)
        w.save()
        w.stop()
        del t, s
        gc.collect()

        r = MDFReader(f, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == n
        mb = current_memory_mb()
        assert mb < 300, f"RSS {mb:.1f} MB exceeded 300 MB"

    def test_concurrent_reader_writer_no_crash(self, temp_dir):
        """Concurrent reader and writer on separate files."""
        f_write = os.path.join(temp_dir, "r5_conc_w.mf4")
        f_read = os.path.join(temp_dir, "r5_conc_r.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10)

        # Pre-create read file
        w_pre = MDFWriter(f_read, cfg)
        w_pre.start()
        dg_r = w_pre.create_data_group(DataGroupAttributes())
        cg_r = w_pre.create_channel_group(dg_r, ChannelGroupAttributes())
        ch_r = w_pre.create_channel(dg_r, cg_r, "R", ChannelAttributes())
        w_pre.append(dg_r, cg_r, ch_r, np.arange(100.0), np.arange(100))
        w_pre.save()
        w_pre.stop()

        w = MDFWriter(f_write, cfg)
        r = MDFReader(f_read)
        w.start()
        r.start()
        errors = []

        def writer_worker():
            try:
                dg_w = w.create_data_group(DataGroupAttributes())
                cg_w = w.create_channel_group(dg_w, ChannelGroupAttributes())
                ch_w = w.create_channel(dg_w, cg_w, "W", ChannelAttributes())
                for i in range(50):
                    w.append(dg_w, cg_w, ch_w, np.array([i]), np.array([i * 2]))
                w.save()
            except Exception as exc:
                errors.append(exc)

        def reader_worker():
            try:
                for _ in range(50):
                    ts, s = r.get(dg_r, cg_r, ch_r)
                    assert len(ts) == 100
            except Exception as exc:
                errors.append(exc)

        t0 = threading.Thread(target=writer_worker)
        t1 = threading.Thread(target=reader_worker)
        t0.start()
        t1.start()
        t0.join()
        t1.join()
        w.stop()
        r.stop()
        assert not errors
