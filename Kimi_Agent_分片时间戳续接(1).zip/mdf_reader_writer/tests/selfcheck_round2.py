# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Round 2 Self-Inspection Tests.

Focus: Deep correctness of data ordering, quantity, and cross-fragment stitching.
Detects: mis-ordered samples, incorrect counts, timestamp gaps, duplicated data.

Memory budget: < 300 MB per test process.
"""

import gc
import os
import shutil
import sys
import tempfile
import tracemalloc
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
)


def current_memory_mb():
    tracemalloc.start()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / (1024 * 1024)


@pytest.fixture
def temp_dir():
    p = tempfile.mkdtemp(prefix="selfcheck_r2_")
    yield p
    shutil.rmtree(p, ignore_errors=True)


# ------------------------------------------------------------------
# Round 2-A: FRAGMENTED mode cross-fragment data stitch exactness
# ------------------------------------------------------------------

class TestR2_FragmentedStitch:
    """Verify reader concatenates fragments in correct order without gaps."""

    def test_stitched_timestamps_no_gaps(self, temp_dir):
        """Five fragments stitched must yield a perfectly contiguous timeline."""
        frag_dir = os.path.join(temp_dir, "stitch")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Seq", ChannelAttributes())

        # 5 batches of 100 samples, raw timestamps 0..9 each
        for i in range(5):
            t = np.linspace(0, 9, 100)
            s = np.arange(i * 100, (i + 1) * 100)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()

        assert len(samples) == 500
        # Samples must be in exact order 0..499
        np.testing.assert_array_equal(samples, np.arange(500))
        # Timestamps must be monotonically non-decreasing with no large gaps
        assert np.all(np.diff(ts) >= -1e-9)
        # First fragment starts near 0; last fragment ends near 36 (0.9*4*10)
        assert ts[0] >= 0.0
        assert ts[-1] > ts[0]

    def test_fragment_order_preserved(self, temp_dir):
        """Fragment file listing order must match logical append order."""
        frag_dir = os.path.join(temp_dir, "order")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=1024,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Inc", ChannelAttributes())

        for i in range(4):
            t = np.linspace(0, 4, 50)
            s = np.full(50, i)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()

        assert len(samples) == 200
        # Each 50-sample chunk should have the same value i
        for i in range(4):
            chunk = samples[i * 50:(i + 1) * 50]
            np.testing.assert_array_equal(chunk, np.full(50, i))

    def test_range_query_across_fragments(self, temp_dir):
        """get_range must correctly filter samples that span multiple shards."""
        frag_dir = os.path.join(temp_dir, "range_frag")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "R", ChannelAttributes())

        for i in range(5):
            t = np.linspace(0, 9, 100)
            s = np.arange(i * 100, (i + 1) * 100)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        # Actual timestamps are offset by previous fragments.
        # With raw 0..9 per batch and offset accumulation:
        #   batch0 actual: 0..9      (offset 0)
        #   batch1 actual: 9..18    (offset 9)
        #   batch2 actual: 18..27   (offset 18)
        # Query window [5, 15] should cover tail of batch0 + head of batch1
        ts_win, s_win = r.get_range(dg, cg, ch, 5.0, 15.0)
        r.stop()

        assert len(s_win) > 0
        assert ts_win[0] >= 5.0
        assert ts_win[-1] < 15.0
        # All returned sample values must lie inside the expected range
        assert np.all(s_win >= 0) and np.all(s_win < 500)


# ------------------------------------------------------------------
# Round 2-B: Data quantity exactness under various append patterns
# ------------------------------------------------------------------

class TestR2_QuantityExactness:
    """Sample counts must match exactly regardless of append/extend pattern."""

    def test_append_then_save_then_append(self, temp_dir):
        """append→save→append must yield only the second batch in NORMAL mode."""
        f = os.path.join(temp_dir, "r2b.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(50.0), np.arange(50))
        w.save()
        w.append(dg, cg, ch, np.arange(100.0, 150.0), np.arange(100, 150))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 50
        np.testing.assert_array_equal(samples, np.arange(100, 150))

    def test_large_batch_then_small_extend(self, temp_dir):
        """1M samples + 1 sample must round-trip as 1_000_001."""
        f = os.path.join(temp_dir, "r2c.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Big", ChannelAttributes())
        big = np.arange(1_000_000.0)
        w.append(dg, cg, ch, big, big.astype(np.int64))
        w.extend(dg, cg, ch, np.array([1_000_000.0]), np.array([1_000_000]))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == 1_000_001
        assert samples[-1] == 1_000_000
        mb = current_memory_mb()
        assert mb < 300

    def test_unequal_channel_lengths_in_group(self, temp_dir):
        """Shorter channel must be truncated to match group length."""
        f = os.path.join(temp_dir, "r2d.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch_long = w.create_channel(dg, cg, "L", ChannelAttributes())
        ch_short = w.create_channel(dg, cg, "S", ChannelAttributes())
        w.append(dg, cg, ch_long, np.arange(100.0), np.arange(100))
        w.append(dg, cg, ch_short, np.arange(50.0), np.arange(50) + 1000)
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        _, s_long = r.get(dg, cg, ch_long)
        _, s_short = r.get(dg, cg, ch_short)
        r.stop()
        assert len(s_long) == 50
        assert len(s_short) == 50
        np.testing.assert_array_equal(s_long, np.arange(50))
        np.testing.assert_array_equal(s_short, np.arange(50) + 1000)


# ------------------------------------------------------------------
# Round 2-C: STOP / START resume data continuity
# ------------------------------------------------------------------

class TestR2_ResumeContinuity:
    """After stop/start the structural registry is restored; new writes continue."""

    def test_normal_resume_and_overwrite(self, temp_dir):
        """NORMAL mode: resume then append must overwrite previous file content."""
        f = os.path.join(temp_dir, "r2e.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, version=MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(10.0), np.arange(10))
        w.save()
        w.stop()

        w.start()
        # Resume restores structure but buffer is empty; append replaces.
        w.append(dg, cg, ch, np.arange(20.0, 30.0), np.arange(20, 30))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        _, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 10
        np.testing.assert_array_equal(samples, np.arange(20, 30))


# ------------------------------------------------------------------
# Round 2-D: Memory usage under fragmented write pressure
# ------------------------------------------------------------------

class TestR2_MemoryUnderPressure:
    """Ensure fragmented rotations do not leak memory."""

    def test_many_small_fragments(self, temp_dir):
        """Create 20 fragments and ensure RSS stays below 300 MB."""
        frag_dir = os.path.join(temp_dir, "many_frag")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=256,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Pressure", ChannelAttributes())

        for i in range(20):
            t = np.linspace(0, 9, 200)
            s = np.full(200, i)
            w.append(dg, cg, ch, t, s)
            w.save()
        w.stop()

        # Reader must still retrieve all 4000 samples across 20 fragments
        r = MDFReader(frag_dir, cfg)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 4000
        mb = current_memory_mb()
        assert mb < 300, f"RSS {mb:.1f} MB exceeded 300 MB"
