# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Round 3 Self-Inspection Tests.

Focus: Edge cases, boundary conditions, and cross-mode compatibility.
Detects: off-by-one errors, empty channels, version mismatch, unicode names,
         concurrent read/write safety.

Memory budget: < 300 MB per test process.
"""

import gc
import os
import shutil
import sys
import tempfile
import threading
import time
import tracemalloc
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
    MDFLocationNotFoundError,
    MDFIOError,
)


def current_memory_mb():
    tracemalloc.start()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / (1024 * 1024)


@pytest.fixture
def temp_dir():
    p = tempfile.mkdtemp(prefix="selfcheck_r3_")
    yield p
    shutil.rmtree(p, ignore_errors=True)


# ------------------------------------------------------------------
# Round 3-A: Boundary conditions
# ------------------------------------------------------------------

class TestR3_BoundaryConditions:
    """Stress the system with extreme but valid inputs."""

    def test_empty_group_save(self, temp_dir):
        """Saving a group with no channel data must not crash."""
        f = os.path.join(temp_dir, "r3a.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        w.create_channel(dg, cg, "Empty", ChannelAttributes())
        w.save()
        w.stop()
        assert os.path.exists(f)

    def test_single_sample(self, temp_dir):
        """A channel with exactly one sample must round-trip."""
        f = os.path.join(temp_dir, "r3b.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "One", ChannelAttributes())
        w.append(dg, cg, ch, np.array([0.0]), np.array([42]))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == 1
        assert samples[0] == 42

    def test_negative_timestamps(self, temp_dir):
        """Timestamps may be negative (pre-trigger data)."""
        f = os.path.join(temp_dir, "r3c.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Neg", ChannelAttributes())
        t = np.linspace(-5, 0, 51)
        w.append(dg, cg, ch, t, t * 10)
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert ts[0] == -5.0
        assert ts[-1] == 0.0
        np.testing.assert_array_almost_equal(samples, ts * 10)

    def test_zero_sample_rate(self, temp_dir):
        """Constant signal (all same timestamp) is a degenerate case."""
        f = os.path.join(temp_dir, "r3d.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Const", ChannelAttributes())
        t = np.zeros(10)
        s = np.arange(10)
        w.append(dg, cg, ch, t, s)
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == 10

    def test_very_high_sample_count(self, temp_dir):
        """5M samples must fit under 300 MB."""
        f = os.path.join(temp_dir, "r3e.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Huge", ChannelAttributes())
        n = 5_000_000
        t = np.linspace(0, 1, n)
        s = np.sin(t)
        w.append(dg, cg, ch, t, s)
        w.save()
        w.stop()
        del t, s
        gc.collect()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(ts) == n
        mb = current_memory_mb()
        assert mb < 300


# ------------------------------------------------------------------
# Round 3-B: Cross-mode compatibility
# ------------------------------------------------------------------

class TestR3_CrossMode:
    """Ensure files written in one mode behave predictably in another."""

    def test_normal_file_read_as_streaming(self, temp_dir):
        """NORMAL-written file opened with STREAMING config must work."""
        f = os.path.join(temp_dir, "cross.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(100.0), np.arange(100))
        w.save()
        w.stop()

        r = MDFReader(f, MDFConfig(OperationMode.STREAMING, MDFVersion.V4_10))
        r.start()
        _, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 100

    def test_v3_and_v4_side_by_side(self, temp_dir):
        """Both MDF 3.x and 4.x must coexist in the same directory."""
        f3 = os.path.join(temp_dir, "v3.mdf")
        f4 = os.path.join(temp_dir, "v4.mf4")
        for f, ver in [(f3, MDFVersion.V3_30), (f4, MDFVersion.V4_10)]:
            w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, ver))
            w.start()
            dg = w.create_data_group(DataGroupAttributes())
            cg = w.create_channel_group(dg, ChannelGroupAttributes())
            ch = w.create_channel(dg, cg, "Speed", ChannelAttributes(unit="m/s"))
            w.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([0.0, 10.0]))
            w.save()
            w.stop()

        for f, ver in [(f3, MDFVersion.V3_30), (f4, MDFVersion.V4_10)]:
            r = MDFReader(f, MDFConfig(OperationMode.NORMAL, ver))
            r.start()
            groups = r.list_data_groups()
            assert len(groups) >= 1
            r.stop()


# ------------------------------------------------------------------
# Round 3-C: Concurrency safety
# ------------------------------------------------------------------

class TestR3_Concurrency:
    """Thread-safe correctness under mixed read/write workloads."""

    def test_concurrent_appends_then_read(self, temp_dir):
        """4 threads append to shared channel; final read must match sum."""
        f = os.path.join(temp_dir, "r3f.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "Counter", ChannelAttributes())

        errors = []

        def worker(offset):
            try:
                t = np.arange(offset, offset + 25)
                s = np.arange(offset, offset + 25) * 2
                w.append(dg, cg, ch, t, s)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(i * 25,)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        ts, samples = r.get(dg, cg, ch)
        r.stop()
        # Only the last winning append survives (overwrite semantics)
        assert len(samples) == 25
        # Values must be exactly the last thread's data
        last_t = np.arange(75, 100)
        np.testing.assert_array_equal(ts, last_t)
        np.testing.assert_array_equal(samples, last_t * 2)

    def test_concurrent_reader_no_crash(self, temp_dir):
        """2 threads reading same file must not crash or corrupt."""
        f = os.path.join(temp_dir, "r3g.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(1000.0), np.arange(1000))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        results = {"t0": [], "t1": [], "errors": []}

        def reader_a():
            try:
                for _ in range(50):
                    ts, s = r.get(dg, cg, ch)
                    results["t0"].append(len(ts))
            except Exception as exc:
                results["errors"].append(exc)

        def reader_b():
            try:
                for _ in range(50):
                    ts, s = r.get_range(dg, cg, ch, 100.0, 500.0)
                    results["t1"].append(len(ts))
            except Exception as exc:
                results["errors"].append(exc)

        t0 = threading.Thread(target=reader_a)
        t1 = threading.Thread(target=reader_b)
        t0.start()
        t1.start()
        t0.join()
        t1.join()
        r.stop()

        assert not results["errors"]
        assert all(c == 1000 for c in results["t0"])
        assert all(300 <= c <= 400 for c in results["t1"])
