# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Round 4 Self-Inspection Tests.

Focus: Concurrent safety, memory stability, and resource cleanup.
Detects: deadlocks, memory leaks, file-handle leaks, stale metadata.

Memory budget: < 300 MB per test process.
"""

import gc
import os
import shutil
import sys
import tempfile
import threading
import time
import tracemalloc
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
)


def current_memory_mb():
    tracemalloc.start()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / (1024 * 1024)


@pytest.fixture
def temp_dir():
    p = tempfile.mkdtemp(prefix="selfcheck_r4_")
    yield p
    shutil.rmtree(p, ignore_errors=True)


# ------------------------------------------------------------------
# Round 4-A: File handle release verification
# ------------------------------------------------------------------

class TestR4_HandleRelease:
    """Ensure files can be moved/deleted after stop()."""

    def test_normal_file_movable_after_stop(self, temp_dir):
        f = os.path.join(temp_dir, "r4a.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(100.0), np.arange(100))
        w.save()
        w.stop()

        new_path = os.path.join(temp_dir, "moved.mf4")
        os.rename(f, new_path)
        assert os.path.exists(new_path)

    def test_fragmented_dir_deletable_after_stop(self, temp_dir):
        frag_dir = os.path.join(temp_dir, "frag_r4")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(200.0), np.arange(200))
        w.save()
        w.stop()

        shutil.rmtree(frag_dir)
        assert not os.path.exists(frag_dir)

    def test_reader_releases_handle(self, temp_dir):
        f = os.path.join(temp_dir, "r4c.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(100.0), np.arange(100))
        w.save()
        w.stop()

        r = MDFReader(f)
        r.start()
        r.get(dg, cg, ch)
        r.stop()

        os.unlink(f)
        assert not os.path.exists(f)


# ------------------------------------------------------------------
# Round 4-B: Stop/start cycles do not leak memory
# ------------------------------------------------------------------

class TestR4_MemoryStability:
    """Repeated stop/start must not leak buffers or file handles."""

    def test_repeated_stop_start_normal(self, temp_dir):
        """NORMAL mode: each save() overwrites the file; only last group remains."""
        f = os.path.join(temp_dir, "r4d.mf4")
        cfg = MDFConfig(OperationMode.NORMAL, version=MDFVersion.V4_10)
        w = MDFWriter(f, cfg)
        for cycle in range(5):
            w.start()
            dg = w.create_data_group(DataGroupAttributes())
            cg = w.create_channel_group(dg, ChannelGroupAttributes())
            ch = w.create_channel(dg, cg, "X", ChannelAttributes())
            w.append(dg, cg, ch, np.array([cycle]), np.array([cycle]))
            w.save()
            w.stop()

        r = MDFReader(f)
        r.start()
        # NORMAL save() overwrites the entire file, so only the last group exists.
        groups = r.list_data_groups()
        assert len(groups) == 1
        _, samples = r.get(groups[0], 0, 0)
        assert samples[0] == 4
        r.stop()

    def test_repeated_stop_start_fragmented(self, temp_dir):
        """FRAGMENTED mode: each save() creates a new fragment with its own group."""
        frag_dir = os.path.join(temp_dir, "frag_r4b")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        for cycle in range(5):
            w.start()
            dg = w.create_data_group(DataGroupAttributes())
            cg = w.create_channel_group(dg, ChannelGroupAttributes())
            ch = w.create_channel(dg, cg, "X", ChannelAttributes())
            t = np.linspace(0, 9, 100)
            s = np.full(100, cycle)
            w.append(dg, cg, ch, t, s)
            w.save()
            w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        groups = r.list_data_groups()
        # Each iteration creates a new group in a new fragment.
        assert len(groups) == 5
        total = 0
        for cycle, dg in enumerate(groups):
            _, samples = r.get(dg, 0, 0)
            assert len(samples) == 100
            assert samples[0] == cycle
            total += len(samples)
        r.stop()
        assert total == 500


# ------------------------------------------------------------------
# Round 4-C: Metadata sidecar survives crashes
# ------------------------------------------------------------------

class TestR4_MetadataResilience:
    """Unexpected stop() mid-session must leave recoverable metadata."""

    def test_partial_write_recoverable(self, temp_dir):
        """Writer stopped without explicit save() must still persist via stop()."""
        f = os.path.join(temp_dir, "r4e.mf4")
        w = MDFWriter(f, MDFConfig(OperationMode.NORMAL, MDFVersion.V4_10))
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        w.append(dg, cg, ch, np.arange(50.0), np.arange(50))
        # Intentionally no save(); stop() should auto-flush
        w.stop()

        r = MDFReader(f)
        r.start()
        _, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 50

    def test_fragmented_partial_recoverable(self, temp_dir):
        frag_dir = os.path.join(temp_dir, "frag_r4f")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        w = MDFWriter(frag_dir, cfg)
        w.start()
        dg = w.create_data_group(DataGroupAttributes())
        cg = w.create_channel_group(dg, ChannelGroupAttributes())
        ch = w.create_channel(dg, cg, "X", ChannelAttributes())
        t = np.linspace(0, 9, 100)
        s = np.arange(100)
        w.append(dg, cg, ch, t, s)
        # No save(); stop() auto-flushes
        w.stop()

        r = MDFReader(frag_dir, cfg)
        r.start()
        _, samples = r.get(dg, cg, ch)
        r.stop()
        assert len(samples) == 100
