#!/usr/bin/env python3
"""
Project Test Script
Tests the MDF4 Java-Python hybrid project components.
"""

import os
import sys
import subprocess
import time
import socket
import json
import struct

# Constants
JAVA_CLIENT_DIR = os.path.join(os.path.dirname(__file__), "java-client")
PYTHON_SERVICE_DIR = os.path.join(os.path.dirname(__file__), "python-service")
DEFAULT_PORT = 25333


def print_header(text):
    """Print a formatted header"""
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60)


def print_result(test_name, success, message=""):
    """Print test result"""
    status = "✓ PASS" if success else "✗ FAIL"
    print(f"  [{status}] {test_name}")
    if message:
        print(f"         {message}")
    return success


def check_python():
    """Check Python installation"""
    print_header("Checking Python Environment")
    
    try:
        result = subprocess.run([sys.executable, "--version"], 
                              capture_output=True, text=True)
        version = result.stdout.strip() or result.stderr.strip()
        print(f"  Python: {version}")
        
        # Check version
        version_str = version.replace("Python ", "").strip()
        major, minor = map(int, version_str.split(".")[:2])
        if major < 3 or (major == 3 and minor < 8):
            return print_result("Python Version", False, "Need Python 3.8+")
        
        return print_result("Python Version", True)
    except Exception as e:
        return print_result("Python Check", False, str(e))


def check_python_packages():
    """Check Python packages"""
    print_header("Checking Python Packages")
    
    packages = ["asammdf", "numpy"]
    all_ok = True
    
    for pkg in packages:
        try:
            __import__(pkg)
            print_result(f"Package: {pkg}", True)
        except ImportError:
            print_result(f"Package: {pkg}", False, f"Run: pip install {pkg}")
            all_ok = False
    
    return all_ok


def check_java():
    """Check Java installation"""
    print_header("Checking Java Environment")
    
    try:
        result = subprocess.run(["java", "-version"], 
                              capture_output=True, text=True)
        
        # Java outputs version to stderr
        output = result.stderr or result.stdout
        
        for line in output.split("\n"):
            if "version" in line.lower():
                print(f"  Java: {line.strip()}")
                
                # Check for Java 21+
                if "21." in line or "21-" in line:
                    return print_result("Java Version", True)
                else:
                    return print_result("Java Version", False, "Need Java 21+")
        
        return print_result("Java Check", False, "Could not determine version")
    except FileNotFoundError:
        return print_result("Java Check", False, "Java not found in PATH")
    except Exception as e:
        return print_result("Java Check", False, str(e))


def check_maven():
    """Check Maven installation"""
    print_header("Checking Maven")
    
    try:
        result = subprocess.run(["mvn", "-version"], 
                              capture_output=True, text=True)
        
        first_line = result.stdout.split("\n")[0]
        print(f"  {first_line}")
        return print_result("Maven", True)
    except FileNotFoundError:
        return print_result("Maven", False, "Maven not found in PATH")
    except Exception as e:
        return print_result("Maven Check", False, str(e))


def test_port_detection():
    """Test port detection"""
    print_header("Testing Port Detection")
    
    # Test if default port is available
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(("localhost", DEFAULT_PORT))
        sock.close()
        return print_result("Default Port Available", True, f"Port {DEFAULT_PORT} is free")
    except OSError:
        return print_result("Default Port Available", False, f"Port {DEFAULT_PORT} is in use")


def test_python_server_script():
    """Test Python server script"""
    print_header("Testing Python Server Script")
    
    script_path = os.path.join(PYTHON_SERVICE_DIR, "socket_server.py")
    
    if not os.path.exists(script_path):
        return print_result("Script Exists", False, f"Not found: {script_path}")
    
    print_result("Script Exists", True)
    
    # Test syntax
    try:
        result = subprocess.run([sys.executable, "-m", "py_compile", script_path],
                              capture_output=True, text=True)
        if result.returncode == 0:
            return print_result("Script Syntax", True)
        else:
            return print_result("Script Syntax", False, result.stderr)
    except Exception as e:
        return print_result("Script Syntax", False, str(e))


def test_java_compilation():
    """Test Java compilation"""
    print_header("Testing Java Compilation")
    
    if not os.path.exists(JAVA_CLIENT_DIR):
        return print_result("Java Client Dir", False, f"Not found: {JAVA_CLIENT_DIR}")
    
    pom_path = os.path.join(JAVA_CLIENT_DIR, "pom.xml")
    if not os.path.exists(pom_path):
        return print_result("pom.xml", False, f"Not found: {pom_path}")
    
    print_result("Java Client Structure", True)
    
    # Try to compile
    print("\n  Compiling Java project (this may take a while)...")
    try:
        result = subprocess.run(["mvn", "clean", "compile", "-q"],
                              cwd=JAVA_CLIENT_DIR,
                              capture_output=True, text=True)
        if result.returncode == 0:
            return print_result("Java Compilation", True)
        else:
            return print_result("Java Compilation", False, result.stderr[:200])
    except Exception as e:
        return print_result("Java Compilation", False, str(e))


def test_server_start_stop():
    """Test server start and stop"""
    print_header("Testing Python Server Start/Stop")
    
    script_path = os.path.join(PYTHON_SERVICE_DIR, "socket_server.py")
    
    # Start server
    print("  Starting server...")
    try:
        proc = subprocess.Popen(
            [sys.executable, script_path, "foreground", "--port", str(DEFAULT_PORT)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for server to start
        time.sleep(3)
        
        # Check if server is running
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect(("localhost", DEFAULT_PORT))
            
            # Send handshake
            handshake = {"cmd": "HANDSHAKE", "params": {}, "reqId": "0"}
            json_bytes = json.dumps(handshake).encode('utf-8')
            sock.sendall(struct.pack('>I', len(json_bytes)))
            sock.sendall(json_bytes)
            
            # Read response
            length_bytes = sock.recv(4)
            msg_len = struct.unpack('>I', length_bytes)[0]
            response_bytes = sock.recv(msg_len)
            response = json.loads(response_bytes.decode('utf-8'))
            
            if response.get('success'):
                print_result("Server Handshake", True)
                
                # Send shutdown
                shutdown = {"cmd": "SHUTDOWN", "params": {}, "reqId": "999"}
                json_bytes = json.dumps(shutdown).encode('utf-8')
                sock.sendall(struct.pack('>I', len(json_bytes)))
                sock.sendall(json_bytes)
                
                sock.close()
                
                # Wait for server to stop
                time.sleep(1)
                
                # Check if server stopped
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    sock.connect(("localhost", DEFAULT_PORT))
                    sock.close()
                    return print_result("Server Stop", False, "Server still running")
                except:
                    return print_result("Server Stop", True)
            else:
                sock.close()
                proc.terminate()
                return print_result("Server Handshake", False, "Handshake failed")
                
        except Exception as e:
            proc.terminate()
            return print_result("Server Connection", False, str(e))
            
    except Exception as e:
        return print_result("Server Start", False, str(e))


def main():
    """Main test function"""
    print("\n" + "=" * 60)
    print("  MDF4 Hybrid Project - Test Suite")
    print("=" * 60)
    
    results = []
    
    # Environment checks
    results.append(("Python", check_python()))
    results.append(("Python Packages", check_python_packages()))
    results.append(("Java", check_java()))
    results.append(("Maven", check_maven()))
    
    # Component checks
    results.append(("Port Detection", test_port_detection()))
    results.append(("Python Server Script", test_python_server_script()))
    
    # Compilation check (skip if Maven not available)
    if any(r[0] == "Maven" and r[1] for r in results):
        results.append(("Java Compilation", test_java_compilation()))
    else:
        print_header("Java Compilation")
        print_result("Java Compilation", False, "Maven not available, skipping")
        results.append(("Java Compilation", False))
    
    # Server test (skip if packages not available)
    if all(r[1] for r in results if r[0] in ["Python", "Python Packages"]):
        results.append(("Server Start/Stop", test_server_start_stop()))
    else:
        print_header("Server Start/Stop")
        print_result("Server Test", False, "Dependencies not met, skipping")
        results.append(("Server Start/Stop", False))
    
    # Summary
    print_header("Test Summary")
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✓" if result else "✗"
        print(f"  [{status}] {name}")
    
    print(f"\n  Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n  🎉 All tests passed!")
        return 0
    else:
        print("\n  ⚠️  Some tests failed. Please check the errors above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
