# MDF4 Java-Python Hybrid Project

Java与Python混合的MDF4文件读写项目，支持GB级数据量、自动服务管理、JSON元数据存储。

## 功能特性

- **MDF4文件操作**: 创建、读取、部分读取MDF4文件
- **Socket通信**: 自定义长度前缀JSON协议，支持1MB分块传输
- **服务自动管理**: Java端控制Python服务启动/停止/监控
- **端口自动探测**: Java端检测端口占用，自动寻找可用端口
- **环境检测**: 自动检测Python/Java环境，提供安装指引
- **空闲超时**: Python服务3分钟无活动自动关闭
- **握手超时**: 30秒无握手自动关闭服务
- **元数据存储**: 文件和通道元数据以JSON字符串格式存储在comment中
- **GB级数据支持**: 分块传输支持大数据量

## 项目结构

```
mdf4-hybrid-project/
├── java-client/           # Java客户端
│   ├── pom.xml           # Maven配置 (Java 21)
│   └── src/main/java/com/mdf4/
│       ├── Mdf4Client.java           # 主客户端类
│       ├── PythonServiceManager.java # Python服务管理
│       ├── SocketClient.java         # Socket通信客户端
│       ├── FileMetadata.java         # 文件元数据
│       ├── ChannelMetadata.java      # 通道元数据
│       ├── DataRecord.java           # 数据记录
│       └── Main.java                 # 示例程序
│
└── python-service/        # Python服务端
    ├── socket_server.py   # Socket服务器
    ├── mdf4_handler.py    # MDF4处理核心
    └── requirements.txt   # Python依赖
```

## 环境要求

### Java
- Java 21 或更高版本
- Maven 3.6+

### Python
- Python 3.8 或更高版本
- 依赖包: asammdf, numpy

## 快速开始

### 1. 安装Python依赖

```bash
cd python-service
pip install -r requirements.txt
```

### 2. 编译Java项目

```bash
cd java-client
mvn clean package
```

### 3. 运行示例程序

```bash
java -jar target/mdf4-java-client-1.0.0.jar
```

## 使用示例

### 基本用法

```java
import com.mdf4.*;

// 创建客户端（自动管理Python服务）
try (Mdf4Client client = new Mdf4Client()) {
    // 连接服务
    client.connect();
    
    // 创建新文件
    client.createNewFile("data.mf4");
    
    // 写入数据
    List<Double> timestamps = Arrays.asList(0.0, 0.1, 0.2, 0.3);
    List<Double> values = Arrays.asList(10.0, 20.0, 30.0, 40.0);
    client.addChannel("Temperature", timestamps, values, "C", "Temperature sensor", "float");
    
    // 保存文件
    client.saveFile();
    
    // 读取数据
    DataRecord record = client.readChannel("Temperature");
    System.out.println("Samples: " + record.getSampleCount());
}
// 客户端关闭时自动停止Python服务
```

### 部分读取

```java
// 按索引范围读取
DataRecord partial = client.readChannelPartial("Temperature", 0, 100);

// 按时间范围读取
List<DataRecord> records = client.readChannelsPartial(
    Arrays.asList("Temperature", "Pressure"), 
    0.0, 10.0  // 读取0-10秒的数据
);
```

### 元数据操作

```java
// 设置文件元数据
FileMetadata fileMeta = FileMetadata.builder()
    .title("Test Data")
    .author("Engineer")
    .description("Vehicle test data")
    .project("Project X")
    .version("1.0")
    .customProperty("location", "Test Track A")
    .build();
client.setFileMetadata(fileMeta);

// 设置通道元数据
ChannelMetadata channelMeta = ChannelMetadata.builder()
    .source("Sensor A1")
    .sensorType("Thermocouple")
    .samplingRate(100.0)
    .minValue(0.0)
    .maxValue(100.0)
    .build();
client.addChannel("Temperature", timestamps, values, "C", "", "float", channelMeta);
```

## 高级功能

### 端口配置

```java
// 使用指定端口
Mdf4Client client = new Mdf4Client("localhost", 25333);

// 如果端口被占用，会自动寻找25333-25433范围内的可用端口
```

### 服务管理

```java
PythonServiceManager manager = new PythonServiceManager();

// 启动服务
manager.startService();

// 检查服务状态
boolean running = manager.isServiceRunning();

// 重启服务
manager.restartService();

// 停止服务
manager.stopServiceSync();
```

### 环境检测

```java
PythonServiceManager manager = new PythonServiceManager();
EnvironmentManager env = manager.getEnvironmentManager();

// 检查Python
boolean pythonOk = env.isPythonInstalled();

// 检查Java 21
boolean javaOk = env.isJava21Installed();

// 检查Python包
boolean packagesOk = env.checkPythonPackages();

// 自动安装Python包
env.installPythonPackages();

// 确保所有环境就绪
boolean allOk = env.ensureAllEnvironments();
```

## 协议说明

### Socket通信协议

- **消息格式**: 4字节长度前缀 + JSON消息体
- **分块传输**: 大于1MB的消息自动分块
- **握手**: 连接后必须发送HANDSHAKE命令
- **心跳**: 支持PING命令检测连接状态

### 命令列表

- `HANDSHAKE` - 握手
- `PING` - 心跳检测
- `SHUTDOWN` - 关闭服务
- `createNewFile` - 创建新文件
- `openFile` - 打开文件
- `closeFile` - 关闭文件
- `saveFile` - 保存文件
- `addChannel` - 添加通道
- `readChannel` - 读取通道
- `readChannelPartial` - 部分读取
- `getChannelNames` - 获取通道列表
- `getChannelInfo` - 获取通道信息
- `setFileMetadata` - 设置文件元数据
- `getFileMetadata` - 获取文件元数据

## 故障排除

### Python服务无法启动

1. 检查Python是否安装: `python3 --version`
2. 检查依赖包: `pip list | grep asammdf`
3. 查看日志: `python-service/mdf4_server.log`

### 端口被占用

Java端会自动探测可用端口（25333-25433范围），无需手动配置。

### 连接超时

1. 检查防火墙设置
2. 确认Python服务已启动: `python socket_server.py status`
3. 重启服务: `python socket_server.py stop && python socket_server.py start`

### Java版本问题

需要Java 21或更高版本:
```bash
java -version  # 应显示21.x
```

## 许可证

MIT License
