package com.mdf4;

import java.util.HashMap;
import java.util.Map;

/**
 * ChannelMetadata - Represents metadata for a channel in an MDF4 file.
 */
public class ChannelMetadata {
    
    private String source;
    private String sensorType;
    private String calibrationDate;
    private double samplingRate;
    private double minValue;
    private double maxValue;
    private Map<String, String> customProperties;
    
    /**
     * Default constructor
     */
    public ChannelMetadata() {
        this.source = "";
        this.sensorType = "";
        this.calibrationDate = "";
        this.samplingRate = 0.0;
        this.minValue = 0.0;
        this.maxValue = 0.0;
        this.customProperties = new HashMap<>();
    }
    
    /**
     * Constructor with essential fields
     */
    public ChannelMetadata(String source, String sensorType, double samplingRate) {
        this();
        this.source = source;
        this.sensorType = sensorType;
        this.samplingRate = samplingRate;
    }
    
    // ==================== Getters and Setters ====================
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
    public String getSensorType() {
        return sensorType;
    }
    
    public void setSensorType(String sensorType) {
        this.sensorType = sensorType;
    }
    
    public String getCalibrationDate() {
        return calibrationDate;
    }
    
    public void setCalibrationDate(String calibrationDate) {
        this.calibrationDate = calibrationDate;
    }
    
    public double getSamplingRate() {
        return samplingRate;
    }
    
    public void setSamplingRate(double samplingRate) {
        this.samplingRate = samplingRate;
    }
    
    public double getMinValue() {
        return minValue;
    }
    
    public void setMinValue(double minValue) {
        this.minValue = minValue;
    }
    
    public double getMaxValue() {
        return maxValue;
    }
    
    public void setMaxValue(double maxValue) {
        this.maxValue = maxValue;
    }
    
    public Map<String, String> getCustomProperties() {
        return customProperties;
    }
    
    public void setCustomProperties(Map<String, String> customProperties) {
        this.customProperties = customProperties != null ? customProperties : new HashMap<>();
    }
    
    /**
     * Add a custom property
     */
    public void addCustomProperty(String key, String value) {
        if (this.customProperties == null) {
            this.customProperties = new HashMap<>();
        }
        this.customProperties.put(key, value);
    }
    
    /**
     * Get a custom property
     */
    public String getCustomProperty(String key) {
        return this.customProperties != null ? this.customProperties.get(key) : null;
    }
    
    // ==================== Builder Pattern ====================
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private ChannelMetadata metadata = new ChannelMetadata();
        
        public Builder source(String source) {
            metadata.setSource(source);
            return this;
        }
        
        public Builder sensorType(String sensorType) {
            metadata.setSensorType(sensorType);
            return this;
        }
        
        public Builder calibrationDate(String calibrationDate) {
            metadata.setCalibrationDate(calibrationDate);
            return this;
        }
        
        public Builder samplingRate(double samplingRate) {
            metadata.setSamplingRate(samplingRate);
            return this;
        }
        
        public Builder minValue(double minValue) {
            metadata.setMinValue(minValue);
            return this;
        }
        
        public Builder maxValue(double maxValue) {
            metadata.setMaxValue(maxValue);
            return this;
        }
        
        public Builder customProperty(String key, String value) {
            metadata.addCustomProperty(key, value);
            return this;
        }
        
        public ChannelMetadata build() {
            return metadata;
        }
    }
    
    @Override
    public String toString() {
        return String.format("ChannelMetadata{source='%s', sensorType='%s', samplingRate=%.2f}",
                source, sensorType, samplingRate);
    }
}
