package com.mdf4;

import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;
import java.net.URL;
import java.net.HttpURLConnection;

/**
 * PythonServiceManager - Manages the Python MDF4 service lifecycle.
 * Handles starting, stopping, and monitoring the Python service.
 * Features:
 * - Automatic port detection (finds available port if default is in use)
 * - Environment auto-download (Python, Java)
 * - Graceful shutdown
 */
public class PythonServiceManager {
    
    private static final String DEFAULT_HOST = "localhost";
    private static final int DEFAULT_PORT = 25333;
    private static final int CONNECT_TIMEOUT_MS = 2000;
    private static final int MAX_STARTUP_WAIT_MS = 30000;
    private static final int STARTUP_CHECK_INTERVAL_MS = 500;
    private static final int PORT_RANGE_START = 25333;
    private static final int PORT_RANGE_END = 25433;
    
    private final String host;
    private int port;
    private final String pythonExecutable;
    private final String serverScriptPath;
    private final String portFilePath;
    private Process serviceProcess;
    private boolean autoRestartEnabled;
    private EnvironmentManager envManager;
    
    /**
     * Constructor with default settings
     */
    public PythonServiceManager() {
        this(DEFAULT_HOST, DEFAULT_PORT, findPythonExecutable(), findServerScript());
    }
    
    /**
     * Constructor with custom settings
     */
    public PythonServiceManager(String host, int port, String pythonExecutable, String serverScriptPath) {
        this.host = host;
        this.port = port;
        this.pythonExecutable = pythonExecutable;
        this.serverScriptPath = serverScriptPath;
        this.portFilePath = new File(serverScriptPath).getParent() + File.separator + "mdf4_server.port";
        this.autoRestartEnabled = true;
        this.envManager = new EnvironmentManager();
    }
    
    /**
     * Find an available port in the specified range
     * 
     * @param preferredPort The preferred port to try first
     * @param startRange Start of port range
     * @param endRange End of port range
     * @return Available port number, or -1 if none found
     */
    public static int findAvailablePort(int preferredPort, int startRange, int endRange) {
        // First try the preferred port
        if (isPortAvailable(preferredPort)) {
            return preferredPort;
        }
        
        // Then search in the range
        for (int p = startRange; p <= endRange; p++) {
            if (p != preferredPort && isPortAvailable(p)) {
                System.out.println("Port " + preferredPort + " is in use, using alternative port: " + p);
                return p;
            }
        }
        
        return -1;
    }
    
    /**
     * Check if a port is available
     */
    public static boolean isPortAvailable(int port) {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            serverSocket.setReuseAddress(true);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * Find Python executable with auto-download support
     */
    public static String findPythonExecutable() {
        String[] candidates = {"python3", "python", "py"};
        for (String candidate : candidates) {
            try {
                ProcessBuilder pb = new ProcessBuilder(candidate, "--version");
                pb.inheritIO().redirectOutput(ProcessBuilder.Redirect.DISCARD);
                Process p = pb.start();
                if (p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0) {
                    return candidate;
                }
            } catch (Exception e) {
                // Try next candidate
            }
        }
        return "python3"; // Default fallback
    }
    
    /**
     * Find server script path
     */
    public static String findServerScript() {
        // Try to find relative to current directory
        Path[] candidates = {
            Paths.get("python-service", "socket_server.py"),
            Paths.get("..", "python-service", "socket_server.py"),
            Paths.get("..", "..", "python-service", "socket_server.py"),
        };
        
        for (Path candidate : candidates) {
            if (Files.exists(candidate)) {
                return candidate.toAbsolutePath().toString();
            }
        }
        
        return "python-service/socket_server.py"; // Default fallback
    }
    
    /**
     * Read actual port from port file
     */
    public int readActualPortFromFile() {
        try {
            File portFile = new File(portFilePath);
            if (portFile.exists()) {
                String content = new String(Files.readAllBytes(portFile.toPath())).trim();
                return Integer.parseInt(content);
            }
        } catch (Exception e) {
            logger.warning("Failed to read port file: " + e.getMessage());
        }
        return port;
    }
    
    /**
     * Update port from file
     */
    public void updatePortFromFile() {
        this.port = readActualPortFromFile();
    }
    
    // ==================== Environment Management ====================
    
    /**
     * EnvironmentManager - Handles environment detection and auto-download
     */
    public class EnvironmentManager {
        
        private static final String PYTHON_DOWNLOAD_URL_WINDOWS = "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe";
        private static final String PYTHON_DOWNLOAD_URL_MAC = "https://www.python.org/ftp/python/3.11.8/python-3.11.8-macos11.pkg";
        private static final String JAVA_DOWNLOAD_URL = "https://download.java.net/java/GA/jdk21.0.2/f2283984656d49d69e91c558476027ac/13/GPL/openjdk-21.0.2_windows-x64_bin.zip";
        
        /**
         * Check if Python is installed
         */
        public boolean isPythonInstalled() {
            try {
                ProcessBuilder pb = new ProcessBuilder("python3", "--version");
                pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
                pb.redirectError(ProcessBuilder.Redirect.DISCARD);
                Process p = pb.start();
                return p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0;
            } catch (Exception e) {
                try {
                    ProcessBuilder pb = new ProcessBuilder("python", "--version");
                    pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
                    pb.redirectError(ProcessBuilder.Redirect.DISCARD);
                    Process p = pb.start();
                    return p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0;
                } catch (Exception e2) {
                    return false;
                }
            }
        }
        
        /**
         * Check if Java is installed and is version 21+
         */
        public boolean isJava21Installed() {
            try {
                ProcessBuilder pb = new ProcessBuilder("java", "-version");
                Process p = pb.start();
                
                // Read version output
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains("version")) {
                        // Check for Java 21
                        if (line.contains("21.") || line.contains("21-")) {
                            return true;
                        }
                        // Also check for newer versions
                        for (int v = 21; v <= 99; v++) {
                            if (line.contains(" " + v + ".") || line.contains(" " + v + "-")) {
                                return true;
                            }
                        }
                    }
                }
                return false;
            } catch (Exception e) {
                return false;
            }
        }
        
        /**
         * Check and install Python if needed
         * 
         * @return true if Python is available (installed or already present)
         */
        public boolean ensurePython() {
            if (isPythonInstalled()) {
                System.out.println("Python is already installed");
                return true;
            }
            
            System.err.println("========================================");
            System.err.println("ERROR: Python is not installed!");
            System.err.println("========================================");
            System.err.println();
            System.err.println("Please install Python 3.8 or higher:");
            System.err.println();
            System.err.println("Windows:");
            System.err.println("  1. Download from: https://www.python.org/downloads/");
            System.err.println("  2. Run the installer and check 'Add Python to PATH'");
            System.err.println();
            System.err.println("macOS:");
            System.err.println("  brew install python3");
            System.err.println();
            System.err.println("Linux (Ubuntu/Debian):");
            System.err.println("  sudo apt-get update");
            System.err.println("  sudo apt-get install python3 python3-pip");
            System.err.println();
            System.err.println("Linux (CentOS/RHEL):");
            System.err.println("  sudo yum install python3 python3-pip");
            System.err.println();
            System.err.println("After installation, please restart this application.");
            System.err.println("========================================");
            
            return false;
        }
        
        /**
         * Check and install Java 21 if needed
         * 
         * @return true if Java 21+ is available
         */
        public boolean ensureJava21() {
            if (isJava21Installed()) {
                System.out.println("Java 21+ is already installed");
                return true;
            }
            
            System.err.println("========================================");
            System.err.println("ERROR: Java 21 is not installed!");
            System.err.println("========================================");
            System.err.println();
            System.err.println("Please install Java 21 or higher:");
            System.err.println();
            System.err.println("Windows:");
            System.err.println("  1. Download from: https://adoptium.net/temurin/releases/?version=21");
            System.err.println("  2. Run the installer");
            System.err.println();
            System.err.println("macOS:");
            System.err.println("  brew install --cask temurin21");
            System.err.println();
            System.err.println("Linux:");
            System.err.println("  See: https://adoptium.net/installation/");
            System.err.println();
            System.err.println("After installation, please restart this application.");
            System.err.println("========================================");
            
            return false;
        }
        
        /**
         * Check if required Python packages are installed
         */
        public boolean checkPythonPackages() {
            try {
                ProcessBuilder pb = new ProcessBuilder(pythonExecutable, "-c", "import asammdf; import numpy");
                pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
                pb.redirectError(ProcessBuilder.Redirect.DISCARD);
                Process p = pb.start();
                return p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0;
            } catch (Exception e) {
                return false;
            }
        }
        
        /**
         * Install required Python packages
         */
        public boolean installPythonPackages() {
            System.out.println("Installing required Python packages (asammdf, numpy)...");
            try {
                ProcessBuilder pb = new ProcessBuilder(pythonExecutable, "-m", "pip", "install", "asammdf", "numpy");
                pb.inheritIO();
                Process p = pb.start();
                if (p.waitFor(60, TimeUnit.SECONDS) && p.exitValue() == 0) {
                    System.out.println("Python packages installed successfully");
                    return true;
                }
            } catch (Exception e) {
                System.err.println("Failed to install Python packages: " + e.getMessage());
            }
            return false;
        }
        
        /**
         * Ensure all environments are ready
         */
        public boolean ensureAllEnvironments() {
            boolean javaOk = ensureJava21();
            boolean pythonOk = ensurePython();
            
            if (!javaOk || !pythonOk) {
                return false;
            }
            
            // Check Python packages
            if (!checkPythonPackages()) {
                System.out.println("Required Python packages not found");
                return installPythonPackages();
            }
            
            return true;
        }
    }
    
    // ==================== Service Control ====================
    
    /**
     * Start the Python service
     * 
     * @param waitForReady Whether to wait for service to be ready
     * @return true if service started successfully
     */
    public synchronized boolean startService(boolean waitForReady) {
        if (isServiceRunning()) {
            System.out.println("Python service is already running");
            updatePortFromFile();
            return true;
        }
        
        // Check environments first
        System.out.println("Checking environments...");
        if (!envManager.ensureAllEnvironments()) {
            System.err.println("Environment check failed. Please install required environments.");
            return false;
        }
        
        // Find available port
        int availablePort = findAvailablePort(port, PORT_RANGE_START, PORT_RANGE_END);
        if (availablePort == -1) {
            System.err.println("Could not find an available port in range " + PORT_RANGE_START + "-" + PORT_RANGE_END);
            return false;
        }
        this.port = availablePort;
        
        try {
            System.out.println("Starting Python service...");
            System.out.println("  Python: " + pythonExecutable);
            System.out.println("  Script: " + serverScriptPath);
            System.out.println("  Port: " + port);
            
            // Check if script exists
            if (!Files.exists(Paths.get(serverScriptPath))) {
                System.err.println("Server script not found: " + serverScriptPath);
                return false;
            }
            
            // Build command - pass port to Python server
            ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                serverScriptPath,
                "foreground",
                "--host", host,
                "--port", String.valueOf(port)
            );
            
            // Redirect output to log file
            Path logDir = Paths.get(serverScriptPath).getParent();
            Path logFile = logDir.resolve("mdf4_server.log");
            pb.redirectOutput(logFile.toFile());
            pb.redirectError(ProcessBuilder.Redirect.INHERIT);
            
            // Start process
            serviceProcess = pb.start();
            
            // Add shutdown hook to stop service
            Runtime.getRuntime().addShutdownHook(new Thread(this::stopServiceSync));
            
            System.out.println("Python service process started (PID: " + serviceProcess.pid() + ")");
            
            // Wait for service to be ready
            if (waitForReady) {
                boolean ready = waitForServiceReady();
                if (ready) {
                    System.out.println("Server is listening on port: " + port);
                }
                return ready;
            }
            
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to start Python service: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Start the Python service and wait for it to be ready
     */
    public boolean startService() {
        return startService(true);
    }
    
    /**
     * Stop the Python service (asynchronous)
     * 
     * @return true if service stopped successfully
     */
    public synchronized boolean stopService() {
        return stopServiceInternal(false);
    }
    
    /**
     * Stop the Python service (synchronous - waits for process to exit)
     * 
     * @return true if service stopped successfully
     */
    public synchronized boolean stopServiceSync() {
        return stopServiceInternal(true);
    }
    
    /**
     * Internal stop service method
     */
    private boolean stopServiceInternal(boolean sync) {
        System.out.println("Stopping Python service...");
        boolean stopped = false;
        
        // First try graceful shutdown via socket
        try {
            int actualPort = readActualPortFromFile();
            if (actualPort > 0) {
                Socket socket = new Socket();
                socket.connect(new java.net.InetSocketAddress(host, actualPort), 3000);
                
                // Send shutdown command
                java.io.DataOutputStream out = new java.io.DataOutputStream(socket.getOutputStream());
                String shutdownJson = "{\"cmd\":\"SHUTDOWN\",\"params\":{},\"reqId\":\"999\"}";
                byte[] jsonBytes = shutdownJson.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                out.writeInt(jsonBytes.length);
                out.write(jsonBytes);
                out.flush();
                socket.close();
                
                System.out.println("Sent graceful shutdown command to server");
                stopped = true;
                
                // Wait a bit for graceful shutdown
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            System.out.println("Graceful shutdown failed: " + e.getMessage());
        }
        
        // Kill process if still running
        if (serviceProcess != null && serviceProcess.isAlive()) {
            System.out.println("Terminating Python service process...");
            serviceProcess.destroy();
            
            if (sync) {
                try {
                    if (!serviceProcess.waitFor(5, TimeUnit.SECONDS)) {
                        System.out.println("Force killing Python service...");
                        serviceProcess.destroyForcibly();
                        serviceProcess.waitFor(2, TimeUnit.SECONDS);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            stopped = true;
        }
        
        // Also try to stop via Python command
        try {
            ProcessBuilder pb = new ProcessBuilder(
                pythonExecutable,
                serverScriptPath,
                "stop"
            );
            pb.inheritIO();
            Process p = pb.start();
            if (p.waitFor(5, TimeUnit.SECONDS)) {
                stopped = true;
            }
        } catch (Exception e) {
            // Ignore
        }
        
        serviceProcess = null;
        
        if (stopped) {
            System.out.println("Python service stopped");
        }
        return stopped;
    }
    
    /**
     * Restart the Python service
     */
    public boolean restartService() {
        System.out.println("Restarting Python service...");
        stopServiceSync();
        try {
            Thread.sleep(1000); // Wait for port to be released
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return startService();
    }
    
    /**
     * Check if the service is running
     */
    public boolean isServiceRunning() {
        // First try to connect
        try {
            int actualPort = readActualPortFromFile();
            if (actualPort <= 0) {
                actualPort = port;
            }
            Socket socket = new Socket();
            socket.connect(new java.net.InetSocketAddress(host, actualPort), CONNECT_TIMEOUT_MS);
            socket.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Wait for service to be ready
     */
    private boolean waitForServiceReady() {
        System.out.println("Waiting for service to be ready...");
        
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < MAX_STARTUP_WAIT_MS) {
            if (isServiceRunning()) {
                System.out.println("Python service is ready");
                return true;
            }
            
            // Check if process died
            if (serviceProcess != null && !serviceProcess.isAlive()) {
                System.err.println("Python service process exited unexpectedly");
                return false;
            }
            
            try {
                Thread.sleep(STARTUP_CHECK_INTERVAL_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        
        System.err.println("Timeout waiting for Python service to start");
        return false;
    }
    
    // ==================== Auto-Restart ====================
    
    /**
     * Enable or disable auto-restart
     */
    public void setAutoRestartEnabled(boolean enabled) {
        this.autoRestartEnabled = enabled;
    }
    
    /**
     * Check if auto-restart is enabled
     */
    public boolean isAutoRestartEnabled() {
        return autoRestartEnabled;
    }
    
    /**
     * Ensure service is running (start if not running)
     * 
     * @return true if service is running or was successfully started
     */
    public boolean ensureServiceRunning() {
        if (isServiceRunning()) {
            return true;
        }
        
        if (autoRestartEnabled) {
            System.out.println("Service not running, attempting to restart...");
            return restartService();
        }
        
        return false;
    }
    
    // ==================== Getters ====================
    
    public String getHost() {
        return host;
    }
    
    public int getPort() {
        updatePortFromFile();
        return port;
    }
    
    public String getPythonExecutable() {
        return pythonExecutable;
    }
    
    public String getServerScriptPath() {
        return serverScriptPath;
    }
    
    public EnvironmentManager getEnvironmentManager() {
        return envManager;
    }
    
    // Simple logger
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PythonServiceManager.class.getName());
}
