"""
MF4文件处理模块 - 处理MF4文件的具体操作
支持多线程、大文件分段读取、extend追加数据
"""
import os
import threading
import uuid
import gc
from typing import Dict, List, Optional, Any, Iterator, Tuple
from dataclasses import dataclass
from enum import Enum
import numpy as np

from asammdf import MDF, Signal

import logging

logger = logging.getLogger('mf4_server')


class WriteMode(Enum):
    """写入模式枚举"""
    APPEND = "append"          # 使用extend追加数据
    OVERWRITE = "overwrite"    # 覆盖现有通道
    CREATE_NEW = "create_new"  # 创建新通道（如果存在则报错）


@dataclass
class FileHandle:
    """文件句柄封装类"""
    file_id: str
    file_path: str
    mdf: MDF
    mode: str
    ref_count: int = 0
    lock: threading.RLock = None
    
    def __post_init__(self):
        if self.lock is None:
            self.lock = threading.RLock()


class DataChunker:
    """数据分块器 - 将大数据分割成小块，控制内存使用"""
    
    DEFAULT_SAMPLES_PER_CHUNK = 50000  # 每块5万样本
    DEFAULT_BYTES_PER_CHUNK = 5 * 1024 * 1024  # 每块5MB
    
    def __init__(self, samples_per_chunk: int = None, bytes_per_chunk: int = None):
        self.samples_per_chunk = samples_per_chunk or self.DEFAULT_SAMPLES_PER_CHUNK
        self.bytes_per_chunk = bytes_per_chunk or self.DEFAULT_BYTES_PER_CHUNK
    
    def estimate_chunk_size(self, sample_count: int, dtype_size: int = 8) -> int:
        """估算合适的分块大小"""
        samples_limit = self.samples_per_chunk
        bytes_per_sample = dtype_size * 2
        memory_limit = self.bytes_per_chunk // bytes_per_sample
        return min(samples_limit, memory_limit, sample_count)
    
    def create_iterator(self, handle: FileHandle, group_index: int, channel_index: int,
                        start: float = None, end: float = None,
                        samples: int = None) -> Iterator[Dict[str, Any]]:
        """创建数据迭代器 - 惰性加载数据"""
        try:
            signal = handle.mdf.get(
                group=group_index,
                index=channel_index,
                samples_only=False
            )
            
            timestamps = signal.timestamps
            values = signal.samples
            
            if start is not None or end is not None:
                mask = np.ones(len(timestamps), dtype=bool)
                if start is not None:
                    mask &= timestamps >= start
                if end is not None:
                    mask &= timestamps <= end
                timestamps = timestamps[mask]
                values = values[mask]
                del mask
            
            if samples is not None and len(timestamps) > samples:
                timestamps = timestamps[:samples]
                values = values[:samples]
            
            total_samples = len(timestamps)
            chunk_size = self.estimate_chunk_size(total_samples)
            
            name = signal.name
            unit = signal.unit if hasattr(signal, 'unit') else ''
            total_chunks = (total_samples + chunk_size - 1) // chunk_size
            
            for i in range(0, total_samples, chunk_size):
                end_idx = min(i + chunk_size, total_samples)
                
                chunk = {
                    'timestamps': timestamps[i:end_idx].tolist(),
                    'values': values[i:end_idx].tolist() if not isinstance(values[i:end_idx], np.ndarray) 
                             else values[i:end_idx].tolist(),
                    'name': name,
                    'unit': unit,
                    'sampleCount': end_idx - i,
                    'chunkIndex': i // chunk_size,
                    'totalChunks': total_chunks,
                    'startOffset': i
                }
                
                yield chunk
                
                if i // chunk_size % 10 == 0:
                    gc.collect()
                    
        except Exception as e:
            logger.error(f"Error creating iterator: {e}")
            raise


class Mf4FileManager:
    """MF4文件管理器 - 内存限制300MB"""
    
    DEFAULT_MAX_SAMPLES_PER_READ = 500000  # 单次最大读取50万样本
    DEFAULT_MAX_BYTES_PER_READ = 50 * 1024 * 1024  # 单次最大50MB
    MEMORY_LIMIT_MB = 300  # 内存限制300MB
    
    def __init__(self, max_memory_mb: int = 300):
        self._files: Dict[str, FileHandle] = {}
        self._path_to_ids: Dict[str, set] = {}
        self._global_lock = threading.RLock()
        self._chunker = DataChunker()
        self._iterators: Dict[str, Iterator] = {}
        self._iterator_lock = threading.RLock()
        self._max_memory_mb = max_memory_mb
    
    def _check_memory(self, operation: str = "") -> bool:
        """检查内存使用情况，超过阈值时触发GC"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            rss_mb = memory_info.rss / 1024 / 1024
            
            if rss_mb > self._max_memory_mb * 0.9:  # 超过90%触发GC
                logger.warning(f"Memory high ({rss_mb:.1f}MB) before {operation}, triggering GC")
                gc.collect()
                
                # 再次检查
                memory_info = process.memory_info()
                rss_mb = memory_info.rss / 1024 / 1024
                
                if rss_mb > self._max_memory_mb:
                    logger.error(f"Memory limit exceeded: {rss_mb:.1f}MB > {self._max_memory_mb}MB")
                    return False
            
            return True
        except ImportError:
            return True
    
    def open_file(self, file_path: str, mode: str = 'r', create_if_not_exists: bool = False) -> str:
        """打开MF4文件"""
        with self._global_lock:
            file_exists = os.path.exists(file_path)
            
            if not file_exists and mode == 'r' and not create_if_not_exists:
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if file_path in self._path_to_ids:
                for file_id in self._path_to_ids[file_path]:
                    handle = self._files.get(file_id)
                    if handle and handle.mode == mode:
                        with handle.lock:
                            handle.ref_count += 1
                        logger.info(f"Reused file handle: {file_id}, ref_count: {handle.ref_count}")
                        return file_id
            
            file_id = str(uuid.uuid4())
            
            try:
                if mode == 'w' or (mode == 'rw' and not file_exists and create_if_not_exists):
                    mdf = MDF(version='4.11')
                else:
                    mdf = MDF(file_path)
                
                handle = FileHandle(
                    file_id=file_id,
                    file_path=file_path,
                    mdf=mdf,
                    mode=mode
                )
                handle.ref_count = 1
                
                self._files[file_id] = handle
                
                if file_path not in self._path_to_ids:
                    self._path_to_ids[file_path] = set()
                self._path_to_ids[file_path].add(file_id)
                
                logger.info(f"Opened file: {file_path}, mode: {mode}, file_id: {file_id}")
                return file_id
                
            except Exception as e:
                logger.error(f"Failed to open file {file_path}: {e}")
                raise
    
    def close_file(self, file_id: str) -> bool:
        """关闭文件"""
        with self._global_lock:
            handle = self._files.get(file_id)
            if not handle:
                logger.warning(f"File not found for closing: {file_id}")
                return False
            
            with handle.lock:
                handle.ref_count -= 1
                
                if handle.ref_count <= 0:
                    try:
                        handle.mdf.close()
                        logger.info(f"Closed file: {handle.file_path}, file_id: {file_id}")
                    except Exception as e:
                        logger.error(f"Error closing file {file_id}: {e}")
                    finally:
                        del self._files[file_id]
                        self._path_to_ids[handle.file_path].discard(file_id)
                        if not self._path_to_ids[handle.file_path]:
                            del self._path_to_ids[handle.file_path]
                        
                        with self._iterator_lock:
                            iterator_keys = [k for k in self._iterators.keys() if k.startswith(file_id)]
                            for key in iterator_keys:
                                del self._iterators[key]
                        
                        gc.collect()
                else:
                    logger.info(f"Decreased ref_count for {file_id}: {handle.ref_count}")
            
            return True
    
    def get_file_info(self, file_id: str) -> Dict[str, Any]:
        """获取文件信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            info = {
                'filePath': handle.file_path,
                'mode': handle.mode,
                'version': handle.mdf.version_str if hasattr(handle.mdf, 'version_str') else 'unknown',
                'channelCount': len(handle.mdf.channels_db) if hasattr(handle.mdf, 'channels_db') else 0,
            }
            
            groups = []
            if hasattr(handle.mdf, 'groups'):
                for i, group in enumerate(handle.mdf.groups):
                    group_info = {
                        'index': i,
                        'channelCount': len(group.channels) if hasattr(group, 'channels') else 0
                    }
                    groups.append(group_info)
            
            info['groups'] = groups
            return info
    
    def get_channels(self, file_id: str, group_index: int = None) -> List[Dict[str, Any]]:
        """获取通道列表"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            channels = []
            
            if hasattr(handle.mdf, 'groups'):
                groups_to_process = [handle.mdf.groups[group_index]] if group_index is not None else handle.mdf.groups
                
                for g_idx, group in enumerate(groups_to_process):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            ch_info = {
                                'name': channel.name if hasattr(channel, 'name') else f'Channel_{c_idx}',
                                'groupIndex': g_idx if group_index is None else group_index,
                                'channelIndex': c_idx,
                            }
                            
                            if hasattr(channel, 'unit'):
                                ch_info['unit'] = channel.unit
                            if hasattr(channel, 'comment'):
                                ch_info['comment'] = str(channel.comment) if channel.comment else ''
                            
                            channels.append(ch_info)
            
            return channels
    
    def get_channel_info(self, file_id: str, group_index: int, channel_index: int) -> Dict[str, Any]:
        """获取指定通道的详细信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            if not hasattr(handle.mdf, 'groups'):
                raise ValueError("File has no channel groups")
            
            if group_index >= len(handle.mdf.groups):
                raise ValueError(f"Group index {group_index} out of range")
            
            group = handle.mdf.groups[group_index]
            
            if not hasattr(group, 'channels'):
                raise ValueError("Group has no channels")
            
            if channel_index >= len(group.channels):
                raise ValueError(f"Channel index {channel_index} out of range")
            
            channel = group.channels[channel_index]
            
            info = {
                'name': channel.name if hasattr(channel, 'name') else f'Channel_{channel_index}',
                'groupIndex': group_index,
                'channelIndex': channel_index,
            }
            
            if hasattr(channel, 'unit'):
                info['unit'] = channel.unit
            if hasattr(channel, 'comment'):
                info['comment'] = str(channel.comment) if channel.comment else ''
            if hasattr(channel, 'dtype'):
                info['dataType'] = str(channel.dtype)
            if hasattr(channel, 'conversion') and channel.conversion is not None:
                info['conversion'] = str(channel.conversion)
            
            try:
                signal = handle.mdf.get(group=group_index, index=channel_index, samples_only=False)
                if signal is not None:
                    if hasattr(signal, 'timestamps') and len(signal.timestamps) > 0:
                        info['startTime'] = float(signal.timestamps[0])
                        info['endTime'] = float(signal.timestamps[-1])
                        info['sampleCount'] = len(signal.timestamps)
            except Exception as e:
                logger.warning(f"Could not get signal info: {e}")
            
            return info
    
    def find_channel(self, file_id: str, channel_name: str) -> List[Dict[str, Any]]:
        """根据名称查找通道"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            results = []
            
            if hasattr(handle.mdf, 'groups'):
                for g_idx, group in enumerate(handle.mdf.groups):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            name = channel.name if hasattr(channel, 'name') else ''
                            
                            if channel_name.lower() in name.lower():
                                ch_info = {
                                    'name': name,
                                    'groupIndex': g_idx,
                                    'channelIndex': c_idx,
                                }
                                
                                if hasattr(channel, 'unit'):
                                    ch_info['unit'] = channel.unit
                                if hasattr(channel, 'comment'):
                                    ch_info['comment'] = str(channel.comment) if channel.comment else ''
                                
                                results.append(ch_info)
            
            return results
    
    def _find_channel_in_group(self, handle: FileHandle, group_index: int, channel_name: str) -> Tuple[bool, int]:
        """在指定组中查找通道"""
        if not hasattr(handle.mdf, 'groups'):
            return False, -1
        
        if group_index >= len(handle.mdf.groups):
            return False, -1
        
        group = handle.mdf.groups[group_index]
        if not hasattr(group, 'channels'):
            return False, -1
        
        for idx, channel in enumerate(group.channels):
            name = channel.name if hasattr(channel, 'name') else ''
            if name == channel_name:
                return True, idx
        
        return False, -1
    
    def read_data(self, file_id: str, group_index: int, channel_index: int = None,
                  start: float = None, end: float = None, 
                  samples: int = None, use_iterator: bool = False) -> Dict[str, Any]:
        """读取数据 - 带内存保护"""
        if not self._check_memory("read_data"):
            raise MemoryError("Memory limit exceeded (300MB), cannot read data")
        
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if samples is None or samples > self.DEFAULT_MAX_SAMPLES_PER_READ:
            samples = self.DEFAULT_MAX_SAMPLES_PER_READ
        
        with handle.lock:
            try:
                if use_iterator:
                    iterator_id = f"{file_id}_{group_index}_{channel_index}_{uuid.uuid4().hex[:8]}"
                    iterator = self._chunker.create_iterator(
                        handle, group_index, channel_index, start, end, samples
                    )
                    
                    with self._iterator_lock:
                        self._iterators[iterator_id] = iterator
                    
                    try:
                        first_chunk = next(iterator)
                        first_chunk['iteratorId'] = iterator_id
                        first_chunk['hasMore'] = True
                        return first_chunk
                    except StopIteration:
                        return {
                            'iteratorId': iterator_id,
                            'hasMore': False,
                            'sampleCount': 0
                        }
                
                if channel_index is not None:
                    signal = handle.mdf.get(
                        group=group_index,
                        index=channel_index,
                        samples_only=False
                    )
                    
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                        del mask
                    
                    if samples is not None and len(timestamps) > samples:
                        timestamps = timestamps[:samples]
                        values = values[:samples]
                    
                    total_samples = len(timestamps)
                    estimated_bytes = total_samples * 16
                    
                    if estimated_bytes > self.DEFAULT_MAX_BYTES_PER_READ:
                        chunk_samples = self.DEFAULT_MAX_BYTES_PER_READ // 16
                        total_chunks = (total_samples + chunk_samples - 1) // chunk_samples
                        
                        end_idx = min(chunk_samples, total_samples)
                        first_chunk = {
                            'timestamps': timestamps[:end_idx].tolist(),
                            'values': values[:end_idx].tolist() if not isinstance(values, np.ndarray) 
                                     else values[:end_idx].tolist(),
                            'name': signal.name,
                            'unit': signal.unit if hasattr(signal, 'unit') else '',
                            'sampleCount': end_idx,
                            'chunkIndex': 0,
                            'totalChunks': total_chunks,
                            'hasMore': total_chunks > 1,
                            'startOffset': 0,
                            'totalSamples': total_samples
                        }
                        
                        del timestamps
                        del values
                        gc.collect()
                        
                        return first_chunk
                    
                    result = {
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps),
                        'hasMore': False
                    }
                    
                    del timestamps
                    del values
                    gc.collect()
                    
                    return result
                else:
                    group_data = []
                    total_samples = 0
                    
                    if group_index < len(handle.mdf.groups):
                        group = handle.mdf.groups[group_index]
                        if hasattr(group, 'channels'):
                            max_channels = 10
                            channels_to_read = min(len(group.channels), max_channels)
                            
                            for idx in range(channels_to_read):
                                signal = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                
                                timestamps = signal.timestamps
                                values = signal.samples
                                
                                if start is not None or end is not None:
                                    mask = np.ones(len(timestamps), dtype=bool)
                                    if start is not None:
                                        mask &= timestamps >= start
                                    if end is not None:
                                        mask &= timestamps <= end
                                    timestamps = timestamps[mask]
                                    values = values[mask]
                                    del mask
                                
                                if samples is not None and len(timestamps) > samples:
                                    timestamps = timestamps[:samples]
                                    values = values[:samples]
                                
                                channel_samples = len(timestamps)
                                total_samples += channel_samples
                                
                                group_data.append({
                                    'timestamps': timestamps.tolist(),
                                    'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                                    'name': signal.name,
                                    'unit': signal.unit if hasattr(signal, 'unit') else '',
                                    'sampleCount': channel_samples
                                })
                                
                                if idx % 5 == 0:
                                    gc.collect()
                    
                    result = {
                        'groupIndex': group_index,
                        'channels': group_data,
                        'channelCount': len(group_data),
                        'totalSamples': total_samples,
                        'hasMore': False
                    }
                    
                    gc.collect()
                    return result
                    
            except Exception as e:
                logger.error(f"Error reading data from file {file_id}: {e}")
                raise
    
    def read_next_chunk(self, iterator_id: str) -> Optional[Dict[str, Any]]:
        """读取迭代器的下一个数据块"""
        with self._iterator_lock:
            iterator = self._iterators.get(iterator_id)
            if iterator is None:
                raise ValueError(f"Iterator not found: {iterator_id}")
            
            try:
                chunk = next(iterator)
                chunk['iteratorId'] = iterator_id
                chunk['hasMore'] = True
                return chunk
            except StopIteration:
                del self._iterators[iterator_id]
                gc.collect()
                return {
                    'iteratorId': iterator_id,
                    'hasMore': False,
                    'sampleCount': 0
                }
    
    def close_iterator(self, iterator_id: str):
        """关闭迭代器"""
        with self._iterator_lock:
            if iterator_id in self._iterators:
                del self._iterators[iterator_id]
                gc.collect()
    
    def write_data(self, file_id: str, group_index: int, channel_data: List[Dict[str, Any]],
                   batch_size: int = 5000, write_mode: str = "append") -> Dict[str, Any]:
        """
        写入数据 - 支持extend追加相同group_index和名称的signal，带内存保护
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_data: 通道数据列表
            batch_size: 每批写入的最大样本数（默认5000，降低内存使用）
            write_mode: 写入模式 - "append"(extend追加), "overwrite"(覆盖), "create_new"(新建)
        
        Returns:
            写入结果字典
        """
        if not self._check_memory("write_data"):
            raise MemoryError("Memory limit exceeded (300MB), cannot write data")
        
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if handle.mode == 'r':
            raise PermissionError("File opened in read-only mode")
        
        mode = WriteMode(write_mode) if write_mode else WriteMode.APPEND
        
        result = {
            'success': False,
            'channelsWritten': 0,
            'channelsAppended': 0,
            'channelsOverwritten': 0,
            'channelsCreated': 0,
            'details': []
        }
        
        with handle.lock:
            try:
                for ch in channel_data:
                    channel_name = ch['name']
                    exists, existing_idx = self._find_channel_in_group(handle, group_index, channel_name)
                    
                    channel_result = {
                        'name': channel_name,
                        'action': 'unknown'
                    }
                    
                    if exists:
                        if mode == WriteMode.CREATE_NEW:
                            raise ValueError(f"Channel '{channel_name}' already exists in group {group_index}")
                        
                        elif mode == WriteMode.OVERWRITE:
                            logger.info(f"Overwriting channel '{channel_name}' in group {group_index}")
                            
                            # 读取原有其他通道的数据
                            existing_signals = []
                            group = handle.mdf.groups[group_index]
                            for idx in range(len(group.channels)):
                                if idx != existing_idx:
                                    try:
                                        sig = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                        existing_signals.append(sig)
                                    except Exception as e:
                                        logger.warning(f"Could not read existing channel {idx}: {e}")
                            
                            # 创建新信号
                            new_signal = Signal(
                                samples=np.array(ch['values']),
                                timestamps=np.array(ch['timestamps']),
                                name=channel_name,
                                unit=ch.get('unit', ''),
                                comment=ch.get('comment', '')
                            )
                            existing_signals.append(new_signal)
                            
                            # 保存并重新打开
                            temp_path = handle.file_path + ".tmp"
                            handle.mdf.save(temp_path, overwrite=True)
                            handle.mdf.close()
                            
                            new_mdf = MDF(version='4.11')
                            new_mdf.append(existing_signals, comment=f"Overwritten channel {channel_name}")
                            new_mdf.save(handle.file_path, overwrite=True)
                            new_mdf.close()
                            
                            handle.mdf = MDF(handle.file_path)
                            
                            result['channelsOverwritten'] += 1
                            channel_result['action'] = 'overwritten'
                        
                        else:  # APPEND - 使用extend方式追加
                            logger.info(f"Appending to channel '{channel_name}' in group {group_index} using extend")
                            
                            # 读取现有数据
                            existing_signal = handle.mdf.get(group=group_index, index=existing_idx, samples_only=False)
                            existing_timestamps = existing_signal.timestamps
                            existing_values = existing_signal.samples
                            
                            # 新数据
                            new_timestamps = np.array(ch['timestamps'])
                            new_values = np.array(ch['values'])
                            
                            # 使用extend方式合并（按时间戳排序）
                            combined_timestamps = np.concatenate([existing_timestamps, new_timestamps])
                            combined_values = np.concatenate([existing_values, new_values])
                            
                            # 按时间戳排序
                            sort_indices = np.argsort(combined_timestamps)
                            combined_timestamps = combined_timestamps[sort_indices]
                            combined_values = combined_values[sort_indices]
                            
                            # 创建合并后的信号
                            combined_signal = Signal(
                                samples=combined_values,
                                timestamps=combined_timestamps,
                                name=channel_name,
                                unit=ch.get('unit', existing_signal.unit if hasattr(existing_signal, 'unit') else ''),
                                comment=ch.get('comment', '')
                            )
                            
                            # 读取组内其他通道
                            existing_signals = []
                            group = handle.mdf.groups[group_index]
                            for idx in range(len(group.channels)):
                                if idx != existing_idx:
                                    try:
                                        sig = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                        existing_signals.append(sig)
                                    except Exception as e:
                                        logger.warning(f"Could not read existing channel {idx}: {e}")
                            
                            existing_signals.append(combined_signal)
                            
                            # 保存并重新打开
                            temp_path = handle.file_path + ".tmp"
                            handle.mdf.save(temp_path, overwrite=True)
                            handle.mdf.close()
                            
                            new_mdf = MDF(version='4.11')
                            new_mdf.append(existing_signals, comment=f"Extended channel {channel_name}")
                            new_mdf.save(handle.file_path, overwrite=True)
                            new_mdf.close()
                            
                            handle.mdf = MDF(handle.file_path)
                            
                            result['channelsAppended'] += 1
                            channel_result['action'] = 'appended'
                            channel_result['oldSamples'] = len(existing_timestamps)
                            channel_result['newSamples'] = len(combined_timestamps)
                    
                    else:
                        # 通道不存在，创建新通道
                        timestamps = np.array(ch['timestamps'])
                        values = np.array(ch['values'])
                        
                        if len(timestamps) > batch_size:
                            logger.info(f"Large write ({len(timestamps)} samples), processing in batches")
                            
                            for i in range(0, len(timestamps), batch_size):
                                end_idx = min(i + batch_size, len(timestamps))
                                
                                batch_signal = Signal(
                                    samples=values[i:end_idx],
                                    timestamps=timestamps[i:end_idx],
                                    name=channel_name,
                                    unit=ch.get('unit', ''),
                                    comment=ch.get('comment', '')
                                )
                                
                                handle.mdf.append([batch_signal], comment=f"Batch {i//batch_size}")
                                
                                del batch_signal
                                if i // batch_size % 10 == 0:
                                    gc.collect()
                        else:
                            signal = Signal(
                                samples=values,
                                timestamps=timestamps,
                                name=channel_name,
                                unit=ch.get('unit', ''),
                                comment=ch.get('comment', '')
                            )
                            handle.mdf.append([signal], comment=ch.get('comment', 'Written by mf4_server'))
                            del signal
                        
                        result['channelsCreated'] += 1
                        channel_result['action'] = 'created'
                    
                    result['details'].append(channel_result)
                    result['channelsWritten'] += 1
                
                result['success'] = True
                gc.collect()
                
                logger.info(f"Written {result['channelsWritten']} channels: "
                          f"{result['channelsCreated']} created, "
                          f"{result['channelsAppended']} appended, "
                          f"{result['channelsOverwritten']} overwritten")
                
                return result
                
            except Exception as e:
                logger.error(f"Error writing data to file {file_id}: {e}")
                result['error'] = str(e)
                raise
    
    def save_file(self, file_id: str, file_path: str = None, overwrite: bool = False) -> str:
        """保存文件"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        target_path = file_path or handle.file_path
        
        if os.path.exists(target_path) and not overwrite:
            raise FileExistsError(f"File already exists: {target_path}")
        
        with handle.lock:
            try:
                handle.mdf.save(target_path, overwrite=overwrite)
                logger.info(f"Saved file: {target_path}")
                
                if target_path != handle.file_path:
                    old_path = handle.file_path
                    self._path_to_ids[old_path].discard(file_id)
                    if not self._path_to_ids[old_path]:
                        del self._path_to_ids[old_path]
                    
                    handle.file_path = target_path
                    if target_path not in self._path_to_ids:
                        self._path_to_ids[target_path] = set()
                    self._path_to_ids[target_path].add(file_id)
                
                gc.collect()
                
                return target_path
                
            except Exception as e:
                logger.error(f"Error saving file {file_id}: {e}")
                raise
    
    def close_all(self):
        """关闭所有文件"""
        with self._global_lock:
            file_ids = list(self._files.keys())
            for file_id in file_ids:
                try:
                    handle = self._files.get(file_id)
                    if handle:
                        handle.mdf.close()
                        logger.info(f"Closed file during shutdown: {handle.file_path}")
                except Exception as e:
                    logger.error(f"Error closing file {file_id}: {e}")
            
            self._files.clear()
            self._path_to_ids.clear()
            self._iterators.clear()
            
            gc.collect()
            logger.info("All files closed and memory cleaned up")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取内存使用统计"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            return {
                'rss': memory_info.rss,
                'rssMB': memory_info.rss / 1024 / 1024,
                'vms': memory_info.vms,
                'vmsMB': memory_info.vms / 1024 / 1024,
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
        except ImportError:
            return {
                'error': 'psutil not available',
                'openFiles': len(self._files),
                'activeIterators': len(self._iterators)
            }
    
    def _get_handle(self, file_id: str) -> Optional[FileHandle]:
        """获取文件句柄"""
        return self._files.get(file_id)
