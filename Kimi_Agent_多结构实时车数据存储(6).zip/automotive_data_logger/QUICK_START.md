# 快速开始指南 (多格式版本)

## 环境准备

### 1. 安装Java (JDK 11+)

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install openjdk-11-jdk maven
```

**Windows:**
- 下载 [Oracle JDK](https://www.oracle.com/java/technologies/downloads/) 或 [OpenJDK](https://adoptium.net/)
- 下载 [Maven](https://maven.apache.org/download.cgi)

**验证:**
```bash
java -version
mvn -version
```

### 2. 安装Python (3.8+)

**Ubuntu/Debian:**
```bash
sudo apt install python3 python3-pip
```

**Windows:**
- 下载 [Python](https://www.python.org/downloads/)

**验证:**
```bash
python3 --version
```

### 3. 安装Python依赖

```bash
cd python

# 核心依赖（必需）
pip3 install asammdf numpy

# 可选依赖（Parquet格式支持）
pip3 install pyarrow
```

## 编译项目

```bash
cd java
mvn clean package
cd ..
```

编译成功后，生成 `java/target/automotive-data-logger-1.0.0.jar`

## 启动系统

### Linux/Mac

```bash
chmod +x start_service.sh
./start_service.sh
```

### Windows

```cmd
start_service.bat
```

## 使用界面

### 基本操作

1. **开始记录**: 点击绿色 **"开始记录"** 按钮
2. **切换格式**: 从下拉框选择格式，点击 **"切换格式"**
3. **停止记录**: 点击红色 **"停止记录"** 按钮

### 界面说明

```
┌─────────────────────────────────────────────────────────────┐
│  汽车数据实时记录系统 - 多格式支持                            │
├─────────────────────────────────────────────────────────────┤
│  系统状态                                                    │
│  记录状态: [就绪/正在记录.../已停止]                         │
│  记录时长: 00:01:23    数据条数: 12345                       │
│  发送速率: 100.0 条/秒  队列大小: 0                          │
│  存储格式: mdf4        文件大小: 2.5 MB                      │
├─────────────────────────────────────────────────────────────┤
│  发动机数据      │  车辆动态                                  │
│  发动机转速: ... │  车速: ...                                 │
│  发动机温度: ... │  横向加速度: ...                           │
│  油门位置: ...   │  ...                                       │
├─────────────────────────────────────────────────────────────┤
│  [开始记录] [停止记录]  存储格式: [mdf4 ▼] [切换格式]        │
└─────────────────────────────────────────────────────────────┘
```

## 命令行参数

### Python服务参数

```bash
python multi_format_writer_service.py [选项]

选项:
  --host HOST           监听地址 (默认: localhost)
  --port PORT           监听端口 (默认: 9999)
  --format FORMAT       默认存储格式 (默认: mdf4)
  --output OUTPUT       输出目录 (默认: output)
  --batch-size SIZE     批量写入大小 (默认: 100)

示例:
  # 使用CSV格式
  python multi_format_writer_service.py --format csv

  # 自定义端口和目录
  python multi_format_writer_service.py --port 8888 --output /data/logs
```

## 格式对比

| 格式 | 特点 | 适用场景 |
|------|------|----------|
| **mdf4** | ASAM标准，行业通用 | Vector CANape, MATLAB |
| **csv** | 通用格式，易读 | Excel, 数据分析 |
| **json** | 结构化，Web友好 | Web应用, API |
| **sqlite** | SQL查询，关系型 | 复杂查询, 分析 |
| **parquet** | 列式存储，高效 | 大数据, 机器学习 |

## 验证结果

### 查看存储信息

```bash
cd python

# 查看MDF4文件
python read_mdf4.py info ../output/vehicle_data_*.mf4

# 查看SQLite数据库
sqlite3 ../output/vehicle_data_*.db ".schema"
sqlite3 ../output/vehicle_data_*.db "SELECT COUNT(*) FROM vehicle_data"
```

### 导出数据

```bash
# MDF4转CSV
python read_mdf4.py export ../output/vehicle_data_*.mf4 -o output.csv

# SQLite转CSV
sqlite3 ../output/vehicle_data_*.db ".mode csv" ".output output.csv" "SELECT * FROM vehicle_data"
```

## 常见问题

### Q: 如何添加新的存储格式？

A: 参见 [扩展开发指南](docs/EXTENSION_GUIDE.md)

### Q: 格式切换时数据会丢失吗？

A: 不会。切换格式时会自动保存当前文件并创建新文件。

### Q: 支持同时写入多种格式吗？

A: 当前版本不支持，但可以通过扩展实现。

### Q: 如何处理大文件？

A: 配置文件分割：
```python
config.max_file_size_mb = 100  # 100MB自动分割
config.split_interval_minutes = 60  # 1小时自动分割
```

## 下一步

- 阅读 [README.md](README.md) 了解详细功能
- 阅读 [ARCHITECTURE.md](docs/ARCHITECTURE.md) 了解系统架构
- 阅读 [EXTENSION_GUIDE.md](docs/EXTENSION_GUIDE.md) 学习如何扩展
- 修改代码接入真实的CAN数据
