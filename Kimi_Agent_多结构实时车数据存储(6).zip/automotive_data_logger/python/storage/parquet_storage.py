#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Parquet存储格式实现
高效的列式存储格式，适合大数据分析和机器学习
"""

from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)

# 尝试导入pyarrow
try:
    import pyarrow as pa
    import pyarrow.parquet as pq
    PYARROW_AVAILABLE = True
except ImportError:
    PYARROW_AVAILABLE = False
    logger.debug("pyarrow库未安装，Parquet存储格式不可用")


class ParquetStorage(StorageInterface):
    """
    Parquet存储格式
    高效的列式存储，支持压缩和分片
    适合大数据分析和机器学习场景
    """
    
    FORMAT_NAME = "parquet"
    DEFAULT_EXTENSION = "parquet"
    SUPPORTS_APPEND = False  # Parquet追加需要特殊处理
    SUPPORTS_COMPRESSION = True
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        if not PYARROW_AVAILABLE:
            raise ImportError("pyarrow库未安装，无法使用Parquet存储格式")
        
        self._file_path: Optional[Path] = None
        self._schema: Optional[pa.Schema] = None
        
        # 数据累积
        self._data_batches: Dict[str, List] = {
            'timestamp': [],
            'can_channel': [],
            'can_id': [],
            'vehicle_speed': [],
            'engine_rpm': [],
            'engine_temp': [],
            'throttle_position': [],
            'brake_position': [],
            'steering_angle': [],
            'battery_voltage': [],
            'fuel_level': [],
            'odometer': [],
            'accel_x': [],
            'accel_y': [],
            'accel_z': []
        }
        
        # 压缩设置
        self._compression = self.config.compression or 'snappy'
        if self._compression not in ['none', 'snappy', 'gzip', 'brotli', 'lz4', 'zstd']:
            self._compression = 'snappy'
        
        # 初始化Schema
        self._init_schema()
    
    def _init_schema(self):
        """初始化Parquet Schema"""
        self._schema = pa.schema([
            ('timestamp', pa.int64()),
            ('can_channel', pa.int32()),
            ('can_id', pa.int32()),
            ('vehicle_speed', pa.float64()),
            ('engine_rpm', pa.float64()),
            ('engine_temp', pa.float64()),
            ('throttle_position', pa.float64()),
            ('brake_position', pa.float64()),
            ('steering_angle', pa.float64()),
            ('battery_voltage', pa.float64()),
            ('fuel_level', pa.float64()),
            ('odometer', pa.float64()),
            ('accel_x', pa.float64()),
            ('accel_y', pa.float64()),
            ('accel_z', pa.float64()),
        ])
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建Parquet文件"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            # 确保目录存在
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            self._file_path = file_path
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开Parquet文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            # 累积到缓冲区
            for key in self._data_batches.keys():
                value = data.get(key, 0)
                if key in ['timestamp', 'can_channel', 'can_id']:
                    self._data_batches[key].append(int(value))
                else:
                    self._data_batches[key].append(float(value))
            
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入Parquet数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            # 累积所有数据
            for data in data_list:
                for key in self._data_batches.keys():
                    value = data.get(key, 0)
                    if key in ['timestamp', 'can_channel', 'can_id']:
                        self._data_batches[key].append(int(value))
                    else:
                        self._data_batches[key].append(float(value))
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入Parquet失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭Parquet文件"""
        try:
            if self._file_path is None:
                return True
            
            # 刷新剩余数据
            if any(self._data_batches[key] for key in self._data_batches.keys()):
                self._write_to_parquet()
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭Parquet文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def _write_to_parquet(self):
        """将数据写入Parquet文件"""
        try:
            # 创建Arrow数组
            arrays = []
            for name in self._schema.names:
                values = self._data_batches[name]
                field = self._schema.field(name)
                arr = pa.array(values, type=field.type)
                arrays.append(arr)
            
            # 创建Table
            table = pa.Table.from_arrays(arrays, names=self._schema.names)
            
            # 写入Parquet文件
            pq.write_table(
                table,
                str(self._file_path),
                compression=self._compression if self._compression != 'none' else None,
                use_dictionary=True,
                write_statistics=True
            )
            
            logger.info(f"Parquet文件已保存: {self._file_path}")
            logger.debug(f"  行数: {len(table)}, 列数: {len(table.column_names)}")
            
            # 清空缓冲区
            for key in self._data_batches.keys():
                self._data_batches[key].clear()
            
        except Exception as e:
            logger.error(f"写入Parquet文件失败: {e}")
            raise
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._file_path and self._file_path.exists():
            return self._file_path.stat().st_size
        return 0
    
    def read_metadata(self) -> Optional[Dict[str, Any]]:
        """读取Parquet文件元数据"""
        try:
            if not self._file_path or not self._file_path.exists():
                return None
            
            parquet_file = pq.ParquetFile(str(self._file_path))
            metadata = parquet_file.metadata
            
            return {
                'num_rows': metadata.num_rows,
                'num_columns': metadata.num_columns,
                'row_groups': metadata.num_row_groups,
                'created_by': metadata.created_by,
                'serialized_size': metadata.serialized_size
            }
            
        except Exception as e:
            logger.error(f"读取Parquet元数据失败: {e}")
            return None
