package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * MDF4存储格式实现
 * 通过调用Python脚本将CSV转换为MDF4格式
 */
public class Mdf4Storage extends BaseStorage {
    
    // 临时CSV文件路径（用于Python转换）
    private Path tempCsvPath;
    private CsvStorage tempCsvStorage;
    
    // Python脚本路径
    private String pythonScriptPath = "python/mdf4_converter.py";
    private String pythonExecutable = "python3";
    
    public Mdf4Storage(StorageConfig config) {
        super(config);
        
        // 尝试检测Python可执行文件
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            pythonExecutable = "python";
        }
    }
    
    @Override
    public String getFormatName() {
        return "mdf4";
    }
    
    @Override
    public String getFileExtension() {
        return "mf4";
    }
    
    @Override
    public boolean supportsAppend() {
        return false; // MDF4追加较复杂，暂不实现
    }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        // MDF4文件路径
        currentFilePath = filePath != null ? filePath : config.getOutputPath(getFileExtension());
        currentFilePath.getParent().toFile().mkdirs();
        
        // 创建临时CSV文件
        String tempFileName = currentFilePath.getFileName().toString().replace(".mf4", "_temp.csv");
        tempCsvPath = currentFilePath.resolveSibling(tempFileName);
        
        // 使用CSV存储作为临时存储
        StorageConfig csvConfig = new StorageConfig(
            tempCsvPath.getParent(), 
            tempCsvPath.getFileName().toString().replace(".csv", "")
        );
        csvConfig.setBatchSize(config.getBatchSize());
        
        tempCsvStorage = new CsvStorage(csvConfig);
        tempCsvStorage.open(tempCsvPath);
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        tempCsvStorage.write(data);
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        tempCsvStorage.writeBatch(dataList);
    }
    
    @Override
    protected void doFlush() throws IOException {
        tempCsvStorage.flush();
    }
    
    @Override
    protected void doClose() throws IOException {
        if (tempCsvStorage == null) {
            return;
        }
        
        // 关闭临时CSV存储
        tempCsvStorage.close();
        
        // 调用Python脚本转换为MDF4
        convertToMdf4();
        
        // 删除临时CSV文件
        if (tempCsvPath.toFile().exists()) {
            tempCsvPath.toFile().delete();
        }
        
        tempCsvStorage = null;
    }
    
    /**
     * 调用Python脚本将CSV转换为MDF4
     */
    private void convertToMdf4() throws IOException {
        // 检查Python脚本是否存在
        Path scriptPath = Paths.get(pythonScriptPath);
        if (!scriptPath.toFile().exists()) {
            // 尝试使用类路径查找
            scriptPath = Paths.get("..", "python", "mdf4_converter.py");
        }
        
        if (!scriptPath.toFile().exists()) {
            throw new IOException("MDF4转换脚本未找到: " + pythonScriptPath);
        }
        
        // 构建命令
        ProcessBuilder pb = new ProcessBuilder(
            pythonExecutable,
            scriptPath.toAbsolutePath().toString(),
            tempCsvPath.toAbsolutePath().toString(),
            currentFilePath.toAbsolutePath().toString()
        );
        
        pb.redirectErrorStream(true);
        
        try {
            Process process = pb.start();
            
            // 读取输出
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[MDF4 Converter] " + line);
                }
            }
            
            // 等待完成
            boolean finished = process.waitFor(60, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                throw new IOException("MDF4转换超时");
            }
            
            int exitCode = process.exitValue();
            if (exitCode != 0) {
                throw new IOException("MDF4转换失败，退出码: " + exitCode);
            }
            
            System.out.println("MDF4文件已生成: " + currentFilePath);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("MDF4转换被中断", e);
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null && currentFilePath.toFile().exists()) {
            return currentFilePath.toFile().length();
        }
        return 0;
    }
    
    /**
     * 设置Python可执行文件路径
     */
    public void setPythonExecutable(String pythonExecutable) {
        this.pythonExecutable = pythonExecutable;
    }
    
    /**
     * 设置Python脚本路径
     */
    public void setPythonScriptPath(String pythonScriptPath) {
        this.pythonScriptPath = pythonScriptPath;
    }
}
