package com.automotive.logger.service;

import com.automotive.logger.model.VehicleData;
import com.automotive.logger.storage.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * 数据记录服务
 * 管理数据存储和格式切换
 */
public class DataLoggerService {
    
    private final StorageFactory factory;
    private StorageConfig config;
    private StorageInterface currentStorage;
    private String currentFormat;
    
    // 状态监听器
    private final List<Consumer<StorageInterface.StorageInfo>> statusListeners = new CopyOnWriteArrayList<>();
    
    public DataLoggerService() {
        this.factory = StorageFactory.getInstance();
        this.config = new StorageConfig();
    }
    
    /**
     * 设置配置
     */
    public void setConfig(StorageConfig config) {
        this.config = config;
    }
    
    /**
     * 获取配置
     */
    public StorageConfig getConfig() {
        return config;
    }
    
    /**
     * 获取可用格式列表
     */
    public List<String> getAvailableFormats() {
        return factory.getAvailableFormats();
    }
    
    /**
     * 获取格式信息
     */
    public StorageFactory.FormatInfo getFormatInfo(String format) {
        return factory.getFormatInfo(format);
    }
    
    /**
     * 开始记录
     */
    public boolean startRecording(String format) throws IOException {
        if (currentStorage != null && currentStorage.getInfo().isOpen()) {
            stopRecording();
        }
        
        currentFormat = format.toLowerCase();
        currentStorage = factory.create(currentFormat, config);
        
        boolean success = currentStorage.open(null);
        
        if (success) {
            notifyStatusChanged();
        }
        
        return success;
    }
    
    /**
     * 停止记录
     */
    public void stopRecording() throws IOException {
        if (currentStorage != null) {
            currentStorage.close();
            notifyStatusChanged();
            currentStorage = null;
        }
    }
    
    /**
     * 写入数据
     */
    public void write(VehicleData data) throws IOException {
        if (currentStorage != null) {
            currentStorage.write(data);
        }
    }
    
    /**
     * 切换存储格式
     */
    public boolean switchFormat(String newFormat) throws IOException {
        if (currentStorage == null || !currentStorage.getInfo().isOpen()) {
            return startRecording(newFormat);
        }
        
        // 保存当前文件路径
        String oldFile = currentStorage.getCurrentFilePath().toString();
        
        // 关闭当前存储
        currentStorage.close();
        
        // 创建新格式存储
        currentFormat = newFormat.toLowerCase();
        currentStorage = factory.create(currentFormat, config);
        boolean success = currentStorage.open(null);
        
        if (success) {
            System.out.println("格式已切换: " + oldFile + " -> " + currentStorage.getCurrentFilePath());
            notifyStatusChanged();
        }
        
        return success;
    }
    
    /**
     * 强制刷新
     */
    public void flush() throws IOException {
        if (currentStorage != null) {
            currentStorage.flush();
            notifyStatusChanged();
        }
    }
    
    /**
     * 获取存储信息
     */
    public StorageInterface.StorageInfo getStorageInfo() {
        if (currentStorage != null) {
            return currentStorage.getInfo();
        }
        return null;
    }
    
    /**
     * 获取当前格式
     */
    public String getCurrentFormat() {
        return currentFormat;
    }
    
    /**
     * 是否正在记录
     */
    public boolean isRecording() {
        return currentStorage != null && currentStorage.getInfo().isOpen();
    }
    
    /**
     * 添加状态监听器
     */
    public void addStatusListener(Consumer<StorageInterface.StorageInfo> listener) {
        statusListeners.add(listener);
    }
    
    /**
     * 移除状态监听器
     */
    public void removeStatusListener(Consumer<StorageInterface.StorageInfo> listener) {
        statusListeners.remove(listener);
    }
    
    private void notifyStatusChanged() {
        StorageInterface.StorageInfo info = getStorageInfo();
        if (info != null) {
            for (Consumer<StorageInterface.StorageInfo> listener : statusListeners) {
                try {
                    listener.accept(info);
                } catch (Exception e) {
                    System.err.println("状态监听器异常: " + e.getMessage());
                }
            }
        }
    }
}
