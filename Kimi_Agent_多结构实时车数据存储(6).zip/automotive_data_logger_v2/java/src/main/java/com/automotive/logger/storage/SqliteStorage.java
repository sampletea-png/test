package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SQLite存储格式实现
 * 支持SQL查询和分析
 */
public class SqliteStorage extends BaseStorage {
    
    private Connection connection;
    private PreparedStatement insertStmt;
    
    // 表名
    private static final String TABLE_NAME = "vehicle_data";
    
    public SqliteStorage(StorageConfig config) {
        super(config);
    }
    
    @Override
    public String getFormatName() {
        return "sqlite";
    }
    
    @Override
    public String getFileExtension() {
        return "db";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        try {
            filePath.getParent().toFile().mkdirs();
            currentFilePath = filePath;
            
            // 加载SQLite JDBC驱动
            Class.forName("org.sqlite.JDBC");
            
            // 连接数据库
            String url = "jdbc:sqlite:" + filePath.toAbsolutePath();
            connection = DriverManager.getConnection(url);
            
            // 启用WAL模式提高性能
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("PRAGMA journal_mode=WAL");
                stmt.execute("PRAGMA synchronous=NORMAL");
            }
            
            // 创建表
            createTableIfNotExists();
            
            // 准备插入语句
            prepareInsertStatement();
            
        } catch (ClassNotFoundException e) {
            throw new IOException("SQLite JDBC驱动未找到，请添加依赖: org.xerial:sqlite-jdbc", e);
        } catch (SQLException e) {
            throw new IOException("打开SQLite数据库失败", e);
        }
    }
    
    private void createTableIfNotExists() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "timestamp INTEGER NOT NULL," +
            "can_channel INTEGER," +
            "can_id INTEGER," +
            "vehicle_speed REAL," +
            "engine_rpm REAL," +
            "engine_temp REAL," +
            "throttle_position REAL," +
            "brake_position REAL," +
            "steering_angle REAL," +
            "battery_voltage REAL," +
            "fuel_level REAL," +
            "odometer REAL," +
            "accel_x REAL," +
            "accel_y REAL," +
            "accel_z REAL," +
            "created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
        
        // 创建索引
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON " + TABLE_NAME + "(timestamp)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_can_id ON " + TABLE_NAME + "(can_id)");
        }
    }
    
    private void prepareInsertStatement() throws SQLException {
        String sql = "INSERT INTO " + TABLE_NAME + " (" +
            "timestamp, can_channel, can_id, vehicle_speed, engine_rpm, engine_temp, " +
            "throttle_position, brake_position, steering_angle, battery_voltage, " +
            "fuel_level, odometer, accel_x, accel_y, accel_z" +
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        insertStmt = connection.prepareStatement(sql);
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        try {
            insertStmt.setLong(1, data.getTimestamp());
            insertStmt.setInt(2, data.getCanChannel());
            insertStmt.setInt(3, data.getCanId());
            insertStmt.setDouble(4, data.getVehicleSpeed());
            insertStmt.setDouble(5, data.getEngineRpm());
            insertStmt.setDouble(6, data.getEngineTemp());
            insertStmt.setDouble(7, data.getThrottlePosition());
            insertStmt.setDouble(8, data.getBrakePosition());
            insertStmt.setDouble(9, data.getSteeringAngle());
            insertStmt.setDouble(10, data.getBatteryVoltage());
            insertStmt.setDouble(11, data.getFuelLevel());
            insertStmt.setDouble(12, data.getOdometer());
            insertStmt.setDouble(13, data.getAccelX());
            insertStmt.setDouble(14, data.getAccelY());
            insertStmt.setDouble(15, data.getAccelZ());
            
            insertStmt.executeUpdate();
            
        } catch (SQLException e) {
            throw new IOException("写入SQLite失败", e);
        }
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        try {
            connection.setAutoCommit(false);
            
            for (VehicleData data : dataList) {
                insertStmt.setLong(1, data.getTimestamp());
                insertStmt.setInt(2, data.getCanChannel());
                insertStmt.setInt(3, data.getCanId());
                insertStmt.setDouble(4, data.getVehicleSpeed());
                insertStmt.setDouble(5, data.getEngineRpm());
                insertStmt.setDouble(6, data.getEngineTemp());
                insertStmt.setDouble(7, data.getThrottlePosition());
                insertStmt.setDouble(8, data.getBrakePosition());
                insertStmt.setDouble(9, data.getSteeringAngle());
                insertStmt.setDouble(10, data.getBatteryVoltage());
                insertStmt.setDouble(11, data.getFuelLevel());
                insertStmt.setDouble(12, data.getOdometer());
                insertStmt.setDouble(13, data.getAccelX());
                insertStmt.setDouble(14, data.getAccelY());
                insertStmt.setDouble(15, data.getAccelZ());
                
                insertStmt.addBatch();
            }
            
            insertStmt.executeBatch();
            connection.commit();
            connection.setAutoCommit(true);
            
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                // ignore
            }
            throw new IOException("批量写入SQLite失败", e);
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        // SQLite自动刷新
    }
    
    @Override
    protected void doClose() throws IOException {
        try {
            if (insertStmt != null) {
                insertStmt.close();
                insertStmt = null;
            }
            if (connection != null) {
                connection.close();
                connection = null;
            }
        } catch (SQLException e) {
            throw new IOException("关闭SQLite失败", e);
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            return currentFilePath.toFile().length();
        }
        return 0;
    }
    
    // ==================== 查询方法 ====================
    
    /**
     * 执行SQL查询
     */
    public List<Map<String, Object>> query(String sql) throws SQLException {
        List<Map<String, Object>> results = new ArrayList<>();
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(metaData.getColumnName(i), rs.getObject(i));
                }
                results.add(row);
            }
        }
        
        return results;
    }
    
    /**
     * 获取数据统计信息
     */
    public Map<String, Object> getStatistics() throws SQLException {
        Map<String, Object> stats = new HashMap<>();
        
        // 总记录数
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                stats.put("totalRecords", rs.getLong(1));
            }
        }
        
        // 时间范围
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT MIN(timestamp), MAX(timestamp) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                stats.put("minTimestamp", rs.getLong(1));
                stats.put("maxTimestamp", rs.getLong(2));
            }
        }
        
        // 车速统计
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT MIN(vehicle_speed), MAX(vehicle_speed), AVG(vehicle_speed) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                Map<String, Double> speedStats = new HashMap<>();
                speedStats.put("min", rs.getDouble(1));
                speedStats.put("max", rs.getDouble(2));
                speedStats.put("avg", rs.getDouble(3));
                stats.put("speedStats", speedStats);
            }
        }
        
        return stats;
    }
}
