package com.mf4.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 请求类 - 用于Java与Python之间的通信
 */
public class Request {
    
    /**
     * 请求类型枚举
     */
    public enum RequestType {
        OPEN_FILE("open_file"),
        CREATE_FILE("create_file"),
        CLOSE_FILE("close_file"),
        READ_DATA("read_data"),
        READ_BATCH("read_batch"),
        WRITE_DATA("write_data"),
        GET_INFO("get_info"),
        GET_CHANNELS("get_channels"),
        SAVE_FILE("save_file"),
        PING("ping"),
        SHUTDOWN("shutdown");
        
        private final String value;
        
        RequestType(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    private String requestType;
    private String requestId;
    private String fileId;
    private Map<String, Object> data;
    
    public Request() {
        this.requestId = UUID.randomUUID().toString();
        this.data = new HashMap<>();
    }
    
    public Request(RequestType requestType) {
        this();
        this.requestType = requestType.getValue();
    }
    
    public Request(RequestType requestType, String fileId) {
        this(requestType);
        this.fileId = fileId;
    }
    
    public String getRequestType() {
        return requestType;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    public String getRequestId() {
        return requestId;
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    
    public String getFileId() {
        return fileId;
    }
    
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    
    public Map<String, Object> getData() {
        return data;
    }
    
    public void setData(Map<String, Object> data) {
        this.data = data;
    }
    
    public void addData(String key, Object value) {
        if (this.data == null) {
            this.data = new HashMap<>();
        }
        this.data.put(key, value);
    }
    
    /**
     * 创建打开文件请求
     */
    public static Request openFile(String filePath, boolean createIfNotExists) {
        Request request = new Request(RequestType.OPEN_FILE);
        request.addData("filePath", filePath);
        request.addData("createIfNotExists", createIfNotExists);
        return request;
    }
    
    /**
     * 创建文件请求
     */
    public static Request createFile(String filePath, boolean overwrite) {
        Request request = new Request(RequestType.CREATE_FILE);
        request.addData("filePath", filePath);
        request.addData("overwrite", overwrite);
        return request;
    }
    
    /**
     * 创建关闭文件请求
     */
    public static Request closeFile(String fileId) {
        Request request = new Request(RequestType.CLOSE_FILE, fileId);
        return request;
    }
    
    /**
     * 创建读取数据请求
     */
    public static Request readData(String fileId, int groupIndex, Integer channelIndex,
                                   Double start, Double end, Integer samples, Integer chunkSize) {
        Request request = new Request(RequestType.READ_DATA, fileId);
        request.addData("groupIndex", groupIndex);
        if (channelIndex != null) {
            request.addData("channelIndex", channelIndex);
        }
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        if (samples != null) {
            request.addData("samples", samples);
        }
        if (chunkSize != null) {
            request.addData("chunkSize", chunkSize);
        }
        return request;
    }
    
    /**
     * 创建批量读取请求
     */
    public static Request readBatch(String fileId, int groupIndex, int[] channelIndices,
                                    Double start, Double end) {
        Request request = new Request(RequestType.READ_BATCH, fileId);
        request.addData("groupIndex", groupIndex);
        request.addData("channelIndices", channelIndices);
        if (start != null) {
            request.addData("start", start);
        }
        if (end != null) {
            request.addData("end", end);
        }
        return request;
    }
    
    /**
     * 创建获取文件信息请求
     */
    public static Request getInfo(String fileId) {
        return new Request(RequestType.GET_INFO, fileId);
    }
    
    /**
     * 创建获取通道列表请求
     */
    public static Request getChannels(String fileId, Integer groupIndex) {
        Request request = new Request(RequestType.GET_CHANNELS, fileId);
        if (groupIndex != null) {
            request.addData("groupIndex", groupIndex);
        }
        return request;
    }
    
    /**
     * 创建保存文件请求
     */
    public static Request saveFile(String fileId, String filePath, boolean overwrite) {
        Request request = new Request(RequestType.SAVE_FILE, fileId);
        if (filePath != null) {
            request.addData("filePath", filePath);
        }
        request.addData("overwrite", overwrite);
        return request;
    }
    
    /**
     * 创建Ping请求
     */
    public static Request ping() {
        return new Request(RequestType.PING);
    }
    
    /**
     * 创建关闭服务器请求
     */
    public static Request shutdown() {
        return new Request(RequestType.SHUTDOWN);
    }
}
