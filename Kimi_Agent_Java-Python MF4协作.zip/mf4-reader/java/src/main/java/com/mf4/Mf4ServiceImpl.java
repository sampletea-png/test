package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.Request;
import com.mf4.model.Response;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * MF4服务实现类
 */
public class Mf4ServiceImpl implements Mf4Service {
    
    private static final Logger LOGGER = Logger.getLogger(Mf4ServiceImpl.class.getName());
    
    private final PythonProcessManager processManager;
    private final String pythonResourcePath;
    private final String logDir;
    private final int preferredPort;
    
    private SocketClient client;
    private final Map<String, Mf4FileImpl> openFiles;
    private final ReentrantLock lock;
    private final AtomicBoolean running;
    
    /**
     * 创建服务实例
     */
    public Mf4ServiceImpl(String pythonResourcePath, String logDir, int preferredPort) {
        this.pythonResourcePath = pythonResourcePath;
        this.logDir = logDir;
        this.preferredPort = preferredPort;
        this.processManager = PythonProcessManager.fromResource(pythonResourcePath, logDir, preferredPort);
        this.openFiles = new ConcurrentHashMap<>();
        this.lock = new ReentrantLock();
        this.running = new AtomicBoolean(false);
    }
    
    /**
     * 创建服务实例（使用默认端口0）
     */
    public Mf4ServiceImpl(String pythonResourcePath, String logDir) {
        this(pythonResourcePath, logDir, 0);
    }
    
    /**
     * 创建服务实例（使用默认配置）
     */
    public Mf4ServiceImpl(String pythonResourcePath) {
        this(pythonResourcePath, null, 0);
    }
    
    @Override
    public void start() throws Mf4Exception {
        lock.lock();
        try {
            if (running.get()) {
                LOGGER.info("Service already running");
                return;
            }
            
            LOGGER.info("Starting MF4 service...");
            
            // 启动Python进程
            int port;
            try {
                port = processManager.start();
            } catch (IOException e) {
                throw new Mf4Exception("Failed to start Python process", e);
            }
            
            // 创建Socket客户端
            client = new SocketClient("127.0.0.1", port);
            
            try {
                client.connect();
            } catch (IOException e) {
                processManager.stop();
                throw new Mf4Exception("Failed to connect to Python service", e);
            }
            
            // 验证连接
            if (!client.ping()) {
                client.disconnect();
                processManager.stop();
                throw new Mf4Exception("Python service not responding");
            }
            
            running.set(true);
            LOGGER.info("MF4 service started successfully on port " + port);
            
        } finally {
            lock.unlock();
        }
    }
    
    @Override
    public boolean isRunning() {
        return running.get() && processManager.isRunning() && client != null && client.isConnected();
    }
    
    @Override
    public Mf4File openFile(String filePath) throws Mf4Exception {
        return openFile(filePath, false);
    }
    
    @Override
    public Mf4File openFile(String filePath, boolean createIfNotExists) throws Mf4Exception {
        checkRunning();
        
        lock.lock();
        try {
            Request request = Request.openFile(filePath, createIfNotExists);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to open file: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            String fileId = response.getString("fileId");
            Mf4FileImpl file = new Mf4FileImpl(fileId, filePath, client);
            openFiles.put(fileId, file);
            
            LOGGER.fine("Opened file: " + filePath + " with ID: " + fileId);
            
            return file;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error opening file", e);
        } finally {
            lock.unlock();
        }
    }
    
    @Override
    public Mf4File createFile(String filePath) throws Mf4Exception {
        return createFile(filePath, false);
    }
    
    @Override
    public Mf4File createFile(String filePath, boolean overwrite) throws Mf4Exception {
        checkRunning();
        
        lock.lock();
        try {
            Request request = Request.createFile(filePath, overwrite);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to create file: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            String fileId = response.getString("fileId");
            Mf4FileImpl file = new Mf4FileImpl(fileId, filePath, client);
            openFiles.put(fileId, file);
            
            LOGGER.fine("Created file: " + filePath + " with ID: " + fileId);
            
            return file;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error creating file", e);
        } finally {
            lock.unlock();
        }
    }
    
    @Override
    public void close() {
        if (!running.getAndSet(false)) {
            return;
        }
        
        LOGGER.info("Closing MF4 service...");
        
        lock.lock();
        try {
            // 关闭所有打开的文件
            for (Mf4FileImpl file : openFiles.values()) {
                try {
                    file.close();
                } catch (Exception e) {
                    LOGGER.log(Level.WARNING, "Error closing file", e);
                }
            }
            openFiles.clear();
            
            // 关闭Socket客户端
            if (client != null) {
                try {
                    client.shutdownServer();
                } catch (Exception e) {
                    LOGGER.log(Level.FINE, "Error shutting down server", e);
                }
                client = null;
            }
            
            // 停止Python进程
            if (processManager != null) {
                processManager.stop();
            }
            
            LOGGER.info("MF4 service closed");
            
        } finally {
            lock.unlock();
        }
    }
    
    private void checkRunning() throws Mf4Exception {
        if (!isRunning()) {
            throw new Mf4Exception("Service is not running");
        }
    }
    
    private Response sendRequest(Request request) throws IOException {
        return client.sendRequest(request);
    }
    
    /**
     * 获取Python服务端口
     */
    public int getPort() {
        return processManager.getPort();
    }
}
