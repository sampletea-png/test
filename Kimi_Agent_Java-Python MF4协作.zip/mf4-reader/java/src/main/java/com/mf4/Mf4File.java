package com.mf4;

import com.mf4.exception.Mf4Exception;
import com.mf4.model.ChannelData;
import com.mf4.model.FileInfo;

import java.io.Closeable;
import java.util.List;

/**
 * MF4文件操作接口
 */
public interface Mf4File extends Closeable {
    
    /**
     * 获取文件ID
     */
    String getFileId();
    
    /**
     * 获取文件路径
     */
    String getFilePath();
    
    /**
     * 获取文件信息
     */
    FileInfo getInfo() throws Mf4Exception;
    
    /**
     * 获取通道列表
     */
    List<com.mf4.model.ChannelInfo> getChannels() throws Mf4Exception;
    
    /**
     * 获取指定组的通道列表
     */
    List<com.mf4.model.ChannelInfo> getChannels(int groupIndex) throws Mf4Exception;
    
    /**
     * 读取单个通道数据
     */
    ChannelData readChannel(int groupIndex, int channelIndex) throws Mf4Exception;
    
    /**
     * 读取单个通道数据（带时间范围）
     */
    ChannelData readChannel(int groupIndex, int channelIndex, double startTime, double endTime) throws Mf4Exception;
    
    /**
     * 读取单个通道数据（限制采样数）
     */
    ChannelData readChannel(int groupIndex, int channelIndex, int maxSamples) throws Mf4Exception;
    
    /**
     * 批量读取多个通道数据
     */
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices) throws Mf4Exception;
    
    /**
     * 批量读取多个通道数据（带时间范围）
     */
    List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                   double startTime, double endTime) throws Mf4Exception;
    
    /**
     * 读取整个通道组的数据
     */
    List<ChannelData> readGroup(int groupIndex) throws Mf4Exception;
    
    /**
     * 写入通道数据
     */
    void writeChannel(int groupIndex, ChannelData data) throws Mf4Exception;
    
    /**
     * 批量写入通道数据
     */
    void writeChannels(int groupIndex, List<ChannelData> dataList) throws Mf4Exception;
    
    /**
     * 保存文件到原路径
     */
    void save() throws Mf4Exception;
    
    /**
     * 保存文件到指定路径
     */
    void save(String filePath, boolean overwrite) throws Mf4Exception;
    
    /**
     * 关闭文件
     */
    @Override
    void close();
    
    /**
     * 检查文件是否已关闭
     */
    boolean isClosed();
}
