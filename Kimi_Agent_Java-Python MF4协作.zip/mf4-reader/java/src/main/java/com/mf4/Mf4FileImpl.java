package com.mf4;

import com.google.gson.Gson;
import com.mf4.exception.Mf4Exception;
import com.mf4.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * MF4文件实现类
 */
public class Mf4FileImpl implements Mf4File {
    
    private static final Logger LOGGER = Logger.getLogger(Mf4FileImpl.class.getName());
    private static final Gson GSON = new Gson();
    
    private final String fileId;
    private final String filePath;
    private final SocketClient client;
    private final ReentrantReadWriteLock lock;
    private final AtomicBoolean closed;
    
    public Mf4FileImpl(String fileId, String filePath, SocketClient client) {
        this.fileId = fileId;
        this.filePath = filePath;
        this.client = client;
        this.lock = new ReentrantReadWriteLock();
        this.closed = new AtomicBoolean(false);
    }
    
    @Override
    public String getFileId() {
        return fileId;
    }
    
    @Override
    public String getFilePath() {
        return filePath;
    }
    
    @Override
    public FileInfo getInfo() throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.getInfo(fileId);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to get file info: " + response.getErrorMessage(), 
                        response.getRequestId());
            }
            
            return GSON.fromJson(GSON.toJson(response.getData()), FileInfo.class);
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error getting file info", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelInfo> getChannels() throws Mf4Exception {
        return getChannels(null);
    }
    
    @Override
    public List<ChannelInfo> getChannels(Integer groupIndex) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.getChannels(fileId, groupIndex);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to get channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelInfo> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    ChannelInfo info = new ChannelInfo();
                    info.setName((String) ch.get("name"));
                    info.setGroupIndex(((Number) ch.get("groupIndex")).intValue());
                    info.setChannelIndex(((Number) ch.get("channelIndex")).intValue());
                    info.setUnit((String) ch.get("unit"));
                    info.setComment((String) ch.get("comment"));
                    result.add(info);
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error getting channels", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex) throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, null, null, null);
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex, double startTime, double endTime) 
            throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, startTime, endTime, null);
    }
    
    @Override
    public ChannelData readChannel(int groupIndex, int channelIndex, int maxSamples) throws Mf4Exception {
        return readChannel(groupIndex, channelIndex, null, null, maxSamples);
    }
    
    private ChannelData readChannel(int groupIndex, int channelIndex, 
                                    Double startTime, Double endTime, Integer maxSamples) 
            throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readData(fileId, groupIndex, channelIndex, 
                    startTime, endTime, maxSamples, null);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read channel: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            return parseChannelData(response.getData());
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading channel", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelData> readChannels(int groupIndex, int[] channelIndices) throws Mf4Exception {
        return readChannels(groupIndex, channelIndices, null, null);
    }
    
    @Override
    public List<ChannelData> readChannels(int groupIndex, int[] channelIndices, 
                                          double startTime, double endTime) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readBatch(fileId, groupIndex, channelIndices, startTime, endTime);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelData> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    if (ch.containsKey("error")) {
                        LOGGER.warning("Error reading channel: " + ch.get("error"));
                        continue;
                    }
                    result.add(parseChannelData(ch));
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading channels", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public List<ChannelData> readGroup(int groupIndex) throws Mf4Exception {
        checkClosed();
        
        lock.readLock().lock();
        try {
            Request request = Request.readData(fileId, groupIndex, null, null, null, null, null);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to read group: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
            List<Map<String, Object>> channelList = response.getList("channels");
            List<ChannelData> result = new ArrayList<>();
            
            if (channelList != null) {
                for (Map<String, Object> ch : channelList) {
                    result.add(parseChannelData(ch));
                }
            }
            
            return result;
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error reading group", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void writeChannel(int groupIndex, ChannelData data) throws Mf4Exception {
        List<ChannelData> list = new ArrayList<>();
        list.add(data);
        writeChannels(groupIndex, list);
    }
    
    @Override
    public void writeChannels(int groupIndex, List<ChannelData> dataList) throws Mf4Exception {
        checkClosed();
        
        lock.writeLock().lock();
        try {
            // 构建写入数据
            List<Map<String, Object>> channelData = new ArrayList<>();
            for (ChannelData data : dataList) {
                Map<String, Object> ch = new java.util.HashMap<>();
                ch.put("name", data.getName());
                ch.put("unit", data.getUnit());
                ch.put("timestamps", data.getTimestamps());
                ch.put("values", data.getValues());
                channelData.add(ch);
            }
            
            Request request = new Request(Request.RequestType.WRITE_DATA, fileId);
            request.addData("groupIndex", groupIndex);
            request.addData("channelData", channelData);
            
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to write channels: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error writing channels", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void save() throws Mf4Exception {
        save(null, false);
    }
    
    @Override
    public void save(String filePath, boolean overwrite) throws Mf4Exception {
        checkClosed();
        
        lock.writeLock().lock();
        try {
            Request request = Request.saveFile(fileId, filePath, overwrite);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                throw new Mf4Exception("Failed to save file: " + response.getErrorMessage(),
                        response.getRequestId());
            }
            
        } catch (IOException e) {
            throw new Mf4Exception("IO error saving file", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void close() {
        if (closed.getAndSet(true)) {
            return;
        }
        
        try {
            Request request = Request.closeFile(fileId);
            Response response = sendRequest(request);
            
            if (!response.isSuccess()) {
                LOGGER.warning("Error closing file: " + response.getErrorMessage());
            }
            
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing file", e);
        }
    }
    
    @Override
    public boolean isClosed() {
        return closed.get();
    }
    
    private void checkClosed() throws Mf4Exception {
        if (closed.get()) {
            throw new Mf4Exception("File is closed");
        }
    }
    
    private Response sendRequest(Request request) throws IOException {
        return client.sendRequest(request);
    }
    
    @SuppressWarnings("unchecked")
    private ChannelData parseChannelData(Map<String, Object> data) {
        ChannelData result = new ChannelData();
        result.setName((String) data.get("name"));
        result.setUnit((String) data.get("unit"));
        
        List<Number> timestamps = (List<Number>) data.get("timestamps");
        if (timestamps != null) {
            List<Double> tsList = new ArrayList<>(timestamps.size());
            for (Number n : timestamps) {
                tsList.add(n.doubleValue());
            }
            result.setTimestamps(tsList);
        }
        
        result.setValues((List<Object>) data.get("values"));
        result.setSampleCount(((Number) data.get("sampleCount")).intValue());
        
        return result;
    }
}
