"""
通信协议模块 - 定义Request和Response的数据结构
"""
import json
import struct
from enum import Enum
from typing import Any, Dict, Optional


class RequestType(Enum):
    """请求类型枚举"""
    OPEN_FILE = "open_file"
    CREATE_FILE = "create_file"
    CLOSE_FILE = "close_file"
    READ_DATA = "read_data"
    READ_BATCH = "read_batch"
    WRITE_DATA = "write_data"
    GET_INFO = "get_info"
    GET_CHANNELS = "get_channels"
    SAVE_FILE = "save_file"
    PING = "ping"
    SHUTDOWN = "shutdown"


class ResponseStatus(Enum):
    """响应状态枚举"""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"  # 用于大数据分段返回


class Request:
    """请求类 - 对应Java端的Request"""
    
    def __init__(self, request_type: RequestType, request_id: str = None, 
                 file_id: str = None, data: Dict[str, Any] = None):
        self.request_type = request_type
        self.request_id = request_id
        self.file_id = file_id
        self.data = data or {}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'requestType': self.request_type.value if isinstance(self.request_type, RequestType) else self.request_type,
            'requestId': self.request_id,
            'fileId': self.file_id,
            'data': self.data
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Request':
        req_type = data.get('requestType')
        if isinstance(req_type, str):
            req_type = RequestType(req_type)
        return cls(
            request_type=req_type,
            request_id=data.get('requestId'),
            file_id=data.get('fileId'),
            data=data.get('data', {})
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Request':
        return cls.from_dict(json.loads(json_str))


class Response:
    """响应类 - 对应Java端的Response"""
    
    def __init__(self, request_id: str, status: ResponseStatus, 
                 message: str = None, data: Dict[str, Any] = None,
                 has_more: bool = False, chunk_index: int = 0):
        self.request_id = request_id
        self.status = status
        self.message = message
        self.data = data or {}
        self.has_more = has_more  # 是否还有更多数据（分段传输）
        self.chunk_index = chunk_index  # 当前块索引
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'requestId': self.request_id,
            'status': self.status.value if isinstance(self.status, ResponseStatus) else self.status,
            'message': self.message,
            'data': self.data,
            'hasMore': self.has_more,
            'chunkIndex': self.chunk_index
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Response':
        status = data.get('status')
        if isinstance(status, str):
            status = ResponseStatus(status)
        return cls(
            request_id=data.get('requestId'),
            status=status,
            message=data.get('message'),
            data=data.get('data', {}),
            has_more=data.get('hasMore', False),
            chunk_index=data.get('chunkIndex', 0)
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Response':
        return cls.from_dict(json.loads(json_str))
    
    @classmethod
    def success(cls, request_id: str, data: Dict[str, Any] = None, message: str = None) -> 'Response':
        return cls(request_id, ResponseStatus.SUCCESS, message, data)
    
    @classmethod
    def error(cls, request_id: str, message: str, data: Dict[str, Any] = None) -> 'Response':
        return cls(request_id, ResponseStatus.ERROR, message, data)
    
    @classmethod
    def partial(cls, request_id: str, data: Dict[str, Any], chunk_index: int, has_more: bool) -> 'Response':
        return cls(request_id, ResponseStatus.PARTIAL, None, data, has_more, chunk_index)


class ProtocolHelper:
    """协议辅助类 - 处理数据包的发送和接收"""
    
    # 魔数和版本号，用于协议校验
    MAGIC_NUMBER = b'MF4P'
    VERSION = 1
    HEADER_SIZE = 12  # 魔数(4) + 版本(1) + 保留(3) + 数据长度(4)
    
    @classmethod
    def encode_message(cls, message: str) -> bytes:
        """将消息编码为字节流（带协议头）"""
        data = message.encode('utf-8')
        data_length = len(data)
        
        # 构建协议头: 魔数(4) + 版本(1) + 保留(3) + 数据长度(4)
        header = cls.MAGIC_NUMBER + struct.pack('B', cls.VERSION) + b'\x00\x00\x00' + struct.pack('>I', data_length)
        
        return header + data
    
    @classmethod
    def decode_header(cls, header: bytes) -> tuple:
        """解码协议头，返回(版本, 数据长度)"""
        if len(header) < cls.HEADER_SIZE:
            raise ValueError(f"Invalid header size: {len(header)}")
        
        magic = header[:4]
        if magic != cls.MAGIC_NUMBER:
            raise ValueError(f"Invalid magic number: {magic}")
        
        version = struct.unpack('B', header[4:5])[0]
        data_length = struct.unpack('>I', header[8:12])[0]
        
        return version, data_length
    
    @classmethod
    def receive_message(cls, sock, buffer_size: int = 8192) -> str:
        """从socket接收完整的消息"""
        # 先接收协议头
        header_data = b''
        while len(header_data) < cls.HEADER_SIZE:
            chunk = sock.recv(cls.HEADER_SIZE - len(header_data))
            if not chunk:
                raise ConnectionError("Connection closed while receiving header")
            header_data += chunk
        
        version, data_length = cls.decode_header(header_data)
        
        # 接收数据体
        body_data = b''
        while len(body_data) < data_length:
            to_read = min(buffer_size, data_length - len(body_data))
            chunk = sock.recv(to_read)
            if not chunk:
                raise ConnectionError("Connection closed while receiving body")
            body_data += chunk
        
        return body_data.decode('utf-8')
    
    @classmethod
    def send_message(cls, sock, message: str) -> None:
        """发送完整的消息"""
        data = cls.encode_message(message)
        sock.sendall(data)
