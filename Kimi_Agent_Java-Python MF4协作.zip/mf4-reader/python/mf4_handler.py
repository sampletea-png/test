"""
MF4文件处理模块 - 处理MF4文件的具体操作
"""
import os
import threading
import uuid
from typing import Dict, List, Optional, Any, BinaryIO
from dataclasses import dataclass
import numpy as np

from asammdf import MDF
from asammdf.blocks.mdf_v4 import MDF4

import logging

logger = logging.getLogger('mf4_server')


@dataclass
class FileHandle:
    """文件句柄封装类"""
    file_id: str
    file_path: str
    mdf: MDF
    mode: str  # 'r', 'w', 'rw'
    ref_count: int = 0  # 引用计数
    lock: threading.RLock = None
    
    def __post_init__(self):
        if self.lock is None:
            self.lock = threading.RLock()


class Mf4FileManager:
    """MF4文件管理器 - 管理所有打开的文件句柄"""
    
    # 默认分段读取大小 (10MB)
    DEFAULT_CHUNK_SIZE = 10 * 1024 * 1024
    
    def __init__(self):
        # 文件句柄映射: file_id -> FileHandle
        self._files: Dict[str, FileHandle] = {}
        # 路径到file_id的映射: file_path -> set(file_id)
        self._path_to_ids: Dict[str, set] = {}
        # 全局锁
        self._global_lock = threading.RLock()
    
    def open_file(self, file_path: str, mode: str = 'r', create_if_not_exists: bool = False) -> str:
        """
        打开MF4文件
        
        Args:
            file_path: 文件路径
            mode: 打开模式 ('r', 'w', 'rw')
            create_if_not_exists: 文件不存在时是否创建
            
        Returns:
            file_id: 文件唯一标识
        """
        with self._global_lock:
            # 检查文件是否存在
            file_exists = os.path.exists(file_path)
            
            if not file_exists and mode == 'r' and not create_if_not_exists:
                raise FileNotFoundError(f"File not found: {file_path}")
            
            # 如果文件已打开，增加引用计数
            if file_path in self._path_to_ids:
                for file_id in self._path_to_ids[file_path]:
                    handle = self._files.get(file_id)
                    if handle and handle.mode == mode:
                        with handle.lock:
                            handle.ref_count += 1
                        logger.info(f"Reused file handle: {file_id}, ref_count: {handle.ref_count}")
                        return file_id
            
            # 创建新的文件句柄
            file_id = str(uuid.uuid4())
            
            try:
                if mode == 'w' or (mode == 'rw' and not file_exists and create_if_not_exists):
                    # 创建新文件
                    mdf = MDF(version='4.11')
                else:
                    # 打开现有文件
                    mdf = MDF(file_path)
                
                handle = FileHandle(
                    file_id=file_id,
                    file_path=file_path,
                    mdf=mdf,
                    mode=mode
                )
                handle.ref_count = 1
                
                self._files[file_id] = handle
                
                if file_path not in self._path_to_ids:
                    self._path_to_ids[file_path] = set()
                self._path_to_ids[file_path].add(file_id)
                
                logger.info(f"Opened file: {file_path}, mode: {mode}, file_id: {file_id}")
                return file_id
                
            except Exception as e:
                logger.error(f"Failed to open file {file_path}: {e}")
                raise
    
    def close_file(self, file_id: str) -> bool:
        """
        关闭文件
        
        Args:
            file_id: 文件唯一标识
            
        Returns:
            是否成功关闭
        """
        with self._global_lock:
            handle = self._files.get(file_id)
            if not handle:
                logger.warning(f"File not found for closing: {file_id}")
                return False
            
            with handle.lock:
                handle.ref_count -= 1
                
                if handle.ref_count <= 0:
                    try:
                        handle.mdf.close()
                        logger.info(f"Closed file: {handle.file_path}, file_id: {file_id}")
                    except Exception as e:
                        logger.error(f"Error closing file {file_id}: {e}")
                    finally:
                        del self._files[file_id]
                        self._path_to_ids[handle.file_path].discard(file_id)
                        if not self._path_to_ids[handle.file_path]:
                            del self._path_to_ids[handle.file_path]
                else:
                    logger.info(f"Decreased ref_count for {file_id}: {handle.ref_count}")
            
            return True
    
    def get_file_info(self, file_id: str) -> Dict[str, Any]:
        """获取文件信息"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            info = {
                'filePath': handle.file_path,
                'mode': handle.mode,
                'version': handle.mdf.version_str if hasattr(handle.mdf, 'version_str') else 'unknown',
                'channelCount': len(handle.mdf.channels_db) if hasattr(handle.mdf, 'channels_db') else 0,
            }
            
            # 获取通道组信息
            groups = []
            if hasattr(handle.mdf, 'groups'):
                for i, group in enumerate(handle.mdf.groups):
                    group_info = {
                        'index': i,
                        'channelCount': len(group.channels) if hasattr(group, 'channels') else 0
                    }
                    groups.append(group_info)
            
            info['groups'] = groups
            return info
    
    def get_channels(self, file_id: str, group_index: int = None) -> List[Dict[str, Any]]:
        """获取通道列表"""
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            channels = []
            
            if hasattr(handle.mdf, 'groups'):
                groups_to_process = [handle.mdf.groups[group_index]] if group_index is not None else handle.mdf.groups
                
                for g_idx, group in enumerate(groups_to_process):
                    if hasattr(group, 'channels'):
                        for c_idx, channel in enumerate(group.channels):
                            ch_info = {
                                'name': channel.name if hasattr(channel, 'name') else f'Channel_{c_idx}',
                                'groupIndex': g_idx if group_index is None else group_index,
                                'channelIndex': c_idx,
                            }
                            
                            # 添加更多通道信息
                            if hasattr(channel, 'unit'):
                                ch_info['unit'] = channel.unit
                            if hasattr(channel, 'comment'):
                                ch_info['comment'] = str(channel.comment) if channel.comment else ''
                            
                            channels.append(ch_info)
            
            return channels
    
    def read_data(self, file_id: str, group_index: int, channel_index: int = None,
                  start: float = None, end: float = None, 
                  samples: int = None, chunk_size: int = None) -> Dict[str, Any]:
        """
        读取数据
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_index: 通道索引，None表示读取整个组
            start: 开始时间
            end: 结束时间
            samples: 采样点数限制
            chunk_size: 分段大小（字节）
            
        Returns:
            包含数据和元信息的字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            try:
                # 使用asammdf的get方法读取数据
                if channel_index is not None:
                    # 读取单个通道
                    signal = handle.mdf.get(
                        group=group_index,
                        index=channel_index,
                        samples_only=False
                    )
                    
                    # 应用时间和采样限制
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                    
                    if samples is not None and len(timestamps) > samples:
                        timestamps = timestamps[:samples]
                        values = values[:samples]
                    
                    return {
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps)
                    }
                else:
                    # 读取整个通道组
                    group_data = []
                    if group_index < len(handle.mdf.groups):
                        group = handle.mdf.groups[group_index]
                        if hasattr(group, 'channels'):
                            for idx in range(len(group.channels)):
                                signal = handle.mdf.get(group=group_index, index=idx, samples_only=False)
                                
                                timestamps = signal.timestamps
                                values = signal.samples
                                
                                if start is not None or end is not None:
                                    mask = np.ones(len(timestamps), dtype=bool)
                                    if start is not None:
                                        mask &= timestamps >= start
                                    if end is not None:
                                        mask &= timestamps <= end
                                    timestamps = timestamps[mask]
                                    values = values[mask]
                                
                                if samples is not None and len(timestamps) > samples:
                                    timestamps = timestamps[:samples]
                                    values = values[:samples]
                                
                                group_data.append({
                                    'timestamps': timestamps.tolist(),
                                    'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                                    'name': signal.name,
                                    'unit': signal.unit if hasattr(signal, 'unit') else '',
                                    'sampleCount': len(timestamps)
                                })
                    
                    return {
                        'groupIndex': group_index,
                        'channels': group_data,
                        'channelCount': len(group_data)
                    }
                    
            except Exception as e:
                logger.error(f"Error reading data from file {file_id}: {e}")
                raise
    
    def read_batch(self, file_id: str, group_index: int, channel_indices: List[int],
                   start: float = None, end: float = None) -> Dict[str, Any]:
        """
        批量读取多个通道数据
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引
            channel_indices: 通道索引列表
            start: 开始时间
            end: 结束时间
            
        Returns:
            包含多个通道数据的字典
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        with handle.lock:
            results = []
            
            for ch_idx in channel_indices:
                try:
                    signal = handle.mdf.get(group=group_index, index=ch_idx, samples_only=False)
                    
                    timestamps = signal.timestamps
                    values = signal.samples
                    
                    if start is not None or end is not None:
                        mask = np.ones(len(timestamps), dtype=bool)
                        if start is not None:
                            mask &= timestamps >= start
                        if end is not None:
                            mask &= timestamps <= end
                        timestamps = timestamps[mask]
                        values = values[mask]
                    
                    results.append({
                        'timestamps': timestamps.tolist(),
                        'values': values.tolist() if not isinstance(values, np.ndarray) else values.tolist(),
                        'name': signal.name,
                        'channelIndex': ch_idx,
                        'unit': signal.unit if hasattr(signal, 'unit') else '',
                        'sampleCount': len(timestamps)
                    })
                except Exception as e:
                    logger.error(f"Error reading channel {ch_idx}: {e}")
                    results.append({
                        'error': str(e),
                        'channelIndex': ch_idx
                    })
            
            return {
                'groupIndex': group_index,
                'channels': results,
                'channelCount': len(results)
            }
    
    def write_data(self, file_id: str, group_index: int, channel_data: List[Dict[str, Any]]) -> bool:
        """
        写入数据（追加到现有文件）
        
        Args:
            file_id: 文件ID
            group_index: 通道组索引（None则创建新组）
            channel_data: 通道数据列表
            
        Returns:
            是否成功
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        if handle.mode == 'r':
            raise PermissionError("File opened in read-only mode")
        
        with handle.lock:
            try:
                # 将数据转换为asammdf需要的格式
                signals = []
                for ch in channel_data:
                    from asammdf import Signal
                    signal = Signal(
                        samples=np.array(ch['values']),
                        timestamps=np.array(ch['timestamps']),
                        name=ch['name'],
                        unit=ch.get('unit', '')
                    )
                    signals.append(signal)
                
                # 追加到文件
                handle.mdf.append(signals, comment=channel_data[0].get('comment', 'Written by mf4_server'))
                
                logger.info(f"Written {len(signals)} signals to file {file_id}, group {group_index}")
                return True
                
            except Exception as e:
                logger.error(f"Error writing data to file {file_id}: {e}")
                raise
    
    def save_file(self, file_id: str, file_path: str = None, overwrite: bool = False) -> str:
        """
        保存文件
        
        Args:
            file_id: 文件ID
            file_path: 保存路径，None则保存到原路径
            overwrite: 是否覆盖现有文件
            
        Returns:
            保存的文件路径
        """
        handle = self._get_handle(file_id)
        if not handle:
            raise ValueError(f"File not found: {file_id}")
        
        target_path = file_path or handle.file_path
        
        if os.path.exists(target_path) and not overwrite:
            raise FileExistsError(f"File already exists: {target_path}")
        
        with handle.lock:
            try:
                handle.mdf.save(target_path, overwrite=overwrite)
                logger.info(f"Saved file: {target_path}")
                
                # 更新文件路径映射
                if target_path != handle.file_path:
                    old_path = handle.file_path
                    self._path_to_ids[old_path].discard(file_id)
                    if not self._path_to_ids[old_path]:
                        del self._path_to_ids[old_path]
                    
                    handle.file_path = target_path
                    if target_path not in self._path_to_ids:
                        self._path_to_ids[target_path] = set()
                    self._path_to_ids[target_path].add(file_id)
                
                return target_path
                
            except Exception as e:
                logger.error(f"Error saving file {file_id}: {e}")
                raise
    
    def close_all(self):
        """关闭所有文件"""
        with self._global_lock:
            file_ids = list(self._files.keys())
            for file_id in file_ids:
                try:
                    handle = self._files.get(file_id)
                    if handle:
                        handle.mdf.close()
                        logger.info(f"Closed file during shutdown: {handle.file_path}")
                except Exception as e:
                    logger.error(f"Error closing file {file_id}: {e}")
            
            self._files.clear()
            self._path_to_ids.clear()
    
    def _get_handle(self, file_id: str) -> Optional[FileHandle]:
        """获取文件句柄"""
        return self._files.get(file_id)
