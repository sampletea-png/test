# MF4 File Reader - Java + Python 混合实现

一个支持多线程读写的MF4（ASAM MDF4）文件处理库，Java端提供接口，Python端处理具体的文件操作，通过Socket进行通信。

## 特性

- ✅ **多线程支持**：多个线程可以同时处理不同的MF4文件，也可以安全地处理同一文件
- ✅ **单一Python进程**：整个生命周期只有一个Python进程，支持Java端的多线程请求
- ✅ **自动生命周期管理**：Java端关闭时Python端自动关闭，Java异常退出时Python也会终止
- ✅ **大文件支持**：支持GB级MF4文件的分段读取
- ✅ **灵活的文件操作**：支持创建、打开、读写、保存MF4文件
- ✅ **完善的日志系统**：Python端独立日志，便于调试
- ✅ **自定义通信协议**：通过Request/Response类进行结构化通信

## 项目结构

```
mf4-reader/
├── java/                          # Java端代码
│   ├── src/
│   │   ├── main/java/com/mf4/
│   │   │   ├── Mf4File.java       # MF4文件操作接口
│   │   │   ├── Mf4FileImpl.java   # 文件操作实现
│   │   │   ├── Mf4Service.java    # 服务接口
│   │   │   ├── Mf4ServiceImpl.java # 服务实现
│   │   │   ├── SocketClient.java  # Socket客户端
│   │   │   ├── PythonProcessManager.java # Python进程管理
│   │   │   ├── Main.java          # 入口类
│   │   │   ├── model/
│   │   │   │   ├── Request.java   # 请求类
│   │   │   │   ├── Response.java  # 响应类
│   │   │   │   ├── FileInfo.java  # 文件信息
│   │   │   │   ├── ChannelInfo.java # 通道信息
│   │   │   │   └── ChannelData.java # 通道数据
│   │   │   └── exception/
│   │   │       └── Mf4Exception.java
│   │   └── test/java/com/mf4/
│   │       └── Mf4ServiceTest.java # 测试类
│   └── pom.xml                    # Maven配置
└── python/                        # Python端代码
    ├── mf4_server.py              # 主服务器
    ├── mf4_handler.py             # MF4文件处理
    ├── protocol.py                # 通信协议
    ├── logger_config.py           # 日志配置
    └── requirements.txt           # Python依赖
```

## 快速开始

### 1. 安装Python依赖

```bash
cd python
pip install -r requirements.txt
```

### 2. 构建Java项目

```bash
cd java
mvn clean package
```

### 3. 使用示例

```java
import com.mf4.*;
import com.mf4.model.*;

public class Example {
    public static void main(String[] args) {
        // 创建服务实例
        String pythonScriptPath = "python/mf4_server.py";
        
        try (Mf4Service service = new Mf4ServiceImpl(pythonScriptPath)) {
            // 启动服务
            service.start();
            
            // 创建新文件
            Mf4File file = service.createFile("/path/to/output.mf4");
            
            // 或打开现有文件
            // Mf4File file = service.openFile("/path/to/input.mf4");
            
            // 获取文件信息
            FileInfo info = file.getInfo();
            System.out.println("Version: " + info.getVersion());
            System.out.println("Channels: " + info.getChannelCount());
            
            // 获取通道列表
            List<ChannelInfo> channels = file.getChannels();
            for (ChannelInfo ch : channels) {
                System.out.println("Channel: " + ch.getName());
            }
            
            // 读取通道数据
            ChannelData data = file.readChannel(0, 0);  // 读取第0组的第0个通道
            System.out.println("Samples: " + data.getSampleCount());
            
            // 批量读取多个通道
            List<ChannelData> batchData = file.readChannels(0, new int[]{0, 1, 2});
            
            // 保存文件
            file.save();
            
            // 或保存到其他路径
            // file.save("/path/to/new.mf4", true);  // true表示覆盖
            
            // 关闭文件
            file.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

## 多线程使用示例

```java
// 服务实例是线程安全的，可以被多个线程共享
Mf4Service service = new Mf4ServiceImpl(pythonScriptPath);
service.start();

// 多个线程可以同时处理不同的文件
ExecutorService executor = Executors.newFixedThreadPool(5);

for (int i = 0; i < 5; i++) {
    final int index = i;
    executor.submit(() -> {
        // 每个线程打开自己的文件
        Mf4File file = service.openFile("/path/to/file" + index + ".mf4");
        
        // 处理文件...
        ChannelData data = file.readChannel(0, 0);
        
        file.close();
    });
}

// 多个线程也可以安全地处理同一文件
executor.submit(() -> {
    Mf4File file = service.openFile("/path/to/shared.mf4");
    // 读取操作是线程安全的
    ChannelData data1 = file.readChannel(0, 0);
    file.close();
});

executor.submit(() -> {
    Mf4File file = service.openFile("/path/to/shared.mf4");
    ChannelData data2 = file.readChannel(0, 1);
    file.close();
});
```

## API文档

### Mf4Service 接口

| 方法 | 说明 |
|------|------|
| `start()` | 启动Python服务 |
| `isRunning()` | 检查服务是否运行中 |
| `openFile(path)` | 打开文件（只读） |
| `openFile(path, createIfNotExists)` | 打开文件，可指定不存在时创建 |
| `createFile(path)` | 创建新文件 |
| `createFile(path, overwrite)` | 创建文件，可指定是否覆盖 |
| `close()` | 关闭服务 |

### Mf4File 接口

| 方法 | 说明 |
|------|------|
| `getInfo()` | 获取文件信息 |
| `getChannels()` | 获取所有通道列表 |
| `getChannels(groupIndex)` | 获取指定组的通道列表 |
| `readChannel(group, channel)` | 读取单个通道数据 |
| `readChannel(group, channel, start, end)` | 按时间范围读取 |
| `readChannel(group, channel, maxSamples)` | 限制采样数读取 |
| `readChannels(group, indices)` | 批量读取多个通道 |
| `readGroup(groupIndex)` | 读取整个通道组 |
| `writeChannel(group, data)` | 写入通道数据 |
| `writeChannels(group, dataList)` | 批量写入通道数据 |
| `save()` | 保存到原路径 |
| `save(path, overwrite)` | 保存到指定路径 |
| `close()` | 关闭文件 |

## 通信协议

Java与Python之间使用自定义二进制协议进行通信：

```
协议头 (12字节):
  - 魔数 (4字节): "MF4P"
  - 版本 (1字节): 1
  - 保留 (3字节): 0
  - 数据长度 (4字节): 大端序

数据体:
  - JSON格式的Request/Response
```

### Request 格式

```json
{
  "requestType": "open_file",
  "requestId": "uuid",
  "fileId": "file-uuid",
  "data": {
    "filePath": "/path/to/file.mf4",
    "createIfNotExists": false
  }
}
```

### Response 格式

```json
{
  "requestId": "uuid",
  "status": "success",
  "message": null,
  "data": {
    "fileId": "file-uuid"
  },
  "hasMore": false,
  "chunkIndex": 0
}
```

## 日志配置

Python端日志默认保存在 `python/logs/` 目录下：
- 日志文件按天轮转: `mf4_server_YYYYMMDD.log`
- 单文件最大50MB，保留10个备份
- 包含时间戳、日志级别、线程名、文件名和行号

## 注意事项

1. **Python依赖**: 需要安装 `asammdf>=7.0.0` 和 `numpy>=1.20.0`
2. **Java版本**: 需要Java 11或更高版本
3. **大文件处理**: 读取大文件时建议使用时间范围或采样数限制
4. **线程安全**: 单个Mf4File实例的读操作是线程安全的，写操作会加锁
5. **资源释放**: 确保调用 `close()` 方法释放资源，或使用 try-with-resources

## 许可证

MIT License
