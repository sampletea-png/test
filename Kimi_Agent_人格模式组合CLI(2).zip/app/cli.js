#!/usr/bin/env node
// ============================================================================
// Pattern Orchestrator CLI - Pure Node.js (Zero Dependencies)
// Usage: node cli.js <command> [options]
// ============================================================================

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const {
  C, DIRS, loadConfig, saveConfig, loadMdFile, syncProject, findComponent,
  resolvePattern, getResolvedComponents, exportMarkdown, createPattern,
  installOpenCodeModes, writeOpenCodeJson, exportPatternMdFile
} = require('./core.js');

// Terminal helpers
function log(...args) { console.log(...args); }
function success(msg) { log(`${C.green}  ${msg}${C.reset}`); }
function error(msg) { log(`${C.red}  ${msg}${C.reset}`); }
function warn(msg) { log(`${C.yellow}  ${msg}${C.reset}`); }
function info(msg) { log(`${C.gray}  ${msg}${C.reset}`); }
function bold(msg) { return `${C.bold}${msg}${C.reset}`; }
function header(text) {
  log(`${C.bold}${C.cyan}\n  ╔══════════════════════════════════════════╗${C.reset}`);
  log(`${C.bold}${C.cyan}  ║${text.padStart(21 + text.length / 2).padEnd(42)}║${C.reset}`);
  log(`${C.bold}${C.cyan}  ╚══════════════════════════════════════════╝${C.reset}\n`);
}

// Question prompt (inquirer replacement)
function ask(rl, question) {
  return new Promise(resolve => rl.question(question, resolve));
}

function askList(rl, question, choices) {
  const display = choices.map((c, i) => `  ${C.cyan}${i + 1}.${C.reset} ${c.name || c}`).join('\n');
  return new Promise(async resolve => {
    log(question);
    log(display);
    const answer = await ask(rl, `  ${C.gray}Select (1-${choices.length}):${C.reset} `);
    const idx = parseInt(answer) - 1;
    if (idx >= 0 && idx < choices.length) resolve(choices[idx].value || choices[idx]);
    else resolve(null);
  });
}

function askConfirm(rl, question) {
  return new Promise(async resolve => {
    const answer = await ask(rl, `${question} ${C.gray}[y/N]:${C.reset} `);
    resolve(answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes');
  });
}

// Spinner (ora replacement)
function spinner(text) {
  const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
  let i = 0, timer = null;
  return {
    start() {
      process.stdout.write(`${C.gray}${frames[0]} ${text}${C.reset}`);
      timer = setInterval(() => {
        process.stdout.write(`\r${C.gray}${frames[++i % frames.length]} ${text}${C.reset}`);
      }, 80);
      return this;
    },
    succeed(msg) {
      clearInterval(timer);
      process.stdout.write(`\r${C.green}✓${C.reset} ${msg || text}\n`);
    },
    fail(msg) {
      clearInterval(timer);
      process.stdout.write(`\r${C.red}✗${C.reset} ${msg || text}\n`);
    }
  };
}

// Argument parser (commander replacement)
function parseArgs(argv) {
  const args = argv.slice(2);
  const command = args[0];
  const positional = [];
  const options = {};
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg.startsWith('--')) {
      const eq = arg.indexOf('=');
      if (eq > 0) { options[arg.slice(2, eq)] = arg.slice(eq + 1); }
      else {
        const next = args[i + 1];
        if (next && !next.startsWith('-')) { options[arg.slice(2)] = next; i++; }
        else { options[arg.slice(2)] = true; }
      }
    } else if (arg.startsWith('-') && arg.length === 2) {
      const next = args[i + 1];
      const key = { i: 'inherit', p: 'persona', t: 'thinking', d: 'dialogue', e: 'export' }[arg[1]];
      if (key && next && !next.startsWith('-')) { options[key] = next; i++; }
    } else {
      positional.push(arg);
    }
  }
  return { command, positional, options };
}

// Command handlers
function cmdSync() {
  const spin = spinner('Scanning project directories...').start();
  const config = syncProject(loadConfig());
  saveConfig(config);
  spin.succeed('Synced');
  info(`Config: ${require('./core.js').getConfigPath()}`);
  info(`Personas: ${config.personas.length} | Thinking: ${config.thinkingModels.length} | Dialogue: ${config.dialoguePatterns.length} | Patterns: ${config.patterns.length}`);
  log();
}

function cmdList(type) {
  const config = syncProject(loadConfig());
  if (!type || type === 'all') {
    log(`\n  ${C.bold}${C.brightCyan}=== Pattern Orchestrator ===${C.reset}\n`);
    listComponents(config.personas, 'Personas', C.brightBlue);
    listComponents(config.thinkingModels, 'Thinking Models', C.brightMagenta);
    listComponents(config.dialoguePatterns, 'Dialogue Patterns', C.brightGreen);
    listPatterns(config);
  } else if (type === 'personas') listComponents(config.personas, 'Personas', C.brightBlue);
  else if (type === 'thinking') listComponents(config.thinkingModels, 'Thinking Models', C.brightMagenta);
  else if (type === 'dialogue') listComponents(config.dialoguePatterns, 'Dialogue Patterns', C.brightGreen);
  else if (type === 'patterns') listPatterns(config);
  else error(`Unknown type: ${type}`);
}

function listComponents(items, title, color) {
  log(`${color}  [${title}]${C.reset}`);
  if (items.length === 0) { info('    (none)\n'); return; }
  for (const item of items) {
    log(`    ${C.white}${C.bold}${item.fileName}${C.reset}`);
    info(`      ${item.description || '(no description)'}\n`);
  }
}

function listPatterns(config) {
  log(`${C.brightCyan}  [Patterns]${C.reset}`);
  if (config.patterns.length === 0) { info('    (none)\n'); return; }
  for (const p of config.patterns) {
    const resolved = resolvePattern(config, p);
    const inherits = p.inheritsFrom ? `${C.yellow} <- [${p.inheritsFrom}]${C.reset}` : '';
    log(`    ${C.white}${C.bold}${p.label}${C.reset}${inherits}`);
    const slots = [];
    if (resolved.slots.persona) { const c = findComponent(config, resolved.slots.persona, 'persona'); slots.push(`${C.blue}persona:${c?.name || resolved.slots.persona}${C.reset}`); }
    if (resolved.slots.thinking) { const c = findComponent(config, resolved.slots.thinking, 'thinking'); slots.push(`${C.magenta}thinking:${c?.name || resolved.slots.thinking}${C.reset}`); }
    if (resolved.slots.dialogue) { const c = findComponent(config, resolved.slots.dialogue, 'dialogue'); slots.push(`${C.green}dialogue:${c?.name || resolved.slots.dialogue}${C.reset}`); }
    if (slots.length > 0) log(`      ${slots.join(' | ')}\n`);
    else info('      (empty slots)\n');
  }
}

function cmdAdd(type, filePath) {
  if (!fs.existsSync(filePath)) { error(`File not found: ${filePath}`); process.exit(1); }
  const config = syncProject(loadConfig());
  const comp = loadMdFile(filePath, type);
  const targetDir = path.join(process.cwd(), DIRS[type]);
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
  fs.copyFileSync(filePath, path.join(targetDir, comp.fileName));
  const arr = type === 'persona' ? config.personas : type === 'thinking' ? config.thinkingModels : config.dialoguePatterns;
  const idx = arr.findIndex(c => c.id === comp.id);
  if (idx >= 0) { arr[idx] = comp; warn(`Updated ${type}: ${comp.fileName}`); }
  else { arr.push(comp); success(`Added ${type}: ${comp.fileName}`); }
  saveConfig(config);
  info(`Saved to: ${path.join(targetDir, comp.fileName)}\n`);
}

function cmdRemove(type, query) {
  const config = syncProject(loadConfig());
  const arr = type === 'persona' ? config.personas : type === 'thinking' ? config.thinkingModels : config.dialoguePatterns;
  const idx = arr.findIndex(c => c.id === query || c.name === query || c.fileName === query);
  if (idx < 0) { error(`${type} "${query}" not found`); process.exit(1); }
  const removed = arr.splice(idx, 1)[0];
  const slotKey = type === 'persona' ? 'persona' : type === 'thinking' ? 'thinking' : 'dialogue';
  config.patterns = config.patterns.map(p => p.slots[slotKey] === removed.id ? { ...p, slots: { ...p.slots, [slotKey]: null } } : p);
  saveConfig(config);
  success(`Removed ${type}: ${removed.fileName}\n`);
}

function cmdCreate(name, opts) {
  const config = syncProject(loadConfig());
  const { pattern, errors } = createPattern(config, name, opts);
  if (errors.length > 0) errors.forEach(e => warn(e));
  if (!pattern) process.exit(1);
  config.patterns.push(pattern);
  saveConfig(config);
  success(`Created pattern: ${pattern.label}`);
  if (pattern.inheritsFrom) info(`Inherits from: ${pattern.inheritsFrom}`);
  const comps = getResolvedComponents(config, resolvePattern(config, pattern));
  if (comps.persona) log(`${C.blue}  Persona: ${comps.persona.name}${C.reset}`);
  if (comps.thinking) log(`${C.magenta}  Thinking: ${comps.thinking.name}${C.reset}`);
  if (comps.dialogue) log(`${C.green}  Dialogue: ${comps.dialogue.name}${C.reset}`);
  log();
}

function cmdDelete(name) {
  const config = syncProject(loadConfig());
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const idx = config.patterns.findIndex(p => p.id === id || p.name === name || p.label === name);
  if (idx < 0) { error(`Pattern "${name}" not found`); process.exit(1); }
  const removed = config.patterns.splice(idx, 1)[0];
  config.patterns = config.patterns.map(p => p.inheritsFrom === removed.id ? { ...p, inheritsFrom: null } : p);
  saveConfig(config);
  success(`Deleted pattern: ${removed.label}\n`);
}

function cmdShow(name, exportPath) {
  const config = syncProject(loadConfig());
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(p => p.id === id || p.name === name || p.label === name);
  if (!pattern) { error(`Pattern "${name}" not found`); process.exit(1); }
  if (exportPath) {
    fs.writeFileSync(path.resolve(exportPath), exportMarkdown(config, pattern), 'utf-8');
    success(`Exported to: ${path.resolve(exportPath)}\n`); return;
  }
  const resolved = resolvePattern(config, pattern);
  const comps = getResolvedComponents(config, resolved);
  log(bold('\n  ============================================\n'));
  if (pattern.inheritsFrom) {
    const parent = config.patterns.find(p => p.id === pattern.inheritsFrom);
    log(`  ${C.cyan}${pattern.label} ${C.yellow}(inherits from ${parent?.label || pattern.inheritsFrom})${C.reset}\n`);
  } else log(`  ${C.cyan}${pattern.label}\n${C.reset}`);
  if (comps.persona) { log(`${C.brightBlue}  [PERSONA]${C.reset}`); log(`  ${comps.persona.name}`); info(`  ${comps.persona.description}\n`); }
  if (comps.thinking) { log(`${C.brightMagenta}  [THINKING MODEL]${C.reset}`); log(`  ${comps.thinking.name}`); info(`  ${comps.thinking.description}\n`); }
  if (comps.dialogue) { log(`${C.brightGreen}  [DIALOGUE PATTERN]${C.reset}`); log(`  ${comps.dialogue.name}`); info(`  ${comps.dialogue.description}\n`); }
  log(bold('  ============================================\n'));
}

function cmdUse(name) {
  const config = syncProject(loadConfig());
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(p => p.id === id || p.name === name || p.label === name);
  if (!pattern) { error(`Pattern "${name}" not found`); process.exit(1); }
  log(exportMarkdown(config, pattern));
}

function cmdSetSlot(patternName, slotType, compId) {
  const config = syncProject(loadConfig());
  const pattern = config.patterns.find(p => p.id === generatePatternId(patternName) || p.name === patternName || p.label === patternName);
  if (!pattern) { error(`Pattern "${patternName}" not found`); process.exit(1); }
  const comp = findComponent(config, compId, slotType);
  if (!comp) { error(`${slotType} "${compId}" not found`); process.exit(1); }
  pattern.slots[slotType] = comp.id;
  saveConfig(config);
  const color = slotType === 'persona' ? C.blue : slotType === 'thinking' ? C.magenta : C.green;
  log(`${color}  Set ${slotType} of ${pattern.label} to ${comp.name}${C.reset}\n`);
}

function cmdClearSlot(patternName, slotType) {
  const config = syncProject(loadConfig());
  const pattern = config.patterns.find(p => p.id === generatePatternId(patternName) || p.name === patternName || p.label === patternName);
  if (!pattern) { error(`Pattern "${patternName}" not found`); process.exit(1); }
  pattern.slots[slotType] = null;
  saveConfig(config);
  warn(`Cleared ${slotType} from ${pattern.label}\n`);
}

function cmdInstallOpenCode() {
  const config = syncProject(loadConfig());
  const spin = spinner('Installing OpenCode modes...').start();
  const { installed, errors } = installOpenCodeModes(config);
  spin.succeed('Installation complete');
  if (installed.length > 0) { success(`Installed ${installed.length} mode(s):`); installed.forEach(i => log(`  ${C.cyan}•${C.reset} ${i}`)); }
  if (errors.length > 0) { errors.forEach(e => error(e)); }
  log(`${C.yellow}  → Restart OpenCode and press Tab to switch between your custom modes!${C.reset}\n`);
}

function cmdExportJson(file) {
  const config = syncProject(loadConfig());
  const outPath = file || 'opencode.json';
  writeOpenCodeJson(config, path.resolve(outPath));
  success(`Exported OpenCode config to: ${path.resolve(outPath)}\n`);
}

function cmdExportMode(name, targetDir) {
  const config = syncProject(loadConfig());
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const pattern = config.patterns.find(p => p.id === id || p.name === name || p.label === name);
  if (!pattern) { error(`Pattern "${name}" not found`); process.exit(1); }
  const dir = targetDir || path.join(os.homedir(), '.config', 'opencode', 'modes');
  const filePath = exportPatternMdFile(config, pattern, dir);
  success(`Exported mode: ${pattern.label}`);
  info(`File: ${filePath}`);
  log(`${C.gray}  Press Tab in OpenCode to switch to this mode${C.reset}\n`);
}

// Interactive Wizard
async function interactiveWizard() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const config = syncProject(loadConfig());

  while (true) {
    header('  Pattern Orchestrator - Wizard  ');
    log(`  ${C.cyan}1.${C.reset} Create a new pattern${C.gray} (interactive)${C.reset}`);
    log(`  ${C.blue}2.${C.reset} List all patterns & components`);
    log(`  ${C.magenta}3.${C.reset} Show pattern details`);
    log(`  ${C.yellow}4.${C.reset} Edit pattern slots`);
    log(`  ${C.red}5.${C.reset} Remove a pattern`);
    log(`  ${C.green}6.${C.reset} Install to OpenCode${C.gray} (Tab-switchable modes)${C.reset}`);
    log(`  ${C.gray}0.${C.reset} Exit\n`);

    const choice = await ask(rl, `  ${C.gray}Select option [0-6]:${C.reset} `);
    log();

    if (choice === '0') { log(`${C.gray}  Goodbye!${C.reset}\n`); rl.close(); return; }
    else if (choice === '1') await interactiveCreate(rl, config);
    else if (choice === '2') interactiveList(config);
    else if (choice === '3') await interactiveShow(rl, config);
    else if (choice === '4') await interactiveEdit(rl, config);
    else if (choice === '5') await interactiveRemove(rl, config);
    else if (choice === '6') { cmdInstallOpenCode(); }
    else { warn('Invalid option\n'); }
  }
}

async function interactiveCreate(rl, config) {
  log(`${C.cyan}--- Create New Pattern ---${C.reset}\n`);
  const name = await ask(rl, `  ${C.gray}Pattern name (e.g. CodeReview):${C.reset} `);
  if (!name.trim()) { warn('Cancelled\n'); return; }
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  if (config.patterns.some(p => p.id === id)) { error(`Pattern "${name}" already exists\n`); return; }

  let inherit = '';
  if (config.patterns.length > 0) {
    log(`\n  ${C.gray}Inherit from existing pattern?${C.reset}`);
    const choices = [{ name: `${C.gray}None (create from scratch)${C.reset}`, value: '' },
      ...config.patterns.map(p => ({ name: `${p.label} ${C.gray}(${p.slots.persona || '-'}|${p.slots.thinking || '-'}|${p.slots.dialogue || '-'})${C.reset}`, value: p.id }))];
    for (let i = 0; i < choices.length; i++) log(`  ${C.cyan}${i + 1}.${C.reset} ${choices[i].name}`);
    const ans = await ask(rl, `  ${C.gray}Select [1-${choices.length}]:${C.reset} `);
    const idx = parseInt(ans) - 1;
    if (idx > 0 && idx < choices.length) inherit = choices[idx].value;
  }

  const options = { inherit: inherit || undefined };
  if (config.personas.length > 0) {
    log(`\n  ${C.gray}Select Persona:${C.reset}`);
    for (let i = 0; i < config.personas.length; i++) log(`  ${C.blue}${i + 1}.${C.reset} ${config.personas[i].name}`);
    const ans = await ask(rl, `  ${C.gray}Select [1-${config.personas.length} or 0=none]:${C.reset} `);
    const idx = parseInt(ans) - 1;
    if (idx >= 0) options.persona = config.personas[idx]?.id;
  }
  if (config.thinkingModels.length > 0) {
    log(`\n  ${C.gray}Select Thinking Model:${C.reset}`);
    for (let i = 0; i < config.thinkingModels.length; i++) log(`  ${C.magenta}${i + 1}.${C.reset} ${config.thinkingModels[i].name}`);
    const ans = await ask(rl, `  ${C.gray}Select [1-${config.thinkingModels.length} or 0=none]:${C.reset} `);
    const idx = parseInt(ans) - 1;
    if (idx >= 0) options.thinking = config.thinkingModels[idx]?.id;
  }
  if (config.dialoguePatterns.length > 0) {
    log(`\n  ${C.gray}Select Dialogue Pattern:${C.reset}`);
    for (let i = 0; i < config.dialoguePatterns.length; i++) log(`  ${C.green}${i + 1}.${C.reset} ${config.dialoguePatterns[i].name}`);
    const ans = await ask(rl, `  ${C.gray}Select [1-${config.dialoguePatterns.length} or 0=none]:${C.reset} `);
    const idx = parseInt(ans) - 1;
    if (idx >= 0) options.dialogue = config.dialoguePatterns[idx]?.id;
  }

  const { pattern, errors } = createPattern(config, name, options);
  if (errors.length > 0) errors.forEach(e => warn(e));
  if (pattern) {
    config.patterns.push(pattern);
    saveConfig(config);
    success(`Created pattern: ${pattern.label}\n`);
  }
}

function interactiveList(config) {
  log(bold('\n  === Components ===\n'));
  log(`${C.brightBlue}Personas (${config.personas.length}):${C.reset}`); config.personas.forEach(p => log(`    • ${p.name}`));
  log(`${C.brightMagenta}Thinking Models (${config.thinkingModels.length}):${C.reset}`); config.thinkingModels.forEach(t => log(`    • ${t.name}`));
  log(`${C.brightGreen}Dialogue Patterns (${config.dialoguePatterns.length}):${C.reset}`); config.dialoguePatterns.forEach(d => log(`    • ${d.name}`));
  log(`${C.brightCyan}Patterns (${config.patterns.length}):${C.reset}`);
  for (const p of config.patterns) {
    const resolved = resolvePattern(config, p);
    log(`\n  ${bold(p.label)}${p.inheritsFrom ? C.yellow + ' <- ' + p.inheritsFrom + C.reset : ''}`);
    if (resolved.slots.persona) { const c = findComponent(config, resolved.slots.persona, 'persona'); log(`    ${C.blue}persona:${C.reset} ${c?.name}`); }
    if (resolved.slots.thinking) { const c = findComponent(config, resolved.slots.thinking, 'thinking'); log(`    ${C.magenta}thinking:${C.reset} ${c?.name}`); }
    if (resolved.slots.dialogue) { const c = findComponent(config, resolved.slots.dialogue, 'dialogue'); log(`    ${C.green}dialogue:${C.reset} ${c?.name}`); }
  }
  log();
}

async function interactiveShow(rl, config) {
  if (config.patterns.length === 0) { warn('No patterns found\n'); return; }
  log('  Select pattern:');
  for (let i = 0; i < config.patterns.length; i++) log(`  ${C.cyan}${i + 1}.${C.reset} ${config.patterns[i].label}`);
  const ans = await ask(rl, `  ${C.gray}Select [1-${config.patterns.length}]:${C.reset} `);
  const idx = parseInt(ans) - 1;
  if (idx < 0 || idx >= config.patterns.length) return;
  const pattern = config.patterns[idx];
  const output = exportMarkdown(config, pattern);
  log(bold('\n  --- Preview (first 30 lines) ---\n'));
  log(output.split('\n').slice(0, 30).join('\n'));
  log(C.gray('\n  ... (truncated)\n'));
}

async function interactiveEdit(rl, config) {
  if (config.patterns.length === 0) { warn('No patterns found\n'); return; }
  log('  Select pattern:');
  for (let i = 0; i < config.patterns.length; i++) log(`  ${C.cyan}${i + 1}.${C.reset} ${config.patterns[i].label}`);
  const ans = await ask(rl, `  ${C.gray}Select [1-${config.patterns.length}]:${C.reset} `);
  const pIdx = parseInt(ans) - 1;
  if (pIdx < 0 || pIdx >= config.patterns.length) return;
  const pattern = config.patterns[pIdx];

  log(`\n  Edit slot of ${pattern.label}:`);
  log(`  ${C.blue}1.${C.reset} Persona ${C.gray}(current: ${pattern.slots.persona || 'none'})${C.reset}`);
  log(`  ${C.magenta}2.${C.reset} Thinking ${C.gray}(current: ${pattern.slots.thinking || 'none'})${C.reset}`);
  log(`  ${C.green}3.${C.reset} Dialogue ${C.gray}(current: ${pattern.slots.dialogue || 'none'})${C.reset}`);
  const slotAns = await ask(rl, `  ${C.gray}Select slot [1-3]:${C.reset} `);
  const slotMap = ['persona', 'thinking', 'dialogue'];
  const slotType = slotMap[parseInt(slotAns) - 1];
  if (!slotType) return;

  const arr = slotType === 'persona' ? config.personas : slotType === 'thinking' ? config.thinkingModels : config.dialoguePatterns;
  log(`\n  Select new ${slotType}:`);
  log(`  ${C.gray}0.${C.reset} (none / clear)`);
  for (let i = 0; i < arr.length; i++) log(`  ${C.cyan}${i + 1}.${C.reset} ${arr[i].name}`);
  const compAns = await ask(rl, `  ${C.gray}Select [0-${arr.length}]:${C.reset} `);
  const cIdx = parseInt(compAns) - 1;
  if (cIdx === -1) { pattern.slots[slotType] = null; warn(`Cleared ${slotType}`); }
  else if (cIdx >= 0 && cIdx < arr.length) { pattern.slots[slotType] = arr[cIdx].id; success(`Set ${slotType} to ${arr[cIdx].name}`); }
  saveConfig(config);
  log();
}

async function interactiveRemove(rl, config) {
  if (config.patterns.length === 0) { warn('No patterns to remove\n'); return; }
  log('  Select patterns to remove (comma-separated, e.g. 1,3):');
  for (let i = 0; i < config.patterns.length; i++) {
    const childCount = config.patterns.filter(c => c.inheritsFrom === config.patterns[i].id).length;
    const warning = childCount > 0 ? `${C.red} [${childCount} children]${C.reset}` : '';
    log(`  ${C.red}${i + 1}.${C.reset} ${config.patterns[i].label}${warning}`);
  }
  const ans = await ask(rl, `  ${C.gray}Select [1-${config.patterns.length}]:${C.reset} `);
  const indices = ans.split(',').map(s => parseInt(s.trim()) - 1).filter(i => i >= 0 && i < config.patterns.length);
  if (indices.length === 0) { warn('None selected\n'); return; }

  const hasChildren = indices.some(i => config.patterns.some(p => p.inheritsFrom === config.patterns[i].id));
  if (hasChildren) {
    const ok = await askConfirm(rl, 'Some patterns have children. Continue?');
    if (!ok) { warn('Cancelled\n'); return; }
  }
  const ok = await askConfirm(rl, `Remove ${indices.length} pattern(s)?`);
  if (!ok) { warn('Cancelled\n'); return; }

  const removedIds = [];
  for (const i of indices.sort((a, b) => b - a)) { removedIds.push(config.patterns[i].id); config.patterns.splice(i, 1); }
  config.patterns = config.patterns.map(p => removedIds.includes(p.inheritsFrom) ? { ...p, inheritsFrom: null } : p);
  saveConfig(config);
  success(`Removed ${removedIds.length} pattern(s)\n`);
}

// Help text
function printHelp() {
  log(`${C.bold}${C.cyan}\n  Pattern Orchestrator v2.0 - Zero Dependencies\n${C.reset}`);
  log('  ' + C.gray + 'A CLI tool for managing Personas, Thinking Models, and Dialogue Patterns\n' + C.reset);
  log(bold('  Commands:\n'));
  const cmds = [
    ['wizard, w', 'Interactive wizard (step-by-step)'],
    ['sync', 'Scan project dirs and sync to config'],
    ['list [all|personas|thinking|dialogue|patterns]', 'List components'],
    ['add-persona <file>', 'Add persona from .md file'],
    ['add-thinking <file>', 'Add thinking model from .md'],
    ['add-dialogue <file>', 'Add dialogue pattern from .md'],
    ['remove-persona <name>', 'Remove a persona'],
    ['create-pattern <name>', 'Create pattern (--inherit, --persona, --thinking, --dialogue)'],
    ['delete-pattern <name>', 'Delete a pattern'],
    ['show <pattern> [-e <file>]', 'Show pattern details'],
    ['use <pattern>', 'Output merged config (for piping)'],
    ['set-persona <pattern> <comp>', 'Set persona slot'],
    ['set-thinking <pattern> <comp>', 'Set thinking slot'],
    ['set-dialogue <pattern> <comp>', 'Set dialogue slot'],
    ['clear-persona <pattern>', 'Clear persona slot'],
    ['install-opencode', 'Install as OpenCode Tab-switchable modes'],
    ['export-opencode-json [file]', 'Export opencode.json'],
    ['export-opencode-mode <pattern> [dir]', 'Export single mode .md file'],
  ];
  for (const [cmd, desc] of cmds) {
    log(`    ${C.cyan}${cmd.padEnd(30)}${C.reset} ${C.gray}${desc}${C.reset}`);
  }
  log(bold('\n  Examples:\n'));
  log(`    ${C.gray}$${C.reset} opencode-patterns wizard`);
  log(`    ${C.gray}$${C.reset} opencode-patterns sync`);
  log(`    ${C.gray}$${C.reset} opencode-patterns create-pattern Plan -p java-engineer -t ooda-loop -d socratic`);
  log(`    ${C.gray}$${C.reset} opencode-patterns create-pattern NewPlan --inherit Plan -p python-expert`);
  log(`    ${C.gray}$${C.reset} opencode-patterns install-opencode`);
  log(`    ${C.gray}$${C.reset} opencode-patterns use Plan | opencode\n`);
}

// Main router
function main() {
  const { command, positional, options } = parseArgs(process.argv);
  const config = syncProject(loadConfig());

  switch (command) {
    case 'wizard':
    case 'w':
      interactiveWizard(); break;
    case 'sync':
      cmdSync(); break;
    case 'list':
    case 'ls':
      cmdList(positional[0] || 'all'); break;
    case 'add-persona':
      cmdAdd('persona', positional[0]); break;
    case 'add-thinking':
      cmdAdd('thinking', positional[0]); break;
    case 'add-dialogue':
      cmdAdd('dialogue', positional[0]); break;
    case 'remove-persona':
      cmdRemove('persona', positional[0]); break;
    case 'remove-thinking':
      cmdRemove('thinking', positional[0]); break;
    case 'remove-dialogue':
      cmdRemove('dialogue', positional[0]); break;
    case 'create-pattern':
      cmdCreate(positional[0], options); break;
    case 'delete-pattern':
      cmdDelete(positional[0]); break;
    case 'show':
      cmdShow(positional[0], options.export); break;
    case 'use':
      cmdUse(positional[0]); break;
    case 'set-persona':
      cmdSetSlot(positional[0], 'persona', positional[1]); break;
    case 'set-thinking':
      cmdSetSlot(positional[0], 'thinking', positional[1]); break;
    case 'set-dialogue':
      cmdSetSlot(positional[0], 'dialogue', positional[1]); break;
    case 'clear-persona':
      cmdClearSlot(positional[0], 'persona'); break;
    case 'clear-thinking':
      cmdClearSlot(positional[0], 'thinking'); break;
    case 'clear-dialogue':
      cmdClearSlot(positional[0], 'dialogue'); break;
    case 'install-opencode':
      cmdInstallOpenCode(); break;
    case 'export-opencode-json':
      cmdExportJson(positional[0]); break;
    case 'export-opencode-mode':
      cmdExportMode(positional[0], positional[1]); break;
    case '--help':
    case '-h':
    case 'help':
    case undefined:
    default:
      printHelp();
      break;
  }
}

main();
