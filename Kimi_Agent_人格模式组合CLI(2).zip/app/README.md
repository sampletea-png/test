# 模式编排器 (Pattern Orchestrator) v2.0

纯原生实现，零 npm 依赖，内网可用。管理人格(Persona)、思维模型(Thinking Model)和对话模式(Dialogue Pattern)的组合，导出为 OpenCode 可通过 Tab 切换的模式。

## 特点

- **零第三方依赖**: 纯 Node.js 内置模块，无需 npm install
- **双端支持**: CLI 命令行 + Web 前端（单 HTML 文件）
- **交互式向导**: 逐步选择创建和移除模式
- **OpenCode 集成**: `install-opencode` 导出为 Tab 可切换模式
- **内网可用**: 不需要网络连接，复制到任意目录即可使用

## 文件结构

```
./
├── cli.js                    # CLI 入口（纯 Node.js，零依赖）
├── core.js                   # 核心逻辑（模式管理、OpenCode 导出）
├── web/
│   └── index.html            # Web 前端（单文件，零依赖）
├── personas/                 # 人格 .md 文件
│   ├── java_engineer.md
│   ├── python_expert.md
│   ├── frontend_architect.md
│   ├── rust_systems_engineer.md
│   ├── devops_engineer.md
│   ├── test_persona_alpha.md      # 测试文件
│   └── test_persona_beta.md       # 测试文件
├── thinking-models/          # 思维模型 .md 文件
│   ├── OODA_loop.md
│   ├── first_principles.md
│   ├── systems_thinking.md
│   ├── inversion_thinking.md
│   ├── test_thinking_gamma.md     # 测试文件
│   └── test_thinking_delta.md     # 测试文件
├── dialogue-patterns/        # 对话模式 .md 文件
│   ├── socratic_dialogue.md
│   ├── direct_answer.md
│   ├── exploration_mode.md
│   ├── mentor_mode.md
│   ├── test_dialogue_epsilon.md   # 测试文件
│   └── test_dialogue_zeta.md      # 测试文件
└── patterns/                 # 导出模式存放目录
```

## 快速开始

不需要 npm install，只需要 Node.js（v14+）：

```bash
cd /mnt/agents/output/app/v2

# 1. 同步项目目录中的 .md 文件
node cli.js sync

# 2. 创建模式
node cli.js create-pattern Plan --persona java-engineer --thinking ooda-loop --dialogue socratic
node cli.js create-pattern Build --inherit Plan --persona python-expert --dialogue direct-answer

# 3. 安装到 OpenCode（Tab 切换）
node cli.js install-opencode
# 重启 OpenCode，按 Tab 键在 [Plan] [Build] 间切换
```

## CLI 命令

### 交互式向导（一步步选择）

```bash
node cli.js wizard
```
菜单选项：
1. Create a new pattern — 交互式创建（选择继承、人格、思维、对话）
2. List all patterns & components — 列出所有
3. Show pattern details — 查看模式详情
4. Edit pattern slots — 编辑模式槽位
5. Remove a pattern — 移除模式
6. Install to OpenCode — 安装为 Tab 可切换模式

### 常用命令

```bash
# 同步项目目录
node cli.js sync

# 创建模式
node cli.js create-pattern Plan --persona java-engineer --thinking ooda-loop --dialogue socratic

# 创建继承模式
node cli.js create-pattern NewPlan --inherit Plan --persona python-expert

# 列出
node cli.js list
node cli.js list patterns

# 查看详情
node cli.js show Plan

# 导出使用
node cli.js use Plan

# 导出为 OpenCode 模式文件
node cli.js export-opencode-mode Plan /tmp/modes/

# 批量安装到 OpenCode
node cli.js install-opencode

# 移除
node cli.js delete-pattern Build

# 帮助
node cli.js --help
```

### Web 前端

直接用浏览器打开，不需要任何服务器：

```bash
# 方式1: 直接打开
open web/index.html

# 方式2: 用任意静态服务器
python3 -m http.server 8080 -d web
# 访问 http://localhost:8080
```

功能：
- 可视化组件库（侧边栏点击填充）
- 模式 Tab 切换
- 创建新模式（支持继承）
- 导出 .md / OpenCode / .json

## OpenCode Tab 切换原理

1. `node cli.js install-opencode` 将每个模式导出为 `~/.config/opencode/modes/{id}.md`
2. 每个 .md 文件包含 OpenCode 标准 frontmatter（temperature, tools）
3. 重启 OpenCode 后，按 **Tab** 键即可在所有模式间切换
4. 模式格式与内置的 [Plan] [Build] 完全一致

### 导出文件格式示例

```markdown
---
temperature: 0.2
tools:
  write: true
  edit: true
  bash: true
  read: true
  grep: true
  glob: true
---

# Java 工程师
## 角色定位
...

---

## Thinking Framework
# OODA 循环
...

---

## Dialogue Guidelines
# 苏格拉底对话
...
```

## 生产级组件（13个）

### 人格 (5个)
- **java_engineer.md** — 15年Java企业级，Spring/微服务/性能
- **python_expert.md** — 全栈Python，数据科学/MLOps/Web
- **frontend_architect.md** — 前端架构师，React/Vue/性能工程
- **rust_systems_engineer.md** — Rust系统编程，底层/网络/存储
- **devops_engineer.md** — DevOps/平台工程，K8s/云原生

### 思维模型 (4个)
- **OODA_loop.md** — 观察-判断-决策-行动循环
- **first_principles.md** — 第一性原理，从零构建
- **systems_thinking.md** — 系统思维，反馈回路/杠杆点
- **inversion_thinking.md** — 逆向思维，预演/排除法

### 对话模式 (4个)
- **socratic_dialogue.md** — 苏格拉底追问
- **direct_answer.md** — 直接回答
- **exploration_mode.md** — 探索/发散模式
- **mentor_mode.md** — 导师/长期辅导

## 测试文件（6个）

用于验证配置正确性的测试组件：
- `test_persona_alpha.md` / `test_persona_beta.md`
- `test_thinking_gamma.md` / `test_thinking_delta.md`
- `test_dialogue_epsilon.md` / `test_dialogue_zeta.md`

每个测试文件包含唯一的校验标记，可以通过 `use` 命令输出验证内容是否正确合并。

## 完整工作流示例

```bash
cd /path/to/this/project

# 添加生产级组件
node cli.js add-persona ./personas/java_engineer.md
node cli.js add-thinking ./thinking-models/OODA_loop.md
node cli.js add-dialogue ./dialogue-patterns/socratic_dialogue.md

# 创建 [Plan] 模式
node cli.js create-pattern Plan --persona java-engineer --thinking ooda-loop --dialogue socratic

# 创建 [Build] 继承 Plan，只改人格和对话
node cli.js create-pattern Build --inherit Plan --persona python-expert --dialogue direct-answer

# 查看
node cli.js show Build

# 安装到 OpenCode
node cli.js install-opencode
# → 重启 OpenCode，按 Tab 切换 [Plan] / [Build]
```

## 无 Node.js？用 Web 版

如果环境没有 Node.js，可以直接用浏览器版的 Web 前端：

1. 复制整个项目目录到任意位置
2. 用浏览器打开 `web/index.html`
3. 在 Web 界面中组合模式
4. 点击 "OpenCode" 按钮导出 .md 模式文件
5. 将导出的 .md 文件复制到 `~/.config/opencode/modes/`
