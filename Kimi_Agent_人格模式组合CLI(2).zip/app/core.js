// ============================================================================
// Pattern Orchestrator Core - Pure Node.js (Zero Dependencies)
// ============================================================================

const fs = require('fs');
const path = require('path');
const os = require('os');

// ANSI color codes (replaces chalk)
const C = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
  brightRed: '\x1b[91m',
  brightGreen: '\x1b[92m',
  brightYellow: '\x1b[93m',
  brightBlue: '\x1b[94m',
  brightMagenta: '\x1b[95m',
  brightCyan: '\x1b[96m',
  white: '\x1b[97m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
};

// Config paths
const CONFIG_DIR = path.join(os.homedir(), '.opencode-patterns');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

const DIRS = {
  persona: 'personas',
  thinking: 'thinking-models',
  dialogue: 'dialogue-patterns',
};

function ensureDirs() {
  for (const d of [DIRS.persona, DIRS.thinking, DIRS.dialogue, 'patterns']) {
    const fullPath = path.join(process.cwd(), d);
    if (!fs.existsSync(fullPath)) fs.mkdirSync(fullPath, { recursive: true });
  }
  if (!fs.existsSync(CONFIG_DIR)) fs.mkdirSync(CONFIG_DIR, { recursive: true });
}

function loadConfig() {
  ensureDirs();
  if (fs.existsSync(CONFIG_FILE)) {
    try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8')); } catch { /* ignore */ }
  }
  return { version: '2.0.0', personas: [], thinkingModels: [], dialoguePatterns: [], patterns: [] };
}

function saveConfig(config) {
  ensureDirs();
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

function loadMdFile(filePath, type) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const fileName = path.basename(filePath);
  const name = fileName.replace(/\.md$/, '');
  const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const lines = content.split('\n').filter(l => l.trim());
  let description = '';
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('#') && trimmed.length > 0) {
      description = trimmed;
      break;
    }
  }
  if (!description && lines.length > 0) description = lines[0].replace(/^#+\s*/, '');
  return { id, name, fileName, description, content, type };
}

function scanDir(dirPath, type) {
  if (!fs.existsSync(dirPath)) return [];
  return fs.readdirSync(dirPath).filter(f => f.endsWith('.md')).map(f => loadMdFile(path.join(dirPath, f), type));
}

function syncProject(config) {
  for (const comp of scanDir(path.join(process.cwd(), DIRS.persona), 'persona')) {
    const idx = config.personas.findIndex(c => c.id === comp.id);
    if (idx >= 0) config.personas[idx] = comp; else config.personas.push(comp);
  }
  for (const comp of scanDir(path.join(process.cwd(), DIRS.thinking), 'thinking')) {
    const idx = config.thinkingModels.findIndex(c => c.id === comp.id);
    if (idx >= 0) config.thinkingModels[idx] = comp; else config.thinkingModels.push(comp);
  }
  for (const comp of scanDir(path.join(process.cwd(), DIRS.dialogue), 'dialogue')) {
    const idx = config.dialoguePatterns.findIndex(c => c.id === comp.id);
    if (idx >= 0) config.dialoguePatterns[idx] = comp; else config.dialoguePatterns.push(comp);
  }
  return config;
}

function findComponent(config, query, type) {
  const arr = type === 'persona' ? config.personas : type === 'thinking' ? config.thinkingModels : config.dialoguePatterns;
  const q = query.toLowerCase();
  let found = arr.find(c => c.id === q || c.name.toLowerCase() === q || c.fileName.toLowerCase() === q);
  if (found) return found;
  return arr.find(c => c.id.includes(q) || c.name.toLowerCase().includes(q) || c.fileName.toLowerCase().includes(q));
}

function resolvePattern(config, pattern) {
  if (!pattern || !pattern.inheritsFrom) return pattern || { slots: { persona: null, thinking: null, dialogue: null } };
  const parent = config.patterns.find(p => p.id === pattern.inheritsFrom);
  if (!parent) return pattern;
  const resolvedParent = resolvePattern(config, parent);
  return {
    ...pattern,
    slots: {
      persona: pattern.slots.persona ?? resolvedParent.slots.persona,
      thinking: pattern.slots.thinking ?? resolvedParent.slots.thinking,
      dialogue: pattern.slots.dialogue ?? resolvedParent.slots.dialogue,
    }
  };
}

function getResolvedComponents(config, pattern) {
  const resolved = resolvePattern(config, pattern);
  return {
    persona: resolved.slots.persona ? findComponent(config, resolved.slots.persona, 'persona') : null,
    thinking: resolved.slots.thinking ? findComponent(config, resolved.slots.thinking, 'thinking') : null,
    dialogue: resolved.slots.dialogue ? findComponent(config, resolved.slots.dialogue, 'dialogue') : null,
  };
}

function exportMarkdown(config, pattern) {
  const resolved = resolvePattern(config, pattern);
  const comps = getResolvedComponents(config, resolved);
  const parts = [`# Pattern: ${pattern.label}`];
  if (pattern.inheritsFrom) parts.push(`# Inherits from: ${pattern.inheritsFrom}`);
  parts.push('');
  if (comps.persona) { parts.push(`## Persona: ${comps.persona.name}`); parts.push(comps.persona.content); parts.push(''); }
  if (comps.thinking) { parts.push(`## Thinking Model: ${comps.thinking.name}`); parts.push(comps.thinking.content); parts.push(''); }
  if (comps.dialogue) { parts.push(`## Dialogue Pattern: ${comps.dialogue.name}`); parts.push(comps.dialogue.content); parts.push(''); }
  return parts.join('\n');
}

function generatePatternId(name) { return name.toLowerCase().replace(/[^a-z0-9]/g, '-'); }
function generateLabel(name) { return `[${name}]`; }

function createPattern(config, name, opts) {
  const errors = [];
  const id = generatePatternId(name);
  const label = generateLabel(name);
  if (config.patterns.some(p => p.id === id)) { errors.push(`Pattern "${label}" already exists`); return { pattern: null, errors }; }

  let slots = { persona: null, thinking: null, dialogue: null };
  let inheritsFrom = null;

  if (opts.inherit) {
    const parent = config.patterns.find(p => p.id === opts.inherit || p.name === opts.inherit || p.label === opts.inherit);
    if (parent) { slots = { ...resolvePattern(config, parent).slots }; inheritsFrom = parent.id; }
    else { errors.push(`Parent "${opts.inherit}" not found`); }
  }

  if (opts.persona) { const c = findComponent(config, opts.persona, 'persona'); if (c) slots.persona = c.id; else errors.push(`Persona not found`); }
  if (opts.thinking) { const c = findComponent(config, opts.thinking, 'thinking'); if (c) slots.thinking = c.id; else errors.push(`Thinking not found`); }
  if (opts.dialogue) { const c = findComponent(config, opts.dialogue, 'dialogue'); if (c) slots.dialogue = c.id; else errors.push(`Dialogue not found`); }

  return { pattern: { id, name, label, inheritsFrom, slots }, errors };
}

function exportAsOpenCodeMode(config, pattern) {
  const resolved = resolvePattern(config, pattern);
  const comps = getResolvedComponents(config, resolved);
  const bodyParts = [];
  if (comps.persona) bodyParts.push(comps.persona.content);
  if (comps.thinking) bodyParts.push(`## Thinking Framework\n\n${comps.thinking.content}`);
  if (comps.dialogue) bodyParts.push(`## Dialogue Guidelines\n\n${comps.dialogue.content}`);
  const tools = ['  write: true', '  edit: true', '  bash: true', '  read: true', '  grep: true', '  glob: true'].join('\n');
  const content = `---\ntemperature: 0.2\ntools:\n${tools}\n---\n\n${bodyParts.join('\n\n---\n\n')}\n`;
  return { name: pattern.id, content };
}

function installOpenCodeModes(config) {
  const installed = [], errors = [];
  const modesDir = path.join(os.homedir(), '.config', 'opencode', 'modes');
  if (!fs.existsSync(modesDir)) fs.mkdirSync(modesDir, { recursive: true });
  for (const pattern of config.patterns) {
    try {
      const mode = exportAsOpenCodeMode(config, pattern);
      const filePath = path.join(modesDir, `${mode.name}.md`);
      fs.writeFileSync(filePath, mode.content, 'utf-8');
      installed.push(`${pattern.label} -> ${filePath}`);
    } catch (err) { errors.push(`${pattern.label}: ${err.message}`); }
  }
  return { installed, errors };
}

function writeOpenCodeJson(config, targetPath) {
  const modes = {};
  for (const p of config.patterns) {
    const md = exportMarkdown(config, p);
    modes[p.id] = { temperature: 0.2, prompt: md, tools: { write: true, edit: true, bash: true, read: true, grep: true, glob: true } };
  }
  const json = JSON.stringify({ $schema: 'https://opencode.ai/config.json', mode: modes }, null, 2);
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(targetPath, json, 'utf-8');
}

function exportPatternMdFile(config, pattern, targetDir) {
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
  const mode = exportAsOpenCodeMode(config, pattern);
  const filePath = path.join(targetDir, `${mode.name}.md`);
  fs.writeFileSync(filePath, mode.content, 'utf-8');
  return filePath;
}

module.exports = {
  C,
  DIRS,
  getConfigPath: () => CONFIG_FILE,
  loadConfig,
  saveConfig,
  loadMdFile,
  scanDir,
  syncProject,
  findComponent,
  resolvePattern,
  getResolvedComponents,
  exportMarkdown,
  generatePatternId,
  generateLabel,
  createPattern,
  exportAsOpenCodeMode,
  installOpenCodeModes,
  writeOpenCodeJson,
  exportPatternMdFile,
};
