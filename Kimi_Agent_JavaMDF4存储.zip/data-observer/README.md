# DataObserver - 仿Simulink数据观察器

一个高性能的Java数据收集和存储系统，仿照Simulink Data Inspector设计，支持运行时动态添加/取消数据源，并发读写，以及MDF4（ASAM标准）格式存储。

## 特性

- **动态数据源管理**: 运行时添加或移除观察的数据源
- **并发读写**: 基于无锁环形缓冲区的高性能数据收集
- **MDF4格式支持**: 符合ASAM标准的二进制存储格式
- **大文件支持**: 支持GB级数据量，使用内存映射优化性能
- **可扩展存储**: 支持多种存储格式（可扩展）
- **高性能**: 批量写入、缓冲区优化、多线程处理

## 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                      DataObserver                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ DataSource  │  │ DataSource  │  │     DataSource      │  │
│  │   (源1)     │  │   (源2)     │  │       (源N)         │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         └────────────────┴────────────────────┘             │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │    RingBuffer          │                     │
│              │  (无锁环形缓冲区)        │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │   Writer Thread        │                     │
│              │   (批量写入)            │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
│              ┌───────────▼────────────┐                     │
│              │    DataStorage         │                     │
│              │  (MDF4/其他格式)        │                     │
│              └────────────────────────┘                     │
└─────────────────────────────────────────────────────────────┘
```

## 快速开始

### 1. 添加依赖

```xml
<dependency>
    <groupId>com.dataobserver</groupId>
    <artifactId>data-observer</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 2. 基本使用

```java
import com.dataobserver.core.*;
import com.dataobserver.storage.StorageFormat;
import java.nio.file.Paths;

public class Example {
    public static void main(String[] args) throws Exception {
        // 1. 创建观察器
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        // 2. 创建存储
        observer.createStorage(
            Paths.get("data.mf4"), 
            StorageFormat.MDF4
        );
        
        // 3. 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource(
            "source1", "Test Source", 100.0
        );
        source.addSineWaveChannel("sine", 10.0, 1.0, 0.0);
        source.addNoiseChannel("noise", 2.0, 0.0);
        
        // 4. 添加数据源
        observer.addDataSource(source);
        
        // 5. 开始记录
        observer.startRecording();
        
        // 6. 记录一段时间
        Thread.sleep(5000);
        
        // 7. 停止并关闭
        observer.stopRecording();
        observer.close();
    }
}
```

### 3. 动态数据源管理

```java
// 运行时添加数据源
SimulatedDataSource newSource = new SimulatedDataSource("new", "New Source", 50.0);
newSource.addRampChannel("ramp", 5.0, 0.0);
observer.addDataSource(newSource);

// 运行时移除数据源
observer.removeDataSource("source1");
```

## 核心组件

### DataObserver

主类，负责管理数据源、缓冲区和存储引擎。

```java
// 配置参数
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(100000)      // 环形缓冲区大小
    .setBatchSize(100)          // 批量写入大小
    .setWorkerThreads(2)        // 工作线程数
    .setDebugMode(true);        // 调试模式

DataObserver observer = new DataObserver(config);
```

### DataSource

数据源接口，定义数据源的基本操作。

```java
public interface DataSource {
    String getId();
    String getName();
    List<DataChannel> getChannels();
    void start();
    void stop();
    void setDataCallback(DataCallback callback);
    double getSampleRate();
}
```

### DataStorage

存储接口，支持多种存储格式。

```java
public interface DataStorage {
    void open(Path path, OpenMode mode);
    void writeRecord(DataRecord record);
    void registerChannel(DataChannel channel);
    void flush();
    void close();
}
```

### RingBuffer

无锁环形缓冲区，基于Disruptor设计思想。

```java
RingBuffer<DataRecord> buffer = new RingBuffer<>(
    100000,                    // 容量
    100,                       // 批处理大小
    RingBuffer.WaitStrategy.YIELDING
);
```

## MDF4格式

MDF4（Measurement Data Format version 4）是ASAM标准格式，用于存储测量数据。

### 文件结构

```
┌─────────────────────────────────────┐
│  ID Block (64 bytes)                │
│  - 文件标识、版本信息                 │
├─────────────────────────────────────┤
│  Header Block (HD)                  │
│  - 文件元数据、时间信息               │
├─────────────────────────────────────┤
│  Data Group Block (DG)              │
│  - 数据组描述                        │
├─────────────────────────────────────┤
│  Channel Group Block (CG)           │
│  - 通道组描述、记录大小               │
├─────────────────────────────────────┤
│  Channel Blocks (CN)                │
│  - 通道描述、数据类型、单位            │
├─────────────────────────────────────┤
│  Data Block (DT)                    │
│  - 实际数据记录                      │
└─────────────────────────────────────┘
```

### 支持的通道类型

- 数值类型: UINT8/16/32/64, INT8/16/32/64, FLOAT, DOUBLE
- 特殊类型: BOOLEAN, STRING, BYTE_ARRAY
- 时间通道: 主同步通道

## 性能优化

### 1. 批量写入

```java
// 内部自动批量写入，减少IO次数
observer.startRecording();  // 启用批量模式
```

### 2. 内存映射

```java
MDF4Storage storage = new MDF4Storage();
storage.setUseMemoryMapping(true);  // 启用内存映射
```

### 3. 采样率控制

```java
// 限制数据源采样率
observer.setSampleRate("source1", 50.0);  // 50Hz
```

### 4. 缓冲区调优

```java
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(1000000)    // 大缓冲区减少阻塞
    .setBatchSize(1000)        // 大批量提高吞吐量
    .setWorkerThreads(4);      // 多线程处理
```

## 扩展存储格式

实现自定义存储格式：

```java
public class CustomStorage implements DataStorage {
    @Override
    public void open(Path path, OpenMode mode) { ... }
    
    @Override
    public void writeRecord(DataRecord record) { ... }
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.CUSTOM;
    }
    // ...
}

// 注册到工厂
StorageFactory.registerProvider(
    StorageFormat.CUSTOM, 
    CustomStorage::new
);
```

## 测试

```bash
# 运行测试
mvn test

# 打包
mvn package

# 运行示例
java -jar target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar
```

## 系统要求

- Java 11+
- Maven 3.6+

## 许可证

MIT License

## 参考

- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/)
- [MDF4-Lib](http://www.turbolab.de/mdf_libf.htm)
- [Simulink Data Inspector](https://www.mathworks.com/help/simulink/ug/sdi.html)
