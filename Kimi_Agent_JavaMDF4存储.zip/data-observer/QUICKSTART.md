# DataObserver 快速开始指南

## 项目结构

```
data-observer/
├── pom.xml                          # Maven构建配置
├── README.md                        # 项目说明
├── ARCHITECTURE.md                  # 架构设计文档
├── QUICKSTART.md                    # 本文件
├── build.sh                         # 构建脚本
├── src/
│   ├── main/java/com/dataobserver/
│   │   ├── core/                    # 核心接口和类
│   │   │   ├── DataType.java        # 数据类型枚举
│   │   │   ├── DataRecord.java      # 数据记录
│   │   │   ├── DataChannel.java     # 数据通道接口
│   │   │   ├── DataSource.java      # 数据源接口
│   │   │   ├── DataObserver.java    # 主类
│   │   │   └── SimulatedDataSource.java  # 模拟数据源
│   │   ├── storage/                 # 存储接口
│   │   │   ├── DataStorage.java     # 存储接口
│   │   │   ├── StorageFormat.java   # 存储格式枚举
│   │   │   ├── StorageMetadata.java # 存储元数据
│   │   │   └── StorageFactory.java  # 存储工厂
│   │   ├── mdf4/                    # MDF4实现
│   │   │   ├── MDF4BlockType.java   # 块类型
│   │   │   ├── MDF4Block.java       # 块基类
│   │   │   ├── MDF4IDBlock.java     # ID块
│   │   │   ├── MDF4HeaderBlock.java # 头部块
│   │   │   ├── MDF4TextBlock.java   # 文本块
│   │   │   ├── MDF4ChannelBlock.java    # 通道块
│   │   │   ├── MDF4ChannelGroupBlock.java   # 通道组块
│   │   │   ├── MDF4DataGroupBlock.java      # 数据组块
│   │   │   ├── MDF4DataBlock.java       # 数据块
│   │   │   └── MDF4Storage.java         # MDF4存储实现
│   │   ├── buffer/                  # 缓冲区
│   │   │   └── RingBuffer.java      # 无锁环形缓冲区
│   │   ├── util/                    # 工具类
│   │   │   └── MemoryMappedBuffer.java  # 内存映射缓冲区
│   │   └── example/                 # 示例
│   │       └── DataObserverExample.java # 使用示例
│   └── test/java/com/dataobserver/  # 测试
│       ├── RingBufferTest.java      # RingBuffer测试
│       └── MDF4StorageTest.java     # MDF4存储测试
```

## 环境要求

- Java 11 或更高版本
- Maven 3.6 或更高版本

## 构建项目

### 方式1: 使用Maven

```bash
# 编译
cd data-observer
mvn compile

# 运行测试
mvn test

# 打包
mvn package

# 运行示例
java -jar target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar
```

### 方式2: 使用构建脚本

```bash
cd data-observer
chmod +x build.sh
./build.sh
```

## 快速使用示例

### 1. 基本数据收集

```java
import com.dataobserver.core.*;
import com.dataobserver.storage.StorageFormat;
import java.nio.file.Paths;

public class QuickStart {
    public static void main(String[] args) throws Exception {
        // 创建观察器
        DataObserver observer = new DataObserver();
        observer.initialize();
        
        // 创建MDF4存储
        observer.createStorage(
            Paths.get("output.mf4"), 
            StorageFormat.MDF4
        );
        
        // 创建模拟数据源
        SimulatedDataSource source = new SimulatedDataSource(
            "sensor", "Temperature Sensor", 100.0
        );
        source.addSineWaveChannel("temperature", 50.0, 1.0, 25.0);
        
        // 添加数据源
        observer.addDataSource(source);
        
        // 开始记录
        observer.startRecording();
        
        // 记录5秒
        Thread.sleep(5000);
        
        // 停止
        observer.stopRecording();
        observer.close();
        
        System.out.println("Data saved to output.mf4");
    }
}
```

### 2. 动态数据源管理

```java
// 运行时添加数据源
SimulatedDataSource newSource = new SimulatedDataSource("new", "New Source", 50.0);
newSource.addRampChannel("value", 10.0, 0.0);
observer.addDataSource(newSource);

// 运行时移除数据源
observer.removeDataSource("sensor");
```

### 3. 配置参数

```java
DataObserver.Config config = new DataObserver.Config()
    .setBufferSize(100000)      // 环形缓冲区大小
    .setBatchSize(100)          // 批量写入大小
    .setWorkerThreads(2)        // 工作线程数
    .setProject("MyProject")    // 项目名称
    .setSubject("Test")         // 测试主题
    .setDebugMode(true);        // 调试模式

DataObserver observer = new DataObserver(config);
```

### 4. 监控统计

```java
// 获取统计信息
DataObserver.Statistics stats = observer.getStatistics();
System.out.println("Records: " + stats.getTotalRecords());
System.out.println("Buffer: " + stats.getBufferSize() + "/" + stats.getBufferCapacity());
System.out.println("File size: " + stats.getFileSize() + " bytes");
```

## 核心特性

### 1. 并发读写

```java
// 无锁环形缓冲区，支持高并发
RingBuffer<DataRecord> buffer = new RingBuffer<>(100000);

// 多线程安全写入
buffer.offer(record);

// 批量读取
DataRecord[] batch = new DataRecord[100];
int count = buffer.pollBatch(batch);
```

### 2. MDF4格式存储

```java
// 创建MDF4存储
MDF4Storage storage = new MDF4Storage();
storage.open(Paths.get("data.mf4"), DataStorage.OpenMode.CREATE);

// 注册通道
storage.registerChannel(channel);

// 写入数据
storage.writeRecord(record);

// 刷新到磁盘
storage.flush();
```

### 3. 内存映射（大文件支持）

```java
MDF4Storage storage = new MDF4Storage();
storage.setUseMemoryMapping(true);  // 启用内存映射
storage.open(path, mode);
```

## 测试

```bash
# 运行所有测试
mvn test

# 运行特定测试
mvn test -Dtest=RingBufferTest
mvn test -Dtest=MDF4StorageTest
```

## 常见问题

### Q: 支持多大的数据量？
A: 支持GB级数据量。使用内存映射和分块处理，理论上只受磁盘空间限制。

### Q: 最大支持多少数据源？
A: 取决于系统资源，通常可支持100+个并发数据源。

### Q: 如何保证数据不丢失？
A: 
1. 使用足够大的缓冲区
2. 定期调用flush()
3. 启用批量写入
4. 监控缓冲区使用率

### Q: 支持哪些数据类型？
A: UINT8/16/32/64, INT8/16/32/64, FLOAT, DOUBLE, BOOLEAN, STRING, BYTE_ARRAY

### Q: 如何扩展存储格式？
A: 实现DataStorage接口，注册到StorageFactory。

## 性能调优

### 1. 缓冲区大小

```java
// 大数据量场景，增大缓冲区
config.setBufferSize(1000000);  // 100万条
config.setBatchSize(1000);       // 每批1000条
```

### 2. 采样率控制

```java
// 限制数据源采样率，降低负载
observer.setSampleRate("source1", 50.0);  // 50Hz
```

### 3. 工作线程

```java
// 多核系统，增加工作线程
config.setWorkerThreads(4);
```

## 调试技巧

```java
// 启用调试模式
config.setDebugMode(true);

// 添加监听器
observer.addListener(new DataObserver.ObserverListener() {
    @Override
    public void onDataDropped(DataSource source, DataRecord record) {
        System.err.println("Data dropped from: " + source.getName());
    }
    
    @Override
    public void onError(String message, Throwable error) {
        System.err.println("Error: " + message);
        error.printStackTrace();
    }
});
```

## 更多示例

查看 `src/main/java/com/dataobserver/example/DataObserverExample.java` 获取完整示例。

## 参考文档

- [README.md](README.md) - 项目说明
- [ARCHITECTURE.md](ARCHITECTURE.md) - 架构设计
- [ASAM MDF Standard](https://www.asam.net/standards/detail/mdf/) - MDF标准
