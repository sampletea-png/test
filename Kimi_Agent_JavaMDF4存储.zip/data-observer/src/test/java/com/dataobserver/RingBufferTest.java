package com.dataobserver;

import com.dataobserver.buffer.RingBuffer;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * RingBuffer测试类
 */
public class RingBufferTest {

    @Test
    public void testBasicOperations() {
        RingBuffer<String> buffer = new RingBuffer<>(16);
        
        assertTrue(buffer.isEmpty());
        assertEquals(0, buffer.size());
        assertEquals(16, buffer.getCapacity());
        
        // 测试写入
        assertTrue(buffer.offer("item1"));
        assertTrue(buffer.offer("item2"));
        assertEquals(2, buffer.size());
        
        // 测试读取
        assertEquals("item1", buffer.poll());
        assertEquals("item2", buffer.poll());
        assertNull(buffer.poll());
        assertTrue(buffer.isEmpty());
    }
    
    @Test
    public void testBufferFull() {
        RingBuffer<Integer> buffer = new RingBuffer<>(4);
        
        // 填满缓冲区
        assertTrue(buffer.offer(1));
        assertTrue(buffer.offer(2));
        assertTrue(buffer.offer(3));
        assertTrue(buffer.offer(4));
        
        // 缓冲区已满
        assertFalse(buffer.offer(5));
        assertTrue(buffer.isFull());
        
        // 读取一个后可以继续写入
        assertEquals(1, buffer.poll());
        assertTrue(buffer.offer(5));
    }
    
    @Test
    public void testBatchOperations() {
        RingBuffer<Integer> buffer = new RingBuffer<>(16, 4, RingBuffer.WaitStrategy.SPIN);
        
        // 批量写入
        Integer[] writeBatch = {1, 2, 3, 4, 5};
        int written = buffer.offerBatch(writeBatch);
        assertEquals(4, written);  // 批处理大小限制
        
        // 批量读取
        Integer[] readContainer = new Integer[4];
        int read = buffer.pollBatch(readContainer);
        assertEquals(4, read);
        assertArrayEquals(new Integer[]{1, 2, 3, 4}, readContainer);
    }
    
    @Test
    public void testConcurrentAccess() throws InterruptedException {
        final int capacity = 10000;
        final int itemCount = 100000;
        final RingBuffer<Integer> buffer = new RingBuffer<>(capacity);
        
        ExecutorService executor = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(2);
        AtomicInteger produced = new AtomicInteger(0);
        AtomicInteger consumed = new AtomicInteger(0);
        
        // 生产者线程
        executor.submit(() -> {
            try {
                for (int i = 0; i < itemCount; i++) {
                    while (!buffer.offer(i)) {
                        Thread.yield();
                    }
                    produced.incrementAndGet();
                }
            } finally {
                latch.countDown();
            }
        });
        
        // 消费者线程
        executor.submit(() -> {
            try {
                int expected = 0;
                while (consumed.get() < itemCount) {
                    Integer item = buffer.poll();
                    if (item != null) {
                        consumed.incrementAndGet();
                    } else {
                        Thread.yield();
                    }
                }
            } finally {
                latch.countDown();
            }
        });
        
        latch.await();
        executor.shutdown();
        
        assertEquals(itemCount, produced.get());
        assertEquals(itemCount, consumed.get());
    }
    
    @Test
    public void testClear() {
        RingBuffer<String> buffer = new RingBuffer<>(16);
        
        buffer.offer("item1");
        buffer.offer("item2");
        buffer.offer("item3");
        
        assertEquals(3, buffer.size());
        
        buffer.clear();
        
        assertTrue(buffer.isEmpty());
        assertEquals(0, buffer.size());
        assertNull(buffer.poll());
    }
    
    @Test
    public void testRemainingCapacity() {
        RingBuffer<Integer> buffer = new RingBuffer<>(10);
        
        assertEquals(10, buffer.remainingCapacity());
        
        buffer.offer(1);
        buffer.offer(2);
        
        assertEquals(8, buffer.remainingCapacity());
        
        buffer.poll();
        
        assertEquals(9, buffer.remainingCapacity());
    }
}
