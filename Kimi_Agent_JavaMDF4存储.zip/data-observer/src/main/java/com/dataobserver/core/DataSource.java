package com.dataobserver.core;

import java.util.List;

/**
 * 数据源接口
 * 定义数据源的基本操作
 */
public interface DataSource {
    
    /**
     * 获取数据源唯一标识
     */
    String getId();
    
    /**
     * 获取数据源名称
     */
    String getName();
    
    /**
     * 获取数据源描述
     */
    String getDescription();
    
    /**
     * 获取数据源包含的所有通道
     */
    List<DataChannel> getChannels();
    
    /**
     * 根据名称获取通道
     */
    DataChannel getChannel(String name);
    
    /**
     * 启动数据源
     */
    void start();
    
    /**
     * 停止数据源
     */
    void stop();
    
    /**
     * 检查数据源是否正在运行
     */
    boolean isRunning();
    
    /**
     * 设置数据回调
     */
    void setDataCallback(DataCallback callback);
    
    /**
     * 移除数据回调
     */
    void removeDataCallback();
    
    /**
     * 获取采样率（Hz），0表示不规则采样
     */
    double getSampleRate();
    
    /**
     * 注册数据源监听器
     */
    void addListener(DataSourceListener listener);
    
    /**
     * 移除数据源监听器
     */
    void removeListener(DataSourceListener listener);
    
    /**
     * 数据回调接口
     */
    interface DataCallback {
        void onData(DataRecord record);
    }
    
    /**
     * 数据源监听器接口
     */
    interface DataSourceListener {
        void onChannelAdded(DataChannel channel);
        void onChannelRemoved(DataChannel channel);
        void onStarted();
        void onStopped();
    }
}
