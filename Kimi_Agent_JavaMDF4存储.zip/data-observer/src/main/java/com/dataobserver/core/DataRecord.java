package com.dataobserver.core;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

/**
 * 数据记录类
 * 存储单个时间点的多个通道数据
 */
public class DataRecord {
    private final long timestamp;  // 纳秒级时间戳
    private final Map<String, Object> values;
    private final Map<String, DataType> types;
    
    public DataRecord(long timestamp) {
        this.timestamp = timestamp;
        this.values = new HashMap<>();
        this.types = new HashMap<>();
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void addValue(String channelName, Object value, DataType type) {
        values.put(channelName, value);
        types.put(channelName, type);
    }
    
    public Object getValue(String channelName) {
        return values.get(channelName);
    }
    
    public DataType getType(String channelName) {
        return types.get(channelName);
    }
    
    public Map<String, Object> getAllValues() {
        return new HashMap<>(values);
    }
    
    public boolean hasChannel(String channelName) {
        return values.containsKey(channelName);
    }
    
    /**
     * 将记录序列化为字节数组
     */
    public byte[] serialize(String[] channelOrder) {
        // 计算总大小
        int totalSize = 8;  // 时间戳占8字节
        for (String channel : channelOrder) {
            DataType type = types.get(channel);
            if (type == null) continue;
            
            if (type.isVariableLength()) {
                Object value = values.get(channel);
                if (value instanceof String) {
                    totalSize += 4 + ((String) value).getBytes().length;
                } else if (value instanceof byte[]) {
                    totalSize += 4 + ((byte[]) value).length;
                }
            } else {
                totalSize += type.getSizeBytes();
            }
        }
        
        ByteBuffer buffer = ByteBuffer.allocate(totalSize);
        buffer.putLong(timestamp);
        
        for (String channel : channelOrder) {
            DataType type = types.get(channel);
            if (type == null) continue;
            
            Object value = values.get(channel);
            writeValue(buffer, value, type);
        }
        
        return buffer.array();
    }
    
    private void writeValue(ByteBuffer buffer, Object value, DataType type) {
        switch (type) {
            case UINT8:
            case INT8:
                buffer.put(((Number) value).byteValue());
                break;
            case UINT16:
            case INT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case UINT32:
            case INT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case UINT64:
            case INT64:
                buffer.putLong(((Number) value).longValue());
                break;
            case FLOAT:
                buffer.putFloat(((Number) value).floatValue());
                break;
            case DOUBLE:
                buffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                buffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            case STRING:
                byte[] strBytes = ((String) value).getBytes();
                buffer.putInt(strBytes.length);
                buffer.put(strBytes);
                break;
            case BYTE_ARRAY:
                byte[] arr = (byte[]) value;
                buffer.putInt(arr.length);
                buffer.put(arr);
                break;
        }
    }
    
    @Override
    public String toString() {
        return "DataRecord{timestamp=" + timestamp + ", values=" + values + "}";
    }
}
