package com.dataobserver.core;

/**
 * 数据通道接口
 * 表示一个被观察的数据信号
 */
public interface DataChannel {
    
    /**
     * 获取通道唯一标识
     */
    String getId();
    
    /**
     * 获取通道名称
     */
    String getName();
    
    /**
     * 获取通道描述
     */
    String getDescription();
    
    /**
     * 获取数据类型
     */
    DataType getDataType();
    
    /**
     * 获取单位
     */
    String getUnit();
    
    /**
     * 获取最小值（物理值）
     */
    Double getMinValue();
    
    /**
     * 获取最大值（物理值）
     */
    Double getMaxValue();
    
    /**
     * 获取转换公式（从原始值到物理值）
     * 格式: linear(a,b) 表示 physical = raw * a + b
     */
    String getConversionFormula();
    
    /**
     * 是否为主通道（时间通道）
     */
    boolean isMasterChannel();
    
    /**
     * 获取所属数据源
     */
    DataSource getSource();
    
    /**
     * 获取采样率（Hz），0表示不规则采样
     */
    double getSampleRate();
    
    /**
     * 获取通道元数据
     */
    java.util.Map<String, String> getMetadata();
    
    /**
     * 将原始值转换为物理值
     */
    default double convertToPhysical(Number rawValue) {
        String formula = getConversionFormula();
        if (formula == null || formula.isEmpty()) {
            return rawValue.doubleValue();
        }
        
        // 解析 linear(a,b) 格式
        if (formula.startsWith("linear(")) {
            String params = formula.substring(7, formula.length() - 1);
            String[] parts = params.split(",");
            double a = Double.parseDouble(parts[0].trim());
            double b = Double.parseDouble(parts[1].trim());
            return rawValue.doubleValue() * a + b;
        }
        
        return rawValue.doubleValue();
    }
}
