package com.dataobserver.core;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 模拟数据源实现
 * 用于测试和演示
 */
public class SimulatedDataSource implements DataSource {
    
    private final String id;
    private final String name;
    private final List<DataChannel> channels;
    private final Map<String, SimulatedChannel> channelMap;
    private final double sampleRate;
    private final ScheduledExecutorService executor;
    private final AtomicBoolean running;
    
    private DataCallback dataCallback;
    private final Set<DataSourceListener> listeners;
    
    // 模拟数据生成器
    private final Map<String, DataGenerator> generators;
    
    public SimulatedDataSource(String id, String name, double sampleRate) {
        this.id = id;
        this.name = name;
        this.sampleRate = sampleRate;
        this.channels = new ArrayList<>();
        this.channelMap = new HashMap<>();
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "SimulatedDataSource-" + id);
            t.setDaemon(true);
            return t;
        });
        this.running = new AtomicBoolean(false);
        this.listeners = ConcurrentHashMap.newKeySet();
        this.generators = new HashMap<>();
    }
    
    /**
     * 添加模拟通道
     */
    public void addChannel(String name, DataType type, String unit, 
                          Double minValue, Double maxValue, DataGenerator generator) {
        SimulatedChannel channel = new SimulatedChannel(name, type, unit, minValue, maxValue, this);
        channels.add(channel);
        channelMap.put(name, channel);
        generators.put(name, generator);
    }
    
    /**
     * 添加简单正弦波通道
     */
    public void addSineWaveChannel(String name, double amplitude, double frequency, double offset) {
        addChannel(name, DataType.DOUBLE, "V", -amplitude, amplitude, 
            time -> offset + amplitude * Math.sin(2 * Math.PI * frequency * time));
    }
    
    /**
     * 添加随机噪声通道
     */
    public void addNoiseChannel(String name, double amplitude, double offset) {
        Random random = new Random();
        addChannel(name, DataType.DOUBLE, "V", offset - amplitude, offset + amplitude,
            time -> offset + amplitude * (2 * random.nextDouble() - 1));
    }
    
    /**
     * 添加斜坡通道
     */
    public void addRampChannel(String name, double slope, double offset) {
        addChannel(name, DataType.DOUBLE, "V", null, null,
            time -> offset + slope * time);
    }
    
    /**
     * 添加阶跃通道
     */
    public void addStepChannel(String name, double lowValue, double highValue, double stepTime) {
        addChannel(name, DataType.DOUBLE, "V", 
            Math.min(lowValue, highValue), Math.max(lowValue, highValue),
            time -> time >= stepTime ? highValue : lowValue);
    }
    
    @Override
    public String getId() {
        return id;
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public String getDescription() {
        return "Simulated data source: " + name;
    }
    
    @Override
    public List<DataChannel> getChannels() {
        return new ArrayList<>(channels);
    }
    
    @Override
    public DataChannel getChannel(String name) {
        return channelMap.get(name);
    }
    
    @Override
    public void start() {
        if (running.compareAndSet(false, true)) {
            long periodMs = sampleRate > 0 ? (long) (1000.0 / sampleRate) : 100;
            
            executor.scheduleAtFixedRate(() -> {
                if (dataCallback != null) {
                    generateAndSendData();
                }
            }, 0, periodMs, TimeUnit.MILLISECONDS);
            
            notifyStarted();
        }
    }
    
    @Override
    public void stop() {
        if (running.compareAndSet(true, false)) {
            executor.shutdown();
            try {
                executor.awaitTermination(1, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            notifyStopped();
        }
    }
    
    @Override
    public boolean isRunning() {
        return running.get();
    }
    
    @Override
    public void setDataCallback(DataCallback callback) {
        this.dataCallback = callback;
    }
    
    @Override
    public void removeDataCallback() {
        this.dataCallback = null;
    }
    
    @Override
    public double getSampleRate() {
        return sampleRate;
    }
    
    @Override
    public void addListener(DataSourceListener listener) {
        listeners.add(listener);
    }
    
    @Override
    public void removeListener(DataSourceListener listener) {
        listeners.remove(listener);
    }
    
    /**
     * 生成并发送数据
     */
    private void generateAndSendData() {
        long timestamp = System.nanoTime();
        double time = timestamp / 1_000_000_000.0;
        
        DataRecord record = new DataRecord(timestamp);
        
        for (SimulatedChannel channel : channelMap.values()) {
            DataGenerator generator = generators.get(channel.getName());
            if (generator != null) {
                double value = generator.generate(time);
                record.addValue(channel.getName(), value, channel.getDataType());
            }
        }
        
        dataCallback.onData(record);
    }
    
    private void notifyStarted() {
        for (DataSourceListener listener : listeners) {
            listener.onStarted();
        }
    }
    
    private void notifyStopped() {
        for (DataSourceListener listener : listeners) {
            listener.onStopped();
        }
    }
    
    /**
     * 数据生成器接口
     */
    @FunctionalInterface
    public interface DataGenerator {
        double generate(double time);
    }
    
    /**
     * 模拟通道实现
     */
    private static class SimulatedChannel implements DataChannel {
        private final String name;
        private final DataType dataType;
        private final String unit;
        private final Double minValue;
        private final Double maxValue;
        private final DataSource source;
        
        SimulatedChannel(String name, DataType dataType, String unit, 
                        Double minValue, Double maxValue, DataSource source) {
            this.name = name;
            this.dataType = dataType;
            this.unit = unit;
            this.minValue = minValue;
            this.maxValue = maxValue;
            this.source = source;
        }
        
        @Override
        public String getId() {
            return source.getId() + "." + name;
        }
        
        @Override
        public String getName() {
            return name;
        }
        
        @Override
        public String getDescription() {
            return "Simulated channel: " + name;
        }
        
        @Override
        public DataType getDataType() {
            return dataType;
        }
        
        @Override
        public String getUnit() {
            return unit;
        }
        
        @Override
        public Double getMinValue() {
            return minValue;
        }
        
        @Override
        public Double getMaxValue() {
            return maxValue;
        }
        
        @Override
        public String getConversionFormula() {
            return "linear(1,0)";
        }
        
        @Override
        public boolean isMasterChannel() {
            return false;
        }
        
        @Override
        public DataSource getSource() {
            return source;
        }
        
        @Override
        public double getSampleRate() {
            return source.getSampleRate();
        }
        
        @Override
        public Map<String, String> getMetadata() {
            return new HashMap<>();
        }
    }
}
