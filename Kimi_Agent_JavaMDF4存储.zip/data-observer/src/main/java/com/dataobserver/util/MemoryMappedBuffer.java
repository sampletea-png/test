package com.dataobserver.util;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 内存映射缓冲区
 * 用于处理大文件的高性能读写
 */
public class MemoryMappedBuffer {
    
    // 默认映射大小: 64MB
    private static final long DEFAULT_MAP_SIZE = 64 * 1024 * 1024L;
    
    // 最大文件大小: 2GB（受限于MappedByteBuffer的int索引）
    private static final long MAX_FILE_SIZE = 2L * 1024 * 1024 * 1024;
    
    private final RandomAccessFile file;
    private final FileChannel channel;
    private final long mapSize;
    
    private MappedByteBuffer currentBuffer;
    private long currentMapStart;
    private final AtomicLong writePosition;
    
    public MemoryMappedBuffer(RandomAccessFile file) throws IOException {
        this(file, DEFAULT_MAP_SIZE);
    }
    
    public MemoryMappedBuffer(RandomAccessFile file, long mapSize) throws IOException {
        this.file = file;
        this.channel = file.getChannel();
        this.mapSize = Math.min(mapSize, MAX_FILE_SIZE);
        this.writePosition = new AtomicLong(0);
        this.currentMapStart = 0;
        
        // 初始化第一个映射
        remap(0);
    }
    
    /**
     * 重新映射缓冲区
     */
    private void remap(long position) throws IOException {
        // 清理旧缓冲区
        if (currentBuffer != null) {
            currentBuffer.force();
        }
        
        long fileSize = channel.size();
        long remaining = fileSize - position;
        long sizeToMap = Math.min(mapSize, remaining);
        
        if (sizeToMap <= 0) {
            // 需要扩展文件
            sizeToMap = mapSize;
            file.setLength(position + sizeToMap);
        }
        
        currentBuffer = channel.map(FileChannel.MapMode.READ_WRITE, position, sizeToMap);
        currentMapStart = position;
    }
    
    /**
     * 写入数据
     */
    public void write(byte[] data) throws IOException {
        write(data, 0, data.length);
    }
    
    /**
     * 写入数据（指定偏移和长度）
     */
    public void write(byte[] data, int offset, int length) throws IOException {
        long pos = writePosition.getAndAdd(length);
        
        // 检查是否需要重新映射
        if (pos < currentMapStart || pos + length > currentMapStart + currentBuffer.capacity()) {
            synchronized (this) {
                if (pos < currentMapStart || pos + length > currentMapStart + currentBuffer.capacity()) {
                    remap(pos);
                }
            }
        }
        
        // 写入数据
        int bufferPos = (int) (pos - currentMapStart);
        currentBuffer.position(bufferPos);
        currentBuffer.put(data, offset, length);
    }
    
    /**
     * 写入ByteBuffer
     */
    public void write(java.nio.ByteBuffer buffer) throws IOException {
        int length = buffer.remaining();
        long pos = writePosition.getAndAdd(length);
        
        // 检查是否需要重新映射
        if (pos < currentMapStart || pos + length > currentMapStart + currentBuffer.capacity()) {
            synchronized (this) {
                if (pos < currentMapStart || pos + length > currentMapStart + currentBuffer.capacity()) {
                    remap(pos);
                }
            }
        }
        
        int bufferPos = (int) (pos - currentMapStart);
        currentBuffer.position(bufferPos);
        currentBuffer.put(buffer);
    }
    
    /**
     * 读取数据
     */
    public byte[] read(long position, int length) throws IOException {
        byte[] data = new byte[length];
        read(position, data, 0, length);
        return data;
    }
    
    /**
     * 读取数据到指定数组
     */
    public void read(long position, byte[] dest, int offset, int length) throws IOException {
        // 检查是否需要重新映射
        if (position < currentMapStart || position + length > currentMapStart + currentBuffer.capacity()) {
            synchronized (this) {
                if (position < currentMapStart || position + length > currentMapStart + currentBuffer.capacity()) {
                    remap(position);
                }
            }
        }
        
        int bufferPos = (int) (position - currentMapStart);
        currentBuffer.position(bufferPos);
        currentBuffer.get(dest, offset, length);
    }
    
    /**
     * 刷新缓冲区到磁盘
     */
    public void flush() {
        if (currentBuffer != null) {
            currentBuffer.force();
        }
    }
    
    /**
     * 获取当前写入位置
     */
    public long getWritePosition() {
        return writePosition.get();
    }
    
    /**
     * 设置写入位置
     */
    public void setWritePosition(long position) {
        writePosition.set(position);
    }
    
    /**
     * 关闭缓冲区
     */
    public void close() throws IOException {
        flush();
        if (channel != null) {
            channel.close();
        }
    }
}
