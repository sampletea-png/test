package com.dataobserver.mdf4;

/**
 * MDF4块类型枚举
 * 根据ASAM MDF4规范定义
 */
public enum MDF4BlockType {
    // 标识块
    ID("MDF ", "Identification Block"),
    
    // 头部块
    HD("HD", "Header Block"),
    
    // 文本块
    TX("TX", "Text Block"),
    MD("MD", "Meta Data Block"),
    
    // 数据组块
    DG("DG", "Data Group Block"),
    
    // 通道组块
    CG("CG", "Channel Group Block"),
    
    // 通道块
    CN("CN", "Channel Block"),
    
    // 转换块
    CC("CC", "Channel Conversion Block"),
    
    // 数据源块
    SI("SI", "Source Information Block"),
    
    // 数据块
    DT("DT", "Data Block"),
    RD("RD", "Reduced Data Block"),
    
    // 压缩数据块
    DZ("DZ", "Data Zipped Block"),
    
    // 文件历史块
    FH("FH", "File History Block"),
    
    // 附件块
    AT("AT", "Attachment Block"),
    
    // 事件块
    EV("EV", "Event Block");
    
    private final String blockId;
    private final String description;
    
    MDF4BlockType(String blockId, String description) {
        this.blockId = blockId;
        this.description = description;
    }
    
    public String getBlockId() {
        return blockId;
    }
    
    public String getDescription() {
        return description;
    }
    
    public static MDF4BlockType fromBlockId(String id) {
        for (MDF4BlockType type : values()) {
            if (type.blockId.equals(id)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown block ID: " + id);
    }
}
