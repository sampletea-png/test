package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * MDF4文本块（Text Block - TX）
 * 用于存储文本数据
 */
public class MDF4TextBlock extends MDF4Block {
    
    private String text;
    
    public MDF4TextBlock() {
        super(MDF4BlockType.TX);
        this.text = "";
    }
    
    public MDF4TextBlock(String text) {
        super(MDF4BlockType.TX);
        this.text = text != null ? text : "";
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 链接0字节 + 数据（文本长度+null终止符）
        byte[] textBytes = text.getBytes(StandardCharsets.UTF_8);
        return 24 + textBytes.length + 1;  // +1 for null terminator
    }
    
    @Override
    protected int calculateLinkCount() {
        return 0;  // 文本块没有链接
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        // 无链接
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        byte[] textBytes = text.getBytes(StandardCharsets.UTF_8);
        file.write(textBytes);
        file.writeByte(0);  // null终止符
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        // 无链接
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        // 计算文本数据大小
        long textSize = blockSize - 24;  // 减去头部大小
        if (textSize > 0) {
            byte[] textBytes = new byte[(int) textSize];
            file.readFully(textBytes);
            
            // 找到null终止符
            int actualLen = textBytes.length;
            for (int i = 0; i < textBytes.length; i++) {
                if (textBytes[i] == 0) {
                    actualLen = i;
                    break;
                }
            }
            this.text = new String(textBytes, 0, actualLen, StandardCharsets.UTF_8);
        }
    }
    
    public void setText(String text) {
        this.text = text != null ? text : "";
    }
    
    public String getText() {
        return text;
    }
}
