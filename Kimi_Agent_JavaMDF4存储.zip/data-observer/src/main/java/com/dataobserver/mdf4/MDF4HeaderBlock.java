package com.dataobserver.mdf4;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

/**
 * MDF4头部块（Header Block - HD）
 * 包含文件的全局信息
 */
public class MDF4HeaderBlock extends MDF4Block {
    
    // 链接
    private long dgFirstPosition = 0;      // 第一个数据组块位置
    private long fhFirstPosition = 0;      // 第一个文件历史块位置
    private long chFirstPosition = 0;      // 第一个通道层次块位置（可选）
    private long atFirstPosition = 0;      // 第一个附件块位置（可选）
    private long evFirstPosition = 0;      // 第一个事件块位置（可选）
    private long mdCommentPosition = 0;    // 注释块位置（可选）
    
    // 数据字段
    private long startTimeNs;              // 开始时间（纳秒）
    private short timeZoneOffsetMin;       // 时区偏移（分钟）
    private short daylightSavingTimeMin;   // 夏令时偏移（分钟）
    private byte timeFlags;                // 时间标志
    
    // 自定义属性
    private String author = "";
    private String department = "";
    private String project = "";
    private String subject = "";
    
    public MDF4HeaderBlock() {
        super(MDF4BlockType.HD);
        // 设置默认开始时间为当前时间
        setStartTime(Instant.now());
        this.timeFlags = 0x01;  // 使用UTC时间
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头部24字节 + 链接6*8=48字节 + 数据字段
        return 24 + 48 + 8 + 2 + 2 + 1 + 1 + 32;
    }
    
    @Override
    protected int calculateLinkCount() {
        return 6;
    }
    
    @Override
    protected void writeLinks(RandomAccessFile file) throws IOException {
        file.writeLong(dgFirstPosition);
        file.writeLong(fhFirstPosition);
        file.writeLong(chFirstPosition);
        file.writeLong(atFirstPosition);
        file.writeLong(evFirstPosition);
        file.writeLong(mdCommentPosition);
    }
    
    @Override
    protected void writeData(RandomAccessFile file) throws IOException {
        // 开始时间（8字节，纳秒级Unix时间戳）
        file.writeLong(startTimeNs);
        
        // 时区偏移（2字节）
        file.writeShort(timeZoneOffsetMin);
        
        // 夏令时偏移（2字节）
        file.writeShort(daylightSavingTimeMin);
        
        // 时间标志（1字节）
        file.writeByte(timeFlags);
        
        // 保留（1字节）
        file.writeByte(0);
        
        // 自定义字段（32字节，每字段8字节）
        writeFixedString(file, author, 8);
        writeFixedString(file, department, 8);
        writeFixedString(file, project, 8);
        writeFixedString(file, subject, 8);
    }
    
    @Override
    protected void readLinks(RandomAccessFile file) throws IOException {
        dgFirstPosition = file.readLong();
        fhFirstPosition = file.readLong();
        chFirstPosition = file.readLong();
        atFirstPosition = file.readLong();
        evFirstPosition = file.readLong();
        mdCommentPosition = file.readLong();
    }
    
    @Override
    protected void readData(RandomAccessFile file) throws IOException {
        startTimeNs = file.readLong();
        timeZoneOffsetMin = file.readShort();
        daylightSavingTimeMin = file.readShort();
        timeFlags = file.readByte();
        file.skipBytes(1);  // 保留字节
        
        author = readFixedString(file, 8);
        department = readFixedString(file, 8);
        project = readFixedString(file, 8);
        subject = readFixedString(file, 8);
    }
    
    private void writeFixedString(RandomAccessFile file, String str, int length) throws IOException {
        byte[] bytes = str.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        int len = Math.min(bytes.length, length);
        file.write(bytes, 0, len);
        for (int i = len; i < length; i++) {
            file.writeByte(0);
        }
    }
    
    private String readFixedString(RandomAccessFile file, int length) throws IOException {
        byte[] bytes = new byte[length];
        file.readFully(bytes);
        int actualLen = 0;
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] == 0) {
                actualLen = i;
                break;
            }
        }
        return new String(bytes, 0, actualLen, java.nio.charset.StandardCharsets.UTF_8);
    }
    
    // Getters and Setters
    
    public void setStartTime(Instant instant) {
        this.startTimeNs = instant.toEpochMilli() * 1_000_000L + 
                          (instant.getNano() % 1_000_000);
    }
    
    public Instant getStartTime() {
        return Instant.ofEpochMilli(startTimeNs / 1_000_000);
    }
    
    public void setDgFirstPosition(long position) {
        this.dgFirstPosition = position;
    }
    
    public long getDgFirstPosition() {
        return dgFirstPosition;
    }
    
    public void setFhFirstPosition(long position) {
        this.fhFirstPosition = position;
    }
    
    public long getFhFirstPosition() {
        return fhFirstPosition;
    }
    
    public void setMdCommentPosition(long position) {
        this.mdCommentPosition = position;
    }
    
    public long getMdCommentPosition() {
        return mdCommentPosition;
    }
    
    public void setAuthor(String author) {
        this.author = author != null ? author : "";
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setDepartment(String department) {
        this.department = department != null ? department : "";
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setProject(String project) {
        this.project = project != null ? project : "";
    }
    
    public String getProject() {
        return project;
    }
    
    public void setSubject(String subject) {
        this.subject = subject != null ? subject : "";
    }
    
    public String getSubject() {
        return subject;
    }
}
