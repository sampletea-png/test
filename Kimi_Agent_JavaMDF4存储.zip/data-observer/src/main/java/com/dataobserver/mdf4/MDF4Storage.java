package com.dataobserver.mdf4;

import com.dataobserver.core.DataChannel;
import com.dataobserver.core.DataRecord;
import com.dataobserver.core.DataType;
import com.dataobserver.storage.DataStorage;
import com.dataobserver.storage.StorageFormat;
import com.dataobserver.storage.StorageMetadata;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MDF4格式存储实现
 * 支持并发读写、大文件处理、内存映射
 */
public class MDF4Storage implements DataStorage {
    
    // 文件相关
    private RandomAccessFile file;
    private FileChannel fileChannel;
    private Path filePath;
    private OpenMode openMode;
    
    // MDF4块结构
    private MDF4IDBlock idBlock;
    private MDF4HeaderBlock headerBlock;
    private MDF4DataGroupBlock dataGroupBlock;
    private MDF4ChannelGroupBlock channelGroupBlock;
    private List<MDF4ChannelBlock> channelBlocks;
    private MDF4DataBlock dataBlock;
    
    // 通道管理
    private final Map<String, DataChannel> registeredChannels;
    private final Map<String, Integer> channelOffsets;
    private int currentRecordSize;
    
    // 统计信息
    private final AtomicLong recordCount;
    private long dataBlockStartPosition;
    private long dataBlockSize;
    
    // 并发控制
    private final ReentrantReadWriteLock lock;
    private final AtomicBoolean isOpen;
    
    // 缓冲区
    private ByteBuffer writeBuffer;
    private static final int BUFFER_SIZE = 1024 * 1024;  // 1MB缓冲区
    private static final long MAX_MEMORY_SIZE = 512 * 1024 * 1024L;  // 512MB内存限制
    
    // 元数据
    private StorageMetadata metadata;
    private final Map<String, String> properties;
    
    // 内存映射相关
    private boolean useMemoryMapping;
    private long mappedSize;
    
    public MDF4Storage() {
        this.registeredChannels = new ConcurrentHashMap<>();
        this.channelOffsets = new ConcurrentHashMap<>();
        this.channelBlocks = new ArrayList<>();
        this.recordCount = new AtomicLong(0);
        this.lock = new ReentrantReadWriteLock();
        this.isOpen = new AtomicBoolean(false);
        this.properties = new ConcurrentHashMap<>();
        this.metadata = new StorageMetadata();
        this.useMemoryMapping = false;
        this.mappedSize = 0;
        this.currentRecordSize = 0;
        this.dataBlockSize = 0;
    }
    
    @Override
    public void open(Path path, OpenMode mode) throws IOException {
        lock.writeLock().lock();
        try {
            if (isOpen.get()) {
                throw new IllegalStateException("Storage is already open");
            }
            
            this.filePath = path;
            this.openMode = mode;
            
            if (mode == OpenMode.CREATE) {
                // 创建新文件
                file = new RandomAccessFile(path.toFile(), "rw");
                fileChannel = file.getChannel();
                
                // 初始化MDF4结构
                initializeNewFile();
                
            } else if (mode == OpenMode.APPEND) {
                // 追加到现有文件
                file = new RandomAccessFile(path.toFile(), "rw");
                fileChannel = file.getChannel();
                
                // 读取现有结构
                readExistingFile();
                
                // 定位到数据块末尾
                seekToEndOfData();
                
            } else {
                // 只读模式
                file = new RandomAccessFile(path.toFile(), "r");
                fileChannel = file.getChannel();
                readExistingFile();
            }
            
            // 初始化写入缓冲区
            if (mode != OpenMode.READ_ONLY) {
                writeBuffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
            }
            
            isOpen.set(true);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 初始化新MDF4文件
     */
    private void initializeNewFile() throws IOException {
        // 写入ID块（固定位置0）
        idBlock = new MDF4IDBlock(4, 11);
        idBlock.write(file);
        
        // 写入头部块
        headerBlock = new MDF4HeaderBlock();
        headerBlock.setAuthor(System.getProperty("user.name"));
        headerBlock.setProject(properties.getOrDefault("project", ""));
        headerBlock.setSubject(properties.getOrDefault("subject", ""));
        long headerPos = headerBlock.write(file);
        
        // 写入数据组块
        dataGroupBlock = new MDF4DataGroupBlock();
        long dgPos = dataGroupBlock.write(file);
        headerBlock.setDgFirstPosition(dgPos);
        
        // 写入通道组块
        channelGroupBlock = new MDF4ChannelGroupBlock();
        channelGroupBlock.setRecordId(1);
        long cgPos = channelGroupBlock.write(file);
        dataGroupBlock.setCgFirstPosition(cgPos);
        
        // 预留数据块位置
        dataBlockStartPosition = file.getFilePointer();
        dataBlock = new MDF4DataBlock();
        dataBlock.write(file);
        dataGroupBlock.setDataPosition(dataBlockStartPosition);
        
        // 更新头部块链接
        file.seek(0);
        idBlock.write(file);
        headerBlock.write(file);
        dataGroupBlock.write(file);
        channelGroupBlock.write(file);
        
        // 回到数据块位置
        file.seek(dataBlockStartPosition);
    }
    
    /**
     * 读取现有MDF4文件
     */
    private void readExistingFile() throws IOException {
        // 读取ID块
        idBlock = new MDF4IDBlock();
        idBlock.read(file, 0);
        
        // 读取头部块
        headerBlock = new MDF4HeaderBlock();
        headerBlock.read(file, 64);  // ID块固定64字节
        
        // 读取数据组块
        long dgPos = headerBlock.getDgFirstPosition();
        if (dgPos > 0) {
            dataGroupBlock = new MDF4DataGroupBlock();
            dataGroupBlock.read(file, dgPos);
            
            // 读取通道组块
            long cgPos = dataGroupBlock.getCgFirstPosition();
            if (cgPos > 0) {
                channelGroupBlock = new MDF4ChannelGroupBlock();
                channelGroupBlock.read(file, cgPos);
                
                // 读取通道块
                long cnPos = channelGroupBlock.getCnFirstPosition();
                while (cnPos > 0) {
                    MDF4ChannelBlock cnBlock = new MDF4ChannelBlock();
                    cnBlock.read(file, cnPos);
                    channelBlocks.add(cnBlock);
                    cnPos = cnBlock.getNextCnPosition();
                }
                
                // 获取记录数
                recordCount.set(channelGroupBlock.getCycleCount());
            }
            
            // 获取数据块位置
            dataBlockStartPosition = dataGroupBlock.getDataPosition();
        }
    }
    
    /**
     * 定位到数据块末尾
     */
    private void seekToEndOfData() throws IOException {
        if (dataBlockStartPosition > 0) {
            // 计算数据块大小
            file.seek(dataBlockStartPosition + 16);  // 跳过块头和保留字段
            long blockSize = file.readLong();
            
            // 定位到数据块末尾
            file.seek(dataBlockStartPosition + blockSize);
            dataBlockSize = blockSize - 24;  // 减去头部大小
        }
    }
    
    @Override
    public void close() throws IOException {
        lock.writeLock().lock();
        try {
            if (!isOpen.get()) {
                return;
            }
            
            // 刷新缓冲区
            flush();
            
            // 更新最终统计信息
            if (openMode != OpenMode.READ_ONLY) {
                updateFinalStats();
            }
            
            // 关闭文件
            if (fileChannel != null) {
                fileChannel.close();
                fileChannel = null;
            }
            if (file != null) {
                file.close();
                file = null;
            }
            
            isOpen.set(false);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 更新最终统计信息
     */
    private void updateFinalStats() throws IOException {
        // 更新通道组块中的记录数
        if (channelGroupBlock != null) {
            channelGroupBlock.setCycleCount(recordCount.get());
            
            // 重新写入通道组块
            long cgPos = dataGroupBlock.getCgFirstPosition();
            file.seek(cgPos);
            channelGroupBlock.write(file);
        }
        
        // 更新数据块大小
        if (dataBlockStartPosition > 0) {
            file.seek(dataBlockStartPosition + 16);
            file.writeLong(24 + dataBlockSize);  // 头部 + 数据
        }
    }
    
    @Override
    public void writeRecord(DataRecord record) throws IOException {
        if (openMode == OpenMode.READ_ONLY) {
            throw new IllegalStateException("Cannot write in read-only mode");
        }
        
        lock.readLock().lock();
        try {
            byte[] recordBytes = serializeRecord(record);
            
            // 写入缓冲区或文件
            if (writeBuffer != null && writeBuffer.remaining() >= recordBytes.length) {
                writeBuffer.put(recordBytes);
            } else {
                // 刷新缓冲区
                flushBuffer();
                
                // 直接写入文件
                fileChannel.write(ByteBuffer.wrap(recordBytes));
            }
            
            dataBlockSize += recordBytes.length;
            recordCount.incrementAndGet();
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void writeRecords(List<DataRecord> records) throws IOException {
        if (openMode == OpenMode.READ_ONLY) {
            throw new IllegalStateException("Cannot write in read-only mode");
        }
        
        lock.readLock().lock();
        try {
            // 批量序列化
            int totalSize = 0;
            List<byte[]> serializedRecords = new ArrayList<>(records.size());
            
            for (DataRecord record : records) {
                byte[] bytes = serializeRecord(record);
                serializedRecords.add(bytes);
                totalSize += bytes.length;
            }
            
            // 检查是否需要刷新缓冲区
            if (writeBuffer != null && writeBuffer.remaining() < totalSize) {
                flushBuffer();
            }
            
            // 写入数据
            if (writeBuffer != null) {
                for (byte[] bytes : serializedRecords) {
                    writeBuffer.put(bytes);
                }
            } else {
                // 合并写入
                ByteBuffer combined = ByteBuffer.allocate(totalSize);
                for (byte[] bytes : serializedRecords) {
                    combined.put(bytes);
                }
                combined.flip();
                fileChannel.write(combined);
            }
            
            dataBlockSize += totalSize;
            recordCount.addAndGet(records.size());
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 序列化数据记录
     */
    private byte[] serializeRecord(DataRecord record) {
        ByteBuffer buffer = ByteBuffer.allocate(currentRecordSize);
        buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN);
        
        // 按通道顺序写入数据
        for (Map.Entry<String, Integer> entry : channelOffsets.entrySet()) {
            String channelName = entry.getKey();
            int offset = entry.getValue();
            
            buffer.position(offset);
            
            Object value = record.getValue(channelName);
            DataType type = record.getType(channelName);
            
            if (value != null && type != null) {
                writeValue(buffer, value, type);
            }
        }
        
        return buffer.array();
    }
    
    /**
     * 写入单个值
     */
    private void writeValue(ByteBuffer buffer, Object value, DataType type) {
        switch (type) {
            case UINT8:
            case INT8:
                buffer.put(((Number) value).byteValue());
                break;
            case UINT16:
            case INT16:
                buffer.putShort(((Number) value).shortValue());
                break;
            case UINT32:
            case INT32:
                buffer.putInt(((Number) value).intValue());
                break;
            case UINT64:
            case INT64:
                buffer.putLong(((Number) value).longValue());
                break;
            case FLOAT:
                buffer.putFloat(((Number) value).floatValue());
                break;
            case DOUBLE:
                buffer.putDouble(((Number) value).doubleValue());
                break;
            case BOOLEAN:
                buffer.put((Boolean) value ? (byte) 1 : (byte) 0);
                break;
            default:
                // 变长类型不支持直接写入
                break;
        }
    }
    
    @Override
    public void registerChannel(DataChannel channel) throws IOException {
        if (openMode == OpenMode.READ_ONLY) {
            throw new IllegalStateException("Cannot register channels in read-only mode");
        }
        
        lock.writeLock().lock();
        try {
            if (registeredChannels.containsKey(channel.getName())) {
                return;  // 已注册
            }
            
            // 计算字节偏移
            int byteOffset = currentRecordSize;
            int channelSize = channel.getDataType().getSizeBytes();
            
            // 创建通道块
            MDF4ChannelBlock cnBlock = MDF4ChannelBlock.fromDataChannel(
                channel, byteOffset, currentRecordSize + channelSize
            );
            
            // 写入通道名称文本块
            if (channel.getName() != null && !channel.getName().isEmpty()) {
                MDF4TextBlock nameBlock = new MDF4TextBlock(channel.getName());
                long namePos = nameBlock.write(file);
                cnBlock.setNamePosition(namePos);
            }
            
            // 写入单位文本块
            if (channel.getUnit() != null && !channel.getUnit().isEmpty()) {
                MDF4TextBlock unitBlock = new MDF4TextBlock(channel.getUnit());
                long unitPos = unitBlock.write(file);
                cnBlock.setUnitPosition(unitPos);
            }
            
            // 写入注释文本块
            if (channel.getDescription() != null && !channel.getDescription().isEmpty()) {
                MDF4TextBlock commentBlock = new MDF4TextBlock(channel.getDescription());
                long commentPos = commentBlock.write(file);
                cnBlock.setCommentPosition(commentPos);
            }
            
            // 写入通道块
            long cnPos = cnBlock.write(file);
            
            // 更新链表
            if (!channelBlocks.isEmpty()) {
                MDF4ChannelBlock lastBlock = channelBlocks.get(channelBlocks.size() - 1);
                lastBlock.setNextCnPosition(cnPos);
                
                // 更新文件中的链接
                file.seek(lastBlock.getFilePosition() + 24);  // 跳过头部
                file.writeLong(cnPos);
            }
            
            channelBlocks.add(cnBlock);
            registeredChannels.put(channel.getName(), channel);
            channelOffsets.put(channel.getName(), byteOffset);
            
            // 更新记录大小
            currentRecordSize += channelSize;
            
            // 更新通道组块
            channelGroupBlock.setRecordSize(currentRecordSize);
            long cgPos = dataGroupBlock.getCgFirstPosition();
            file.seek(cgPos);
            channelGroupBlock.write(file);
            
            // 更新通道组中的第一个通道位置
            if (channelBlocks.size() == 1) {
                channelGroupBlock.setCnFirstPosition(cnPos);
                file.seek(cgPos + 24);  // 跳过头部
                file.writeLong(cnPos);
            }
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void registerChannels(List<DataChannel> channels) throws IOException {
        for (DataChannel channel : channels) {
            registerChannel(channel);
        }
    }
    
    @Override
    public List<DataChannel> getRegisteredChannels() {
        lock.readLock().lock();
        try {
            return new ArrayList<>(registeredChannels.values());
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public void flush() throws IOException {
        if (openMode == OpenMode.READ_ONLY) {
            return;
        }
        
        lock.writeLock().lock();
        try {
            flushBuffer();
            
            if (fileChannel != null) {
                fileChannel.force(true);
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 刷新缓冲区到文件
     */
    private void flushBuffer() throws IOException {
        if (writeBuffer != null && writeBuffer.position() > 0) {
            writeBuffer.flip();
            fileChannel.write(writeBuffer);
            writeBuffer.clear();
        }
    }
    
    @Override
    public StorageFormat getFormat() {
        return StorageFormat.MDF4;
    }
    
    @Override
    public long getFileSize() throws IOException {
        lock.readLock().lock();
        try {
            return file != null ? file.length() : 0;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public long getRecordCount() {
        return recordCount.get();
    }
    
    @Override
    public boolean supportsConcurrentWrite() {
        return true;
    }
    
    @Override
    public boolean supportsReadWhileWriting() {
        return true;
    }
    
    @Override
    public StorageMetadata getMetadata() {
        return metadata;
    }
    
    @Override
    public void setProperty(String key, String value) {
        properties.put(key, value);
    }
    
    @Override
    public String getProperty(String key) {
        return properties.get(key);
    }
    
    /**
     * 设置是否使用内存映射
     */
    public void setUseMemoryMapping(boolean useMemoryMapping) {
        this.useMemoryMapping = useMemoryMapping;
    }
    
    /**
     * 获取当前记录大小
     */
    public int getRecordSize() {
        return currentRecordSize;
    }
}
