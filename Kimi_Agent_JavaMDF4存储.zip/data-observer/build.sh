#!/bin/bash

# DataObserver Build Script

set -e

echo "=== DataObserver Build Script ==="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Java version
echo "Checking Java version..."
if ! command -v java &> /dev/null; then
    echo -e "${RED}Error: Java not found${NC}"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "Java version: $JAVA_VERSION"

# Check Maven
echo ""
echo "Checking Maven..."
if ! command -v mvn &> /dev/null; then
    echo -e "${RED}Error: Maven not found${NC}"
    echo "Please install Maven 3.6+"
    exit 1
fi

MVN_VERSION=$(mvn -version | head -1 | awk '{print $3}')
echo "Maven version: $MVN_VERSION"

# Clean
echo ""
echo "Cleaning..."
mvn clean -q

# Compile
echo ""
echo "Compiling..."
mvn compile -q

# Run tests
echo ""
echo "Running tests..."
mvn test -q

if [ $? -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
else
    echo -e "${RED}Tests failed!${NC}"
    exit 1
fi

# Package
echo ""
echo "Packaging..."
mvn package -DskipTests -q

# Check if JAR was created
JAR_FILE="target/data-observer-1.0.0-SNAPSHOT-jar-with-dependencies.jar"
if [ -f "$JAR_FILE" ]; then
    echo -e "${GREEN}Build successful!${NC}"
    echo ""
    echo "JAR file: $JAR_FILE"
    echo "Size: $(du -h $JAR_FILE | cut -f1)"
    echo ""
    echo "To run the example:"
    echo "  java -jar $JAR_FILE"
else
    echo -e "${RED}Build failed: JAR file not found${NC}"
    exit 1
fi

echo ""
echo "=== Build Complete ==="
