#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
存储模块 - 可插拔的存储格式架构
支持多种存储格式：MDF4, CSV, JSON, SQLite, Parquet等
"""

from .base import StorageInterface, StorageConfig
from .factory import StorageFactory
from .mdf4_storage import MDF4Storage
from .csv_storage import CSVStorage
from .json_storage import JSONStorage
from .sqlite_storage import SQLiteStorage

__all__ = [
    'StorageInterface',
    'StorageConfig',
    'StorageFactory',
    'MDF4Storage',
    'CSVStorage',
    'JSONStorage',
    'SQLiteStorage',
]
