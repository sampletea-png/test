#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4存储格式实现
使用asammdf库写入ASAM MDF 4.x格式
"""

from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from .base import StorageInterface, StorageConfig, StorageInfo

logger = logging.getLogger(__name__)

# 尝试导入asammdf
try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False
    logger.warning("asammdf库未安装，MDF4存储格式不可用")


class MDF4Storage(StorageInterface):
    """
    MDF4存储格式
    支持ASAM MDF 4.10/4.11标准
    """
    
    FORMAT_NAME = "mdf4"
    DEFAULT_EXTENSION = "mf4"
    SUPPORTS_APPEND = False  # MDF4追加需要特殊处理
    SUPPORTS_COMPRESSION = True
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        if not ASAMMDF_AVAILABLE:
            raise ImportError("asammdf库未安装，无法使用MDF4存储格式")
        
        self._mdf: Optional[MDF] = None
        self._version = self.config.options.get('version', '4.10')
        
        # 信号数据累积
        self._signal_buffers: Dict[str, List[float]] = {
            'timestamps': []
        }
        
        # 信号名称映射
        self._signal_names = [
            'vehicle_speed', 'engine_rpm', 'engine_temp',
            'throttle_position', 'brake_position', 'steering_angle',
            'battery_voltage', 'fuel_level', 'odometer',
            'accel_x', 'accel_y', 'accel_z'
        ]
        
        for name in self._signal_names:
            self._signal_buffers[name] = []
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建MDF4文件"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            # 确保目录存在
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 创建新的MDF文件
            self._mdf = MDF(version=self._version)
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开MDF4文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            # 累积到信号缓冲区
            timestamp = data.get('timestamp', datetime.now().timestamp() * 1000)
            self._signal_buffers['timestamps'].append(timestamp / 1000.0)  # 转换为秒
            
            for name in self._signal_names:
                value = data.get(name, 0.0)
                self._signal_buffers[name].append(float(value))
            
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入MDF4数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            # 累积所有数据到缓冲区
            for data in data_list:
                timestamp = data.get('timestamp', datetime.now().timestamp() * 1000)
                self._signal_buffers['timestamps'].append(timestamp / 1000.0)
                
                for name in self._signal_names:
                    value = data.get(name, 0.0)
                    self._signal_buffers[name].append(float(value))
            
            # 创建Signal对象并追加到MDF
            signals = []
            timestamps = np.array(self._signal_buffers['timestamps'], dtype=np.float64)
            
            # 单位映射
            units = {
                'vehicle_speed': 'km/h',
                'engine_rpm': 'rpm',
                'engine_temp': '°C',
                'throttle_position': '%',
                'brake_position': '%',
                'steering_angle': '°',
                'battery_voltage': 'V',
                'fuel_level': '%',
                'odometer': 'km',
                'accel_x': 'm/s²',
                'accel_y': 'm/s²',
                'accel_z': 'm/s²'
            }
            
            for name in self._signal_names:
                values = self._signal_buffers[name]
                if values:
                    signal = Signal(
                        samples=np.array(values, dtype=np.float64),
                        timestamps=timestamps,
                        name=name,
                        unit=units.get(name, '')
                    )
                    signals.append(signal)
            
            if signals:
                self._mdf.append(signals)
                logger.debug(f"已写入 {len(signals)} 个信号，{len(data_list)} 条记录")
            
            # 清空缓冲区
            self._clear_buffers()
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入MDF4失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭MDF4文件"""
        try:
            if self._mdf is None:
                return True
            
            # 刷新剩余数据
            if any(self._signal_buffers[name] for name in self._signal_names):
                self._flush_remaining()
            
            # 保存文件
            if self._info.file_path:
                compression = self.config.compression
                if compression == 'gzip':
                    self._mdf.save(str(self._info.file_path), overwrite=True, compression=1)
                elif compression == 'bz2':
                    self._mdf.save(str(self._info.file_path), overwrite=True, compression=2)
                else:
                    self._mdf.save(str(self._info.file_path), overwrite=True)
                
                logger.info(f"MDF4文件已保存: {self._info.file_path}")
            
            self._mdf.close()
            self._mdf = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭MDF4文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
    
    def _clear_buffers(self):
        """清空信号缓冲区"""
        self._signal_buffers['timestamps'].clear()
        for name in self._signal_names:
            self._signal_buffers[name].clear()
    
    def _flush_remaining(self):
        """刷新剩余数据"""
        try:
            signals = []
            timestamps = np.array(self._signal_buffers['timestamps'], dtype=np.float64)
            
            units = {
                'vehicle_speed': 'km/h',
                'engine_rpm': 'rpm',
                'engine_temp': '°C',
                'throttle_position': '%',
                'brake_position': '%',
                'steering_angle': '°',
                'battery_voltage': 'V',
                'fuel_level': '%',
                'odometer': 'km',
                'accel_x': 'm/s²',
                'accel_y': 'm/s²',
                'accel_z': 'm/s²'
            }
            
            for name in self._signal_names:
                values = self._signal_buffers[name]
                if values:
                    signal = Signal(
                        samples=np.array(values, dtype=np.float64),
                        timestamps=timestamps,
                        name=name,
                        unit=units.get(name, '')
                    )
                    signals.append(signal)
            
            if signals:
                self._mdf.append(signals)
                logger.debug(f"已刷新 {len(signals)} 个剩余信号")
            
            self._clear_buffers()
            
        except Exception as e:
            logger.error(f"刷新剩余数据失败: {e}")
    
    def get_mdf_info(self) -> Dict[str, Any]:
        """获取MDF文件详细信息"""
        if self._mdf is None:
            return {}
        
        try:
            info = self._mdf.info()
            return {
                'version': self._mdf.version,
                'groups': len(self._mdf.groups),
                'channels': len(self._mdf.channels_db),
                'start_time': str(self._mdf.header.start_time) if hasattr(self._mdf.header, 'start_time') else None
            }
        except Exception as e:
            logger.error(f"获取MDF信息失败: {e}")
            return {}
