#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
存储工厂 - 管理和创建存储格式实例
支持动态注册新的存储格式
"""

from typing import Dict, Type, Optional, List, Callable
from pathlib import Path
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)


class StorageFactory:
    """
    存储工厂类 - 单例模式
    管理所有可用的存储格式
    """
    
    _instance: Optional['StorageFactory'] = None
    _storages: Dict[str, Type[StorageInterface]] = {}
    _initialized: bool = False
    
    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """初始化（仅执行一次）"""
        if StorageFactory._initialized:
            return
        
        StorageFactory._initialized = True
        self._auto_register()
        logger.debug(f"存储工厂已初始化，已注册格式: {list(self._storages.keys())}")
    
    def _auto_register(self):
        """自动注册内置存储格式"""
        # 延迟导入，避免循环依赖
        try:
            from .mdf4_storage import MDF4Storage
            self.register(MDF4Storage)
        except ImportError as e:
            logger.warning(f"MDF4存储格式不可用: {e}")
        
        try:
            from .csv_storage import CSVStorage
            self.register(CSVStorage)
        except ImportError as e:
            logger.warning(f"CSV存储格式不可用: {e}")
        
        try:
            from .json_storage import JSONStorage
            self.register(JSONStorage)
        except ImportError as e:
            logger.warning(f"JSON存储格式不可用: {e}")
        
        try:
            from .sqlite_storage import SQLiteStorage
            self.register(SQLiteStorage)
        except ImportError as e:
            logger.warning(f"SQLite存储格式不可用: {e}")
        
        try:
            from .parquet_storage import ParquetStorage
            self.register(ParquetStorage)
        except ImportError as e:
            logger.debug(f"Parquet存储格式不可用: {e}")
    
    # ==================== 注册管理 ====================
    
    def register(self, storage_class: Type[StorageInterface]) -> bool:
        """
        注册存储格式
        
        Args:
            storage_class: 存储类，必须继承StorageInterface
            
        Returns:
            是否注册成功
        """
        if not issubclass(storage_class, StorageInterface):
            logger.error(f"注册失败: {storage_class} 必须继承 StorageInterface")
            return False
        
        format_name = storage_class.FORMAT_NAME.lower()
        
        if format_name in self._storages:
            logger.warning(f"存储格式 '{format_name}' 已存在，将被覆盖")
        
        self._storages[format_name] = storage_class
        logger.debug(f"已注册存储格式: {format_name}")
        return True
    
    def unregister(self, format_name: str) -> bool:
        """
        注销存储格式
        
        Args:
            format_name: 格式名称
            
        Returns:
            是否注销成功
        """
        format_name = format_name.lower()
        
        if format_name not in self._storages:
            logger.warning(f"存储格式 '{format_name}' 不存在")
            return False
        
        del self._storages[format_name]
        logger.debug(f"已注销存储格式: {format_name}")
        return True
    
    def is_registered(self, format_name: str) -> bool:
        """检查格式是否已注册"""
        return format_name.lower() in self._storages
    
    def get_available_formats(self) -> List[str]:
        """获取所有可用的存储格式名称"""
        return sorted(self._storages.keys())
    
    def get_format_info(self, format_name: str) -> Optional[Dict]:
        """
        获取存储格式信息
        
        Args:
            format_name: 格式名称
            
        Returns:
            格式信息字典
        """
        format_name = format_name.lower()
        storage_class = self._storages.get(format_name)
        
        if storage_class is None:
            return None
        
        return {
            'name': storage_class.FORMAT_NAME,
            'extension': storage_class.DEFAULT_EXTENSION,
            'supports_append': storage_class.SUPPORTS_APPEND,
            'supports_compression': storage_class.SUPPORTS_COMPRESSION,
            'class': storage_class.__name__
        }
    
    def get_all_formats_info(self) -> Dict[str, Dict]:
        """获取所有格式信息"""
        return {
            name: self.get_format_info(name)
            for name in self.get_available_formats()
        }
    
    # ==================== 创建实例 ====================
    
    def create(
        self,
        format_name: str,
        config: Optional[StorageConfig] = None
    ) -> Optional[StorageInterface]:
        """
        创建存储实例
        
        Args:
            format_name: 格式名称
            config: 存储配置
            
        Returns:
            存储实例，如果格式不存在则返回None
        """
        format_name = format_name.lower()
        storage_class = self._storages.get(format_name)
        
        if storage_class is None:
            logger.error(f"未知的存储格式: {format_name}")
            logger.info(f"可用格式: {self.get_available_formats()}")
            return None
        
        try:
            instance = storage_class(config)
            logger.debug(f"已创建 {format_name} 存储实例")
            return instance
        except Exception as e:
            logger.error(f"创建 {format_name} 存储实例失败: {e}")
            return None
    
    def create_or_fallback(
        self,
        format_name: str,
        config: Optional[StorageConfig] = None,
        fallback_format: str = "csv"
    ) -> StorageInterface:
        """
        创建存储实例，如果失败则使用后备格式
        
        Args:
            format_name: 首选格式名称
            config: 存储配置
            fallback_format: 后备格式名称
            
        Returns:
            存储实例
        """
        instance = self.create(format_name, config)
        
        if instance is None:
            logger.warning(f"使用后备格式: {fallback_format}")
            instance = self.create(fallback_format, config)
        
        if instance is None:
            raise RuntimeError(f"无法创建存储实例，格式: {format_name}, 后备: {fallback_format}")
        
        return instance
    
    # ==================== 便捷方法 ====================
    
    @classmethod
    def get_instance(cls) -> 'StorageFactory':
        """获取工厂实例（单例）"""
        return cls()
    
    @classmethod
    def quick_create(
        cls,
        format_name: str,
        output_dir: str = "output",
        **kwargs
    ) -> Optional[StorageInterface]:
        """
        快速创建存储实例
        
        Args:
            format_name: 格式名称
            output_dir: 输出目录
            **kwargs: 其他配置选项
            
        Returns:
            存储实例
        """
        config = StorageConfig(output_dir=output_dir, **kwargs)
        return cls.get_instance().create(format_name, config)


# ==================== 全局函数 ====================

def get_storage_factory() -> StorageFactory:
    """获取存储工厂实例"""
    return StorageFactory.get_instance()


def create_storage(
    format_name: str,
    config: Optional[StorageConfig] = None
) -> Optional[StorageInterface]:
    """创建存储实例"""
    return get_storage_factory().create(format_name, config)


def list_available_formats() -> List[str]:
    """列出所有可用格式"""
    return get_storage_factory().get_available_formats()


def register_storage(storage_class: Type[StorageInterface]) -> bool:
    """注册存储格式"""
    return get_storage_factory().register(storage_class)
