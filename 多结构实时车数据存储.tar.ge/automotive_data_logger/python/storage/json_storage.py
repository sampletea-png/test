#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JSON存储格式实现
支持JSON Lines格式和JSON Array格式
"""

import json
import gzip
import bz2
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, TextIO
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)


class JSONStorage(StorageInterface):
    """
    JSON存储格式
    支持JSON Lines（每行一个JSON对象）和JSON Array格式
    支持GZIP/BZ2压缩
    """
    
    FORMAT_NAME = "json"
    DEFAULT_EXTENSION = "json"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = True
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        self._file: Optional[TextIO] = None
        self._format = self.config.options.get('format', 'lines')  # 'lines' 或 'array'
        self._first_write = True
        
        # 压缩处理
        self._compression = self.config.compression
        if self._compression and self._compression not in ['gzip', 'bz2']:
            logger.warning(f"不支持的压缩格式: {self._compression}，将使用无压缩")
            self._compression = None
        
        # 如果是array格式，需要特殊处理
        if self._format == 'array':
            self._records: List[Dict[str, Any]] = []
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建JSON文件"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            # 确保目录存在
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 确定文件模式
            mode = 'a' if self.config.append_mode else 'w'
            
            # 检查文件是否存在
            file_exists = file_path.exists() and file_path.stat().st_size > 0
            
            # 根据压缩类型打开文件
            if self._compression == 'gzip':
                actual_path = file_path.with_suffix('.json.gz')
                self._file = gzip.open(actual_path, f'{mode}t', encoding='utf-8')
                file_path = actual_path
                
            elif self._compression == 'bz2':
                actual_path = file_path.with_suffix('.json.bz2')
                self._file = bz2.open(actual_path, f'{mode}t', encoding='utf-8')
                file_path = actual_path
                
            else:
                self._file = open(file_path, mode, encoding='utf-8')
            
            # array格式特殊处理
            if self._format == 'array':
                if not file_exists or not self.config.append_mode:
                    # 新文件，写入数组开始
                    self._file.write('[\n')
                else:
                    # 追加模式需要特殊处理（简化：不支持追加到array格式）
                    logger.warning("JSON array格式不支持追加模式，将创建新文件")
                    self._file.close()
                    self._file = open(file_path, 'w', encoding='utf-8')
                    self._file.write('[\n')
            
            self._first_write = True
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开JSON文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            if self._file is None:
                logger.error("JSON文件未打开")
                return False
            
            if self._format == 'lines':
                # JSON Lines格式
                json_line = json.dumps(data, ensure_ascii=False, default=str)
                self._file.write(json_line + '\n')
                
            else:
                # JSON Array格式
                if not self._first_write:
                    self._file.write(',\n')
                json_line = json.dumps(data, ensure_ascii=False, default=str, indent=2)
                self._file.write(json_line)
                self._first_write = False
            
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入JSON数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            if self._file is None:
                logger.error("JSON文件未打开")
                return False
            
            if self._format == 'lines':
                # JSON Lines格式
                for data in data_list:
                    json_line = json.dumps(data, ensure_ascii=False, default=str)
                    self._file.write(json_line + '\n')
                    
            else:
                # JSON Array格式
                for i, data in enumerate(data_list):
                    if not self._first_write or i > 0:
                        self._file.write(',\n')
                    json_line = json.dumps(data, ensure_ascii=False, default=str, indent=2)
                    self._file.write(json_line)
                self._first_write = False
            
            # 刷新到磁盘
            self._file.flush()
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入JSON失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭JSON文件"""
        try:
            if self._file is None:
                return True
            
            # array格式需要写入数组结束
            if self._format == 'array':
                self._file.write('\n]\n')
            
            # 刷新到磁盘
            self._file.flush()
            
            # 关闭文件
            self._file.close()
            self._file = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭JSON文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
    
    def flush(self) -> bool:
        """强制刷新缓冲区到磁盘"""
        try:
            if self._file:
                self._file.flush()
            return True
        except Exception as e:
            logger.error(f"刷新JSON文件失败: {e}")
            return False
