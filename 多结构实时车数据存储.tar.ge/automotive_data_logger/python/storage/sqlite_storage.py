#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SQLite存储格式实现
支持关系型数据库存储，便于查询和分析
"""

import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)


class SQLiteStorage(StorageInterface):
    """
    SQLite存储格式
    支持关系型数据库存储，便于SQL查询
    """
    
    FORMAT_NAME = "sqlite"
    DEFAULT_EXTENSION = "db"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = False
    
    # 表结构定义
    TABLE_NAME = "vehicle_data"
    
    # 列定义
    COLUMNS = {
        'id': 'INTEGER PRIMARY KEY AUTOINCREMENT',
        'timestamp': 'INTEGER NOT NULL',
        'can_channel': 'INTEGER',
        'can_id': 'INTEGER',
        'vehicle_speed': 'REAL',
        'engine_rpm': 'REAL',
        'engine_temp': 'REAL',
        'throttle_position': 'REAL',
        'brake_position': 'REAL',
        'steering_angle': 'REAL',
        'battery_voltage': 'REAL',
        'fuel_level': 'REAL',
        'odometer': 'REAL',
        'accel_x': 'REAL',
        'accel_y': 'REAL',
        'accel_z': 'REAL',
        'created_at': 'DATETIME DEFAULT CURRENT_TIMESTAMP'
    }
    
    # 索引定义
    INDEXES = [
        ('idx_timestamp', ['timestamp']),
        ('idx_can_id', ['can_id']),
    ]
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        self._conn: Optional[sqlite3.Connection] = None
        self._cursor: Optional[sqlite3.Cursor] = None
        
        # 批量插入缓存
        self._insert_buffer: List[tuple] = []
        self._buffer_size = self.config.batch_size
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建SQLite数据库"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            # 确保目录存在
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 连接数据库
            self._conn = sqlite3.connect(str(file_path))
            self._conn.row_factory = sqlite3.Row
            self._cursor = self._conn.cursor()
            
            # 创建表（如果不存在）
            self._create_table()
            
            # 创建索引
            self._create_indexes()
            
            # 启用WAL模式（提高并发性能）
            self._cursor.execute("PRAGMA journal_mode=WAL")
            self._cursor.execute("PRAGMA synchronous=NORMAL")
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开SQLite数据库失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def _create_table(self):
        """创建数据表"""
        columns_def = ', '.join([f"{name} {dtype}" for name, dtype in self.COLUMNS.items()])
        create_sql = f"CREATE TABLE IF NOT EXISTS {self.TABLE_NAME} ({columns_def})"
        
        self._cursor.execute(create_sql)
        self._conn.commit()
        logger.debug(f"已创建表: {self.TABLE_NAME}")
    
    def _create_indexes(self):
        """创建索引"""
        for idx_name, columns in self.INDEXES:
            columns_str = ', '.join(columns)
            create_idx_sql = f"CREATE INDEX IF NOT EXISTS {idx_name} ON {self.TABLE_NAME} ({columns_str})"
            self._cursor.execute(create_idx_sql)
        
        self._conn.commit()
        logger.debug("已创建索引")
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            # 构建插入语句
            columns = [col for col in self.COLUMNS.keys() if col != 'id' and col != 'created_at']
            placeholders = ', '.join(['?' for _ in columns])
            columns_str = ', '.join(columns)
            
            insert_sql = f"INSERT INTO {self.TABLE_NAME} ({columns_str}) VALUES ({placeholders})"
            
            # 准备数据
            values = tuple(data.get(col, None) for col in columns)
            
            # 执行插入
            self._cursor.execute(insert_sql, values)
            self._conn.commit()
            
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入SQLite数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            # 构建插入语句
            columns = [col for col in self.COLUMNS.keys() if col != 'id' and col != 'created_at']
            placeholders = ', '.join(['?' for _ in columns])
            columns_str = ', '.join(columns)
            
            insert_sql = f"INSERT INTO {self.TABLE_NAME} ({columns_str}) VALUES ({placeholders})"
            
            # 准备批量数据
            values_list = [
                tuple(data.get(col, None) for col in columns)
                for data in data_list
            ]
            
            # 执行批量插入
            self._cursor.executemany(insert_sql, values_list)
            self._conn.commit()
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入SQLite失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭数据库连接"""
        try:
            if self._conn is None:
                return True
            
            # 刷新批量插入缓存
            if self._insert_buffer:
                self._flush_insert_buffer()
            
            # 关闭连接
            self._conn.close()
            self._conn = None
            self._cursor = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭SQLite数据库失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
    
    def _flush_insert_buffer(self):
        """刷新批量插入缓存"""
        if not self._insert_buffer:
            return
        
        try:
            columns = [col for col in self.COLUMNS.keys() if col != 'id' and col != 'created_at']
            placeholders = ', '.join(['?' for _ in columns])
            columns_str = ', '.join(columns)
            
            insert_sql = f"INSERT INTO {self.TABLE_NAME} ({columns_str}) VALUES ({placeholders})"
            
            self._cursor.executemany(insert_sql, self._insert_buffer)
            self._conn.commit()
            
            logger.debug(f"已刷新 {len(self._insert_buffer)} 条缓存数据")
            self._insert_buffer.clear()
            
        except Exception as e:
            logger.error(f"刷新插入缓存失败: {e}")
    
    # ==================== 查询方法 ====================
    
    def query(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """
        执行查询
        
        Args:
            sql: SQL查询语句
            params: 查询参数
            
        Returns:
            查询结果列表
        """
        try:
            self._cursor.execute(sql, params)
            rows = self._cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"查询失败: {e}")
            return []
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取数据统计信息"""
        try:
            stats = {}
            
            # 总记录数
            self._cursor.execute(f"SELECT COUNT(*) FROM {self.TABLE_NAME}")
            stats['total_records'] = self._cursor.fetchone()[0]
            
            # 时间范围
            self._cursor.execute(f"SELECT MIN(timestamp), MAX(timestamp) FROM {self.TABLE_NAME}")
            min_ts, max_ts = self._cursor.fetchone()
            stats['time_range'] = {'min': min_ts, 'max': max_ts}
            
            # 车速统计
            self._cursor.execute(f"""
                SELECT 
                    MIN(vehicle_speed), MAX(vehicle_speed), AVG(vehicle_speed)
                FROM {self.TABLE_NAME}
            """)
            min_speed, max_speed, avg_speed = self._cursor.fetchone()
            stats['speed_stats'] = {
                'min': min_speed,
                'max': max_speed,
                'avg': round(avg_speed, 2) if avg_speed else None
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"获取统计信息失败: {e}")
            return {}
