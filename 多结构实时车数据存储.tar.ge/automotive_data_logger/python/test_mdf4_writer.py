#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4写入服务测试脚本
用于验证Python服务是否正常工作
"""

import socket
import time
import random
import sys
from datetime import datetime


def generate_test_data():
    """生成测试数据"""
    timestamp = int(time.time() * 1000)
    return f"{timestamp},{random.randint(1,2)},{random.randint(256,512)}," \
           f"{random.uniform(0, 120):.2f},{random.uniform(800, 6000):.1f}," \
           f"{random.uniform(70, 110):.1f},{random.uniform(0, 100):.1f}," \
           f"{random.uniform(0, 100):.1f},{random.uniform(-45, 45):.1f}," \
           f"{random.uniform(11, 15):.2f},{random.uniform(0, 100):.1f}," \
           f"{random.uniform(10000, 20000):.1f}," \
           f"{random.uniform(-2, 2):.4f},{random.uniform(-2, 2):.4f},{random.uniform(8, 11):.4f}"


def test_mdf4_service():
    """测试MDF4服务"""
    print("=" * 50)
    print("MDF4写入服务测试")
    print("=" * 50)
    
    host = 'localhost'
    port = 9999
    
    # 创建socket连接
    print(f"\n[1/5] 连接到 {host}:{port}...")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((host, port))
        print("✓ 连接成功")
    except Exception as e:
        print(f"✗ 连接失败: {e}")
        print("\n请确保Python MDF4服务已启动:")
        print("  python mdf4_writer_service.py")
        return False
    
    # 接收就绪响应
    print("\n[2/5] 等待服务就绪...")
    try:
        response = sock.recv(1024).decode('utf-8').strip()
        if response == "READY":
            print("✓ 服务已就绪")
        else:
            print(f"✗ 服务未就绪: {response}")
            return False
    except Exception as e:
        print(f"✗ 接收响应失败: {e}")
        return False
    
    # 发送初始化命令
    print("\n[3/5] 发送初始化命令...")
    try:
        sock.sendall(b"INIT\n")
        response = sock.recv(1024).decode('utf-8').strip()
        if response == "READY":
            print("✓ 初始化成功")
        else:
            print(f"✗ 初始化失败: {response}")
            return False
    except Exception as e:
        print(f"✗ 初始化异常: {e}")
        return False
    
    # 发送CSV头
    print("\n[4/5] 发送CSV头...")
    header = "timestamp,can_channel,can_id,vehicle_speed,engine_rpm,engine_temp," \
             "throttle_position,brake_position,steering_angle,battery_voltage," \
             "fuel_level,odometer,accel_x,accel_y,accel_z"
    try:
        sock.sendall(f"HEADER:{header}\n".encode('utf-8'))
        print("✓ CSV头已发送")
    except Exception as e:
        print(f"✗ 发送CSV头失败: {e}")
        return False
    
    # 发送测试数据
    print("\n[5/5] 发送测试数据 (100条)...")
    try:
        for i in range(100):
            data = generate_test_data()
            sock.sendall(f"DATA:{data}\n".encode('utf-8'))
            
            if (i + 1) % 20 == 0:
                print(f"  已发送 {i + 1}/100 条数据")
            
            time.sleep(0.01)  # 100Hz
        
        print("✓ 测试数据发送完成")
    except Exception as e:
        print(f"✗ 发送数据失败: {e}")
        return False
    
    # 发送关闭命令
    print("\n[6/5] 发送关闭命令...")
    try:
        sock.sendall(b"CLOSE\n")
        print("✓ 关闭命令已发送")
    except Exception as e:
        print(f"✗ 发送关闭命令失败: {e}")
    
    # 关闭连接
    sock.close()
    print("\n" + "=" * 50)
    print("测试完成!")
    print("=" * 50)
    print("\n请检查 output/ 目录下是否生成了MDF4文件")
    
    return True


def main():
    """主函数"""
    if len(sys.argv) > 1 and sys.argv[1] == '--help':
        print("用法: python test_mdf4_writer.py")
        print("\n此脚本用于测试MDF4写入服务是否正常工作")
        print("请确保先启动服务: python mdf4_writer_service.py")
        return
    
    success = test_mdf4_service()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
