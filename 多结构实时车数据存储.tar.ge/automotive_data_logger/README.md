# 汽车数据实时记录系统 (多格式支持)

一个基于Java和Python的实时汽车数据记录工具，支持多种存储格式（MDF4、CSV、JSON、SQLite、Parquet），可通过弹窗展示实时数据并动态切换存储格式。

## 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Java 应用程序                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ 数据模拟器    │  │  实时GUI弹窗  │  │  多格式存储客户端 │  │
│  │ (100Hz)      │  │  (Swing)     │  │   (Socket)       │  │
│  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘  │
│         │                 │                    │            │
│         └─────────────────┴────────────────────┘            │
│                           │                                 │
│                    数据分发 (VehicleData)                    │
└───────────────────────────┼─────────────────────────────────┘
                            │ Socket (TCP)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   Python 服务程序                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ Socket服务器  │  │  存储工厂     │  │  多格式存储器    │  │
│  │  (端口9999)   │  │  (动态切换)   │  │  (策略模式)      │  │
│  └──────────────┘  └──────────────┘  └────────┬─────────┘  │
│                                               │             │
│                    ┌──────────────────────────┼──────────┐  │
│                    │                          │          │  │
│                    ▼                          ▼          ▼  │
│              ┌─────────┐  ┌─────────┐  ┌─────────┐         │
│              │  MDF4   │  │   CSV   │  │  JSON   │         │
│              │  SQLite │  │ Parquet │  │  ...    │         │
│              └─────────┘  └─────────┘  └─────────┘         │
└─────────────────────────────────────────────────────────────┘
```

## 功能特性

### 多格式存储支持

| 格式 | 扩展名 | 特点 | 适用场景 |
|------|--------|------|----------|
| **MDF4** | .mf4 | ASAM标准，行业通用 | 汽车测试、Vector工具链 |
| **CSV** | .csv | 通用格式，易读易处理 | 数据分析、Excel处理 |
| **JSON** | .json | 结构化数据，Web友好 | Web应用、API集成 |
| **SQLite** | .db | 关系型数据库，支持SQL查询 | 数据查询、复杂分析 |
| **Parquet** | .parquet | 列式存储，高效压缩 | 大数据、机器学习 |

### 动态格式切换
- 运行时切换存储格式，无需重启
- 自动创建新文件，保持数据完整性
- 实时显示当前格式和文件大小

### 数据模拟
- **频率**: 100Hz (每10ms一个数据点)
- **信号**: 车速、发动机转速、温度、油门/刹车位置、方向盘角度、电池电压、燃油液位、三轴加速度等

### 实时展示
- **GUI弹窗**: 现代化深色主题界面
- **实时更新**: 100ms刷新频率
- **统计信息**: 记录时长、数据条数、发送速率、队列大小、文件大小

## 环境要求

### Java环境
- **JDK**: 11 或更高版本
- **Maven**: 3.6+ (用于编译)

### Python环境
- **Python**: 3.8 或更高版本
- **核心依赖**:
  ```bash
  pip install asammdf numpy
  ```
- **可选依赖** (Parquet支持):
  ```bash
  pip install pyarrow
  ```

## 项目结构

```
automotive_data_logger/
├── README.md                    # 本文件
├── QUICK_START.md              # 快速开始指南
├── start_service.sh            # Linux/Mac启动脚本
├── start_service.bat           # Windows启动脚本
├── docs/
│   └── ARCHITECTURE.md         # 系统架构文档
├── java/
│   ├── pom.xml                 # Maven配置
│   └── src/main/java/com/automotive/logger/
│       ├── model/VehicleData.java
│       ├── service/DataSimulatorService.java
│       ├── communication/StorageFormatClient.java  # 多格式客户端
│       └── gui/RealTimeDataDisplay.java
├── python/
│   ├── requirements.txt
│   ├── multi_format_writer_service.py              # 多格式服务
│   ├── storage/                                    # 存储模块
│   │   ├── __init__.py
│   │   ├── base.py                                 # 存储接口基类
│   │   ├── factory.py                              # 存储工厂
│   │   ├── mdf4_storage.py                         # MDF4实现
│   │   ├── csv_storage.py                          # CSV实现
│   │   ├── json_storage.py                         # JSON实现
│   │   ├── sqlite_storage.py                       # SQLite实现
│   │   └── parquet_storage.py                      # Parquet实现
│   ├── test_mdf4_writer.py
│   └── read_mdf4.py
└── output/                      # 输出文件目录
```

## 快速开始

### 1. 安装依赖

```bash
# 核心依赖
pip install asammdf numpy

# 可选：Parquet支持
pip install pyarrow
```

### 2. 编译Java项目

```bash
cd java
mvn clean package
cd ..
```

### 3. 启动系统

**Linux/Mac:**
```bash
chmod +x start_service.sh
./start_service.sh
```

**Windows:**
```cmd
start_service.bat
```

### 4. 使用界面

1. 点击 **"开始记录"** 按钮
2. 从下拉框选择存储格式
3. 点击 **"切换格式"** 按钮可动态切换
4. 点击 **"停止记录"** 按钮结束

## 扩展新的存储格式

### 1. 创建存储实现类

```python
# python/storage/myformat_storage.py
from .base import StorageInterface, StorageConfig

class MyFormatStorage(StorageInterface):
    FORMAT_NAME = "myformat"
    DEFAULT_EXTENSION = "my"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = False
    
    def open(self, file_path=None):
        # 实现打开/创建文件逻辑
        pass
    
    def write(self, data):
        # 实现单条数据写入
        pass
    
    def write_batch(self, data_list):
        # 实现批量写入
        pass
    
    def close(self):
        # 实现关闭文件
        pass
    
    def get_file_size(self):
        # 返回文件大小
        return 0
```

### 2. 注册新格式

```python
# 在 storage/__init__.py 中添加
from .myformat_storage import MyFormatStorage

# 在工厂中自动注册
# 或在运行时动态注册
from storage import register_storage
register_storage(MyFormatStorage)
```

### 3. 使用新格式

```bash
# 启动时指定默认格式
python multi_format_writer_service.py --format myformat

# 或通过GUI动态切换
```

## 存储配置选项

通过Java客户端或Python服务参数配置：

```python
config = StorageConfig(
    output_dir="output",              # 输出目录
    filename_prefix="vehicle_data",   # 文件名前缀
    batch_size=100,                   # 批量写入大小
    max_file_size_mb=100,             # 文件大小限制
    split_interval_minutes=0,         # 时间分割间隔
    compression=None,                 # 压缩选项 (gzip, bz2)
    options={}                        # 格式特定选项
)
```

## 通信协议

### 命令列表

| 命令 | 参数 | 说明 |
|------|------|------|
| `INIT` | `[format]` | 初始化存储，可选指定格式 |
| `FORMAT` | `<format>` | 切换存储格式 |
| `CONFIG` | `<json>` | 更新配置 |
| `HEADER` | `<csv_header>` | 发送CSV头 |
| `DATA` | `<csv_data>` | 发送数据 |
| `FLUSH` | - | 强制刷新缓冲区 |
| `INFO` | - | 获取存储信息 |
| `CLOSE` | - | 关闭存储 |

### 响应格式

```json
{
  "status": "OK|ERROR|READY",
  "data": { ... }
}
```

## 故障排除

### 端口被占用

```bash
# Linux/Mac
lsof -i :9999
kill -9 <PID>

# Windows
netstat -ano | findstr :9999
taskkill /F /PID <PID>
```

### 格式不可用

```bash
# 检查可用格式
python -c "from storage import list_available_formats; print(list_available_formats())"
```

### 依赖问题

```bash
# 重新安装依赖
pip install --upgrade asammdf numpy

# 安装Parquet支持
pip install pyarrow
```

## 性能对比

| 格式 | 写入速度 | 文件大小 | 查询速度 | 兼容性 |
|------|----------|----------|----------|--------|
| MDF4 | ★★★★☆ | ★★★☆☆ | ★★☆☆☆ | ★★★★★ |
| CSV | ★★★☆☆ | ★☆☆☆☆ | ★☆☆☆☆ | ★★★★★ |
| JSON | ★★★☆☆ | ★☆☆☆☆ | ★★☆☆☆ | ★★★★☆ |
| SQLite | ★★☆☆☆ | ★★★★☆ | ★★★★★ | ★★★☆☆ |
| Parquet | ★★★★★ | ★★★★★ | ★★★★☆ | ★★☆☆☆ |

## 许可证

MIT License

## 参考资源

- [ASAM MDF标准](https://www.asam.net/standards/detail/mdf/)
- [asammdf文档](https://asammdf.readthedocs.io/)
- [Parquet格式](https://parquet.apache.org/)
