# 扩展开发指南

本指南介绍如何为汽车数据记录系统扩展新的存储格式。

## 架构概述

系统采用**策略模式**和**工厂模式**实现存储格式的可插拔架构：

```
┌─────────────────────────────────────────────────────────────┐
│                      StorageInterface                        │
│                      (抽象接口)                               │
└────────────────────────────┬────────────────────────────────┘
                             │ 实现
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│  MDF4Storage  │   │  CSVStorage   │   │  YourStorage  │
│  (MDF4格式)    │   │  (CSV格式)    │   │  (自定义格式)  │
└───────────────┘   └───────────────┘   └───────────────┘
        │                    │                    │
        └────────────────────┼────────────────────┘
                             │ 注册
                             ▼
                    ┌─────────────────┐
                    │  StorageFactory │
                    │    (存储工厂)    │
                    └─────────────────┘
```

## 快速开始：添加新存储格式

### 步骤1：创建存储类

在 `python/storage/` 目录下创建新的存储实现类：

```python
# python/storage/hdf5_storage.py

import h5py
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)


class HDF5Storage(StorageInterface):
    """
    HDF5存储格式示例
    适合科学计算和大数据存储
    """
    
    # 格式标识
    FORMAT_NAME = "hdf5"
    DEFAULT_EXTENSION = "h5"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = True
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        # 检查依赖
        try:
            import h5py
        except ImportError:
            raise ImportError("h5py库未安装，请运行: pip install h5py")
        
        self._file: Optional[h5py.File] = None
        self._datasets: Dict[str, Any] = {}
        
        # 压缩设置
        self._compression = self.config.compression
        if self._compression == 'gzip':
            self._compression_opts = 4  # 压缩级别
        else:
            self._compression = None
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        """打开/创建HDF5文件"""
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 打开HDF5文件
            mode = 'a' if self.config.append_mode else 'w'
            self._file = h5py.File(file_path, mode)
            
            # 创建数据集组
            if 'vehicle_data' not in self._file:
                self._file.create_group('vehicle_data')
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开HDF5文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        """写入单条数据"""
        try:
            group = self._file['vehicle_data']
            
            # 为每个字段创建/扩展数据集
            for key, value in data.items():
                if key not in group:
                    # 创建新数据集
                    dtype = 'f8' if isinstance(value, float) else 'i8'
                    group.create_dataset(
                        key,
                        shape=(0,),
                        maxshape=(None,),
                        dtype=dtype,
                        compression=self._compression,
                        chunks=True
                    )
                
                # 追加数据
                dataset = group[key]
                dataset.resize(dataset.shape[0] + 1, axis=0)
                dataset[-1] = value
            
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入HDF5数据失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        """批量写入数据"""
        try:
            group = self._file['vehicle_data']
            
            # 按字段组织数据
            field_data: Dict[str, List] = {}
            for data in data_list:
                for key, value in data.items():
                    if key not in field_data:
                        field_data[key] = []
                    field_data[key].append(value)
            
            # 批量写入每个字段
            for key, values in field_data.items():
                if key not in group:
                    dtype = 'f8' if isinstance(values[0], float) else 'i8'
                    group.create_dataset(
                        key,
                        shape=(0,),
                        maxshape=(None,),
                        dtype=dtype,
                        compression=self._compression,
                        chunks=True
                    )
                
                dataset = group[key]
                current_size = dataset.shape[0]
                new_size = current_size + len(values)
                dataset.resize(new_size, axis=0)
                dataset[current_size:] = values
            
            self._file.flush()
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入HDF5失败: {e}")
            return False
    
    def close(self) -> bool:
        """关闭HDF5文件"""
        try:
            if self._file is None:
                return True
            
            self._file.close()
            self._file = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭HDF5文件失败: {e}")
            self._info.errors.append(str(e))
            return False
    
    def get_file_size(self) -> int:
        """获取文件大小"""
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
```

### 步骤2：注册新格式

编辑 `python/storage/__init__.py`：

```python
from .hdf5_storage import HDF5Storage

__all__ = [
    # ... 其他导出
    'HDF5Storage',
]
```

格式会自动被 `StorageFactory` 注册。

### 步骤3：测试新格式

```bash
# 启动服务时指定新格式
python python/multi_format_writer_service.py --format hdf5

# 或通过GUI动态切换
```

## 存储接口详解

### StorageInterface 抽象方法

| 方法 | 说明 | 必需 |
|------|------|------|
| `open(file_path)` | 打开/创建存储文件 | ✓ |
| `write(data)` | 写入单条数据 | ✓ |
| `write_batch(data_list)` | 批量写入数据 | ✓ |
| `close()` | 关闭存储文件 | ✓ |
| `get_file_size()` | 获取文件大小 | ✓ |

### 类属性

| 属性 | 说明 | 示例 |
|------|------|------|
| `FORMAT_NAME` | 格式名称（小写） | `"csv"` |
| `DEFAULT_EXTENSION` | 默认文件扩展名 | `"csv"` |
| `SUPPORTS_APPEND` | 是否支持追加模式 | `True` |
| `SUPPORTS_COMPRESSION` | 是否支持压缩 | `True` |

### 辅助方法

基类提供以下辅助方法：

```python
# 添加数据到缓冲区（自动批量写入）
self.add_data(data)

# 强制刷新缓冲区
self.flush()

# 获取存储信息
self.get_info()

# 添加状态回调
self.add_status_callback(callback)
```

### 生命周期回调

```python
# 文件打开后调用
self._on_open(file_path)

# 文件关闭后调用
self._on_close()

# 数据写入后调用
self._on_write(count)
```

## 配置选项

### StorageConfig 属性

```python
config = StorageConfig(
    output_dir="output",              # 输出目录
    filename_prefix="vehicle_data",   # 文件名前缀
    file_extension="csv",             # 文件扩展名（可选）
    batch_size=100,                   # 批量写入大小
    append_mode=False,                # 是否追加模式
    max_file_size_mb=100,             # 文件大小限制
    split_interval_minutes=0,         # 时间分割间隔
    compression=None,                 # 压缩选项
    options={},                       # 格式特定选项
    metadata={}                       # 元数据
)
```

### 格式特定选项

可以在 `options` 中传递格式特定的配置：

```python
# CSV格式选项
config.options = {
    'delimiter': ',',      # 分隔符
    'quotechar': '"',      # 引号字符
    'lineterminator': '\n' # 行终止符
}

# JSON格式选项
config.options = {
    'format': 'lines',     # 'lines' 或 'array'
    'indent': 2            # 缩进空格数
}
```

## 高级功能

### 文件分割

当文件达到指定大小或时间间隔时自动分割：

```python
# 在存储类中重写 _should_split_file 方法
def _should_split_file(self) -> bool:
    # 自定义分割逻辑
    if self.config.max_file_size_mb > 0:
        current_size_mb = self.get_file_size() / (1024 * 1024)
        if current_size_mb >= self.config.max_file_size_mb:
            return True
    return False
```

### 压缩支持

```python
# 检查压缩选项
if self.config.compression == 'gzip':
    # 使用gzip压缩
    import gzip
    self._file = gzip.open(file_path, 'wt')
elif self.config.compression == 'bz2':
    # 使用bz2压缩
    import bz2
    self._file = bz2.open(file_path, 'wt')
```

### 自定义查询方法

对于数据库类存储，可以添加查询方法：

```python
class SQLiteStorage(StorageInterface):
    # ... 标准方法
    
    def query(self, sql: str, params: tuple = ()) -> List[Dict]:
        """执行SQL查询"""
        self._cursor.execute(sql, params)
        rows = self._cursor.fetchall()
        return [dict(row) for row in rows]
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        # 实现统计查询
        pass
```

## 最佳实践

### 1. 错误处理

```python
def write(self, data: Dict[str, Any]) -> bool:
    try:
        # 写入逻辑
        return True
    except SpecificException as e:
        logger.error(f"特定错误: {e}")
        return False
    except Exception as e:
        logger.error(f"未知错误: {e}")
        self._info.errors.append(str(e))
        return False
```

### 2. 资源管理

```python
def close(self) -> bool:
    try:
        if self._file is not None:
            self._file.close()
            self._file = None
        return True
    except Exception as e:
        logger.error(f"关闭失败: {e}")
        return False
```

### 3. 性能优化

```python
def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
    # 批量操作比单条操作更高效
    # 使用事务（数据库）
    # 使用缓冲区（文件）
    pass
```

### 4. 日志记录

```python
import logging
logger = logging.getLogger(__name__)

# 使用适当的日志级别
logger.debug("调试信息")
logger.info("一般信息")
logger.warning("警告信息")
logger.error("错误信息")
```

## 完整示例：Excel存储格式

```python
# python/storage/excel_storage.py

from pathlib import Path
from typing import Dict, Any, List, Optional
import logging

from .base import StorageInterface, StorageConfig

logger = logging.getLogger(__name__)

try:
    import openpyxl
    from openpyxl import Workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


class ExcelStorage(StorageInterface):
    """Excel存储格式 (XLSX)"""
    
    FORMAT_NAME = "excel"
    DEFAULT_EXTENSION = "xlsx"
    SUPPORTS_APPEND = True
    SUPPORTS_COMPRESSION = False
    
    # 最大行数限制 (Excel限制约100万行)
    MAX_ROWS = 1000000
    
    def __init__(self, config: Optional[StorageConfig] = None):
        super().__init__(config)
        
        if not OPENPYXL_AVAILABLE:
            raise ImportError("openpyxl库未安装，请运行: pip install openpyxl")
        
        self._workbook: Optional[Workbook] = None
        self._worksheet = None
        self._current_row = 1
        
        # 列定义
        self._columns = [
            'timestamp', 'can_channel', 'can_id',
            'vehicle_speed', 'engine_rpm', 'engine_temp',
            'throttle_position', 'brake_position', 'steering_angle',
            'battery_voltage', 'fuel_level', 'odometer',
            'accel_x', 'accel_y', 'accel_z'
        ]
    
    def open(self, file_path: Optional[Path] = None) -> bool:
        try:
            if file_path is None:
                file_path = self.config.get_output_path()
            
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 检查是否追加
            if self.config.append_mode and file_path.exists():
                self._workbook = openpyxl.load_workbook(file_path)
                self._worksheet = self._workbook.active
                self._current_row = self._worksheet.max_row + 1
            else:
                self._workbook = Workbook()
                self._worksheet = self._workbook.active
                self._worksheet.title = "Vehicle Data"
                
                # 写入表头
                for col, header in enumerate(self._columns, 1):
                    self._worksheet.cell(1, col, header)
                
                self._current_row = 2
            
            self._on_open(file_path)
            return True
            
        except Exception as e:
            logger.error(f"打开Excel文件失败: {e}")
            return False
    
    def write(self, data: Dict[str, Any]) -> bool:
        try:
            # 检查行数限制
            if self._current_row >= self.MAX_ROWS:
                logger.warning("达到Excel行数限制，创建新文件")
                self._split_file()
            
            for col, field in enumerate(self._columns, 1):
                value = data.get(field, '')
                self._worksheet.cell(self._current_row, col, value)
            
            self._current_row += 1
            self._on_write(1)
            return True
            
        except Exception as e:
            logger.error(f"写入Excel失败: {e}")
            return False
    
    def write_batch(self, data_list: List[Dict[str, Any]]) -> bool:
        try:
            for data in data_list:
                if self._current_row >= self.MAX_ROWS:
                    self._split_file()
                
                for col, field in enumerate(self._columns, 1):
                    value = data.get(field, '')
                    self._worksheet.cell(self._current_row, col, value)
                
                self._current_row += 1
            
            # 保存
            self._workbook.save(self._info.file_path)
            
            self._on_write(len(data_list))
            return True
            
        except Exception as e:
            logger.error(f"批量写入Excel失败: {e}")
            return False
    
    def close(self) -> bool:
        try:
            if self._workbook and self._info.file_path:
                self._workbook.save(self._info.file_path)
                self._workbook.close()
            
            self._workbook = None
            self._worksheet = None
            
            self._on_close()
            return True
            
        except Exception as e:
            logger.error(f"关闭Excel文件失败: {e}")
            return False
    
    def get_file_size(self) -> int:
        if self._info.file_path and self._info.file_path.exists():
            return self._info.file_path.stat().st_size
        return 0
```

## 测试新格式

```python
# test_new_storage.py

from storage import StorageFactory, StorageConfig

def test_storage(format_name: str):
    """测试存储格式"""
    factory = StorageFactory()
    
    config = StorageConfig(
        output_dir="test_output",
        batch_size=10
    )
    
    storage = factory.create(format_name, config)
    
    if storage is None:
        print(f"无法创建 {format_name} 存储")
        return
    
    # 测试数据
    test_data = {
        'timestamp': 1699123456789,
        'vehicle_speed': 65.5,
        'engine_rpm': 2500.0,
        # ... 其他字段
    }
    
    # 测试写入
    storage.open()
    for i in range(100):
        test_data['timestamp'] += 10
        storage.add_data(test_data)
    
    storage.close()
    
    info = storage.get_info()
    print(f"测试完成: {info.record_count} 条记录")
    print(f"文件大小: {info.file_size_mb:.2f} MB")

if __name__ == "__main__":
    test_storage("hdf5")
```

## 常见问题

### Q: 如何处理大文件？

A: 使用文件分割功能：
```python
config.max_file_size_mb = 100  # 100MB分割
config.split_interval_minutes = 60  # 1小时分割
```

### Q: 如何添加元数据？

A: 在配置中设置：
```python
config.metadata = {
    'vehicle_id': 'VIN123456',
    'test_name': 'Highway Test',
    'driver': 'John Doe'
}
```

### Q: 如何实现增量备份？

A: 使用追加模式：
```python
config.append_mode = True
```

## 参考实现

查看现有实现获取灵感：
- `mdf4_storage.py` - 复杂二进制格式
- `csv_storage.py` - 简单文本格式
- `sqlite_storage.py` - 数据库存储
- `json_storage.py` - JSON格式
