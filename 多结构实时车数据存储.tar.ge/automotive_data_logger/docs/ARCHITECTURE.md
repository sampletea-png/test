# 系统架构文档 (多格式版本)

## 概述

汽车数据实时记录系统采用**Java + Python混合架构**，通过**策略模式**实现多种存储格式的可插拔支持。系统支持MDF4、CSV、JSON、SQLite、Parquet等多种格式，并可在运行时动态切换。

## 架构设计原则

### 1. 开闭原则 (Open/Closed Principle)
- **对扩展开放**：通过实现 `StorageInterface` 接口添加新格式
- **对修改关闭**：现有代码无需修改即可支持新格式

### 2. 单一职责原则 (Single Responsibility Principle)
- 每个存储类只负责一种格式的读写
- 工厂类只负责创建存储实例
- 服务类只负责协调通信

### 3. 依赖倒置原则 (Dependency Inversion Principle)
- 高层模块依赖抽象接口 (`StorageInterface`)
- 低层模块实现抽象接口

## 系统架构图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              数据流架构                                      │
└─────────────────────────────────────────────────────────────────────────────┘

    ┌─────────────┐
    │  数据源      │  ← 真实CAN总线 / 模拟数据 (100Hz)
    │ (CAN Bus)   │
    └──────┬──────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Java 应用程序                                      │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                        数据层 (Model)                                 │  │
│  │                    VehicleData.java                                   │  │
│  │  - 统一数据模型，包含所有车辆信号                                       │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                    ▲                                        │
│                                    │                                        │
│  ┌─────────────────────────────────┴────────────────────────────────────┐  │
│  │                        服务层 (Service)                               │  │
│  │                                                                       │  │
│  │  ┌─────────────────────┐      ┌─────────────────────────────────┐    │  │
│  │  │  DataSimulator      │      │  StorageFormatClient            │    │  │
│  │  │  ─────────────────  │      │  ─────────────────────────────  │    │  │
│  │  │  - 100Hz数据生成    │─────▶│  - Socket连接管理               │    │  │
│  │  │  - 随机波动模拟     │      │  - 多格式支持                   │    │  │
│  │  │  - 趋势变化模拟     │      │  - 格式动态切换                 │    │  │
│  │  │  - 多监听器支持     │      │  - 发送速率统计                 │    │  │
│  │  └─────────────────────┘      │  - 状态监听器                   │    │  │
│  │                               └─────────────────────────────────┘    │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                    │                                        │
│  ┌─────────────────────────────────┴────────────────────────────────────┐  │
│  │                        表现层 (GUI)                                   │  │
│  │                    RealTimeDataDisplay.java                           │  │
│  │  - 实时数据显示面板                                                   │  │
│  │  - 格式选择下拉框                                                     │  │
│  │  - 开始/停止/切换格式按钮                                             │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Socket (TCP) + JSON协议
                                    │ 端口: 9999
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Python 服务程序                                     │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    MultiFormatWriterService                           │  │
│  │  - Socket服务器 (端口9999)                                            │  │
│  │  - 协议解析 (INIT, FORMAT, DATA, etc.)                                │  │
│  │  - 命令分发                                                           │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                    │                                        │
│                                    ▼                                        │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                      StorageFactory (单例)                            │  │
│  │  - 存储格式注册                                                       │  │
│  │  - 实例创建                                                           │  │
│  │  - 格式发现                                                           │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                    │                                        │
│                    ┌───────────────┼───────────────┐                        │
│                    │               │               │                        │
│                    ▼               ▼               ▼                        │
│  ┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐   │
│  │   StorageInterface  │ │   StorageInterface  │ │   StorageInterface  │   │
│  │   (抽象接口)         │ │   (抽象接口)         │ │   (抽象接口)         │   │
│  │                     │ │                     │ │                     │   │
│  │  + open()           │ │  + open()           │ │  + open()           │   │
│  │  + write()          │ │  + write()          │ │  + write()          │   │
│  │  + write_batch()    │ │  + write_batch()    │ │  + write_batch()    │   │
│  │  + close()          │ │  + close()          │ │  + close()          │   │
│  └──────────┬──────────┘ └──────────┬──────────┘ └──────────┬──────────┘   │
│             │                       │                       │              │
│             ▼                       ▼                       ▼              │
│  ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐           │
│  │   MDF4Storage   │   │   CSVStorage    │   │  SQLiteStorage  │           │
│  │   (asammdf)     │   │   (标准库)       │   │   (sqlite3)     │           │
│  └─────────────────┘   └─────────────────┘   └─────────────────┘           │
│                                                                             │
│  ┌─────────────────┐   ┌─────────────────┐                                  │
│  │  JSONStorage    │   │ ParquetStorage  │                                  │
│  │   (标准库)       │   │   (pyarrow)     │                                  │
│  └─────────────────┘   └─────────────────┘                                  │
│                                                                             │
│                    (可扩展更多格式...)                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
│                        output/*.mf4, *.csv, *.db, etc.                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 核心组件

### 1. 存储接口 (StorageInterface)

```python
class StorageInterface(ABC):
    """存储抽象接口 - 所有存储格式必须实现"""
    
    # 类属性
    FORMAT_NAME: str           # 格式名称
    DEFAULT_EXTENSION: str     # 默认扩展名
    SUPPORTS_APPEND: bool      # 是否支持追加
    SUPPORTS_COMPRESSION: bool # 是否支持压缩
    
    # 抽象方法
    @abstractmethod
    def open(self, file_path) -> bool: ...
    
    @abstractmethod
    def write(self, data: Dict) -> bool: ...
    
    @abstractmethod
    def write_batch(self, data_list: List[Dict]) -> bool: ...
    
    @abstractmethod
    def close(self) -> bool: ...
    
    @abstractmethod
    def get_file_size(self) -> int: ...
```

### 2. 存储工厂 (StorageFactory)

```python
class StorageFactory:
    """存储工厂 - 单例模式管理所有存储格式"""
    
    def register(self, storage_class: Type[StorageInterface]) -> bool
    def create(self, format_name: str, config: StorageConfig) -> StorageInterface
    def get_available_formats(self) -> List[str]
```

### 3. 存储配置 (StorageConfig)

```python
@dataclass
class StorageConfig:
    output_dir: str = "output"
    filename_prefix: str = "vehicle_data"
    batch_size: int = 100
    max_file_size_mb: float = 100.0
    split_interval_minutes: int = 0
    compression: Optional[str] = None
    options: Dict[str, Any] = field(default_factory=dict)
```

## 设计模式应用

### 策略模式 (Strategy Pattern)

```
┌─────────────────────────────────────┐
│         StorageInterface            │
│         (策略接口)                   │
└──────────────┬──────────────────────┘
               │
    ┌──────────┼──────────┐
    │          │          │
    ▼          ▼          ▼
┌───────┐  ┌───────┐  ┌───────┐
│ MDF4  │  │  CSV  │  │  ...  │
│策略   │  │ 策略  │  │ 策略  │
└───────┘  └───────┘  └───────┘
```

**应用场景**：
- 运行时动态切换存储格式
- 添加新格式不影响现有代码

### 工厂模式 (Factory Pattern)

```
┌──────────────────┐
│  StorageFactory  │
│  (工厂类)        │
│  ─────────────── │
│  + create()      │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ StorageInterface │
│ (产品接口)        │
└──────────────────┘
```

**应用场景**：
- 统一创建存储实例
- 隐藏具体实现细节

### 观察者模式 (Observer Pattern)

```
┌─────────────────┐     ┌─────────────────┐
│  StorageInterface│◄────│ StatusListener  │
│  (被观察者)      │     │  (观察者)        │
└─────────────────┘     └─────────────────┘
         │
         │ notify
         ▼
┌─────────────────┐
│   GUI Update    │
└─────────────────┘
```

**应用场景**：
- 存储状态变化时更新GUI
- 格式切换时通知界面

## 通信协议

### 消息格式

所有消息使用JSON格式：

**请求：**
```json
{
  "command": "FORMAT",
  "parameter": "csv"
}
```

**响应：**
```json
{
  "status": "OK",
  "data": {
    "format": "csv",
    "file_path": "output/vehicle_data_20240101_120000.csv"
  }
}
```

### 命令列表

| 命令 | 参数 | 响应 | 说明 |
|------|------|------|------|
| `INIT` | `[format]` | `READY`/`ERROR` | 初始化存储 |
| `FORMAT` | `<format>` | `OK`/`ERROR` | 切换格式 |
| `CONFIG` | `<json>` | `OK`/`ERROR` | 更新配置 |
| `HEADER` | `<csv>` | - | 设置CSV头 |
| `DATA` | `<csv>` | `OK`/`ERROR` | 发送数据 |
| `FLUSH` | - | `OK` | 强制刷新 |
| `INFO` | - | `OK` | 获取信息 |
| `CLOSE` | - | `OK` | 关闭存储 |
| `PING` | - | `PONG` | 心跳检测 |

## 数据流时序

### 正常记录流程

```
Java客户端              Python服务              存储器
    │                       │                    │
    │──── INIT:mdf4 ───────▶│                    │
    │◄──────── READY ───────│                    │
    │                       │──── create() ─────▶│
    │                       │◄─── StorageInst ───│
    │                       │                    │
    │──── HEADER:... ──────▶│                    │
    │                       │                    │
    │──── DATA:... ────────▶│                    │
    │◄──────── OK ──────────│                    │
    │                       │──── add_data() ───▶│
    │                       │                    │(缓冲)
    │──── DATA:... ────────▶│                    │
    │◄──────── OK ──────────│                    │
    │                       │──── add_data() ───▶│
    │                       │                    │(缓冲满)
    │                       │◄──── flush() ──────│
    │                       │                    │──┐
    │                       │                    │  │ 写入文件
    │                       │                    │◄─┘
    │                       │                    │
    │──── CLOSE ───────────▶│                    │
    │◄──────── OK ──────────│                    │
    │                       │──── close() ──────▶│
    │                       │                    │──┐
    │                       │                    │  │ 保存文件
    │                       │                    │◄─┘
```

### 格式切换流程

```
Java客户端              Python服务              旧存储器           新存储器
    │                       │                    │                  │
    │──── FORMAT:csv ──────▶│                    │                  │
    │                       │──── close() ──────▶│                  │
    │                       │                    │──┐               │
    │                       │                    │  │ 保存文件       │
    │                       │                    │◄─┘               │
    │                       │                                     │
    │                       │──── create() ──────────────────────▶│
    │                       │◄──── StorageInst ───────────────────│
    │                       │                                     │
    │◄──────── OK ──────────│                                     │
    │                       │                                     │
    │──── DATA:... ────────▶│                                     │
    │                       │──── add_data() ────────────────────▶│
```

## 扩展性设计

### 添加新格式的步骤

1. **实现接口**
```python
class NewFormatStorage(StorageInterface):
    FORMAT_NAME = "newformat"
    DEFAULT_EXTENSION = "new"
    
    def open(self, file_path): ...
    def write(self, data): ...
    def write_batch(self, data_list): ...
    def close(self): ...
    def get_file_size(self): ...
```

2. **注册格式**
```python
# 自动注册
from storage import register_storage
register_storage(NewFormatStorage)
```

3. **使用格式**
```python
# 动态切换
storageClient.switchFormat("newformat")
```

### 扩展示例

```
新增格式: AvroStorage (Apache Avro)
├── 实现 StorageInterface
├── 添加依赖: pip install fastavro
├── 注册到工厂
└── 无需修改现有代码
```

## 性能优化

### 批量写入

```python
# 缓冲区设计
self._data_buffer: List[Dict] = []
self._batch_size = 100

def add_data(self, data):
    self._data_buffer.append(data)
    if len(self._data_buffer) >= self._batch_size:
        self._flush_buffer()
```

### 文件分割

```python
def _should_split_file(self) -> bool:
    # 大小分割
    if self.config.max_file_size_mb > 0:
        current_size_mb = self.get_file_size() / (1024 * 1024)
        if current_size_mb >= self.config.max_file_size_mb:
            return True
    
    # 时间分割
    if self.config.split_interval_minutes > 0:
        elapsed = (datetime.now() - self._start_time).total_seconds() / 60
        if elapsed >= self.config.split_interval_minutes:
            return True
    
    return False
```

## 错误处理

### 分层错误处理

```
┌─────────────────────────────────────┐
│  Java客户端                          │
│  - 连接错误处理                       │
│  - 超时处理                          │
└─────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│  Python服务                          │
│  - 协议解析错误                       │
│  - 命令分发错误                       │
└─────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────┐
│  存储器                              │
│  - IO错误处理                        │
│  - 格式特定错误                       │
└─────────────────────────────────────┘
```

### 错误恢复策略

| 错误类型 | 处理策略 |
|----------|----------|
| 连接断开 | 自动重连 |
| 写入失败 | 跳过该条数据，记录日志 |
| 文件损坏 | 创建新文件 |
| 格式不支持 | 使用后备格式(CSV) |

## 监控与调试

### 日志级别

```python
logger.debug("调试信息")   # 详细执行过程
logger.info("一般信息")    # 重要事件
logger.warning("警告")     # 非致命问题
logger.error("错误")       # 致命错误
```

### 性能指标

| 指标 | 说明 | 正常范围 |
|------|------|----------|
| send_rate | 发送速率 | 80-100 条/秒 |
| queue_size | 队列大小 | < 1000 |
| write_rate | 写入速率 | 接近发送速率 |
| file_size_mb | 文件大小 | 按配置限制 |

## 参考

- [策略模式](https://refactoringguru.cn/design-patterns/strategy)
- [工厂模式](https://refactoringguru.cn/design-patterns/factory-method)
- [Python ABC模块](https://docs.python.org/3/library/abc.html)
