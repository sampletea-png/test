# -*- coding: utf-8 -*-
"""
ASAM MDF 多线程读写器综合测试模块 (v4.0.0)

本模块包含 64 个测试用例,覆盖 15 个测试类:
    TestConfig, TestNormal, TestFragmented, TestStreaming,
    TestIntermittent, TestMultiThreading, TestCompression,
    TestIterator, TestEdgeCases, TestReader, TestDataIntegrity,
    TestAppendWriter, TestExceptions, TestStress, TestHeaderBlock

测试层次:
    - 单元测试: 配置验证,通道定义,异常类
    - 集成测试: 写入-读取端到端验证,分片合并,HD 属性
    - 压力测试: 10 万条记录,多线程并发

分片存储结构(v4.0+):
    基础路径: /path/to/data.mf4
    分片文件夹: /path/to/data_fragments/
    分片文件:   /path/to/data_fragments/data_001.mf4
    索引文件:   /path/to/data_fragments/index.json

运行: python test_mdf_rw.py
"""

# ============================================================================
# 标准库导入
# ============================================================================
from __future__ import annotations

import os
import sys
import time
import json
import glob
import shutil
import tempfile
import unittest
import logging
import threading
import numpy as np

# ============================================================================
# 本地模块导入
# ============================================================================
from mdf_config import (
    MDFConfig, ChannelDef, HeaderConfig, WriterStats, ReaderStats,
    OperationMode, DataContinuity, CompressionType,
)
from mdf_writer import (
    MDFWriter, MDFAppendWriter, FragmentIndex,
    MDFWriterError, MDFWriterStateError, MDFWriterValidationError,
    MDFWriterModeError, MDFWriterThreadError,
)
from mdf_reader import (
    MDFReader,
    MDFReaderError, MDFReaderNotFoundError, MDFReaderStateError,
    MDFReaderFormatError,
)

# ============================================================================
# 日志配置
# ============================================================================
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)


# ============================================================================
# 工具函数
# ============================================================================

def tmpfile(suffix=".mf4"):
    """创建临时文件路径并确保文件不存在"""
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    return path


def rm(path):
    """删除文件或文件夹(忽略错误)"""
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def rm_fragments(base_path):
    """
    删除分片文件,索引文件和子文件夹

    v4.0+ 结构: 删除 base_fragments/ 子文件夹
    兼容旧版: 删除散落在基础目录下的分片文件
    """
    base, ext = os.path.splitext(base_path)
    # v4.0+: 删除子文件夹
    frag_folder = f"{base}_fragments"
    if os.path.isdir(frag_folder):
        shutil.rmtree(frag_folder, ignore_errors=True)
    # 兼容旧版本(v3.x)
    for pattern in [f"{base}_*{ext}", f"{base}.index"]:
        for f in glob.glob(pattern):
            rm(f)
    rm(base_path)


def gen_data(n, names):
    """生成连续测试数据,返回(values_dict, timestamps_list)"""
    ts = [i * 0.01 for i in range(n)]
    vals = {}
    for i, name in enumerate(names):
        vals[name] = [float(j * 10 + i) for j in range(n)]
    return vals, ts


# ============================================================================
# 测试类 1: 配置验证
# ============================================================================

class TestConfig(unittest.TestCase):
    """配置验证测试类,测试 MDFConfig 和 ChannelDef 的参数验证"""

    def test_default(self):
        """验证默认配置参数值是否正确"""
        c = MDFConfig()
        self.assertEqual(c.operation_mode, OperationMode.NORMAL)
        self.assertEqual(c.fragment_size, 10 * 1024 * 1024)
        self.assertEqual(c.version, "4.10")

    def test_fragment_size_validation(self):
        """分片大小必须在 256KB ~ 1GB 范围内,否则抛出 ValueError"""
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=100)  # 太小
        with self.assertRaises(ValueError):
            MDFConfig(fragment_size=2 * 1024 * 1024 * 1024)  # 太大

    def test_stream_buffer_validation(self):
        """流式缓冲区大小必须在 10 ~ 100000 范围内"""
        with self.assertRaises(ValueError):
            MDFConfig(stream_buffer_size=5)
        with self.assertRaises(ValueError):
            MDFConfig(stream_buffer_size=200000)

    def test_lock_timeout_validation(self):
        """锁超时时间必须在 1 ~ 300 秒范围内"""
        with self.assertRaises(ValueError):
            MDFConfig(lock_timeout_seconds=0.5)
        with self.assertRaises(ValueError):
            MDFConfig(lock_timeout_seconds=400)

    def test_folder_suffix_validation(self):
        """分片文件夹后缀不能为空"""
        with self.assertRaises(ValueError):
            MDFConfig(fragment_folder_suffix="")

    def test_serialization(self):
        """配置序列化(to_dict)和反序列化(from_dict)应正确还原"""
        c = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            compression=CompressionType.ZIP,
            fragment_size=5 * 1024 * 1024,
        )
        d = c.to_dict()
        r = MDFConfig.from_dict(d)
        self.assertEqual(r.operation_mode, OperationMode.FRAGMENTED)
        self.assertEqual(r.fragment_size, 5 * 1024 * 1024)
        self.assertEqual(r.compression, CompressionType.ZIP)

    def test_from_dict_with_enums(self):
        """从字典创建时应正确解析枚举字符串值"""
        d = {
            "operation_mode": "streaming",
            "compression": "zstd",
            "fragment_size": 262144,
        }
        c = MDFConfig.from_dict(d)
        self.assertEqual(c.operation_mode, OperationMode.STREAMING)
        self.assertEqual(c.compression, CompressionType.ZSTD)

    def test_channel_def(self):
        """通道定义创建和基本属性验证"""
        ch = ChannelDef(name="Temp", unit="C", data_type="<f4", comment="温度")
        self.assertEqual(ch.name, "Temp")
        self.assertEqual(ch.unit, "C")
        self.assertEqual(ch.display_name, "Temp")

    def test_channel_def_empty_name(self):
        """通道名称不能为空,否则抛出 ValueError"""
        with self.assertRaises(ValueError):
            ChannelDef(name="")

    def test_header_config(self):
        """HeaderConfig 创建和属性验证"""
        h = HeaderConfig(author="A", department="B", project="C")
        self.assertEqual(h.author, "A")
        self.assertFalse(h.is_empty())

    def test_header_config_empty(self):
        """空 HeaderConfig 的 is_empty() 应返回 True"""
        self.assertTrue(HeaderConfig().is_empty())

    def test_header_config_serialization(self):
        """HeaderConfig 序列化和反序列化"""
        h = HeaderConfig(author="X", project="Y")
        d = h.to_dict()
        r = HeaderConfig.from_dict(d)
        self.assertEqual(r.author, "X")
        self.assertEqual(r.project, "Y")


# ============================================================================
# 测试类 2: 一般模式
# ============================================================================

class TestNormal(unittest.TestCase):
    """一般模式(NORMAL)测试,单文件直接写入和读取"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_basic_write_read(self):
        """基本写入读取:定义通道,写入 100 条,读取验证数量"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Speed", unit="km/h", data_type="<f4")])
            vals, ts = gen_data(100, ["Speed"])
            w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            sig = r.get_channel("Speed")
            self.assertEqual(len(sig.samples), 100)

    def test_multiple_channels(self):
        """多通道写入读取:两个通道各 50 条,分别验证"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("A", data_type="<f4"),
                ChannelDef("B", data_type="<f4"),
            ])
            vals, ts = gen_data(50, ["A", "B"])
            w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("A").samples), 50)
            self.assertEqual(len(r.get_channel("B").samples), 50)

    def test_state_error_no_channels(self):
        """未定义通道时写入应抛出 MDFWriterStateError"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        writer = MDFWriter(self.path, config)
        with self.assertRaises(MDFWriterStateError):
            writer.append_continuous({"X": [1.0]}, [0.0])
        writer.close()

    def test_validation_mismatched_length(self):
        """样本数与时间戳数不匹配应抛出 MDFWriterValidationError"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("X", data_type="<f4")])
            with self.assertRaises(MDFWriterValidationError):
                w.append_continuous({"X": [1.0, 2.0]}, [0.0])

    def test_empty_data(self):
        """空数据应不报错,返回 0 条记录"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("E", data_type="<f4")])
            w.append_continuous({"E": []}, [])

    def test_flush_empty_buffer(self):
        """刷新空缓冲区应不报错"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("F", data_type="<f4")])
            w.flush()


# ============================================================================
# 测试类 3: 分片模式 (核心测试)
# ============================================================================

class TestFragmented(unittest.TestCase):
    """
    分片模式(FRAGMENTED)核心测试

    验证以体积阈值自动切分,分片存储在子文件夹中的功能:
        - 分片自动切分(体积阈值触发)
        - 每个分片包含完整 Schema
        - 索引文件管理(在子文件夹中)
        - 读取器自动发现分片并合并数据
        - 关闭后重新打开继续追加
        - 分片文件命名格式验证
        - 间歇数据触发分片切分
    """

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm_fragments(self.path)

    def test_fragment_auto_split(self):
        """
        分片自动切分测试

        写入约 1.5MB 数据触发分片切分,验证:
            1. 产生多个分片文件(在子文件夹中)
            2. 每个分片大于 64 字节(有效 MDF)
            3. 索引文件存在于子文件夹中
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("BigData", data_type="<f4")])
            for batch in range(150):
                vals = {"BigData": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        # 验证多个分片
        frag_paths = w.get_fragment_paths()
        self.assertGreaterEqual(len(frag_paths), 2, "应产生至少 2 个分片")
        for path in frag_paths:
            self.assertTrue(os.path.exists(path), f"分片应存在: {path}")
            self.assertGreater(os.path.getsize(path), 64, "分片应大于 64 字节")

        # 验证索引文件在子文件夹中
        base, _ = os.path.splitext(self.path)
        index_path = os.path.join(f"{base}_fragments", "index.json")
        self.assertTrue(os.path.exists(index_path), "索引文件应存在于子文件夹")

    def test_each_fragment_has_schema(self):
        """
        每个分片包含完整 Schema 测试

        定义 Speed/RPM/Temp 三个通道,写入大量数据触发分片,
        逐个打开分片验证通道完整性
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [
            ChannelDef("Speed", unit="km/h", data_type="<f4", comment="车速"),
            ChannelDef("RPM", unit="rpm", data_type="<u4", comment="转速"),
            ChannelDef("Temp", unit="C", data_type="<f4", comment="温度"),
        ]
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            for batch in range(100):
                vals, ts = gen_data(1000, ["Speed", "RPM", "Temp"])
                ts = [t + batch * 10 for t in ts]
                w.append_continuous(vals, ts)

        # 在子文件夹中查找分片
        base, _ = os.path.splitext(self.path)
        frag_folder = f"{base}_fragments"
        frag_paths = sorted(glob.glob(os.path.join(frag_folder, "*.mf4")))
        self.assertGreaterEqual(len(frag_paths), 2)

        for path in frag_paths:
            with MDFReader(path) as r:
                names = set(r.get_channel_names())
                self.assertIn("Speed", names)
                self.assertIn("RPM", names)
                self.assertIn("Temp", names)

    def test_index_file_content(self):
        """
        索引文件内容和结构验证

        验证 JSON 索引文件的完整结构:
            - base_path, schema, fragments 顶层字段
            - 每个分片的 index, path, size, records 字段
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Data", data_type="<f4")])
            for batch in range(80):
                vals = {"Data": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        base, _ = os.path.splitext(self.path)
        index_path = os.path.join(f"{base}_fragments", "index.json")
        with open(index_path, 'r') as f:
            index = json.load(f)

        self.assertIn("base_path", index)
        self.assertIn("schema", index)
        self.assertIn("fragments", index)
        self.assertIn("channels", index["schema"])
        self.assertGreaterEqual(len(index["fragments"]), 2)
        for frag in index["fragments"]:
            self.assertIn("index", frag)
            self.assertIn("path", frag)
            self.assertIn("size", frag)
            self.assertIn("records", frag)

    def test_fragment_reader_merge(self):
        """
        分片读取器自动合并测试

        通过基础路径读取,验证 MDFReader 自动发现子文件夹中的
        分片并正确合并数据
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Merged", data_type="<f4")])
            for batch in range(20):
                vals = {"Merged": [float(batch * 1000 + i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            info = r.get_file_info()
            self.assertEqual(info["mode"], "fragmented")
            sig = r.get_channel("Merged")
            self.assertEqual(len(sig.samples), 20000)

    def test_persistence_append(self):
        """
        分片持久化追加测试

        关闭后重新打开继续追加,验证总记录数正确(无重复)
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=2 * 1024 * 1024,
        )
        channels = [ChannelDef("Persistent", data_type="<f4")]
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            w.append_continuous(
                {"Persistent": [float(i) for i in range(2000)]},
                [i * 0.01 for i in range(2000)]
            )
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels)
            w.append_continuous(
                {"Persistent": [float(2000 + i) for i in range(2000)]},
                [20.0 + i * 0.01 for i in range(2000)]
            )

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("Persistent").samples), 4000)

    def test_fragment_naming(self):
        """
        分片文件命名和存储位置验证

        验证分片存储在子文件夹中,命名格式为 base_001.mf4
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Named", data_type="<f4")])
            for batch in range(60):
                vals = {"Named": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        base, ext = os.path.splitext(self.path)
        frag_folder = f"{base}_fragments"
        self.assertTrue(os.path.isdir(frag_folder), "分片应存储在子文件夹")

        # 验证命名格式(检查实际存在的分片)
        basename = os.path.basename(base)
        frag_paths = sorted(glob.glob(os.path.join(frag_folder, f"{basename}_*{ext}")))
        self.assertGreaterEqual(len(frag_paths), 2, "应产生至少 2 个分片")
        for i, expected in enumerate(frag_paths[:5], 1):
            self.assertTrue(os.path.exists(expected), f"分片应存在: {expected}")

    def test_fragment_with_intermittent_split(self):
        """
        分片模式间歇数据触发切分测试

        使用 40000 条间歇记录验证间歇模式也能触发分片
        """
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        channels = [ChannelDef("EvtA", data_type="<u4"), ChannelDef("EvtB", data_type="<f4")]
        with MDFWriter(self.path, config) as w:
            w.define_channels(channels, DataContinuity.INTERMITTENT)
            for i in range(20000):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)

        frag_paths = w.get_fragment_paths()
        self.assertGreaterEqual(len(frag_paths), 2, "间歇数据也应触发分片")

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 20000)
            self.assertEqual(len(r.get_channel("EvtB").samples), 20000)

    def test_large_fragment_threshold(self):
        """大分片阈值(10MB)下小数据应只产生 1 个分片"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=10 * 1024 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Small", data_type="<f4")])
            w.append_continuous({"Small": [float(i) for i in range(100)]}, [i * 0.01 for i in range(100)])
        self.assertEqual(len(w.get_fragment_paths()), 1)


# ============================================================================
# 测试类 4: 流式模式
# ============================================================================

class TestStreaming(unittest.TestCase):
    """流式模式(STREAMING)测试,带缓冲区和刷盘机制"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_basic(self):
        """流式模式基本写入读取(后台线程禁用)"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=500,
            stream_enable_background_thread=False,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("S1", data_type="<f4")])
            for batch in range(5):
                vals, ts = gen_data(100, ["S1"])
                ts = [t + batch for t in ts]
                w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("S1").samples), 500)

    def test_continuous_append(self):
        """流式模式逐条追加(模拟实时采集)"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=1000,
            stream_enable_background_thread=False,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("C1", data_type="<u4"),
                ChannelDef("C2", data_type="<f4"),
            ])
            for i in range(100):
                w.append_continuous(
                    {"C1": [i], "C2": [float(i) * 1.5]},
                    [float(i) * 0.01]
                )
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("C1").samples), 100)
            self.assertEqual(len(r.get_channel("C2").samples), 100)

    def test_flush_before_close(self):
        """关闭前自动 flush 缓冲区,数据不丢失"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=10000,
            stream_enable_background_thread=False,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Flush", data_type="<f4")])
            vals, ts = gen_data(50, ["Flush"])
            w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("Flush").samples), 50)


# ============================================================================
# 测试类 5: 间歇数据
# ============================================================================

class TestIntermittent(unittest.TestCase):
    """间歇数据(INTERMITTENT)测试,各通道独立时间基"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_normal_intermittent(self):
        """一般模式间歇数据写入和读取"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Evt", data_type="<u4")], DataContinuity.INTERMITTENT)
            for i in range(20):
                w.append_intermittent("Evt", float(i) * 0.5, i * 10)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("Evt").samples), 20)

    def test_normal_intermittent_multi_channel(self):
        """一般模式多通道间歇数据"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("EvtA", data_type="<u4"),
                ChannelDef("EvtB", data_type="<f4"),
            ], DataContinuity.INTERMITTENT)
            for i in range(50):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 50)
            self.assertEqual(len(r.get_channel("EvtB").samples), 50)

    def test_fragmented_intermittent(self):
        """分片模式间歇数据写入和读取"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=1 * 1024 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("EvtA", data_type="<u4"),
                ChannelDef("EvtB", data_type="<f4"),
            ], DataContinuity.INTERMITTENT)
            for i in range(100):
                w.append_intermittent("EvtA", float(i) * 0.1, i)
                w.append_intermittent("EvtB", float(i) * 0.2, float(i) * 2.5)
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("EvtA").samples), 100)
            self.assertEqual(len(r.get_channel("EvtB").samples), 100)

    def test_intermittent_undefined_channel(self):
        """向未定义通道写入间歇数据应抛出 MDFWriterValidationError"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("OnlyOne", data_type="<f4")])
            with self.assertRaises(MDFWriterValidationError):
                w.append_intermittent("Undefined", 0.0, 1.0)


# ============================================================================
# 测试类 6: 多线程并发
# ============================================================================

class TestMultiThreading(unittest.TestCase):
    """多线程并发测试,验证 RLock 线程安全性"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_concurrent_write_streaming(self):
        """流式模式 4 线程并发写入共 100 条记录"""
        config = MDFConfig(
            operation_mode=OperationMode.STREAMING,
            stream_buffer_size=1000,
            stream_enable_background_thread=False,
        )
        writer = MDFWriter(self.path, config)
        writer.define_channels([ChannelDef("ThreadData", data_type="<f4")])

        def worker(tid, count):
            for i in range(count):
                writer.append_continuous(
                    {"ThreadData": [float(tid * 1000 + i)]},
                    [float(tid * 1000 + i) * 0.001]
                )

        threads = [threading.Thread(target=worker, args=(i, 25)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        writer.close()

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("ThreadData").samples), 100)

    def test_concurrent_write_fragmented(self):
        """分片模式 5 线程并发写入共 100 条记录"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=2 * 1024 * 1024,
        )
        writer = MDFWriter(self.path, config)
        writer.define_channels([ChannelDef("FragThread", data_type="<f4")])

        def worker(tid, count):
            for i in range(count):
                writer.append_continuous(
                    {"FragThread": [float(tid * 100 + i)]},
                    [float(tid * 100 + i) * 0.01]
                )

        threads = [threading.Thread(target=worker, args=(i, 20)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        writer.close()

        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("FragThread").samples), 100)


# ============================================================================
# 测试类 7: 压缩
# ============================================================================

class TestCompression(unittest.TestCase):
    """压缩功能测试"""

    def test_zip_compression(self):
        """ZIP 压缩模式下数据完整性验证"""
        path = tmpfile()
        config = MDFConfig(
            operation_mode=OperationMode.NORMAL,
            compression=CompressionType.ZIP,
        )
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Comp", data_type="<f4")])
            vals, ts = gen_data(500, ["Comp"])
            w.append_continuous(vals, ts)
        with MDFReader(path) as r:
            self.assertEqual(len(r.get_channel("Comp").samples), 500)
        rm(path)


# ============================================================================
# 测试类 8: 迭代器读取
# ============================================================================

class TestIterator(unittest.TestCase):
    """迭代器读取测试,适用于大数据量分批处理"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_iter_channel(self):
        """单文件通道迭代器分批读取"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Iter", data_type="<f4")])
            vals, ts = gen_data(5000, ["Iter"])
            w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            total = sum(len(chunk.samples) for chunk in r.iter_channel("Iter", batch_size=500))
            self.assertEqual(total, 5000)

    def test_iter_fragmented(self):
        """分片数据迭代器分批读取"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("FragIter", data_type="<f4")])
            for batch in range(20):
                vals = {"FragIter": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)
        with MDFReader(self.path) as r:
            total = sum(len(chunk.samples) for chunk in r.iter_channel("FragIter", batch_size=1000))
            self.assertEqual(total, 20000)


# ============================================================================
# 测试类 9: 边界条件
# ============================================================================

class TestEdgeCases(unittest.TestCase):
    """边界条件测试,覆盖极端和特殊场景"""

    def test_single_record(self):
        """单条记录写入和精确值验证"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("One", data_type="<f4")])
            w.append_continuous({"One": [42.0]}, [0.0])
        with MDFReader(path) as r:
            sig = r.get_channel("One")
            self.assertEqual(len(sig.samples), 1)
            self.assertAlmostEqual(float(sig.samples[0]), 42.0)
        rm(path)

    def test_large_data(self):
        """大数据量写入(5万条),验证稳定性"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.FRAGMENTED)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Big", data_type="<f4")])
            vals, ts = gen_data(50000, ["Big"])
            w.append_continuous(vals, ts)
        with MDFReader(path) as r:
            self.assertEqual(len(r.get_channel("Big").samples), 50000)
        rm_fragments(path)

    def test_double_close(self):
        """重复关闭应不报错(幂等性验证)"""
        path = tmpfile()
        writer = MDFWriter(path, MDFConfig())
        writer.close()
        writer.close()  # 第二次关闭不应报错
        self.assertFalse(writer.is_open)
        rm(path)

    def test_zero_length_timestamps(self):
        """零长度时间戳应返回 0 条记录"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Zero", data_type="<f4")])
            count = w.append_continuous({"Zero": []}, [])
            self.assertEqual(count, 0)
        rm(path)


# ============================================================================
# 测试类 10: 读取器功能
# ============================================================================

class TestReader(unittest.TestCase):
    """读取器(MDFReader)功能测试"""

    def setUp(self):
        """预创建测试文件:Speed 和 Temp 两个通道各 100 条"""
        self.path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("Speed", unit="km/h", data_type="<f4"),
                ChannelDef("Temp", unit="C", data_type="<f4"),
            ])
            vals, ts = gen_data(100, ["Speed", "Temp"])
            w.append_continuous(vals, ts)

    def tearDown(self):
        rm(self.path)

    def test_get_channel(self):
        """读取单个通道数据"""
        with MDFReader(self.path) as r:
            sig = r.get_channel("Speed")
            self.assertEqual(len(sig.samples), 100)

    def test_get_channels(self):
        """批量读取多个通道"""
        with MDFReader(self.path) as r:
            data = r.get_channels(["Speed", "Temp"])
            self.assertIn("Speed", data)
            self.assertIn("Temp", data)
            self.assertEqual(len(data["Speed"].samples), 100)

    def test_channel_not_found(self):
        """不存在的通道应抛出 MDFReaderNotFoundError"""
        with MDFReader(self.path) as r:
            with self.assertRaises(MDFReaderNotFoundError):
                r.get_channel("XXX")

    def test_file_info(self):
        """文件信息查询应返回正确的元数据"""
        with MDFReader(self.path) as r:
            info = r.get_file_info()
            self.assertIn("channels", info)
            self.assertGreater(info["channels"], 0)
            self.assertEqual(info["mode"], "single")

    def test_records_slice(self):
        """切片读取指定范围的记录"""
        with MDFReader(self.path) as r:
            sig = r.get_records_slice("Speed", start=10, count=20)
            self.assertEqual(len(sig.samples), 20)

    def test_has_channel(self):
        """通道存在性检查"""
        with MDFReader(self.path) as r:
            self.assertTrue(r.has_channel("Speed"))
            self.assertFalse(r.has_channel("NonExist"))

    def test_get_header(self):
        """读取 HD 块属性(默认应为空)"""
        with MDFReader(self.path) as r:
            header = r.get_header()
            self.assertIsInstance(header, object)


# ============================================================================
# 测试类 11: 数据完整性
# ============================================================================

class TestDataIntegrity(unittest.TestCase):
    """
    数据完整性测试

    通过确定性数据生成和精确比对,验证写入值与读取值完全一致。
    """

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_exact_values_normal(self):
        """一般模式精确值验证:写入 pi 倍数,逐个比对"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        expected_values = [float(i * 3.14159) for i in range(200)]
        expected_ts = [i * 0.001 for i in range(200)]
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("Exact", data_type="<f4")])
            w.append_continuous({"Exact": expected_values}, expected_ts)
        with MDFReader(self.path) as r:
            sig = r.get_channel("Exact")
            self.assertEqual(len(sig.samples), 200)
            for i in range(200):
                self.assertAlmostEqual(float(sig.samples[i]), expected_values[i], places=4)

    def test_exact_values_fragmented(self):
        """分片模式跨分片精确值验证"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        all_values = []
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("FragExact", data_type="<f4")])
            for batch in range(10):
                vals = [float(batch * 1000 + i) for i in range(1000)]
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous({"FragExact": vals}, ts)
                all_values.extend(vals)
        with MDFReader(self.path) as r:
            sig = r.get_channel("FragExact")
            self.assertEqual(len(sig.samples), 10000)
            for i in range(10000):
                self.assertAlmostEqual(float(sig.samples[i]), all_values[i], places=4)

    def test_multi_channel_integrity(self):
        """多通道数据完整性:三个通道各 5 条记录独立验证"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        expected = {
            "A": [1.0, 2.0, 3.0, 4.0, 5.0],
            "B": [10.0, 20.0, 30.0, 40.0, 50.0],
            "C": [100.0, 200.0, 300.0, 400.0, 500.0],
        }
        ts = [0.0, 0.1, 0.2, 0.3, 0.4]
        with MDFWriter(self.path, config) as w:
            w.define_channels([
                ChannelDef("A", data_type="<f4"),
                ChannelDef("B", data_type="<f4"),
                ChannelDef("C", data_type="<f4"),
            ])
            w.append_continuous(expected, ts)
        with MDFReader(self.path) as r:
            for name in ["A", "B", "C"]:
                sig = r.get_channel(name)
                self.assertEqual(len(sig.samples), 5)
                for i in range(5):
                    self.assertAlmostEqual(float(sig.samples[i]), expected[name][i])

    def test_timestamps_integrity(self):
        """时间戳完整性:验证时间戳无漂移"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        expected_ts = [i * 0.5 for i in range(100)]
        values = [float(i) for i in range(100)]
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("TS", data_type="<f4")])
            w.append_continuous({"TS": values}, expected_ts)
        with MDFReader(self.path) as r:
            sig = r.get_channel("TS")
            for i in range(100):
                self.assertAlmostEqual(float(sig.timestamps[i]), expected_ts[i], places=6)


# ============================================================================
# 测试类 12: 追加写入器
# ============================================================================

class TestAppendWriter(unittest.TestCase):
    """MDFAppendWriter 追加写入器测试"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)

    def test_append_writer_basic(self):
        """追加写入器在已有文件上追加数据"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            w.define_channels([ChannelDef("App", data_type="<f4")])
            w.append_continuous({"App": [1.0, 2.0]}, [0.0, 0.1])
        with MDFAppendWriter(self.path, config) as w:
            w.define_channels([ChannelDef("App", data_type="<f4")])
            w.append_continuous({"App": [3.0, 4.0]}, [0.2, 0.3])
        with MDFReader(self.path) as r:
            self.assertEqual(len(r.get_channel("App").samples), 4)

    def test_append_writer_is_mdf_writer_subclass(self):
        """MDFAppendWriter 应是 MDFWriter 的子类"""
        self.assertTrue(issubclass(MDFAppendWriter, MDFWriter))


# ============================================================================
# 测试类 13: 异常处理
# ============================================================================

class TestExceptions(unittest.TestCase):
    """异常处理测试,验证异常类体系和错误检测"""

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_exception_hierarchy(self):
        """验证异常类的继承层次关系"""
        self.assertTrue(issubclass(MDFWriterStateError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterValidationError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterModeError, MDFWriterError))
        self.assertTrue(issubclass(MDFWriterThreadError, MDFWriterError))
        self.assertTrue(issubclass(MDFReaderNotFoundError, MDFReaderError))
        self.assertTrue(issubclass(MDFReaderStateError, MDFReaderError))

    def test_duplicate_channel_names(self):
        """重复通道名称应抛出 MDFWriterValidationError"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(self.path, config) as w:
            with self.assertRaises(MDFWriterValidationError):
                w.define_channels([
                    ChannelDef("Dup", data_type="<f4"),
                    ChannelDef("Dup", data_type="<u4"),
                ])

    def test_write_after_close(self):
        """关闭后写入应抛出 MDFWriterStateError"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        w = MDFWriter(self.path, config)
        w.define_channels([ChannelDef("X", data_type="<f4")])
        w.close()
        with self.assertRaises(MDFWriterStateError):
            w.append_continuous({"X": [1.0]}, [0.0])


# ============================================================================
# 测试类 14: 压力测试
# ============================================================================

class TestStress(unittest.TestCase):
    """压力测试,大数据量和高负载场景"""

    def test_many_batches_normal(self):
        """一般模式 10 万条记录(100 批次 x 1000 条)"""
        path = tmpfile()
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("Stress", data_type="<f4")])
            for batch in range(100):
                vals = {"Stress": [float(i) for i in range(1000)]}
                ts = [batch + i * 0.001 for i in range(1000)]
                w.append_continuous(vals, ts)
        with MDFReader(path) as r:
            self.assertEqual(len(r.get_channel("Stress").samples), 100000)
        rm(path)

    def test_many_batches_fragmented(self):
        """分片模式 5 万条记录(50 批次 x 1000 条),产生多个分片"""
        path = tmpfile()
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        with MDFWriter(path, config) as w:
            w.define_channels([ChannelDef("StressFrag", data_type="<f4")])
            for batch in range(50):
                vals = {"StressFrag": [float(i) for i in range(1000)]}
                ts = [batch + i * 0.001 for i in range(1000)]
                w.append_continuous(vals, ts)
        with MDFReader(path) as r:
            self.assertEqual(len(r.get_channel("StressFrag").samples), 50000)
        rm_fragments(path)


# ============================================================================
# 测试类 15: HD 块属性
# ============================================================================

class TestHeaderBlock(unittest.TestCase):
    """
    HD(Header)块属性测试

    验证 MDF 文件 Header 块元数据的写入和读取:
        - set_header() 设置 HD 属性
        - get_header() 读取 HD 属性
        - 分片模式下每个分片 HD 属性一致
        - 部分字段设置
        - HeaderConfig 序列化
    """

    def setUp(self):
        self.path = tmpfile()

    def tearDown(self):
        rm(self.path)
        rm_fragments(self.path)

    def test_header_set_and_get_normal(self):
        """一般模式 HD 属性写入和读取"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        header = HeaderConfig(
            author="张三",
            department="测试部",
            project="车型A制动测试",
            subject="前刹车盘温度",
            comment="2026年4月测试",
        )
        with MDFWriter(self.path, config) as w:
            w.set_header(header)
            w.define_channels([ChannelDef("Temp", data_type="<f4", unit="C")])
            w.append_continuous({"Temp": [25.0, 30.0]}, [0.0, 0.1])

        with MDFReader(self.path) as r:
            h = r.get_header()
            self.assertEqual(h.author, "张三")
            self.assertEqual(h.department, "测试部")
            self.assertEqual(h.project, "车型A制动测试")
            self.assertEqual(h.subject, "前刹车盘温度")
            # asammdf 将 comment 存储为 XML,验证包含文本即可
            self.assertIn("2026年4月测试", h.comment)

    def test_header_set_and_get_fragmented(self):
        """分片模式 HD 属性写入和读取"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        header = HeaderConfig(
            author="李四",
            department="研发部",
            project="车型B动力测试",
        )
        with MDFWriter(self.path, config) as w:
            w.set_header(header)
            w.define_channels([ChannelDef("Power", data_type="<f4", unit="kW")])
            for batch in range(100):
                vals = {"Power": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        with MDFReader(self.path) as r:
            h = r.get_header()
            self.assertEqual(h.author, "李四")
            self.assertEqual(h.department, "研发部")
            self.assertEqual(h.project, "车型B动力测试")

    def test_header_each_fragment_has_same_hd(self):
        """分片模式下每个分片都有相同的 HD 属性"""
        config = MDFConfig(
            operation_mode=OperationMode.FRAGMENTED,
            fragment_size=256 * 1024,
        )
        header = HeaderConfig(
            author="王五",
            department="质量部",
            project="耐久性测试",
        )
        with MDFWriter(self.path, config) as w:
            w.set_header(header)
            w.define_channels([ChannelDef("Durability", data_type="<f4")])
            for batch in range(60):
                vals = {"Durability": [float(i) for i in range(1000)]}
                ts = [batch * 10 + i * 0.01 for i in range(1000)]
                w.append_continuous(vals, ts)

        # 获取所有分片路径
        frag_paths = sorted(glob.glob(
            os.path.join(os.path.splitext(self.path)[0] + "_fragments", "*.mf4")
        ))
        self.assertGreaterEqual(len(frag_paths), 2, "应产生至少 2 个分片")

        # 逐个验证每个分片的 HD 属性
        for path in frag_paths:
            reader = MDFReader(path)
            try:
                h = reader.get_header()
                self.assertEqual(h.author, "王五")
                self.assertEqual(h.department, "质量部")
                self.assertEqual(h.project, "耐久性测试")
            finally:
                reader.close()

    def test_header_partial_fields(self):
        """HD 属性支持部分字段设置"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        header = HeaderConfig(author="仅作者", project="仅项目")
        with MDFWriter(self.path, config) as w:
            w.set_header(header)
            w.define_channels([ChannelDef("X", data_type="<f4")])
            w.append_continuous({"X": [1.0]}, [0.0])
        with MDFReader(self.path) as r:
            h = r.get_header()
            self.assertEqual(h.author, "仅作者")
            self.assertEqual(h.project, "仅项目")

    def test_header_config_empty(self):
        """空 HeaderConfig 的 is_empty() 方法"""
        self.assertTrue(HeaderConfig().is_empty())
        self.assertFalse(HeaderConfig(author="有值").is_empty())

    def test_header_set_before_channels(self):
        """应在 define_channels 之前调用 set_header"""
        config = MDFConfig(operation_mode=OperationMode.NORMAL)
        header = HeaderConfig(author="先设置作者")
        with MDFWriter(self.path, config) as w:
            w.set_header(header)
            w.define_channels([ChannelDef("Y", data_type="<f4")])
            w.append_continuous({"Y": [2.0]}, [0.0])
        with MDFReader(self.path) as r:
            self.assertEqual(r.get_header().author, "先设置作者")


# ============================================================================
# 主入口
# ============================================================================

def run_tests():
    """运行全部测试并输出摘要"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    classes = [
        TestConfig, TestNormal, TestFragmented, TestStreaming,
        TestIntermittent, TestMultiThreading, TestCompression,
        TestIterator, TestEdgeCases, TestReader, TestDataIntegrity,
        TestAppendWriter, TestExceptions, TestStress, TestHeaderBlock,
    ]
    for cls in classes:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 70)
    print("测试摘要")
    print("=" * 70)
    print(f"总测试数: {result.testsRun}")
    passed = result.testsRun - len(result.failures) - len(result.errors)
    print(f"通过: {passed}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
