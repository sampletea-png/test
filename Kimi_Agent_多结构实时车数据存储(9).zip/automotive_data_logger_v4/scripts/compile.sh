#!/bin/bash
# 手动编译脚本（无需Maven）- JDK 21版本

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
JAVA_DIR="$PROJECT_DIR/java"

echo "========================================"
echo "   汽车数据记录系统 - 手动编译"
echo "   JDK 21 + JavaFX 21"
echo "========================================"
echo ""

# 检查Java版本
if ! command -v java &> /dev/null; then
    echo "[错误] 未找到Java，请安装JDK 21"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -n 1 | grep -o '"[0-9.]*"' | tr -d '"' | cut -d'.' -f1)
if [[ "$JAVA_VERSION" != "21" ]]; then
    echo "[警告] 建议使用JDK 21，当前版本: $JAVA_VERSION"
fi

# 创建输出目录
mkdir -p "$JAVA_DIR/target/classes"

# 下载依赖JAR
echo "下载依赖..."
DEPS_DIR="$JAVA_DIR/target/deps"
mkdir -p "$DEPS_DIR"

# 下载GSON
if [ ! -f "$DEPS_DIR/gson-2.10.1.jar" ]; then
    curl -sL -o "$DEPS_DIR/gson-2.10.1.jar" \
        "https://repo1.maven.org/maven2/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"
    echo "✓ gson-2.10.1.jar"
fi

# 下载SQLite JDBC
if [ ! -f "$DEPS_DIR/sqlite-jdbc-3.44.1.0.jar" ]; then
    curl -sL -o "$DEPS_DIR/sqlite-jdbc-3.44.1.0.jar" \
        "https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.44.1.0/sqlite-jdbc-3.44.1.0.jar"
    echo "✓ sqlite-jdbc-3.44.1.0.jar"
fi

# 下载JavaFX 21 (Linux x64)
JAVAFX_VERSION="21"
JAVAFX_PLATFORM="linux"

for module in base controls graphics; do
    JAR_NAME="javafx-$module-$JAVAFX_VERSION-$JAVAFX_PLATFORM.jar"
    if [ ! -f "$DEPS_DIR/$JAR_NAME" ]; then
        curl -sL -o "$DEPS_DIR/$JAR_NAME" \
            "https://repo1.maven.org/maven2/org/openjfx/javafx-$module/$JAVAFX_VERSION/$JAR_NAME"
        echo "✓ $JAR_NAME"
    fi
done

# 构建classpath
CLASSPATH="$DEPS_DIR/*"

echo ""
echo "编译Java源代码..."

# 编译所有Java文件
find "$JAVA_DIR/src/main/java" -name "*.java" > "$JAVA_DIR/sources.txt"
javac -cp "$CLASSPATH" -d "$JAVA_DIR/target/classes" --release 21 @$JAVA_DIR/sources.txt

rm "$JAVA_DIR/sources.txt"

echo "✓ 编译完成"
echo ""
echo "类文件位置: $JAVA_DIR/target/classes"
