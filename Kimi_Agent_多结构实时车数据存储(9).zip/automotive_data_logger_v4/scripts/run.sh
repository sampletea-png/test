#!/bin/bash
# 汽车数据记录系统启动脚本 (Linux/macOS) - JDK 21版本

set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   汽车数据实时记录系统 V4${NC}"
echo -e "${GREEN}   JDK 21 + JavaFX 21${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# 检查Java
if ! command -v java &> /dev/null; then
    echo -e "${RED}错误: 未找到Java，请安装JDK 21${NC}"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -n 1 | grep -o '"[0-9.]*"' | tr -d '"' | cut -d'.' -f1)
if [[ "$JAVA_VERSION" != "21" ]]; then
    echo -e "${YELLOW}警告: 建议使用JDK 21，当前版本: $JAVA_VERSION${NC}"
else
    echo -e "${GREEN}✓ Java版本: $(java -version 2>&1 | head -n 1)${NC}"
fi

# 检查Maven
if ! command -v mvn &> /dev/null; then
    echo -e "${YELLOW}警告: 未找到Maven，将使用手动编译${NC}"
    USE_MAVEN=false
else
    echo -e "${GREEN}✓ Maven版本: $(mvn -version | head -n 1)${NC}"
    USE_MAVEN=true
fi

# 检查Python和asammdf
echo ""
echo "检查Python环境..."

PYTHON_CMD=""
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
fi

if [ -z "$PYTHON_CMD" ]; then
    echo -e "${YELLOW}警告: 未找到Python，MDF4格式将无法使用${NC}"
    echo -e "${YELLOW}  请安装Python 3.8+${NC}"
else
    echo -e "${GREEN}✓ Python: $($PYTHON_CMD --version)${NC}"
    
    # 检查asammdf
    if $PYTHON_CMD -c "import asammdf" 2>/dev/null; then
        echo -e "${GREEN}✓ asammdf已安装${NC}"
    else
        echo -e "${YELLOW}asammdf未安装，将在首次使用MDF4格式时自动安装${NC}"
        echo -e "${YELLOW}  或手动运行: pip install asammdf numpy${NC}"
    fi
fi

echo ""

# 进入Java项目目录
cd "$PROJECT_DIR/java"

# 编译项目
JAR_FILE="target/automotive-data-logger-4.0.0.jar"

if [ ! -f "$JAR_FILE" ]; then
    if [ "$USE_MAVEN" = true ]; then
        echo -e "${YELLOW}正在使用Maven编译项目...${NC}"
        mvn clean package -q
    else
        echo -e "${YELLOW}正在使用手动编译...${NC}"
        "$SCRIPT_DIR/compile.sh"
    fi
    echo -e "${GREEN}✓ 编译完成${NC}"
else
    echo -e "${GREEN}✓ 使用已编译的JAR文件${NC}"
fi

echo ""
echo -e "${GREEN}启动应用...${NC}"
echo ""

# 运行应用
if [ "$USE_MAVEN" = true ]; then
    mvn javafx:run
else
    # 手动运行
    DEPS_DIR="$PROJECT_DIR/java/target/deps"
    CLASSPATH="$PROJECT_DIR/java/target/classes:$DEPS_DIR/*"
    java -cp "$CLASSPATH" --module-path "$DEPS_DIR" --add-modules javafx.controls,javafx.graphics com.automotive.logger.VehicleDataLoggerApp
fi
