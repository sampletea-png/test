#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MDF4流式读写工具 - 支持GB级大文件

特性：
1. 写入：内存数据直接流式写入MDF4，支持追加模式
2. 读取：支持分块读取，避免内存溢出
3. 大文件：支持GB级文件的高效读写

用法:
    python mdf4_writer_stream.py <output_mf4> [--mode write|read] [--append]

交互命令 (stdin):
    WRITE:<json_data>           - 写入单条数据
    BATCH:<json_array>          - 批量写入数据
    FLUSH                       - 刷新缓冲区
    CLOSE                       - 关闭文件
    READ_CHUNK:<offset>:<count> - 分块读取
    READ_RANGE:<start>:<end>    - 读取时间范围
    READ_LATEST:<count>         - 读取最新N条
    GET_COUNT                   - 获取总记录数
    GET_RANGE                   - 获取时间范围
"""

import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Iterator

try:
    from asammdf import MDF, Signal
    import numpy as np
    ASAMMDF_AVAILABLE = True
except ImportError:
    ASAMMDF_AVAILABLE = False
    print("ERROR: asammdf not installed. Run: pip install asammdf numpy", file=sys.stderr)
    sys.exit(1)


class Mdf4StreamWriter:
    """MDF4流式写入器 - 支持追加模式"""
    
    # 信号定义
    SIGNAL_NAMES = [
        'vehicle_speed', 'engine_rpm', 'engine_temp',
        'throttle_position', 'brake_position', 'steering_angle',
        'battery_voltage', 'fuel_level', 'odometer',
        'accel_x', 'accel_y', 'accel_z'
    ]
    
    UNITS = {
        'vehicle_speed': 'km/h',
        'engine_rpm': 'rpm',
        'engine_temp': '°C',
        'throttle_position': '%',
        'brake_position': '%',
        'steering_angle': '°',
        'battery_voltage': 'V',
        'fuel_level': '%',
        'odometer': 'km',
        'accel_x': 'm/s²',
        'accel_y': 'm/s²',
        'accel_z': 'm/s²'
    }
    
    def __init__(self, output_path: str, append: bool = False):
        self.output_path = Path(output_path)
        self.append_mode = append
        self.mdf: Optional[MDF] = None
        self.buffer: List[Dict] = []
        self.buffer_size = 1000  # 缓冲区大小
        self.total_records = 0
        self.start_time = None
        self.end_time = None
        self.existing_records = 0
        
    def open(self):
        """打开MDF4文件"""
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if self.append_mode and self.output_path.exists():
            # 追加模式：打开现有文件
            self.mdf = MDF(str(self.output_path))
            self.existing_records = self._count_existing_records()
            self.total_records = self.existing_records
            print(f"READY:{self.output_path} (append mode, existing: {self.existing_records})")
        else:
            # 新建模式
            self.mdf = MDF(version='4.10')
            print(f"READY:{self.output_path} (new file)")
        
        sys.stdout.flush()
    
    def _count_existing_records(self) -> int:
        """统计现有记录数"""
        try:
            master_channels = self.mdf.get_master_channels()
            if master_channels:
                master = self.mdf.get(master_channels[0])
                return len(master.timestamps)
        except:
            pass
        return 0
    
    def write(self, data: Dict):
        """写入单条数据"""
        self.buffer.append(data)
        
        # 更新统计
        timestamp = data.get('timestamp', 0)
        if self.start_time is None:
            self.start_time = timestamp
        self.end_time = timestamp
        
        # 缓冲区满时刷新
        if len(self.buffer) >= self.buffer_size:
            self.flush()
        
        self.total_records += 1
    
    def write_batch(self, data_list: List[Dict]):
        """批量写入数据"""
        for data in data_list:
            self.buffer.append(data)
            timestamp = data.get('timestamp', 0)
            if self.start_time is None:
                self.start_time = timestamp
            self.end_time = timestamp
        
        self.total_records += len(data_list)
        
        # 缓冲区满时刷新
        if len(self.buffer) >= self.buffer_size:
            self.flush()
    
    def flush(self):
        """刷新缓冲区到文件"""
        if not self.buffer or self.mdf is None:
            return
        
        # 按信号组织数据
        timestamps = []
        signal_data = {name: [] for name in self.SIGNAL_NAMES}
        
        for record in self.buffer:
            timestamps.append(record.get('timestamp', 0) / 1000.0)  # 转换为秒
            signal_data['vehicle_speed'].append(record.get('vehicleSpeed', 0))
            signal_data['engine_rpm'].append(record.get('engineRpm', 0))
            signal_data['engine_temp'].append(record.get('engineTemp', 0))
            signal_data['throttle_position'].append(record.get('throttlePosition', 0))
            signal_data['brake_position'].append(record.get('brakePosition', 0))
            signal_data['steering_angle'].append(record.get('steeringAngle', 0))
            signal_data['battery_voltage'].append(record.get('batteryVoltage', 0))
            signal_data['fuel_level'].append(record.get('fuelLevel', 0))
            signal_data['odometer'].append(record.get('odometer', 0))
            signal_data['accel_x'].append(record.get('accelX', 0))
            signal_data['accel_y'].append(record.get('accelY', 0))
            signal_data['accel_z'].append(record.get('accelZ', 0))
        
        # 创建信号列表
        signals = []
        timestamps_array = np.array(timestamps, dtype=np.float64)
        
        for name in self.SIGNAL_NAMES:
            values = np.array(signal_data[name], dtype=np.float64)
            signal = Signal(
                samples=values,
                timestamps=timestamps_array,
                name=name,
                unit=self.UNITS.get(name, '')
            )
            signals.append(signal)
        
        # 追加到MDF文件
        self.mdf.append(signals)
        
        # 清空缓冲区
        count = len(self.buffer)
        self.buffer.clear()
        
        print(f"FLUSHED:{count}")
        sys.stdout.flush()
    
    def close(self):
        """关闭文件"""
        if self.mdf is None:
            return
        
        # 刷新剩余数据
        self.flush()
        
        # 保存文件
        self.mdf.save(str(self.output_path), overwrite=True)
        self.mdf.close()
        
        file_size = self.output_path.stat().st_size / (1024 * 1024)
        print(f"CLOSED:{self.output_path}:{file_size:.2f}MB:{self.total_records}")
        sys.stdout.flush()


class Mdf4StreamReader:
    """MDF4流式读取器 - 支持大文件分块读取"""
    
    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        self.mdf: Optional[MDF] = None
        self.timestamps = None
        self.signals = {}
        self.total_records = 0
        
    def open(self) -> bool:
        """打开MDF4文件"""
        if not self.file_path.exists():
            print(f"ERROR:File not found:{self.file_path}")
            return False
        
        self.mdf = MDF(str(self.file_path))
        
        # 预加载时间戳
        master_channels = self.mdf.get_master_channels()
        if master_channels:
            master = self.mdf.get(master_channels[0])
            self.timestamps = master.timestamps
            self.total_records = len(self.timestamps)
        
        # 预加载信号
        for channel in self.mdf.channels_db:
            if channel not in master_channels:
                try:
                    sig = self.mdf.get(channel)
                    self.signals[channel] = sig.samples
                except:
                    pass
        
        print(f"READY:{self.file_path} (records: {self.total_records})")
        return True
    
    def read_chunk(self, offset: int, count: int) -> List[Dict]:
        """分块读取数据"""
        if self.mdf is None or self.timestamps is None:
            print("ERROR:File not open")
            return []
        
        end = min(offset + count, self.total_records)
        
        records = []
        for i in range(offset, end):
            record = self._create_record(i)
            records.append(record)
        
        return records
    
    def read_range(self, start_time: int, end_time: int) -> List[Dict]:
        """读取指定时间范围的数据"""
        if self.mdf is None or self.timestamps is None:
            print("ERROR:File not open")
            return []
        
        start_sec = start_time / 1000.0
        end_sec = end_time / 1000.0
        
        records = []
        for i in range(self.total_records):
            ts = self.timestamps[i]
            if start_sec <= ts <= end_sec:
                record = self._create_record(i)
                records.append(record)
        
        return records
    
    def read_latest(self, count: int) -> List[Dict]:
        """读取最新N条数据"""
        if self.mdf is None or self.timestamps is None:
            print("ERROR:File not open")
            return []
        
        start = max(0, self.total_records - count)
        records = []
        
        for i in range(start, self.total_records):
            record = self._create_record(i)
            records.append(record)
        
        return records
    
    def _create_record(self, index: int) -> Dict:
        """创建单条记录"""
        return {
            'timestamp': int(self.timestamps[index] * 1000),  # 转换为毫秒
            'vehicleSpeed': float(self.signals.get('vehicle_speed', [0]*self.total_records)[index]),
            'engineRpm': float(self.signals.get('engine_rpm', [0]*self.total_records)[index]),
            'engineTemp': float(self.signals.get('engine_temp', [0]*self.total_records)[index]),
            'throttlePosition': float(self.signals.get('throttle_position', [0]*self.total_records)[index]),
            'brakePosition': float(self.signals.get('brake_position', [0]*self.total_records)[index]),
            'steeringAngle': float(self.signals.get('steering_angle', [0]*self.total_records)[index]),
            'batteryVoltage': float(self.signals.get('battery_voltage', [0]*self.total_records)[index]),
            'fuelLevel': float(self.signals.get('fuel_level', [0]*self.total_records)[index]),
            'odometer': float(self.signals.get('odometer', [0]*self.total_records)[index]),
            'accelX': float(self.signals.get('accel_x', [0]*self.total_records)[index]),
            'accelY': float(self.signals.get('accel_y', [0]*self.total_records)[index]),
            'accelZ': float(self.signals.get('accel_z', [0]*self.total_records)[index]),
        }
    
    def get_time_range(self) -> tuple:
        """获取时间范围"""
        if self.timestamps is None or len(self.timestamps) == 0:
            return (0, 0)
        
        min_time = int(self.timestamps[0] * 1000)
        max_time = int(self.timestamps[-1] * 1000)
        return (min_time, max_time)
    
    def get_record_count(self) -> int:
        """获取总记录数"""
        return self.total_records
    
    def close(self):
        """关闭文件"""
        if self.mdf:
            self.mdf.close()
            print("CLOSED")


def main():
    parser = argparse.ArgumentParser(description='MDF4 Stream Tool')
    parser.add_argument('file_path', help='MDF4 file path')
    parser.add_argument('--mode', choices=['write', 'read'], default='write',
                       help='Operation mode')
    parser.add_argument('--append', action='store_true',
                       help='Append to existing file (write mode only)')
    
    args = parser.parse_args()
    
    if args.mode == 'write':
        writer = Mdf4StreamWriter(args.file_path, append=args.append)
        writer.open()
        
        try:
            while True:
                line = sys.stdin.readline()
                if not line:
                    break
                
                line = line.strip()
                if not line:
                    continue
                
                if line.startswith("WRITE:"):
                    json_data = line[6:]
                    data = json.loads(json_data)
                    writer.write(data)
                
                elif line.startswith("BATCH:"):
                    json_data = line[6:]
                    data_list = json.loads(json_data)
                    writer.write_batch(data_list)
                
                elif line == "FLUSH":
                    writer.flush()
                    print("OK")
                    sys.stdout.flush()
                
                elif line == "CLOSE":
                    writer.close()
                    break
                
                elif line == "GET_INFO":
                    info = {
                        'path': str(writer.output_path),
                        'records': writer.total_records,
                        'start_time': writer.start_time,
                        'end_time': writer.end_time,
                        'buffered': len(writer.buffer)
                    }
                    print(f"INFO:{json.dumps(info)}")
                    sys.stdout.flush()
                
                else:
                    print(f"ERROR:Unknown command:{line}")
                    sys.stdout.flush()
        
        except KeyboardInterrupt:
            writer.close()
    
    else:  # read mode
        reader = Mdf4StreamReader(args.file_path)
        if not reader.open():
            sys.exit(1)
        
        try:
            while True:
                line = sys.stdin.readline()
                if not line:
                    break
                
                line = line.strip()
                if not line:
                    continue
                
                if line.startswith("READ_CHUNK:"):
                    parts = line.split(":")
                    offset = int(parts[1])
                    count = int(parts[2])
                    records = reader.read_chunk(offset, count)
                    print(f"DATA:{json.dumps(records)}")
                    print(f"CHUNK_END:{len(records)}")
                    sys.stdout.flush()
                
                elif line.startswith("READ_RANGE:"):
                    parts = line.split(":")
                    start_time = int(parts[1])
                    end_time = int(parts[2])
                    records = reader.read_range(start_time, end_time)
                    print(f"DATA:{json.dumps(records)}")
                    print(f"END:{len(records)}")
                    sys.stdout.flush()
                
                elif line.startswith("READ_LATEST:"):
                    parts = line.split(":")
                    count = int(parts[1])
                    records = reader.read_latest(count)
                    print(f"DATA:{json.dumps(records)}")
                    print(f"END:{len(records)}")
                    sys.stdout.flush()
                
                elif line == "READ_ALL":
                    # 分块读取所有数据
                    offset = 0
                    chunk_size = 10000
                    while True:
                        records = reader.read_chunk(offset, chunk_size)
                        if not records:
                            break
                        print(f"DATA:{json.dumps(records)}")
                        sys.stdout.flush()
                        offset += len(records)
                        if len(records) < chunk_size:
                            break
                    print(f"END:{offset}")
                    sys.stdout.flush()
                
                elif line == "GET_RANGE":
                    min_time, max_time = reader.get_time_range()
                    print(f"RANGE:{min_time},{max_time}")
                    sys.stdout.flush()
                
                elif line == "GET_COUNT":
                    count = reader.get_record_count()
                    print(f"COUNT:{count}")
                    sys.stdout.flush()
                
                elif line == "CLOSE":
                    reader.close()
                    break
                
                else:
                    print(f"ERROR:Unknown command:{line}")
                    sys.stdout.flush()
        
        except KeyboardInterrupt:
            reader.close()


if __name__ == "__main__":
    main()
