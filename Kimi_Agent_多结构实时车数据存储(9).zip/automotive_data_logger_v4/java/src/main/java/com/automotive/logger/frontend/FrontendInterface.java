package com.automotive.logger.frontend;

import com.automotive.logger.data.DataBuffer;
import com.automotive.logger.data.DataHistoryManager;
import com.automotive.logger.model.VehicleData;
import com.automotive.logger.storage.StorageInterface;

import java.util.List;
import java.util.function.Consumer;

/**
 * 前端接口 - 定义所有前端实现的通用接口
 * 支持JavaFX、Web等多种前端实现
 */
public interface FrontendInterface {
    
    /**
     * 初始化前端
     */
    void initialize();
    
    /**
     * 启动前端界面
     */
    void start();
    
    /**
     * 关闭前端
     */
    void shutdown();
    
    /**
     * 更新实时数据显示
     * 
     * @param data 最新的车辆数据
     */
    void updateRealtimeData(VehicleData data);
    
    /**
     * 更新图表数据
     * 
     * @param dataList 数据列表（用于绘制连续曲线）
     */
    void updateChartData(List<VehicleData> dataList);
    
    /**
     * 更新存储状态
     * 
     * @param info 存储信息
     */
    void updateStorageStatus(StorageInterface.StorageInfo info);
    
    /**
     * 设置记录状态
     * 
     * @param isRecording 是否正在记录
     */
    void setRecordingState(boolean isRecording);
    
    /**
     * 显示消息
     * 
     * @param message 消息内容
     * @param type 消息类型 (info, warning, error)
     */
    void showMessage(String message, MessageType type);
    
    /**
     * 获取选中的信号列表
     * 
     * @return 信号名称列表
     */
    List<String> getSelectedSignals();
    
    /**
     * 添加状态变化监听器
     */
    void addStatusListener(FrontendStatusListener listener);
    
    /**
     * 移除状态变化监听器
     */
    void removeStatusListener(FrontendStatusListener listener);
    
    /**
     * 设置数据缓冲区
     */
    void setDataBuffer(DataBuffer dataBuffer);
    
    /**
     * 设置历史数据管理器
     */
    void setHistoryManager(DataHistoryManager historyManager);
    
    /**
     * 设置可用格式列表
     */
    void setAvailableFormats(List<String> formats);
    
    /**
     * 更新记录时长显示
     */
    void updateRecordTime(String timeStr);
    
    /**
     * 前端状态监听器接口
     */
    interface FrontendStatusListener {
        void onStartRecording(String format);
        void onStopRecording();
        void onSwitchFormat(String newFormat);
    }
    
    /**
     * 消息类型枚举
     */
    enum MessageType {
        INFO, WARNING, ERROR
    }
}
