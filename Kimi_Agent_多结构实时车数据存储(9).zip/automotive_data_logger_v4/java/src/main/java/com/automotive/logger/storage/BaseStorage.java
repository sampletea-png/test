package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 存储基类
 * 提供通用的缓冲、文件分割等功能
 * 支持大文件的流式读写
 */
public abstract class BaseStorage implements StorageInterface {
    
    protected final StorageConfig config;
    protected Path currentFilePath;
    protected long recordCount = 0;
    protected long startTime = 0;
    protected boolean isOpen = false;
    protected boolean isReadMode = false;
    
    // 数据缓冲区
    private final List<VehicleData> buffer = new ArrayList<>();
    
    // 文件分割相关
    private long fileStartTime = 0;
    
    public BaseStorage(StorageConfig config) {
        this.config = config;
    }
    
    @Override
    public boolean open(Path filePath) throws IOException {
        if (filePath == null) {
            filePath = config.getOutputPath(getFileExtension());
        }
        
        doOpen(filePath);
        
        this.currentFilePath = filePath;
        this.isOpen = true;
        this.isReadMode = false;
        this.recordCount = 0;
        this.startTime = System.currentTimeMillis();
        this.fileStartTime = startTime;
        
        return true;
    }
    
    @Override
    public boolean openForRead(Path filePath) throws IOException {
        if (filePath == null || !filePath.toFile().exists()) {
            throw new IOException("文件不存在: " + filePath);
        }
        
        doOpenForRead(filePath);
        
        this.currentFilePath = filePath;
        this.isOpen = true;
        this.isReadMode = true;
        this.startTime = System.currentTimeMillis();
        
        return true;
    }
    
    @Override
    public boolean write(VehicleData data) throws IOException {
        ensureOpen();
        ensureWriteMode();
        
        // 检查是否需要分割文件
        if (shouldSplitFile()) {
            splitFile();
        }
        
        // 添加到缓冲区
        buffer.add(data);
        
        // 缓冲区满时刷新
        if (buffer.size() >= config.getBatchSize()) {
            flushBuffer();
        }
        
        return true;
    }
    
    @Override
    public boolean writeBatch(List<VehicleData> dataList) throws IOException {
        ensureOpen();
        ensureWriteMode();
        
        for (VehicleData data : dataList) {
            // 检查是否需要分割文件
            if (shouldSplitFile()) {
                splitFile();
            }
            
            buffer.add(data);
            
            if (buffer.size() >= config.getBatchSize()) {
                flushBuffer();
            }
        }
        
        // 刷新剩余数据
        if (!buffer.isEmpty()) {
            flushBuffer();
        }
        
        return true;
    }
    
    @Override
    public void flush() throws IOException {
        if (!buffer.isEmpty()) {
            flushBuffer();
        }
        doFlush();
    }
    
    @Override
    public void close() throws IOException {
        if (!isOpen) {
            return;
        }
        
        // 刷新缓冲区
        flush();
        
        // 关闭文件
        doClose();
        
        isOpen = false;
        isReadMode = false;
    }
    
    @Override
    public long getRecordCount() {
        return recordCount;
    }
    
    @Override
    public Path getCurrentFilePath() {
        return currentFilePath;
    }
    
    @Override
    public StorageInfo getInfo() {
        StorageInfo info = new StorageInfo();
        info.setFormatName(getFormatName());
        info.setFilePath(currentFilePath != null ? currentFilePath.toString() : null);
        info.setOpen(isOpen);
        info.setReadMode(isReadMode);
        info.setRecordCount(recordCount);
        info.setFileSizeBytes(getFileSize());
        info.setStartTime(startTime);
        
        if (startTime > 0) {
            info.setDurationMs(System.currentTimeMillis() - startTime);
        }
        
        if (info.getDurationMs() > 0) {
            info.setWriteRate(recordCount * 1000.0 / info.getDurationMs());
        }
        
        return info;
    }
    
    @Override
    public void setOptions(Map<String, Object> options) {
        if (options != null) {
            config.setOptions(options);
        }
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    @Override
    public boolean supportsIterator() {
        return false; // 默认不支持，子类可以覆盖
    }
    
    @Override
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        throw new UnsupportedOperationException("该存储格式不支持分块读取");
    }
    
    // ==================== 抽象方法 ====================
    
    /**
     * 实际打开文件（写入模式）
     */
    protected abstract void doOpen(Path filePath) throws IOException;
    
    /**
     * 实际打开文件（读取模式）
     */
    protected abstract void doOpenForRead(Path filePath) throws IOException;
    
    /**
     * 实际写入单条数据
     */
    protected abstract void doWrite(VehicleData data) throws IOException;
    
    /**
     * 实际批量写入
     */
    protected abstract void doWriteBatch(List<VehicleData> dataList) throws IOException;
    
    /**
     * 实际刷新
     */
    protected abstract void doFlush() throws IOException;
    
    /**
     * 实际关闭文件
     */
    protected abstract void doClose() throws IOException;
    
    // ==================== 内部方法 ====================
    
    private void ensureOpen() throws IOException {
        if (!isOpen) {
            throw new IOException("存储未打开");
        }
    }
    
    private void ensureWriteMode() throws IOException {
        if (isReadMode) {
            throw new IOException("存储处于读取模式，无法写入");
        }
    }
    
    private void flushBuffer() throws IOException {
        if (buffer.isEmpty()) {
            return;
        }
        
        doWriteBatch(new ArrayList<>(buffer));
        recordCount += buffer.size();
        buffer.clear();
    }
    
    private boolean shouldSplitFile() {
        // 检查文件大小
        if (config.getMaxFileSizeMb() > 0) {
            double currentSizeMb = getFileSize() / (1024.0 * 1024.0);
            if (currentSizeMb >= config.getMaxFileSizeMb()) {
                return true;
            }
        }
        
        // 检查时间间隔
        if (config.getSplitIntervalMinutes() > 0) {
            long elapsedMinutes = (System.currentTimeMillis() - fileStartTime) / (1000 * 60);
            if (elapsedMinutes >= config.getSplitIntervalMinutes()) {
                return true;
            }
        }
        
        return false;
    }
    
    private void splitFile() throws IOException {
        // 刷新当前缓冲区
        flush();
        
        // 关闭当前文件
        doClose();
        
        // 创建新文件
        Path newFilePath = config.getOutputPath(getFileExtension());
        doOpen(newFilePath);
        
        currentFilePath = newFilePath;
        fileStartTime = System.currentTimeMillis();
    }
}
