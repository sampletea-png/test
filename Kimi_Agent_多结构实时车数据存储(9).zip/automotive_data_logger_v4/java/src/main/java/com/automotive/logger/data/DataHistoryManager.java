package com.automotive.logger.data;

import com.automotive.logger.model.VehicleData;
import com.automotive.logger.storage.StorageFactory;
import com.automotive.logger.storage.StorageInterface;
import com.automotive.logger.storage.Mdf4Storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * 数据历史管理器 - 支持GB级大文件的高效加载
 * 
 * 特性：
 * 1. 大文件分块加载：避免内存溢出
 * 2. 迭代器支持：流式处理大数据
 * 3. 智能缓存：缓存常用数据，释放不常用数据
 */
public class DataHistoryManager {
    
    private final StorageFactory factory;
    private final Path outputDir;
    
    // 当前加载的历史文件
    private Path currentHistoryFile;
    private StorageInterface currentStorage;
    
    // 数据缓存（用于小文件）
    private List<VehicleData> historyDataCache;
    
    // 大文件模式
    private boolean largeFileMode = false;
    private static final long LARGE_FILE_THRESHOLD = 100 * 1024 * 1024; // 100MB
    private static final int DEFAULT_CHUNK_SIZE = 10000; // 默认分块大小
    
    // 迭代器（用于大文件）
    private Iterator<VehicleData> dataIterator;
    
    // 历史文件列表
    private List<FileInfo> historyFiles;
    
    // 监听器
    private final List<Consumer<List<VehicleData>>> historyDataListeners;
    private final List<Consumer<List<FileInfo>>> fileListListeners;
    private final List<Consumer<Iterator<VehicleData>>> iteratorListeners;
    
    public DataHistoryManager(Path outputDir) {
        this.factory = StorageFactory.getInstance();
        this.outputDir = outputDir;
        this.historyDataCache = new ArrayList<>();
        this.historyFiles = new ArrayList<>();
        this.historyDataListeners = new CopyOnWriteArrayList<>();
        this.fileListListeners = new CopyOnWriteArrayList<>();
        this.iteratorListeners = new CopyOnWriteArrayList<>();
    }
    
    /**
     * 扫描历史文件
     */
    public void scanHistoryFiles() {
        historyFiles.clear();
        
        if (!Files.exists(outputDir)) {
            notifyFileListListeners();
            return;
        }
        
        try {
            Files.list(outputDir)
                .filter(this::isValidDataFile)
                .sorted(Comparator.comparing(this::getFileTime).reversed())
                .forEach(path -> {
                    FileInfo info = createFileInfo(path);
                    if (info != null) {
                        historyFiles.add(info);
                    }
                });
        } catch (IOException e) {
            System.err.println("扫描历史文件失败: " + e.getMessage());
        }
        
        notifyFileListListeners();
    }
    
    /**
     * 加载历史文件
     * 根据文件大小自动选择加载模式（小文件缓存/大文件迭代器）
     */
    public boolean loadHistoryFile(Path filePath) {
        // 关闭当前文件
        closeCurrentFile();
        
        // 检测文件格式
        String format = detectFormat(filePath);
        if (format == null) {
            System.err.println("无法识别的文件格式: " + filePath);
            return false;
        }
        
        try {
            // 获取文件大小
            long fileSize = Files.size(filePath);
            largeFileMode = fileSize > LARGE_FILE_THRESHOLD;
            
            // 创建存储实例
            currentStorage = factory.create(format);
            
            // 打开文件读取
            if (!currentStorage.openForRead(filePath)) {
                System.err.println("打开文件失败: " + filePath);
                return false;
            }
            
            currentHistoryFile = filePath;
            
            if (largeFileMode) {
                // 大文件模式：使用迭代器
                System.out.println("大文件模式，使用迭代器读取: " + filePath + " (" + formatFileSize(fileSize) + ")");
                
                if (currentStorage.supportsIterator()) {
                    dataIterator = currentStorage.iterator();
                    notifyIteratorListeners();
                } else {
                    // 不支持迭代器的格式，使用分块读取
                    loadLargeFileInChunks();
                }
            } else {
                // 小文件模式：直接加载到内存
                System.out.println("小文件模式，直接加载: " + filePath + " (" + formatFileSize(fileSize) + ")");
                historyDataCache = currentStorage.readAll();
                
                // 关闭读取器
                currentStorage.close();
                currentStorage = null;
                
                // 通知监听器
                notifyHistoryDataListeners();
            }
            
            return true;
            
        } catch (IOException e) {
            System.err.println("加载历史文件失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 分块加载大文件
     */
    private void loadLargeFileInChunks() throws IOException {
        historyDataCache.clear();
        long offset = 0;
        int chunkSize = DEFAULT_CHUNK_SIZE;
        
        while (true) {
            List<VehicleData> chunk = currentStorage.readChunk(offset, chunkSize);
            if (chunk.isEmpty()) {
                break;
            }
            
            historyDataCache.addAll(chunk);
            offset += chunk.size();
            
            // 如果缓存数据过多，停止加载并切换到迭代器模式
            if (historyDataCache.size() > DEFAULT_CHUNK_SIZE * 5) {
                System.out.println("数据量过大，切换到分块显示模式");
                break;
            }
            
            // 如果读取数量不足chunkSize，说明已到文件末尾
            if (chunk.size() < chunkSize) {
                break;
            }
        }
        
        // 关闭读取器
        currentStorage.close();
        currentStorage = null;
        
        notifyHistoryDataListeners();
    }
    
    /**
     * 加载最新的历史文件
     */
    public boolean loadLatestHistoryFile() {
        scanHistoryFiles();
        
        if (historyFiles.isEmpty()) {
            return false;
        }
        
        return loadHistoryFile(historyFiles.get(0).getPath());
    }
    
    /**
     * 获取下一批数据（用于大文件迭代器模式）
     */
    public List<VehicleData> getNextBatch(int batchSize) {
        List<VehicleData> batch = new ArrayList<>();
        
        if (dataIterator != null) {
            int count = 0;
            while (dataIterator.hasNext() && count < batchSize) {
                batch.add(dataIterator.next());
                count++;
            }
        }
        
        return batch;
    }
    
    /**
     * 获取历史数据（小文件模式）
     */
    public List<VehicleData> getHistoryData() {
        return new ArrayList<>(historyDataCache);
    }
    
    /**
     * 获取历史数据（指定时间范围）
     */
    public List<VehicleData> getHistoryData(long startTime, long endTime) {
        if (largeFileMode && currentStorage != null) {
            // 大文件模式：直接从存储读取时间范围
            try {
                return currentStorage.readRange(startTime, endTime);
            } catch (IOException e) {
                System.err.println("读取时间范围失败: " + e.getMessage());
                return new ArrayList<>();
            }
        }
        
        // 小文件模式：从缓存过滤
        return historyDataCache.stream()
            .filter(d -> d.getTimestamp() >= startTime && d.getTimestamp() <= endTime)
            .collect(Collectors.toList());
    }
    
    /**
     * 获取最新N条历史数据
     */
    public List<VehicleData> getLatestHistoryData(int count) {
        if (largeFileMode && currentStorage != null) {
            // 大文件模式：直接读取最新N条
            try {
                return currentStorage.readLatest(count);
            } catch (IOException e) {
                System.err.println("读取最新数据失败: " + e.getMessage());
                return new ArrayList<>();
            }
        }
        
        // 小文件模式：从缓存获取
        int start = Math.max(0, historyDataCache.size() - count);
        return new ArrayList<>(historyDataCache.subList(start, historyDataCache.size()));
    }
    
    /**
     * 获取历史文件列表
     */
    public List<FileInfo> getHistoryFiles() {
        return new ArrayList<>(historyFiles);
    }
    
    /**
     * 获取当前加载的文件
     */
    public Path getCurrentHistoryFile() {
        return currentHistoryFile;
    }
    
    /**
     * 是否为大文件模式
     */
    public boolean isLargeFileMode() {
        return largeFileMode;
    }
    
    /**
     * 获取历史数据时间范围
     */
    public long[] getHistoryTimeRange() {
        if (largeFileMode && currentStorage != null) {
            try {
                return currentStorage.getTimeRange();
            } catch (IOException e) {
                System.err.println("获取时间范围失败: " + e.getMessage());
            }
        }
        
        if (historyDataCache.isEmpty()) {
            return new long[]{0, 0};
        }
        
        long minTime = historyDataCache.get(0).getTimestamp();
        long maxTime = historyDataCache.get(historyDataCache.size() - 1).getTimestamp();
        
        return new long[]{minTime, maxTime};
    }
    
    /**
     * 获取总记录数
     */
    public long getTotalRecordCount() {
        if (largeFileMode && currentStorage != null) {
            try {
                return currentStorage.getTotalRecordCount();
            } catch (IOException e) {
                System.err.println("获取记录数失败: " + e.getMessage());
            }
        }
        
        return historyDataCache.size();
    }
    
    /**
     * 清除历史数据
     */
    public void clearHistoryData() {
        closeCurrentFile();
        historyDataCache.clear();
        dataIterator = null;
        currentHistoryFile = null;
        largeFileMode = false;
        notifyHistoryDataListeners();
    }
    
    // ==================== 监听器管理 ====================
    
    public void addHistoryDataListener(Consumer<List<VehicleData>> listener) {
        historyDataListeners.add(listener);
    }
    
    public void removeHistoryDataListener(Consumer<List<VehicleData>> listener) {
        historyDataListeners.remove(listener);
    }
    
    public void addFileListListener(Consumer<List<FileInfo>> listener) {
        fileListListeners.add(listener);
    }
    
    public void removeFileListListener(Consumer<List<FileInfo>> listener) {
        fileListListeners.remove(listener);
    }
    
    public void addIteratorListener(Consumer<Iterator<VehicleData>> listener) {
        iteratorListeners.add(listener);
    }
    
    public void removeIteratorListener(Consumer<Iterator<VehicleData>> listener) {
        iteratorListeners.remove(listener);
    }
    
    // ==================== 内部方法 ====================
    
    private void closeCurrentFile() {
        if (currentStorage != null) {
            try {
                currentStorage.close();
            } catch (IOException e) {
                // ignore
            }
            currentStorage = null;
        }
        dataIterator = null;
    }
    
    private boolean isValidDataFile(Path path) {
        String name = path.toString().toLowerCase();
        return name.endsWith(".csv") || name.endsWith(".csv.gz") ||
               name.endsWith(".json") || name.endsWith(".json.gz") ||
               name.endsWith(".db") ||
               name.endsWith(".mf4");
    }
    
    private long getFileTime(Path path) {
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (IOException e) {
            return 0;
        }
    }
    
    private String detectFormat(Path path) {
        String name = path.toString().toLowerCase();
        if (name.endsWith(".csv") || name.endsWith(".csv.gz")) {
            return "csv";
        } else if (name.endsWith(".json") || name.endsWith(".json.gz")) {
            return "json";
        } else if (name.endsWith(".db")) {
            return "sqlite";
        } else if (name.endsWith(".mf4")) {
            return "mdf4";
        }
        return null;
    }
    
    private FileInfo createFileInfo(Path path) {
        try {
            String format = detectFormat(path);
            if (format == null) {
                return null;
            }
            
            long size = Files.size(path);
            long modifiedTime = Files.getLastModifiedTime(path).toMillis();
            
            return new FileInfo(path, format, size, modifiedTime);
        } catch (IOException e) {
            return null;
        }
    }
    
    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.2f MB", size / (1024.0 * 1024.0));
        } else {
            return String.format("%.2f GB", size / (1024.0 * 1024.0 * 1024.0));
        }
    }
    
    private void notifyHistoryDataListeners() {
        List<VehicleData> dataCopy = getHistoryData();
        for (Consumer<List<VehicleData>> listener : historyDataListeners) {
            try {
                listener.accept(dataCopy);
            } catch (Exception e) {
                System.err.println("历史数据监听器异常: " + e.getMessage());
            }
        }
    }
    
    private void notifyFileListListeners() {
        List<FileInfo> filesCopy = getHistoryFiles();
        for (Consumer<List<FileInfo>> listener : fileListListeners) {
            try {
                listener.accept(filesCopy);
            } catch (Exception e) {
                System.err.println("文件列表监听器异常: " + e.getMessage());
            }
        }
    }
    
    private void notifyIteratorListeners() {
        if (dataIterator != null) {
            for (Consumer<Iterator<VehicleData>> listener : iteratorListeners) {
                try {
                    listener.accept(dataIterator);
                } catch (Exception e) {
                    System.err.println("迭代器监听器异常: " + e.getMessage());
                }
            }
        }
    }
    
    // ==================== 文件信息类 ====================
    
    public static class FileInfo {
        private final Path path;
        private final String format;
        private final long size;
        private final long modifiedTime;
        
        public FileInfo(Path path, String format, long size, long modifiedTime) {
            this.path = path;
            this.format = format;
            this.size = size;
            this.modifiedTime = modifiedTime;
        }
        
        public Path getPath() { return path; }
        public String getFormat() { return format; }
        public long getSize() { return size; }
        public long getModifiedTime() { return modifiedTime; }
        
        public String getFileName() {
            return path.getFileName().toString();
        }
        
        public String getFormattedSize() {
            if (size < 1024) {
                return size + " B";
            } else if (size < 1024 * 1024) {
                return String.format("%.2f KB", size / 1024.0);
            } else if (size < 1024 * 1024 * 1024) {
                return String.format("%.2f MB", size / (1024.0 * 1024.0));
            } else {
                return String.format("%.2f GB", size / (1024.0 * 1024.0 * 1024.0));
            }
        }
        
        public String getFormattedTime() {
            return new Date(modifiedTime).toString();
        }
        
        public boolean isLargeFile() {
            return size > LARGE_FILE_THRESHOLD;
        }
    }
}
