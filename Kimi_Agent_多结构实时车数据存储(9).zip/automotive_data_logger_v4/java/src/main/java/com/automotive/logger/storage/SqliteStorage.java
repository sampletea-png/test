package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * SQLite存储格式实现 - 支持GB级大文件直接内存读写
 * 
 * 特性：
 * 1. 写入：内存数据直接批量插入SQLite
 * 2. 读取：支持分页查询和迭代器，避免内存溢出
 * 3. 大文件：支持GB级数据库的高效读写
 * 4. 索引：自动创建索引优化查询性能
 */
public class SqliteStorage extends BaseStorage {
    
    private Connection connection;
    private PreparedStatement insertStmt;
    
    // 表名
    private static final String TABLE_NAME = "vehicle_data";
    
    // 分页配置
    private static final int DEFAULT_PAGE_SIZE = 10000;
    private int pageSize = DEFAULT_PAGE_SIZE;
    
    // 文件信息缓存
    private long cachedRecordCount = -1;
    private long[] cachedTimeRange = null;
    
    public SqliteStorage(StorageConfig config) {
        super(config);
        
        // 从配置读取分页大小
        Object pageSizeOption = config.getOption("sqlite.pageSize");
        if (pageSizeOption != null) {
            this.pageSize = ((Number) pageSizeOption).intValue();
        }
    }
    
    @Override
    public String getFormatName() {
        return "sqlite";
    }
    
    @Override
    public String getFileExtension() {
        return "db";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    public boolean supportsRead() {
        return true;
    }
    
    @Override
    public boolean supportsIterator() {
        return true;
    }
    
    // ==================== 写入操作 ====================
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        try {
            Files.createDirectories(filePath.getParent());
            currentFilePath = filePath;
            
            // 加载SQLite JDBC驱动
            Class.forName("org.sqlite.JDBC");
            
            // 连接数据库
            String url = "jdbc:sqlite:" + filePath.toAbsolutePath();
            connection = DriverManager.getConnection(url);
            
            // 启用WAL模式提高性能
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("PRAGMA journal_mode=WAL");
                stmt.execute("PRAGMA synchronous=NORMAL");
                stmt.execute("PRAGMA cache_size=10000");
                stmt.execute("PRAGMA page_size=4096");
            }
            
            // 创建表
            createTableIfNotExists();
            
            // 准备插入语句
            prepareInsertStatement();
            
        } catch (ClassNotFoundException e) {
            throw new IOException("SQLite JDBC驱动未找到，请添加依赖: org.xerial:sqlite-jdbc", e);
        } catch (SQLException e) {
            throw new IOException("打开SQLite数据库失败", e);
        }
    }
    
    @Override
    protected void doOpenForRead(Path filePath) throws IOException {
        try {
            currentFilePath = filePath;
            cachedRecordCount = -1;
            cachedTimeRange = null;
            
            // 加载SQLite JDBC驱动
            Class.forName("org.sqlite.JDBC");
            
            // 连接数据库（只读模式）
            String url = "jdbc:sqlite:" + filePath.toAbsolutePath();
            connection = DriverManager.getConnection(url);
            
        } catch (ClassNotFoundException e) {
            throw new IOException("SQLite JDBC驱动未找到", e);
        } catch (SQLException e) {
            throw new IOException("打开SQLite数据库失败", e);
        }
    }
    
    private void createTableIfNotExists() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "timestamp INTEGER NOT NULL," +
            "can_channel INTEGER," +
            "can_id INTEGER," +
            "vehicle_speed REAL," +
            "engine_rpm REAL," +
            "engine_temp REAL," +
            "throttle_position REAL," +
            "brake_position REAL," +
            "steering_angle REAL," +
            "battery_voltage REAL," +
            "fuel_level REAL," +
            "odometer REAL," +
            "accel_x REAL," +
            "accel_y REAL," +
            "accel_z REAL," +
            "created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
        
        // 创建索引
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON " + TABLE_NAME + "(timestamp)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_can_id ON " + TABLE_NAME + "(can_id)");
        }
    }
    
    private void prepareInsertStatement() throws SQLException {
        String sql = "INSERT INTO " + TABLE_NAME + " (" +
            "timestamp, can_channel, can_id, vehicle_speed, engine_rpm, engine_temp, " +
            "throttle_position, brake_position, steering_angle, battery_voltage, " +
            "fuel_level, odometer, accel_x, accel_y, accel_z" +
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        insertStmt = connection.prepareStatement(sql);
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        try {
            insertStmt.setLong(1, data.getTimestamp());
            insertStmt.setInt(2, data.getCanChannel());
            insertStmt.setInt(3, data.getCanId());
            insertStmt.setDouble(4, data.getVehicleSpeed());
            insertStmt.setDouble(5, data.getEngineRpm());
            insertStmt.setDouble(6, data.getEngineTemp());
            insertStmt.setDouble(7, data.getThrottlePosition());
            insertStmt.setDouble(8, data.getBrakePosition());
            insertStmt.setDouble(9, data.getSteeringAngle());
            insertStmt.setDouble(10, data.getBatteryVoltage());
            insertStmt.setDouble(11, data.getFuelLevel());
            insertStmt.setDouble(12, data.getOdometer());
            insertStmt.setDouble(13, data.getAccelX());
            insertStmt.setDouble(14, data.getAccelY());
            insertStmt.setDouble(15, data.getAccelZ());
            
            insertStmt.executeUpdate();
            
        } catch (SQLException e) {
            throw new IOException("写入SQLite失败", e);
        }
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        try {
            connection.setAutoCommit(false);
            
            for (VehicleData data : dataList) {
                insertStmt.setLong(1, data.getTimestamp());
                insertStmt.setInt(2, data.getCanChannel());
                insertStmt.setInt(3, data.getCanId());
                insertStmt.setDouble(4, data.getVehicleSpeed());
                insertStmt.setDouble(5, data.getEngineRpm());
                insertStmt.setDouble(6, data.getEngineTemp());
                insertStmt.setDouble(7, data.getThrottlePosition());
                insertStmt.setDouble(8, data.getBrakePosition());
                insertStmt.setDouble(9, data.getSteeringAngle());
                insertStmt.setDouble(10, data.getBatteryVoltage());
                insertStmt.setDouble(11, data.getFuelLevel());
                insertStmt.setDouble(12, data.getOdometer());
                insertStmt.setDouble(13, data.getAccelX());
                insertStmt.setDouble(14, data.getAccelY());
                insertStmt.setDouble(15, data.getAccelZ());
                
                insertStmt.addBatch();
            }
            
            insertStmt.executeBatch();
            connection.commit();
            connection.setAutoCommit(true);
            
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                // ignore
            }
            throw new IOException("批量写入SQLite失败", e);
        }
    }
    
    @Override
    protected void doFlush() throws IOException {
        // SQLite自动刷新
    }
    
    @Override
    protected void doClose() throws IOException {
        try {
            if (insertStmt != null) {
                insertStmt.close();
                insertStmt = null;
            }
            if (connection != null) {
                connection.close();
                connection = null;
            }
        } catch (SQLException e) {
            throw new IOException("关闭SQLite失败", e);
        }
    }
    
    // ==================== 读取操作（大文件优化）====================
    
    @Override
    public Iterator<VehicleData> iterator() throws IOException {
        return new SqliteIterator();
    }
    
    @Override
    public List<VehicleData> readChunk(long offset, int count) throws IOException {
        List<VehicleData> result = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + 
                     " ORDER BY timestamp LIMIT ? OFFSET ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, count);
            stmt.setLong(2, offset);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(mapResultSetToVehicleData(rs));
                }
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite分块数据失败", e);
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readAll() throws IOException {
        List<VehicleData> result = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + " ORDER BY timestamp";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                result.add(mapResultSetToVehicleData(rs));
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite失败", e);
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readRange(long startTime, long endTime) throws IOException {
        List<VehicleData> result = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + 
                     " WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, startTime);
            stmt.setLong(2, endTime);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(mapResultSetToVehicleData(rs));
                }
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite时间范围失败", e);
        }
        
        return result;
    }
    
    @Override
    public List<VehicleData> readLatest(int count) throws IOException {
        List<VehicleData> result = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + 
                     " ORDER BY timestamp DESC LIMIT ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, count);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(0, mapResultSetToVehicleData(rs)); // 插入到开头保持顺序
                }
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite最新数据失败", e);
        }
        
        return result;
    }
    
    @Override
    public long[] getTimeRange() throws IOException {
        if (cachedTimeRange != null) {
            return cachedTimeRange.clone();
        }
        
        String sql = "SELECT MIN(timestamp), MAX(timestamp) FROM " + TABLE_NAME;
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                cachedTimeRange = new long[]{rs.getLong(1), rs.getLong(2)};
                return cachedTimeRange.clone();
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite时间范围失败", e);
        }
        
        return new long[]{0, 0};
    }
    
    @Override
    public long getTotalRecordCount() throws IOException {
        if (cachedRecordCount >= 0) {
            return cachedRecordCount;
        }
        
        String sql = "SELECT COUNT(*) FROM " + TABLE_NAME;
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                cachedRecordCount = rs.getLong(1);
                return cachedRecordCount;
            }
        } catch (SQLException e) {
            throw new IOException("读取SQLite记录数失败", e);
        }
        
        return 0;
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            try {
                return Files.size(currentFilePath);
            } catch (IOException e) {
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public boolean isValidFile(Path filePath) {
        if (!Files.exists(filePath)) {
            return false;
        }
        
        try {
            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:" + filePath.toAbsolutePath();
            
            try (Connection testConn = DriverManager.getConnection(url);
                 Statement stmt = testConn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT name FROM sqlite_master WHERE type='table'")) {
                
                while (rs.next()) {
                    if (TABLE_NAME.equals(rs.getString(1))) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            return false;
        }
        
        return false;
    }
    
    private VehicleData mapResultSetToVehicleData(ResultSet rs) throws SQLException {
        VehicleData data = new VehicleData();
        data.setTimestamp(rs.getLong("timestamp"));
        data.setCanChannel(rs.getInt("can_channel"));
        data.setCanId(rs.getInt("can_id"));
        data.setVehicleSpeed(rs.getDouble("vehicle_speed"));
        data.setEngineRpm(rs.getDouble("engine_rpm"));
        data.setEngineTemp(rs.getDouble("engine_temp"));
        data.setThrottlePosition(rs.getDouble("throttle_position"));
        data.setBrakePosition(rs.getDouble("brake_position"));
        data.setSteeringAngle(rs.getDouble("steering_angle"));
        data.setBatteryVoltage(rs.getDouble("battery_voltage"));
        data.setFuelLevel(rs.getDouble("fuel_level"));
        data.setOdometer(rs.getDouble("odometer"));
        data.setAccelX(rs.getDouble("accel_x"));
        data.setAccelY(rs.getDouble("accel_y"));
        data.setAccelZ(rs.getDouble("accel_z"));
        return data;
    }
    
    // ==================== 迭代器实现 ====================
    
    private class SqliteIterator implements Iterator<VehicleData> {
        private long currentOffset = 0;
        private List<VehicleData> currentBatch = new ArrayList<>();
        private int currentIndex = 0;
        private boolean hasMore = true;
        
        public SqliteIterator() {
            loadNextBatch();
        }
        
        private void loadNextBatch() {
            try {
                currentBatch = readChunk(currentOffset, pageSize);
                currentIndex = 0;
                currentOffset += currentBatch.size();
                hasMore = !currentBatch.isEmpty();
            } catch (IOException e) {
                hasMore = false;
                currentBatch.clear();
            }
        }
        
        @Override
        public boolean hasNext() {
            if (currentIndex < currentBatch.size()) {
                return true;
            }
            if (hasMore) {
                loadNextBatch();
                return !currentBatch.isEmpty();
            }
            return false;
        }
        
        @Override
        public VehicleData next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return currentBatch.get(currentIndex++);
        }
    }
    
    // ==================== 查询方法 ====================
    
    /**
     * 执行SQL查询
     */
    public List<Map<String, Object>> query(String sql) throws SQLException {
        List<Map<String, Object>> results = new ArrayList<>();
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(metaData.getColumnName(i), rs.getObject(i));
                }
                results.add(row);
            }
        }
        
        return results;
    }
    
    /**
     * 获取数据统计信息
     */
    public Map<String, Object> getStatistics() throws SQLException {
        Map<String, Object> stats = new HashMap<>();
        
        // 总记录数
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                stats.put("totalRecords", rs.getLong(1));
            }
        }
        
        // 时间范围
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT MIN(timestamp), MAX(timestamp) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                stats.put("minTimestamp", rs.getLong(1));
                stats.put("maxTimestamp", rs.getLong(2));
            }
        }
        
        // 车速统计
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT MIN(vehicle_speed), MAX(vehicle_speed), AVG(vehicle_speed) FROM " + TABLE_NAME)) {
            if (rs.next()) {
                Map<String, Double> speedStats = new HashMap<>();
                speedStats.put("min", rs.getDouble(1));
                speedStats.put("max", rs.getDouble(2));
                speedStats.put("avg", rs.getDouble(3));
                stats.put("speedStats", speedStats);
            }
        }
        
        return stats;
    }
}
