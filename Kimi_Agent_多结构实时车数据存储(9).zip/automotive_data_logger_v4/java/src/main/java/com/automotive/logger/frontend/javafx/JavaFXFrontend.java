package com.automotive.logger.frontend.javafx;

import com.automotive.logger.data.DataBuffer;
import com.automotive.logger.data.DataHistoryManager;
import com.automotive.logger.frontend.FrontendInterface;
import com.automotive.logger.model.VehicleData;
import com.automotive.logger.storage.StorageInterface;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * JavaFX前端实现 - 支持实时数据和历史数据显示
 */
public class JavaFXFrontend extends Application implements FrontendInterface {
    
    private static JavaFXFrontend instance;
    private static java.util.function.Consumer<JavaFXFrontend> appInitializer;
    
    // 显示模式
    public enum DisplayMode {
        REALTIME,   // 实时数据
        HISTORY     // 历史数据
    }
    
    private DisplayMode currentMode = DisplayMode.REALTIME;
    
    // UI组件
    private Stage primaryStage;
    private Label statusLabel;
    private Label recordTimeLabel;
    private Label dataCountLabel;
    private Label writeRateLabel;
    private Label formatLabel;
    private Label fileSizeLabel;
    private Label modeLabel;
    
    // 数据值标签
    private Map<String, Label> valueLabels = new HashMap<>();
    
    // 图表
    private LineChart<Number, Number> lineChart;
    private Map<String, XYChart.Series<Number, Number>> chartSeries = new HashMap<>();
    
    // 控制按钮
    private Button startButton;
    private Button stopButton;
    private ComboBox<String> formatComboBox;
    private Button switchFormatButton;
    private ToggleButton modeToggleButton;
    
    // 历史文件列表
    private ListView<DataHistoryManager.FileInfo> historyFileList;
    private ObservableList<DataHistoryManager.FileInfo> historyFileItems;
    
    // 信号选择
    private Map<String, CheckBox> signalCheckBoxes = new HashMap<>();
    
    // 状态监听器
    private final List<FrontendStatusListener> statusListeners = new CopyOnWriteArrayList<>();
    
    // 数据管理
    private DataBuffer dataBuffer;
    private DataHistoryManager historyManager;
    
    // 图表数据点计数
    private int dataPointCounter = 0;
    
    // 颜色定义
    private static final Color BG_COLOR = Color.rgb(30, 30, 30);
    private static final Color PANEL_BG = Color.rgb(45, 45, 45);
    private static final Color TEXT_COLOR = Color.rgb(220, 220, 220);
    private static final Color ACCENT_COLOR = Color.rgb(0, 150, 200);
    private static final Color RECORDING_COLOR = Color.rgb(200, 50, 50);
    private static final Color VALUE_COLOR = Color.rgb(100, 200, 100);
    private static final Color HISTORY_COLOR = Color.rgb(255, 165, 0);
    
    // 信号颜色
    private static final Map<String, Color> SIGNAL_COLORS = new LinkedHashMap<>();
    static {
        SIGNAL_COLORS.put("vehicleSpeed", Color.rgb(255, 99, 71));
        SIGNAL_COLORS.put("engineRpm", Color.rgb(60, 179, 113));
        SIGNAL_COLORS.put("engineTemp", Color.rgb(30, 144, 255));
        SIGNAL_COLORS.put("throttlePosition", Color.rgb(255, 165, 0));
        SIGNAL_COLORS.put("brakePosition", Color.rgb(220, 20, 60));
        SIGNAL_COLORS.put("steeringAngle", Color.rgb(138, 43, 226));
        SIGNAL_COLORS.put("batteryVoltage", Color.rgb(255, 215, 0));
        SIGNAL_COLORS.put("fuelLevel", Color.rgb(0, 206, 209));
        SIGNAL_COLORS.put("accelX", Color.rgb(255, 105, 180));
        SIGNAL_COLORS.put("accelY", Color.rgb(154, 205, 50));
        SIGNAL_COLORS.put("accelZ", Color.rgb(106, 90, 205));
    }
    
    public JavaFXFrontend() {
        instance = this;
    }
    
    public static JavaFXFrontend getInstance() {
        return instance;
    }
    
    public static void setAppInitializer(java.util.function.Consumer<JavaFXFrontend> initializer) {
        appInitializer = initializer;
    }
    
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        initialize();
    }
    
    @Override
    public void initialize() {
        if (appInitializer != null) {
            appInitializer.accept(this);
        }
        
        primaryStage.setTitle("汽车数据实时记录系统");
        primaryStage.setMinWidth(1400);
        primaryStage.setMinHeight(900);
        
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #1e1e1e;");
        
        root.setTop(createStatusBar());
        root.setLeft(createLeftPanel());
        root.setCenter(createChartPanel());
        root.setRight(createRightPanel());
        root.setBottom(createControlBar());
        
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        
        primaryStage.setOnCloseRequest(e -> {
            shutdown();
            Platform.exit();
        });
    }
    
    private HBox createStatusBar() {
        HBox statusBar = new HBox(20);
        statusBar.setPadding(new Insets(10));
        statusBar.setStyle("-fx-background-color: #2d2d2d;");
        statusBar.setAlignment(Pos.CENTER_LEFT);
        
        statusLabel = createStatusLabel("就绪", TEXT_COLOR);
        modeLabel = createStatusLabel("[实时模式]", ACCENT_COLOR);
        recordTimeLabel = createValueLabel("00:00:00");
        dataCountLabel = createValueLabel("0");
        writeRateLabel = createValueLabel("0.0 条/秒");
        formatLabel = createValueLabel("-");
        fileSizeLabel = createValueLabel("0.0 MB");
        
        statusBar.getChildren().addAll(
            createInfoBox("状态:", statusLabel),
            createInfoBox("模式:", modeLabel),
            createInfoBox("记录时长:", recordTimeLabel),
            createInfoBox("数据条数:", dataCountLabel),
            createInfoBox("写入速率:", writeRateLabel),
            createInfoBox("存储格式:", formatLabel),
            createInfoBox("文件大小:", fileSizeLabel)
        );
        
        return statusBar;
    }
    
    private VBox createLeftPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #2d2d2d;");
        panel.setPrefWidth(280);
        
        // 实时数据面板
        TitledPane realtimePane = new TitledPane("实时数据", createRealtimeDataPanel());
        realtimePane.setExpanded(true);
        realtimePane.setStyle("-fx-text-fill: #00c8ff;");
        
        // 历史文件面板
        TitledPane historyPane = new TitledPane("历史文件", createHistoryFilePanel());
        historyPane.setExpanded(false);
        historyPane.setStyle("-fx-text-fill: #ffa500;");
        
        panel.getChildren().addAll(realtimePane, historyPane);
        VBox.setVgrow(historyPane, Priority.ALWAYS);
        
        return panel;
    }
    
    private VBox createRealtimeDataPanel() {
        VBox panel = new VBox(5);
        panel.setPadding(new Insets(5));
        
        String[][] dataItems = {
            {"vehicleSpeed", "车速"},
            {"engineRpm", "发动机转速"},
            {"engineTemp", "发动机温度"},
            {"throttlePosition", "油门位置"},
            {"brakePosition", "刹车位置"},
            {"steeringAngle", "方向盘角度"},
            {"batteryVoltage", "电池电压"},
            {"fuelLevel", "燃油液位"},
            {"accelX", "横向加速度"},
            {"accelY", "纵向加速度"},
            {"accelZ", "垂直加速度"}
        };
        
        for (String[] item : dataItems) {
            String key = item[0];
            String name = item[1];
            String unit = DataBuffer.getSignalUnit(key);
            
            HBox row = new HBox(10);
            row.setAlignment(Pos.CENTER_LEFT);
            
            Label nameLabel = new Label(name + ":");
            nameLabel.setTextFill(TEXT_COLOR);
            nameLabel.setFont(Font.font("Microsoft YaHei", 11));
            nameLabel.setPrefWidth(90);
            
            Label valueLabel = new Label("--");
            valueLabel.setTextFill(VALUE_COLOR);
            valueLabel.setFont(Font.font("Consolas", FontWeight.BOLD, 13));
            valueLabel.setPrefWidth(70);
            
            Label unitLabel = new Label(unit);
            unitLabel.setTextFill(Color.GRAY);
            unitLabel.setFont(Font.font("Microsoft YaHei", 10));
            
            row.getChildren().addAll(nameLabel, valueLabel, unitLabel);
            panel.getChildren().add(row);
            valueLabels.put(key, valueLabel);
        }
        
        return panel;
    }
    
    private VBox createHistoryFilePanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(5));
        
        // 刷新按钮
        Button refreshButton = new Button("刷新列表");
        refreshButton.setOnAction(e -> {
            if (historyManager != null) {
                historyManager.scanHistoryFiles();
            }
        });
        panel.getChildren().add(refreshButton);
        
        // 文件列表
        historyFileItems = FXCollections.observableArrayList();
        historyFileList = new ListView<>(historyFileItems);
        historyFileList.setCellFactory(lv -> new ListCell<DataHistoryManager.FileInfo>() {
            @Override
            protected void updateItem(DataHistoryManager.FileInfo item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getFileName() + "\n" + 
                            item.getFormattedSize() + " | " + item.getFormat());
                    setFont(Font.font("Microsoft YaHei", 10));
                    setTextFill(TEXT_COLOR);
                }
            }
        });
        
        historyFileList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                DataHistoryManager.FileInfo selected = historyFileList.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    loadHistoryFile(selected.getPath());
                }
            }
        });
        
        VBox.setVgrow(historyFileList, Priority.ALWAYS);
        panel.getChildren().add(historyFileList);
        
        // 打开文件按钮
        Button openFileButton = new Button("打开其他文件...");
        openFileButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("选择数据文件");
            fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("所有数据文件", "*.csv", "*.json", "*.db", "*.mf4"),
                new FileChooser.ExtensionFilter("CSV文件", "*.csv"),
                new FileChooser.ExtensionFilter("JSON文件", "*.json"),
                new FileChooser.ExtensionFilter("SQLite数据库", "*.db"),
                new FileChooser.ExtensionFilter("MDF4文件", "*.mf4")
            );
            
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                loadHistoryFile(file.toPath());
            }
        });
        panel.getChildren().add(openFileButton);
        
        return panel;
    }
    
    private VBox createChartPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #1e1e1e;");
        
        Label title = new Label("数据曲线");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        title.setTextFill(ACCENT_COLOR);
        panel.getChildren().add(title);
        
        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("数据点");
        xAxis.setStyle("-fx-tick-label-fill: #aaaaaa;");
        yAxis.setLabel("数值");
        yAxis.setStyle("-fx-tick-label-fill: #aaaaaa;");
        
        lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setStyle("-fx-background-color: #2d2d2d;");
        lineChart.setCreateSymbols(false);
        lineChart.setLegendVisible(true);
        lineChart.setLegendSide(javafx.geometry.Side.BOTTOM);
        lineChart.setPrefHeight(600);
        
        VBox.setVgrow(lineChart, Priority.ALWAYS);
        panel.getChildren().add(lineChart);
        
        return panel;
    }
    
    private VBox createRightPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));
        panel.setStyle("-fx-background-color: #2d2d2d;");
        panel.setPrefWidth(180);
        
        Label title = new Label("信号选择");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        title.setTextFill(ACCENT_COLOR);
        panel.getChildren().add(title);
        
        HBox selectButtons = new HBox(10);
        Button selectAllBtn = new Button("全选");
        Button selectNoneBtn = new Button("全不选");
        
        selectAllBtn.setOnAction(e -> setAllSignalsSelected(true));
        selectNoneBtn.setOnAction(e -> setAllSignalsSelected(false));
        
        selectButtons.getChildren().addAll(selectAllBtn, selectNoneBtn);
        panel.getChildren().add(selectButtons);
        
        for (String signal : DataBuffer.getAvailableSignals()) {
            CheckBox checkBox = new CheckBox(DataBuffer.getSignalDisplayName(signal));
            checkBox.setTextFill(TEXT_COLOR);
            checkBox.setSelected(true);
            
            Color signalColor = SIGNAL_COLORS.getOrDefault(signal, Color.WHITE);
            checkBox.setStyle("-fx-mark-color: " + toRgbString(signalColor) + ";");
            
            checkBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
                updateChartSeries();
            });
            
            panel.getChildren().add(checkBox);
            signalCheckBoxes.put(signal, checkBox);
        }
        
        return panel;
    }
    
    private HBox createControlBar() {
        HBox controlBar = new HBox(15);
        controlBar.setPadding(new Insets(15));
        controlBar.setStyle("-fx-background-color: #2d2d2d;");
        controlBar.setAlignment(Pos.CENTER);
        
        // 模式切换按钮
        modeToggleButton = new ToggleButton("切换到历史模式");
        modeToggleButton.setOnAction(e -> toggleMode());
        
        // 开始/停止按钮
        startButton = createControlButton("开始记录", Color.rgb(50, 150, 50));
        stopButton = createControlButton("停止记录", Color.rgb(150, 50, 50));
        stopButton.setDisable(true);
        
        startButton.setOnAction(e -> notifyStartRecording());
        stopButton.setOnAction(e -> notifyStopRecording());
        
        // 格式选择
        Label formatLabel = new Label("存储格式:");
        formatLabel.setTextFill(TEXT_COLOR);
        
        formatComboBox = new ComboBox<>();
        formatComboBox.setPrefWidth(120);
        formatComboBox.setDisable(true);
        
        switchFormatButton = createControlButton("切换格式", ACCENT_COLOR);
        switchFormatButton.setDisable(true);
        switchFormatButton.setOnAction(e -> notifySwitchFormat());
        
        controlBar.getChildren().addAll(
            modeToggleButton,
            new Region() {{ setPrefWidth(30); }},
            startButton, stopButton,
            new Region() {{ setPrefWidth(20); }},
            formatLabel, formatComboBox, switchFormatButton
        );
        
        return controlBar;
    }
    
    private void toggleMode() {
        if (currentMode == DisplayMode.REALTIME) {
            currentMode = DisplayMode.HISTORY;
            modeLabel.setText("[历史模式]");
            modeLabel.setTextFill(HISTORY_COLOR);
            modeToggleButton.setText("切换到实时模式");
            startButton.setDisable(true);
            
            // 加载最新的历史文件
            if (historyManager != null) {
                historyManager.loadLatestHistoryFile();
            }
        } else {
            currentMode = DisplayMode.REALTIME;
            modeLabel.setText("[实时模式]");
            modeLabel.setTextFill(ACCENT_COLOR);
            modeToggleButton.setText("切换到历史模式");
            startButton.setDisable(false);
            
            // 清除历史数据显示
            clearChart();
        }
    }
    
    private void loadHistoryFile(Path filePath) {
        if (historyManager != null) {
            boolean success = historyManager.loadHistoryFile(filePath);
            if (success) {
                currentMode = DisplayMode.HISTORY;
                modeLabel.setText("[历史模式]");
                modeLabel.setTextFill(HISTORY_COLOR);
                modeToggleButton.setText("切换到实时模式");
                startButton.setDisable(true);
            }
        }
    }
    
    private void clearChart() {
        Platform.runLater(() -> {
            lineChart.getData().clear();
            chartSeries.clear();
            dataPointCounter = 0;
        });
    }
    
    private Label createStatusLabel(String text, Color color) {
        Label label = new Label(text);
        label.setTextFill(color);
        label.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 12));
        return label;
    }
    
    private Label createValueLabel(String text) {
        Label label = new Label(text);
        label.setTextFill(VALUE_COLOR);
        label.setFont(Font.font("Consolas", FontWeight.BOLD, 14));
        return label;
    }
    
    private Button createControlButton(String text, Color color) {
        Button button = new Button(text);
        button.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 13));
        button.setTextFill(Color.WHITE);
        button.setStyle(String.format("-fx-background-color: %s; -fx-padding: 8 16;", toRgbString(color)));
        return button;
    }
    
    private VBox createInfoBox(String label, Label valueLabel) {
        VBox box = new VBox(2);
        box.setAlignment(Pos.CENTER);
        
        Label nameLabel = new Label(label);
        nameLabel.setTextFill(Color.GRAY);
        nameLabel.setFont(Font.font("Microsoft YaHei", 10));
        
        box.getChildren().addAll(nameLabel, valueLabel);
        return box;
    }
    
    private String toRgbString(Color color) {
        return String.format("rgb(%d, %d, %d)",
            (int)(color.getRed() * 255),
            (int)(color.getGreen() * 255),
            (int)(color.getBlue() * 255));
    }
    
    private void setAllSignalsSelected(boolean selected) {
        for (CheckBox checkBox : signalCheckBoxes.values()) {
            checkBox.setSelected(selected);
        }
    }
    
    private void updateChartSeries() {
        Platform.runLater(() -> {
            lineChart.getData().clear();
            chartSeries.clear();
            
            for (Map.Entry<String, CheckBox> entry : signalCheckBoxes.entrySet()) {
                String signal = entry.getKey();
                CheckBox checkBox = entry.getValue();
                
                if (checkBox.isSelected()) {
                    XYChart.Series<Number, Number> series = new XYChart.Series<>();
                    series.setName(DataBuffer.getSignalDisplayName(signal));
                    lineChart.getData().add(series);
                    chartSeries.put(signal, series);
                }
            }
            
            // 重新加载数据
            reloadChartData();
        });
    }
    
    private void reloadChartData() {
        if (currentMode == DisplayMode.REALTIME && dataBuffer != null) {
            List<VehicleData> dataList = dataBuffer.getChartData();
            dataPointCounter = 0;
            for (VehicleData data : dataList) {
                addDataToChart(data);
            }
        } else if (currentMode == DisplayMode.HISTORY && historyManager != null) {
            List<VehicleData> dataList = historyManager.getHistoryData();
            dataPointCounter = 0;
            for (VehicleData data : dataList) {
                addDataToChart(data);
            }
        }
    }
    
    private void addDataToChart(VehicleData data) {
        int pointIndex = dataPointCounter++;
        
        for (Map.Entry<String, XYChart.Series<Number, Number>> entry : chartSeries.entrySet()) {
            String signal = entry.getKey();
            XYChart.Series<Number, Number> series = entry.getValue();
            
            double value = dataBuffer != null ? 
                dataBuffer.getSignalValue(data, signal) : getSignalValue(data, signal);
            
            series.getData().add(new XYChart.Data<>(pointIndex, value));
            
            if (series.getData().size() > 500) {
                series.getData().remove(0);
            }
        }
    }
    
    private double getSignalValue(VehicleData data, String signal) {
        switch (signal) {
            case "vehicleSpeed": return data.getVehicleSpeed();
            case "engineRpm": return data.getEngineRpm();
            case "engineTemp": return data.getEngineTemp();
            case "throttlePosition": return data.getThrottlePosition();
            case "brakePosition": return data.getBrakePosition();
            case "steeringAngle": return data.getSteeringAngle();
            case "batteryVoltage": return data.getBatteryVoltage();
            case "fuelLevel": return data.getFuelLevel();
            case "odometer": return data.getOdometer();
            case "accelX": return data.getAccelX();
            case "accelY": return data.getAccelY();
            case "accelZ": return data.getAccelZ();
            default: return 0.0;
        }
    }
    
    // ==================== FrontendInterface 实现 ====================
    
    @Override
    public void start() {
        launch(JavaFXFrontend.class);
    }
    
    @Override
    public void shutdown() {
        Platform.runLater(() -> {
            if (primaryStage != null) {
                primaryStage.close();
            }
        });
    }
    
    @Override
    public void updateRealtimeData(VehicleData data) {
        if (currentMode != DisplayMode.REALTIME) return;
        
        Platform.runLater(() -> {
            for (Map.Entry<String, Label> entry : valueLabels.entrySet()) {
                String signal = entry.getKey();
                Label label = entry.getValue();
                double value = dataBuffer != null ? 
                    dataBuffer.getSignalValue(data, signal) : getSignalValue(data, signal);
                label.setText(String.format("%.1f", value));
            }
        });
    }
    
    @Override
    public void updateChartData(List<VehicleData> dataList) {
        if (currentMode != DisplayMode.REALTIME) return;
        
        Platform.runLater(() -> {
            for (VehicleData data : dataList) {
                addDataToChart(data);
            }
        });
    }
    
    @Override
    public void updateStorageStatus(StorageInterface.StorageInfo info) {
        Platform.runLater(() -> {
            formatLabel.setText(info.getFormatName());
            fileSizeLabel.setText(String.format("%.2f MB", info.getFileSizeMb()));
            dataCountLabel.setText(String.valueOf(info.getRecordCount()));
            writeRateLabel.setText(String.format("%.1f 条/秒", info.getWriteRate()));
        });
    }
    
    @Override
    public void setRecordingState(boolean isRecording) {
        Platform.runLater(() -> {
            if (isRecording) {
                statusLabel.setText("正在记录...");
                statusLabel.setTextFill(RECORDING_COLOR);
                startButton.setDisable(true);
                stopButton.setDisable(false);
                formatComboBox.setDisable(false);
                switchFormatButton.setDisable(false);
            } else {
                statusLabel.setText("已停止");
                statusLabel.setTextFill(TEXT_COLOR);
                startButton.setDisable(false);
                stopButton.setDisable(true);
                formatComboBox.setDisable(true);
                switchFormatButton.setDisable(true);
            }
        });
    }
    
    @Override
    public void showMessage(String message, MessageType type) {
        Platform.runLater(() -> {
            Alert.AlertType alertType;
            switch (type) {
                case WARNING: alertType = Alert.AlertType.WARNING; break;
                case ERROR: alertType = Alert.AlertType.ERROR; break;
                default: alertType = Alert.AlertType.INFORMATION; break;
            }
            
            Alert alert = new Alert(alertType);
            alert.setTitle(type.toString());
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
    
    @Override
    public List<String> getSelectedSignals() {
        List<String> selected = new ArrayList<>();
        for (Map.Entry<String, CheckBox> entry : signalCheckBoxes.entrySet()) {
            if (entry.getValue().isSelected()) {
                selected.add(entry.getKey());
            }
        }
        return selected;
    }
    
    @Override
    public void addStatusListener(FrontendStatusListener listener) {
        statusListeners.add(listener);
    }
    
    @Override
    public void removeStatusListener(FrontendStatusListener listener) {
        statusListeners.remove(listener);
    }
    
    // ==================== 通知方法 ====================
    
    private void notifyStartRecording() {
        String format = formatComboBox.getValue();
        if (format == null) format = "csv";
        
        for (FrontendStatusListener listener : statusListeners) {
            listener.onStartRecording(format);
        }
    }
    
    private void notifyStopRecording() {
        for (FrontendStatusListener listener : statusListeners) {
            listener.onStopRecording();
        }
    }
    
    private void notifySwitchFormat() {
        String newFormat = formatComboBox.getValue();
        if (newFormat != null) {
            for (FrontendStatusListener listener : statusListeners) {
                listener.onSwitchFormat(newFormat);
            }
        }
    }
    
    // ==================== 公共方法 ====================
    
    public void setDataBuffer(DataBuffer dataBuffer) {
        this.dataBuffer = dataBuffer;
        
        dataBuffer.addDataListener(dataList -> {
            if (!dataList.isEmpty()) {
                VehicleData latest = dataList.get(dataList.size() - 1);
                updateRealtimeData(latest);
                updateChartData(Collections.singletonList(latest));
            }
        });
        
        updateChartSeries();
    }
    
    public void setHistoryManager(DataHistoryManager historyManager) {
        this.historyManager = historyManager;
        
        historyManager.addFileListListener(files -> {
            Platform.runLater(() -> {
                historyFileItems.clear();
                historyFileItems.addAll(files);
            });
        });
        
        historyManager.addHistoryDataListener(data -> {
            Platform.runLater(() -> {
                clearChart();
                dataPointCounter = 0;
                for (VehicleData d : data) {
                    addDataToChart(d);
                }
            });
        });
        
        historyManager.scanHistoryFiles();
    }
    
    public void setAvailableFormats(List<String> formats) {
        Platform.runLater(() -> {
            formatComboBox.getItems().clear();
            formatComboBox.getItems().addAll(formats);
            if (!formats.isEmpty()) {
                formatComboBox.setValue(formats.get(0));
            }
        });
    }
    
    public void updateRecordTime(String timeStr) {
        Platform.runLater(() -> recordTimeLabel.setText(timeStr));
    }
}
