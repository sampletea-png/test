# 汽车数据实时记录系统 V4

一个功能完整的汽车数据实时记录工具，支持GB级大文件的直接内存读写，无需中间转储。

## 核心特性

### 大文件支持
- **直接内存写入**：数据从内存直接写入最终文件，无中间转储
- **流式读取**：支持迭代器分块读取，避免内存溢出
- **GB级支持**：支持GB级大文件的高效读写

### 自动依赖管理
- **asammdf自动安装**：当Python的asammdf库不存在时，自动下载安装
- **无需手动配置**：首次使用MDF4格式时自动处理依赖

### 存储格式
| 格式 | 扩展名 | 写入方式 | 读取方式 | 大文件支持 |
|------|--------|----------|----------|------------|
| CSV | .csv | 流式直接写入 | 迭代器/分块读取 | ✓ |
| JSON | .json | 流式直接写入 (Lines格式) | 迭代器/分块读取 | ✓ |
| SQLite | .db | 批量插入 | 分页查询/迭代器 | ✓ |
| MDF4 | .mf4 | 流式直接写入 (asammdf) | 分块读取 | ✓ |

## 环境要求

### Java环境
- **JDK 21** (必需)
- Maven 3.6+ (可选，用于构建)

### Python环境（用于MDF4格式）
- Python 3.8+ (必需)
- asammdf (自动安装)
- numpy (自动安装)

> **注意**：asammdf和numpy会在首次使用MDF4格式时自动安装，无需手动操作。

## 快速开始

### 1. 确保JDK 21已安装
```bash
java -version
# 应显示: openjdk version "21" 或类似信息
```

### 2. 确保Python已安装
```bash
python --version
# 或
python3 --version
```

### 3. 运行应用
```bash
# Linux/macOS
./scripts/run.sh

# Windows
scripts\run.bat
```

首次使用MDF4格式时，系统会自动下载并安装asammdf和numpy，这可能需要几分钟时间。

## 大文件读写示例

### 写入（直接内存到文件）
```java
// 创建存储实例
Mdf4Storage storage = new Mdf4Storage(config);
storage.open(Path.of("output/large_file.mf4"));

// 直接写入 - 无中间转储
while (hasMoreData()) {
    VehicleData data = getNextData();  // 从内存获取数据
    storage.write(data);               // 直接写入MDF4
}

storage.close();
```

### 读取（迭代器模式 - 推荐用于大文件）
```java
// 打开文件
storage.openForRead(Path.of("output/large_file.mf4"));

// 使用迭代器流式读取 - 内存占用恒定
Iterator<VehicleData> iterator = storage.iterator();
while (iterator.hasNext()) {
    VehicleData data = iterator.next();  // 逐条读取
    process(data);
}
```

### 读取（分块模式）
```java
// 分块读取 - 控制内存使用
long offset = 0;
int chunkSize = 10000;  // 每次读取1万条

while (true) {
    List<VehicleData> chunk = storage.readChunk(offset, chunkSize);
    if (chunk.isEmpty()) break;
    
    process(chunk);
    offset += chunk.size();
}
```

## 项目结构

```
automotive_data_logger_v4/
├── java/
│   ├── pom.xml                          # Maven配置 (JDK 21 + JavaFX 21)
│   └── src/main/java/com/automotive/logger/
│       ├── VehicleDataLoggerApp.java    # 主应用入口
│       ├── model/
│       │   └── VehicleData.java         # 数据模型
│       ├── service/
│       │   ├── DataSimulatorService.java    # 数据模拟服务
│       │   └── DataLoggerService.java       # 数据记录服务
│       ├── storage/
│       │   ├── StorageInterface.java        # 存储接口（支持迭代器）
│       │   ├── StorageConfig.java           # 存储配置
│       │   ├── StorageFactory.java          # 存储工厂
│       │   ├── BaseStorage.java             # 存储基类
│       │   ├── CsvStorage.java              # CSV存储（迭代器支持）
│       │   ├── JsonStorage.java             # JSON存储（迭代器支持）
│       │   ├── SqliteStorage.java           # SQLite存储（分页查询）
│       │   └── Mdf4Storage.java             # MDF4存储（自动安装asammdf）
│       ├── data/
│       │   ├── DataBuffer.java              # 数据缓冲区
│       │   └── DataHistoryManager.java      # 历史数据管理（大文件模式）
│       └── frontend/
│           ├── FrontendInterface.java       # 前端接口
│           └── javafx/
│               └── JavaFXFrontend.java      # JavaFX实现
├── python/
│   ├── mdf4_writer_stream.py          # MDF4流式读写脚本
│   └── requirements.txt               # Python依赖
├── scripts/
│   ├── run.sh / run.bat               # 启动脚本
│   └── compile.sh / compile.bat       # 编译脚本
└── README.md
```

## 手动编译

如果没有Maven，可以使用手动编译脚本：

```bash
# Linux/macOS
./scripts/compile.sh

# Windows
scripts\compile.bat
```

这将自动下载所有依赖（JavaFX 21、Gson、SQLite JDBC）并编译项目。

## 大文件配置

### 分块大小配置
```java
StorageConfig config = new StorageConfig();

// CSV分块大小
config.setOption("csv.chunkSize", 10000);

// JSON分块大小
config.setOption("json.chunkSize", 10000);

// SQLite分页大小
config.setOption("sqlite.pageSize", 10000);

// MDF4分块大小
config.setOption("mdf4.chunkSize", 10000);
```

### 大文件阈值
```java
// 超过100MB的文件使用大文件模式
DataHistoryManager historyManager = new DataHistoryManager(outputDir);
// 自动检测文件大小，大文件使用迭代器模式
```

## 存储接口方法

### 写入操作
- `open(Path)` - 打开/创建文件
- `write(VehicleData)` - 写入单条数据
- `writeBatch(List<VehicleData>)` - 批量写入
- `flush()` - 刷新缓冲区
- `close()` - 关闭文件

### 读取操作
- `openForRead(Path)` - 打开文件读取
- `iterator()` - 获取迭代器（流式读取）
- `readChunk(offset, count)` - 分块读取
- `readAll()` - 读取全部（小文件）
- `readRange(startTime, endTime)` - 读取时间范围
- `readLatest(count)` - 读取最新N条
- `getTimeRange()` - 获取时间范围
- `getTotalRecordCount()` - 获取总记录数

## asammdf自动安装

当首次使用MDF4格式时，系统会自动执行以下操作：

1. 检查Python是否已安装
2. 检查asammdf是否已安装
3. 如果未安装，自动运行 `pip install asammdf numpy --user`
4. 等待安装完成后继续执行

安装过程可能需要几分钟，请耐心等待。安装成功后，后续使用无需再次安装。

### 手动安装
如果自动安装失败，可以手动安装：
```bash
pip install asammdf numpy
```

## 性能对比

| 操作 | 小文件(<100MB) | 大文件(>1GB) |
|------|----------------|--------------|
| 写入 | 直接写入 | 流式写入 |
| 读取 | 全部加载 | 迭代器/分块 |
| 内存占用 | 与文件大小相关 | 恒定（分块大小） |

## 常见问题

### Q: JDK版本要求？
A: 必须使用JDK 21，JavaFX版本也是21。

### Q: asammdf自动安装失败？
A: 可以尝试手动安装：
```bash
pip install asammdf numpy
```

### Q: 如何处理GB级大文件？
A: 使用迭代器模式或分块读取：
```java
Iterator<VehicleData> it = storage.iterator();
while (it.hasNext()) {
    process(it.next());
}
```

### Q: 可以追加写入吗？
A: 支持，打开时设置append模式：
```java
config.setAppendMode(true);
storage.open(filePath);
```

### Q: 如何优化写入性能？
A: 调整批量大小：
```java
config.setBatchSize(1000);  // 每1000条刷新一次
```

## License

MIT License
