package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPOutputStream;

/**
 * CSV存储格式实现
 * 支持标准CSV和GZIP压缩
 */
public class CsvStorage extends BaseStorage {
    
    private static final String[] HEADERS = {
        "timestamp", "can_channel", "can_id",
        "vehicle_speed", "engine_rpm", "engine_temp",
        "throttle_position", "brake_position", "steering_angle",
        "battery_voltage", "fuel_level", "odometer",
        "accel_x", "accel_y", "accel_z"
    };
    
    private BufferedWriter writer;
    private boolean headerWritten = false;
    
    public CsvStorage(StorageConfig config) {
        super(config);
    }
    
    @Override
    public String getFormatName() {
        return "csv";
    }
    
    @Override
    public String getFileExtension() {
        return "csv";
    }
    
    @Override
    public boolean supportsAppend() {
        return true;
    }
    
    @Override
    protected void doOpen(Path filePath) throws IOException {
        // 确保目录存在
        filePath.getParent().toFile().mkdirs();
        
        // 检查是否追加模式
        boolean fileExists = filePath.toFile().exists() && filePath.toFile().length() > 0;
        headerWritten = fileExists && config.isAppendMode();
        
        // 根据压缩选项创建输出流
        OutputStream os = new FileOutputStream(filePath.toFile(), config.isAppendMode());
        
        if ("gzip".equals(config.getCompression())) {
            os = new GZIPOutputStream(os);
            currentFilePath = filePath.resolveSibling(filePath.getFileName() + ".gz");
        } else {
            currentFilePath = filePath;
        }
        
        writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        
        // 写入表头
        if (!headerWritten) {
            writeHeader();
        }
    }
    
    private void writeHeader() throws IOException {
        writer.write(String.join(",", HEADERS));
        writer.newLine();
        headerWritten = true;
    }
    
    @Override
    protected void doWrite(VehicleData data) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(data.getTimestamp()).append(",");
        sb.append(data.getCanChannel()).append(",");
        sb.append(data.getCanId()).append(",");
        sb.append(data.getVehicleSpeed()).append(",");
        sb.append(data.getEngineRpm()).append(",");
        sb.append(data.getEngineTemp()).append(",");
        sb.append(data.getThrottlePosition()).append(",");
        sb.append(data.getBrakePosition()).append(",");
        sb.append(data.getSteeringAngle()).append(",");
        sb.append(data.getBatteryVoltage()).append(",");
        sb.append(data.getFuelLevel()).append(",");
        sb.append(data.getOdometer()).append(",");
        sb.append(data.getAccelX()).append(",");
        sb.append(data.getAccelY()).append(",");
        sb.append(data.getAccelZ());
        
        writer.write(sb.toString());
        writer.newLine();
    }
    
    @Override
    protected void doWriteBatch(List<VehicleData> dataList) throws IOException {
        for (VehicleData data : dataList) {
            doWrite(data);
        }
        writer.flush();
    }
    
    @Override
    protected void doFlush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }
    
    @Override
    protected void doClose() throws IOException {
        if (writer != null) {
            writer.flush();
            writer.close();
            writer = null;
        }
    }
    
    @Override
    public long getFileSize() {
        if (currentFilePath != null) {
            return currentFilePath.toFile().length();
        }
        return 0;
    }
}
