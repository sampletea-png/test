package com.automotive.logger.storage;

import com.automotive.logger.model.VehicleData;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * 存储接口 - 定义所有存储格式的通用接口
 * 所有存储格式必须实现此接口
 */
public interface StorageInterface {
    
    /**
     * 获取格式名称
     */
    String getFormatName();
    
    /**
     * 获取文件扩展名
     */
    String getFileExtension();
    
    /**
     * 是否支持追加模式
     */
    boolean supportsAppend();
    
    /**
     * 打开/创建存储文件
     * 
     * @param filePath 文件路径，如果为null则自动生成
     * @return 是否成功
     */
    boolean open(Path filePath) throws IOException;
    
    /**
     * 写入单条数据
     * 
     * @param data 车辆数据
     * @return 是否成功
     */
    boolean write(VehicleData data) throws IOException;
    
    /**
     * 批量写入数据
     * 
     * @param dataList 数据列表
     * @return 是否成功
     */
    boolean writeBatch(List<VehicleData> dataList) throws IOException;
    
    /**
     * 刷新缓冲区到磁盘
     */
    void flush() throws IOException;
    
    /**
     * 关闭存储文件
     */
    void close() throws IOException;
    
    /**
     * 获取当前文件大小（字节）
     */
    long getFileSize();
    
    /**
     * 获取已写入记录数
     */
    long getRecordCount();
    
    /**
     * 获取当前文件路径
     */
    Path getCurrentFilePath();
    
    /**
     * 获取存储信息
     */
    StorageInfo getInfo();
    
    /**
     * 设置配置选项
     */
    void setOptions(Map<String, Object> options);
    
    /**
     * 存储信息类
     */
    class StorageInfo {
        private String formatName;
        private String filePath;
        private boolean isOpen;
        private long recordCount;
        private long fileSizeBytes;
        private double fileSizeMb;
        private long startTime;
        private long durationMs;
        private double writeRate;
        
        // Getters and Setters
        public String getFormatName() { return formatName; }
        public void setFormatName(String formatName) { this.formatName = formatName; }
        
        public String getFilePath() { return filePath; }
        public void setFilePath(String filePath) { this.filePath = filePath; }
        
        public boolean isOpen() { return isOpen; }
        public void setOpen(boolean open) { isOpen = open; }
        
        public long getRecordCount() { return recordCount; }
        public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
        
        public long getFileSizeBytes() { return fileSizeBytes; }
        public void setFileSizeBytes(long fileSizeBytes) { 
            this.fileSizeBytes = fileSizeBytes;
            this.fileSizeMb = fileSizeBytes / (1024.0 * 1024.0);
        }
        
        public double getFileSizeMb() { return fileSizeMb; }
        
        public long getStartTime() { return startTime; }
        public void setStartTime(long startTime) { this.startTime = startTime; }
        
        public long getDurationMs() { return durationMs; }
        public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
        
        public double getWriteRate() { return writeRate; }
        public void setWriteRate(double writeRate) { this.writeRate = writeRate; }
    }
}
