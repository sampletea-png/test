package com.automotive.logger.model;

import java.io.Serializable;

/**
 * 车辆数据模型类
 * 包含常见的汽车传感器数据
 */
public class VehicleData implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // 时间戳（毫秒）
    private long timestamp;
    
    // CAN总线通道
    private int canChannel;
    
    // CAN消息ID
    private int canId;
    
    // 车速 (km/h)
    private double vehicleSpeed;
    
    // 发动机转速 (RPM)
    private double engineRpm;
    
    // 发动机温度 (°C)
    private double engineTemp;
    
    // 油门位置 (%)
    private double throttlePosition;
    
    // 刹车踏板位置 (%)
    private double brakePosition;
    
    // 方向盘角度 (度)
    private double steeringAngle;
    
    // 电池电压 (V)
    private double batteryVoltage;
    
    // 燃油液位 (%)
    private double fuelLevel;
    
    // 里程表读数 (km)
    private double odometer;
    
    // 横向加速度 (m/s²)
    private double accelX;
    
    // 纵向加速度 (m/s²)
    private double accelY;
    
    // 垂直加速度 (m/s²)
    private double accelZ;
    
    // 原始CAN数据字节
    private byte[] rawCanData;
    
    public VehicleData() {
        this.timestamp = System.currentTimeMillis();
    }
    
    // Getters and Setters
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    
    public int getCanChannel() { return canChannel; }
    public void setCanChannel(int canChannel) { this.canChannel = canChannel; }
    
    public int getCanId() { return canId; }
    public void setCanId(int canId) { this.canId = canId; }
    
    public double getVehicleSpeed() { return vehicleSpeed; }
    public void setVehicleSpeed(double vehicleSpeed) { this.vehicleSpeed = vehicleSpeed; }
    
    public double getEngineRpm() { return engineRpm; }
    public void setEngineRpm(double engineRpm) { this.engineRpm = engineRpm; }
    
    public double getEngineTemp() { return engineTemp; }
    public void setEngineTemp(double engineTemp) { this.engineTemp = engineTemp; }
    
    public double getThrottlePosition() { return throttlePosition; }
    public void setThrottlePosition(double throttlePosition) { this.throttlePosition = throttlePosition; }
    
    public double getBrakePosition() { return brakePosition; }
    public void setBrakePosition(double brakePosition) { this.brakePosition = brakePosition; }
    
    public double getSteeringAngle() { return steeringAngle; }
    public void setSteeringAngle(double steeringAngle) { this.steeringAngle = steeringAngle; }
    
    public double getBatteryVoltage() { return batteryVoltage; }
    public void setBatteryVoltage(double batteryVoltage) { this.batteryVoltage = batteryVoltage; }
    
    public double getFuelLevel() { return fuelLevel; }
    public void setFuelLevel(double fuelLevel) { this.fuelLevel = fuelLevel; }
    
    public double getOdometer() { return odometer; }
    public void setOdometer(double odometer) { this.odometer = odometer; }
    
    public double getAccelX() { return accelX; }
    public void setAccelX(double accelX) { this.accelX = accelX; }
    
    public double getAccelY() { return accelY; }
    public void setAccelY(double accelY) { this.accelY = accelY; }
    
    public double getAccelZ() { return accelZ; }
    public void setAccelZ(double accelZ) { this.accelZ = accelZ; }
    
    public byte[] getRawCanData() { return rawCanData; }
    public void setRawCanData(byte[] rawCanData) { this.rawCanData = rawCanData; }
    
    /**
     * 将数据转换为CSV格式字符串
     */
    public String toCsvString() {
        return String.format("%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.4f,%.4f,%.4f",
            timestamp, canChannel, canId, vehicleSpeed, engineRpm, engineTemp,
            throttlePosition, brakePosition, steeringAngle, batteryVoltage,
            fuelLevel, odometer, accelX, accelY, accelZ
        );
    }
    
    /**
     * 获取CSV头
     */
    public static String getCsvHeader() {
        return "timestamp,can_channel,can_id,vehicle_speed,engine_rpm,engine_temp," +
               "throttle_position,brake_position,steering_angle,battery_voltage," +
               "fuel_level,odometer,accel_x,accel_y,accel_z";
    }
    
    @Override
    public String toString() {
        return String.format("VehicleData[time=%d, speed=%.1f km/h, rpm=%.0f, temp=%.1f°C]",
            timestamp, vehicleSpeed, engineRpm, engineTemp);
    }
}
