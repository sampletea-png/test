# MDF4 Python Library

Python bindings for the high-performance MDF4 file library.

## Installation

### Prerequisites

- Python 3.7 or higher
- Java 11 or higher
- JPype1

### Install from source

```bash
cd python/mdf4
pip install -e .
```

## Usage

### Writing Data

```python
import mdf4
import numpy as np

# Create sample data
num_samples = 10000
timestamps = np.arange(num_samples, dtype=np.uint64) * 1_000_000  # 1ms intervals
values = np.random.randn(num_samples)

# Write to MDF4 file
with mdf4.open('data.mf4', mode='write') as f:
    ch = f.create_channel('EngineSpeed', unit='rpm', dtype='float64')
    ch.write(timestamps, values)
```

### Reading Data

```python
import mdf4

# Read from MDF4 file
with mdf4.open('data.mf4', mode='read') as f:
    for ch in f.channels:
        print(f"Channel: {ch.name}, Records: {ch.record_count}")
```

### Multiple Channels

```python
import mdf4
import numpy as np

num_samples = 1000
timestamps = np.arange(num_samples, dtype=np.uint64) * 1_000_000

with mdf4.open('multi.mf4', mode='write') as f:
    # Create multiple channels
    ch1 = f.create_channel('EngineSpeed', unit='rpm', dtype='float64')
    ch2 = f.create_channel('ThrottlePosition', unit='%', dtype='float32')
    ch3 = f.create_channel('Gear', dtype='int32')
    
    # Write data
    ch1.write(timestamps, np.random.randn(num_samples))
    ch2.write(timestamps, np.random.rand(num_samples).astype(np.float32) * 100)
    ch3.write(timestamps, np.ones(num_samples, dtype=np.int32) * 5)
```

## API Reference

### `mdf4.open(filepath, mode='read')`

Open an MDF4 file.

**Parameters:**
- `filepath` (str): Path to the MDF4 file
- `mode` (str): File mode ('read', 'write', 'append', 'read_write')

**Returns:** `Mdf4File` object

### `Mdf4File`

#### Methods

- `create_channel(name, unit='', dtype='float64', **kwargs)`: Create a new channel
- `get_channel(channel_id)`: Get channel by ID
- `get_channel_by_name(name)`: Get channel by name
- `flush()`: Flush all pending writes
- `close()`: Close the file

#### Properties

- `filepath`: File path
- `mode`: File mode
- `is_open`: Whether file is open
- `channels`: List of channels
- `channel_count`: Number of channels

### `Channel`

#### Methods

- `write(timestamps, values)`: Write data to channel
- `read(start=None, end=None)`: Read data from channel

#### Properties

- `channel_id`: Channel ID
- `name`: Channel name
- `unit`: Channel unit
- `dtype`: Data type
- `record_count`: Number of records

### `ChannelConfig`

Channel configuration class.

**Class Methods:**
- `create_double(name, unit='')`: Create double precision channel
- `create_float(name, unit='')`: Create single precision channel
- `create_int32(name, unit='')`: Create 32-bit integer channel
- `create_uint32(name, unit='')`: Create 32-bit unsigned integer channel
- `create_time_channel(name='Time')`: Create time channel

## Data Types

| Type | Description |
|------|-------------|
| `float64` | Double precision floating point |
| `float32` | Single precision floating point |
| `int64` | 64-bit signed integer |
| `int32` | 32-bit signed integer |
| `int16` | 16-bit signed integer |
| `int8` | 8-bit signed integer |
| `uint64` | 64-bit unsigned integer |
| `uint32` | 32-bit unsigned integer |
| `uint16` | 16-bit unsigned integer |
| `uint8` | 8-bit unsigned integer |

## Examples

See the `examples/` directory for more usage examples.

## License

MIT License
