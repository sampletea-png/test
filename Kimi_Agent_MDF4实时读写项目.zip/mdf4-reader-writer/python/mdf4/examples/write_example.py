"""
Example: Writing data to MDF4 file
"""

import numpy as np
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import mdf4


def write_simple_data():
    """Write simple data to MDF4 file"""
    
    # Create sample data
    num_samples = 10000
    sample_rate = 1000  # Hz
    
    # Time vector in nanoseconds
    timestamps = np.arange(num_samples, dtype=np.uint64) * (1_000_000_000 // sample_rate)
    
    # Generate some signals
    time_sec = timestamps / 1e9
    engine_speed = 3000 + 500 * np.sin(2 * np.pi * 10 * time_sec) + np.random.randn(num_samples) * 50
    throttle_pos = 50 + 30 * np.sin(2 * np.pi * 5 * time_sec) + np.random.randn(num_samples) * 5
    coolant_temp = 90 + 10 * np.sin(2 * np.pi * 0.1 * time_sec) + np.random.randn(num_samples) * 2
    
    # Write to MDF4 file
    output_file = "engine_data.mf4"
    
    print(f"Writing {num_samples} samples to {output_file}...")
    
    with mdf4.open(output_file, mode='write') as f:
        # Create time channel
        time_ch = f.create_channel("Time", unit="s", dtype="float64")
        time_ch.write(timestamps, time_sec)
        
        # Create data channels
        rpm_ch = f.create_channel("EngineSpeed", unit="rpm", dtype="float64")
        rpm_ch.write(timestamps, engine_speed)
        
        throttle_ch = f.create_channel("ThrottlePosition", unit="%", dtype="float64")
        throttle_ch.write(timestamps, throttle_pos)
        
        temp_ch = f.create_channel("CoolantTemp", unit="°C", dtype="float64")
        temp_ch.write(timestamps, coolant_temp)
        
        print(f"Created {f.channel_count} channels")
    
    print(f"File written: {output_file}")
    print(f"File size: {os.path.getsize(output_file) / 1024:.2f} KB")


def write_large_data():
    """Write large dataset to test performance"""
    
    num_samples = 1_000_000  # 1 million samples
    sample_rate = 10000  # 10 kHz
    
    print(f"\nWriting large dataset ({num_samples} samples)...")
    
    timestamps = np.arange(num_samples, dtype=np.uint64) * (1_000_000_000 // sample_rate)
    signal = np.random.randn(num_samples).astype(np.float64)
    
    output_file = "large_data.mf4"
    
    import time
    start_time = time.time()
    
    with mdf4.open(output_file, mode='write') as f:
        ch = f.create_channel("Signal", unit="V", dtype="float64")
        ch.write(timestamps, signal)
    
    elapsed = time.time() - start_time
    file_size = os.path.getsize(output_file)
    throughput = (num_samples * 8) / elapsed / 1024 / 1024  # MB/s
    
    print(f"Written in {elapsed:.2f} seconds")
    print(f"Throughput: {throughput:.2f} MB/s")
    print(f"File size: {file_size / 1024 / 1024:.2f} MB")


def write_multiple_data_types():
    """Write channels with different data types"""
    
    num_samples = 1000
    timestamps = np.arange(num_samples, dtype=np.uint64) * 1_000_000
    
    output_file = "multi_type_data.mf4"
    
    print(f"\nWriting multiple data types to {output_file}...")
    
    with mdf4.open(output_file, mode='write') as f:
        # Float64
        ch1 = f.create_channel("Float64_Channel", dtype="float64")
        ch1.write(timestamps, np.random.randn(num_samples))
        
        # Float32
        ch2 = f.create_channel("Float32_Channel", dtype="float32")
        ch2.write(timestamps, np.random.randn(num_samples).astype(np.float32))
        
        # Int32
        ch3 = f.create_channel("Int32_Channel", dtype="int32")
        ch3.write(timestamps, np.arange(num_samples, dtype=np.int32))
        
        # UInt32
        ch4 = f.create_channel("UInt32_Channel", dtype="uint32")
        ch4.write(timestamps, np.arange(num_samples, dtype=np.uint32))
        
        print(f"Created {f.channel_count} channels with different types")


if __name__ == '__main__':
    try:
        write_simple_data()
        write_large_data()
        write_multiple_data_types()
        print("\nAll examples completed successfully!")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
