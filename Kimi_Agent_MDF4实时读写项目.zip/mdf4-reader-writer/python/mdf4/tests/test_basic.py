"""
Basic tests for MDF4 library
"""

import os
import tempfile
import unittest
import numpy as np

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mdf4 import open as mdf4_open, ChannelConfig
from mdf4.exceptions import Mdf4Error


class TestMdf4Basic(unittest.TestCase):
    """Basic functionality tests"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, "test.mf4")
    
    def tearDown(self):
        """Clean up test fixtures"""
        try:
            if os.path.exists(self.test_file):
                os.remove(self.test_file)
            os.rmdir(self.temp_dir)
        except:
            pass
    
    def test_channel_config_creation(self):
        """Test channel configuration creation"""
        config = ChannelConfig.create_double("EngineSpeed", "rpm")
        self.assertEqual(config.name, "EngineSpeed")
        self.assertEqual(config.unit, "rpm")
        self.assertEqual(config.dtype, ChannelConfig.DTYPE_FLOAT64)
        
        config = ChannelConfig.create_int32("Counter")
        self.assertEqual(config.dtype, ChannelConfig.DTYPE_INT32)
        
        config = ChannelConfig.create_time_channel()
        self.assertEqual(config.name, "Time")
        self.assertEqual(config.unit, "ns")
    
    def test_write_and_read(self):
        """Test writing and reading data"""
        # Skip if Java not available
        try:
            import jpype
        except ImportError:
            self.skipTest("JPype not installed")
        
        # Create test data
        num_samples = 1000
        timestamps = np.arange(num_samples, dtype=np.uint64) * 1_000_000  # 1ms intervals
        values = np.random.randn(num_samples).astype(np.float64)
        
        # Write data
        try:
            with mdf4_open(self.test_file, mode='write') as f:
                ch = f.create_channel("TestChannel", unit="V", dtype="float64")
                ch.write(timestamps, values)
            
            self.assertTrue(os.path.exists(self.test_file))
            self.assertGreater(os.path.getsize(self.test_file), 0)
            
        except Mdf4Error as e:
            # May fail if Java library not built
            print(f"Write test skipped: {e}")
    
    def test_multiple_channels(self):
        """Test writing multiple channels"""
        try:
            import jpype
        except ImportError:
            self.skipTest("JPype not installed")
        
        num_samples = 100
        timestamps = np.arange(num_samples, dtype=np.uint64) * 1_000_000
        
        try:
            with mdf4_open(self.test_file, mode='write') as f:
                # Create multiple channels
                ch1 = f.create_channel("Channel1", dtype="float64")
                ch2 = f.create_channel("Channel2", dtype="float32")
                ch3 = f.create_channel("Channel3", dtype="int32")
                
                # Write data
                ch1.write(timestamps, np.random.randn(num_samples))
                ch2.write(timestamps, np.random.randn(num_samples).astype(np.float32))
                ch3.write(timestamps, np.arange(num_samples, dtype=np.int32))
                
                self.assertEqual(f.channel_count, 3)
                
        except Mdf4Error as e:
            print(f"Multi-channel test skipped: {e}")


class TestChannelConfig(unittest.TestCase):
    """Test channel configuration"""
    
    def test_dtype_properties(self):
        """Test data type properties"""
        config = ChannelConfig.create_double("Test")
        self.assertEqual(config.data_type_id, 2)  # FLOAT
        self.assertEqual(config.bit_count, 64)
        self.assertEqual(config.item_size, 8)
        
        config = ChannelConfig.create_float("Test")
        self.assertEqual(config.bit_count, 32)
        self.assertEqual(config.item_size, 4)
        
        config = ChannelConfig.create_int32("Test")
        self.assertEqual(config.data_type_id, 1)  # SIGNED_INT
        self.assertEqual(config.bit_count, 32)


if __name__ == '__main__':
    unittest.main()
