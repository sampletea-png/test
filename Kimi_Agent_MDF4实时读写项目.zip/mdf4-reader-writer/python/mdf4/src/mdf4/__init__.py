"""
MDF4 - High-performance MDF4 file real-time read/write library

This module provides Python bindings for the Java-based MDF4 library,
enabling real-time read/write operations on MDF4 files with support
for GB-level data volumes.

Example usage:
    import mdf4
    
    # Write data
    with mdf4.open('data.mf4', mode='write') as f:
        ch = f.create_channel('EngineSpeed', unit='rpm', dtype='float64')
        ch.write(timestamps, values)
    
    # Read data
    with mdf4.open('data.mf4', mode='read') as f:
        ch = f.get_channel(1)
        timestamps, values = ch.read()
"""

__version__ = "1.0.0"
__author__ = "MDF4 Team"

from .core import Mdf4File, open
from .channel import Channel, ChannelConfig
from .exceptions import Mdf4Error, Mdf4IOError, Mdf4FormatError

__all__ = [
    "Mdf4File",
    "open",
    "Channel",
    "ChannelConfig",
    "Mdf4Error",
    "Mdf4IOError",
    "Mdf4FormatError",
]
