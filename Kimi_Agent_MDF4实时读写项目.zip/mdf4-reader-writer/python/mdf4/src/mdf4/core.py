"""
MDF4 Core module - Main file operations
"""

import os
import sys
import atexit
from pathlib import Path
from typing import Dict, List, Optional, Union
import numpy as np

from .channel import Channel, ChannelConfig
from .exceptions import (
    Mdf4Error,
    Mdf4IOError,
    Mdf4FormatError,
    Mdf4NotOpenError,
    Mdf4ModeError,
)

# JPype imports (lazy loaded)
_jvm = None
_jpype = None
_java_classes = {}


def _init_jvm(jar_path: Optional[str] = None):
    """Initialize JVM with MDF4 library"""
    global _jvm, _jpype, _java_classes
    
    if _jvm is not None:
        return
    
    try:
        import jpype
        import jpype.imports
        from jpype.types import *
        
        _jpype = jpype
        
        if not jpype.isJVMStarted():
            # Find JAR file
            if jar_path is None:
                # Default path relative to package
                package_dir = Path(__file__).parent.parent.parent
                jar_path = str(package_dir / "java" / "target" / "mdf4-core-1.0.0-SNAPSHOT.jar")
            
            if not os.path.exists(jar_path):
                raise Mdf4Error(f"MDF4 JAR file not found: {jar_path}")
            
            # Start JVM
            jvm_path = jpype.getDefaultJVMPath()
            jpype.startJVM(
                jvm_path,
                "-Djava.class.path=" + jar_path,
                "-Xmx512m",
            )
            
            atexit.register(_shutdown_jvm)
        
        # Import Java classes
        from com.mdf4.core import Mdf4File as JavaMdf4File
        from com.mdf4.core import Mdf4Constants as JavaMdf4Constants
        from com.mdf4.channel import ChannelConfig as JavaChannelConfig
        from com.mdf4.channel import Channel as JavaChannel
        
        _java_classes['Mdf4File'] = JavaMdf4File
        _java_classes['Mdf4Constants'] = JavaMdf4Constants
        _java_classes['ChannelConfig'] = JavaChannelConfig
        _java_classes['Channel'] = JavaChannel
        
        _jvm = jpype
        
    except ImportError:
        raise Mdf4Error("JPype not installed. Run: pip install JPype1")
    except Exception as e:
        raise Mdf4Error(f"Failed to initialize JVM: {e}")


def _shutdown_jvm():
    """Shutdown JVM"""
    global _jvm
    if _jvm is not None and _jvm.isJVMStarted():
        _jvm.shutdownJVM()
        _jvm = None


def _get_open_mode(mode: str):
    """Convert Python mode string to Java OpenMode"""
    JavaMdf4Constants = _java_classes.get('Mdf4Constants')
    if JavaMdf4Constants is None:
        raise Mdf4Error("JVM not initialized")
    
    mode_map = {
        'r': JavaMdf4Constants.OpenMode.READ,
        'read': JavaMdf4Constants.OpenMode.READ,
        'w': JavaMdf4Constants.OpenMode.WRITE,
        'write': JavaMdf4Constants.OpenMode.WRITE,
        'a': JavaMdf4Constants.OpenMode.APPEND,
        'append': JavaMdf4Constants.OpenMode.APPEND,
        'r+': JavaMdf4Constants.OpenMode.READ_WRITE,
        'rw': JavaMdf4Constants.OpenMode.READ_WRITE,
    }
    
    if mode.lower() not in mode_map:
        raise Mdf4Error(f"Invalid mode: {mode}. Use 'r', 'w', 'a', or 'r+'")
    
    return mode_map[mode.lower()]


class Mdf4File:
    """
    MDF4 File class
    
    Provides high-level interface for reading and writing MDF4 files.
    
    Example:
        # Write data
        with Mdf4File('data.mf4', mode='write') as f:
            ch = f.create_channel('EngineSpeed', unit='rpm', dtype='float64')
            ch.write(timestamps, values)
        
        # Read data
        with Mdf4File('data.mf4', mode='read') as f:
            for ch in f.channels:
                print(f"Channel: {ch.name}")
    """
    
    def __init__(self, filepath: str, mode: str = 'read', jar_path: Optional[str] = None):
        """
        Initialize MDF4 file
        
        Args:
            filepath: Path to MDF4 file
            mode: File mode ('read', 'write', 'append', 'read_write')
            jar_path: Path to Java JAR file (optional)
        """
        self._filepath = filepath
        self._mode = mode
        self._java_file = None
        self._channels: Dict[int, Channel] = {}
        self._open = False
        
        # Initialize JVM
        _init_jvm(jar_path)
        
        # Open file
        self._open_file()
    
    def _open_file(self):
        """Open the file"""
        try:
            JavaMdf4File = _java_classes['Mdf4File']
            open_mode = _get_open_mode(self._mode)
            
            self._java_file = JavaMdf4File(self._filepath, open_mode)
            self._java_file.open()
            self._open = True
            
            # Load existing channels if reading
            if self._mode in ('read', 'r', 'read_write', 'r+'):
                self._load_channels()
                
        except Exception as e:
            raise Mdf4IOError(f"Failed to open file: {e}")
    
    def _load_channels(self):
        """Load existing channels from file"""
        try:
            java_channels = self._java_file.getChannels()
            for java_ch in java_channels:
                channel_id = java_ch.getChannelId()
                config = ChannelConfig(
                    name=java_ch.getName(),
                    unit="",  # TODO: Get from Java
                    dtype="float64",  # TODO: Get from Java
                )
                self._channels[channel_id] = Channel(channel_id, config, java_ch)
        except Exception as e:
            # Ignore errors when loading channels
            pass
    
    @property
    def filepath(self) -> str:
        """Get file path"""
        return self._filepath
    
    @property
    def mode(self) -> str:
        """Get file mode"""
        return self._mode
    
    @property
    def is_open(self) -> bool:
        """Check if file is open"""
        return self._open
    
    @property
    def channels(self) -> List[Channel]:
        """Get list of channels"""
        return list(self._channels.values())
    
    @property
    def channel_count(self) -> int:
        """Get number of channels"""
        return len(self._channels)
    
    def create_channel(
        self,
        name: str,
        unit: str = "",
        dtype: str = "float64",
        description: str = "",
        precision: int = 6,
    ) -> Channel:
        """
        Create a new channel
        
        Args:
            name: Channel name
            unit: Unit of measurement
            dtype: Data type (float32, float64, int32, etc.)
            description: Channel description
            precision: Decimal precision for display
        
        Returns:
            Created Channel object
        
        Raises:
            Mdf4ModeError: If file is opened in read mode
        """
        if not self._open:
            raise Mdf4NotOpenError()
        
        if self._mode in ('read', 'r'):
            raise Mdf4ModeError("Cannot create channel in read mode")
        
        try:
            config = ChannelConfig(
                name=name,
                unit=unit,
                dtype=dtype,
                description=description,
                precision=precision,
            )
            
            JavaChannelConfig = _java_classes['ChannelConfig']
            java_config = JavaChannelConfig()
            java_config.setName(name)
            java_config.setUnit(unit)
            java_config.setDataType(config.data_type_id)
            java_config.setBitCount(config.bit_count)
            
            java_channel = self._java_file.createChannel(java_config)
            channel_id = java_channel.getChannelId()
            
            channel = Channel(channel_id, config, java_channel)
            self._channels[channel_id] = channel
            
            return channel
            
        except Exception as e:
            raise Mdf4IOError(f"Failed to create channel: {e}")
    
    def get_channel(self, channel_id: int) -> Optional[Channel]:
        """
        Get channel by ID
        
        Args:
            channel_id: Channel ID
        
        Returns:
            Channel object or None if not found
        """
        return self._channels.get(channel_id)
    
    def get_channel_by_name(self, name: str) -> Optional[Channel]:
        """
        Get channel by name
        
        Args:
            name: Channel name
        
        Returns:
            Channel object or None if not found
        """
        for channel in self._channels.values():
            if channel.name == name:
                return channel
        return None
    
    def flush(self):
        """Flush all pending writes to disk"""
        if not self._open:
            raise Mdf4NotOpenError()
        
        try:
            self._java_file.flush()
        except Exception as e:
            raise Mdf4IOError(f"Failed to flush: {e}")
    
    def close(self):
        """Close the file"""
        if not self._open:
            return
        
        try:
            self._java_file.close()
            self._open = False
            self._channels.clear()
        except Exception as e:
            raise Mdf4IOError(f"Failed to close file: {e}")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
    
    def __repr__(self) -> str:
        return f"Mdf4File('{self._filepath}', mode='{self._mode}', channels={self.channel_count})"


def open(filepath: str, mode: str = 'read', **kwargs) -> Mdf4File:
    """
    Open an MDF4 file
    
    Args:
        filepath: Path to MDF4 file
        mode: File mode ('read', 'write', 'append', 'read_write')
        **kwargs: Additional arguments passed to Mdf4File
    
    Returns:
        Mdf4File object
    
    Example:
        with mdf4.open('data.mf4', mode='write') as f:
            ch = f.create_channel('EngineSpeed', unit='rpm')
            ch.write(timestamps, values)
    """
    return Mdf4File(filepath, mode, **kwargs)
