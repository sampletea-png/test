"""
MDF4 exceptions module
"""


class Mdf4Error(Exception):
    """Base exception for MDF4 operations"""
    
    def __init__(self, message=None):
        self.message = message
        super().__init__(message)


class Mdf4IOError(Mdf4Error):
    """I/O operation error"""
    
    def __init__(self, message=None, cause=None):
        super().__init__(message)
        self.cause = cause


class Mdf4FormatError(Mdf4Error):
    """MDF4 format error"""
    
    def __init__(self, message=None):
        super().__init__(message)


class Mdf4NotOpenError(Mdf4Error):
    """File not opened error"""
    
    def __init__(self, message="File not opened"):
        super().__init__(message)


class Mdf4ModeError(Mdf4Error):
    """Invalid mode error"""
    
    def __init__(self, message="Invalid operation for current mode"):
        super().__init__(message)


class Mdf4ChannelError(Mdf4Error):
    """Channel operation error"""
    
    def __init__(self, message=None):
        super().__init__(message)
