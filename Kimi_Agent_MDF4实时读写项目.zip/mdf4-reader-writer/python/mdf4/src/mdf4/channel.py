"""
MDF4 Channel module
"""

import numpy as np
from typing import Optional, Tuple, Union
from .exceptions import Mdf4Error, Mdf4ChannelError


class ChannelConfig:
    """Channel configuration class"""
    
    # Data types
    DTYPE_FLOAT32 = "float32"
    DTYPE_FLOAT64 = "float64"
    DTYPE_INT8 = "int8"
    DTYPE_INT16 = "int16"
    DTYPE_INT32 = "int32"
    DTYPE_INT64 = "int64"
    DTYPE_UINT8 = "uint8"
    DTYPE_UINT16 = "uint16"
    DTYPE_UINT32 = "uint32"
    DTYPE_UINT64 = "uint64"
    
    # Data type mapping
    _DTYPE_MAP = {
        DTYPE_FLOAT32: (2, 32),   # (type_id, bit_count)
        DTYPE_FLOAT64: (2, 64),
        DTYPE_INT8: (1, 8),
        DTYPE_INT16: (1, 16),
        DTYPE_INT32: (1, 32),
        DTYPE_INT64: (1, 64),
        DTYPE_UINT8: (0, 8),
        DTYPE_UINT16: (0, 16),
        DTYPE_UINT32: (0, 32),
        DTYPE_UINT64: (0, 64),
    }
    
    def __init__(
        self,
        name: str,
        unit: str = "",
        dtype: str = DTYPE_FLOAT64,
        description: str = "",
        precision: int = 6,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None,
    ):
        """
        Initialize channel configuration
        
        Args:
            name: Channel name
            unit: Unit of measurement
            dtype: Data type (float32, float64, int32, etc.)
            description: Channel description
            precision: Decimal precision for display
            min_value: Minimum expected value
            max_value: Maximum expected value
        """
        self.name = name
        self.unit = unit
        self.dtype = dtype
        self.description = description
        self.precision = precision
        self.min_value = min_value
        self.max_value = max_value
        
        if dtype not in self._DTYPE_MAP:
            raise Mdf4Error(f"Unsupported data type: {dtype}")
    
    @property
    def data_type_id(self) -> int:
        """Get data type ID for Java layer"""
        return self._DTYPE_MAP[self.dtype][0]
    
    @property
    def bit_count(self) -> int:
        """Get bit count for Java layer"""
        return self._DTYPE_MAP[self.dtype][1]
    
    @property
    def item_size(self) -> int:
        """Get size of each data item in bytes"""
        return self.bit_count // 8
    
    @classmethod
    def create_double(cls, name: str, unit: str = "") -> "ChannelConfig":
        """Create a double precision floating point channel"""
        return cls(name, unit, dtype=cls.DTYPE_FLOAT64)
    
    @classmethod
    def create_float(cls, name: str, unit: str = "") -> "ChannelConfig":
        """Create a single precision floating point channel"""
        return cls(name, unit, dtype=cls.DTYPE_FLOAT32)
    
    @classmethod
    def create_int32(cls, name: str, unit: str = "") -> "ChannelConfig":
        """Create a 32-bit integer channel"""
        return cls(name, unit, dtype=cls.DTYPE_INT32)
    
    @classmethod
    def create_uint32(cls, name: str, unit: str = "") -> "ChannelConfig":
        """Create a 32-bit unsigned integer channel"""
        return cls(name, unit, dtype=cls.DTYPE_UINT32)
    
    @classmethod
    def create_time_channel(cls, name: str = "Time") -> "ChannelConfig":
        """Create a time channel (64-bit unsigned integer in nanoseconds)"""
        return cls(name, "ns", dtype=cls.DTYPE_UINT64)
    
    def __repr__(self) -> str:
        return f"ChannelConfig(name='{self.name}', dtype='{self.dtype}', unit='{self.unit}')"


class Channel:
    """MDF4 Channel class"""
    
    def __init__(self, channel_id: int, config: ChannelConfig, java_channel=None):
        """
        Initialize channel
        
        Args:
            channel_id: Channel ID
            config: Channel configuration
            java_channel: Java channel object (for internal use)
        """
        self._channel_id = channel_id
        self._config = config
        self._java_channel = java_channel
        self._record_count = 0
    
    @property
    def channel_id(self) -> int:
        """Get channel ID"""
        return self._channel_id
    
    @property
    def name(self) -> str:
        """Get channel name"""
        return self._config.name
    
    @property
    def unit(self) -> str:
        """Get channel unit"""
        return self._config.unit
    
    @property
    def dtype(self) -> str:
        """Get channel data type"""
        return self._config.dtype
    
    @property
    def config(self) -> ChannelConfig:
        """Get channel configuration"""
        return self._config
    
    @property
    def record_count(self) -> int:
        """Get number of records written"""
        return self._record_count
    
    def write(self, timestamps: np.ndarray, values: np.ndarray) -> None:
        """
        Write data to channel
        
        Args:
            timestamps: Array of timestamps (nanoseconds)
            values: Array of values
        
        Raises:
            Mdf4ChannelError: If write fails
        """
        if self._java_channel is None:
            raise Mdf4ChannelError("Channel not properly initialized")
        
        try:
            # Convert to numpy arrays if needed
            timestamps = np.asarray(timestamps, dtype=np.uint64)
            values = np.asarray(values)
            
            # Ensure same length
            if len(timestamps) != len(values):
                raise Mdf4ChannelError("Timestamps and values must have same length")
            
            # Write data based on dtype
            if self._config.dtype in (ChannelConfig.DTYPE_FLOAT64,):
                values = values.astype(np.float64)
                self._java_channel.writeDouble(values.tobytes())
            elif self._config.dtype in (ChannelConfig.DTYPE_FLOAT32,):
                values = values.astype(np.float32)
                self._java_channel.writeFloat(values.tobytes())
            elif self._config.dtype in (ChannelConfig.DTYPE_INT32,):
                values = values.astype(np.int32)
                self._java_channel.writeInt(values.tobytes())
            elif self._config.dtype in (ChannelConfig.DTYPE_INT64,):
                values = values.astype(np.int64)
                self._java_channel.writeLong(values.tobytes())
            elif self._config.dtype in (ChannelConfig.DTYPE_UINT64,):
                values = values.astype(np.uint64)
                self._java_channel.writeLong(values.tobytes())
            else:
                raise Mdf4ChannelError(f"Unsupported data type: {self._config.dtype}")
            
            self._record_count += len(values)
            
        except Exception as e:
            raise Mdf4ChannelError(f"Failed to write data: {e}")
    
    def read(self, start: Optional[int] = None, end: Optional[int] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        Read data from channel
        
        Args:
            start: Start index (inclusive), None for beginning
            end: End index (exclusive), None for end
        
        Returns:
            Tuple of (timestamps, values) as numpy arrays
        
        Raises:
            Mdf4ChannelError: If read fails
        """
        if self._java_channel is None:
            raise Mdf4ChannelError("Channel not properly initialized")
        
        try:
            # TODO: Implement read functionality
            # This requires implementing the read logic in Java layer
            raise NotImplementedError("Read functionality not yet implemented")
            
        except Exception as e:
            raise Mdf4ChannelError(f"Failed to read data: {e}")
    
    def __repr__(self) -> str:
        return f"Channel(id={self._channel_id}, name='{self.name}', dtype='{self.dtype}')"
