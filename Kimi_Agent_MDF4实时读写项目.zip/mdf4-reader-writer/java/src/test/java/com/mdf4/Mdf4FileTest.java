package com.mdf4;

import com.mdf4.block.*;
import com.mdf4.channel.Channel;
import com.mdf4.channel.ChannelConfig;
import com.mdf4.core.Mdf4Constants;
import com.mdf4.core.Mdf4File;
import com.mdf4.exception.Mdf4Exception;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MDF4 File tests
 */
public class Mdf4FileTest {

    @TempDir
    Path tempDir;

    @Test
    @DisplayName("Test create new MDF4 file")
    void testCreateNewFile() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_new.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        assertTrue(file.isOpened());
        assertEquals(400, file.getVersion());
        
        file.close();
        assertFalse(file.isOpened());
    }

    @Test
    @DisplayName("Test create channel")
    void testCreateChannel() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_channel.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        ChannelConfig config = ChannelConfig.createDouble("EngineSpeed")
            .setUnit("rpm");
        
        Channel channel = file.createChannel(config);
        
        assertNotNull(channel);
        assertEquals("EngineSpeed", channel.getName());
        assertEquals(1, file.getChannelCount());
        
        file.close();
    }

    @Test
    @DisplayName("Test create multiple channels")
    void testCreateMultipleChannels() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_multi_channel.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel ch1 = file.createChannel(ChannelConfig.createDouble("Channel1"));
        Channel ch2 = file.createChannel(ChannelConfig.createDouble("Channel2"));
        Channel ch3 = file.createChannel(ChannelConfig.createInt32("Channel3"));
        
        assertNotNull(ch1);
        assertNotNull(ch2);
        assertNotNull(ch3);
        assertEquals(3, file.getChannelCount());
        
        file.close();
    }

    @Test
    @DisplayName("Test write double data")
    void testWriteDoubleData() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_write_double.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel channel = file.createChannel(ChannelConfig.createDouble("TestChannel"));
        
        double[] data = new double[1000];
        for (int i = 0; i < data.length; i++) {
            data[i] = Math.sin(i * 0.01);
        }
        
        channel.writeDouble(data);
        
        assertEquals(1000, channel.getRecordCount());
        
        file.close();
    }

    @Test
    @DisplayName("Test write float data")
    void testWriteFloatData() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_write_float.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel channel = file.createChannel(ChannelConfig.createFloat("TestChannel"));
        
        float[] data = new float[1000];
        for (int i = 0; i < data.length; i++) {
            data[i] = (float) Math.sin(i * 0.01);
        }
        
        channel.writeFloat(data);
        
        assertEquals(1000, channel.getRecordCount());
        
        file.close();
    }

    @Test
    @DisplayName("Test write int data")
    void testWriteIntData() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_write_int.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel channel = file.createChannel(ChannelConfig.createInt32("TestChannel"));
        
        int[] data = new int[1000];
        for (int i = 0; i < data.length; i++) {
            data[i] = i;
        }
        
        channel.writeInt(data);
        
        assertEquals(1000, channel.getRecordCount());
        
        file.close();
    }

    @Test
    @DisplayName("Test read mode prevents write")
    void testReadModePreventsWrite() throws Mdf4Exception {
        // First create a file
        Path filePath = tempDir.resolve("test_read_only.mf4");
        
        Mdf4File writeFile = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        writeFile.open();
        writeFile.createChannel(ChannelConfig.createDouble("TestChannel"));
        writeFile.close();
        
        // Try to open in read mode and create channel
        Mdf4File readFile = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.READ);
        readFile.open();
        
        assertThrows(Mdf4Exception.class, () -> {
            readFile.createChannel(ChannelConfig.createDouble("NewChannel"));
        });
        
        readFile.close();
    }

    @Test
    @DisplayName("Test flush data")
    void testFlushData() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_flush.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel channel = file.createChannel(ChannelConfig.createDouble("TestChannel"));
        
        double[] data = new double[100];
        for (int i = 0; i < data.length; i++) {
            data[i] = i;
        }
        
        channel.writeDouble(data);
        file.flush();
        
        // File should exist and have content
        assertTrue(filePath.toFile().exists());
        assertTrue(filePath.toFile().length() > 0);
        
        file.close();
    }

    @Test
    @DisplayName("Test get channel")
    void testGetChannel() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_get_channel.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        Channel created = file.createChannel(ChannelConfig.createDouble("TestChannel"));
        long channelId = created.getChannelId();
        
        Channel retrieved = file.getChannel(channelId);
        
        assertNotNull(retrieved);
        assertEquals(created.getName(), retrieved.getName());
        
        file.close();
    }

    @Test
    @DisplayName("Test file not opened exception")
    void testFileNotOpenedException() {
        Path filePath = tempDir.resolve("test_not_opened.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        
        assertThrows(Mdf4Exception.class, () -> {
            file.createChannel(ChannelConfig.createDouble("TestChannel"));
        });
    }

    @Test
    @DisplayName("Test double open exception")
    void testDoubleOpenException() throws Mdf4Exception {
        Path filePath = tempDir.resolve("test_double_open.mf4");
        
        Mdf4File file = new Mdf4File(filePath.toString(), Mdf4Constants.OpenMode.WRITE);
        file.open();
        
        assertThrows(Mdf4Exception.class, () -> {
            file.open();
        });
        
        file.close();
    }
}
