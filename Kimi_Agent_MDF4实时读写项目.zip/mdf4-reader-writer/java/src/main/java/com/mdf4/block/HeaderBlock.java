package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;
import com.mdf4.util.ByteBufferUtils;

import java.nio.ByteBuffer;

/**
 * MDF4 HD块（Header Block）
 * 
 * HD块包含文件的全局信息和指向数据组的链接。
 * 
 * 链接段：
 * - DG块链接 (8 bytes): 指向第一个DG块
 * - TX块链接 (8 bytes): 指向文件注释
 * - PR块链接 (8 bytes): 指向项目信息
 * 
 * 数据段：
 * - 开始时间 (8 bytes): 纳秒级时间戳
 * - 时区偏移分钟 (2 bytes)
 * - 夏令时偏移分钟 (2 bytes)
 * - 时间标志 (1 byte)
 * -  reserved (1 byte)
 */
public class HeaderBlock extends Mdf4Block {
    
    // 链接索引
    private static final int LINK_DG_BLOCK = 0;
    private static final int LINK_TX_BLOCK = 1;
    private static final int LINK_PR_BLOCK = 2;
    
    // 链接
    private long dgBlockLink;    // 指向DG块
    private long txBlockLink;    // 指向TX块（注释）
    private long prBlockLink;    // 指向PR块（项目信息）
    
    // 数据段字段
    private long startTimeNs;    // 开始时间（纳秒）
    private short tzOffsetMin;   // 时区偏移（分钟）
    private short dstOffsetMin;  // 夏令时偏移（分钟）
    private byte timeFlags;      // 时间标志
    
    public HeaderBlock() {
        super(Mdf4Constants.HD_BLOCK_TYPE);
        this.dgBlockLink = 0;
        this.txBlockLink = 0;
        this.prBlockLink = 0;
        this.startTimeNs = System.currentTimeMillis() * 1_000_000L;
        this.tzOffsetMin = 0;
        this.dstOffsetMin = 0;
        this.timeFlags = 0;
    }
    
    public long getDgBlockLink() {
        return dgBlockLink;
    }
    
    public void setDgBlockLink(long link) {
        this.dgBlockLink = link;
        markDirty();
    }
    
    public long getTxBlockLink() {
        return txBlockLink;
    }
    
    public void setTxBlockLink(long link) {
        this.txBlockLink = link;
        markDirty();
    }
    
    public long getPrBlockLink() {
        return prBlockLink;
    }
    
    public void setPrBlockLink(long link) {
        this.prBlockLink = link;
        markDirty();
    }
    
    public long getStartTimeNs() {
        return startTimeNs;
    }
    
    public void setStartTimeNs(long timeNs) {
        this.startTimeNs = timeNs;
        markDirty();
    }
    
    public short getTzOffsetMin() {
        return tzOffsetMin;
    }
    
    public void setTzOffsetMin(short offset) {
        this.tzOffsetMin = offset;
        markDirty();
    }
    
    public short getDstOffsetMin() {
        return dstOffsetMin;
    }
    
    public void setDstOffsetMin(short offset) {
        this.dstOffsetMin = offset;
        markDirty();
    }
    
    public byte getTimeFlags() {
        return timeFlags;
    }
    
    public void setTimeFlags(byte flags) {
        this.timeFlags = flags;
        markDirty();
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 链接(3*8=24) + 数据(8+2+2+1+1=14) = 62, 对齐到64
        return 64;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 3;
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        buffer.putLong(dgBlockLink);
        buffer.putLong(txBlockLink);
        buffer.putLong(prBlockLink);
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        this.dgBlockLink = buffer.getLong();
        this.txBlockLink = buffer.getLong();
        this.prBlockLink = buffer.getLong();
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        buffer.putLong(startTimeNs);
        buffer.putShort(tzOffsetMin);
        buffer.putShort(dstOffsetMin);
        buffer.put(timeFlags);
        buffer.put((byte) 0);  // reserved
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        this.startTimeNs = buffer.getLong();
        this.tzOffsetMin = buffer.getShort();
        this.dstOffsetMin = buffer.getShort();
        this.timeFlags = buffer.get();
        buffer.get();  // skip reserved
    }
    
    @Override
    public String toString() {
        return String.format("HeaderBlock{dgLink=%d, txLink=%d, startTime=%d}",
            dgBlockLink, txBlockLink, startTimeNs);
    }
}
