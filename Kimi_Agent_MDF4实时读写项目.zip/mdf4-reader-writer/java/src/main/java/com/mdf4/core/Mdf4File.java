package com.mdf4.core;

import com.mdf4.block.*;
import com.mdf4.cache.PageCache;
import com.mdf4.cache.WriteBuffer;
import com.mdf4.channel.Channel;
import com.mdf4.channel.ChannelConfig;
import com.mdf4.exception.Mdf4Exception;
import com.mdf4.exception.Mdf4FormatException;
import com.mdf4.exception.Mdf4IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * MDF4文件主类
 * 
 * 提供对MDF4文件的读写操作。
 */
public class Mdf4File implements AutoCloseable {
    
    private static final Logger logger = LoggerFactory.getLogger(Mdf4File.class);
    
    // 文件路径
    private final String filePath;
    
    // 打开模式
    private final Mdf4Constants.OpenMode openMode;
    
    // 随机访问文件
    private RandomAccessFile randomAccessFile;
    
    // 文件通道
    private FileChannel fileChannel;
    
    // ID块
    private IdBlock idBlock;
    
    // 头块
    private HeaderBlock headerBlock;
    
    // 数据组列表
    private final List<DataGroupBlock> dataGroups;
    
    // 通道映射
    private final Map<Long, Channel> channels;
    
    // 通道组映射
    private final Map<Long, ChannelGroupBlock> channelGroups;
    
    // 写缓冲区
    private WriteBuffer writeBuffer;
    
    // 页缓存
    private PageCache pageCache;
    
    // 读写锁
    private final ReadWriteLock lock;
    
    // 是否已打开
    private boolean opened;
    
    // 下一个块位置
    private long nextBlockPosition;
    
    // 通道ID生成器
    private final AtomicLong channelIdGenerator;
    
    // 当前数据组
    private DataGroupBlock currentDataGroup;
    
    // 当前通道组
    private ChannelGroupBlock currentChannelGroup;
    
    // 数据块位置
    private long dataBlockPosition;
    
    // 数据块缓冲区
    private ByteBuffer dataBlockBuffer;
    
    public Mdf4File(String filePath, Mdf4Constants.OpenMode openMode) {
        this.filePath = filePath;
        this.openMode = openMode;
        this.dataGroups = new ArrayList<>();
        this.channels = new ConcurrentHashMap<>();
        this.channelGroups = new ConcurrentHashMap<>();
        this.lock = new ReentrantReadWriteLock();
        this.opened = false;
        this.nextBlockPosition = 0;
        this.channelIdGenerator = new AtomicLong(1);
        this.currentDataGroup = null;
        this.currentChannelGroup = null;
        this.dataBlockPosition = 0;
        this.dataBlockBuffer = null;
    }
    
    /**
     * 打开文件
     */
    public void open() throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            if (opened) {
                throw new Mdf4Exception("File already opened");
            }
            
            logger.info("Opening MDF4 file: {}, mode: {}", filePath, openMode);
            
            switch (openMode) {
                case READ:
                    openForRead();
                    break;
                case WRITE:
                    openForWrite();
                    break;
                case APPEND:
                    openForAppend();
                    break;
                case READ_WRITE:
                    openForReadWrite();
                    break;
                default:
                    throw new Mdf4Exception("Unknown open mode: " + openMode);
            }
            
            // 初始化缓存
            initCache();
            
            opened = true;
            logger.info("MDF4 file opened successfully");
            
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to open file: " + filePath, e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 以只读模式打开
     */
    private void openForRead() throws IOException, Mdf4Exception {
        randomAccessFile = new RandomAccessFile(filePath, "r");
        fileChannel = randomAccessFile.getChannel();
        
        // 读取ID块
        readIdBlock();
        
        // 读取头块
        readHeaderBlock();
        
        // 读取数据组
        readDataGroups();
    }
    
    /**
     * 以写入模式打开（新建）
     */
    private void openForWrite() throws IOException {
        randomAccessFile = new RandomAccessFile(filePath, "rw");
        fileChannel = randomAccessFile.getChannel();
        
        // 创建ID块
        idBlock = new IdBlock();
        writeBlock(idBlock, 0);
        
        // 创建头块
        headerBlock = new HeaderBlock();
        nextBlockPosition = IdBlock.ID_BLOCK_SIZE;
        headerBlock.setFilePosition(nextBlockPosition);
        writeBlock(headerBlock, nextBlockPosition);
        
        nextBlockPosition += headerBlock.getBlockSize();
        
        // 创建第一个数据组
        createDataGroup();
    }
    
    /**
     * 以追加模式打开
     */
    private void openForAppend() throws IOException, Mdf4Exception {
        randomAccessFile = new RandomAccessFile(filePath, "rw");
        fileChannel = randomAccessFile.getChannel();
        
        // 读取现有结构
        readIdBlock();
        readHeaderBlock();
        readDataGroups();
        
        // 定位到文件末尾
        nextBlockPosition = fileChannel.size();
        
        // 创建新的数据组
        createDataGroup();
    }
    
    /**
     * 以读写模式打开
     */
    private void openForReadWrite() throws IOException, Mdf4Exception {
        randomAccessFile = new RandomAccessFile(filePath, "rw");
        fileChannel = randomAccessFile.getChannel();
        
        if (fileChannel.size() == 0) {
            // 新文件
            openForWrite();
        } else {
            // 现有文件
            readIdBlock();
            readHeaderBlock();
            readDataGroups();
            nextBlockPosition = fileChannel.size();
        }
    }
    
    /**
     * 初始化缓存
     */
    private void initCache() {
        // 初始化写缓冲区
        if (openMode != Mdf4Constants.OpenMode.READ) {
            writeBuffer = new WriteBuffer(Mdf4Constants.DEFAULT_WRITE_BUFFER_SIZE);
            writeBuffer.setFlushCallback(data -> {
                try {
                    writeRawData(data);
                } catch (Mdf4Exception e) {
                    logger.error("Failed to flush write buffer", e);
                }
            });
        }
        
        // 初始化页缓存
        pageCache = new PageCache(Mdf4Constants.DEFAULT_PAGE_CACHE_SIZE);
        pageCache.setPageLoader((offset, length) -> {
            try {
                return readRawData(offset, length);
            } catch (Mdf4Exception e) {
                logger.error("Failed to load page", e);
                return null;
            }
        });
    }
    
    /**
     * 读取ID块
     */
    private void readIdBlock() throws Mdf4Exception, IOException {
        ByteBuffer buffer = ByteBuffer.allocate(IdBlock.ID_BLOCK_SIZE);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        fileChannel.position(0);
        int read = fileChannel.read(buffer);
        if (read != IdBlock.ID_BLOCK_SIZE) {
            throw new Mdf4FormatException("Failed to read ID block");
        }
        
        buffer.flip();
        idBlock = new IdBlock();
        idBlock.deserialize(buffer);
        
        if (!idBlock.isValid()) {
            throw new Mdf4FormatException("Invalid MDF4 file");
        }
        
        logger.debug("ID block: {}", idBlock);
    }
    
    /**
     * 读取头块
     */
    private void readHeaderBlock() throws Mdf4Exception, IOException {
        ByteBuffer buffer = ByteBuffer.allocate(64);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        fileChannel.position(IdBlock.ID_BLOCK_SIZE);
        int read = fileChannel.read(buffer);
        if (read < 24) {
            throw new Mdf4FormatException("Failed to read header block");
        }
        
        buffer.flip();
        headerBlock = new HeaderBlock();
        headerBlock.deserialize(buffer);
        
        logger.debug("Header block: {}", headerBlock);
    }
    
    /**
     * 读取数据组
     */
    private void readDataGroups() throws Mdf4Exception, IOException {
        long dgLink = headerBlock.getDgBlockLink();
        
        while (dgLink != 0) {
            DataGroupBlock dgBlock = readBlock(dgLink, DataGroupBlock.class);
            dataGroups.add(dgBlock);
            
            // 读取通道组
            readChannelGroups(dgBlock);
            
            dgLink = dgBlock.getNextDgLink();
        }
    }
    
    /**
     * 读取通道组
     */
    private void readChannelGroups(DataGroupBlock dgBlock) throws Mdf4Exception, IOException {
        long cgLink = dgBlock.getFirstCgLink();
        
        while (cgLink != 0) {
            ChannelGroupBlock cgBlock = readBlock(cgLink, ChannelGroupBlock.class);
            channelGroups.put(cgLink, cgBlock);
            
            // 读取通道
            readChannels(cgBlock);
            
            cgLink = cgBlock.getNextCgLink();
        }
    }
    
    /**
     * 读取通道
     */
    private void readChannels(ChannelGroupBlock cgBlock) throws Mdf4Exception, IOException {
        long cnLink = cgBlock.getFirstCnLink();
        
        while (cnLink != 0) {
            ChannelBlock cnBlock = readBlock(cnLink, ChannelBlock.class);
            
            // 创建通道配置
            ChannelConfig config = new ChannelConfig();
            config.setDataType(cnBlock.getDataType());
            config.setBitCount(cnBlock.getBitCount());
            
            // 创建通道
            long channelId = channelIdGenerator.getAndIncrement();
            Channel channel = new Channel(channelId, config, cnBlock);
            channels.put(channelId, channel);
            
            cnLink = cnBlock.getNextCnLink();
        }
    }
    
    /**
     * 读取块
     */
    private <T extends Mdf4Block> T readBlock(long position, Class<T> blockClass) throws Mdf4Exception, IOException {
        // 先读取块头获取大小
        ByteBuffer headerBuffer = ByteBuffer.allocate(24);
        headerBuffer.order(ByteOrder.LITTLE_ENDIAN);
        fileChannel.position(position);
        fileChannel.read(headerBuffer);
        headerBuffer.flip();
        
        String blockType = new String(headerBuffer.array(), 0, 4);
        headerBuffer.getInt();  // skip reserved
        long blockSize = headerBuffer.getLong();
        
        // 读取完整块
        ByteBuffer buffer = ByteBuffer.allocate((int) blockSize);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        fileChannel.position(position);
        fileChannel.read(buffer);
        buffer.flip();
        
        try {
            T block = blockClass.getDeclaredConstructor().newInstance();
            block.setFilePosition(position);
            block.deserialize(buffer);
            return block;
        } catch (Exception e) {
            throw new Mdf4Exception("Failed to create block instance", e);
        }
    }
    
    /**
     * 写入块
     */
    private void writeBlock(Mdf4Block block, long position) throws IOException {
        ByteBuffer buffer = block.serialize();
        fileChannel.position(position);
        fileChannel.write(buffer);
        block.setFilePosition(position);
        block.markClean();
    }
    
    /**
     * 创建数据组
     */
    private void createDataGroup() throws IOException {
        currentDataGroup = new DataGroupBlock();
        currentDataGroup.setFilePosition(nextBlockPosition);
        writeBlock(currentDataGroup, nextBlockPosition);
        
        // 更新头块链接
        if (headerBlock.getDgBlockLink() == 0) {
            headerBlock.setDgBlockLink(nextBlockPosition);
            writeBlock(headerBlock, headerBlock.getFilePosition());
        } else if (!dataGroups.isEmpty()) {
            DataGroupBlock lastDg = dataGroups.get(dataGroups.size() - 1);
            lastDg.setNextDgLink(nextBlockPosition);
            writeBlock(lastDg, lastDg.getFilePosition());
        }
        
        dataGroups.add(currentDataGroup);
        nextBlockPosition += currentDataGroup.getBlockSize();
        
        // 创建通道组
        createChannelGroup();
    }
    
    /**
     * 创建通道组
     */
    private void createChannelGroup() throws IOException {
        currentChannelGroup = new ChannelGroupBlock();
        currentChannelGroup.setFilePosition(nextBlockPosition);
        writeBlock(currentChannelGroup, nextBlockPosition);
        
        // 更新数据组链接
        if (currentDataGroup.getFirstCgLink() == 0) {
            currentDataGroup.setFirstCgLink(nextBlockPosition);
            writeBlock(currentDataGroup, currentDataGroup.getFilePosition());
        }
        
        channelGroups.put(nextBlockPosition, currentChannelGroup);
        nextBlockPosition += currentChannelGroup.getBlockSize();
        
        // 初始化数据块
        initDataBlock();
    }
    
    /**
     * 初始化数据块
     */
    private void initDataBlock() throws IOException {
        dataBlockPosition = nextBlockPosition;
        dataBlockBuffer = ByteBuffer.allocate(Mdf4Constants.DEFAULT_DATA_BLOCK_SIZE);
        dataBlockBuffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // 预留DT块头
        dataBlockBuffer.position(24);
    }
    
    /**
     * 创建通道
     */
    public Channel createChannel(ChannelConfig config) throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            if (!opened) {
                throw new Mdf4Exception("File not opened");
            }
            
            if (openMode == Mdf4Constants.OpenMode.READ) {
                throw new Mdf4Exception("Cannot create channel in read mode");
            }
            
            long channelId = channelIdGenerator.getAndIncrement();
            
            // 创建通道块
            ChannelBlock cnBlock = new ChannelBlock();
            cnBlock.setChannelType(config.isTimeChannel() ? ChannelBlock.CHANNEL_TYPE_TIME : ChannelBlock.CHANNEL_TYPE_DATA);
            cnBlock.setDataType(config.getDataType());
            cnBlock.setBitCount(config.getBitCount());
            cnBlock.setByteOffset((int) currentChannelGroup.getDataSize());
            cnBlock.setSamplingInterval(config.getSamplingInterval());
            
            // 创建名称文本块
            TextBlock nameBlock = new TextBlock(config.getName());
            nameBlock.setFilePosition(nextBlockPosition);
            writeBlock(nameBlock, nextBlockPosition);
            cnBlock.setTxNameLink(nextBlockPosition);
            nextBlockPosition += nameBlock.getBlockSize();
            
            // 设置通道块位置
            cnBlock.setFilePosition(nextBlockPosition);
            
            // 更新通道组链接
            if (currentChannelGroup.getFirstCnLink() == 0) {
                currentChannelGroup.setFirstCnLink(nextBlockPosition);
            } else {
                // 找到最后一个通道并链接
                long lastCnLink = currentChannelGroup.getFirstCnLink();
                ChannelBlock lastCn = channels.values().stream()
                    .filter(c -> c.getChannelBlock().getFilePosition() == lastCnLink)
                    .findFirst()
                    .map(Channel::getChannelBlock)
                    .orElse(null);
                
                if (lastCn != null) {
                    // 需要遍历找到最后一个
                    while (lastCn.getNextCnLink() != 0) {
                        lastCnLink = lastCn.getNextCnLink();
                    }
                }
            }
            
            // 写入通道块
            writeBlock(cnBlock, nextBlockPosition);
            
            // 更新通道组数据大小
            currentChannelGroup.setDataSize(currentChannelGroup.getDataSize() + config.getDataTypeSize());
            writeBlock(currentChannelGroup, currentChannelGroup.getFilePosition());
            
            // 创建通道对象
            Channel channel = new Channel(channelId, config, cnBlock);
            channel.setNameBlock(nameBlock);
            channel.setRecordSize((int) currentChannelGroup.getDataSize());
            channel.setChannelOffset(cnBlock.getByteOffset());
            channel.initWriteBuffer(Mdf4Constants.DEFAULT_WRITE_BUFFER_SIZE);
            
            channels.put(channelId, channel);
            
            nextBlockPosition += cnBlock.getBlockSize();
            
            logger.info("Created channel: {} (ID: {})", config.getName(), channelId);
            
            return channel;
            
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to create channel", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 获取通道
     */
    public Channel getChannel(long channelId) {
        lock.readLock().lock();
        try {
            return channels.get(channelId);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 获取所有通道
     */
    public Collection<Channel> getChannels() {
        lock.readLock().lock();
        try {
            return new ArrayList<>(channels.values());
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 写入通道数据
     */
    public void writeChannelData(long channelId, Object data) throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            Channel channel = channels.get(channelId);
            if (channel == null) {
                throw new Mdf4Exception("Channel not found: " + channelId);
            }
            
            ByteBuffer buffer = channel.getWriteBuffer();
            
            if (data instanceof double[]) {
                for (double v : (double[]) data) {
                    buffer.putDouble(v);
                }
            } else if (data instanceof float[]) {
                for (float v : (float[]) data) {
                    buffer.putFloat(v);
                }
            } else if (data instanceof int[]) {
                for (int v : (int[]) data) {
                    buffer.putInt(v);
                }
            } else if (data instanceof long[]) {
                for (long v : (long[]) data) {
                    buffer.putLong(v);
                }
            } else {
                throw new Mdf4Exception("Unsupported data type: " + data.getClass());
            }
            
            channel.setRecordCount(channel.getRecordCount() + ((Object[]) data).length);
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 写入原始数据
     */
    private void writeRawData(byte[] data) throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            if (dataBlockBuffer.remaining() < data.length) {
                flushDataBlock();
                initDataBlock();
            }
            
            dataBlockBuffer.put(data);
            
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to write data", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 读取原始数据
     */
    private byte[] readRawData(long offset, int length) throws Mdf4Exception {
        lock.readLock().lock();
        try {
            ByteBuffer buffer = ByteBuffer.allocate(length);
            fileChannel.position(offset);
            fileChannel.read(buffer);
            return buffer.array();
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to read data", e);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 刷新数据块
     */
    private void flushDataBlock() throws IOException {
        if (dataBlockBuffer == null || dataBlockBuffer.position() <= 24) {
            return;
        }
        
        dataBlockBuffer.flip();
        
        // 创建DT块
        int dataLength = dataBlockBuffer.remaining() - 24;
        byte[] data = new byte[dataLength];
        dataBlockBuffer.position(24);
        dataBlockBuffer.get(data);
        
        DataBlock dtBlock = new DataBlock(data);
        dtBlock.setFilePosition(dataBlockPosition);
        writeBlock(dtBlock, dataBlockPosition);
        
        // 更新数据组链接
        if (currentDataGroup.getDataLink() == 0) {
            currentDataGroup.setDataLink(dataBlockPosition);
            writeBlock(currentDataGroup, currentDataGroup.getFilePosition());
        }
        
        logger.debug("Flushed data block: {} bytes at position {}", dataLength, dataBlockPosition);
    }
    
    /**
     * 刷新所有数据
     */
    public void flush() throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            // 刷新通道缓冲区
            for (Channel channel : channels.values()) {
                byte[] data = channel.getWriteBufferData();
                if (data.length > 0) {
                    writeRawData(data);
                }
                channel.clearWriteBuffer();
            }
            
            // 刷新写缓冲区
            if (writeBuffer != null) {
                writeBuffer.flush();
            }
            
            // 刷新数据块
            flushDataBlock();
            
            // 强制同步到磁盘
            fileChannel.force(true);
            
            logger.info("All data flushed to disk");
            
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to flush data", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 关闭文件
     */
    @Override
    public void close() throws Mdf4Exception {
        lock.writeLock().lock();
        try {
            if (!opened) {
                return;
            }
            
            logger.info("Closing MDF4 file: {}", filePath);
            
            // 刷新数据
            flush();
            
            // 关闭资源
            if (writeBuffer != null) {
                writeBuffer.close();
            }
            
            if (pageCache != null) {
                pageCache.clear();
            }
            
            if (fileChannel != null) {
                fileChannel.close();
            }
            
            if (randomAccessFile != null) {
                randomAccessFile.close();
            }
            
            opened = false;
            logger.info("MDF4 file closed");
            
        } catch (IOException e) {
            throw new Mdf4IOException("Failed to close file", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 获取文件路径
     */
    public String getFilePath() {
        return filePath;
    }
    
    /**
     * 获取打开模式
     */
    public Mdf4Constants.OpenMode getOpenMode() {
        return openMode;
    }
    
    /**
     * 检查是否已打开
     */
    public boolean isOpened() {
        return opened;
    }
    
    /**
     * 获取通道数量
     */
    public int getChannelCount() {
        return channels.size();
    }
    
    /**
     * 获取文件版本
     */
    public short getVersion() {
        return idBlock != null ? idBlock.getVersion() : 0;
    }
}
