package com.mdf4.exception;

/**
 * MDF4操作异常基类
 */
public class Mdf4Exception extends Exception {
    
    public Mdf4Exception(String message) {
        super(message);
    }
    
    public Mdf4Exception(String message, Throwable cause) {
        super(message, cause);
    }
    
    public Mdf4Exception(Throwable cause) {
        super(cause);
    }
}
