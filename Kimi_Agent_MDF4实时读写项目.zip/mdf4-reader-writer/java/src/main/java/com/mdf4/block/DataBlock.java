package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;

import java.nio.ByteBuffer;

/**
 * MDF4 DT块（Data Block）
 * 
 * DT块存储实际的测量数据。
 * 
 * 结构：
 * - 块头 (24 bytes)
 * - 数据 (可变长度)
 */
public class DataBlock extends Mdf4Block {
    
    // 数据
    private byte[] data;
    
    public DataBlock() {
        super(Mdf4Constants.DT_BLOCK_TYPE);
        this.data = new byte[0];
    }
    
    public DataBlock(byte[] data) {
        super(Mdf4Constants.DT_BLOCK_TYPE);
        this.data = data != null ? data : new byte[0];
    }
    
    public byte[] getData() {
        return data;
    }
    
    public void setData(byte[] data) {
        this.data = data != null ? data : new byte[0];
        markDirty();
    }
    
    public int getDataLength() {
        return data.length;
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 数据长度，对齐到8字节边界
        long size = 24 + data.length;
        return (size + 7) & ~7;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 0;  // DT块没有链接
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        // DT块没有链接段
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        // DT块没有链接段
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        buffer.put(data);
        // 填充对齐
        int padding = (int) (calculateBlockSize() - 24 - data.length);
        for (int i = 0; i < padding; i++) {
            buffer.put((byte) 0);
        }
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        int dataLength = (int) (blockSize - 24);
        this.data = new byte[dataLength];
        buffer.get(this.data);
    }
    
    @Override
    public String toString() {
        return String.format("DataBlock{size=%d bytes}", data.length);
    }
}
