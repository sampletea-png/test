package com.mdf4.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 页缓存
 * 
 * 使用LRU策略缓存数据页，加速随机读取。
 */
public class PageCache {
    
    private static final Logger logger = LoggerFactory.getLogger(PageCache.class);
    
    // 页大小
    public static final int PAGE_SIZE = 4096;  // 4KB
    
    // 缓存映射
    private final LinkedHashMap<Long, CachePage> cache;
    
    // 最大缓存大小（字节）
    private final long maxSize;
    
    // 当前缓存大小
    private long currentSize;
    
    // 读写锁
    private final ReadWriteLock lock;
    
    // 命中计数
    private long hitCount;
    
    // 未命中计数
    private long missCount;
    
    // 页加载回调
    private PageLoader pageLoader;
    
    public PageCache(long maxSize) {
        this.maxSize = maxSize;
        this.currentSize = 0;
        this.hitCount = 0;
        this.missCount = 0;
        this.lock = new ReentrantReadWriteLock();
        
        // 创建LRU缓存
        int initialCapacity = (int) (maxSize / PAGE_SIZE / 0.75f) + 1;
        this.cache = new LinkedHashMap<Long, CachePage>(initialCapacity, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Long, CachePage> eldest) {
                if (currentSize > maxSize) {
                    currentSize -= eldest.getValue().data.length;
                    return true;
                }
                return false;
            }
        };
    }
    
    /**
     * 设置页加载器
     */
    public void setPageLoader(PageLoader loader) {
        this.pageLoader = loader;
    }
    
    /**
     * 获取页
     */
    public ByteBuffer getPage(long pageIndex) {
        lock.readLock().lock();
        try {
            CachePage page = cache.get(pageIndex);
            if (page != null) {
                hitCount++;
                return ByteBuffer.wrap(page.data);
            }
        } finally {
            lock.readLock().unlock();
        }
        
        // 缓存未命中，加载页
        missCount++;
        return loadPage(pageIndex);
    }
    
    /**
     * 加载页
     */
    private ByteBuffer loadPage(long pageIndex) {
        if (pageLoader == null) {
            return null;
        }
        
        long offset = pageIndex * PAGE_SIZE;
        byte[] data = pageLoader.load(offset, PAGE_SIZE);
        
        if (data == null) {
            return null;
        }
        
        lock.writeLock().lock();
        try {
            cache.put(pageIndex, new CachePage(data));
            currentSize += data.length;
        } finally {
            lock.writeLock().unlock();
        }
        
        return ByteBuffer.wrap(data);
    }
    
    /**
     * 将页放入缓存
     */
    public void putPage(long pageIndex, byte[] data) {
        lock.writeLock().lock();
        try {
            CachePage oldPage = cache.get(pageIndex);
            if (oldPage != null) {
                currentSize -= oldPage.data.length;
            }
            cache.put(pageIndex, new CachePage(data));
            currentSize += data.length;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 使缓存页失效
     */
    public void invalidate(long pageIndex) {
        lock.writeLock().lock();
        try {
            CachePage page = cache.remove(pageIndex);
            if (page != null) {
                currentSize -= page.data.length;
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 清空缓存
     */
    public void clear() {
        lock.writeLock().lock();
        try {
            cache.clear();
            currentSize = 0;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 获取缓存命中率
     */
    public double getHitRate() {
        long total = hitCount + missCount;
        return total == 0 ? 0.0 : (double) hitCount / total;
    }
    
    /**
     * 获取命中次数
     */
    public long getHitCount() {
        return hitCount;
    }
    
    /**
     * 获取未命中次数
     */
    public long getMissCount() {
        return missCount;
    }
    
    /**
     * 获取当前缓存大小
     */
    public long getCurrentSize() {
        lock.readLock().lock();
        try {
            return currentSize;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 获取缓存页数
     */
    public int getPageCount() {
        lock.readLock().lock();
        try {
            return cache.size();
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 缓存页
     */
    private static class CachePage {
        final byte[] data;
        
        CachePage(byte[] data) {
            this.data = data;
        }
    }
    
    /**
     * 页加载器接口
     */
    @FunctionalInterface
    public interface PageLoader {
        byte[] load(long offset, int length);
    }
}
