package com.mdf4.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 写缓冲区
 * 
 * 用于聚合多次小写入操作，减少磁盘I/O次数。
 */
public class WriteBuffer {
    
    private static final Logger logger = LoggerFactory.getLogger(WriteBuffer.class);
    
    // 缓冲区
    private ByteBuffer buffer;
    
    // 缓冲区容量
    private final int capacity;
    
    // 刷新阈值
    private final int flushThreshold;
    
    // 写入计数
    private final AtomicLong writeCount;
    
    // 刷新计数
    private final AtomicLong flushCount;
    
    // 是否自动刷新
    private final boolean autoFlush;
    
    // 刷新回调
    private FlushCallback flushCallback;
    
    public WriteBuffer(int capacity) {
        this(capacity, true);
    }
    
    public WriteBuffer(int capacity, boolean autoFlush) {
        this.capacity = capacity;
        this.flushThreshold = (int) (capacity * 0.8);  // 80%阈值
        this.autoFlush = autoFlush;
        this.buffer = ByteBuffer.allocate(capacity);
        this.buffer.order(ByteOrder.LITTLE_ENDIAN);
        this.writeCount = new AtomicLong(0);
        this.flushCount = new AtomicLong(0);
    }
    
    /**
     * 设置刷新回调
     */
    public void setFlushCallback(FlushCallback callback) {
        this.flushCallback = callback;
    }
    
    /**
     * 写入数据
     */
    public synchronized void write(byte[] data) {
        if (data == null || data.length == 0) {
            return;
        }
        
        // 如果数据超过缓冲区容量，直接刷新
        if (data.length > capacity) {
            flush();
            if (flushCallback != null) {
                flushCallback.onFlush(data);
            }
            writeCount.incrementAndGet();
            return;
        }
        
        // 检查剩余空间
        if (buffer.remaining() < data.length) {
            flush();
        }
        
        buffer.put(data);
        writeCount.incrementAndGet();
        
        // 检查是否需要自动刷新
        if (autoFlush && buffer.position() >= flushThreshold) {
            flush();
        }
    }
    
    /**
     * 写入ByteBuffer
     */
    public synchronized void write(ByteBuffer data) {
        if (data == null || !data.hasRemaining()) {
            return;
        }
        
        int remaining = data.remaining();
        
        // 如果数据超过缓冲区容量，直接刷新
        if (remaining > capacity) {
            flush();
            byte[] bytes = new byte[remaining];
            data.get(bytes);
            if (flushCallback != null) {
                flushCallback.onFlush(bytes);
            }
            writeCount.incrementAndGet();
            return;
        }
        
        // 检查剩余空间
        if (buffer.remaining() < remaining) {
            flush();
        }
        
        buffer.put(data);
        writeCount.incrementAndGet();
        
        // 检查是否需要自动刷新
        if (autoFlush && buffer.position() >= flushThreshold) {
            flush();
        }
    }
    
    /**
     * 刷新缓冲区
     */
    public synchronized void flush() {
        if (buffer.position() == 0) {
            return;
        }
        
        buffer.flip();
        byte[] data = new byte[buffer.remaining()];
        buffer.get(data);
        
        if (flushCallback != null) {
            flushCallback.onFlush(data);
        }
        
        buffer.clear();
        flushCount.incrementAndGet();
        
        logger.debug("WriteBuffer flushed: {} bytes", data.length);
    }
    
    /**
     * 获取当前缓冲区大小
     */
    public synchronized int size() {
        return buffer.position();
    }
    
    /**
     * 获取缓冲区容量
     */
    public int capacity() {
        return capacity;
    }
    
    /**
     * 检查缓冲区是否为空
     */
    public synchronized boolean isEmpty() {
        return buffer.position() == 0;
    }
    
    /**
     * 清空缓冲区
     */
    public synchronized void clear() {
        buffer.clear();
    }
    
    /**
     * 获取写入计数
     */
    public long getWriteCount() {
        return writeCount.get();
    }
    
    /**
     * 获取刷新计数
     */
    public long getFlushCount() {
        return flushCount.get();
    }
    
    /**
     * 关闭缓冲区
     */
    public void close() {
        flush();
    }
    
    /**
     * 刷新回调接口
     */
    @FunctionalInterface
    public interface FlushCallback {
        void onFlush(byte[] data);
    }
}
