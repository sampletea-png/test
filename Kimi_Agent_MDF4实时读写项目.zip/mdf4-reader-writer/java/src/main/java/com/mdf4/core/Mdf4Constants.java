package com.mdf4.core;

/**
 * MDF4格式常量定义
 */
public final class Mdf4Constants {
    
    private Mdf4Constants() {}
    
    // 文件魔数
    public static final byte[] MDF_MAGIC = new byte[] { 'M', 'D', 'F' };
    
    // 版本号
    public static final short MDF_VERSION = 400;  // MDF4.00
    public static final short MDF_VERSION_41 = 410;  // MDF4.10
    public static final short MDF_VERSION_42 = 420;  // MDF4.20
    
    // 块类型ID
    public static final String BLOCK_ID = "##";
    public static final String ID_BLOCK_TYPE = "ID";
    public static final String HD_BLOCK_TYPE = "HD";
    public static final String DG_BLOCK_TYPE = "DG";
    public static final String CG_BLOCK_TYPE = "CG";
    public static final String CN_BLOCK_TYPE = "CN";
    public static final String DT_BLOCK_TYPE = "DT";
    public static final String SR_BLOCK_TYPE = "SR";
    public static final String RD_BLOCK_TYPE = "RD";
    public static final String SD_BLOCK_TYPE = "SD";
    public static final String SI_BLOCK_TYPE = "SI";
    public static final String TX_BLOCK_TYPE = "TX";
    public static final String FH_BLOCK_TYPE = "FH";
    public static final String CH_BLOCK_TYPE = "CH";
    
    // 数据类型
    public static final int DT_UNSIGNED_INT = 0;
    public static final int DT_SIGNED_INT = 1;
    public static final int DT_FLOAT = 2;
    public static final int DT_STRING = 3;
    public static final int DT_BYTE_ARRAY = 4;
    public static final int DT_COMPLEX = 5;
    
    // 数值类型大小（字节）
    public static final int SIZEOF_UINT8 = 1;
    public static final int SIZEOF_INT8 = 1;
    public static final int SIZEOF_UINT16 = 2;
    public static final int SIZEOF_INT16 = 2;
    public static final int SIZEOF_UINT32 = 4;
    public static final int SIZEOF_INT32 = 4;
    public static final int SIZEOF_UINT64 = 8;
    public static final int SIZEOF_INT64 = 8;
    public static final int SIZEOF_FLOAT = 4;
    public static final int SIZEOF_DOUBLE = 8;
    
    // 块头大小
    public static final int BLOCK_HEADER_SIZE = 24;  // 4 (id) + 4 (reserved) + 8 (length) + 8 (link count)
    
    // 对齐要求
    public static final int ALIGNMENT = 8;
    
    // 默认缓冲区大小
    public static final int DEFAULT_WRITE_BUFFER_SIZE = 64 * 1024;  // 64KB
    public static final int DEFAULT_READ_BUFFER_SIZE = 256 * 1024;  // 256KB
    public static final int DEFAULT_PAGE_CACHE_SIZE = 16 * 1024 * 1024;  // 16MB
    
    // 默认数据块大小
    public static final int DEFAULT_DATA_BLOCK_SIZE = 64 * 1024 * 1024;  // 64MB
    
    // 内存映射窗口大小
    public static final long DEFAULT_MMAP_WINDOW_SIZE = 256 * 1024 * 1024L;  // 256MB
    
    // 最大通道数
    public static final int MAX_CHANNELS = 10000;
    
    // 时间戳精度（纳秒）
    public static final long TIME_PRECISION_NS = 1L;
    
    // 文件打开模式
    public enum OpenMode {
        READ,           // 只读模式
        WRITE,          // 写入模式（新建或覆盖）
        APPEND,         // 追加模式
        READ_WRITE      // 读写模式
    }
    
    // 压缩类型
    public enum CompressionType {
        NONE,           // 无压缩
        ZLIB,           // ZLIB压缩
        LZ4             // LZ4压缩
    }
}
