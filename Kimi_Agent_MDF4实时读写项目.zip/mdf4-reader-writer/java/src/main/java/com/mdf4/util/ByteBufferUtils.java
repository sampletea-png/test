package com.mdf4.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * ByteBuffer工具类
 */
public class ByteBufferUtils {
    
    /**
     * 创建小端序的ByteBuffer
     */
    public static ByteBuffer createLittleEndian(int capacity) {
        ByteBuffer buffer = ByteBuffer.allocate(capacity);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer;
    }
    
    /**
     * 创建直接缓冲区
     */
    public static ByteBuffer createDirectLittleEndian(int capacity) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(capacity);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer;
    }
    
    /**
     * 读取以0结尾的字符串
     */
    public static String readNullTerminatedString(ByteBuffer buffer, int maxLength) {
        byte[] bytes = new byte[maxLength];
        buffer.get(bytes);
        int length = 0;
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] == 0) {
                length = i;
                break;
            }
        }
        return new String(bytes, 0, length, StandardCharsets.UTF_8);
    }
    
    /**
     * 写入以0结尾的字符串
     */
    public static void writeNullTerminatedString(ByteBuffer buffer, String str, int maxLength) {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        int length = Math.min(bytes.length, maxLength - 1);
        buffer.put(bytes, 0, length);
        // 填充剩余空间为0
        for (int i = length; i < maxLength; i++) {
            buffer.put((byte) 0);
        }
    }
    
    /**
     * 读取UTF-8字符串
     */
    public static String readString(ByteBuffer buffer, int length) {
        byte[] bytes = new byte[length];
        buffer.get(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }
    
    /**
     * 写入UTF-8字符串
     */
    public static void writeString(ByteBuffer buffer, String str, int length) {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        int writeLength = Math.min(bytes.length, length);
        buffer.put(bytes, 0, writeLength);
        // 填充剩余空间
        for (int i = writeLength; i < length; i++) {
            buffer.put((byte) 0);
        }
    }
    
    /**
     * 对齐到指定边界
     */
    public static long align(long value, int alignment) {
        return (value + alignment - 1) & ~(alignment - 1);
    }
    
    /**
     * 计算填充字节数
     */
    public static int padding(long value, int alignment) {
        long aligned = align(value, alignment);
        return (int) (aligned - value);
    }
}
