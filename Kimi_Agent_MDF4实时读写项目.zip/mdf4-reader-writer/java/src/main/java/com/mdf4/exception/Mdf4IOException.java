package com.mdf4.exception;

/**
 * MDF4 I/O操作异常
 */
public class Mdf4IOException extends Mdf4Exception {
    
    public Mdf4IOException(String message) {
        super(message);
    }
    
    public Mdf4IOException(String message, Throwable cause) {
        super(message, cause);
    }
}
