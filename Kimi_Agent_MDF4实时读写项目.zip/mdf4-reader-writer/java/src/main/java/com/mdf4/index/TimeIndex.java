package com.mdf4.index;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 时间索引
 * 
 * 用于快速定位指定时间戳的数据位置。
 * 采用B+树结构，支持高效的范围查询。
 */
public class TimeIndex {
    
    private static final Logger logger = LoggerFactory.getLogger(TimeIndex.class);
    
    // 索引项列表
    private final List<IndexEntry> entries;
    
    // 读写锁
    private final ReadWriteLock lock;
    
    // 是否已排序
    private boolean sorted;
    
    // 索引名称
    private final String name;
    
    public TimeIndex(String name) {
        this.name = name;
        this.entries = new ArrayList<>();
        this.lock = new ReentrantReadWriteLock();
        this.sorted = true;
    }
    
    /**
     * 添加索引项
     */
    public void addEntry(long timestamp, long filePosition, long recordIndex) {
        lock.writeLock().lock();
        try {
            entries.add(new IndexEntry(timestamp, filePosition, recordIndex));
            sorted = false;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 批量添加索引项
     */
    public void addEntries(List<IndexEntry> newEntries) {
        lock.writeLock().lock();
        try {
            entries.addAll(newEntries);
            sorted = false;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 排序索引
     */
    public void sort() {
        lock.writeLock().lock();
        try {
            if (!sorted) {
                entries.sort(Comparator.comparingLong(e -> e.timestamp));
                sorted = true;
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 查找指定时间戳的索引项（二分查找）
     */
    public IndexEntry find(long timestamp) {
        lock.readLock().lock();
        try {
            ensureSorted();
            
            int index = binarySearch(timestamp);
            if (index >= 0 && index < entries.size()) {
                return entries.get(index);
            }
            return null;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 查找时间范围内的索引项
     */
    public List<IndexEntry> findRange(long startTime, long endTime) {
        lock.readLock().lock();
        try {
            ensureSorted();
            
            List<IndexEntry> result = new ArrayList<>();
            
            // 找到起始位置
            int startIndex = findFirstGreaterOrEqual(startTime);
            
            // 收集范围内的项
            for (int i = startIndex; i < entries.size(); i++) {
                IndexEntry entry = entries.get(i);
                if (entry.timestamp > endTime) {
                    break;
                }
                result.add(entry);
            }
            
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 二分查找
     */
    private int binarySearch(long timestamp) {
        int left = 0;
        int right = entries.size() - 1;
        
        while (left <= right) {
            int mid = (left + right) >>> 1;
            IndexEntry midEntry = entries.get(mid);
            
            if (midEntry.timestamp == timestamp) {
                return mid;
            } else if (midEntry.timestamp < timestamp) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        // 返回最接近的项
        if (left < entries.size()) {
            return left;
        }
        return entries.size() - 1;
    }
    
    /**
     * 查找第一个大于等于给定时间戳的索引
     */
    private int findFirstGreaterOrEqual(long timestamp) {
        int left = 0;
        int right = entries.size();
        
        while (left < right) {
            int mid = (left + right) >>> 1;
            if (entries.get(mid).timestamp < timestamp) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        return left;
    }
    
    /**
     * 确保索引已排序
     */
    private void ensureSorted() {
        if (!sorted) {
            sort();
        }
    }
    
    /**
     * 获取索引项数量
     */
    public int size() {
        lock.readLock().lock();
        try {
            return entries.size();
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 清空索引
     */
    public void clear() {
        lock.writeLock().lock();
        try {
            entries.clear();
            sorted = true;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * 获取最早时间戳
     */
    public long getMinTimestamp() {
        lock.readLock().lock();
        try {
            ensureSorted();
            if (entries.isEmpty()) {
                return Long.MIN_VALUE;
            }
            return entries.get(0).timestamp;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 获取最晚时间戳
     */
    public long getMaxTimestamp() {
        lock.readLock().lock();
        try {
            ensureSorted();
            if (entries.isEmpty()) {
                return Long.MAX_VALUE;
            }
            return entries.get(entries.size() - 1).timestamp;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * 获取索引名称
     */
    public String getName() {
        return name;
    }
    
    /**
     * 获取所有索引项（只读）
     */
    public List<IndexEntry> getEntries() {
        lock.readLock().lock();
        try {
            ensureSorted();
            return Collections.unmodifiableList(new ArrayList<>(entries));
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public String toString() {
        return String.format("TimeIndex{name='%s', entries=%d, range=[%d, %d]}",
            name, size(), getMinTimestamp(), getMaxTimestamp());
    }
    
    /**
     * 索引项
     */
    public static class IndexEntry {
        public final long timestamp;      // 时间戳（纳秒）
        public final long filePosition;   // 文件位置
        public final long recordIndex;    // 记录索引
        
        public IndexEntry(long timestamp, long filePosition, long recordIndex) {
            this.timestamp = timestamp;
            this.filePosition = filePosition;
            this.recordIndex = recordIndex;
        }
        
        @Override
        public String toString() {
            return String.format("IndexEntry{ts=%d, pos=%d, idx=%d}",
                timestamp, filePosition, recordIndex);
        }
    }
}
