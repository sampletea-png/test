package com.mdf4.util;

import java.util.zip.CRC32;

/**
 * CRC32校验计算器
 */
public class CRC32Calculator {
    
    private final CRC32 crc32;
    
    public CRC32Calculator() {
        this.crc32 = new CRC32();
    }
    
    /**
     * 重置计算器
     */
    public void reset() {
        crc32.reset();
    }
    
    /**
     * 更新校验值
     */
    public void update(byte[] data, int offset, int length) {
        crc32.update(data, offset, length);
    }
    
    /**
     * 获取CRC32值
     */
    public long getValue() {
        return crc32.getValue();
    }
    
    /**
     * 计算数据的CRC32值
     */
    public static long calculate(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        return crc.getValue();
    }
    
    /**
     * 计算数据的CRC32值（带偏移和长度）
     */
    public static long calculate(byte[] data, int offset, int length) {
        CRC32 crc = new CRC32();
        crc.update(data, offset, length);
        return crc.getValue();
    }
}
