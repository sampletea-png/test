package com.mdf4.block;

import com.mdf4.util.ByteBufferUtils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * MDF4块基类
 * 
 * MDF4文件中的所有块都遵循以下结构：
 * - 块ID (4 bytes): "##XX" 格式
 * - 保留字段 (4 bytes)
 * - 块长度 (8 bytes): 整个块的字节数
 * - 链接数量 (8 bytes): 链接段中的链接数
 * - 链接段: 可变长度，包含指向其他块的链接
 * - 数据段: 块的实际数据内容
 */
public abstract class Mdf4Block {
    
    // 块头字段
    protected String blockType;      // 块类型ID (4 bytes)
    protected long blockSize;        // 块总大小 (8 bytes)
    protected long linkCount;        // 链接数量 (8 bytes)
    
    // 块在文件中的位置
    protected long filePosition;
    
    // 是否已修改
    protected boolean dirty;
    
    public Mdf4Block(String blockType) {
        this.blockType = blockType;
        this.blockSize = 0;
        this.linkCount = 0;
        this.filePosition = -1;
        this.dirty = false;
    }
    
    /**
     * 获取块类型
     */
    public String getBlockType() {
        return blockType;
    }
    
    /**
     * 获取块大小
     */
    public long getBlockSize() {
        return blockSize;
    }
    
    /**
     * 获取链接数量
     */
    public long getLinkCount() {
        return linkCount;
    }
    
    /**
     * 获取文件位置
     */
    public long getFilePosition() {
        return filePosition;
    }
    
    /**
     * 设置文件位置
     */
    public void setFilePosition(long position) {
        this.filePosition = position;
    }
    
    /**
     * 检查是否已修改
     */
    public boolean isDirty() {
        return dirty;
    }
    
    /**
     * 标记为已修改
     */
    public void markDirty() {
        this.dirty = true;
    }
    
    /**
     * 标记为已保存
     */
    public void markClean() {
        this.dirty = false;
    }
    
    /**
     * 计算块大小（子类实现）
     */
    protected abstract long calculateBlockSize();
    
    /**
     * 序列化块数据到ByteBuffer
     */
    public ByteBuffer serialize() {
        // 计算块大小
        this.blockSize = calculateBlockSize();
        this.linkCount = getLinkCountInternal();
        
        ByteBuffer buffer = ByteBuffer.allocate((int) blockSize);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // 写入块头
        ByteBufferUtils.writeString(buffer, blockType, 4);
        buffer.putInt(0);  // 保留字段
        buffer.putLong(blockSize);
        buffer.putLong(linkCount);
        
        // 写入链接段
        serializeLinks(buffer);
        
        // 写入数据段
        serializeData(buffer);
        
        buffer.flip();
        return buffer;
    }
    
    /**
     * 从ByteBuffer反序列化块数据
     */
    public void deserialize(ByteBuffer buffer) {
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // 读取块头
        this.blockType = ByteBufferUtils.readString(buffer, 4);
        buffer.getInt();  // 跳过保留字段
        this.blockSize = buffer.getLong();
        this.linkCount = buffer.getLong();
        
        // 读取链接段
        deserializeLinks(buffer);
        
        // 读取数据段
        deserializeData(buffer);
        
        this.dirty = false;
    }
    
    /**
     * 获取链接数量（子类实现）
     */
    protected abstract long getLinkCountInternal();
    
    /**
     * 序列化链接段（子类实现）
     */
    protected abstract void serializeLinks(ByteBuffer buffer);
    
    /**
     * 反序列化链接段（子类实现）
     */
    protected abstract void deserializeLinks(ByteBuffer buffer);
    
    /**
     * 序列化数据段（子类实现）
     */
    protected abstract void serializeData(ByteBuffer buffer);
    
    /**
     * 反序列化数据段（子类实现）
     */
    protected abstract void deserializeData(ByteBuffer buffer);
    
    @Override
    public String toString() {
        return String.format("%s{position=%d, size=%d, links=%d}", 
            blockType, filePosition, blockSize, linkCount);
    }
}
