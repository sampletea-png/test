package com.mdf4;

import com.mdf4.channel.Channel;
import com.mdf4.channel.ChannelConfig;
import com.mdf4.core.Mdf4Constants;
import com.mdf4.core.Mdf4File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MDF4 Library Main Class
 * 
 * Demonstrates basic usage of the MDF4 library.
 */
public class Mdf4Main {
    
    private static final Logger logger = LoggerFactory.getLogger(Mdf4Main.class);
    
    public static void main(String[] args) {
        logger.info("MDF4 Reader/Writer Library v1.0.0");
        logger.info("=================================");
        
        if (args.length < 1) {
            printUsage();
            return;
        }
        
        String command = args[0];
        
        switch (command) {
            case "write":
                if (args.length < 2) {
                    System.err.println("Usage: write <output_file>");
                    return;
                }
                writeExample(args[1]);
                break;
                
            case "read":
                if (args.length < 2) {
                    System.err.println("Usage: read <input_file>");
                    return;
                }
                readExample(args[1]);
                break;
                
            case "info":
                if (args.length < 2) {
                    System.err.println("Usage: info <input_file>");
                    return;
                }
                showInfo(args[1]);
                break;
                
            default:
                System.err.println("Unknown command: " + command);
                printUsage();
        }
    }
    
    private static void printUsage() {
        System.out.println("Usage: java -jar mdf4-core.jar <command> [args]");
        System.out.println("");
        System.out.println("Commands:");
        System.out.println("  write <output_file>    Write sample data to file");
        System.out.println("  read <input_file>      Read and display file contents");
        System.out.println("  info <input_file>      Show file information");
    }
    
    /**
     * Write example data to MDF4 file
     */
    private static void writeExample(String filename) {
        logger.info("Writing example data to: {}", filename);
        
        try {
            Mdf4File file = new Mdf4File(filename, Mdf4Constants.OpenMode.WRITE);
            file.open();
            
            // Create channels
            Channel rpmChannel = file.createChannel(
                ChannelConfig.createDouble("EngineSpeed")
                    .setUnit("rpm")
                    .setDescription("Engine speed in revolutions per minute")
            );
            
            Channel throttleChannel = file.createChannel(
                ChannelConfig.createDouble("ThrottlePosition")
                    .setUnit("%")
                    .setDescription("Throttle position percentage")
            );
            
            Channel tempChannel = file.createChannel(
                ChannelConfig.createDouble("CoolantTemperature")
                    .setUnit("°C")
                    .setDescription("Engine coolant temperature")
            );
            
            // Generate sample data
            int numSamples = 1000;
            double[] rpmData = new double[numSamples];
            double[] throttleData = new double[numSamples];
            double[] tempData = new double[numSamples];
            
            for (int i = 0; i < numSamples; i++) {
                double t = i * 0.01;  // 10ms intervals
                rpmData[i] = 3000 + 500 * Math.sin(2 * Math.PI * 10 * t) + Math.random() * 50;
                throttleData[i] = 50 + 30 * Math.sin(2 * Math.PI * 5 * t) + Math.random() * 5;
                tempData[i] = 90 + 10 * Math.sin(2 * Math.PI * 0.1 * t) + Math.random() * 2;
            }
            
            // Write data
            rpmChannel.writeDouble(rpmData);
            throttleChannel.writeDouble(throttleData);
            tempChannel.writeDouble(tempData);
            
            logger.info("Written {} samples to each channel", numSamples);
            logger.info("Channels created: {}", file.getChannelCount());
            
            file.close();
            logger.info("File written successfully: {}", filename);
            
        } catch (Exception e) {
            logger.error("Failed to write file", e);
            System.exit(1);
        }
    }
    
    /**
     * Read and display MDF4 file contents
     */
    private static void readExample(String filename) {
        logger.info("Reading file: {}", filename);
        
        try {
            Mdf4File file = new Mdf4File(filename, Mdf4Constants.OpenMode.READ);
            file.open();
            
            logger.info("File version: {}", file.getVersion());
            logger.info("Number of channels: {}", file.getChannelCount());
            
            for (Channel channel : file.getChannels()) {
                logger.info("Channel: {} (ID: {}, Records: {})",
                    channel.getName(),
                    channel.getChannelId(),
                    channel.getRecordCount()
                );
            }
            
            file.close();
            
        } catch (Exception e) {
            logger.error("Failed to read file", e);
            System.exit(1);
        }
    }
    
    /**
     * Show file information
     */
    private static void showInfo(String filename) {
        logger.info("File information: {}", filename);
        
        try {
            java.io.File f = new java.io.File(filename);
            if (!f.exists()) {
                System.err.println("File not found: " + filename);
                return;
            }
            
            System.out.println("File: " + filename);
            System.out.println("Size: " + f.length() + " bytes (" + 
                String.format("%.2f", f.length() / 1024.0) + " KB)");
            
            Mdf4File file = new Mdf4File(filename, Mdf4Constants.OpenMode.READ);
            file.open();
            
            System.out.println("MDF Version: " + file.getVersion());
            System.out.println("Channels: " + file.getChannelCount());
            
            for (Channel channel : file.getChannels()) {
                System.out.println("  - " + channel.getName() + 
                    " (Records: " + channel.getRecordCount() + ")");
            }
            
            file.close();
            
        } catch (Exception e) {
            logger.error("Failed to get file info", e);
            System.exit(1);
        }
    }
}
