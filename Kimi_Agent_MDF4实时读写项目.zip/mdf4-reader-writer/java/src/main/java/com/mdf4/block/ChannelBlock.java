package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;

import java.nio.ByteBuffer;

/**
 * MDF4 CN块（Channel Block）
 * 
 * CN块定义单个通道的属性和数据类型。
 * 
 * 链接段：
 * - 下一个CN块链接 (8 bytes)
 * - 通道名称TX块链接 (8 bytes)
 * - SI块链接 (8 bytes): 源信息
 * - CC块链接 (8 bytes): 转换规则
 * - CD块链接 (8 bytes): 数据列表
 * - CE块链接 (8 bytes): 通道扩展
 * 
 * 数据段：
 * - 通道类型 (1 byte): 0=数据, 1=时间, 2=其他
 * - 同步类型 (1 byte): 0=无, 1=时间, 2=角度, 3=距离, 4=索引
 * - 数据类型 (1 byte)
 * - 位偏移 (1 byte)
 * - 字节偏移 (4 bytes)
 * - 位计数 (4 bytes)
 * - 标志 (4 bytes)
 * - 无效位位置 (4 bytes)
 * - 精度 (4 bytes): 浮点精度
 * - 保留字段 (4 bytes)
 * - 附件数量 (2 bytes)
 * - 采样间隔 (8 bytes): 采样间隔（纳秒）
 */
public class ChannelBlock extends Mdf4Block {
    
    // 通道类型
    public static final byte CHANNEL_TYPE_DATA = 0;
    public static final byte CHANNEL_TYPE_TIME = 1;
    public static final byte CHANNEL_TYPE_OTHER = 2;
    
    // 同步类型
    public static final byte SYNC_TYPE_NONE = 0;
    public static final byte SYNC_TYPE_TIME = 1;
    public static final byte SYNC_TYPE_ANGLE = 2;
    public static final byte SYNC_TYPE_DISTANCE = 3;
    public static final byte SYNC_TYPE_INDEX = 4;
    
    // 链接索引
    private static final int LINK_NEXT_CN = 0;
    private static final int LINK_TX_NAME = 1;
    private static final int LINK_SI = 2;
    private static final int LINK_CC = 3;
    private static final int LINK_CD = 4;
    private static final int LINK_CE = 5;
    
    // 链接
    private long nextCnLink;       // 下一个CN块
    private long txNameLink;       // 名称TX块
    private long siLink;           // 源信息块
    private long ccLink;           // 转换规则块
    private long cdLink;           // 数据列表块
    private long ceLink;           // 通道扩展块
    
    // 数据段字段
    private byte channelType;      // 通道类型
    private byte syncType;         // 同步类型
    private byte dataType;         // 数据类型
    private byte bitOffset;        // 位偏移
    private int byteOffset;        // 字节偏移
    private int bitCount;          // 位计数
    private int flags;             // 标志
    private int invalidBitPos;     // 无效位位置
    private int precision;         // 精度
    private short attachmentCount; // 附件数量
    private long samplingInterval; // 采样间隔（纳秒）
    
    public ChannelBlock() {
        super(Mdf4Constants.CN_BLOCK_TYPE);
        this.nextCnLink = 0;
        this.txNameLink = 0;
        this.siLink = 0;
        this.ccLink = 0;
        this.cdLink = 0;
        this.ceLink = 0;
        this.channelType = CHANNEL_TYPE_DATA;
        this.syncType = SYNC_TYPE_NONE;
        this.dataType = Mdf4Constants.DT_FLOAT;
        this.bitOffset = 0;
        this.byteOffset = 0;
        this.bitCount = 64;
        this.flags = 0;
        this.invalidBitPos = 0;
        this.precision = 0;
        this.attachmentCount = 0;
        this.samplingInterval = 0;
    }
    
    public long getNextCnLink() {
        return nextCnLink;
    }
    
    public void setNextCnLink(long link) {
        this.nextCnLink = link;
        markDirty();
    }
    
    public long getTxNameLink() {
        return txNameLink;
    }
    
    public void setTxNameLink(long link) {
        this.txNameLink = link;
        markDirty();
    }
    
    public long getSiLink() {
        return siLink;
    }
    
    public void setSiLink(long link) {
        this.siLink = link;
        markDirty();
    }
    
    public long getCcLink() {
        return ccLink;
    }
    
    public void setCcLink(long link) {
        this.ccLink = link;
        markDirty();
    }
    
    public long getCdLink() {
        return cdLink;
    }
    
    public void setCdLink(long link) {
        this.cdLink = link;
        markDirty();
    }
    
    public long getCeLink() {
        return ceLink;
    }
    
    public void setCeLink(long link) {
        this.ceLink = link;
        markDirty();
    }
    
    public byte getChannelType() {
        return channelType;
    }
    
    public void setChannelType(byte type) {
        this.channelType = type;
        markDirty();
    }
    
    public byte getSyncType() {
        return syncType;
    }
    
    public void setSyncType(byte type) {
        this.syncType = type;
        markDirty();
    }
    
    public byte getDataType() {
        return dataType;
    }
    
    public void setDataType(byte type) {
        this.dataType = type;
        markDirty();
    }
    
    public byte getBitOffset() {
        return bitOffset;
    }
    
    public void setBitOffset(byte offset) {
        this.bitOffset = offset;
        markDirty();
    }
    
    public int getByteOffset() {
        return byteOffset;
    }
    
    public void setByteOffset(int offset) {
        this.byteOffset = offset;
        markDirty();
    }
    
    public int getBitCount() {
        return bitCount;
    }
    
    public void setBitCount(int count) {
        this.bitCount = count;
        markDirty();
    }
    
    public int getFlags() {
        return flags;
    }
    
    public void setFlags(int flags) {
        this.flags = flags;
        markDirty();
    }
    
    public int getInvalidBitPos() {
        return invalidBitPos;
    }
    
    public void setInvalidBitPos(int pos) {
        this.invalidBitPos = pos;
        markDirty();
    }
    
    public int getPrecision() {
        return precision;
    }
    
    public void setPrecision(int precision) {
        this.precision = precision;
        markDirty();
    }
    
    public short getAttachmentCount() {
        return attachmentCount;
    }
    
    public void setAttachmentCount(short count) {
        this.attachmentCount = count;
        markDirty();
    }
    
    public long getSamplingInterval() {
        return samplingInterval;
    }
    
    public void setSamplingInterval(long interval) {
        this.samplingInterval = interval;
        markDirty();
    }
    
    /**
     * 获取数据类型对应的字节大小
     */
    public int getDataTypeSize() {
        switch (dataType) {
            case Mdf4Constants.DT_UNSIGNED_INT:
            case Mdf4Constants.DT_SIGNED_INT:
                return (bitCount + 7) / 8;
            case Mdf4Constants.DT_FLOAT:
                return bitCount / 8;
            case Mdf4Constants.DT_STRING:
                return bitCount / 8;
            default:
                return bitCount / 8;
        }
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 链接(6*8=48) + 数据(1+1+1+1+4+4+4+4+4+4+2+8=38) = 110, 对齐到112
        return 112;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 6;
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        buffer.putLong(nextCnLink);
        buffer.putLong(txNameLink);
        buffer.putLong(siLink);
        buffer.putLong(ccLink);
        buffer.putLong(cdLink);
        buffer.putLong(ceLink);
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        this.nextCnLink = buffer.getLong();
        this.txNameLink = buffer.getLong();
        this.siLink = buffer.getLong();
        this.ccLink = buffer.getLong();
        this.cdLink = buffer.getLong();
        this.ceLink = buffer.getLong();
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        buffer.put(channelType);
        buffer.put(syncType);
        buffer.put(dataType);
        buffer.put(bitOffset);
        buffer.putInt(byteOffset);
        buffer.putInt(bitCount);
        buffer.putInt(flags);
        buffer.putInt(invalidBitPos);
        buffer.putInt(precision);
        buffer.putInt(0);  // reserved
        buffer.putShort(attachmentCount);
        buffer.putLong(samplingInterval);
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        this.channelType = buffer.get();
        this.syncType = buffer.get();
        this.dataType = buffer.get();
        this.bitOffset = buffer.get();
        this.byteOffset = buffer.getInt();
        this.bitCount = buffer.getInt();
        this.flags = buffer.getInt();
        this.invalidBitPos = buffer.getInt();
        this.precision = buffer.getInt();
        buffer.getInt();  // skip reserved
        this.attachmentCount = buffer.getShort();
        this.samplingInterval = buffer.getLong();
    }
    
    @Override
    public String toString() {
        return String.format("ChannelBlock{type=%d, syncType=%d, dataType=%d, bitCount=%d}",
            channelType, syncType, dataType, bitCount);
    }
}
