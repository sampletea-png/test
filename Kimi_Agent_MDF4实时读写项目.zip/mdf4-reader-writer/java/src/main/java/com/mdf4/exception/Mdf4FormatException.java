package com.mdf4.exception;

/**
 * MDF4格式错误异常
 */
public class Mdf4FormatException extends Mdf4Exception {
    
    public Mdf4FormatException(String message) {
        super(message);
    }
    
    public Mdf4FormatException(String message, Throwable cause) {
        super(message, cause);
    }
}
