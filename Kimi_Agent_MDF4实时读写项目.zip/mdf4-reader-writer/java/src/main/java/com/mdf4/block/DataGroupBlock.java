package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;

import java.nio.ByteBuffer;

/**
 * MDF4 DG块（Data Group Block）
 * 
 * DG块组织一组相关的通道数据，包含指向通道组和下一个DG块的链接。
 * 
 * 链接段：
 * - 下一个DG块链接 (8 bytes)
 * - 第一个CG块链接 (8 bytes)
 * - 数据块链接 (8 bytes): 指向DT块或DL块
 * - MD块链接 (8 bytes): 指向注释
 * 
 * 数据段：
 * - 记录ID大小 (1 byte)
 * - 保留字段 (7 bytes)
 */
public class DataGroupBlock extends Mdf4Block {
    
    // 链接索引
    private static final int LINK_NEXT_DG = 0;
    private static final int LINK_FIRST_CG = 1;
    private static final int LINK_DATA = 2;
    private static final int LINK_MD = 3;
    
    // 链接
    private long nextDgLink;     // 下一个DG块
    private long firstCgLink;    // 第一个CG块
    private long dataLink;       // 数据块（DT或DL）
    private long mdLink;         // 注释块
    
    // 数据段字段
    private byte recordIdSize;   // 记录ID大小
    
    public DataGroupBlock() {
        super(Mdf4Constants.DG_BLOCK_TYPE);
        this.nextDgLink = 0;
        this.firstCgLink = 0;
        this.dataLink = 0;
        this.mdLink = 0;
        this.recordIdSize = 0;
    }
    
    public long getNextDgLink() {
        return nextDgLink;
    }
    
    public void setNextDgLink(long link) {
        this.nextDgLink = link;
        markDirty();
    }
    
    public long getFirstCgLink() {
        return firstCgLink;
    }
    
    public void setFirstCgLink(long link) {
        this.firstCgLink = link;
        markDirty();
    }
    
    public long getDataLink() {
        return dataLink;
    }
    
    public void setDataLink(long link) {
        this.dataLink = link;
        markDirty();
    }
    
    public long getMdLink() {
        return mdLink;
    }
    
    public void setMdLink(long link) {
        this.mdLink = link;
        markDirty();
    }
    
    public byte getRecordIdSize() {
        return recordIdSize;
    }
    
    public void setRecordIdSize(byte size) {
        this.recordIdSize = size;
        markDirty();
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 链接(4*8=32) + 数据(1+7=8) = 64
        return 64;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 4;
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        buffer.putLong(nextDgLink);
        buffer.putLong(firstCgLink);
        buffer.putLong(dataLink);
        buffer.putLong(mdLink);
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        this.nextDgLink = buffer.getLong();
        this.firstCgLink = buffer.getLong();
        this.dataLink = buffer.getLong();
        this.mdLink = buffer.getLong();
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        buffer.put(recordIdSize);
        // 填充7字节保留字段
        for (int i = 0; i < 7; i++) {
            buffer.put((byte) 0);
        }
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        this.recordIdSize = buffer.get();
        // 跳过7字节保留字段
        buffer.position(buffer.position() + 7);
    }
    
    @Override
    public String toString() {
        return String.format("DataGroupBlock{nextDg=%d, firstCg=%d, data=%d}",
            nextDgLink, firstCgLink, dataLink);
    }
}
