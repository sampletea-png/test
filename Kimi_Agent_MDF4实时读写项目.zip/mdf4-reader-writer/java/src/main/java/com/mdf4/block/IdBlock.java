package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;
import com.mdf4.util.ByteBufferUtils;

import java.nio.ByteBuffer;

/**
 * MDF4 ID块（Identification Block）
 * 
 * ID块位于文件开头，包含文件格式标识和版本信息。
 * 
 * 结构：
 * - 文件标识 (8 bytes): "MDF     "
 * - 格式标识 (8 bytes): "4.00    " 或 "4.10    " 等
 * - 程序标识 (8 bytes): 创建程序名称
 * - 默认字节序 (2 bytes): 0 = 小端序
 * - 浮点格式 (2 bytes): 0 = IEEE 754
 * - 版本号 (2 bytes): 400, 410, 420 等
 * - 保留字段 (2 bytes)
 * - 标准版本 (2 bytes)
 * - 保留字段 (2 bytes)
 */
public class IdBlock extends Mdf4Block {
    
    // ID块固定大小
    public static final int ID_BLOCK_SIZE = 64;
    
    // 字段
    private String fileId;           // 文件标识 "MDF"
    private String formatId;         // 格式标识 "4.00"
    private String programId;        // 程序标识
    private short defaultByteOrder;  // 默认字节序 (0=小端)
    private short floatFormat;       // 浮点格式 (0=IEEE754)
    private short version;           // 版本号
    private short standardVersion;   // 标准版本
    
    public IdBlock() {
        super(Mdf4Constants.ID_BLOCK_TYPE);
        this.fileId = "MDF";
        this.formatId = "4.00";
        this.programId = "MDF4J";
        this.defaultByteOrder = 0;
        this.floatFormat = 0;
        this.version = Mdf4Constants.MDF_VERSION;
        this.standardVersion = 0;
    }
    
    public IdBlock(short version) {
        super(Mdf4Constants.ID_BLOCK_TYPE);
        this.fileId = "MDF";
        this.formatId = String.format("%d.%02d", version / 100, version % 100);
        this.programId = "MDF4J";
        this.defaultByteOrder = 0;
        this.floatFormat = 0;
        this.version = version;
        this.standardVersion = 0;
    }
    
    public String getFileId() {
        return fileId;
    }
    
    public String getFormatId() {
        return formatId;
    }
    
    public String getProgramId() {
        return programId;
    }
    
    public void setProgramId(String programId) {
        this.programId = programId;
        markDirty();
    }
    
    public short getDefaultByteOrder() {
        return defaultByteOrder;
    }
    
    public short getFloatFormat() {
        return floatFormat;
    }
    
    public short getVersion() {
        return version;
    }
    
    public short getStandardVersion() {
        return standardVersion;
    }
    
    @Override
    protected long calculateBlockSize() {
        return ID_BLOCK_SIZE;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 0;  // ID块没有链接
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        // ID块没有链接段
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        // ID块没有链接段
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        // 写入ID块特定数据
        ByteBufferUtils.writeNullTerminatedString(buffer, fileId, 8);
        ByteBufferUtils.writeNullTerminatedString(buffer, formatId, 8);
        ByteBufferUtils.writeNullTerminatedString(buffer, programId, 8);
        buffer.putShort(defaultByteOrder);
        buffer.putShort(floatFormat);
        buffer.putShort(version);
        buffer.putShort((short) 0);  // 保留
        buffer.putShort(standardVersion);
        buffer.putShort((short) 0);  // 保留
        
        // 填充到64字节
        int remaining = ID_BLOCK_SIZE - buffer.position();
        for (int i = 0; i < remaining; i++) {
            buffer.put((byte) 0);
        }
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        this.fileId = ByteBufferUtils.readNullTerminatedString(buffer, 8);
        this.formatId = ByteBufferUtils.readNullTerminatedString(buffer, 8);
        this.programId = ByteBufferUtils.readNullTerminatedString(buffer, 8);
        this.defaultByteOrder = buffer.getShort();
        this.floatFormat = buffer.getShort();
        this.version = buffer.getShort();
        buffer.getShort();  // 跳过保留字段
        this.standardVersion = buffer.getShort();
        // 跳过剩余字节
    }
    
    /**
     * 验证ID块是否有效
     */
    public boolean isValid() {
        return "MDF".equals(fileId) && version >= 400;
    }
    
    @Override
    public String toString() {
        return String.format("IDBlock{fileId='%s', formatId='%s', version=%d, programId='%s'}",
            fileId, formatId, version, programId);
    }
}
