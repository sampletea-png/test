package com.mdf4.channel;

import com.mdf4.block.ChannelBlock;
import com.mdf4.core.Mdf4Constants;

/**
 * 通道配置类
 * 
 * 用于创建通道时指定通道的各项属性。
 */
public class ChannelConfig {
    
    // 通道名称
    private String name;
    
    // 通道描述
    private String description;
    
    // 单位
    private String unit;
    
    // 数据类型
    private byte dataType;
    
    // 位计数
    private int bitCount;
    
    // 精度（小数位数）
    private int precision;
    
    // 最小值
    private double minValue;
    
    // 最大值
    private double maxValue;
    
    // 采样间隔（纳秒）
    private long samplingInterval;
    
    // 是否为时间通道
    private boolean timeChannel;
    
    public ChannelConfig() {
        this.name = "";
        this.description = "";
        this.unit = "";
        this.dataType = Mdf4Constants.DT_FLOAT;
        this.bitCount = 64;
        this.precision = 6;
        this.minValue = Double.NaN;
        this.maxValue = Double.NaN;
        this.samplingInterval = 0;
        this.timeChannel = false;
    }
    
    public ChannelConfig(String name) {
        this();
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public ChannelConfig setName(String name) {
        this.name = name;
        return this;
    }
    
    public String getDescription() {
        return description;
    }
    
    public ChannelConfig setDescription(String description) {
        this.description = description;
        return this;
    }
    
    public String getUnit() {
        return unit;
    }
    
    public ChannelConfig setUnit(String unit) {
        this.unit = unit;
        return this;
    }
    
    public byte getDataType() {
        return dataType;
    }
    
    public ChannelConfig setDataType(byte dataType) {
        this.dataType = dataType;
        return this;
    }
    
    public int getBitCount() {
        return bitCount;
    }
    
    public ChannelConfig setBitCount(int bitCount) {
        this.bitCount = bitCount;
        return this;
    }
    
    public int getPrecision() {
        return precision;
    }
    
    public ChannelConfig setPrecision(int precision) {
        this.precision = precision;
        return this;
    }
    
    public double getMinValue() {
        return minValue;
    }
    
    public ChannelConfig setMinValue(double minValue) {
        this.minValue = minValue;
        return this;
    }
    
    public double getMaxValue() {
        return maxValue;
    }
    
    public ChannelConfig setMaxValue(double maxValue) {
        this.maxValue = maxValue;
        return this;
    }
    
    public long getSamplingInterval() {
        return samplingInterval;
    }
    
    public ChannelConfig setSamplingInterval(long samplingInterval) {
        this.samplingInterval = samplingInterval;
        return this;
    }
    
    public boolean isTimeChannel() {
        return timeChannel;
    }
    
    public ChannelConfig setTimeChannel(boolean timeChannel) {
        this.timeChannel = timeChannel;
        return this;
    }
    
    /**
     * 获取数据类型对应的字节大小
     */
    public int getDataTypeSize() {
        switch (dataType) {
            case Mdf4Constants.DT_UNSIGNED_INT:
            case Mdf4Constants.DT_SIGNED_INT:
                return (bitCount + 7) / 8;
            case Mdf4Constants.DT_FLOAT:
                return bitCount / 8;
            case Mdf4Constants.DT_STRING:
                return bitCount / 8;
            default:
                return bitCount / 8;
        }
    }
    
    /**
     * 创建预配置的DOUBLE类型通道
     */
    public static ChannelConfig createDouble(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_FLOAT)
            .setBitCount(64);
    }
    
    /**
     * 创建预配置的FLOAT类型通道
     */
    public static ChannelConfig createFloat(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_FLOAT)
            .setBitCount(32);
    }
    
    /**
     * 创建预配置的INT32类型通道
     */
    public static ChannelConfig createInt32(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_SIGNED_INT)
            .setBitCount(32);
    }
    
    /**
     * 创建预配置的UINT32类型通道
     */
    public static ChannelConfig createUInt32(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_UNSIGNED_INT)
            .setBitCount(32);
    }
    
    /**
     * 创建预配置的INT64类型通道
     */
    public static ChannelConfig createInt64(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_SIGNED_INT)
            .setBitCount(64);
    }
    
    /**
     * 创建时间通道
     */
    public static ChannelConfig createTimeChannel(String name) {
        return new ChannelConfig(name)
            .setDataType(Mdf4Constants.DT_UNSIGNED_INT)
            .setBitCount(64)
            .setTimeChannel(true)
            .setUnit("ns");
    }
    
    @Override
    public String toString() {
        return String.format("ChannelConfig{name='%s', type=%d, bits=%d, unit='%s'}",
            name, dataType, bitCount, unit);
    }
}
