package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;

import java.nio.ByteBuffer;

/**
 * MDF4 CG块（Channel Group Block）
 * 
 * CG块包含同采样率的通道集合，定义了记录大小和记录数量。
 * 
 * 链接段：
 * - 下一个CG块链接 (8 bytes)
 * - 第一个CN块链接 (8 bytes)
 * - TX块链接 (8 bytes): 通道组名称
 * - SI块链接 (8 bytes): 源信息
 * - MD块链接 (8 bytes): 注释
 * 
 * 数据段：
 * - 记录ID (8 bytes)
 * - 循环计数 (8 bytes): 记录数量
 * - 数据大小 (8 bytes): 每个记录的字节数
 * - 无效字节数 (4 bytes)
 * - 标志 (2 bytes)
 * - 路径分隔符 (2 bytes)
 * - 保留字段 (4 bytes)
 */
public class ChannelGroupBlock extends Mdf4Block {
    
    // 链接索引
    private static final int LINK_NEXT_CG = 0;
    private static final int LINK_FIRST_CN = 1;
    private static final int LINK_TX_NAME = 2;
    private static final int LINK_SI = 3;
    private static final int LINK_MD = 4;
    
    // 链接
    private long nextCgLink;     // 下一个CG块
    private long firstCnLink;    // 第一个CN块
    private long txNameLink;     // 名称TX块
    private long siLink;         // 源信息块
    private long mdLink;         // 注释块
    
    // 数据段字段
    private long recordId;       // 记录ID
    private long cycleCount;     // 循环计数（记录数）
    private long dataSize;       // 数据大小（每记录字节数）
    private int invalidBytes;    // 无效字节数
    private short flags;         // 标志
    private short pathSeparator; // 路径分隔符
    
    public ChannelGroupBlock() {
        super(Mdf4Constants.CG_BLOCK_TYPE);
        this.nextCgLink = 0;
        this.firstCnLink = 0;
        this.txNameLink = 0;
        this.siLink = 0;
        this.mdLink = 0;
        this.recordId = 0;
        this.cycleCount = 0;
        this.dataSize = 0;
        this.invalidBytes = 0;
        this.flags = 0;
        this.pathSeparator = (short) '.';
    }
    
    public long getNextCgLink() {
        return nextCgLink;
    }
    
    public void setNextCgLink(long link) {
        this.nextCgLink = link;
        markDirty();
    }
    
    public long getFirstCnLink() {
        return firstCnLink;
    }
    
    public void setFirstCnLink(long link) {
        this.firstCnLink = link;
        markDirty();
    }
    
    public long getTxNameLink() {
        return txNameLink;
    }
    
    public void setTxNameLink(long link) {
        this.txNameLink = link;
        markDirty();
    }
    
    public long getSiLink() {
        return siLink;
    }
    
    public void setSiLink(long link) {
        this.siLink = link;
        markDirty();
    }
    
    public long getMdLink() {
        return mdLink;
    }
    
    public void setMdLink(long link) {
        this.mdLink = link;
        markDirty();
    }
    
    public long getRecordId() {
        return recordId;
    }
    
    public void setRecordId(long recordId) {
        this.recordId = recordId;
        markDirty();
    }
    
    public long getCycleCount() {
        return cycleCount;
    }
    
    public void setCycleCount(long count) {
        this.cycleCount = count;
        markDirty();
    }
    
    public long getDataSize() {
        return dataSize;
    }
    
    public void setDataSize(long size) {
        this.dataSize = size;
        markDirty();
    }
    
    public int getInvalidBytes() {
        return invalidBytes;
    }
    
    public void setInvalidBytes(int bytes) {
        this.invalidBytes = bytes;
        markDirty();
    }
    
    public short getFlags() {
        return flags;
    }
    
    public void setFlags(short flags) {
        this.flags = flags;
        markDirty();
    }
    
    public short getPathSeparator() {
        return pathSeparator;
    }
    
    public void setPathSeparator(short separator) {
        this.pathSeparator = separator;
        markDirty();
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 链接(5*8=40) + 数据(8+8+8+4+2+2+4=36) = 100, 对齐到104
        return 104;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 5;
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        buffer.putLong(nextCgLink);
        buffer.putLong(firstCnLink);
        buffer.putLong(txNameLink);
        buffer.putLong(siLink);
        buffer.putLong(mdLink);
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        this.nextCgLink = buffer.getLong();
        this.firstCnLink = buffer.getLong();
        this.txNameLink = buffer.getLong();
        this.siLink = buffer.getLong();
        this.mdLink = buffer.getLong();
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        buffer.putLong(recordId);
        buffer.putLong(cycleCount);
        buffer.putLong(dataSize);
        buffer.putInt(invalidBytes);
        buffer.putShort(flags);
        buffer.putShort(pathSeparator);
        // 填充4字节保留字段
        buffer.putInt(0);
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        this.recordId = buffer.getLong();
        this.cycleCount = buffer.getLong();
        this.dataSize = buffer.getLong();
        this.invalidBytes = buffer.getInt();
        this.flags = buffer.getShort();
        this.pathSeparator = buffer.getShort();
        buffer.getInt();  // skip reserved
    }
    
    @Override
    public String toString() {
        return String.format("ChannelGroupBlock{recordId=%d, cycleCount=%d, dataSize=%d}",
            recordId, cycleCount, dataSize);
    }
}
