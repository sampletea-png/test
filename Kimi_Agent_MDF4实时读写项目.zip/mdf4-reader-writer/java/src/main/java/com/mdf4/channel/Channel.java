package com.mdf4.channel;

import com.mdf4.block.ChannelBlock;
import com.mdf4.block.TextBlock;
import com.mdf4.core.Mdf4Constants;
import com.mdf4.exception.Mdf4Exception;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * 通道类
 * 
 * 封装了对单个通道的读写操作。
 */
public class Channel {
    
    // 通道ID
    private final long channelId;
    
    // 通道配置
    private final ChannelConfig config;
    
    // 通道块
    private final ChannelBlock channelBlock;
    
    // 名称文本块
    private TextBlock nameBlock;
    
    // 数据缓冲区
    private ByteBuffer writeBuffer;
    
    // 数据写入位置
    private long dataPosition;
    
    // 记录计数
    private long recordCount;
    
    // 父通道组的数据大小
    private int recordSize;
    
    // 通道在记录中的偏移
    private int channelOffset;
    
    public Channel(long channelId, ChannelConfig config, ChannelBlock channelBlock) {
        this.channelId = channelId;
        this.config = config;
        this.channelBlock = channelBlock;
        this.nameBlock = null;
        this.writeBuffer = null;
        this.dataPosition = 0;
        this.recordCount = 0;
        this.recordSize = 0;
        this.channelOffset = 0;
    }
    
    public long getChannelId() {
        return channelId;
    }
    
    public String getName() {
        return config.getName();
    }
    
    public ChannelConfig getConfig() {
        return config;
    }
    
    public ChannelBlock getChannelBlock() {
        return channelBlock;
    }
    
    public TextBlock getNameBlock() {
        return nameBlock;
    }
    
    public void setNameBlock(TextBlock nameBlock) {
        this.nameBlock = nameBlock;
    }
    
    public long getRecordCount() {
        return recordCount;
    }
    
    public void setRecordCount(long count) {
        this.recordCount = count;
    }
    
    public int getRecordSize() {
        return recordSize;
    }
    
    public void setRecordSize(int size) {
        this.recordSize = size;
    }
    
    public int getChannelOffset() {
        return channelOffset;
    }
    
    public void setChannelOffset(int offset) {
        this.channelOffset = offset;
    }
    
    /**
     * 初始化写缓冲区
     */
    public void initWriteBuffer(int capacity) {
        this.writeBuffer = ByteBuffer.allocate(capacity);
        this.writeBuffer.order(ByteOrder.LITTLE_ENDIAN);
    }
    
    /**
     * 获取写缓冲区
     */
    public ByteBuffer getWriteBuffer() {
        return writeBuffer;
    }
    
    /**
     * 写入double数组数据
     */
    public void writeDouble(double[] values) throws Mdf4Exception {
        if (writeBuffer == null) {
            throw new Mdf4Exception("Write buffer not initialized");
        }
        
        int dataSize = config.getDataTypeSize();
        int requiredSize = values.length * dataSize;
        
        if (writeBuffer.remaining() < requiredSize) {
            throw new Mdf4Exception("Write buffer overflow");
        }
        
        for (double value : values) {
            switch (config.getBitCount()) {
                case 32:
                    writeBuffer.putFloat((float) value);
                    break;
                case 64:
                    writeBuffer.putDouble(value);
                    break;
                default:
                    throw new Mdf4Exception("Unsupported bit count: " + config.getBitCount());
            }
        }
        
        recordCount += values.length;
    }
    
    /**
     * 写入float数组数据
     */
    public void writeFloat(float[] values) throws Mdf4Exception {
        if (writeBuffer == null) {
            throw new Mdf4Exception("Write buffer not initialized");
        }
        
        int dataSize = config.getDataTypeSize();
        int requiredSize = values.length * dataSize;
        
        if (writeBuffer.remaining() < requiredSize) {
            throw new Mdf4Exception("Write buffer overflow");
        }
        
        for (float value : values) {
            writeBuffer.putFloat(value);
        }
        
        recordCount += values.length;
    }
    
    /**
     * 写入int数组数据
     */
    public void writeInt(int[] values) throws Mdf4Exception {
        if (writeBuffer == null) {
            throw new Mdf4Exception("Write buffer not initialized");
        }
        
        int dataSize = config.getDataTypeSize();
        int requiredSize = values.length * dataSize;
        
        if (writeBuffer.remaining() < requiredSize) {
            throw new Mdf4Exception("Write buffer overflow");
        }
        
        for (int value : values) {
            switch (config.getBitCount()) {
                case 8:
                    writeBuffer.put((byte) value);
                    break;
                case 16:
                    writeBuffer.putShort((short) value);
                    break;
                case 32:
                    writeBuffer.putInt(value);
                    break;
                case 64:
                    writeBuffer.putLong(value);
                    break;
                default:
                    throw new Mdf4Exception("Unsupported bit count: " + config.getBitCount());
            }
        }
        
        recordCount += values.length;
    }
    
    /**
     * 写入long数组数据（用于时间戳）
     */
    public void writeLong(long[] values) throws Mdf4Exception {
        if (writeBuffer == null) {
            throw new Mdf4Exception("Write buffer not initialized");
        }
        
        int dataSize = config.getDataTypeSize();
        int requiredSize = values.length * dataSize;
        
        if (writeBuffer.remaining() < requiredSize) {
            throw new Mdf4Exception("Write buffer overflow");
        }
        
        for (long value : values) {
            writeBuffer.putLong(value);
        }
        
        recordCount += values.length;
    }
    
    /**
     * 从字节缓冲区读取数据
     */
    public double[] readDouble(ByteBuffer buffer, int count) throws Mdf4Exception {
        double[] values = new double[count];
        
        for (int i = 0; i < count; i++) {
            // 定位到当前记录在缓冲区中的位置
            int recordPos = i * recordSize + channelOffset;
            buffer.position(recordPos);
            
            switch (config.getBitCount()) {
                case 32:
                    values[i] = buffer.getFloat();
                    break;
                case 64:
                    values[i] = buffer.getDouble();
                    break;
                default:
                    throw new Mdf4Exception("Unsupported bit count: " + config.getBitCount());
            }
        }
        
        return values;
    }
    
    /**
     * 读取float数据
     */
    public float[] readFloat(ByteBuffer buffer, int count) throws Mdf4Exception {
        float[] values = new float[count];
        
        for (int i = 0; i < count; i++) {
            int recordPos = i * recordSize + channelOffset;
            buffer.position(recordPos);
            values[i] = buffer.getFloat();
        }
        
        return values;
    }
    
    /**
     * 读取int数据
     */
    public int[] readInt(ByteBuffer buffer, int count) throws Mdf4Exception {
        int[] values = new int[count];
        
        for (int i = 0; i < count; i++) {
            int recordPos = i * recordSize + channelOffset;
            buffer.position(recordPos);
            
            switch (config.getBitCount()) {
                case 8:
                    values[i] = buffer.get();
                    break;
                case 16:
                    values[i] = buffer.getShort();
                    break;
                case 32:
                    values[i] = buffer.getInt();
                    break;
                case 64:
                    values[i] = (int) buffer.getLong();
                    break;
                default:
                    throw new Mdf4Exception("Unsupported bit count: " + config.getBitCount());
            }
        }
        
        return values;
    }
    
    /**
     * 读取long数据（时间戳）
     */
    public long[] readLong(ByteBuffer buffer, int count) throws Mdf4Exception {
        long[] values = new long[count];
        
        for (int i = 0; i < count; i++) {
            int recordPos = i * recordSize + channelOffset;
            buffer.position(recordPos);
            values[i] = buffer.getLong();
        }
        
        return values;
    }
    
    /**
     * 清空写缓冲区
     */
    public void clearWriteBuffer() {
        if (writeBuffer != null) {
            writeBuffer.clear();
        }
    }
    
    /**
     * 获取写缓冲区中的数据
     */
    public byte[] getWriteBufferData() {
        if (writeBuffer == null) {
            return new byte[0];
        }
        
        writeBuffer.flip();
        byte[] data = new byte[writeBuffer.remaining()];
        writeBuffer.get(data);
        return data;
    }
    
    @Override
    public String toString() {
        return String.format("Channel{id=%d, name='%s', records=%d}",
            channelId, config.getName(), recordCount);
    }
}
