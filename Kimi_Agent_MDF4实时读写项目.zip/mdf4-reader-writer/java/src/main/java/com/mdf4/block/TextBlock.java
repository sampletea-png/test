package com.mdf4.block;

import com.mdf4.core.Mdf4Constants;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * MDF4 TX块（Text Block）
 * 
 * TX块存储UTF-8编码的文本数据，用于存储通道名称、单位、注释等。
 * 
 * 结构：
 * - 块头 (24 bytes)
 * - 文本数据 (可变长度，UTF-8编码)
 */
public class TextBlock extends Mdf4Block {
    
    // 文本内容
    private String text;
    
    public TextBlock() {
        super(Mdf4Constants.TX_BLOCK_TYPE);
        this.text = "";
    }
    
    public TextBlock(String text) {
        super(Mdf4Constants.TX_BLOCK_TYPE);
        this.text = text != null ? text : "";
    }
    
    public String getText() {
        return text;
    }
    
    public void setText(String text) {
        this.text = text != null ? text : "";
        markDirty();
    }
    
    @Override
    protected long calculateBlockSize() {
        // 头(24) + 文本字节数 + 1(结尾\0)，对齐到8字节边界
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        long size = 24 + bytes.length + 1;
        return (size + 7) & ~7;
    }
    
    @Override
    protected long getLinkCountInternal() {
        return 0;  // TX块没有链接
    }
    
    @Override
    protected void serializeLinks(ByteBuffer buffer) {
        // TX块没有链接段
    }
    
    @Override
    protected void deserializeLinks(ByteBuffer buffer) {
        // TX块没有链接段
    }
    
    @Override
    protected void serializeData(ByteBuffer buffer) {
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        buffer.put(bytes);
        buffer.put((byte) 0);  // 结尾\0
        // 填充对齐
        int padding = (int) (calculateBlockSize() - 24 - bytes.length - 1);
        for (int i = 0; i < padding; i++) {
            buffer.put((byte) 0);
        }
    }
    
    @Override
    protected void deserializeData(ByteBuffer buffer) {
        int textLength = (int) (blockSize - 24);
        byte[] bytes = new byte[textLength];
        buffer.get(bytes);
        
        // 找到结尾的\0
        int actualLength = 0;
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] == 0) {
                actualLength = i;
                break;
            }
        }
        this.text = new String(bytes, 0, actualLength, StandardCharsets.UTF_8);
    }
    
    @Override
    public String toString() {
        String displayText = text.length() > 50 ? text.substring(0, 50) + "..." : text;
        return String.format("TextBlock{text='%s'}", displayText);
    }
}
