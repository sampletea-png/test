# MDF4 Real-time Reader/Writer

高性能MDF4文件实时读写库，支持GB级大数据量处理。

## 特性

- **实时性**: 毫秒级数据写入延迟
- **大容量**: 支持GB级甚至TB级数据文件
- **高性能**: 写入吞吐量≥500MB/s，读取吞吐量≥800MB/s
- **跨平台**: 支持Windows、Linux等主流操作系统
- **多语言**: Java核心库 + Python绑定

## 项目结构

```
mdf4-reader-writer/
├── java/                    # Java核心库
│   ├── src/main/java/com/mdf4/
│   │   ├── block/          # MDF4块定义
│   │   ├── cache/          # 缓存管理
│   │   ├── channel/        # 通道管理
│   │   ├── core/           # 核心类
│   │   ├── exception/      # 异常类
│   │   └── util/           # 工具类
│   └── pom.xml
├── python/                  # Python绑定
│   └── mdf4/
│       ├── src/mdf4/       # Python模块
│       ├── tests/          # 测试用例
│       └── examples/       # 示例代码
└── docs/                    # 文档
```

## 快速开始

### Java使用

```java
import com.mdf4.core.Mdf4File;
import com.mdf4.core.Mdf4Constants;
import com.mdf4.channel.Channel;
import com.mdf4.channel.ChannelConfig;

// 创建并写入数据
Mdf4File file = new Mdf4File("data.mf4", Mdf4Constants.OpenMode.WRITE);
file.open();

ChannelConfig config = ChannelConfig.createDouble("EngineSpeed")
    .setUnit("rpm");
Channel channel = file.createChannel(config);

// 写入数据
channel.writeDouble(values);

file.close();
```

### Python使用

```python
import mdf4
import numpy as np

# 创建并写入数据
with mdf4.open('data.mf4', mode='write') as f:
    ch = f.create_channel('EngineSpeed', unit='rpm', dtype='float64')
    
    timestamps = np.arange(1000, dtype=np.uint64) * 1_000_000
    values = np.random.randn(1000)
    
    ch.write(timestamps, values)

# 读取数据
with mdf4.open('data.mf4', mode='read') as f:
    for ch in f.channels:
        print(f"Channel: {ch.name}")
```

## 构建

### 构建Java库

```bash
cd java
mvn clean package
```

### 构建Python库

```bash
cd python/mdf4
pip install -e .
```

## 性能指标

| 指标 | 目标值 | 说明 |
|------|--------|------|
| 写入吞吐量 | ≥500 MB/s | 连续写入场景 |
| 读取吞吐量 | ≥800 MB/s | 顺序读取场景 |
| 写入延迟 | ≤1 ms | 单次写入操作 |
| 随机读取延迟 | ≤10 ms | 非缓存命中 |
| 支持文件大小 | ≥1 TB | 单文件最大容量 |
| 并发通道数 | ≥1000 | 同时写入通道数 |

## 架构设计

### 分层架构

1. **存储层**: 内存映射文件访问
2. **缓存层**: 多级缓存策略（写缓冲区、页缓存、元数据缓存）
3. **核心引擎层**: MDF4协议解析和数据序列化
4. **API层**: C/C++、Python等多种语言绑定

### 关键技术

- **内存映射**: 分段内存映射策略，支持超大文件
- **写缓冲**: 批量写入减少磁盘I/O
- **页缓存**: LRU缓存策略加速随机读取
- **索引机制**: B+树时间索引支持快速查询

## 许可证

MIT License
