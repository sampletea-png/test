# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Logging Utilities.

Provides a standardized logger factory used across the package.
All modules obtain their logger through get_logger(__name__) to
enable fine-grained control via the Python logging hierarchy.

Author: AI Assistant
Date: 2026-04-25
"""

import logging
from typing import Optional

# Package-level logger name; consumers may configure via
# logging.getLogger("mdf_reader_writer").setLevel(...)
_LOGGER_NAME = "mdf_reader_writer"


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Return a logger instance under the package namespace.

    Parameters
    ----------
    name : str, optional
        Typically __name__ of the calling module. If omitted, the
        package root logger is returned.

    Returns
    -------
    logging.Logger
        Configured logger instance.
    """
    if name is None:
        return logging.getLogger(_LOGGER_NAME)
    return logging.getLogger(f"{_LOGGER_NAME}.{name}")
