# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Configuration Module.

Provides a typed, validated configuration dataclass that controls all
aspects of MDF reader/writer behavior: operation mode, fragmentation,
streaming, threading, and file format versioning.

Author: AI Assistant
Date: 2026-04-25
"""

from dataclasses import dataclass, field
from typing import Optional, Union, Literal
from pathlib import Path

from .constants import (
    OperationMode,
    MDFVersion,
    DEFAULT_FRAGMENT_THRESHOLD_BYTES,
    DEFAULT_WRITE_FRAGMENT_SIZE,
    DEFAULT_READ_FRAGMENT_SIZE,
    DEFAULT_LOCK_TIMEOUT_SECONDS,
)
from .exceptions import MDFModeError, MDFVersionError


@dataclass
class MDFConfig:
    """
    Configuration container for MDF reader/writer instances.

    All parameters have sensible defaults for production use, but can be
    tuned for specific acquisition scenarios (high-frequency logging,
    long-term recording, network streaming, etc.).

    Attributes
    ----------
    mode : OperationMode
        Operational mode: NORMAL, FRAGMENTED, or STREAMING.
    version : str
        MDF format version (e.g., '4.10', '3.30').
    fragment_threshold_bytes : int
        Maximum size of a single fragment file in bytes (FRAGMENTED mode).
    fragment_name_format : str
        Python format string for fragment filenames. Accepts {base}, {seq}, {ext}.
    write_fragment_size : int
        Internal data-block split hint for asammdf write path (STREAMING/NORMAL).
    read_fragment_size : int
        Internal data-block split hint for asammdf read path.
    lock_timeout_seconds : float
        Maximum seconds to wait for the instance reentrant lock.
    use_display_names : bool
        If True, channel lookups prefer XML display names over internal names.
    single_bit_uint_as_bool : bool
        If True, single-bit integer channels are returned as np.bool arrays.
    temporary_folder : Optional[str]
        Directory for asammdf temporary files. None uses system default.
    overwrite_on_start : bool
        If True, existing files at the target path are overwritten on start().
    index_file_name : str
        Name of the index file in FRAGMENTED mode (relative to fragment dir).
    """

    mode: OperationMode = OperationMode.NORMAL
    version: str = MDFVersion.DEFAULT

    # Fragmented mode options
    fragment_threshold_bytes: int = DEFAULT_FRAGMENT_THRESHOLD_BYTES
    fragment_name_format: str = "{base}_{seq:03d}{ext}"
    index_file_name: str = "index.mf4"

    # Streaming / internal buffer options
    write_fragment_size: int = DEFAULT_WRITE_FRAGMENT_SIZE
    read_fragment_size: int = DEFAULT_READ_FRAGMENT_SIZE

    # Threading / concurrency
    lock_timeout_seconds: float = DEFAULT_LOCK_TIMEOUT_SECONDS

    # asammdf display/options
    use_display_names: bool = True
    single_bit_uint_as_bool: bool = False
    temporary_folder: Optional[str] = None

    # File lifecycle
    overwrite_on_start: bool = False

    def __post_init__(self):
        """
        Validate configuration values after dataclass initialization.

        Raises
        ------
        MDFVersionError
            If the requested version is not in the supported set.
        MDFModeError
            If mode-specific parameters are inconsistent (e.g., fragment
            threshold <= 0 in FRAGMENTED mode).
        ValueError
            For general parameter out-of-range conditions.
        """
        # Validate MDF version string
        if self.version not in MDFVersion.SUPPORTED:
            raise MDFVersionError(self.version)

        # Validate mode-specific constraints
        if self.mode == OperationMode.FRAGMENTED:
            if self.fragment_threshold_bytes <= 0:
                raise MDFModeError(
                    "fragment_threshold_bytes must be > 0 in FRAGMENTED mode"
                )
            if not self.fragment_name_format:
                raise MDFModeError(
                    "fragment_name_format must be a non-empty format string"
                )

        if self.mode == OperationMode.STREAMING:
            if self.write_fragment_size <= 0:
                raise ValueError("write_fragment_size must be > 0")

        # Validate threading parameter
        if self.lock_timeout_seconds <= 0:
            raise ValueError("lock_timeout_seconds must be > 0")

        # Validate file format / version consistency
        v_major = int(self.version.split(".")[0])
        if v_major == 3:
            self._expected_ext = ".mdf"
        elif v_major == 4:
            self._expected_ext = ".mf4"
        else:
            raise MDFVersionError(self.version)

    @property
    def expected_extension(self) -> str:
        """
        Return the canonical file extension for the configured version.

        Returns
        -------
        str
            '.mdf' for version 3.x, '.mf4' for version 4.x.
        """
        return self._expected_ext

    @classmethod
    def default_for(cls, mode: Union[OperationMode, str]) -> "MDFConfig":
        """
        Factory method returning a pre-tuned default configuration.

        Parameters
        ----------
        mode : OperationMode or str
            Target mode. If str, must be one of 'normal', 'fragmented',
            'streaming' (case-insensitive).

        Returns
        -------
        MDFConfig
            A configuration instance with mode-appropriate defaults.

        Examples
        --------
        >>> cfg = MDFConfig.default_for(OperationMode.FRAGMENTED)
        >>> cfg.fragment_threshold_bytes
        52428800
        """
        if isinstance(mode, str):
            mode_map = {
                "normal": OperationMode.NORMAL,
                "fragmented": OperationMode.FRAGMENTED,
                "streaming": OperationMode.STREAMING,
            }
            mode = mode_map[mode.lower().strip()]

        if mode == OperationMode.FRAGMENTED:
            return cls(mode=mode, fragment_threshold_bytes=50 * 1024 * 1024)
        if mode == OperationMode.STREAMING:
            return cls(mode=mode, write_fragment_size=4 * 1024 * 1024)
        return cls(mode=mode)
