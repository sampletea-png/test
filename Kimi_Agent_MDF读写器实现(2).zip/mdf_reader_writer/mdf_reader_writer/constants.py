# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Constants Module.

Defines version strings, default values, file extensions, and other
immutable constants used throughout the library.

Author: AI Assistant
Date: 2026-04-25
"""

from enum import Enum, auto


class OperationMode(Enum):
    """
    Enumeration of supported MDF reader/writer operation modes.

    Members
    -------
    NORMAL : auto
        Standard single-file mode. All data is stored in one .mf4/.mdf file.
    FRAGMENTED : auto
        Shard mode. Data is split across multiple files based on volume/size
        thresholds. An index file maintains the schema mapping data groups
        to physical fragments.
    STREAMING : auto
        Streaming mode. Optimized for continuous, append-only writes with
        configurable fragment sizes for real-time acquisition scenarios.
    """
    NORMAL = auto()
    FRAGMENTED = auto()
    STREAMING = auto()


class MDFVersion:
    """
    Supported MDF file format versions.

    Version 3.x uses the .mdf extension; version 4.x uses .mf4.
    The underlying asammdf engine handles both families.
    """
    V3_00 = "3.00"
    V3_10 = "3.10"
    V3_20 = "3.20"
    V3_30 = "3.30"
    V4_00 = "4.00"
    V4_10 = "4.10"
    V4_11 = "4.11"
    V4_20 = "4.20"
    V4_30 = "4.30"

    SUPPORTED = (V3_00, V3_10, V3_20, V3_30, V4_00, V4_10, V4_11, V4_20, V4_30)
    DEFAULT = V4_10


# File extensions
EXT_MDF = ".mdf"   # MDF version 3.x
EXT_MF4 = ".mf4"   # MDF version 4.x
EXT_INDEX = ".mf4"  # Fragmented mode index file extension

# Fragmented mode defaults
DEFAULT_FRAGMENT_THRESHOLD_BYTES = 50 * 1024 * 1024  # 50 MB per fragment
DEFAULT_FRAGMENT_NAME_FORMAT = "{base}_{seq:03d}{ext}"
DEFAULT_INDEX_FILE_NAME = "index.mf4"

# Streaming mode defaults
DEFAULT_WRITE_FRAGMENT_SIZE = 4 * 1024 * 1024   # 4 MB (asammdf CANape compat)
DEFAULT_READ_FRAGMENT_SIZE = 256 * 1024 * 1024  # 256 MB

# Threading defaults
DEFAULT_LOCK_TIMEOUT_SECONDS = 30.0

# Metadata sidecar for persistent append state
METADATA_SUFFIX = ".mdfmeta.json"

# HDF/HD block attribute keys (used when creating data groups)
HD_COMMENT = "comment"
HD_TIME_SOURCE = "time_source"
HD_START_TIME = "start_time"

# Channel group attribute keys
CG_COMMENT = "comment"
CG_ACQ_NAME = "acq_name"
CG_ACQ_SOURCE = "acq_source"

# Channel attribute keys
CH_COMMENT = "comment"
CH_UNIT = "unit"
CH_DISPLAY_NAME = "display_name"
CH_MIN = "min"
CH_MAX = "max"
