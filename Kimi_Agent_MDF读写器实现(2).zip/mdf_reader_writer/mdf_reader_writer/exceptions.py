# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Custom Exceptions Module.

Provides a comprehensive exception hierarchy for the MDF reader/writer system,
enabling precise error handling and debugging across all operation modes
(normal, fragmented, streaming).

Author: AI Assistant
Date: 2026-04-25
"""


class MDFError(Exception):
    """
    Base exception for all MDF reader/writer errors.

    Serves as the root of the exception hierarchy, allowing callers to catch
    any MDF-related error with a single except clause.

    Attributes
    ----------
    message : str
        Human-readable error description.
    error_code : str, optional
        Machine-readable error code for programmatic handling.
    """

    def __init__(self, message: str, error_code: str = None):
        """
        Initialize the base MDF error.

        Parameters
        ----------
        message : str
            Detailed error description.
        error_code : str, optional
            Optional error code (e.g., 'E001', 'W002') for classification.
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code


class MDFNotStartedError(MDFError):
    """
    Raised when an operation is invoked before start() was called.

    Both reader and writer require an explicit start() call to initialize
    internal resources. Any read/write/check operation issued before start()
    or after stop() will raise this exception.

    Typical triggers:
    - Calling append() before writer.start()
    - Calling get() before reader.start()
    - Calling exists() after writer.stop()
    """

    def __init__(self, message: str = "Operation requires start() to be called first"):
        super().__init__(message, error_code="E100")


class MDFAlreadyStartedError(MDFError):
    """
    Raised when start() is called twice without an intervening stop().

    Prevents resource leaks and state corruption by enforcing a strict
    start -> work -> stop lifecycle.
    """

    def __init__(self, message: str = "Instance already started; call stop() before restarting"):
        super().__init__(message, error_code="E101")


class MDFLocationNotFoundError(MDFError):
    """
    Raised when a specified (data_group, channel_group, channel) does not exist.

    Used by:
    - Writer.append() when the target location is absent and must exist.
    - Writer.extend() when the target location is absent.
    - Reader.get() when reading from a non-existent channel.

    Attributes
    ----------
    data_group_index : int
        Requested data group index.
    channel_group_index : int
        Requested channel group index.
    channel_index : int
        Requested channel index.
    """

    def __init__(self, data_group_index: int, channel_group_index: int, channel_index: int):
        message = (
            f"Location not found: "
            f"data_group={data_group_index}, "
            f"channel_group={channel_group_index}, "
            f"channel={channel_index}"
        )
        super().__init__(message, error_code="E200")
        self.data_group_index = data_group_index
        self.channel_group_index = channel_group_index
        self.channel_index = channel_index


class MDFVersionError(MDFError):
    """
    Raised when an unsupported MDF version is requested.

    The library supports MDF versions 3.00, 3.10, 3.20, 3.30 and
    4.00, 4.10, 4.11, 4.20, 4.30 via the underlying asammdf engine.
    Requests for 2.x or other unsupported versions raise this error.
    """

    def __init__(self, version: str):
        message = f"Unsupported MDF version: '{version}'. Supported: 3.x, 4.x"
        super().__init__(message, error_code="E300")
        self.version = version


class MDFModeError(MDFError):
    """
    Raised when an operation is incompatible with the current mode.

    For example, attempting a fragmented-mode operation on a writer
    configured for streaming mode, or vice versa.
    """

    def __init__(self, message: str):
        super().__init__(message, error_code="E400")


class MDFIOError(MDFError):
    """
    Raised for low-level I/O failures during read/write operations.

    Wraps filesystem errors (PermissionError, OSError) with additional
    context about the MDF operation in progress.

    Attributes
    ----------
    original_error : Exception
        The underlying exception that caused the failure.
    filepath : str
        File path being accessed when the error occurred.
    """

    def __init__(self, message: str, original_error: Exception = None, filepath: str = None):
        super().__init__(message, error_code="E500")
        self.original_error = original_error
        self.filepath = filepath


class MDFCorruptError(MDFError):
    """
    Raised when an MDF file or its index metadata is corrupted.

    Detected during:
    - Index schema parsing in fragmented mode.
    - File header validation on open.
    - Checksum verification if enabled.
    """

    def __init__(self, message: str, filepath: str = None):
        super().__init__(message, error_code="E600")
        self.filepath = filepath


class MDFConcurrencyError(MDFError):
    """
    Raised when a thread-safety violation is detected.

    Typically occurs if a timeout is exceeded while waiting for the
    instance lock, indicating potential deadlock or excessive contention.
    """

    def __init__(self, message: str = "Concurrency timeout or lock contention"):
        super().__init__(message, error_code="E700")
