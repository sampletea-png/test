# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Utilities Module.

Helper functions for path manipulation, version detection, schema
serialization, locking, and other cross-cutting concerns.

Author: AI Assistant
Date: 2026-04-25
"""

import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

import numpy as np

from .constants import EXT_MDF, EXT_MF4
from .exceptions import MDFConcurrencyError, MDFIOError


def infer_extension(version: str) -> str:
    """
    Return the canonical file extension for an MDF version string.

    Parameters
    ----------
    version : str
        MDF version string (e.g., '3.30', '4.10').

    Returns
    -------
    str
        '.mdf' for major version 3, '.mf4' for major version 4.

    Raises
    ------
    ValueError
        If the version string is malformed or unsupported.
    """
    try:
        major = int(version.split(".")[0])
    except (IndexError, ValueError) as exc:
        raise ValueError(f"Invalid version string: {version}") from exc
    if major == 3:
        return EXT_MDF
    if major == 4:
        return EXT_MF4
    raise ValueError(f"Unsupported major version: {major}")


def resolve_path(filepath: Union[str, Path]) -> Path:
    """
    Convert a user-supplied path to an absolute, normalized Path object.

    Expands user home directories (~) and resolves symbolic links.

    Parameters
    ----------
    filepath : str or Path
        Input path, potentially relative or containing ~.

    Returns
    -------
    Path
        Absolute, resolved Path.
    """
    return Path(filepath).expanduser().resolve()


def build_fragment_path(
    fragment_dir: Union[str, Path],
    base_name: str,
    sequence: int,
    extension: str,
    name_format: str = "{base}_{seq:03d}{ext}",
) -> Path:
    """
    Construct a fragment file path from naming components.

    Parameters
    ----------
    fragment_dir : str or Path
        Directory that will contain the fragment.
    base_name : str
        Filename stem shared across all fragments.
    sequence : int
        1-based fragment sequence number.
    extension : str
        File extension including leading dot (e.g., '.mf4').
    name_format : str, optional
        Python format string accepting {base}, {seq}, {ext}.

    Returns
    -------
    Path
        Fully resolved fragment path.
    """
    filename = name_format.format(base=base_name, seq=sequence, ext=extension)
    return resolve_path(fragment_dir) / filename


def build_index_path(fragment_dir: Union[str, Path], index_name: str = "index.mf4") -> Path:
    """
    Construct the index file path for fragmented mode.

    Parameters
    ----------
    fragment_dir : str or Path
        Directory containing fragments.
    index_name : str, optional
        Index file name (default 'index.mf4').

    Returns
    -------
    Path
        Fully resolved index path.
    """
    return resolve_path(fragment_dir) / index_name


def schema_to_json(schema: Any) -> str:
    """
    Serialize a dataclass-based schema to a JSON string.

    Uses a custom encoder that handles numpy scalars, arrays, and
    dataclasses recursively.

    Parameters
    ----------
    schema : Any
        Typically an IndexSchema instance or any nested dataclass.

    Returns
    -------
    str
        Compact JSON representation.
    """
    def _convert(obj: Any) -> Any:
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        if isinstance(obj, np.str_):
            return str(obj)
        if hasattr(obj, "__dataclass_fields__"):
            return {k: _convert(v) for k, v in obj.__dict__.items()}
        if isinstance(obj, tuple):
            return [_convert(item) for item in obj]
        if isinstance(obj, list):
            return [_convert(item) for item in obj]
        if isinstance(obj, dict):
            return {str(k): _convert(v) for k, v in obj.items()}
        return obj

    return json.dumps(_convert(schema), ensure_ascii=False)


def schema_from_json(json_str: str) -> Dict[str, Any]:
    """
    Deserialize a JSON string to a plain dictionary.

    Callers are responsible for reconstructing specific dataclass instances.

    Parameters
    ----------
    json_str : str
        JSON text previously produced by schema_to_json().

    Returns
    -------
    Dict[str, Any]
        Nested dictionary representation of the schema.
    """
    return json.loads(json_str)


def atomic_write_json(path: Union[str, Path], data: Dict[str, Any]) -> None:
    """
    Write a JSON file atomically using a temporary rename.

    Parameters
    ----------
    path : str or Path
        Destination file path.
    data : dict
        Serializable dictionary.

    Raises
    ------
    MDFIOError
        If the write or rename operation fails.
    """
    path = resolve_path(path)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=2)
        os.replace(temp_path, path)
    except OSError as exc:
        raise MDFIOError(
            f"Failed to write JSON metadata to {path}",
            original_error=exc,
            filepath=str(path),
        ) from exc


def safe_read_json(path: Union[str, Path]) -> Optional[Dict[str, Any]]:
    """
    Read a JSON file if it exists; return None otherwise.

    Parameters
    ----------
    path : str or Path
        Source file path.

    Returns
    -------
    dict or None
        Parsed dictionary, or None if the file does not exist.

    Raises
    ------
    MDFIOError
        If the file exists but cannot be read or parsed.
    """
    path = resolve_path(path)
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as fp:
            return json.load(fp)
    except (OSError, json.JSONDecodeError) as exc:
        raise MDFIOError(
            f"Failed to read JSON metadata from {path}",
            original_error=exc,
            filepath=str(path),
        ) from exc


def file_size(path: Union[str, Path]) -> int:
    """
    Return the size of a file in bytes, or 0 if the file does not exist.

    Parameters
    ----------
    path : str or Path
        File to inspect.

    Returns
    -------
    int
        File size in bytes (non-negative).
    """
    path = resolve_path(path)
    if path.exists() and path.is_file():
        return path.stat().st_size
    return 0


def ensure_dir(path: Union[str, Path]) -> Path:
    """
    Ensure that a directory exists, creating parents if necessary.

    Parameters
    ----------
    path : str or Path
        Target directory.

    Returns
    -------
    Path
        Resolved directory path.
    """
    path = resolve_path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def create_channel_name(base: str, index: int) -> str:
    """
    Generate a deterministic channel name for internal bookkeeping.

    Parameters
    ----------
    base : str
        User-visible channel name.
    index : int
        Numeric suffix for disambiguation.

    Returns
    -------
    str
        Internal unique name (e.g., 'Sine__ch_1').
    """
    return f"{base}__ch_{index}"


def split_time_and_samples(
    raw: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Validate and split a 2D array into timestamps (first column) and samples.

    Parameters
    ----------
    raw : np.ndarray
        Array of shape (N, 2+) or (N,). If 1D, a default linear timebase
        0..N-1 is synthesized.

    Returns
    -------
    timestamps : np.ndarray
        1D float64 array of length N.
    samples : np.ndarray
        Original array if 1D, else all columns after the first.

    Raises
    ------
    ValueError
        If input is not a numpy array or has insufficient dimensions.
    """
    if not isinstance(raw, np.ndarray):
        raise ValueError("Input must be a numpy ndarray")
    if raw.ndim == 1:
        timestamps = np.arange(len(raw), dtype=np.float64)
        samples = raw
    elif raw.ndim == 2 and raw.shape[1] >= 2:
        timestamps = raw[:, 0].astype(np.float64)
        samples = raw[:, 1:]
    else:
        raise ValueError(
            f"Input array must be 1D or 2D with at least 2 columns; got shape {raw.shape}"
        )
    return timestamps, samples


def validate_samples_timestamps(
    timestamps: np.ndarray,
    samples: np.ndarray,
) -> None:
    """
    Ensure timestamps and samples have compatible lengths and monotonic time.

    Parameters
    ----------
    timestamps : np.ndarray
        1D array of time values.
    samples : np.ndarray
        1D or 2D array of payload values.

    Raises
    ------
    ValueError
        If lengths mismatch, timestamps are not 1D, or time is not
        monotonically non-decreasing.
    """
    if timestamps.ndim != 1:
        raise ValueError(f"timestamps must be 1D; got {timestamps.ndim}D")
    ts_len = len(timestamps)
    if samples.ndim == 1:
        if len(samples) != ts_len:
            raise ValueError(
                f"timestamps length {ts_len} != samples length {len(samples)}"
            )
    elif samples.ndim >= 2:
        if samples.shape[0] != ts_len:
            raise ValueError(
                f"timestamps length {ts_len} != samples first dim {samples.shape[0]}"
            )
    else:
        raise ValueError(f"samples must be at least 1D; got {samples.ndim}D")

    # Check monotonic (with tolerance for floating noise)
    if ts_len > 1:
        if not np.all(np.diff(timestamps) >= -1e-12):
            raise ValueError("timestamps must be monotonically non-decreasing")


class TimedRLock:
    """
    Reentrant lock wrapper with configurable acquisition timeout.

    Protects the MDF reader/writer state across concurrent threads.
    Every public method on the writer/reader acquires this lock for
    the duration of the call.

    Attributes
    ----------
    timeout_seconds : float
        Maximum time to wait for lock acquisition.
    """

    def __init__(self, timeout_seconds: float = 30.0):
        self._lock = threading.RLock()
        self.timeout_seconds = timeout_seconds

    def acquire(self) -> bool:
        """
        Attempt to acquire the lock within the configured timeout.

        Returns
        -------
        bool
            True if acquired, False on timeout.

        Raises
        ------
        MDFConcurrencyError
            If the lock cannot be acquired within timeout_seconds.
        """
        if self._lock.acquire(blocking=True, timeout=self.timeout_seconds):
            return True
        raise MDFConcurrencyError(
            f"Failed to acquire lock within {self.timeout_seconds}s"
        )

    def release(self) -> None:
        """Release the lock (idempotent for the owning thread)."""
        try:
            self._lock.release()
        except RuntimeError:
            # releasing an unowned lock is safe to ignore
            pass

    def __enter__(self) -> "TimedRLock":
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.release()
