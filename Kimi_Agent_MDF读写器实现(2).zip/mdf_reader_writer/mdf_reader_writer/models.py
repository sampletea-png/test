# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Data Models Module.

Defines lightweight data-transfer objects (DTOs) used for channel
metadata, fragment descriptors, index schema records, and acquisition
attribute bundles.

Author: AI Assistant
Date: 2026-04-25
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple
import numpy as np


@dataclass
class ChannelLocation:
    """
    Uniquely identifies a channel within the MDF hierarchy.

    In MDF4 (and asammdf), data groups and channel groups are tightly
    coupled: each appended signal list creates one data group containing
    exactly one channel group. Therefore, (data_group, channel_group) usually
    map to the same integer. However, the API exposes both for forward
    compatibility and conceptual clarity.

    Attributes
    ----------
    data_group_index : int
        Top-level data group (DG) index.
    channel_group_index : int
        Channel group (CG) index within the data group.
    channel_index : int
        Channel index within the channel group.
    """

    data_group_index: int
    channel_group_index: int
    channel_index: int

    def __hash__(self) -> int:
        """Enable use as dict key and set member."""
        return hash((self.data_group_index, self.channel_group_index, self.channel_index))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ChannelLocation):
            return NotImplemented
        return (
            self.data_group_index == other.data_group_index
            and self.channel_group_index == other.channel_group_index
            and self.channel_index == other.channel_index
        )

    def __repr__(self) -> str:
        return (
            f"ChannelLocation(dg={self.data_group_index}, "
            f"cg={self.channel_group_index}, ch={self.channel_index})"
        )


@dataclass
class ChannelAttributes:
    """
    Mutable attribute bundle for a channel at creation time.

    Wraps asammdf-level metadata such as display unit, physical min/max,
    comment, and source information.

    Attributes
    ----------
    comment : str
        Human-readable channel description.
    unit : str
        Physical unit string (e.g., 'V', 'm/s^2').
    display_name : Optional[str]
        Preferred GUI display name (XML comment override).
    min_raw : Optional[float]
        Minimum expected raw value.
    max_raw : Optional[float]
        Maximum expected raw value.
    conversion : Optional[Any]
        asammdf ChannelConversion or dict describing raw->phys conversion.
    extra : Dict[str, Any]
        Vendor-specific or user-defined metadata key-value pairs.
    """

    comment: str = ""
    unit: str = ""
    display_name: Optional[str] = None
    min_raw: Optional[float] = None
    max_raw: Optional[float] = None
    conversion: Optional[Any] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChannelGroupAttributes:
    """
    Mutable attribute bundle for a channel group at creation time.

    In asammdf, a channel group maps to a single append() call: all signals
    share timestamps and are stored in the same data block.

    Attributes
    ----------
    comment : str
        Description of the acquisition event / group.
    acq_name : str
        Acquisition name (e.g., 'DAQ_task_1').
    acq_source : Optional[Any]
        asammdf Source object describing the measurement source.
    sample_rate : Optional[float]
        Nominal sample rate in Hz, if known.
    extra : Dict[str, Any]
        User-defined metadata.
    """

    comment: str = ""
    acq_name: str = ""
    acq_source: Optional[Any] = None
    sample_rate: Optional[float] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataGroupAttributes:
    """
    Mutable attribute bundle for a data group at creation time.

    In asammdf, a data group is created automatically when append() is
    called. This class captures the HD-block level metadata that can be
    injected into the resulting group.

    Attributes
    ----------
    comment : str
        Data group / file-level comment.
    start_time : Optional[np.datetime64]
        Acquisition start timestamp.
    time_source : Optional[str]
        Source of the master timebase ('PC', 'GPS', 'IRIG', etc.).
    extra : Dict[str, Any]
        User-defined metadata.
    """

    comment: str = ""
    start_time: Optional[np.datetime64] = None
    time_source: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FragmentDescriptor:
    """
    Metadata record for a single fragment file in FRAGMENTED mode.

    Maintained inside the index schema; describes the physical file that
    hosts a subset of data groups.

    Attributes
    ----------
    fragment_id : int
        Monotonically increasing fragment sequence number (1-based).
    file_path : str
        Absolute or relative path to the fragment .mf4/.mdf file.
    data_groups : Tuple[int, ...]
        Data group indices stored in this fragment (inclusive ranges).
    byte_size : int
        Actual file size on disk at the time of indexing.
    checksum : Optional[str]
        Optional file checksum for integrity verification.
    """

    fragment_id: int
    file_path: str
    data_groups: Tuple[int, ...] = field(default_factory=tuple)
    byte_size: int = 0
    checksum: Optional[str] = None


@dataclass
class IndexSchema:
    """
    Top-level schema stored in the fragmented-mode index file.

    Maps logical data groups to physical fragments and persists writer
    state so that append/extend operations can resume after stop/start.

    Attributes
    ----------
    version : str
        Schema format version for future migrations.
    base_name : str
        Base filename stem (e.g., 'mdf_test').
    mdf_version : str
        Underlying MDF format version ('4.10', etc.).
    fragments : List[FragmentDescriptor]
        Ordered list of fragment descriptors.
    next_fragment_id : int
        Sequence counter for the next fragment to be created.
    channel_map : Dict[ChannelLocation, Tuple[int, str]]
        Maps each ChannelLocation -> (fragment_id, channel_name) for quick
        reverse lookups. fragment_id of -1 means 'not yet persisted'.
    global_attrs : Dict[str, Any]
        Global file attributes (HD block metadata mirrored here).
    """

    version: str = "1.0"
    base_name: str = ""
    mdf_version: str = "4.10"
    fragments: List[FragmentDescriptor] = field(default_factory=list)
    next_fragment_id: int = 1
    channel_map: Dict[ChannelLocation, Tuple[int, str]] = field(default_factory=dict)
    global_attrs: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PendingWrite:
    """
    Internal record of a pending append/extend operation before save().

    Used by the writer to batch in-memory mutations and flush them
    atomically during save().

    Attributes
    ----------
    operation : str
        Either 'append' or 'extend'.
    location : ChannelLocation
        Target channel address.
    timestamps : np.ndarray
        Master timebase samples.
    samples : np.ndarray
        Channel payload samples.
    """

    operation: str
    location: ChannelLocation
    timestamps: np.ndarray
    samples: np.ndarray
