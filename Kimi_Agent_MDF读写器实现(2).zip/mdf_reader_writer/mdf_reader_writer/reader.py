# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Reader Module.

Implements MDFReader with three operational modes that mirror the writer:
  - NORMAL    : read from a single MDF file
  - FRAGMENTED : read via index schema, stitching fragments transparently
  - STREAMING  : read from a single file optimized for streaming acquisition

Provides variant get methods with time-range slicing and count-limited
retrieval. All reads are protected by the same reentrant lock used in the
writer, allowing safe concurrent access.

Author: AI Assistant
Date: 2026-04-25
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
from asammdf import MDF

from .base import MDFBase
from .config import MDFConfig
from .constants import EXT_MF4, OperationMode
from .exceptions import (
    MDFIOError,
    MDFLocationNotFoundError,
    MDFNotStartedError,
)
from .logging_utils import get_logger
from .models import ChannelLocation, FragmentDescriptor, IndexSchema
from .utils import (
    build_index_path,
    file_size,
    infer_extension,
    resolve_path,
    safe_read_json,
    schema_from_json,
)

logger = get_logger(__name__)


class _ReaderChannelCache:
    """
    Lightweight cache entry for a resolved (group_index, channel_name) pair.

    Avoids repeated name->index lookups inside asammdf.
    """

    def __init__(self, group_index: int, channel_name: str):
        self.group_index = group_index
        self.channel_name = channel_name


class MDFReader(MDFBase):
    """
    Production-grade MDF reader supporting normal, fragmented, and streaming modes.

    The reader reconstructs the logical (dg, cg, ch) address space by either
    reading a single file (NORMAL/STREAMING) or following the fragmented
    index schema to locate the correct shard file(s) for each query.

    Usage Example
    -------------
    >>> reader = MDFReader("/data/run_01.mf4")
    >>> reader.start()
    >>> ts, samples = reader.get(0, 0, 1)  # dg=0, cg=0, ch=1
    >>> ts_win, samples_win = reader.get_range(0, 0, 1, 5.0, 10.0)
    >>> reader.stop()
    """

    def __init__(self, filepath: Union[str, Path], config: Optional[MDFConfig] = None):
        """
        Initialize reader without opening file handles.

        Parameters
        ----------
        filepath : str or Path
            Source path. In NORMAL/STREAMING modes this is the MDF file.
            In FRAGMENTED mode it is the directory containing the index.
        config : MDFConfig, optional
            Read configuration (fragment sizes, timeout, etc.). Defaults to
            NORMAL mode if omitted.
        """
        super().__init__(filepath, config)
        # For fragmented mode
        self._schema: Optional[IndexSchema] = None
        self._fragment_mdfs: Dict[str, MDF] = {}
        # Logical -> physical cache
        self._channel_cache: Dict[ChannelLocation, _ReaderChannelCache] = {}
        # Index of which fragment contains which data groups
        self._dg_to_fragment: Dict[int, str] = {}

    # ------------------------------------------------------------------
    # Lifecycle hooks
    # ------------------------------------------------------------------

    def _do_start(self) -> None:
        """
        Open the underlying MDF storage and build lookup indices.

        NORMAL / STREAMING
        --------------------
        Opens a single asammdf.MDF handle on self._filepath.
        Builds a logical channel map from asammdf.groups metadata.

        FRAGMENTED
        ----------
        Loads the index schema, then opens each fragment file lazily (or
        eagerly based on configuration). Builds a reverse map from
        data_group_index -> fragment path.

        Logging
        -------
        INFO level messages emitted for file open and schema load events.
        """
        if self._config.mode == OperationMode.FRAGMENTED:
            logger.info("Starting FRAGMENTED reader: %s", self._filepath)
            self._start_fragmented()
        else:
            logger.info("Starting %s reader: %s", self._config.mode.name, self._filepath)
            self._start_single()

    def _do_stop(self) -> None:
        """
        Close all open MDF handles and clear caches.

        Guarantees that file descriptors are released even if individual
        close() calls raise exceptions. Caches are unconditionally cleared
        to prevent stale lookups on a subsequent start().

        Logging
        -------
        INFO level message emitted after all handles are closed.
        """
        close_errors = []
        for frag_path, mdf in list(self._fragment_mdfs.items()):
            try:
                mdf.close()
                logger.debug("Closed fragment: %s", frag_path)
            except Exception as exc:
                close_errors.append((frag_path, exc))
                logger.warning("Error closing fragment %s: %s", frag_path, exc)
        self._fragment_mdfs.clear()
        self._channel_cache.clear()
        self._dg_to_fragment.clear()
        if self._mdf is not None:
            try:
                self._mdf.close()
                logger.debug("Closed primary MDF file")
            except Exception as exc:
                close_errors.append((str(self._filepath), exc))
                logger.warning("Error closing primary file %s: %s", self._filepath, exc)
            finally:
                self._mdf = None
        logger.info(
            "Reader stopped: mode=%s, fragments_closed=%d",
            self._config.mode.name,
            len(close_errors),
        )

    def _start_single(self) -> None:
        """Open one MDF file and index its channels."""
        if not self._filepath.exists():
            raise MDFIOError(f"File not found: {self._filepath}", filepath=str(self._filepath))
        self._mdf = MDF(str(self._filepath))
        self._index_channels(self._mdf, source_path=str(self._filepath))

    def _start_fragmented(self) -> None:
        """Load index schema and prepare fragment map."""
        if not self._filepath.is_dir():
            raise MDFIOError(
                f"FRAGMENTED mode expects a directory: {self._filepath}",
                filepath=str(self._filepath),
            )
        # Load schema
        schema_path = build_index_path(self._filepath, self._config.index_file_name)
        schema_path = schema_path.with_suffix(".schema.json")
        payload = safe_read_json(schema_path)
        if payload is None:
            raise MDFIOError(
                f"Fragment schema not found: {schema_path}",
                filepath=str(schema_path),
            )
        self._schema = self._deserialize_schema(payload)
        # Build dg -> fragment map
        for frag in self._schema.fragments:
            for dg in frag.data_groups:
                self._dg_to_fragment[dg] = frag.file_path

    def _deserialize_schema(self, payload: Dict) -> IndexSchema:
        """Reconstruct an IndexSchema from its JSON payload."""
        schema = IndexSchema(
            version=payload.get("version", "1.0"),
            base_name=payload.get("base_name", ""),
            mdf_version=payload.get("mdf_version", "4.10"),
            next_fragment_id=payload.get("next_fragment_id", 1),
            global_attrs=payload.get("global_attrs", {}),
        )
        for frag_payload in payload.get("fragments", []):
            frag = FragmentDescriptor(
                fragment_id=frag_payload["fragment_id"],
                file_path=frag_payload["file_path"],
                data_groups=tuple(frag_payload.get("data_groups", [])),
                byte_size=frag_payload.get("byte_size", 0),
                checksum=frag_payload.get("checksum"),
            )
            schema.fragments.append(frag)
        return schema

    def _index_channels(self, mdf: MDF, source_path: str) -> None:
        """
        Walk asammdf groups/channels and populate logical cache.

        In the underlying MDF model, channel 0 of each group is the master
        timebase (automatically created by asammdf). User-created channels
        start at asammdf index 1, which we map to user channel_index 0.
        """
        for grp_idx, grp in enumerate(mdf.groups):
            for ch_idx, ch in enumerate(grp.channels):
                if ch_idx == 0:
                    # Master timebase is exposed at logical channel index -1
                    # (not typically used by callers) but we keep it for completeness
                    loc = ChannelLocation(grp_idx, 0, -1)
                    cache = _ReaderChannelCache(grp_idx, ch.name)
                    self._channel_cache[loc] = cache
                    continue
                user_ch_idx = ch_idx - 1
                loc = ChannelLocation(grp_idx, 0, user_ch_idx)
                cache = _ReaderChannelCache(grp_idx, ch.name)
                self._channel_cache[loc] = cache

    def _get_fragment_mdf(self, fragment_path: str) -> MDF:
        """Open or return a cached MDF handle for a fragment file."""
        if fragment_path not in self._fragment_mdfs:
            mdf = MDF(fragment_path)
            self._fragment_mdfs[fragment_path] = mdf
            # Also index its channels into the global cache
            self._index_channels(mdf, source_path=fragment_path)
        return self._fragment_mdfs[fragment_path]

    # ------------------------------------------------------------------
    # Public API: Reading
    # ------------------------------------------------------------------

    def get(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Retrieve the full (timestamps, samples) arrays for a logical channel.

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int

        Returns
        -------
        timestamps : np.ndarray
            1D float64 master timebase.
        samples : np.ndarray
            1D array of channel samples.

        Raises
        ------
        MDFLocationNotFoundError
            If the logical channel does not exist.
        MDFIOError
            If the underlying file read fails.
        """
        with self._lock:
            self._require_started()
            return self._read_channel(data_group_index, channel_group_index, channel_index)

    def get_range(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
        start_time: float,
        end_time: float,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Retrieve channel data restricted to a time window [start_time, end_time).

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int
        start_time : float
            Inclusive lower bound of the time window.
        end_time : float
            Exclusive upper bound of the time window.

        Returns
        -------
        timestamps : np.ndarray
            1D float64, filtered to the window.
        samples : np.ndarray
            1D array aligned to the returned timestamps.

        Raises
        ------
        MDFLocationNotFoundError
            If the logical channel does not exist.
        ValueError
            If start_time >= end_time.
        """
        with self._lock:
            # Step 1: Verify the reader is in a valid started state.
            self._require_started()
            # Step 2: Validate the time window bounds.
            if start_time >= end_time:
                raise ValueError(f"start_time {start_time} must be < end_time {end_time}")
            # Step 3: Read the full channel data from the appropriate MDF source.
            timestamps, samples = self._read_channel(
                data_group_index, channel_group_index, channel_index
            )
            # Step 4: Build a boolean mask for samples within the half-open window.
            mask = (timestamps >= start_time) & (timestamps < end_time)
            # Step 5: Return filtered arrays; empty arrays if no samples match.
            return timestamps[mask], samples[mask]

    def get_from_time(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
        start_time: float,
        max_count: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Retrieve up to max_count samples starting from start_time (inclusive).

        This is useful for real-time polling or paged access to large files.

        Parameters
        ----------
        data_group_index : int
        channel_group_index : int
        channel_index : int
        start_time : float
            Inclusive starting time.
        max_count : int
            Maximum number of samples to return (must be > 0).

        Returns
        -------
        timestamps : np.ndarray
            1D float64 of length <= max_count.
        samples : np.ndarray
            1D array of matching length.

        Raises
        ------
        MDFLocationNotFoundError
            If the logical channel does not exist.
        ValueError
            If max_count <= 0.
        """
        with self._lock:
            # Step 1: Verify the reader is in a valid started state.
            self._require_started()
            # Step 2: Validate the sample count limit is positive.
            if max_count <= 0:
                raise ValueError(f"max_count must be > 0; got {max_count}")
            # Step 3: Read the full channel data from the appropriate MDF source.
            timestamps, samples = self._read_channel(
                data_group_index, channel_group_index, channel_index
            )
            # Step 4: Build a mask for samples at or after start_time.
            mask = timestamps >= start_time
            ts_filtered = timestamps[mask]
            samples_filtered = samples[mask]
            # Step 5: Restrict to the requested maximum count.
            n = min(max_count, len(ts_filtered))
            return ts_filtered[:n], samples_filtered[:n]

    # ------------------------------------------------------------------
    # Internal read implementation
    # ------------------------------------------------------------------

    def _read_channel(self, dg: int, cg: int, ch: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Resolve the logical channel and fetch its data from the appropriate MDF.

        In FRAGMENTED mode, the correct fragment file is selected via
        _dg_to_fragment. In NORMAL/STREAMING mode, the single handle is used.

        Returns
        -------
        timestamps, samples : np.ndarray
        """
        # Step 1: Construct the logical address key.
        loc = ChannelLocation(dg, cg, ch)
        # Step 2: If the channel is not yet in the cache, attempt to locate it.
        if loc not in self._channel_cache:
            # In fragmented mode the channel may reside in a not-yet-opened fragment.
            if self._config.mode == OperationMode.FRAGMENTED:
                frag_path = self._dg_to_fragment.get(dg)
                if frag_path is None:
                    raise MDFLocationNotFoundError(dg, cg, ch)
                # Lazily open the fragment and index its channels.
                mdf = self._get_fragment_mdf(frag_path)
                # Re-check after indexing; if still missing, the location is invalid.
                if loc not in self._channel_cache:
                    raise MDFLocationNotFoundError(dg, cg, ch)
            else:
                raise MDFLocationNotFoundError(dg, cg, ch)

        # Step 3: Retrieve the cached physical address (group + name).
        cache = self._channel_cache[loc]
        # Step 4: Select the correct MDF handle (fragment-specific or primary).
        if self._config.mode == OperationMode.FRAGMENTED:
            frag_path = self._dg_to_fragment.get(dg)
            if frag_path is None:
                raise MDFLocationNotFoundError(dg, cg, ch)
            mdf = self._get_fragment_mdf(frag_path)
        else:
            mdf = self._mdf

        # Step 5: Execute the asammdf read by channel name and group.
        try:
            sig = mdf.get(
                cache.channel_name,
                group=cache.group_index,
            )
            # Step 6: Return the raw timestamps and sample arrays.
            return sig.timestamps, sig.samples
        except Exception as exc:
            # Step 7: Wrap low-level asammdf exceptions in our MDFIOError hierarchy.
            raise MDFIOError(
                f"Failed to read channel {cache.channel_name} from group {cache.group_index}",
                original_error=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Informational API
    # ------------------------------------------------------------------

    def list_data_groups(self) -> List[int]:
        """Return sorted list of data group indices visible in the file(s)."""
        with self._lock:
            self._require_started()
            if self._config.mode == OperationMode.FRAGMENTED:
                return sorted(self._dg_to_fragment.keys())
            else:
                return list(range(len(self._mdf.groups))) if self._mdf else []

    def list_channels(self, data_group_index: int) -> List[Tuple[int, str]]:
        """
        Return (channel_index, channel_name) tuples for a data group.

        Returns empty list if the group does not exist.
        """
        with self._lock:
            self._require_started()
            if self._config.mode == OperationMode.FRAGMENTED:
                frag_path = self._dg_to_fragment.get(data_group_index)
                if frag_path is None:
                    return []
                mdf = self._get_fragment_mdf(frag_path)
                if data_group_index >= len(mdf.groups):
                    return []
                grp = mdf.groups[data_group_index]
                return [(i, ch.name) for i, ch in enumerate(grp.channels)]
            else:
                if self._mdf is None or data_group_index >= len(self._mdf.groups):
                    return []
                grp = self._mdf.groups[data_group_index]
                return [(i, ch.name) for i, ch in enumerate(grp.channels)]

    def get_channel_name(
        self,
        data_group_index: int,
        channel_group_index: int,
        channel_index: int,
    ) -> str:
        """
        Return the channel name for a logical location.

        Raises
        ------
        MDFLocationNotFoundError
            If the location does not exist.
        """
        with self._lock:
            self._require_started()
            loc = ChannelLocation(data_group_index, channel_group_index, channel_index)
            if loc not in self._channel_cache:
                raise MDFLocationNotFoundError(data_group_index, channel_group_index, channel_index)
            return self._channel_cache[loc].channel_name

    def file_info(self) -> Dict[str, Union[str, int, List[int]]]:
        """
        Return a dictionary of file metadata.

        Includes mode, version, path, and visible data groups.
        """
        with self._lock:
            self._require_started()
            info = {
                "mode": self._config.mode.name,
                "version": self._config.version,
                "filepath": str(self._filepath),
                "data_groups": self.list_data_groups(),
            }
            if self._config.mode == OperationMode.FRAGMENTED and self._schema:
                info["fragment_count"] = len(self._schema.fragments)
                info["fragments"] = [
                    {"id": f.fragment_id, "path": f.file_path, "size": f.byte_size}
                    for f in self._schema.fragments
                ]
            elif self._mdf:
                info["groups_count"] = len(self._mdf.groups)
                info["channels_db_keys"] = list(self._mdf.channels_db.keys())[:20]
            return info
