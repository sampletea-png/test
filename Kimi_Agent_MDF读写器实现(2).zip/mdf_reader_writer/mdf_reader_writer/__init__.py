# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Public API.

A production-grade Python wrapper over asammdf providing three operational
modes (normal, fragmented, streaming) with thread-safe read/write semantics,
structured metadata APIs, and resumable append/extend after stop/start.

Exports
-------
MDFWriter : class
    Thread-safe writer with append/extend/persist semantics.
MDFReader : class
    Thread-safe reader with full/range/count-limited retrieval.
MDFConfig : class
    Typed configuration dataclass controlling mode, thresholds, threading.
OperationMode : enum
    NORMAL, FRAGMENTED, STREAMING.
MDFVersion : class
    Supported version strings.
ChannelLocation : dataclass
    Logical (dg, cg, ch) address.
ChannelAttributes : dataclass
    Mutable creation-time channel metadata.
ChannelGroupAttributes : dataclass
    Mutable creation-time channel-group metadata.
DataGroupAttributes : dataclass
    Mutable creation-time data-group metadata.
MDFError : exception
    Base exception hierarchy root.
MDFLocationNotFoundError : exception
    Missing logical location.
MDFIOError : exception
    File-system level failure.

Example
-------
>>> from mdf_reader_writer import MDFWriter, MDFReader, MDFConfig, OperationMode
>>> cfg = MDFConfig(mode=OperationMode.NORMAL, version="4.10")
>>> writer = MDFWriter("/tmp/data.mf4", config=cfg)
>>> writer.start()
>>> dg = writer.create_data_group(DataGroupAttributes(comment="test"))
>>> cg = writer.create_channel_group(dg, ChannelGroupAttributes(comment="cg1"))
>>> ch = writer.create_channel(dg, cg, "Speed", ChannelAttributes(unit="km/h"))
>>> writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([10, 20]))
>>> writer.save()
>>> writer.stop()
>>> reader = MDFReader("/tmp/data.mf4")
>>> reader.start()
>>> ts, vals = reader.get(dg, cg, ch)
>>> reader.stop()
"""

from .base import MDFBase
from .channel_buffer import ChannelBuffer
from .config import MDFConfig
from .constants import MDFVersion, OperationMode
from .exceptions import (
    MDFAlreadyStartedError,
    MDFConcurrencyError,
    MDFCorruptError,
    MDFError,
    MDFIOError,
    MDFLocationNotFoundError,
    MDFModeError,
    MDFNotStartedError,
    MDFVersionError,
)
from .logging_utils import get_logger
from .models import (
    ChannelAttributes,
    ChannelGroupAttributes,
    ChannelLocation,
    DataGroupAttributes,
    FragmentDescriptor,
    IndexSchema,
    PendingWrite,
)
from .reader import MDFReader
from .writer import MDFWriter

__version__ = "1.0.0"
__all__ = [
    "MDFWriter",
    "MDFReader",
    "MDFConfig",
    "MDFBase",
    "OperationMode",
    "MDFVersion",
    "ChannelLocation",
    "ChannelAttributes",
    "ChannelGroupAttributes",
    "DataGroupAttributes",
    "FragmentDescriptor",
    "IndexSchema",
    "PendingWrite",
    "ChannelBuffer",
    "get_logger",
    # Exceptions
    "MDFError",
    "MDFNotStartedError",
    "MDFAlreadyStartedError",
    "MDFLocationNotFoundError",
    "MDFVersionError",
    "MDFModeError",
    "MDFIOError",
    "MDFCorruptError",
    "MDFConcurrencyError",
    # Convenience
    "__version__",
]
