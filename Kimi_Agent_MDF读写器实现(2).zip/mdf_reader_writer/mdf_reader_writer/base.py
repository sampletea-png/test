# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Base Classes Module.

Provides the abstract and concrete base classes shared by MDFWriter and
MDFReader: lifecycle management, locking, configuration access, and
common resource cleanup patterns.

Author: AI Assistant
Date: 2026-04-25
"""

import abc
from pathlib import Path
from typing import Any, Dict, Optional, Union

from .config import MDFConfig
from .constants import OperationMode
from .exceptions import MDFAlreadyStartedError, MDFNotStartedError
from .utils import TimedRLock, resolve_path


class MDFBase(abc.ABC):
    """
    Abstract base for both MDFWriter and MDFReader.

    Manages the start/stop lifecycle, thread-safe locking, and
    configuration reference. Subclasses must implement the `_do_start`
    and `_do_stop` hooks for mode-specific initialization and teardown.

    Thread Safety
    -------------
    All public methods are protected by a reentrant lock (TimedRLock).
    Callers may use the same instance from multiple threads; the lock
    serializes access to the underlying asammdf objects and internal
    mutable state.

    Lifecycle (strict ordering)
    ----------------------------
    1. __init__(config)   -> configure but do not allocate resources
    2. start()            -> allocate asammdf objects, open files
    3. work (read/write)  -> business operations
    4. stop()             -> flush, close files, release handles
    5. (optional) start() again -> re-open for a new session
    """

    def __init__(self, filepath: Union[str, Path], config: Optional[MDFConfig] = None):
        """
        Initialize the base with a target path and configuration.

        Parameters
        ----------
        filepath : str or Path
            Primary file path. In NORMAL and STREAMING modes this is the
            data file itself. In FRAGMENTED mode it is the directory that
            will contain the index file and fragment sub-files.
        config : MDFConfig, optional
            Operational configuration. If None, a default NORMAL-mode config
            is created.
        """
        self._filepath: Path = resolve_path(filepath)
        self._config: MDFConfig = config or MDFConfig()
        self._lock = TimedRLock(self._config.lock_timeout_seconds)
        self._started: bool = False
        self._closed: bool = False
        # Internal asammdf handle; concrete subclasses type it appropriately
        self._mdf: Optional[Any] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """
        Begin a new read/write session.

        Acquires the instance lock, validates state, and delegates to
        the subclass-specific `_do_start()` hook.

        Raises
        ------
        MDFAlreadyStartedError
            If start() has already been called without an intervening stop().
        MDFIOError
            If file system operations required by _do_start() fail.
        """
        with self._lock:
            if self._started:
                raise MDFAlreadyStartedError()
            self._do_start()
            self._started = True
            self._closed = False

    def stop(self) -> None:
        """
        End the current session, releasing all resources.

        Safe to call multiple times (idempotent after the first call).

        Delegates to `_do_stop()` for mode-specific cleanup, then marks
        the instance as stopped.
        """
        with self._lock:
            if not self._started:
                return  # idempotent
            try:
                self._do_stop()
            finally:
                self._started = False
                self._closed = True
                self._mdf = None

    # ------------------------------------------------------------------
    # State guards
    # ------------------------------------------------------------------

    def _require_started(self) -> None:
        """
        Raise MDFNotStartedError if the instance is not in a started state.

        Must be called inside a lock-acquired context.
        """
        if not self._started:
            raise MDFNotStartedError()

    # ------------------------------------------------------------------
    # Abstract hooks for subclasses
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def _do_start(self) -> None:
        """
        Subclass-specific start logic: open files, create asammdf objects,
        rebuild indices, etc. Called with the lock held.
        """

    @abc.abstractmethod
    def _do_stop(self) -> None:
        """
        Subclass-specific stop logic: flush buffers, close handles,
        write metadata sidecars, etc. Called with the lock held.
        """

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def filepath(self) -> Path:
        """Resolved target path."""
        return self._filepath

    @property
    def config(self) -> MDFConfig:
        """Active configuration (read-only reference)."""
        return self._config

    @property
    def is_started(self) -> bool:
        """True if start() has been called and stop() has not yet been called."""
        return self._started

    @property
    def is_closed(self) -> bool:
        """True after stop() has been called at least once."""
        return self._closed

    @property
    def mode(self) -> OperationMode:
        """Current operational mode enumeration member."""
        return self._config.mode

    def __enter__(self):
        """Context manager entry: calls start()."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit: calls stop(), swallowing no exceptions."""
        self.stop()
        return False
