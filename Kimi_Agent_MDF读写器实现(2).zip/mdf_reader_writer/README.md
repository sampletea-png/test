# MDF Reader/Writer Package

A production-grade Python wrapper over [asammdf](https://github.com/danielhrisca/asammdf) providing three operational modes with thread-safe read/write semantics, structured metadata APIs, and resumable append/extend after stop/start cycles.

## Features

- **Three Operational Modes**
  - **NORMAL**: Single-file MDF read/write.
  - **FRAGMENTED**: Sharded writes across size-threshold fragment files with an index schema.
  - **STREAMING**: Continuous append-optimized writes with configurable internal flush size.
- **Format Support**: MDF version 3.x (`.mdf`) and 4.x (`.mf4`).
- **Thread Safety**: All public methods are protected by a reentrant lock with configurable timeout.
- **Resume Support**: Stop/start cycles restore structural metadata so writing can continue.
- **Rich Query API**: Full read, time-window slicing, and count-limited retrieval.
- **Production-Grade**: Comprehensive exception hierarchy, logging, resource cleanup, and 75+ unit tests.

## Quick Start

### Installation

```bash
pip install asammdf numpy
```

Add the `mdf_reader_writer` package to your `PYTHONPATH` or install it as a local package.

### Writing

```python
from mdf_reader_writer import (
    MDFWriter, MDFConfig, OperationMode, MDFVersion,
    DataGroupAttributes, ChannelGroupAttributes, ChannelAttributes
)
import numpy as np

# 1. Configure and create writer
cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
writer = MDFWriter("/tmp/output.mf4", config=cfg)

# 2. Start the session (allocates resources)
writer.start()

# 3. Create structure
dg = writer.create_data_group(DataGroupAttributes(comment="Vehicle"))
cg = writer.create_channel_group(dg, ChannelGroupAttributes(acq_name="ECU"))
ch = writer.create_channel(dg, cg, "EngineSpeed", ChannelAttributes(unit="rpm"))

# 4. Append initial data
t = np.linspace(0, 10, 1000)
writer.append(dg, cg, ch, t, 1000 + 500 * np.sin(t))

# 5. Extend with more data
t2 = np.linspace(10, 20, 1000)
writer.extend(dg, cg, ch, t2, 1500 * np.ones_like(t2))

# 6. Save and stop
writer.save()
writer.stop()
```

### Reading

```python
from mdf_reader_writer import MDFReader

reader = MDFReader("/tmp/output.mf4")
reader.start()

# Full read
ts, samples = reader.get(dg, cg, ch)

# Time-window query
ts_win, samples_win = reader.get_range(dg, cg, ch, 5.0, 15.0)

# Count-limited from a start time
ts_paged, samples_paged = reader.get_from_time(dg, cg, ch, 5.0, max_count=100)

reader.stop()
```

### Context Manager

Both writer and reader support context-manager usage for automatic start/stop:

```python
with MDFWriter("/tmp/output.mf4", config=cfg) as w:
    dg = w.create_data_group(DataGroupAttributes())
    # ... write data
# stop() is called automatically on exit
```

## Operational Modes

### NORMAL Mode

All data is stored in a single `.mf4` or `.mdf` file. `save()` overwrites the file with the cumulative in-memory state.

```python
cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
```

### FRAGMENTED Mode

Data is split across multiple files based on a byte threshold. An index schema tracks which data groups live in which fragment.

```python
cfg = MDFConfig(
    mode=OperationMode.FRAGMENTED,
    version=MDFVersion.V4_10,
    fragment_threshold_bytes=50 * 1024 * 1024,  # 50 MB per shard
    overwrite_on_start=True,
)
writer = MDFWriter("/tmp/shards/", config=cfg)  # directory, not file
```

Directory layout:
```
/tmp/shards/
  index.schema.json   # fragment index metadata
  shards_001.mf4      # data fragment 1
  shards_002.mf4      # data fragment 2
  ...
```

### STREAMING Mode

Optimized for high-frequency, append-only acquisition. Internally configures asammdf with a smaller write fragment size.

```python
cfg = MDFConfig(mode=OperationMode.STREAMING, version=MDFVersion.V4_10)
```

## Thread Safety

Instances are safe to use from multiple threads. All public methods acquire a reentrant lock (`threading.RLock`) internally:

```python
import threading

def worker(writer, dg, cg, ch):
    for i in range(100):
        writer.extend(dg, cg, ch, np.array([i]), np.array([i * 2]))

t1 = threading.Thread(target=worker, args=(writer, dg, cg, ch))
t2 = threading.Thread(target=worker, args=(writer, dg, cg, ch))
t1.start(); t2.start()
t1.join(); t2.join()
```

## Exception Hierarchy

```
MDFError
├── MDFNotStartedError
├── MDFAlreadyStartedError
├── MDFLocationNotFoundError
├── MDFVersionError
├── MDFModeError
├── MDFIOError
├── MDFCorruptError
└── MDFConcurrencyError
```

## Project Structure

```
mdf_reader_writer/
├── mdf_reader_writer/          # Core package
│   ├── __init__.py            # Public API exports
│   ├── base.py                # Abstract lifecycle base class
│   ├── channel_buffer.py      # Per-channel in-memory accumulator
│   ├── config.py              # Typed configuration dataclass
│   ├── constants.py           # Version enums, defaults, keys
│   ├── exceptions.py          # Full exception hierarchy
│   ├── logging_utils.py       # Standardized logger factory
│   ├── models.py              # DTOs: ChannelLocation, IndexSchema, etc.
│   ├── reader.py              # MDFReader (3 modes)
│   ├── utils.py               # Path helpers, JSON, locking utilities
│   └── writer.py              # MDFWriter (3 modes)
└── tests/
    ├── test_writer.py         # Writer unit tests (lifecycle, append, extend, save)
    ├── test_reader.py         # Reader unit tests (get, range, count, fragmented)
    ├── test_advanced.py       # Edge cases, large data, concurrency, resilience
    └── test_integration.py    # End-to-end workflows across all modes
```

## Running Tests

```bash
cd mdf_reader_writer
pytest tests/ -v
```

## License

MIT License (example). See project repository for full terms.

## Author

AI Assistant, 2026-04-25
