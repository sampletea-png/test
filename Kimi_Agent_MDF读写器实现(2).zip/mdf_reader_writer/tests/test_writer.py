# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Writer Unit Tests.

Exercises all public methods of MDFWriter across the three operational modes:
NORMAL, FRAGMENTED, and STREAMING. Validates lifecycle, structural creation,
append/extend semantics, persistence, resume after stop/start, and error paths.

Run with: pytest tests/test_writer.py -v

Author: AI Assistant
Date: 2026-04-25
"""

import os
import shutil
import tempfile
import threading
import time
from pathlib import Path

import numpy as np
import pytest

# Adjust import path for the mdf_reader_writer package
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
    MDFNotStartedError,
    MDFLocationNotFoundError,
    MDFAlreadyStartedError,
    MDFIOError,
)


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    """Provide a temporary directory that is cleaned up after the test."""
    path = tempfile.mkdtemp(prefix="mdf_rw_test_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def writer_normal(temp_dir):
    """Fresh NORMAL-mode writer targeting a single file."""
    filepath = os.path.join(temp_dir, "test.mf4")
    cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
    writer = MDFWriter(filepath, config=cfg)
    yield writer
    if writer.is_started:
        writer.stop()


@pytest.fixture
def writer_fragmented(temp_dir):
    """Fresh FRAGMENTED-mode writer targeting a directory."""
    fragment_dir = os.path.join(temp_dir, "fragments")
    cfg = MDFConfig(
        mode=OperationMode.FRAGMENTED,
        version=MDFVersion.V4_10,
        fragment_threshold_bytes=1024,  # very small for testing
        overwrite_on_start=True,
    )
    writer = MDFWriter(fragment_dir, config=cfg)
    yield writer
    if writer.is_started:
        writer.stop()


@pytest.fixture
def writer_streaming(temp_dir):
    """Fresh STREAMING-mode writer targeting a single file."""
    filepath = os.path.join(temp_dir, "stream.mf4")
    cfg = MDFConfig(mode=OperationMode.STREAMING, version=MDFVersion.V4_10)
    writer = MDFWriter(filepath, config=cfg)
    yield writer
    if writer.is_started:
        writer.stop()


# ------------------------------------------------------------------
# Lifecycle tests
# ------------------------------------------------------------------

class TestLifecycle:
    """Validate start/stop/context-manager behavior and state guards."""

    def test_start_stop_idempotent(self, writer_normal):
        """Calling stop() twice must not raise."""
        writer_normal.start()
        assert writer_normal.is_started
        writer_normal.stop()
        assert not writer_normal.is_started
        writer_normal.stop()  # should be idempotent
        assert not writer_normal.is_started

    def test_double_start_raises(self, writer_normal):
        """Calling start() twice without stop() must raise MDFAlreadyStartedError."""
        writer_normal.start()
        with pytest.raises(MDFAlreadyStartedError):
            writer_normal.start()

    def test_context_manager(self, temp_dir):
        """Using writer as context manager should auto-start/stop."""
        filepath = os.path.join(temp_dir, "ctx.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        with MDFWriter(filepath, config=cfg) as w:
            assert w.is_started
            dg = w.create_data_group(DataGroupAttributes(comment="ctx"))
            assert dg == 0
        assert not w.is_started

    def test_operation_before_start_raises(self, writer_normal):
        """Any structural mutation before start() raises MDFNotStartedError."""
        with pytest.raises(MDFNotStartedError):
            writer_normal.create_data_group(DataGroupAttributes())


# ------------------------------------------------------------------
# Structural creation tests
# ------------------------------------------------------------------

class TestStructuralCreation:
    """Validate create_data_group, create_channel_group, create_channel."""

    def test_create_data_group_returns_incrementing_indices(self, writer_normal):
        writer_normal.start()
        dg0 = writer_normal.create_data_group(DataGroupAttributes(comment="A"))
        dg1 = writer_normal.create_data_group(DataGroupAttributes(comment="B"))
        assert dg0 == 0
        assert dg1 == 1

    def test_create_channel_group_returns_zero(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes(comment="CG"))
        assert cg == 0

    def test_create_channel_returns_incrementing_indices(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch0 = writer_normal.create_channel(dg, cg, "Speed", ChannelAttributes(unit="m/s"))
        ch1 = writer_normal.create_channel(dg, cg, "Temp", ChannelAttributes(unit="C"))
        assert ch0 == 0
        assert ch1 == 1

    def test_create_channel_group_missing_dg_raises(self, writer_normal):
        writer_normal.start()
        with pytest.raises(MDFLocationNotFoundError):
            writer_normal.create_channel_group(99, ChannelGroupAttributes())

    def test_create_channel_missing_dg_raises(self, writer_normal):
        writer_normal.start()
        with pytest.raises(MDFLocationNotFoundError):
            writer_normal.create_channel(99, 0, "X", ChannelAttributes())

    def test_create_channel_missing_cg_raises(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        # cg not created yet
        with pytest.raises(MDFLocationNotFoundError):
            writer_normal.create_channel(dg, 0, "X", ChannelAttributes())


# ------------------------------------------------------------------
# Existence query tests
# ------------------------------------------------------------------

class TestExists:
    """Validate the exists() predicate across lifecycle states."""

    def test_exists_after_creation(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        assert writer_normal.exists(dg, cg, ch)
        assert not writer_normal.exists(dg, cg, 999)

    def test_exists_before_start_raises(self, writer_normal):
        with pytest.raises(MDFNotStartedError):
            writer_normal.exists(0, 0, 0)


# ------------------------------------------------------------------
# Append / Extend tests
# ------------------------------------------------------------------

class TestAppendExtend:
    """Validate append() and extend() semantics and error paths."""

    def test_append_to_nonexistent_location_raises(self, writer_normal):
        writer_normal.start()
        t = np.array([0.0, 1.0, 2.0])
        s = np.array([10, 20, 30])
        with pytest.raises(MDFLocationNotFoundError):
            writer_normal.append(0, 0, 0, t, s)

    def test_extend_to_nonexistent_location_raises(self, writer_normal):
        writer_normal.start()
        t = np.array([0.0, 1.0])
        s = np.array([1, 2])
        with pytest.raises(MDFLocationNotFoundError):
            writer_normal.extend(0, 0, 0, t, s)

    def test_extend_before_append_raises(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        t = np.array([0.0, 1.0])
        s = np.array([1, 2])
        with pytest.raises(ValueError, match="no existing data"):
            writer_normal.extend(dg, cg, ch, t, s)

    def test_append_creates_data(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        t = np.array([0.0, 1.0, 2.0])
        s = np.array([10, 20, 30])
        writer_normal.append(dg, cg, ch, t, s)
        # Buffers are internal; we verify indirectly via save + read later
        assert writer_normal._groups[dg].channels[ch].has_data
        assert writer_normal._groups[dg].channels[ch].sample_count == 3

    def test_extend_concatenates(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        writer_normal.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        writer_normal.extend(dg, cg, ch, np.array([2.0, 3.0]), np.array([3, 4]))
        buf = writer_normal._groups[dg].channels[ch]
        assert buf.sample_count == 4
        ts, samples = buf.get_merged()
        np.testing.assert_array_equal(ts, [0.0, 1.0, 2.0, 3.0])
        np.testing.assert_array_equal(samples, [1, 2, 3, 4])

    def test_append_clears_previous_data(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        writer_normal.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer_normal.append(dg, cg, ch, np.array([5.0, 6.0]), np.array([50, 60]))
        buf = writer_normal._groups[dg].channels[ch]
        assert buf.sample_count == 2
        ts, samples = buf.get_merged()
        np.testing.assert_array_equal(ts, [5.0, 6.0])

    def test_extend_continuity_validation(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        writer_normal.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        # Non-monotonic extend should raise
        with pytest.raises(ValueError, match="continue"):
            writer_normal.extend(dg, cg, ch, np.array([0.5]), np.array([99]))

    def test_validation_length_mismatch(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        with pytest.raises(ValueError):
            writer_normal.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1]))


# ------------------------------------------------------------------
# Save / Persistence tests
# ------------------------------------------------------------------

class TestSaveAndPersistence:
    """Validate save() writes readable MDF and resume works after stop/start."""

    def test_save_creates_file(self, writer_normal, temp_dir):
        filepath = writer_normal.filepath
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes(comment="save_test"))
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "Speed", ChannelAttributes(unit="km/h"))
        writer_normal.append(dg, cg, ch, np.array([0.0, 1.0, 2.0]), np.array([10, 20, 30]))
        writer_normal.save()
        writer_normal.stop()
        assert os.path.exists(filepath)
        assert os.path.getsize(filepath) > 0

    def test_save_overwrite_idempotent(self, writer_normal):
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes())
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "X", ChannelAttributes())
        writer_normal.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer_normal.save()
        writer_normal.save()  # second save should overwrite safely
        writer_normal.stop()

    def test_resume_structure_after_stop_start(self, writer_normal):
        """After stop and restart, structural registry must be restored."""
        writer_normal.start()
        dg = writer_normal.create_data_group(DataGroupAttributes(comment="resume"))
        cg = writer_normal.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_normal.create_channel(dg, cg, "Y", ChannelAttributes())
        writer_normal.append(dg, cg, ch, np.array([0.0]), np.array([42]))
        writer_normal.save()
        writer_normal.stop()

        # Restart same writer instance
        writer_normal.start()
        assert writer_normal.exists(dg, cg, ch)
        # New data can be appended
        writer_normal.append(dg, cg, ch, np.array([1.0]), np.array([43]))
        writer_normal.save()
        writer_normal.stop()

    def test_multiple_groups_save(self, temp_dir):
        filepath = os.path.join(temp_dir, "multi.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg0 = writer.create_data_group(DataGroupAttributes(comment="G0"))
        cg0 = writer.create_channel_group(dg0, ChannelGroupAttributes())
        ch0 = writer.create_channel(dg0, cg0, "A", ChannelAttributes())
        writer.append(dg0, cg0, ch0, np.array([0.0, 1.0]), np.array([1, 2]))

        dg1 = writer.create_data_group(DataGroupAttributes(comment="G1"))
        cg1 = writer.create_channel_group(dg1, ChannelGroupAttributes())
        ch1 = writer.create_channel(dg1, cg1, "B", ChannelAttributes())
        writer.append(dg1, cg1, ch1, np.array([0.0, 1.0]), np.array([3, 4]))

        writer.save()
        writer.stop()
        assert os.path.exists(filepath)


# ------------------------------------------------------------------
# Fragmented mode tests
# ------------------------------------------------------------------

class TestFragmentedMode:
    """Validate FRAGMENTED-mode shard creation, rotation, and index persistence."""

    def test_fragment_directory_created(self, writer_fragmented):
        writer_fragmented.start()
        assert os.path.isdir(writer_fragmented.filepath)

    def test_fragment_rotation_on_threshold(self, writer_fragmented):
        """With a tiny threshold, multiple save() calls should create shards."""
        writer_fragmented.start()
        dg = writer_fragmented.create_data_group(DataGroupAttributes())
        cg = writer_fragmented.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_fragmented.create_channel(dg, cg, "Big", ChannelAttributes())
        # Append enough data to exceed 1024 bytes after a few saves
        for i in range(5):
            data = np.arange(1000, dtype=np.float64)
            ts = data * 0.001 + i
            writer_fragmented.append(dg, cg, ch, ts, data)
            writer_fragmented.save()
        writer_fragmented.stop()

        # There should be at least one fragment file
        frag_files = [
            f for f in os.listdir(writer_fragmented.filepath)
            if f.endswith(".mf4") and not f.startswith("index")
        ]
        assert len(frag_files) >= 1

    def test_index_schema_persisted(self, writer_fragmented):
        writer_fragmented.start()
        dg = writer_fragmented.create_data_group(DataGroupAttributes(comment="idx"))
        cg = writer_fragmented.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_fragmented.create_channel(dg, cg, "X", ChannelAttributes())
        writer_fragmented.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer_fragmented.save()
        writer_fragmented.stop()

        schema_path = os.path.join(writer_fragmented.filepath, "index.schema.json")
        assert os.path.exists(schema_path)

    def test_fragmented_resume(self, writer_fragmented):
        writer_fragmented.start()
        dg = writer_fragmented.create_data_group(DataGroupAttributes(comment="resume_frag"))
        cg = writer_fragmented.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_fragmented.create_channel(dg, cg, "Z", ChannelAttributes())
        writer_fragmented.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer_fragmented.save()
        writer_fragmented.stop()

        writer_fragmented.start()
        assert writer_fragmented.exists(dg, cg, ch)
        writer_fragmented.append(dg, cg, ch, np.array([1.0]), np.array([2]))
        writer_fragmented.save()
        writer_fragmented.stop()


# ------------------------------------------------------------------
# Streaming mode tests
# ------------------------------------------------------------------

class TestStreamingMode:
    """Validate STREAMING-mode file creation and configuration."""

    def test_streaming_file_created(self, writer_streaming):
        writer_streaming.start()
        dg = writer_streaming.create_data_group(DataGroupAttributes())
        cg = writer_streaming.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer_streaming.create_channel(dg, cg, "S", ChannelAttributes())
        writer_streaming.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        writer_streaming.save()
        writer_streaming.stop()
        assert os.path.exists(writer_streaming.filepath)

    def test_streaming_overwrite_config(self, temp_dir):
        filepath = os.path.join(temp_dir, "stream2.mf4")
        cfg = MDFConfig(
            mode=OperationMode.STREAMING,
            version=MDFVersion.V4_10,
            overwrite_on_start=True,
        )
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Q", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer.save()
        writer.stop()
        assert os.path.exists(filepath)


# ------------------------------------------------------------------
# Version tests (3.x vs 4.x)
# ------------------------------------------------------------------

class TestVersionSupport:
    """Validate MDF 3.x and 4.x file creation."""

    def test_mdf3_file_extension(self, temp_dir):
        filepath = os.path.join(temp_dir, "v3.mdf")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V3_30)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "V3", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        writer.save()
        writer.stop()
        assert os.path.exists(filepath)
        # Verify it is a valid MDF by quick size check
        assert os.path.getsize(filepath) > 0

    def test_mdf4_file_extension(self, temp_dir):
        filepath = os.path.join(temp_dir, "v4.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "V4", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([1, 2]))
        writer.save()
        writer.stop()
        assert os.path.exists(filepath)


# ------------------------------------------------------------------
# Concurrency tests (writer side)
# ------------------------------------------------------------------

class TestWriterConcurrency:
    """Validate thread-safe access with concurrent appends."""

    def test_concurrent_appends_on_shared_channel(self, temp_dir):
        filepath = os.path.join(temp_dir, "concurrent.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Counter", ChannelAttributes())

        errors = []

        def worker(offset):
            try:
                for i in range(50):
                    t = np.array([offset + i * 0.1])
                    s = np.array([offset * 100 + i])
                    writer.append(dg, cg, ch, t, s)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(k * 10,)) for k in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent append errors: {errors}"
        writer.save()
        writer.stop()
        assert os.path.exists(filepath)
