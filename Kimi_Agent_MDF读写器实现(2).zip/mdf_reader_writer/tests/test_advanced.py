# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Advanced & Edge-Case Tests.

Production-grade validation covering:
  - Large dataset throughput and memory stability
  - Boundary conditions (empty arrays, single-sample writes)
  - Timestamp misalignment across channels in the same group
  - Reader/Writer concurrent interaction
  - Resource cleanup verification after stop()
  - Error recovery and malformed input resilience

Run with: pytest tests/test_advanced.py -v

Author: AI Assistant
Date: 2026-04-25
"""

import gc
import os
import shutil
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
    MDFLocationNotFoundError,
    MDFIOError,
    MDFNotStartedError,
)


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    path = tempfile.mkdtemp(prefix="mdf_adv_test_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


# ------------------------------------------------------------------
# Large dataset / performance tests
# ------------------------------------------------------------------

class TestLargeDatasets:
    """Validate memory stability and correctness with high sample counts."""

    def test_million_samples_single_channel(self, temp_dir):
        """Write and read back 1M samples without memory blow-up."""
        filepath = os.path.join(temp_dir, "large.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes(comment="large"))
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Big", ChannelAttributes(unit="V"))

        n = 1_000_000
        t = np.linspace(0, 1000, n, dtype=np.float64)
        s = np.sin(t, dtype=np.float64)
        writer.append(dg, cg, ch, t, s)
        writer.save()
        writer.stop()

        # Force garbage collect before reader
        gc.collect()

        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        assert len(ts) == n
        assert len(samples) == n
        np.testing.assert_allclose(samples, np.sin(ts), atol=1e-5)

    def test_many_small_appends(self, temp_dir):
        """Simulate real-time streaming with thousands of small appends."""
        filepath = os.path.join(temp_dir, "streaming_sim.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes(comment="stream"))
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "Stream", ChannelAttributes())

        total = 0
        # Prime the channel with an initial append
        writer.append(dg, cg, ch, np.linspace(0, 0.9, 10, dtype=np.float64), np.zeros(10, dtype=np.float64))
        total += 10
        for i in range(1, 500):
            chunk_t = np.linspace(i, i + 0.9, 10, dtype=np.float64)
            chunk_s = np.full(10, i, dtype=np.float64)
            writer.extend(dg, cg, ch, chunk_t, chunk_s)
            total += 10

        writer.save()
        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        assert len(ts) == total
        assert samples[0] == 0.0
        assert samples[-1] == 499.0


# ------------------------------------------------------------------
# Boundary conditions
# ------------------------------------------------------------------

class TestBoundaryConditions:
    """Edge cases that often trip up production systems."""

    def test_single_sample_append(self, temp_dir):
        """A channel with exactly one sample must round-trip correctly."""
        filepath = os.path.join(temp_dir, "single.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "One", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0]), np.array([42.0]))
        writer.save()
        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        assert len(ts) == 1
        assert samples[0] == 42.0

    def test_empty_group_save(self, temp_dir):
        """Saving a writer that has groups but no channel data must not crash."""
        filepath = os.path.join(temp_dir, "empty_group.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        writer.create_channel_group(dg, ChannelGroupAttributes())
        writer.create_channel(dg, 0, "Empty", ChannelAttributes())
        # No append
        writer.save()
        writer.stop()
        assert os.path.exists(filepath)

    def test_two_channel_misaligned_timestamps(self, temp_dir):
        """
        Channels in the same group with different-length timestamps
        must be truncated to the shortest length with a warning.
        """
        filepath = os.path.join(temp_dir, "misaligned.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch0 = writer.create_channel(dg, cg, "A", ChannelAttributes())
        ch1 = writer.create_channel(dg, cg, "B", ChannelAttributes())

        writer.append(dg, cg, ch0, np.array([0.0, 1.0, 2.0]), np.array([1, 2, 3]))
        writer.append(dg, cg, ch1, np.array([0.0, 1.0]), np.array([10, 20]))
        writer.save()
        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        ts_a, samples_a = reader.get(dg, cg, ch0)
        ts_b, samples_b = reader.get(dg, cg, ch1)
        reader.stop()

        # Both should be truncated to the shorter length (2)
        assert len(ts_a) == 2
        assert len(ts_b) == 2
        np.testing.assert_array_equal(samples_a, [1, 2])
        np.testing.assert_array_equal(samples_b, [10, 20])

    def test_unicode_channel_names(self, temp_dir):
        """Channel names with unicode characters must persist correctly."""
        filepath = os.path.join(temp_dir, "unicode.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes(comment="中文测试"))
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "温度_°C", ChannelAttributes(unit="°C"))
        writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([20.0, 21.0]))
        writer.save()
        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        name = reader.get_channel_name(dg, cg, ch)
        ts, samples = reader.get(dg, cg, ch)
        reader.stop()

        assert name == "温度_°C"
        np.testing.assert_array_almost_equal(samples, [20.0, 21.0])


# ------------------------------------------------------------------
# Resource cleanup tests
# ------------------------------------------------------------------

class TestResourceCleanup:
    """Verify that stop() releases all file handles and temporary state."""

    def test_stop_releases_file_handle(self, temp_dir):
        """After stop(), the MDF file must be movable/deletable."""
        filepath = os.path.join(temp_dir, "handle.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "X", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer.save()
        writer.stop()

        # Should be able to rename (proves handle released on Windows/Linux)
        new_path = os.path.join(temp_dir, "handle_renamed.mf4")
        os.rename(filepath, new_path)
        assert os.path.exists(new_path)

    def test_reader_stop_releases_handle(self, temp_dir):
        """After reader stop(), the file must be deletable."""
        filepath = os.path.join(temp_dir, "read_handle.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "X", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0]), np.array([1]))
        writer.save()
        writer.stop()

        reader = MDFReader(filepath)
        reader.start()
        reader.get(dg, cg, ch)
        reader.stop()

        os.unlink(filepath)
        assert not os.path.exists(filepath)

    def test_fragmented_stop_cleans_fragments(self, temp_dir):
        """FRAGMENTED writer stop must leave only valid fragment/index files."""
        frag_dir = os.path.join(temp_dir, "frag_stop")
        cfg = MDFConfig(
            mode=OperationMode.FRAGMENTED,
            version=MDFVersion.V4_10,
            fragment_threshold_bytes=512,
            overwrite_on_start=True,
        )
        writer = MDFWriter(frag_dir, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "X", ChannelAttributes())
        t = np.linspace(0, 10, 1000)
        writer.append(dg, cg, ch, t, t * 2)
        writer.save()
        writer.stop()

        # Only expected files should exist
        files = set(os.listdir(frag_dir))
        expected_ext = {".mf4", ".json"}
        for f in files:
            assert Path(f).suffix in expected_ext, f"Unexpected file: {f}"


# ------------------------------------------------------------------
# Concurrent reader + writer tests
# ------------------------------------------------------------------

class TestConcurrentReaderWriter:
    """Validate thread safety when reader and writer overlap (different files)."""

    def test_concurrent_write_and_read_separate_files(self, temp_dir):
        """Write to file A while reading from file B in parallel threads."""
        filepath_a = os.path.join(temp_dir, "a.mf4")
        filepath_b = os.path.join(temp_dir, "b.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)

        # Pre-create file B
        writer_b = MDFWriter(filepath_b, config=cfg)
        writer_b.start()
        dg_b = writer_b.create_data_group(DataGroupAttributes())
        cg_b = writer_b.create_channel_group(dg_b, ChannelGroupAttributes())
        ch_b = writer_b.create_channel(dg_b, cg_b, "B", ChannelAttributes())
        writer_b.append(dg_b, cg_b, ch_b, np.array([0.0, 1.0]), np.array([1, 2]))
        writer_b.save()
        writer_b.stop()

        writer_a = MDFWriter(filepath_a, config=cfg)
        reader_b = MDFReader(filepath_b)
        writer_a.start()
        reader_b.start()

        errors = []

        def write_worker():
            try:
                dg_a = writer_a.create_data_group(DataGroupAttributes())
                cg_a = writer_a.create_channel_group(dg_a, ChannelGroupAttributes())
                ch_a = writer_a.create_channel(dg_a, cg_a, "A", ChannelAttributes())
                for i in range(100):
                    writer_a.append(dg_a, cg_a, ch_a, np.array([i]), np.array([i * 2]))
                writer_a.save()
            except Exception as exc:
                errors.append(exc)

        def read_worker():
            try:
                for _ in range(100):
                    ts, s = reader_b.get(dg_b, cg_b, ch_b)
                    assert len(ts) == 2
            except Exception as exc:
                errors.append(exc)

        t_write = threading.Thread(target=write_worker)
        t_read = threading.Thread(target=read_worker)
        t_write.start()
        t_read.start()
        t_write.join()
        t_read.join()

        writer_a.stop()
        reader_b.stop()

        assert not errors, f"Concurrent R/W errors: {errors}"


# ------------------------------------------------------------------
# Error recovery / resilience tests
# ------------------------------------------------------------------

class TestResilience:
    """System behavior under abnormal or hostile inputs."""

    def test_extend_with_non_monotonic_timestamps(self, temp_dir):
        """Extend that breaks monotonicity must raise ValueError."""
        filepath = os.path.join(temp_dir, "bad_extend.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        dg = writer.create_data_group(DataGroupAttributes())
        cg = writer.create_channel_group(dg, ChannelGroupAttributes())
        ch = writer.create_channel(dg, cg, "X", ChannelAttributes())
        writer.append(dg, cg, ch, np.array([0.0, 1.0, 2.0]), np.array([1, 2, 3]))
        with pytest.raises(ValueError):
            writer.extend(dg, cg, ch, np.array([1.5]), np.array([99]))
        writer.stop()

    def test_get_from_nonexistent_file_raises(self, temp_dir):
        """Starting a reader on a missing file must raise MDFIOError."""
        filepath = os.path.join(temp_dir, "missing.mf4")
        reader = MDFReader(filepath)
        with pytest.raises(MDFIOError):
            reader.start()

    def test_double_stop_is_idempotent(self, temp_dir):
        """Calling stop() twice must not raise or corrupt state."""
        filepath = os.path.join(temp_dir, "idempotent.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = MDFWriter(filepath, config=cfg)
        writer.start()
        writer.stop()
        writer.stop()
        writer.stop()
        assert writer.is_closed
        assert not writer.is_started

    def test_context_manager_exception_handling(self, temp_dir):
        """Exceptions inside a context manager must still trigger stop()."""
        filepath = os.path.join(temp_dir, "ctx_exc.mf4")
        cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
        writer = None
        try:
            with MDFWriter(filepath, config=cfg) as w:
                writer = w
                dg = w.create_data_group(DataGroupAttributes())
                cg = w.create_channel_group(dg, ChannelGroupAttributes())
                w.create_channel(dg, cg, "X", ChannelAttributes())
                raise RuntimeError("boom")
        except RuntimeError:
            pass
        # Verify that the writer was stopped by the context manager __exit__
        assert writer is not None
        assert not writer.is_started
        assert writer.is_closed

    def test_fragmented_corrupt_schema_raises(self, temp_dir):
        """A corrupt schema JSON must raise MDFIOError on reader start."""
        frag_dir = os.path.join(temp_dir, "corrupt_frag")
        os.makedirs(frag_dir, exist_ok=True)
        # Write garbage as schema
        with open(os.path.join(frag_dir, "index.schema.json"), "w") as f:
            f.write("this is not json{!")

        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(frag_dir, config=cfg)
        with pytest.raises(MDFIOError):
            reader.start()


# ------------------------------------------------------------------
# Version interoperability tests
# ------------------------------------------------------------------

class TestVersionInterop:
    """Validate that version 3.x and 4.x files can coexist and be read."""

    def test_mdf3_and_mdf4_side_by_side(self, temp_dir):
        """Create one .mdf and one .mf4 and read both in the same session."""
        mdf3_path = os.path.join(temp_dir, "v3.mdf")
        mf4_path = os.path.join(temp_dir, "v4.mf4")

        for path, ver in [(mdf3_path, MDFVersion.V3_30), (mf4_path, MDFVersion.V4_10)]:
            cfg = MDFConfig(mode=OperationMode.NORMAL, version=ver)
            writer = MDFWriter(path, config=cfg)
            writer.start()
            dg = writer.create_data_group(DataGroupAttributes())
            cg = writer.create_channel_group(dg, ChannelGroupAttributes())
            ch = writer.create_channel(dg, cg, "Speed", ChannelAttributes(unit="m/s"))
            writer.append(dg, cg, ch, np.array([0.0, 1.0]), np.array([0.0, 10.0]))
            writer.save()
            writer.stop()

        for path, ver in [(mdf3_path, MDFVersion.V3_30), (mf4_path, MDFVersion.V4_10)]:
            cfg = MDFConfig(mode=OperationMode.NORMAL, version=ver)
            reader = MDFReader(path, config=cfg)
            reader.start()
            groups = reader.list_data_groups()
            assert len(groups) >= 1
            reader.stop()
