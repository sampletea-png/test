# -*- coding: utf-8 -*-
"""
MDF Reader/Writer Package - Reader Unit Tests.

Exercises all public methods of MDFReader across the three operational modes.
Validates lifecycle, get/get_range/get_from_time variants, fragmented stitching,
error paths, and thread-safe concurrent reads.

Run with: pytest tests/test_reader.py -v

Author: AI Assistant
Date: 2026-04-25
"""

import os
import shutil
import sys
import tempfile
import threading
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mdf_reader_writer import (
    MDFWriter,
    MDFReader,
    MDFConfig,
    OperationMode,
    MDFVersion,
    DataGroupAttributes,
    ChannelGroupAttributes,
    ChannelAttributes,
    MDFNotStartedError,
    MDFLocationNotFoundError,
    MDFIOError,
)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _make_single_file(path: str) -> tuple:
    """
    Create a simple MDF4 file with one group and two channels.

    Returns
    -------
    (dg, cg, ch0, ch1) indices used during creation.
    """
    cfg = MDFConfig(mode=OperationMode.NORMAL, version=MDFVersion.V4_10)
    writer = MDFWriter(path, config=cfg)
    writer.start()
    dg = writer.create_data_group(DataGroupAttributes(comment="reader_test"))
    cg = writer.create_channel_group(dg, ChannelGroupAttributes())
    ch0 = writer.create_channel(dg, cg, "Sine", ChannelAttributes(unit="V"))
    ch1 = writer.create_channel(dg, cg, "Cosine", ChannelAttributes(unit="V"))
    t = np.linspace(0, 10, 1001)
    writer.append(dg, cg, ch0, t, np.sin(t))
    writer.append(dg, cg, ch1, t, np.cos(t))
    writer.save()
    writer.stop()
    return dg, cg, ch0, ch1


def _make_fragmented_dir(dirpath: str) -> tuple:
    """
    Create a fragmented MDF dataset with two data groups across shards.
    Returns creation indices.
    """
    cfg = MDFConfig(
        mode=OperationMode.FRAGMENTED,
        version=MDFVersion.V4_10,
        fragment_threshold_bytes=1024,
        overwrite_on_start=True,
    )
    writer = MDFWriter(dirpath, config=cfg)
    writer.start()
    dg0 = writer.create_data_group(DataGroupAttributes(comment="frag0"))
    cg0 = writer.create_channel_group(dg0, ChannelGroupAttributes())
    ch0 = writer.create_channel(dg0, cg0, "A", ChannelAttributes())
    t = np.linspace(0, 5, 500)
    writer.append(dg0, cg0, ch0, t, t * 2)
    writer.save()

    dg1 = writer.create_data_group(DataGroupAttributes(comment="frag1"))
    cg1 = writer.create_channel_group(dg1, ChannelGroupAttributes())
    ch1 = writer.create_channel(dg1, cg1, "B", ChannelAttributes())
    t2 = np.linspace(0, 3, 300)
    writer.append(dg1, cg1, ch1, t2, t2 ** 2)
    writer.save()
    writer.stop()
    return dg0, cg0, ch0, dg1, cg1, ch1


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    path = tempfile.mkdtemp(prefix="mdf_reader_test_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def sample_file(temp_dir):
    filepath = os.path.join(temp_dir, "sample.mf4")
    dg, cg, ch0, ch1 = _make_single_file(filepath)
    return filepath, dg, cg, ch0, ch1


@pytest.fixture
def fragmented_dir(temp_dir):
    dirpath = os.path.join(temp_dir, "frags")
    dg0, cg0, ch0, dg1, cg1, ch1 = _make_fragmented_dir(dirpath)
    return dirpath, dg0, cg0, ch0, dg1, cg1, ch1


# ------------------------------------------------------------------
# Lifecycle tests
# ------------------------------------------------------------------

class TestReaderLifecycle:
    def test_start_stop_idempotent(self, sample_file):
        filepath, *_ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        assert reader.is_started
        reader.stop()
        assert not reader.is_started
        reader.stop()

    def test_context_manager(self, sample_file):
        filepath, dg, cg, ch0, ch1 = sample_file
        with MDFReader(filepath) as r:
            ts, samples = r.get(dg, cg, ch0)
            assert len(ts) == 1001

    def test_read_before_start_raises(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        with pytest.raises(MDFNotStartedError):
            reader.get(dg, cg, ch0)


# ------------------------------------------------------------------
# Retrieval tests (normal mode)
# ------------------------------------------------------------------

class TestReaderGet:
    def test_get_full_channel(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch0)
        reader.stop()
        assert len(ts) == 1001
        np.testing.assert_allclose(samples, np.sin(ts), atol=1e-6)

    def test_get_second_channel(self, sample_file):
        filepath, dg, cg, _, ch1 = sample_file
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get(dg, cg, ch1)
        reader.stop()
        np.testing.assert_allclose(samples, np.cos(ts), atol=1e-6)

    def test_get_missing_location_raises(self, sample_file):
        filepath, dg, cg, _, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        with pytest.raises(MDFLocationNotFoundError):
            reader.get(dg, cg, 999)
        reader.stop()

    def test_get_range_window(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get_range(dg, cg, ch0, 2.0, 5.0)
        reader.stop()
        assert ts[0] >= 2.0
        assert ts[-1] < 5.0
        np.testing.assert_allclose(samples, np.sin(ts), atol=1e-6)

    def test_get_range_empty_window(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get_range(dg, cg, ch0, 100.0, 200.0)
        reader.stop()
        assert len(ts) == 0
        assert len(samples) == 0

    def test_get_range_invalid_window_raises(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        with pytest.raises(ValueError):
            reader.get_range(dg, cg, ch0, 5.0, 2.0)
        reader.stop()

    def test_get_from_time_count_limit(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        ts, samples = reader.get_from_time(dg, cg, ch0, start_time=2.0, max_count=50)
        reader.stop()
        assert len(ts) <= 50
        assert ts[0] >= 2.0

    def test_get_from_time_zero_count_raises(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        with pytest.raises(ValueError):
            reader.get_from_time(dg, cg, ch0, start_time=0.0, max_count=0)
        reader.stop()


# ------------------------------------------------------------------
# Retrieval tests (fragmented mode)
# ------------------------------------------------------------------

class TestFragmentedReader:
    def test_fragmented_list_groups(self, fragmented_dir):
        dirpath, dg0, cg0, ch0, dg1, cg1, ch1 = fragmented_dir
        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(dirpath, config=cfg)
        reader.start()
        groups = reader.list_data_groups()
        reader.stop()
        assert dg0 in groups
        assert dg1 in groups

    def test_fragmented_read_first_group(self, fragmented_dir):
        dirpath, dg0, cg0, ch0, _, _, _ = fragmented_dir
        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(dirpath, config=cfg)
        reader.start()
        ts, samples = reader.get(dg0, cg0, ch0)
        reader.stop()
        assert len(ts) == 500
        np.testing.assert_array_almost_equal(samples, ts * 2)

    def test_fragmented_read_second_group(self, fragmented_dir):
        dirpath, _, _, _, dg1, cg1, ch1 = fragmented_dir
        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(dirpath, config=cfg)
        reader.start()
        ts, samples = reader.get(dg1, cg1, ch1)
        reader.stop()
        assert len(ts) == 300
        np.testing.assert_array_almost_equal(samples, ts ** 2)

    def test_fragmented_get_range(self, fragmented_dir):
        dirpath, dg0, cg0, ch0, _, _, _ = fragmented_dir
        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(dirpath, config=cfg)
        reader.start()
        ts, samples = reader.get_range(dg0, cg0, ch0, 1.0, 3.0)
        reader.stop()
        assert len(ts) > 0
        assert ts[0] >= 1.0
        assert ts[-1] < 3.0

    def test_fragmented_file_info(self, fragmented_dir):
        dirpath, *_ = fragmented_dir
        cfg = MDFConfig(mode=OperationMode.FRAGMENTED, version=MDFVersion.V4_10)
        reader = MDFReader(dirpath, config=cfg)
        reader.start()
        info = reader.file_info()
        reader.stop()
        assert info["mode"] == "FRAGMENTED"
        assert "fragments" in info


# ------------------------------------------------------------------
# Informational API tests
# ------------------------------------------------------------------

class TestReaderInfo:
    def test_list_channels(self, sample_file):
        filepath, dg, cg, ch0, ch1 = sample_file
        reader = MDFReader(filepath)
        reader.start()
        channels = reader.list_channels(dg)
        reader.stop()
        names = [name for _, name in channels]
        assert "Sine" in names
        assert "Cosine" in names

    def test_get_channel_name(self, sample_file):
        filepath, dg, cg, ch0, _ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        name = reader.get_channel_name(dg, cg, ch0)
        reader.stop()
        assert name == "Sine"

    def test_file_info_normal(self, sample_file):
        filepath, *_ = sample_file
        reader = MDFReader(filepath)
        reader.start()
        info = reader.file_info()
        reader.stop()
        assert info["mode"] == "NORMAL"
        assert info["groups_count"] >= 1


# ------------------------------------------------------------------
# Concurrency tests (reader side)
# ------------------------------------------------------------------

class TestReaderConcurrency:
    def test_concurrent_gets(self, sample_file):
        filepath, dg, cg, ch0, ch1 = sample_file
        reader = MDFReader(filepath)
        reader.start()
        results = {"ch0": [], "ch1": [], "errors": []}

        def worker_ch0():
            try:
                for _ in range(20):
                    ts, s = reader.get(dg, cg, ch0)
                    results["ch0"].append((ts, s))
            except Exception as exc:
                results["errors"].append(exc)

        def worker_ch1():
            try:
                for _ in range(20):
                    ts, s = reader.get(dg, cg, ch1)
                    results["ch1"].append((ts, s))
            except Exception as exc:
                results["errors"].append(exc)

        t0 = threading.Thread(target=worker_ch0)
        t1 = threading.Thread(target=worker_ch1)
        t0.start()
        t1.start()
        t0.join()
        t1.join()
        reader.stop()

        assert not results["errors"], f"Concurrent read errors: {results['errors']}"
        assert len(results["ch0"]) == 20
        assert len(results["ch1"]) == 20
